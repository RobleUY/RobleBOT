const fs = require('fs');
const path = require('path');
const os = require('os');
const chalk = require('chalk');

/**
 * Sistema de limpieza automática de archivos temporales del bot
 * Limpia archivos generados por comandos de stickers, MENCIONAR, conversiones, etc.
 */

class TempCleaner {
    constructor() {
        this.tempDir = os.tmpdir();
        this.maxAgeMinutes = 15; // Limpiar archivos más antiguos que 15 minutos
        this.cleanupInterval = null;
        this.isRunning = false;
    }

    /**
     * Verifica si un archivo parece ser generado por el bot
     */
    isBotTempFile(fileName, stats) {
        // Patrones de archivos temporales del bot
        const botPatterns = [
            /^[a-f0-9]{20,}\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i, // Archivos con nombres hex + extensión media
            /^[a-f0-9]{20,}$/i, // Archivos con solo nombres hex (sin extensión)
            /^tmp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i, // Archivos que empiecen con tmp_
            /^temp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i, // Archivos que empiecen con temp_
        ];

        // Verificar si coincide con algún patrón
        const matchesPattern = botPatterns.some(pattern => pattern.test(fileName));
        
        if (!matchesPattern) return false;

        // Verificar edad del archivo (solo limpiar archivos antiguos)
        const ageMinutes = (Date.now() - stats.mtime.getTime()) / (1000 * 60);
        return ageMinutes > this.maxAgeMinutes;
    }

    /**
     * Limpia archivos temporales del bot
     */
    async cleanTempFiles() {
        if (this.isRunning) return { cleaned: 0, errors: 0, skipped: 'already_running' };

        this.isRunning = true;
        let cleaned = 0;
        let errors = 0;
        let totalSize = 0;

        try {
            if (!fs.existsSync(this.tempDir)) {
                console.log(chalk.yellow('[TempCleaner] Directorio temporal no existe'));
                return { cleaned: 0, errors: 0, skipped: 'no_temp_dir' };
            }

            const files = fs.readdirSync(this.tempDir);
            
            for (const fileName of files) {
                try {
                    const filePath = path.join(this.tempDir, fileName);
                    const stats = fs.statSync(filePath);

                    // Solo procesar archivos (no directorios)
                    if (!stats.isFile()) continue;

                    // Verificar si es un archivo temporal del bot
                    if (this.isBotTempFile(fileName, stats)) {
                        const fileSize = stats.size;
                        fs.unlinkSync(filePath);
                        cleaned++;
                        totalSize += fileSize;
                    }
                } catch (error) {
                    errors++;
                    // No loguear errores individuales para evitar spam
                }
            }

            if (cleaned > 0) {
                const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
                console.log(chalk.green(`[TempCleaner] ✅ Limpiados ${cleaned} archivos temporales (${sizeMB} MB liberados)`));
            }

            return { cleaned, errors, totalSize };

        } catch (error) {
            console.error(chalk.red('[TempCleaner] Error durante limpieza:'), error.message);
            return { cleaned, errors: errors + 1, error: error.message };
        } finally {
            this.isRunning = false;
        }
    }

    /**
     * Inicia limpieza automática periódica
     */
    startPeriodicCleanup(intervalMinutes = 30) {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }

        // Limpieza inicial
        setTimeout(() => this.cleanTempFiles(), 5000); // 5 segundos después del inicio

        // Limpieza periódica
        this.cleanupInterval = setInterval(() => {
            this.cleanTempFiles();
        }, intervalMinutes * 60 * 1000);

        console.log(chalk.cyan(`[TempCleaner] 🧹 Limpieza automática iniciada (cada ${intervalMinutes} min)`));
    }

    /**
     * Detiene la limpieza automática
     */
    stopPeriodicCleanup() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
            console.log(chalk.yellow('[TempCleaner] Limpieza automática detenida'));
        }
    }

    /**
     * Limpieza manual (para usar en comandos)
     */
    async manualCleanup() {
        console.log(chalk.blue('[TempCleaner] 🧹 Iniciando limpieza manual...'));
        const result = await this.cleanTempFiles();
        
        if (result.cleaned === 0) {
            console.log(chalk.gray('[TempCleaner] No hay archivos temporales para limpiar'));
        }
        
        return result;
    }

    /**
     * Obtiene estadísticas de archivos temporales
     */
    getTempStats() {
        try {
            if (!fs.existsSync(this.tempDir)) return { files: 0, botFiles: 0, totalSize: 0 };

            const files = fs.readdirSync(this.tempDir);
            let totalFiles = 0;
            let botFiles = 0;
            let totalSize = 0;
            let botSize = 0;

            for (const fileName of files) {
                try {
                    const filePath = path.join(this.tempDir, fileName);
                    const stats = fs.statSync(filePath);

                    if (stats.isFile()) {
                        totalFiles++;
                        totalSize += stats.size;

                        if (this.isBotTempFile(fileName, stats)) {
                            botFiles++;
                            botSize += stats.size;
                        }
                    }
                } catch (error) {
                    // Ignorar errores de archivos individuales
                }
            }

            return {
                totalFiles,
                botFiles,
                totalSize: (totalSize / (1024 * 1024)).toFixed(2) + ' MB',
                botSize: (botSize / (1024 * 1024)).toFixed(2) + ' MB'
            };
        } catch (error) {
            return { error: error.message };
        }
    }
}

// Instancia global
const tempCleaner = new TempCleaner();

module.exports = {
    TempCleaner,
    tempCleaner
};