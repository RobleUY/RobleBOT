const fs = require('fs');
const path = require('path');
const os = require('os');
const chalk = require('chalk');

class TempCleaner {
    constructor() {
        this.maxAgeMinutes = 1; // Borrar todo lo que tenga más de 1 minuto

        // ✅ TODAS las carpetas donde el bot y sus librerías escriben temporales
        this.tempDirs = [
            os.tmpdir(), // /tmp del sistema
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'dist'),
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'temp'),
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'src', 'temp'),
            path.join(process.cwd(), 'tmp'),
            path.join(process.cwd(), 'temp'),
        ].filter(d => {
            try { return fs.existsSync(d); } catch { return false; }
        });

        this.cleanupInterval = null;
        this.isRunning = false;
    }

    isBotTempFile(fileName, stats) {
        const botPatterns = [
            /^[a-f0-9]{16,}\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg|video|v)$/i,
            /^[a-f0-9]{16,}$/i,
            /^tmp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i,
            /^temp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i,
            /\.(webp|mp4|gif)$/i, // en carpetas de wa-sticker-formatter cualquier webp/mp4/gif
        ];

        const matchesPattern = botPatterns.some(pattern => pattern.test(fileName));
        if (!matchesPattern) return false;

        const ageMinutes = (Date.now() - stats.mtime.getTime()) / (1000 * 60);
        return ageMinutes > this.maxAgeMinutes;
    }

    async cleanDir(dirPath) {
        let cleaned = 0;
        let totalSize = 0;

        try {
            const files = fs.readdirSync(dirPath);
            for (const fileName of files) {
                try {
                    const filePath = path.join(dirPath, fileName);
                    const stats = fs.statSync(filePath);
                    if (!stats.isFile()) continue;
                    if (this.isBotTempFile(fileName, stats)) {
                        totalSize += stats.size;
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }
                } catch (_) {}
            }
        } catch (_) {}

        return { cleaned, totalSize };
    }

    async cleanTempFiles() {
        if (this.isRunning) return { cleaned: 0, errors: 0 };
        this.isRunning = true;

        let totalCleaned = 0;
        let totalSize = 0;

        try {
            for (const dir of this.tempDirs) {
                const result = await this.cleanDir(dir);
                totalCleaned += result.cleaned;
                totalSize += result.totalSize;
            }

            if (totalCleaned > 0) {
                const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
                console.log(chalk.green(`[TempCleaner] ✅ Limpiados ${totalCleaned} archivos (${sizeMB} MB liberados)`));
            }

            return { cleaned: totalCleaned, totalSize };
        } catch (error) {
            console.error(chalk.red('[TempCleaner] Error:'), error.message);
            return { cleaned: totalCleaned, error: error.message };
        } finally {
            this.isRunning = false;
        }
    }

    startPeriodicCleanup(intervalMinutes = 2) {
        if (this.cleanupInterval) clearInterval(this.cleanupInterval);

        setTimeout(() => this.cleanTempFiles(), 5000);

        this.cleanupInterval = setInterval(() => {
            this.cleanTempFiles();
        }, intervalMinutes * 60 * 1000);

        console.log(chalk.cyan(`[TempCleaner] 🧹 Limpieza automática iniciada (cada ${intervalMinutes} min)`));
        console.log(chalk.cyan(`[TempCleaner] 📁 Monitoreando ${this.tempDirs.length} carpetas:`));
        this.tempDirs.forEach(d => console.log(chalk.gray(`  - ${d}`)));
    }

    stopPeriodicCleanup() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
            console.log(chalk.yellow('[TempCleaner] Limpieza automática detenida'));
        }
    }

    async manualCleanup() {
        console.log(chalk.blue('[TempCleaner] 🧹 Iniciando limpieza manual...'));
        const result = await this.cleanTempFiles();
        if (result.cleaned === 0) {
            console.log(chalk.gray('[TempCleaner] No hay archivos temporales para limpiar'));
        }
        return result;
    }

    getTempStats() {
        let totalFiles = 0;
        let botFiles = 0;
        let totalSize = 0;
        let botSize = 0;

        for (const dir of this.tempDirs) {
            try {
                const files = fs.readdirSync(dir);
                for (const fileName of files) {
                    try {
                        const filePath = path.join(dir, fileName);
                        const stats = fs.statSync(filePath);
                        if (!stats.isFile()) continue;
                        totalFiles++;
                        totalSize += stats.size;
                        if (this.isBotTempFile(fileName, stats)) {
                            botFiles++;
                            botSize += stats.size;
                        }
                    } catch (_) {}
                }
            } catch (_) {}
        }

        return {
            totalFiles,
            botFiles,
            totalSize: (totalSize / (1024 * 1024)).toFixed(2) + ' MB',
            botSize: (botSize / (1024 * 1024)).toFixed(2) + ' MB',
            dirs: this.tempDirs
        };
    }
}

const tempCleaner = new TempCleaner();

module.exports = { TempCleaner, tempCleaner };