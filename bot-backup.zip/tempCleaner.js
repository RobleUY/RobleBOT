const fs = require('fs');
const path = require('path');
const os = require('os');
const chalk = require('chalk');

class TempCleaner {
    constructor() {
        this.maxAgeMinutes = 1; // Borrar todo lo que tenga más de 1 minuto
        this.emergencyMaxAgeMinutes = 0; // En emergencia ENOSPC: borrar TODO lo que tenga más de 0 min

        // ✅ TODAS las carpetas donde el bot y sus librerías escriben temporales
        const dirs = [
            os.tmpdir(), // /tmp del sistema (o local redirigido)
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'dist'),
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'temp'),
            path.join(process.cwd(), 'node_modules', 'wa-sticker-formatter', 'src', 'temp'),
            path.join(process.cwd(), 'tmp'),
            path.join(process.cwd(), 'temp'),
            path.join(process.cwd(), '.temp'), // Descargas de downloadUtils
        ];

        // Evitar duplicados y carpetas que no existen
        this.tempDirs = [...new Set(dirs)].filter(d => {
            try { return fs.existsSync(d); } catch { return false; }
        });

        this.cleanupInterval = null;
        this.isRunning = false;
    }

    isBotTempFile(dirPath, fileName, stats, emergency = false) {
        // Si es una carpeta temporal local del bot (tmp o temp), borramos todo
        // (ya que sólo nuestro bot escribe allí y todos sus contenidos son temporales)
        const isLocalTemp = dirPath.endsWith('tmp') || 
                            dirPath.endsWith('temp') || 
                            dirPath.endsWith('.temp') ||
                            dirPath.includes('/tmp/') || 
                            dirPath.includes('\\tmp\\') || 
                            dirPath.includes('/temp/') || 
                            dirPath.includes('\\temp\\') ||
                            dirPath.includes('/.temp/') || 
                            dirPath.includes('\\.temp\\');

        if (isLocalTemp) {
            const maxAge = emergency ? this.emergencyMaxAgeMinutes : this.maxAgeMinutes;
            const ageMinutes = (Date.now() - stats.mtime.getTime()) / (1000 * 60);
            return ageMinutes > maxAge;
        }

        const botPatterns = [
            // Archivos hex de ffmpeg/crypto (sin extensión o con extensión multimedia)
            /^[a-f0-9]{16,}\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg|video|v)$/i,
            /^[a-f0-9]{16,}$/i,
            // Patrones tmp_/temp_ con multimedia
            /^tmp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i,
            /^temp_.*\.(mp4|webp|jpg|jpeg|png|wav|mp3|gif|ogg)$/i,
            // En carpetas de wa-sticker-formatter: cualquier webp/mp4/gif
            /\.(webp|mp4|gif)$/i,
            // Archivos de ffmpeg: pueden ser hex más cortos o con guiones
            /^ffmpeg[_-].*$/i,
            /^[a-f0-9]{8,}\.gif$/i,
            /^[a-f0-9]{8,}\.mp4$/i,
            // Archivos de pipe/fifo de ffmpeg (sin extensión, nombre corto hex)
            /^[a-f0-9]{8,16}$/i,
            // Archivos temporales de Baileys
            /^baileys-.*$/i,
        ];

        const matchesPattern = botPatterns.some(pattern => pattern.test(fileName));
        if (!matchesPattern) return false;

        const maxAge = emergency ? this.emergencyMaxAgeMinutes : this.maxAgeMinutes;
        const ageMinutes = (Date.now() - stats.mtime.getTime()) / (1000 * 60);
        return ageMinutes > maxAge;
    }

    async cleanDir(dirPath, emergency = false) {
        let cleaned = 0;
        let totalSize = 0;

        try {
            const files = fs.readdirSync(dirPath);
            for (const fileName of files) {
                try {
                    const filePath = path.join(dirPath, fileName);
                    const stats = fs.statSync(filePath);
                    if (!stats.isFile()) continue;
                    if (this.isBotTempFile(dirPath, fileName, stats, emergency)) {
                        totalSize += stats.size;
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }
                } catch (_) {}
            }
        } catch (_) {}

        return { cleaned, totalSize };
    }

    /**
     * Limpieza de emergencia cuando ocurre ENOSPC.
     * Borra TODOS los archivos temporales del bot sin importar su antigüedad.
     */
    async emergencyCleanup() {
        console.log(chalk.red('[TempCleaner] 🚨 LIMPIEZA DE EMERGENCIA ENOSPC — borrando todos los temporales...'));
        let totalCleaned = 0;
        let totalSize = 0;

        for (const dir of this.tempDirs) {
            const result = await this.cleanDir(dir, true);
            totalCleaned += result.cleaned;
            totalSize += result.totalSize;
        }

        const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
        console.log(chalk.red(`[TempCleaner] 🚨 Emergencia completada: ${totalCleaned} archivos borrados (${sizeMB} MB liberados)`));
        return { cleaned: totalCleaned, totalSize };
    }

    async cleanTempFiles(emergency = false) {
        if (this.isRunning) return { cleaned: 0, errors: 0 };
        this.isRunning = true;

        let totalCleaned = 0;
        let totalSize = 0;

        try {
            for (const dir of this.tempDirs) {
                const result = await this.cleanDir(dir, emergency);
                totalCleaned += result.cleaned;
                totalSize += result.totalSize;
            }

            if (totalCleaned > 0) {
                const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
                console.log(chalk.green(`[TempCleaner] ✅ Limpiados ${totalCleaned} archivos (${sizeMB} MB liberados)`));
            }

            return { cleaned: totalCleaned, totalSize };
        } catch (error) {
            console.error(chalk.red('[TempCleaner] Error:'), error.message);
            return { cleaned: totalCleaned, error: error.message };
        } finally {
            this.isRunning = false;
        }
    }

    startPeriodicCleanup(intervalMinutes = 5) {
        if (this.cleanupInterval) clearInterval(this.cleanupInterval);

        // Primera limpieza a los 5 segundos de arrancar
        setTimeout(() => this.cleanTempFiles(), 5000);

        this.cleanupInterval = setInterval(() => {
            this.cleanTempFiles();
        }, intervalMinutes * 60 * 1000);

        console.log(chalk.cyan(`[TempCleaner] 🧹 Limpieza automática iniciada (cada ${intervalMinutes} min)`));
        console.log(chalk.cyan(`[TempCleaner] 📁 Monitoreando ${this.tempDirs.length} carpetas:`));
        this.tempDirs.forEach(d => console.log(chalk.gray(`  - ${d}`)));
    }

    stopPeriodicCleanup() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
            this.cleanupInterval = null;
            console.log(chalk.yellow('[TempCleaner] Limpieza automática detenida'));
        }
    }

    async manualCleanup() {
        console.log(chalk.blue('[TempCleaner] 🧹 Iniciando limpieza manual...'));
        const result = await this.cleanTempFiles();
        if (result.cleaned === 0) {
            console.log(chalk.gray('[TempCleaner] No hay archivos temporales para limpiar'));
        }
        return result;
    }

    /**
     * Verifica si hay poco espacio en /tmp y activa limpieza de emergencia si es necesario.
     * Devuelve true si se hizo limpieza de emergencia.
     */
    async checkAndCleanIfLowSpace() {
        try {
            // Contar archivos en /tmp como proxy de presión de espacio
            const tmpDir = os.tmpdir();
            const files = fs.readdirSync(tmpDir);
            const tmpFileCount = files.length;

            // Si hay más de 500 archivos en /tmp, limpieza preventiva
            if (tmpFileCount > 500) {
                console.log(chalk.yellow(`[TempCleaner] ⚠️ /tmp tiene ${tmpFileCount} archivos — limpieza preventiva`));
                await this.emergencyCleanup();
                return true;
            }
        } catch (_) {}
        return false;
    }

    getTempStats() {
        let totalFiles = 0;
        let botFiles = 0;
        let totalSize = 0;
        let botSize = 0;

        for (const dir of this.tempDirs) {
            try {
                const files = fs.readdirSync(dir);
                for (const fileName of files) {
                    try {
                        const filePath = path.join(dir, fileName);
                        const stats = fs.statSync(filePath);
                        if (!stats.isFile()) continue;
                        totalFiles++;
                        totalSize += stats.size;
                        if (this.isBotTempFile(dir, fileName, stats)) {
                            botFiles++;
                            botSize += stats.size;
                        }
                    } catch (_) {}
                }
            } catch (_) {}
        }

        return {
            totalFiles,
            botFiles,
            totalSize: (totalSize / (1024 * 1024)).toFixed(2) + ' MB',
            botSize: (botSize / (1024 * 1024)).toFixed(2) + ' MB',
            dirs: this.tempDirs
        };
    }
}

const tempCleaner = new TempCleaner();

module.exports = { TempCleaner, tempCleaner };