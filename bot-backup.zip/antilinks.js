/**
 * Sistema Anti-Links Optimizado v2.0
 * ✅ Llamado desde handler después de comandos
 * ✅ Caché para evitar rate-limit
 * ✅ Ignora owners y admins configurables
 */

const botConfig = require('./config');

const ANTILINK_CONFIG = {
    "grupo_principal": {
        grupo: "120363203689229697@g.us",
        activo: true,
        whitelist: [], // Números sin @ ni dominio
        permitirOwners: true, // Ignora owners del bot
        permitirAdmins: true, // Ignora admins del grupo
        tipos: {
            whatsapp: true,
            http: true,
            www: true,
            acortadores: true
        }
    }
};

const LINK_PATTERNS = {
    whatsapp: /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})|wa\.me\/\d+/gi,
    http: /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    www: /www\.[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    acortadores: /bit\.ly\/\S+|tinyurl\.com\/\S+|t\.co\/\S+|goo\.gl\/\S+|ow\.ly\/\S+|short\.link\/\S+|cutt\.ly\/\S+/gi
};

// Caché con tiempo de vida
const ADMIN_CACHE = new Map();
const CACHE_DURATION = 300000; // 5 minutos

// Limpieza automática del caché cada 10 minutos
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of ADMIN_CACHE.entries()) {
        if (now - value.timestamp > CACHE_DURATION) {
            ADMIN_CACHE.delete(key);
        }
    }
}, 600000);

class AntiLink {
    constructor(conn) {
        this.conn = conn;
        console.log('[AntiLink] ✓ Inicializado');
    }

    getConfig(groupId) {
        return Object.values(ANTILINK_CONFIG).find(g => g.grupo === groupId);
    }

    extractPhoneNumber(jid) {
        if (!jid) return null;
        let number = jid.split('@')[0];
        if (number.includes(':')) number = number.split(':')[0];
        return number.replace(/\D/g, '');
    }

    getMessageText(baileyMessage) {
        const msg = baileyMessage.message;
        if (!msg) return '';

        if (msg.conversation) return msg.conversation;
        if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
        if (msg.imageMessage?.caption) return msg.imageMessage.caption;
        if (msg.videoMessage?.caption) return msg.videoMessage.caption;
        if (msg.documentMessage?.caption) return msg.documentMessage.caption;
        
        return '';
    }

    detectLinks(text, config) {
        const detectedLinks = [];

        // Reiniciar índices de regex
        LINK_PATTERNS.whatsapp.lastIndex = 0;
        LINK_PATTERNS.acortadores.lastIndex = 0;
        LINK_PATTERNS.http.lastIndex = 0;
        LINK_PATTERNS.www.lastIndex = 0;

        if (config.tipos.whatsapp && LINK_PATTERNS.whatsapp.test(text)) {
            detectedLinks.push('WhatsApp');
        }

        if (config.tipos.acortadores) {
            LINK_PATTERNS.acortadores.lastIndex = 0;
            if (LINK_PATTERNS.acortadores.test(text)) {
                detectedLinks.push('Acortador');
            }
        }

        if (config.tipos.http) {
            LINK_PATTERNS.http.lastIndex = 0;
            if (LINK_PATTERNS.http.test(text) && !text.match(/chat\.whatsapp\.com|wa\.me/gi)) {
                detectedLinks.push('HTTP');
            }
        }

        if (config.tipos.www) {
            LINK_PATTERNS.www.lastIndex = 0;
            if (LINK_PATTERNS.www.test(text) && !text.match(/chat\.whatsapp\.com/gi)) {
                detectedLinks.push('WWW');
            }
        }

        return detectedLinks;
    }

    async getGroupMetadataSafe(groupId) {
        try {
            if (!this.conn || !this.conn.user) return null;
            
            const cacheKey = `metadata_${groupId}`;
            const cached = ADMIN_CACHE.get(cacheKey);
            
            if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
                return cached.data;
            }
            
            const metadata = await this.conn.groupMetadata(groupId);
            ADMIN_CACHE.set(cacheKey, { data: metadata, timestamp: Date.now() });
            
            return metadata;
        } catch (error) {
            if (error.message?.includes('rate-overlimit')) {
                console.log('[AntiLink] ⏳ Rate limit alcanzado, usando caché');
            } else if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error groupMetadata:', error.message);
            }
            return null;
        }
    }

    async isAdmin(groupId, userId) {
        try {
            const cacheKey = `admin_${groupId}_${userId}`;
            const cached = ADMIN_CACHE.get(cacheKey);
            
            if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
                return cached.status;
            }

            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const userNumber = userId.split('@')[0].split(':')[0];
            
            const userParticipant = groupMetadata.participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return participantNumber === userNumber;
            });
            
            const status = userParticipant && 
                          (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
            
            ADMIN_CACHE.set(cacheKey, { status, timestamp: Date.now() });
            return status;
        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error verificando admin:', error.message);
            }
            return false;
        }
    }

    async isBotAdmin(groupId) {
        try {
            const cacheKey = `botadmin_${groupId}`;
            const cached = ADMIN_CACHE.get(cacheKey);
            
            if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
                return cached.status;
            }

            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const botJid = this.conn.user.id;
            
            const possibleBotNumbers = [
                botJid.split(':')[0].split('@')[0],
                botJid.split('@')[0].split(':')[0]
            ];
            
            let botParticipant;
            
            for (const participant of groupMetadata.participants) {
                const participantNumber = participant.id.split('@')[0].split(':')[0];
                
                if (possibleBotNumbers.includes(participantNumber)) {
                    botParticipant = participant;
                    break;
                }
                
                if (participant.id.includes(possibleBotNumbers[0]) || 
                    participant.id.includes(possibleBotNumbers[1])) {
                    botParticipant = participant;
                    break;
                }
            }
            
            if (!botParticipant) {
                botParticipant = groupMetadata.participants.find(p => {
                    return p.id.includes('@lid') && p.admin;
                });
            }

            const status = botParticipant && 
                          (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
            
            ADMIN_CACHE.set(cacheKey, { status, timestamp: Date.now() });
            
            return status;
        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error verificando bot admin:', error.message);
            }
            return false;
        }
    }

    // Método principal llamado desde handler (DESPUÉS de procesar comandos)
    async checkMessage(baileyMessage) {
        try {
            if (!this.conn || !this.conn.user) return false;

            const groupId = baileyMessage.key.remoteJid;
            
            if (!groupId.includes('@g.us')) return false;

            const config = this.getConfig(groupId);
            
            if (!config || !config.activo) return false;

            const text = this.getMessageText(baileyMessage);
            if (!text) return false;

            const detectedLinks = this.detectLinks(text, config);
            if (detectedLinks.length === 0) return false;

            console.log(`[AntiLink] 🔍 Enlaces detectados en ${groupId}: ${detectedLinks.join(', ')}`);

            const userId = baileyMessage.key.participant || baileyMessage.key.remoteJid;
            const userNumber = this.extractPhoneNumber(userId);

            if (config.whitelist.includes(userNumber)) {
                console.log(`[AntiLink] ✓ Usuario ${userNumber} en whitelist`);
                return false;
            }

            if (config.permitirOwners) {
                const isOwner = botConfig.isOwner(userNumber) || 
                               botConfig.isOwner(`${userNumber}@s.whatsapp.net`);
                if (isOwner) {
                    console.log(`[AntiLink] ✓ Owner detectado: ${userNumber}`);
                    return false;
                }
            }

            if (config.permitirAdmins) {
                const isUserAdmin = await this.isAdmin(groupId, userId);
                if (isUserAdmin) {
                    console.log(`[AntiLink] ✓ Admin del grupo: ${userNumber}`);
                    return false;
                }
            }

            const botIsAdmin = await this.isBotAdmin(groupId);
            if (!botIsAdmin) {
                console.log(`[AntiLink] ⚠️ Bot no es admin en ${groupId}`);
                return false;
            }

            let groupName = 'Grupo';
            const metadata = await this.getGroupMetadataSafe(groupId);
            if (metadata) groupName = metadata.subject || 'Grupo';

            if (!this.conn || !this.conn.user) return false;

            try {
                await this.conn.sendMessage(groupId, { delete: baileyMessage.key });
                console.log(`[AntiLink] 🚫 Enlace eliminado en "${groupName}" de @${userNumber} (${detectedLinks.join(', ')})`);
                return true;
            } catch (deleteError) {
                if (deleteError.message?.includes('Connection Closed')) {
                    return false;
                }
                
                console.error('[AntiLink] Error eliminando:', deleteError.message);
                
                if (this.conn && this.conn.user) {
                    try {
                        const alternativeKey = {
                            remoteJid: groupId,
                            id: baileyMessage.key.id,
                            participant: userId,
                            fromMe: baileyMessage.key.fromMe || false
                        };
                        
                        await this.conn.sendMessage(groupId, { delete: alternativeKey });
                        console.log(`[AntiLink] 🚫 Eliminado (método alternativo)`);
                        return true;
                    } catch (altError) {
                        if (!altError.message?.includes('Connection Closed')) {
                            console.error('[AntiLink] Método alternativo falló:', altError.message);
                        }
                    }
                }
            }

            return false;
        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error en checkMessage:', error.message);
            }
            return false;
        }
    }

    clearCache() {
        ADMIN_CACHE.clear();
        console.log('[AntiLink] 🧹 Caché limpiado');
    }
}

module.exports = AntiLink;