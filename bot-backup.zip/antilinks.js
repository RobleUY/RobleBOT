/**
 * Sistema Anti-Links Dinámico
 * Configuración por grupo con eliminación automática
 * Archivo: antilinks.js
 * * 🚀 OPTIMIZACIÓN DE RENDIMIENTO:
 * Se implementó una caché para 'isBotAdmin' y 'isAdmin' 
 * para prevenir errores de 'rate-overlimit' (429) al reducir 
 * las consultas a groupMetadata.
 */
 
const ANTILINK_CONFIG = {
    "grupo_principal": {
        grupo: "120363203689229697@g.us",
        activo: true,
        whitelist: [], // Números de teléfono que pueden enviar links (sin @s.whatsapp.net)
        permitirAdmins: true, // Si true, los admins pueden enviar links
        tipos: {
            whatsapp: true,     // chat.whatsapp.com, wa.me
            http: true,         // http://, https://
            www: true,          // www.
            acortadores: true   // bit.ly, tinyurl, etc
        }
    }
};

// Patrones de detección
const LINK_PATTERNS = {
    whatsapp: /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})|wa\.me\/\d+/gi,
    http: /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    www: /www\.[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    acortadores: /bit\.ly\/\S+|tinyurl\.com\/\S+|t\.co\/\S+|goo\.gl\/\S+|ow\.ly\/\S+|short\.link\/\S+|cutt\.ly\/\S+/gi
};

// Caché para almacenar el estado de admin y evitar rate-limit
const ADMIN_CACHE = {
    // Estructura: groupId: { botAdmin: { status: boolean, timestamp: number }, userAdmin: { 'userId': { status: boolean, timestamp: number } } }
};
const CACHE_DURATION = 300000; // 5 minutos (300,000 ms)

class AntiLink {
    constructor(conn) {
        this.conn = conn;
        this.setupListener();
    }

    setupListener() {
        // Escuchar mensajes entrantes
        this.conn.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const msg of messages) {
                // Ignorar mensajes enviados por el bot
                if (msg.key.fromMe) continue; 
                await this.handleMessage(msg);
            }
        });
    }

    /**
     * Obtiene la configuración de antilink para un grupo
     */
    getConfig(groupId) {
        return Object.values(ANTILINK_CONFIG).find(g => g.grupo === groupId);
    }

    /**
     * Extrae el número de teléfono desde un JID
     */
    extractPhoneNumber(jid) {
        if (!jid) return null;
        let number = jid.split('@')[0];
        if (number.includes(':')) number = number.split(':')[0];
        return number.replace(/\D/g, '');
    }

    /**
     * Obtiene el texto del mensaje
     */
    getMessageText(baileyMessage) {
        const msg = baileyMessage.message;
        if (!msg) return '';

        if (msg.conversation) return msg.conversation;
        if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
        if (msg.imageMessage?.caption) return msg.imageMessage.caption;
        if (msg.videoMessage?.caption) return msg.videoMessage.caption;
        if (msg.documentMessage?.caption) return msg.documentMessage.caption;
        
        return '';
    }

    /**
     * Detecta si un texto contiene links según la configuración
     */
    detectLinks(text, config) {
        const detectedLinks = [];

        if (config.tipos.whatsapp && LINK_PATTERNS.whatsapp.test(text)) {
            detectedLinks.push('WhatsApp');
        }

        if (config.tipos.acortadores && LINK_PATTERNS.acortadores.test(text)) {
            detectedLinks.push('Acortador');
        }

        if (config.tipos.http && LINK_PATTERNS.http.test(text)) {
            // Evitar duplicados con WhatsApp
            if (!text.match(/chat\.whatsapp\.com|wa\.me/gi)) {
                detectedLinks.push('HTTP');
            }
        }

        if (config.tipos.www && LINK_PATTERNS.www.test(text)) {
            // Evitar duplicados
            if (!text.match(/chat\.whatsapp\.com/gi)) {
                detectedLinks.push('WWW');
            }
        }

        return detectedLinks;
    }

    /**
     * Obtiene los metadatos del grupo, o null si falla
     */
    async getGroupMetadataSafe(groupId) {
        try {
            return await this.conn.groupMetadata(groupId);
        } catch (error) {
            // Manejamos errores de rate-limit o no encontrado
            console.error('Error al obtener groupMetadata:', error.message.includes('rate-overlimit') ? 'RATE-OVERLIMIT' : error);
            return null;
        }
    }

    /**
     * Verifica si un usuario es admin del grupo usando caché.
     */
    async isAdmin(groupId, userId) {
        const now = Date.now();
        
        // Inicializar caché si no existe
        if (!ADMIN_CACHE[groupId]) {
            ADMIN_CACHE[groupId] = { users: {} };
        }
        
        const userCache = ADMIN_CACHE[groupId].users[userId];
        
        // Devolver valor de caché si no ha expirado
        if (userCache && now - userCache.timestamp < CACHE_DURATION) {
            return userCache.status;
        }

        // Si no está en caché o expiró, verificar el estado real
        try {
            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const userNumber = this.extractPhoneNumber(userId);
            
            const userParticipant = groupMetadata.participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return participantNumber === userNumber;
            });
            
            const status = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
            
            // Actualizar caché
            ADMIN_CACHE[groupId].users[userId] = { status: status, timestamp: now };

            return status;
        } catch (error) {
            console.error('Error verificando admin (cache miss):', error);
            return false;
        }
    }

    /**
     * Verifica si el bot es admin del grupo usando caché.
     */
    async isBotAdmin(groupId) {
        const now = Date.now();
        
        // Inicializar caché si no existe
        if (!ADMIN_CACHE[groupId]) {
            ADMIN_CACHE[groupId] = { botAdmin: { status: false, timestamp: 0 } };
        }
        
        const botCache = ADMIN_CACHE[groupId].botAdmin;
        
        // Devolver valor de caché si no ha expirado
        if (botCache && now - botCache.timestamp < CACHE_DURATION) {
            return botCache.status;
        }

        // Si no está en caché o expiró, verificar el estado real
        try {
            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const botJid = this.conn.user.id;
            
            // Buscar al bot en los participantes (lógica optimizada)
            let botParticipant;
            for (const participant of groupMetadata.participants) {
                 if (participant.id === botJid || participant.id.startsWith(botJid.split('@')[0])) {
                    botParticipant = participant;
                    break;
                 }
            }

            const status = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
            
            // Actualizar caché
            ADMIN_CACHE[groupId].botAdmin = { status: status, timestamp: now };

            return status;
        } catch (error) {
            console.error('Error verificando si bot es admin (cache miss):', error);
            return false;
        }
    }

    /**
     * Maneja un mensaje detectado con link
     */
    async handleMessage(baileyMessage) {
        try {
            const groupId = baileyMessage.key.remoteJid;
            
            // Solo procesar mensajes de grupos
            if (!groupId.includes('@g.us')) return;

            const config = this.getConfig(groupId);
            
            // Si el grupo no tiene antilink configurado, ignorar
            if (!config || !config.activo) return;

            const text = this.getMessageText(baileyMessage);
            if (!text) return;

            // Detectar links
            const detectedLinks = this.detectLinks(text, config);
            if (detectedLinks.length === 0) return;

            const userId = baileyMessage.key.participant || baileyMessage.key.remoteJid;
            const userNumber = this.extractPhoneNumber(userId);

            // Verificar whitelist
            if (config.whitelist.includes(userNumber)) {
                return;
            }

            // Verificar si es admin y están permitidos (usa caché)
            if (config.permitirAdmins) {
                const isUserAdmin = await this.isAdmin(groupId, userId);
                if (isUserAdmin) {
                    return;
                }
            }

            // Verificar si el bot es admin (usa caché)
            const botIsAdmin = await this.isBotAdmin(groupId);
            if (!botIsAdmin) {
                console.log(`⚠️ AntiLink: No puedo actuar en ${groupId}: no soy admin (Estado en caché)`);
                return;
            }

            // Obtener metadata del grupo (Solo para el nombre, si falla, usamos 'Grupo')
            let groupName = 'Grupo';
            const metadata = await this.getGroupMetadataSafe(groupId);
            if(metadata) groupName = metadata.subject || 'Grupo';

            // ELIMINAR EL MENSAJE
            try {
                await this.conn.sendMessage(groupId, { delete: baileyMessage.key });
                console.log(`🚫 AntiLink: Mensaje eliminado en ${groupName} de @${userNumber} (${detectedLinks.join(', ')})`);
            } catch (deleteError) {
                console.error('Error eliminando mensaje con antilink (primary):', deleteError.message);
                
                // Intentar método alternativo
                try {
                    const alternativeKey = {
                        remoteJid: groupId,
                        id: baileyMessage.key.id,
                        participant: userId,
                        fromMe: baileyMessage.key.fromMe || false
                    };
                    
                    await this.conn.sendMessage(groupId, { delete: alternativeKey });
                    console.log(`🚫 AntiLink: Mensaje eliminado (método alternativo) en ${groupName}`);
                } catch (altError) {
                    console.error('AntiLink: Método alternativo también falló:', altError.message);
                }
            }

        } catch (error) {
            console.error('Error en handleMessage de AntiLink:', error.message);
        }
    }
}

module.exports = AntiLink;