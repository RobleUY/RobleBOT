/**
 * Sistema Anti-Links Dinámico
 * Configuración por grupo con eliminación automática
 * Archivo: antilinks.js
 * 🚀 OPTIMIZACIÓN DE RENDIMIENTO:
 * Se implementó una caché para 'isBotAdmin' y 'isAdmin' 
 * para prevenir errores de 'rate-overlimit' (429) al reducir 
 * las consultas a groupMetadata.
 * ✅ REPARADO: Prevención de listeners duplicados y mejor manejo de errores
 */
 
const ANTILINK_CONFIG = {
    "grupo_principal": {
        grupo: "120363203689229697@g.us",
        activo: true,
        whitelist: [],
        permitirAdmins: true,
        tipos: {
            whatsapp: true,
            http: true,
            www: true,
            acortadores: true
        }
    }
};

const LINK_PATTERNS = {
    whatsapp: /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})|wa\.me\/\d+/gi,
    http: /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    www: /www\.[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi,
    acortadores: /bit\.ly\/\S+|tinyurl\.com\/\S+|t\.co\/\S+|goo\.gl\/\S+|ow\.ly\/\S+|short\.link\/\S+|cutt\.ly\/\S+/gi
};

const ADMIN_CACHE = {};
const CACHE_DURATION = 300000; // 5 minutos

class AntiLink {
    constructor(conn) {
        this.conn = conn;
        this.listenerAdded = false;
        this.setupListener();
    }

    setupListener() {
        // Prevenir listeners duplicados
        if (this.listenerAdded) {
            console.log('[AntiLink] ⚠️ Listener ya existe, saltando');
            return;
        }

        // Verificar que conn existe antes de agregar listener
        if (!this.conn || !this.conn.ev) {
            console.error('[AntiLink] ❌ Socket no válido');
            return;
        }

        this.messageHandler = async ({ messages, type }) => {
            if (type !== 'notify') return;
            
            // Verificar conexión antes de procesar
            if (!this.conn || !this.conn.user) return;

            for (const msg of messages) {
                if (msg.key.fromMe) continue;
                
                try {
                    await this.handleMessage(msg);
                } catch (error) {
                    // Silenciar errores de conexión cerrada
                    if (!error.message?.includes('Connection Closed')) {
                        console.error('[AntiLink] Error procesando mensaje:', error.message);
                    }
                }
            }
        };

        this.conn.ev.on('messages.upsert', this.messageHandler);
        this.listenerAdded = true;
        console.log('[AntiLink] ✓ Listener configurado');
    }

    // Limpiar listener al destruir
    destroy() {
        if (this.conn && this.conn.ev && this.messageHandler) {
            this.conn.ev.off('messages.upsert', this.messageHandler);
            this.listenerAdded = false;
            console.log('[AntiLink] 🗑️ Listener removido');
        }
    }

    getConfig(groupId) {
        return Object.values(ANTILINK_CONFIG).find(g => g.grupo === groupId);
    }

    extractPhoneNumber(jid) {
        if (!jid) return null;
        let number = jid.split('@')[0];
        if (number.includes(':')) number = number.split(':')[0];
        return number.replace(/\D/g, '');
    }

    getMessageText(baileyMessage) {
        const msg = baileyMessage.message;
        if (!msg) return '';

        if (msg.conversation) return msg.conversation;
        if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
        if (msg.imageMessage?.caption) return msg.imageMessage.caption;
        if (msg.videoMessage?.caption) return msg.videoMessage.caption;
        if (msg.documentMessage?.caption) return msg.documentMessage.caption;
        
        return '';
    }

    detectLinks(text, config) {
        const detectedLinks = [];

        if (config.tipos.whatsapp && LINK_PATTERNS.whatsapp.test(text)) {
            detectedLinks.push('WhatsApp');
        }

        if (config.tipos.acortadores && LINK_PATTERNS.acortadores.test(text)) {
            detectedLinks.push('Acortador');
        }

        if (config.tipos.http && LINK_PATTERNS.http.test(text)) {
            if (!text.match(/chat\.whatsapp\.com|wa\.me/gi)) {
                detectedLinks.push('HTTP');
            }
        }

        if (config.tipos.www && LINK_PATTERNS.www.test(text)) {
            if (!text.match(/chat\.whatsapp\.com/gi)) {
                detectedLinks.push('WWW');
            }
        }

        return detectedLinks;
    }

    async getGroupMetadataSafe(groupId) {
        try {
            // Verificar que el socket esté conectado
            if (!this.conn || !this.conn.user) {
                return null;
            }
            
            return await this.conn.groupMetadata(groupId);
        } catch (error) {
            if (error.message?.includes('rate-overlimit')) {
                console.log('[AntiLink] ⏳ Rate limit, usando caché');
            } else if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error groupMetadata:', error.message);
            }
            return null;
        }
    }

    async isAdmin(groupId, userId) {
        const now = Date.now();
        
        if (!ADMIN_CACHE[groupId]) {
            ADMIN_CACHE[groupId] = { users: {} };
        }
        
        const userCache = ADMIN_CACHE[groupId].users[userId];
        
        if (userCache && now - userCache.timestamp < CACHE_DURATION) {
            return userCache.status;
        }

        try {
            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const userNumber = this.extractPhoneNumber(userId);
            
            const userParticipant = groupMetadata.participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return participantNumber === userNumber;
            });
            
            const status = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
            
            ADMIN_CACHE[groupId].users[userId] = { status: status, timestamp: now };

            return status;
        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error verificando admin:', error.message);
            }
            return false;
        }
    }

    async isBotAdmin(groupId) {
        const now = Date.now();
        
        if (!ADMIN_CACHE[groupId]) {
            ADMIN_CACHE[groupId] = { botAdmin: { status: false, timestamp: 0 } };
        }
        
        const botCache = ADMIN_CACHE[groupId].botAdmin;
        
        if (botCache && now - botCache.timestamp < CACHE_DURATION) {
            return botCache.status;
        }

        try {
            const groupMetadata = await this.getGroupMetadataSafe(groupId);
            if (!groupMetadata) return false;

            const botJid = this.conn.user.id;
            
            let botParticipant;
            for (const participant of groupMetadata.participants) {
                 if (participant.id === botJid || participant.id.startsWith(botJid.split('@')[0])) {
                    botParticipant = participant;
                    break;
                 }
            }

            const status = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
            
            ADMIN_CACHE[groupId].botAdmin = { status: status, timestamp: now };

            return status;
        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error verificando bot admin:', error.message);
            }
            return false;
        }
    }

    async handleMessage(baileyMessage) {
        try {
            // Verificar conexión activa
            if (!this.conn || !this.conn.user) {
                return;
            }

            const groupId = baileyMessage.key.remoteJid;
            
            if (!groupId.includes('@g.us')) return;

            const config = this.getConfig(groupId);
            
            if (!config || !config.activo) return;

            const text = this.getMessageText(baileyMessage);
            if (!text) return;

            const detectedLinks = this.detectLinks(text, config);
            if (detectedLinks.length === 0) return;

            const userId = baileyMessage.key.participant || baileyMessage.key.remoteJid;
            const userNumber = this.extractPhoneNumber(userId);

            if (config.whitelist.includes(userNumber)) {
                return;
            }

            if (config.permitirAdmins) {
                const isUserAdmin = await this.isAdmin(groupId, userId);
                if (isUserAdmin) {
                    return;
                }
            }

            const botIsAdmin = await this.isBotAdmin(groupId);
            if (!botIsAdmin) {
                return;
            }

            let groupName = 'Grupo';
            const metadata = await this.getGroupMetadataSafe(groupId);
            if (metadata) groupName = metadata.subject || 'Grupo';

            // Verificar conexión antes de eliminar
            if (!this.conn || !this.conn.user) {
                return;
            }

            try {
                await this.conn.sendMessage(groupId, { delete: baileyMessage.key });
                console.log(`[AntiLink] 🚫 Mensaje eliminado en ${groupName} de @${userNumber} (${detectedLinks.join(', ')})`);
            } catch (deleteError) {
                if (deleteError.message?.includes('Connection Closed')) {
                    return;
                }
                
                console.error('[AntiLink] Error eliminando mensaje:', deleteError.message);
                
                // Método alternativo solo si la conexión sigue activa
                if (this.conn && this.conn.user) {
                    try {
                        const alternativeKey = {
                            remoteJid: groupId,
                            id: baileyMessage.key.id,
                            participant: userId,
                            fromMe: baileyMessage.key.fromMe || false
                        };
                        
                        await this.conn.sendMessage(groupId, { delete: alternativeKey });
                        console.log(`[AntiLink] 🚫 Mensaje eliminado (método alternativo)`);
                    } catch (altError) {
                        if (!altError.message?.includes('Connection Closed')) {
                            console.error('[AntiLink] Método alternativo falló:', altError.message);
                        }
                    }
                }
            }

        } catch (error) {
            if (!error.message?.includes('Connection Closed')) {
                console.error('[AntiLink] Error en handleMessage:', error.message);
            }
        }
    }
}

module.exports = AntiLink;