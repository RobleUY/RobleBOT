/**
 * SISTEMA DE RESET AUTOMÁTICO DE TEMPORADA
 * 
 * Este módulo se encarga de ejecutar automáticamente el reset de temporada
 * cada día 1 de cada mes a las 00:05 hora de Uruguay (UTC-3)
 * 
 * IMPORTANTE: Requiere node-cron instalado en el servidor
 * Se programa a las 00:05 para evitar conflicto con el reinicio automático de 4 horas
 */

const cron = require('node-cron');
const fs = require('fs');
const path = require('path');

// Zona horaria de Uruguay: America/Montevideo
const URUGUAY_TIMEZONE = 'America/Montevideo';

/**
 * Función que ejecuta el reset de temporada
 * (Misma lógica que el comando manual)
 */
async function ejecutarResetTemporada(sock = null, isAutomatic = false) {
  try {
    const logPrefix = isAutomatic ? '[RESET AUTOMÁTICO]' : '[RESET MANUAL]';
    
    console.log('\n🔄 ========================================');
    console.log(`🔄 ${logPrefix} INICIANDO RESET DE TEMPORADA`);
    console.log('🔄 ========================================\n');
    
    const databasePath = path.join(__dirname, 'database.db');
    const botstatsPath = path.join(__dirname, 'data/botstats.json');
    const iasPath = path.join(__dirname, 'data/ias-personalizadas.json');
    const comandosPath = path.join(__dirname, 'data/comandos.json');
    
    // ============ PASO 1: CREAR BACKUPS ============
    console.log('📦 Creando backups de seguridad...\n');
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
    const backupResults = [];
    
    // Backup database.db (SQLite)
    try {
      if (global.db && typeof global.db.backup === 'function') {
        const backupDbPath = global.db.backup();
        backupResults.push('✅ database.db');
        console.log('   ✅ Backup de database.db creado:', backupDbPath);
      } else if (fs.existsSync(databasePath)) {
        const backupDbPath = path.join(__dirname, `database_backup_${timestamp}.db`);
        fs.copyFileSync(databasePath, backupDbPath);
        backupResults.push('✅ database.db (copia directa)');
        console.log('   ✅ Backup de database.db creado');
      }
    } catch (err) {
      backupResults.push('❌ database.db: ' + err.message);
      console.error('   ❌ Error en backup de database.db:', err.message);
    }
    
    // Backup botstats.json (en data/)
    try {
      if (fs.existsSync(botstatsPath)) {
        const backupBotstatsPath = path.join(__dirname, 'data', `backup-botstats-${timestamp}.json`);
        fs.copyFileSync(botstatsPath, backupBotstatsPath);
        backupResults.push('✅ botstats.json');
        console.log('   ✅ Backup de botstats.json creado');
      }
    } catch (err) {
      backupResults.push('❌ botstats.json: ' + err.message);
      console.error('   ❌ Error en backup de botstats.json:', err.message);
    }
    
    // Backup ias-personalizadas.json (en data/)
    try {
      if (fs.existsSync(iasPath)) {
        const backupIasPath = path.join(__dirname, 'data', `backup-ias-personalizadas-${timestamp}.json`);
        fs.copyFileSync(iasPath, backupIasPath);
        backupResults.push('✅ ias-personalizadas.json');
        console.log('   ✅ Backup de ias-personalizadas.json creado');
      }
    } catch (err) {
      backupResults.push('❌ ias-personalizadas.json: ' + err.message);
      console.error('   ❌ Error en backup de ias-personalizadas.json:', err.message);
    }
    
    // Backup comandos.json (en data/)
    try {
      if (fs.existsSync(comandosPath)) {
        const backupComandosPath = path.join(__dirname, 'data', `backup-comandos-${timestamp}.json`);
        fs.copyFileSync(comandosPath, backupComandosPath);
        backupResults.push('✅ comandos.json');
        console.log('   ✅ Backup de comandos.json creado');
      }
    } catch (err) {
      backupResults.push('❌ comandos.json: ' + err.message);
      console.error('   ❌ Error en backup de comandos.json:', err.message);
    }
    
    console.log('\n🔄 Iniciando reset de datos...\n');
    
    // ============ PASO 2: RESETEAR DATOS ============
    const resetResults = [];
    let usersResetCount = 0;
    
    // 1. RESETEAR DATABASE (usuarios — mantener solo apodos)
    try {
        const cleanNumber = (jid) => {
          if (!jid) return '';
          let s = String(jid).split('@')[0].split(':')[0].trim();
          return s.replace(/\.0+$/, '').replace(/\D/g, '');
        };

        const seenCanonical = new Set();

        for (const userId in allUsers) {
          const user = allUsers[userId];
          const apodoActual = user.apodo || '';
          const canonicalId = cleanNumber(userId) || userId;
          
          // Construir objeto reseteado manteniendo solo el apodo
          const resetData = {
            apodo: apodoActual,
            money: 0,
            bank: 0,
            exp: 0,
            level: 1,
            ComandosEjecutados: 0,
            lastWork: 0,
            lastSlut: 0,
            lastDaily: 0,
            lastCrime: 0,
            lastRob: 0,
            lastStudy: 0,
            lastMine: 0,
            lastHunt: 0,
            respeto: 0,
            rango: '🌱 Novato',
            minerales: {},
            animales: {},
            betStats: {},
            blackjackStats: {},
            bombaStats: {},
            carreraStats: {},
            dadosStats: {},
            ruletaStats: {},
            tragamonedasStats: {},
            caballosStats: {},
            prestamo: 0,
            prestamoFecha: 0,
            inversiones: {},
            wordleStats: {},
            numberleStats: {},
            ahorcadoStats: {},
            tatetiStats: {},
          };
          
          // Usar setUser para que SQLite persista el cambio correctamente
          global.db.setUser(canonicalId, resetData);

          // Si el ID original era un alias corrupto como xxx.0 o xxx0, borrarlo de la tabla users
          if (userId !== canonicalId && global.db.db) {
            try {
              global.db.db.prepare('DELETE FROM users WHERE id = ?').run(userId);
            } catch (_) {}
          }

          if (!seenCanonical.has(canonicalId)) {
            seenCanonical.add(canonicalId);
            usersResetCount++;
          }
        }
        
        resetResults.push(`✅ Database: ${usersResetCount} usuarios reseteados (apodos mantenidos)`);
        console.log(`   ✅ Database: ${usersResetCount} usuarios reseteados (apodos mantenidos)`);
    } catch (err) {
      resetResults.push('❌ Database: ' + err.message);
      console.error('   ❌ Error en Database:', err.message);
    }
    
    // 2. RESETEAR BOTSTATS.JSON (vaciar usuariosUsados)
    try {
      if (fs.existsSync(botstatsPath)) {
        const botstatsData = JSON.parse(fs.readFileSync(botstatsPath, 'utf-8'));
        const previousUsers = botstatsData.usuariosUsados ? botstatsData.usuariosUsados.length : 0;
        
        botstatsData.usuariosUsados = [];
        
        fs.writeFileSync(botstatsPath, JSON.stringify(botstatsData, null, 2), 'utf-8');
        resetResults.push(`✅ BotStats: ${previousUsers} usuarios removidos de usuariosUsados`);
        console.log(`   ✅ BotStats: ${previousUsers} usuarios removidos de usuariosUsados`);
      }
    } catch (err) {
      resetResults.push('❌ BotStats: ' + err.message);
      console.error('   ❌ Error en BotStats:', err.message);
    }
    
    // 3. RESETEAR IAS-PERSONALIZADAS.JSON
    try {
      if (fs.existsSync(iasPath)) {
        const iasData = JSON.parse(fs.readFileSync(iasPath, 'utf-8'));
        let iasResetCount = 0;
        
        if (iasData.ias) {
          for (const iaKey in iasData.ias) {
            const ia = iasData.ias[iaKey];
            if (ia.uses !== undefined) ia.uses = 0;
            if (ia.usedBy !== undefined) ia.usedBy = [];
            iasResetCount++;
          }
        }
        
        fs.writeFileSync(iasPath, JSON.stringify(iasData, null, 2), 'utf-8');
        resetResults.push(`✅ IAs: ${iasResetCount} IAs reseteadas (manteniendo creadores)`);
        console.log(`   ✅ IAs: ${iasResetCount} IAs reseteadas (manteniendo creadores)`);
      }
    } catch (err) {
      resetResults.push('❌ IAs: ' + err.message);
      console.error('   ❌ Error en IAs:', err.message);
    }
    
    // 4. RESETEAR COMANDOS.JSON
    try {
      if (fs.existsSync(comandosPath)) {
        const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf-8'));
        let comandosResetCount = 0;
        
        if (comandosData.commands) {
          for (const cmdKey in comandosData.commands) {
            const cmd = comandosData.commands[cmdKey];
            if (cmd.uses !== undefined) cmd.uses = 0;
            if (cmd.usedBy !== undefined) cmd.usedBy = [];
            comandosResetCount++;
          }
        }
        
        fs.writeFileSync(comandosPath, JSON.stringify(comandosData, null, 2), 'utf-8');
        resetResults.push(`✅ Comandos: ${comandosResetCount} comandos reseteados (manteniendo configuración)`);
        console.log(`   ✅ Comandos: ${comandosResetCount} comandos reseteados (manteniendo configuración)`);
      }
    } catch (err) {
      resetResults.push('❌ Comandos: ' + err.message);
      console.error('   ❌ Error en Comandos:', err.message);
    }
    
    console.log('\n✅ ========================================');
    console.log('✅ RESET DE TEMPORADA COMPLETADO');
    console.log('✅ ========================================\n');
    
    return { success: true, resetResults, backupResults };
    
  } catch (error) {
    console.error('❌ ERROR DURANTE EL RESET:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Inicializar el sistema de reset automático
 */
function inicializarResetAutomatico(sock) {
  console.log('\n🤖 Inicializando sistema de reset automático de temporada...');
  
  // Cron para ejecutar el día 1 de cada mes a las 00:05 hora de Uruguay
  // Se programa a las 00:05 para evitar conflicto con el reinicio automático cada 4 horas
  // Formato: minuto hora día mes día-de-semana
  // '5 0 1 * *' = A las 00:05 del día 1 de cada mes
  const cronExpression = '5 0 1 * *';
  
  const task = cron.schedule(cronExpression, async () => {
    console.log('\n⏰ CRON DISPARADO: Ejecutando reset automático de temporada...');
    await ejecutarResetTemporada(sock, true);
  }, {
    scheduled: true,
    timezone: URUGUAY_TIMEZONE
  });
  
  console.log(`✅ Reset automático programado:`);
  console.log(`   📅 Frecuencia: Día 1 de cada mes`);
  console.log(`   🕐 Hora: 00:05 (5 minutos después de medianoche)`);
  console.log(`   🌍 Zona horaria: ${URUGUAY_TIMEZONE}`);
  console.log(`   📋 Expresión cron: ${cronExpression}`);
  console.log(`   ℹ️  Programado a las 00:05 para evitar conflicto con reinicio automático\n`);
  
  return task;
}

module.exports = {
  inicializarResetAutomatico,
  ejecutarResetTemporada
};
