/**
 * SISTEMA DE RESET AUTOMÁTICO DE TEMPORADA
 * 
 * Este módulo se encarga de ejecutar automáticamente el reset de temporada
 * cada día 1 de cada mes a las 00:05 hora de Uruguay (UTC-3).
 * 
 * Filosofía de Lista Blanca (Whitelist):
 * Para evitar que queden datos obsoletos o que se pierdan datos futuros al agregar
 * nuevas características, la reconstrucción de objetos se hace utilizando una lista
 * blanca definida en `data/reset-whitelist.json`. Todo lo que no esté explícitamente
 * en la lista blanca de conservar se reinicia de cero.
 */

const cron = require('node-cron');
const fs = require('fs');
const path = require('path');

// Zona horaria de Uruguay: America/Montevideo
const URUGUAY_TIMEZONE = 'America/Montevideo';

/**
 * Función auxiliar para borrar un directorio y todo su contenido recursivamente
 */
function deleteFolderRecursive(folderPath) {
  if (fs.existsSync(folderPath)) {
    fs.readdirSync(folderPath).forEach((file) => {
      const curPath = path.join(folderPath, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        deleteFolderRecursive(curPath);
      } else {
        try { fs.unlinkSync(curPath); } catch (_) {}
      }
    });
    try { fs.rmdirSync(folderPath); } catch (_) {}
  }
}

/**
 * Función que ejecuta el reset de temporada completo
 */
async function ejecutarResetTemporada(sock = null, isAutomatic = false) {
  try {
    const logPrefix = isAutomatic ? '[RESET AUTOMÁTICO]' : '[RESET MANUAL]';
    
    console.log('\n🔄 ========================================');
    console.log(`🔄 ${logPrefix} INICIANDO RESET DE TEMPORADA`);
    console.log('🔄 ========================================\n');

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
    const backupResults = [];
    const resetResults = [];

    // Rutas principales
    const databasePath = path.join(__dirname, 'database.db');
    const botstatsPath = path.join(__dirname, 'data', 'botstats.json');
    const iasPath = path.join(__dirname, 'data', 'ias-personalizadas.json');
    const comandosPath = path.join(__dirname, 'data', 'comandos.json');
    const subbotActividadPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', 'subbots-actividad.json');
    const whitelistPath = path.join(__dirname, 'data', 'reset-whitelist.json');

    // Cargar configuración de lista blanca (whitelist)
    let whitelist = {
      userFieldsToKeep: ['apodo'],
      clanFieldsToKeep: ['nombre', 'lider', 'decanos', 'miembros', 'invitaciones', 'creadoEn', 'logo', 'banner', 'descripcion'],
      kvCollectionsToKeep: ['parejas', 'aliases']
    };

    if (fs.existsSync(whitelistPath)) {
      try {
        const rawWl = fs.readFileSync(whitelistPath, 'utf8');
        const parsedWl = JSON.parse(rawWl);
        if (parsedWl.userFieldsToKeep) whitelist.userFieldsToKeep = parsedWl.userFieldsToKeep;
        if (parsedWl.clanFieldsToKeep) whitelist.clanFieldsToKeep = parsedWl.clanFieldsToKeep;
        if (parsedWl.kvCollectionsToKeep) whitelist.kvCollectionsToKeep = parsedWl.kvCollectionsToKeep;
        console.log('📋 Lista blanca cargada desde data/reset-whitelist.json');
      } catch (wlErr) {
        console.warn('⚠️ Error leyendo reset-whitelist.json, usando lista blanca por defecto:', wlErr.message);
      }
    }

    // ============ PASO 1: FLUSH PREVIO Y BACKUPS ============
    console.log('📦 Guardando datos pendientes y creando backups de seguridad...\n');

    if (global.db && typeof global.db.saveNow === 'function') {
      await global.db.saveNow();
    }

    // SQLite WAL Checkpoint previo
    if (global.db && global.db.db) {
      try {
        global.db.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
      } catch (_) {}
    }

    // Backup database.db (SQLite)
    try {
      if (global.db && typeof global.db.backup === 'function') {
        const backupDbPath = global.db.backup();
        backupResults.push(`✅ database.db (${backupDbPath ? path.basename(backupDbPath) : 'creado'})`);
        console.log('   ✅ Backup de database.db creado');
      } else if (fs.existsSync(databasePath)) {
        const backupDbPath = path.join(__dirname, `database_backup_${timestamp}.db`);
        fs.copyFileSync(databasePath, backupDbPath);
        backupResults.push('✅ database.db (copia directa)');
        console.log('   ✅ Backup de database.db creado');
      }
    } catch (err) {
      backupResults.push('❌ database.db: ' + err.message);
    }

    // Backup botstats.json
    try {
      if (fs.existsSync(botstatsPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-botstats-${timestamp}.json`);
        fs.copyFileSync(botstatsPath, backupPath);
        backupResults.push('✅ botstats.json');
      }
    } catch (err) { backupResults.push('❌ botstats.json: ' + err.message); }

    // Backup ias-personalizadas.json
    try {
      if (fs.existsSync(iasPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-ias-personalizadas-${timestamp}.json`);
        fs.copyFileSync(iasPath, backupPath);
        backupResults.push('✅ ias-personalizadas.json');
      }
    } catch (err) { backupResults.push('❌ ias-personalizadas.json: ' + err.message); }

    // Backup comandos.json
    try {
      if (fs.existsSync(comandosPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-comandos-${timestamp}.json`);
        fs.copyFileSync(comandosPath, backupPath);
        backupResults.push('✅ comandos.json');
      }
    } catch (err) { backupResults.push('❌ comandos.json: ' + err.message); }

    // Backup subbots-actividad.json
    try {
      if (fs.existsSync(subbotActividadPath)) {
        const backupPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', `backup-subbots-actividad-${timestamp}.json`);
        fs.copyFileSync(subbotActividadPath, backupPath);
        backupResults.push('✅ subbots-actividad.json');
      }
    } catch (err) { backupResults.push('❌ subbots-actividad.json: ' + err.message); }

    console.log('\n🔄 Iniciando reset de datos...\n');

    // ============ PASO 2: RESET EN DATABASE.DB (SQLITE) ============

    if (global.db && global.db.db) {
      const sqliteDb = global.db.db;

      // 1. Resetear Tabla USERS mediante Lista Blanca (Whitelist)
      try {
        const cleanNumber = (jid) => {
          if (!jid) return '';
          let s = String(jid).split('@')[0].split(':')[0].trim();
          return s.replace(/\.0+$/, '').replace(/\D/g, '');
        };

        const userRows = sqliteDb.prepare('SELECT id, data FROM users').all();
        let usersResetCount = 0;
        const aliases = global.db._getKvAll('aliases') || {};

        // Iniciar transacción atómica en SQLite
        sqliteDb.exec('BEGIN IMMEDIATE');

        for (const row of userRows) {
          const rawId = row.id;
          const cleanId = cleanNumber(rawId) || rawId;
          const canonicalId = String(aliases[cleanId] || aliases[rawId] || cleanId);

          let oldUser = {};
          try { oldUser = JSON.parse(row.data); } catch (_) {}

          // Objeto de usuario reseteado de fábrica
          const resetUser = {
            name: '',
            warns: 0,
            ComandosEjecutados: 0,
            accesscode: null,
            isBanned: false,
            bank: 0,
            money: 0,
            escudosAntiRobos: 0,
            level: 1,
            exp: 0,
            lastWork: 0,
            workedHours: 0,
            totalWorkedHours: 0,
            totalWorkedTimes: 0,
            lastDaily: 0,
            lastClanAttack: 0,
            registered: false,
            premium: false,
            banned: false,
            reseña: null,
            apodo: '',
            rank: 0,
            respeto: 0,
            cookies: 0,
            auto: 0,
            manual: 0,
            lastCookie: 0,
            lastAuto: Date.now(),
            pet: { name: 'Mi Mascota', type: 'perro', level: 1, food: 0, requiredFood: 100 },
            lastMining: 0,
            lastPremio: 0,
            minerales: { CARBON: 0, HIERRO: 0, PLATA: 0, ORO: 0, DIAMANTE: 0, ESMERALDA: 0, RUBI: 0 },
            prestamo: { activo: false, monto: 0, deuda: 0, intereses: 0, fechaPrestamo: 0 },
            betStats: { totalBets: 0, totalWins: 0, totalLosses: 0, totalBetAmount: 0, totalWonAmount: 0, totalLostAmount: 0, biggestBet: 0, biggestWin: 0, biggestLoss: 0, currentStreak: 0, bestWinStreak: 0, worstLoseStreak: 0, lastBetTime: 0 },
            achievements: { commands: { total: 0, milestones: [] }, work: { total: 0, milestones: [] }, betting: { total: 0, milestones: [] }, daily: { total: 0, milestones: [] } }
          };

          // Inyectar ÚNICAMENTE los campos permitidos en la lista blanca (ej: apodo)
          for (const field of whitelist.userFieldsToKeep) {
            if (oldUser[field] !== undefined) {
              resetUser[field] = oldUser[field];
            }
          }

          // Guardar en SQLite con ID canónico
          sqliteDb.prepare('INSERT OR REPLACE INTO users (id, data) VALUES (?, ?)').run(canonicalId, JSON.stringify(resetUser));

          // Si era una clave no canónica (como xxx.0), borrar la fila antigua
          if (rawId !== canonicalId) {
            try { sqliteDb.prepare('DELETE FROM users WHERE id = ?').run(rawId); } catch (_) {}
          }

          usersResetCount++;
        }

        sqliteDb.exec('COMMIT');
        resetResults.push(`✅ Database Users: ${usersResetCount} usuarios reseteados (conservando solo campos en whitelist)`);
        console.log(`   ✅ Database Users: ${usersResetCount} usuarios reseteados.`);
      } catch (errUsers) {
        try { sqliteDb.exec('ROLLBACK'); } catch (_) {}
        resetResults.push('❌ Database Users: ' + errUsers.message);
        console.error('   ❌ Error en Database Users:', errUsers.message);
      }

      // 2. Resetear Colección de Clanes en KV Store
      try {
        const clanRows = sqliteDb.prepare("SELECT key, value FROM kv WHERE collection = 'clanes'").all();
        let clanesResetCount = 0;

        sqliteDb.exec('BEGIN IMMEDIATE');

        for (const row of clanRows) {
          let clan = {};
          try { clan = JSON.parse(row.value); } catch (_) {}

          const resetClan = {
            nombre: clan.nombre || row.key,
            lider: clan.lider || '',
            decanos: Array.isArray(clan.decanos) ? clan.decanos : [],
            miembros: Array.isArray(clan.miembros) ? clan.miembros : [],
            invitaciones: Array.isArray(clan.invitaciones) ? clan.invitaciones : [],
            creadoEn: clan.creadoEn || Date.now(),
            logo: clan.logo || null,
            banner: clan.banner || null,
            descripcion: clan.descripcion || '',

            // Campos a resetear a 0 / por defecto
            vida: 100,
            maxVida: 100,
            depositos: {},
            lastAttackedTime: 0,
            reparaciones: 0,
            stats: {
              ataquesRealizados: 0,
              ataquesRecibidos: 0,
              clanesDerrotados: 0
            }
          };

          sqliteDb.prepare("INSERT OR REPLACE INTO kv (collection, key, value) VALUES ('clanes', ?, ?)").run(row.key, JSON.stringify(resetClan));
          clanesResetCount++;
        }

        sqliteDb.exec('COMMIT');
        resetResults.push(`✅ Clanes: ${clanesResetCount} clanes reseteados (conservando miembros, roles y personalización)`);
        console.log(`   ✅ Clanes: ${clanesResetCount} clanes reseteados.`);
      } catch (errClanes) {
        try { sqliteDb.exec('ROLLBACK'); } catch (_) {}
        resetResults.push('❌ Clanes: ' + errClanes.message);
        console.error('   ❌ Error en Clanes:', errClanes.message);
      }

      // 3. Eliminar Colecciones KV NO permitidas
      try {
        const collectionsToKeep = ['parejas', 'clanes', 'aliases', ...whitelist.kvCollectionsToKeep];
        const placeholders = collectionsToKeep.map(() => '?').join(',');
        const delKvStmt = sqliteDb.prepare(`DELETE FROM kv WHERE collection NOT IN (${placeholders})`);
        const info = delKvStmt.run(...collectionsToKeep);
        resetResults.push(`✅ Colecciones KV secundarias: ${info.changes} registros eliminados`);
        console.log(`   ✅ Colecciones KV secundarias limpiadas: ${info.changes} registros.`);
      } catch (errKv) {
        resetResults.push('❌ Colecciones KV: ' + errKv.message);
        console.error('   ❌ Error limpiando KV:', errKv.message);
      }

      // 4. Vaciar Tabla CHATS
      try {
        const infoChats = sqliteDb.prepare('DELETE FROM chats').run();
        resetResults.push(`✅ Tabla Chats SQLite: ${infoChats.changes} filas reseteadas`);
        console.log(`   ✅ Tabla Chats SQLite limpiada.`);
      } catch (errChats) {
        resetResults.push('❌ Tabla Chats SQLite: ' + errChats.message);
      }
    }

    // ============ PASO 3: RESET Y BORRADO DE ARCHIVOS DE DATOS ============

    // 1. Borrar carpeta data/chats/
    try {
      const chatsDir = path.join(__dirname, 'data', 'chats');
      if (fs.existsSync(chatsDir)) {
        deleteFolderRecursive(chatsDir);
        resetResults.push('✅ data/chats/: Carpeta y base de datos eliminadas');
        console.log('   ✅ data/chats/ eliminada.');
      }
    } catch (err) { resetResults.push('❌ data/chats/: ' + err.message); }

    // 2. Borrar carpeta data/NOTAS-VOZ-GUARDADAS/
    try {
      const notasDir = path.join(__dirname, 'data', 'NOTAS-VOZ-GUARDADAS');
      if (fs.existsSync(notasDir)) {
        deleteFolderRecursive(notasDir);
        resetResults.push('✅ data/NOTAS-VOZ-GUARDADAS/: Carpeta eliminada');
        console.log('   ✅ data/NOTAS-VOZ-GUARDADAS/ eliminada.');
      }
    } catch (err) { resetResults.push('❌ data/NOTAS-VOZ-GUARDADAS/: ' + err.message); }

    // 3. Borrar data/botstats.json
    try {
      if (fs.existsSync(botstatsPath)) {
        fs.unlinkSync(botstatsPath);
        resetResults.push('✅ data/botstats.json: Archivo eliminado');
        console.log('   ✅ data/botstats.json eliminado.');
      }
    } catch (err) { resetResults.push('❌ data/botstats.json: ' + err.message); }

    // 4. Borrar data/huertos.json
    try {
      const huertosPath = path.join(__dirname, 'data', 'huertos.json');
      if (fs.existsSync(huertosPath)) {
        fs.unlinkSync(huertosPath);
        resetResults.push('✅ data/huertos.json: Archivo eliminado');
        console.log('   ✅ data/huertos.json eliminado.');
      }
    } catch (err) { resetResults.push('❌ data/huertos.json: ' + err.message); }

    // 5. Borrar data/mascotas.json
    try {
      const mascotasPath = path.join(__dirname, 'data', 'mascotas.json');
      if (fs.existsSync(mascotasPath)) {
        fs.unlinkSync(mascotasPath);
        resetResults.push('✅ data/mascotas.json: Archivo eliminado');
        console.log('   ✅ data/mascotas.json eliminado.');
      }
    } catch (err) { resetResults.push('❌ data/mascotas.json: ' + err.message); }

    // 6. Resetear data/comandos.json (usos = 0, usuariosUsados = [])
    try {
      if (fs.existsSync(comandosPath)) {
        const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf8'));
        let count = 0;
        if (comandosData.commands) {
          for (const cmdKey in comandosData.commands) {
            const cmd = comandosData.commands[cmdKey];
            if (cmd) {
              cmd.uses = 0;
              cmd.usedBy = [];
              count++;
            }
          }
        }
        fs.writeFileSync(comandosPath, JSON.stringify(comandosData, null, 2), 'utf8');
        resetResults.push(`✅ Comandos Personalizados: ${count} comandos reseteados a 0 usos`);
        console.log(`   ✅ Comandos Personalizados: ${count} comandos reseteados.`);
      }
    } catch (err) { resetResults.push('❌ Comandos Personalizados: ' + err.message); }

    // 7. Resetear data/ias-personalizadas.json (usos = 0, usuariosUsados = [])
    try {
      if (fs.existsSync(iasPath)) {
        const iasData = JSON.parse(fs.readFileSync(iasPath, 'utf8'));
        let count = 0;
        if (iasData.ias) {
          for (const iaKey in iasData.ias) {
            const ia = iasData.ias[iaKey];
            if (ia) {
              ia.uses = 0;
              ia.usedBy = [];
              count++;
            }
          }
        }
        fs.writeFileSync(iasPath, JSON.stringify(iasData, null, 2), 'utf8');
        resetResults.push(`✅ IAs Personalizadas: ${count} IAs reseteadas a 0 usos`);
        console.log(`   ✅ IAs Personalizadas: ${count} IAs reseteadas.`);
      }
    } catch (err) { resetResults.push('❌ IAs Personalizadas: ' + err.message); }

    // 8. Resetear plugins/SUBBOTS/data/subbots-actividad.json (commandCount = 0, lastUsed = 0)
    try {
      if (fs.existsSync(subbotActividadPath)) {
        const subActData = JSON.parse(fs.readFileSync(subbotActividadPath, 'utf8'));
        let count = 0;
        for (const subKey in subActData) {
          if (subActData[subKey]) {
            subActData[subKey].commandCount = 0;
            subActData[subKey].lastUsed = 0;
            count++;
          }
        }
        fs.writeFileSync(subbotActividadPath, JSON.stringify(subActData, null, 2), 'utf8');
        resetResults.push(`✅ Subbots Actividad: ${count} subbots reseteados a 0 comandos`);
        console.log(`   ✅ Subbots Actividad: ${count} subbots reseteados.`);
      }
    } catch (err) { resetResults.push('❌ Subbots Actividad: ' + err.message); }

    // ============ PASO 4: LIMPIEZA DE CACHÉS EN MEMORIA Y WAL FINAL ============
    console.log('\n🧹 Limpiando cachés en memoria y haciendo checkpoint final...\n');

    if (global.db) {
      if (global.db._userCache && typeof global.db._userCache.clear === 'function') {
        global.db._userCache.clear();
      }
      if (global.db._kvCache && typeof global.db._kvCache.clear === 'function') {
        global.db._kvCache.clear();
      }
    }

    // Invalidad caché en subbotActivityTracker si está cargado
    try {
      const subActivityTracker = require('./plugins/SUBBOTS/subbotActivityTracker');
      if (typeof subActivityTracker.loadActivity === 'function') {
        subActivityTracker.loadActivity();
      }
    } catch (_) {}

    // Checkpoint WAL final en SQLite
    if (global.db && global.db.db) {
      try {
        global.db.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
        console.log('   ✅ PRAGMA wal_checkpoint(TRUNCATE) ejecutado.');
      } catch (_) {}
    }

    console.log('\n✅ ========================================');
    console.log('✅ RESET DE TEMPORADA COMPLETADO EXITOSAMENTE');
    console.log('✅ ========================================\n');

    return { success: true, resetResults, backupResults };

  } catch (error) {
    console.error('❌ ERROR FATAL DURANTE EL RESET:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Inicializar el sistema de reset automático
 */
function inicializarResetAutomatico(sock) {
  console.log('\n🤖 Inicializando sistema de reset automático de temporada...');
  
  // Cron para ejecutar el día 1 de cada mes a las 00:05 hora de Uruguay
  const cronExpression = '5 0 1 * *';
  
  const task = cron.schedule(cronExpression, async () => {
    console.log('\n⏰ CRON DISPARADO: Ejecutando reset automático de temporada...');
    await ejecutarResetTemporada(sock, true);
  }, {
    scheduled: true,
    timezone: URUGUAY_TIMEZONE
  });
  
  console.log(`✅ Reset automático programado:`);
  console.log(`   📅 Frecuencia: Día 1 de cada mes`);
  console.log(`   🕐 Hora: 00:05 (5 minutos después de medianoche)`);
  console.log(`   🌍 Zona horaria: ${URUGUAY_TIMEZONE}`);
  console.log(`   📋 Expresión cron: ${cronExpression}\n`);
  
  return task;
}

module.exports = {
  inicializarResetAutomatico,
  ejecutarResetTemporada
};
