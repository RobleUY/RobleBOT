/**
 * statsCache.js
 * Caché compartido para grupos únicos y usuarios totales.
 *
 * - Grupos: se refresca cada 10 min (llama a la API de WhatsApp en background)
 * - Usuarios: se refresca cada 5 min (lee global.db, sin API)
 *
 * Uso:
 *   const { getCachedGroups, getCachedUsers } = require('./statsCache');
 *   const { totalGroups, totalParticipants } = getCachedGroups();
 *   const totalUsers = getCachedUsers();
 */

const GROUPS_INTERVAL_MS  = 10 * 60 * 1000; //  10 minutos
const USERS_INTERVAL_MS   =  5 * 60 * 1000; //   5 minutos
const FETCH_TIMEOUT_MS    =  8 * 1000;       //   8 s por bot antes de abandonar

// ── Estado interno ────────────────────────────────────────────────────────────
let _groupsCache = { totalGroups: 0, totalParticipants: 0, updatedAt: 0 };
let _usersCache  = { totalUsers: 0, updatedAt: 0 };
let _initialized = false;

// ── Helpers ───────────────────────────────────────────────────────────────────
function filterGroups(chatsObj) {
    return Object.entries(chatsObj || {}).filter(
        ([jid, g]) => jid.endsWith('@g.us') && !jid.includes('@newsletter') && g.announce !== true
    );
}

function withTimeout(promise, ms) {
    return Promise.race([
        promise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
    ]);
}

// ── Refresh de grupos ─────────────────────────────────────────────────────────
async function refreshGroups() {
    try {
        const mainConn = global.conn;
        const subbots  = (global.subConns || []).filter(c => c?.user);
        const allBots  = [mainConn, ...subbots].filter(Boolean);

        const results = await Promise.allSettled(
            allBots.map(bot =>
                typeof bot.groupFetchAllParticipating === 'function'
                    ? withTimeout(bot.groupFetchAllParticipating(), FETCH_TIMEOUT_MS)
                    : Promise.resolve({})
            )
        );

        const uniqueMap = new Map();
        for (const result of results) {
            if (result.status === 'fulfilled') {
                for (const [jid, g] of filterGroups(result.value)) {
                    if (!uniqueMap.has(jid)) {
                        uniqueMap.set(jid, g.participants?.length || 0);
                    }
                }
            }
        }

        _groupsCache = {
            totalGroups:       uniqueMap.size,
            totalParticipants: [...uniqueMap.values()].reduce((s, n) => s + n, 0),
            updatedAt:         Date.now()
        };
    } catch (e) {
        console.error('[statsCache] Error refrescando grupos:', e.message);
    }
}

// ── Refresh de usuarios ───────────────────────────────────────────────────────
function refreshUsers() {
    try {
        const count = global.db?.data?.users
            ? Object.keys(global.db.data.users).length
            : 0;
        _usersCache = { totalUsers: count, updatedAt: Date.now() };
    } catch (e) {
        console.error('[statsCache] Error refrescando usuarios:', e.message);
    }
}

// ── Inicialización (llamar una vez al arrancar) ───────────────────────────────
function initStatsCache() {
    if (_initialized) return;
    _initialized = true;

    // Primera carga inmediata
    refreshGroups();
    refreshUsers();

    // Intervalos periódicos
    setInterval(refreshGroups, GROUPS_INTERVAL_MS);
    setInterval(refreshUsers,  USERS_INTERVAL_MS);

    console.log('[statsCache] Caché de stats iniciado (grupos: 10 min, usuarios: 5 min)');
}

// ── Getters públicos ──────────────────────────────────────────────────────────
function getCachedGroups() {
    return { ..._groupsCache };
}

function getCachedUsers() {
    return _usersCache.totalUsers;
}

module.exports = { initStatsCache, getCachedGroups, getCachedUsers };
