'use strict';

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

// Archivos críticos que NUNCA se borran
const KEEP_FILES = new Set([
    'creds.json',
    'owner.json',
    'app-state-sync-version.json',
    'app-state-sync-version-regular_high.json',
    'app-state-sync-version-regular_low.json',
    'app-state-sync-version-critical_unblock_to_change.json',
    'app-state-sync-version-critical_block_to_change.json',
    'app-state-sync-version-nse_vod_w.json',
]);

// Prefijos de archivos Signal que son PELIGROSOS de borrar mientras el bot está vivo
// Estos solo se limpian con límite de cantidad (cleanupBaileysAuth), NO por edad
const SIGNAL_PREFIXES = new Set([
    'pre-key-',
    'sender-key-',
    'sender-key-memory-',
    'session-',
    'app-state-sync-key-',
    'app-state-sync-version-',
    'device-list-',
    'lid-mapping-',
    'tctoken-',
]);

class SessionCleaner {
    constructor(options = {}) {
        this.mainAuthDir = options.mainAuthDir || path.join(__dirname, 'baileys_auth');
        this.subbotsDir = options.subbotsDir || path.join(__dirname, 'plugins/SUBBOTS/sesiones');

        // Intervalo de limpieza: por defecto 30 minutos (no 5)
        this.cleanInterval = options.cleanInterval || 30 * 60 * 1000;

        // Edad máxima para archivos TEMPORALES (no-Signal): 4 horas
        this.maxFileAge = options.maxFileAge || 4 * 60 * 60 * 1000;

        this.intervalId = null;
        this.stats = {
            totalCleaned: 0,
            lastCleanTime: null,
            errors: 0
        };
    }

    start() {
        if (this.intervalId) {
            console.log(chalk.yellow('[SessionCleaner] Ya está en ejecución'));
            return;
        }

        console.log(chalk.green(`[SessionCleaner] Iniciado - limpieza cada ${this.cleanInterval / 60000} minutos`));

        // Primera limpieza con delay de 2 minutos para no interferir con el arranque
        setTimeout(() => this.cleanAll(), 2 * 60 * 1000);

        this.intervalId = setInterval(() => {
            this.cleanAll();
        }, this.cleanInterval);
    }

    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log(chalk.yellow('[SessionCleaner] Detenido'));
        }
    }

    async cleanAll() {
        const startTime = Date.now();
        let totalCleaned = 0;

        try {
            const mainCleaned = await this.cleanDirectory(this.mainAuthDir, 'Bot Principal');
            totalCleaned += mainCleaned;

            const subbotsCleaned = await this.cleanSubBots();
            totalCleaned += subbotsCleaned;

            this.stats.totalCleaned += totalCleaned;
            this.stats.lastCleanTime = new Date().toISOString();

            if (totalCleaned > 0) {
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
                console.log(chalk.green(`[SessionCleaner] ✓ ${totalCleaned} archivos eliminados en ${elapsed}s`));
            }

            if (global.gc) {
                global.gc();
            }

        } catch (error) {
            this.stats.errors++;
            console.error(chalk.red('[SessionCleaner] Error en limpieza:'), error.message);
        }
    }

    async cleanDirectory(dirPath, label = 'Directorio') {
        if (!fs.existsSync(dirPath)) {
            return 0;
        }

        let cleaned = 0;
        const now = Date.now();

        try {
            const files = fs.readdirSync(dirPath);

            for (const file of files) {
                const filePath = path.join(dirPath, file);

                try {
                    const stats = fs.statSync(filePath);

                    if (stats.isDirectory()) continue;

                    const shouldClean = this.shouldCleanFile(file, stats, now);

                    if (shouldClean) {
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }

                } catch (error) {
                    // Solo borrar si el archivo está corrupto (ENOENT = ya no existe, EPERM = sin permisos)
                    if (error.code === 'ENOENT') {
                        // El archivo ya fue borrado por otro proceso, ignorar
                    } else if (error.code === 'EPERM') {
                        // Sin permisos, ignorar silenciosamente
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.cyan(`[SessionCleaner] ${label}: ${cleaned} archivos eliminados`));
            }

        } catch (error) {
            console.error(chalk.red(`[SessionCleaner] Error limpiando ${label}:`), error.message);
        }

        return cleaned;
    }

    async cleanSubBots() {
        if (!fs.existsSync(this.subbotsDir)) {
            return 0;
        }

        let totalCleaned = 0;

        try {
            const subBotFolders = fs.readdirSync(this.subbotsDir);

            for (const folder of subBotFolders) {
                const subBotPath = path.join(this.subbotsDir, folder);

                try {
                    const stats = fs.statSync(subBotPath);
                    if (!stats.isDirectory()) continue;

                    const cleaned = await this.cleanDirectory(subBotPath, `SubBot #${folder}`);
                    totalCleaned += cleaned;

                    await this.cleanEmptySubBotSession(subBotPath, folder);

                } catch (error) {
                    console.error(chalk.red(`[SessionCleaner] Error en SubBot ${folder}:`), error.message);
                }
            }

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error limpiando SubBots:'), error.message);
        }

        return totalCleaned;
    }

    async cleanEmptySubBotSession(subBotPath, folder) {
        try {
            const files = fs.readdirSync(subBotPath);
            const credsFile = path.join(subBotPath, 'creds.json');
            const ownerFile = path.join(subBotPath, 'owner.json');

            const hasCreds = fs.existsSync(credsFile);
            const hasOwner = fs.existsSync(ownerFile);

            if (!hasCreds && !hasOwner && files.length < 3) {
                const isActive = global.subConns?.some(c => c._subNum === parseInt(folder) && c.user);

                if (!isActive) {
                    fs.rmSync(subBotPath, { recursive: true, force: true });
                    console.log(chalk.yellow(`[SessionCleaner] Sesión incompleta eliminada: SubBot #${folder}`));
                }
            }

        } catch (error) {
            // Ignorar errores aquí
        }
    }

    shouldCleanFile(fileName, stats, now) {
        // Nunca borrar archivos críticos
        if (KEEP_FILES.has(fileName)) {
            return false;
        }

        // Nunca borrar archivos de claves Signal por edad — son manejados
        // exclusivamente por cleanupBaileysAuth.js que usa límites de cantidad,
        // no de tiempo. Borrarlos aquí causa "Bad MAC" porque el bot pierde
        // las claves para verificar mensajes en vuelo.
        const isSignalKey = [...SIGNAL_PREFIXES].some(prefix => fileName.startsWith(prefix));
        if (isSignalKey) {
            return false;
        }

        // Archivos de tamaño 0 que no son claves Signal sí se pueden borrar
        if (stats.size === 0) {
            return true;
        }

        // Archivos temporales genéricos (tmp-, temp-) mayores a maxFileAge
        const isTempFile =
            fileName.startsWith('tmp-') ||
            fileName.startsWith('temp-');

        const age = now - stats.mtimeMs;

        if (isTempFile && age > this.maxFileAge) {
            return true;
        }

        return false;
    }

    async forceCleanSession(jid, label = 'Usuario') {
        try {
            const userNumber = jid.split('@')[0].split(':')[0];
            let cleaned = 0;

            if (fs.existsSync(this.mainAuthDir)) {
                const files = fs.readdirSync(this.mainAuthDir);
                for (const file of files) {
                    if (file.includes(userNumber)) {
                        const filePath = path.join(this.mainAuthDir, file);
                        try {
                            fs.unlinkSync(filePath);
                            cleaned++;
                        } catch {}
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.yellow(`[SessionCleaner] Sesión forzada limpiada: ${label} (${cleaned} archivos)`));
            }

            return cleaned;

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error en limpieza forzada:'), error.message);
            return 0;
        }
    }

    getStats() {
        return {
            ...this.stats,
            isRunning: this.intervalId !== null,
            cleanInterval: this.cleanInterval / 60000 + ' minutos',
            maxFileAge: this.maxFileAge / 60000 + ' minutos'
        };
    }

    async cleanNow() {
        console.log(chalk.cyan('[SessionCleaner] Ejecutando limpieza manual...'));
        await this.cleanAll();
    }
}

module.exports = SessionCleaner;