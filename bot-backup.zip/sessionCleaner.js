'use strict';
/**
 * Sistema de limpieza automática de sesiones de Baileys
 * 
 * Limpia archivos temporales acumulados en:
 * - baileys_auth/ (bot principal)
 * - plugins/SUBBOTS/sesiones/*/  (subbots)
 * 
 * Previene acumulación de:
 * - pre-key-*
 * - sender-key-*
 * - session-*
 * - app-state-sync-*
 * - Archivos corruptos o muy antiguos
 */

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

class SessionCleaner {
    constructor(options = {}) {
        this.mainAuthDir = options.mainAuthDir || path.join(__dirname, 'baileys_auth');
        this.subbotsDir = options.subbotsDir || path.join(__dirname, 'plugins/SUBBOTS/sesiones');
        
        // Configuración de tiempos (en milisegundos)
        this.cleanInterval = options.cleanInterval || 5 * 60 * 1000; // 5 minutos
        this.maxFileAge = options.maxFileAge || 2 * 60 * 60 * 1000; // 2 horas
        this.tempFileAge = options.tempFileAge || 30 * 60 * 1000; // 30 minutos para archivos temporales
        
        this.intervalId = null;
        this.stats = {
            totalCleaned: 0,
            lastCleanTime: null,
            errors: 0
        };
    }

    /**
     * Inicia la limpieza automática periódica
     */
    start() {
        if (this.intervalId) {
            console.log(chalk.yellow('[SessionCleaner] Ya está en ejecución'));
            return;
        }

        console.log(chalk.green(`[SessionCleaner] Iniciado - limpieza cada ${this.cleanInterval / 60000} minutos`));
        
        // Limpieza inicial
        this.cleanAll();
        
        // Programar limpiezas periódicas
        this.intervalId = setInterval(() => {
            this.cleanAll();
        }, this.cleanInterval);
    }

    /**
     * Detiene la limpieza automática
     */
    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log(chalk.yellow('[SessionCleaner] Detenido'));
        }
    }

    /**
     * Ejecuta limpieza completa de todas las sesiones
     */
    async cleanAll() {
        const startTime = Date.now();
        let totalCleaned = 0;

        try {
            // Limpiar bot principal
            const mainCleaned = await this.cleanDirectory(this.mainAuthDir, 'Bot Principal');
            totalCleaned += mainCleaned;

            // Limpiar subbots
            const subbotsCleaned = await this.cleanSubBots();
            totalCleaned += subbotsCleaned;

            // Actualizar estadísticas
            this.stats.totalCleaned += totalCleaned;
            this.stats.lastCleanTime = new Date().toISOString();

            if (totalCleaned > 0) {
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
                console.log(chalk.green(`[SessionCleaner] ✓ ${totalCleaned} archivos eliminados en ${elapsed}s`));
            }

            // Forzar garbage collection si está disponible
            if (global.gc) {
                global.gc();
            }

        } catch (error) {
            this.stats.errors++;
            console.error(chalk.red('[SessionCleaner] Error en limpieza:'), error.message);
        }
    }

    /**
     * Limpia un directorio específico
     */
    async cleanDirectory(dirPath, label = 'Directorio') {
        if (!fs.existsSync(dirPath)) {
            return 0;
        }

        let cleaned = 0;
        const now = Date.now();

        try {
            const files = fs.readdirSync(dirPath);

            for (const file of files) {
                const filePath = path.join(dirPath, file);

                try {
                    const stats = fs.statSync(filePath);
                    
                    // Saltar directorios
                    if (stats.isDirectory()) continue;

                    // Archivos a limpiar
                    const shouldClean = this.shouldCleanFile(file, stats, now);

                    if (shouldClean) {
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }

                } catch (error) {
                    // Si hay error al leer el archivo, probablemente está corrupto
                    if (error.code === 'ENOENT' || error.code === 'EPERM') {
                        try {
                            fs.unlinkSync(filePath);
                            cleaned++;
                        } catch {}
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.cyan(`[SessionCleaner] ${label}: ${cleaned} archivos eliminados`));
            }

        } catch (error) {
            console.error(chalk.red(`[SessionCleaner] Error limpiando ${label}:`), error.message);
        }

        return cleaned;
    }

    /**
     * Limpia sesiones de todos los subbots
     */
    async cleanSubBots() {
        if (!fs.existsSync(this.subbotsDir)) {
            return 0;
        }

        let totalCleaned = 0;

        try {
            const subBotFolders = fs.readdirSync(this.subbotsDir);

            for (const folder of subBotFolders) {
                const subBotPath = path.join(this.subbotsDir, folder);
                
                try {
                    const stats = fs.statSync(subBotPath);
                    if (!stats.isDirectory()) continue;

                    const cleaned = await this.cleanDirectory(subBotPath, `SubBot #${folder}`);
                    totalCleaned += cleaned;

                    // Limpiar carpetas vacías o sin creds.json (sesiones incompletas)
                    await this.cleanEmptySubBotSession(subBotPath, folder);

                } catch (error) {
                    console.error(chalk.red(`[SessionCleaner] Error en SubBot ${folder}:`), error.message);
                }
            }

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error limpiando SubBots:'), error.message);
        }

        return totalCleaned;
    }

    /**
     * Elimina sesiones de subbots vacías o incompletas
     */
    async cleanEmptySubBotSession(subBotPath, folder) {
        try {
            const files = fs.readdirSync(subBotPath);
            const credsFile = path.join(subBotPath, 'creds.json');
            const ownerFile = path.join(subBotPath, 'owner.json');

            // Si no tiene creds.json ni owner.json, es una sesión incompleta
            const hasCreds = fs.existsSync(credsFile);
            const hasOwner = fs.existsSync(ownerFile);

            if (!hasCreds && !hasOwner && files.length < 3) {
                // Verificar que no esté activo
                const isActive = global.subConns?.some(c => c._subNum === parseInt(folder) && c.user);
                
                if (!isActive) {
                    fs.rmSync(subBotPath, { recursive: true, force: true });
                    console.log(chalk.yellow(`[SessionCleaner] Sesión incompleta eliminada: SubBot #${folder}`));
                }
            }

        } catch (error) {
            // Ignorar errores en esta limpieza opcional
        }
    }

    /**
     * Determina si un archivo debe ser limpiado
     */
    shouldCleanFile(fileName, stats, now) {
        const age = now - stats.mtimeMs;

        // Archivos temporales de Baileys (más agresivo)
        const isTempFile = 
            fileName.includes('pre-key-') ||
            fileName.includes('sender-key-') ||
            fileName.includes('session-') ||
            fileName.includes('app-state-sync-key-') ||
            fileName.startsWith('tmp-') ||
            fileName.startsWith('temp-');

        if (isTempFile && age > this.tempFileAge) {
            return true;
        }

        // Archivos muy antiguos (cualquier tipo)
        if (age > this.maxFileAge) {
            // No eliminar archivos críticos aunque sean antiguos
            const isCritical = 
                fileName === 'creds.json' ||
                fileName === 'owner.json' ||
                fileName === 'app-state-sync-version.json';
            
            if (!isCritical) {
                return true;
            }
        }

        // Archivos corruptos o con tamaño 0
        if (stats.size === 0) {
            return true;
        }

        return false;
    }

    /**
     * Limpieza forzada de sesión específica (para errores BAD MAC)
     */
    async forceCleanSession(jid, label = 'Usuario') {
        try {
            const userNumber = jid.split('@')[0].split(':')[0];
            let cleaned = 0;

            // Limpiar del bot principal
            if (fs.existsSync(this.mainAuthDir)) {
                const files = fs.readdirSync(this.mainAuthDir);
                for (const file of files) {
                    if (file.includes(userNumber)) {
                        const filePath = path.join(this.mainAuthDir, file);
                        try {
                            fs.unlinkSync(filePath);
                            cleaned++;
                        } catch {}
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.yellow(`[SessionCleaner] Sesión forzada limpiada: ${label} (${cleaned} archivos)`));
            }

            return cleaned;

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error en limpieza forzada:'), error.message);
            return 0;
        }
    }

    /**
     * Obtiene estadísticas de limpieza
     */
    getStats() {
        return {
            ...this.stats,
            isRunning: this.intervalId !== null,
            cleanInterval: this.cleanInterval / 60000 + ' minutos',
            maxFileAge: this.maxFileAge / 60000 + ' minutos',
            tempFileAge: this.tempFileAge / 60000 + ' minutos'
        };
    }

    /**
     * Limpieza manual bajo demanda
     */
    async cleanNow() {
        console.log(chalk.cyan('[SessionCleaner] Ejecutando limpieza manual...'));
        await this.cleanAll();
    }
}

module.exports = SessionCleaner;
