'use strict';


const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

class SessionCleaner {
    constructor(options = {}) {
        this.mainAuthDir = options.mainAuthDir || path.join(__dirname, 'baileys_auth');
        this.subbotsDir = options.subbotsDir || path.join(__dirname, 'plugins/SUBBOTS/sesiones');
        
       
        this.cleanInterval = options.cleanInterval || 5 * 60 * 1000; 
        this.maxFileAge = options.maxFileAge || 2 * 60 * 60 * 1000;
        this.tempFileAge = options.tempFileAge || 30 * 60 * 1000;
        
        this.intervalId = null;
        this.stats = {
            totalCleaned: 0,
            lastCleanTime: null,
            errors: 0
        };
    }

  
    start() {
        if (this.intervalId) {
            console.log(chalk.yellow('[SessionCleaner] Ya está en ejecución'));
            return;
        }

        console.log(chalk.green(`[SessionCleaner] Iniciado - limpieza cada ${this.cleanInterval / 60000} minutos`));
        
        this.cleanAll();
        
        this.intervalId = setInterval(() => {
            this.cleanAll();
        }, this.cleanInterval);
    }

    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log(chalk.yellow('[SessionCleaner] Detenido'));
        }
    }

  
    async cleanAll() {
        const startTime = Date.now();
        let totalCleaned = 0;

        try {
          
            const mainCleaned = await this.cleanDirectory(this.mainAuthDir, 'Bot Principal');
            totalCleaned += mainCleaned;

            
            const subbotsCleaned = await this.cleanSubBots();
            totalCleaned += subbotsCleaned;

            
            this.stats.totalCleaned += totalCleaned;
            this.stats.lastCleanTime = new Date().toISOString();

            if (totalCleaned > 0) {
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
                console.log(chalk.green(`[SessionCleaner] ✓ ${totalCleaned} archivos eliminados en ${elapsed}s`));
            }

          
            if (global.gc) {
                global.gc();
            }

        } catch (error) {
            this.stats.errors++;
            console.error(chalk.red('[SessionCleaner] Error en limpieza:'), error.message);
        }
    }

    
    async cleanDirectory(dirPath, label = 'Directorio') {
        if (!fs.existsSync(dirPath)) {
            return 0;
        }

        let cleaned = 0;
        const now = Date.now();

        try {
            const files = fs.readdirSync(dirPath);

            for (const file of files) {
                const filePath = path.join(dirPath, file);

                try {
                    const stats = fs.statSync(filePath);
                    
                    if (stats.isDirectory()) continue;

                    const shouldClean = this.shouldCleanFile(file, stats, now);

                    if (shouldClean) {
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }

                } catch (error) {
                    if (error.code === 'ENOENT' || error.code === 'EPERM') {
                        try {
                            fs.unlinkSync(filePath);
                            cleaned++;
                        } catch {}
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.cyan(`[SessionCleaner] ${label}: ${cleaned} archivos eliminados`));
            }

        } catch (error) {
            console.error(chalk.red(`[SessionCleaner] Error limpiando ${label}:`), error.message);
        }

        return cleaned;
    }

   
    async cleanSubBots() {
        if (!fs.existsSync(this.subbotsDir)) {
            return 0;
        }

        let totalCleaned = 0;

        try {
            const subBotFolders = fs.readdirSync(this.subbotsDir);

            for (const folder of subBotFolders) {
                const subBotPath = path.join(this.subbotsDir, folder);
                
                try {
                    const stats = fs.statSync(subBotPath);
                    if (!stats.isDirectory()) continue;

                    const cleaned = await this.cleanDirectory(subBotPath, `SubBot #${folder}`);
                    totalCleaned += cleaned;

                  
                    await this.cleanEmptySubBotSession(subBotPath, folder);

                } catch (error) {
                    console.error(chalk.red(`[SessionCleaner] Error en SubBot ${folder}:`), error.message);
                }
            }

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error limpiando SubBots:'), error.message);
        }

        return totalCleaned;
    }

    
    async cleanEmptySubBotSession(subBotPath, folder) {
        try {
            const files = fs.readdirSync(subBotPath);
            const credsFile = path.join(subBotPath, 'creds.json');
            const ownerFile = path.join(subBotPath, 'owner.json');

          
            const hasCreds = fs.existsSync(credsFile);
            const hasOwner = fs.existsSync(ownerFile);

            if (!hasCreds && !hasOwner && files.length < 3) {
               
                const isActive = global.subConns?.some(c => c._subNum === parseInt(folder) && c.user);
                
                if (!isActive) {
                    fs.rmSync(subBotPath, { recursive: true, force: true });
                    console.log(chalk.yellow(`[SessionCleaner] Sesión incompleta eliminada: SubBot #${folder}`));
                }
            }

        } catch (error) {
          
        }
    }

   
    shouldCleanFile(fileName, stats, now) {
        const age = now - stats.mtimeMs;

     
        const isTempFile = 
            fileName.includes('pre-key-') ||
            fileName.includes('sender-key-') ||
            fileName.includes('session-') ||
            fileName.includes('app-state-sync-key-') ||
            fileName.startsWith('tmp-') ||
            fileName.startsWith('temp-');

        if (isTempFile && age > this.tempFileAge) {
            return true;
        }

      
        if (age > this.maxFileAge) {
           
            const isCritical = 
                fileName === 'creds.json' ||
                fileName === 'owner.json' ||
                fileName === 'app-state-sync-version.json';
            
            if (!isCritical) {
                return true;
            }
        }

       
        if (stats.size === 0) {
            return true;
        }

        return false;
    }

    
    async forceCleanSession(jid, label = 'Usuario') {
        try {
            const userNumber = jid.split('@')[0].split(':')[0];
            let cleaned = 0;

          
            if (fs.existsSync(this.mainAuthDir)) {
                const files = fs.readdirSync(this.mainAuthDir);
                for (const file of files) {
                    if (file.includes(userNumber)) {
                        const filePath = path.join(this.mainAuthDir, file);
                        try {
                            fs.unlinkSync(filePath);
                            cleaned++;
                        } catch {}
                    }
                }
            }

            if (cleaned > 0) {
                console.log(chalk.yellow(`[SessionCleaner] Sesión forzada limpiada: ${label} (${cleaned} archivos)`));
            }

            return cleaned;

        } catch (error) {
            console.error(chalk.red('[SessionCleaner] Error en limpieza forzada:'), error.message);
            return 0;
        }
    }

   
    getStats() {
        return {
            ...this.stats,
            isRunning: this.intervalId !== null,
            cleanInterval: this.cleanInterval / 60000 + ' minutos',
            maxFileAge: this.maxFileAge / 60000 + ' minutos',
            tempFileAge: this.tempFileAge / 60000 + ' minutos'
        };
    }


    async cleanNow() {
        console.log(chalk.cyan('[SessionCleaner] Ejecutando limpieza manual...'));
        await this.cleanAll();
    }
}

module.exports = SessionCleaner;
