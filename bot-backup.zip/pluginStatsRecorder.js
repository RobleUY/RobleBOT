const fs = require('fs');
const path = require('path');

const PLUGIN_STATS_FILE = path.join(__dirname, 'data', 'plugin-stats.json');

function loadPluginStats() {
    try {
        if (fs.existsSync(PLUGIN_STATS_FILE)) {
            return JSON.parse(fs.readFileSync(PLUGIN_STATS_FILE, 'utf8'));
        }
    } catch (e) {}
    return {};
}

function savePluginStats(data) {
    try {
        fs.writeFileSync(PLUGIN_STATS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[pluginStats] Error guardando stats:', e.message);
    }
}

/**
 * Incrementa el contador de usos de un plugin dado su filePath absoluto.
 * La clave guardada es la ruta relativa desde la raíz del proyecto (ej: plugins/ECONOMIA/saldo.js)
 */
function recordPluginUse(filePath) {
    if (!filePath) return;

    // Normalizar a ruta relativa con barras forward
    const relative = path.relative(__dirname, filePath).replace(/\\/g, '/');

    const stats = loadPluginStats();
    stats[relative] = (stats[relative] || 0) + 1;
    savePluginStats(stats);
}

/**
 * Devuelve el ranking de plugins ordenado de mayor a menor uso.
 * Cada entrada: { plugin: 'plugins/ECONOMIA/saldo.js', uses: 42 }
 */
function getPluginRanking() {
    const stats = loadPluginStats();
    return Object.entries(stats)
        .map(([plugin, uses]) => ({ plugin, uses }))
        .sort((a, b) => b.uses - a.uses);
}

module.exports = { recordPluginUse, getPluginRanking, loadPluginStats };
