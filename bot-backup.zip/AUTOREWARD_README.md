# 💰 Sistema de Recompensas Automáticas

## 📋 Descripción

Sistema automático que entrega **1,000 monedas** cada **minuto** a **TODOS los usuarios** registrados en la base de datos.

## ⚙️ Funcionamiento

- El sistema se inicia automáticamente cuando el bot se conecta
- Cada minuto (basado en el uptime del bot), entrega recompensas **silenciosamente**
- **TODOS los usuarios** en la base de datos reciben las monedas
- **NO envía notificaciones** a los grupos (totalmente automático y silencioso)
- Las recompensas se acumulan: 1min → 1k, 2min → 1k más, 3min → 1k más, etc.

## 🎯 Requisitos para Recibir Recompensas

**Ninguno** - Todos los usuarios registrados en la base de datos reciben recompensas automáticamente.

## 📊 Comandos Disponibles

### Para Usuarios

#### `.recompensas` o `.autoreward`
Muestra información sobre el sistema de recompensas:
- Monto de la recompensa (1,000 monedas/min)
- Frecuencia de entrega (cada minuto)
- Cuántas recompensas se han entregado
- Tiempo hasta la próxima recompensa
- Uptime del bot

#### `.ping` o `.status`
Muestra el estado del bot incluyendo:
- Latencia
- Uptime
- Información de recompensas automáticas

### Para Owner

#### `.autorewardctl`
Panel de control del sistema (solo owner):

- `.autorewardctl` - Ver estado y comandos disponibles
- `.autorewardctl forzar` - Forzar entrega inmediata de recompensas
- `.autorewardctl stats` - Ver estadísticas detalladas
- `.autorewardctl reiniciar` - Reiniciar el contador de recompensas
- `.autorewardctl parar` - Detener el sistema
- `.autorewardctl iniciar` - Iniciar el sistema

## 🔧 Archivos del Sistema

### `autoRewardSystem.js`
Clase principal que maneja:
- Tracking del uptime
- Verificación cada minuto
- Entrega de recompensas
- Notificaciones a grupos
- Estadísticas

### `index.js` (modificado)
- Inicializa el sistema al conectarse
- Lo reinicia en reloads
- Lo mantiene en `global.autoRewardSystem`

### `plugins/ECONOMIA/autoreward.js`
Comando para usuarios: ver estado del sistema

### `plugins/OWNER/autoreward-control.js`
Comando para owner: controlar el sistema manualmente

### `plugins/_status.js` (modificado)
Comando `.ping` actualizado con info de recompensas

## 📈 Flujo de Funcionamiento

1. **Inicio del Bot**
   - Se crea instancia de `AutoRewardSystem`
   - Se inicia el intervalo de verificación (cada 60 segundos)
   - Se registra en `global.autoRewardSystem`

2. **Cada Minuto**
   - El sistema verifica el uptime actual
   - Calcula cuántas recompensas deberían haberse dado
   - Si faltan recompensas por dar, las entrega

3. **Entrega de Recompensas**
   - Itera sobre todos los usuarios en la BD
   - Suma 1,000 monedas a cada usuario
   - Guarda los cambios en la BD
   - **NO notifica a grupos** (silencioso)
   - Log simple en consola: "💰 Recompensa de 1,000 entregada a X usuarios"

4. **Sin Notificaciones**
   - El sistema funciona completamente en segundo plano
   - No envía mensajes a grupos
   - Los usuarios ven sus monedas aumentar al revisar `.saldo`
   - Solo logs en consola del servidor

## 🔄 Reload y Persistencia

El sistema se reinicia automáticamente en:
- Reloads del bot (`.reload`)
- Reconexiones
- Reinicios del proceso

**Nota:** El contador de recompensas se reinicia al reiniciar el bot, ya que se basa en el uptime del proceso actual.

## 💡 Ejemplos de Uso

### Usuario Normal
```
.recompensas
```
Respuesta:
```
╔═══════════════════════╗
║  💰 RECOMPENSAS AUTOMÁTICAS  ║
╚═══════════════════════╝

🎁 Recompensa: 1,000 monedas
⏱️ Frecuencia: Cada minuto
📊 Recompensas entregadas: 45
⏰ Uptime: 0h 45m 30s
⏳ Próxima recompensa en: 30s

✅ Todos los usuarios reciben recompensas automáticamente

Las recompensas se entregan de forma silenciosa cada minuto.
```

### Owner
```
.autorewardctl forzar
```
Respuesta:
```
⏳ Forzando entrega de recompensas...
✅ Recompensas entregadas manualmente.
```

## 🐛 Troubleshooting

### Las recompensas no se entregan
1. Verificar que el sistema esté activo: `.autorewardctl`
2. Verificar que haya usuarios en la BD
3. Revisar logs del servidor para errores

### El contador se reinició
- Esto es normal al reiniciar el bot
- El uptime se basa en `process.uptime()`
- Las recompensas se reanudarán automáticamente

### El contador no coincide con el uptime
- El sistema ahora entrega todas las recompensas pendientes
- Si el bot estuvo caído, al reiniciar NO recupera las recompensas perdidas
- El contador empieza desde 0 en cada reinicio

## 📝 Notas Técnicas

- **Intervalo de verificación:** 60 segundos (1 minuto)
- **Intervalo de recompensas:** 60,000 ms (1 minuto)
- **Monto por recompensa:** 1,000 monedas
- **Notificaciones:** Ninguna (totalmente silencioso)
- **Persistencia:** En memoria, se reinicia con el bot
- **Ganancia por hora:** 60,000 monedas por usuario con apodo
- **Ganancia por día:** 1,440,000 monedas por usuario con apodo

## 🎉 Beneficios

- ✅ **Todos los usuarios** reciben recompensas (sin requisitos)
- ✅ Recompensa la actividad y permanencia
- ✅ Totalmente automático, sin intervención manual
- ✅ **Silencioso, sin spam en grupos**
- ✅ Escalable a cualquier número de usuarios
- ✅ Control total para el owner
- ✅ Recompensas frecuentes (cada minuto)
- ✅ Los usuarios descubren sus monedas al revisar su saldo
- ✅ Logs simples y limpios en consola

---

**Desarrollado para RobleBOT** 🤖
