/**
 * Archivo de configuración centralizado
 * Puedes modificar aquí los números de owner
 */

const config = {
    // Números de propietarios del bot (pueden ser números reales o IDs de grupo)
    owners: [
        '59893900470',      // Tu número real
        '149078365237384',
        '120363402856520241@g.us',
        '120363402856520241',
        'ACFC20689D94FF6377E1263C37170916',
        '59893900470@s.whatsapp.net'
    ],
    
    // Verificar si un número es owner
    isOwner: function(number) {
        return this.owners.includes(number);
    },
    
    // Verificar si un JID es owner (maneja ambos formatos)
    async isOwnerJid(jid, groupId = null) {
        // Extraer número del JID
        const cleanNumber = await global.db.extractRealNumber(jid, groupId);
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        // Verificar ambos
        return this.isOwner(cleanNumber) || this.isOwner(rawNumber);
    },
    
    // Agregar un owner
    addOwner: function(number) {
        if (!this.owners.includes(number)) {
            this.owners.push(number);
            return true;
        }
        return false;
    },
    
    // Remover un owner
    removeOwner: function(number) {
        const index = this.owners.indexOf(number);
        if (index > -1) {
            this.owners.splice(index, 1);
            return true;
        }
        return false;
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // GRUPOS EXCLUSIVOS - Solo responde el bot principal
    // ═══════════════════════════════════════════════════════════════════════
    
    // Grupo oficial del bot
    OFFICIAL_GROUP: '120363203689229697@g.us',
    
    // Lista de grupos donde solo el bot principal puede responder
    // Los subbots ignorarán todos los mensajes en estos grupos
    exclusiveGroups: [
        '120363203689229697@g.us', // Grupo oficial
        // Agrega más grupos aquí si es necesario
        // 'XXXXXXXXXX@g.us',
    ],
    
    // Verificar si un grupo es exclusivo del bot principal
    isExclusiveGroup: function(groupJid) {
        return this.exclusiveGroups.includes(groupJid);
    },
    
    // Agregar un grupo a la lista de exclusivos
    addExclusiveGroup: function(groupJid) {
        if (!this.exclusiveGroups.includes(groupJid)) {
            this.exclusiveGroups.push(groupJid);
            return true;
        }
        return false;
    },
    
    // Remover un grupo de la lista de exclusivos
    removeExclusiveGroup: function(groupJid) {
        const index = this.exclusiveGroups.indexOf(groupJid);
        if (index > -1) {
            this.exclusiveGroups.splice(index, 1);
            return true;
        }
        return false;
    }
};

// Exportar configuración global
global.botConfig = config;

module.exports = config;