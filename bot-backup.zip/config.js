/**
 * Archivo de configuración centralizado
 * Puedes modificar aquí los números de owner
 */
 //asd
const config = {
    // Admins del bot (permisos intermedios entre usuarios normales y owners)
    // Los owners siempre tienen acceso a los comandos adminbot también
    adminBots: [
        // Agrega aquí los números de los adminBots (solo número, sin @s.whatsapp.net)
        '59891234567'
    ],

    // Verificar si un número es adminBot (o owner, que incluye todos los permisos)
    isAdminBot: function(number) {
        return this.adminBots.includes(number) || this.isOwner(number);
    },

    // Verificar si un JID es adminBot (maneja ambos formatos)
    async isAdminBotJid(jid, groupId = null) {
        if (!jid) return false;
        const cleanNumber = (global.db && typeof global.db.extractRealNumber === 'function')
            ? await global.db.extractRealNumber(jid, groupId)
            : jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        return this.isAdminBot(cleanNumber) || this.isAdminBot(rawNumber);
    },

    // Agregar un adminBot
    addAdminBot: function(number) {
        if (!this.adminBots.includes(number)) {
            this.adminBots.push(number);
            return true;
        }
        return false;
    },

    // Remover un adminBot
    removeAdminBot: function(number) {
        const index = this.adminBots.indexOf(number);
        if (index > -1) {
            this.adminBots.splice(index, 1);
            return true;
        }
        return false;
    },

    // Números de propietarios del bot (pueden ser números reales o IDs de grupo)
    owners: [
        '59893900470',      // Tu número real
        '149078365237384',
        '120363402856520241@g.us',
        '120363402856520241',
        '119783047569454',
        '119783047569454@g.us',
        '59893759855',
        'ACFC20689D94FF6377E1263C37170916',
        '59893900470@s.whatsapp.net'
    ],
    
    // Verificar si un número es owner
    isOwner: function(number) {
        return this.owners.includes(number);
    },
    
    // Verificar si un JID es owner (maneja ambos formatos)
    async isOwnerJid(jid, groupId = null) {
        if (!jid) return false;
        const cleanNumber = (global.db && typeof global.db.extractRealNumber === 'function')
            ? await global.db.extractRealNumber(jid, groupId)
            : jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        // Verificar ambos
        return this.isOwner(cleanNumber) || this.isOwner(rawNumber);
    },
    
    // Agregar un owner
    addOwner: function(number) {
        if (!this.owners.includes(number)) {
            this.owners.push(number);
            return true;
        }
        return false;
    },
    
    // Remover un owner
    removeOwner: function(number) {
        const index = this.owners.indexOf(number);
        if (index > -1) {
            this.owners.splice(index, 1);
            return true;
        }
        return false;
    },
    
};

// Exportar configuración global
global.botConfig = config;

module.exports = config;