/**
 * Archivo de configuración centralizado
 * Puedes modificar aquí los números de owner
 */
 //asd
const config = {
    // Números de propietarios del bot (pueden ser números reales o IDs de grupo)
    owners: [
        '59893900470',      // Tu número real
        '149078365237384',
        '120363402856520241@g.us',
        '120363402856520241',
        '119783047569454',
        '119783047569454@g.us',
        '59893759855',
        'ACFC20689D94FF6377E1263C37170916',
        '59893900470@s.whatsapp.net'
    ],
    
    // Verificar si un número es owner
    isOwner: function(number) {
        return this.owners.includes(number);
    },
    
    // Verificar si un JID es owner (maneja ambos formatos)
    async isOwnerJid(jid, groupId = null) {
        if (!jid) return false;
        const cleanNumber = (global.db && typeof global.db.extractRealNumber === 'function')
            ? await global.db.extractRealNumber(jid, groupId)
            : jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        // Verificar ambos
        return this.isOwner(cleanNumber) || this.isOwner(rawNumber);
    },
    
    // Agregar un owner
    addOwner: function(number) {
        if (!this.owners.includes(number)) {
            this.owners.push(number);
            return true;
        }
        return false;
    },
    
    // Remover un owner
    removeOwner: function(number) {
        const index = this.owners.indexOf(number);
        if (index > -1) {
            this.owners.splice(index, 1);
            return true;
        }
        return false;
    },

    // Números de administradores del bot
    adminsbot: [
        //// CAMI ///
        '573118718336',
        '229188883742770',
        //// CAMI 2///
        '573133103300',
        '137916433043568',
        //////////////////////
        
        //// ROBLEUY ////
        '149078365237384',
        '59893900470',
        //////////////////
    ],
    
};

// Exportar configuración global
global.botConfig = config;

module.exports = config;