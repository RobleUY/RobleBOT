/**
 * Archivo de configuración centralizado
 * Puedes modificar aquí los números de owner
 */

const config = {
    // Números de propietarios del bot (pueden ser números reales o IDs de grupo)
    owners: [
        '159893900470',      // Tu número real
        '1149078365237384',   // Tu ID de grupo
        '163922786836653'   // Tu ID de grupo
    ],
    
    // Números de administradores del bot (pueden ser números reales o IDs de grupo)
    admins: [
        '59812345678',
    ],
    
    // Verificar si un número es owner
    isOwner: function(number) {
        return this.owners.includes(number);
    },
    
    // Verificar si un JID es owner (maneja ambos formatos)
    async isOwnerJid(jid, groupId = null) {
        // Extraer número del JID
        const cleanNumber = await global.db.extractRealNumber(jid, groupId);
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        // Verificar ambos
        return this.isOwner(cleanNumber) || this.isOwner(rawNumber);
    },
    
    // Agregar un owner
    addOwner: function(number) {
        if (!this.owners.includes(number)) {
            this.owners.push(number);
            return true;
        }
        return false;
    },
    
    // Remover un owner
    removeOwner: function(number) {
        const index = this.owners.indexOf(number);
        if (index > -1) {
            this.owners.splice(index, 1);
            return true;
        }
        return false;
    },
    
    // Verificar si un número es admin
    isAdmin: function(number) {
        return this.admins.includes(number);
    },
    
    // Verificar si un JID es admin (maneja ambos formatos)
    async isAdminJid(jid, groupId = null) {
        // Extraer número del JID
        const cleanNumber = await global.db.extractRealNumber(jid, groupId);
        const rawNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        // Verificar ambos
        return this.isAdmin(cleanNumber) || this.isAdmin(rawNumber);
    },
    
    // Agregar un admin
    addAdmin: function(number) {
        if (!this.admins.includes(number)) {
            this.admins.push(number);
            return true;
        }
        return false;
    },
    
    // Remover un admin
    removeAdmin: function(number) {
        const index = this.admins.indexOf(number);
        if (index > -1) {
            this.admins.splice(index, 1);
            return true;
        }
        return false;
    }
};

// Exportar configuración global
global.botConfig = config;

module.exports = config;