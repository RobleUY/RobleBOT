// Sistema automático de recompensas cada 30 minutos
const chalk = require('chalk');

class AutoRewardSystem {
    constructor() {
        this.startTime = Date.now();
        this.rewardInterval = 60 * 1000; // 1 minuto en milisegundos
        this.rewardAmount = 1000;
        this.lastRewardTime = 0;
        this.rewardsGiven = 0;
        this.intervalId = null;
        
        console.log(chalk.cyan('💰 Sistema de recompensas automáticas iniciado'));
    }

    start() {
        // Verificar cada minuto si es momento de dar recompensas
        this.intervalId = setInterval(() => {
            this.checkAndReward();
        }, 60000); // Revisar cada 60 segundos
        
        console.log(chalk.green('✓ Sistema de recompensas activo (1,000 monedas/min - silencioso)'));
    }

    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log(chalk.yellow('⚠️ Sistema de recompensas detenido'));
        }
    }

    getUptime() {
        return Date.now() - this.startTime;
    }

    getUptimeFormatted() {
        const uptime = this.getUptime();
        const hours = Math.floor(uptime / (60 * 60 * 1000));
        const minutes = Math.floor((uptime % (60 * 60 * 1000)) / (60 * 1000));
        const seconds = Math.floor((uptime % (60 * 1000)) / 1000);
        return `${hours}h ${minutes}m ${seconds}s`;
    }

    async checkAndReward() {
        try {
            const currentUptime = this.getUptime();
            
            // Calcular cuántas recompensas deberían haberse dado hasta ahora
            const expectedRewards = Math.floor(currentUptime / this.rewardInterval);
            
            // Si ya dimos todas las recompensas esperadas, no hacer nada
            if (this.rewardsGiven >= expectedRewards) {
                return;
            }
            
            // Es momento de dar recompensas
            console.log(chalk.yellow(`\n⏰ Uptime: ${this.getUptimeFormatted()} - Entregando recompensas automáticas (silencioso)...`));
            
            await this.giveRewardsToAllUsers();
            
            this.rewardsGiven = expectedRewards;
            this.lastRewardTime = Date.now();
            
        } catch (error) {
            console.error(chalk.red('[AutoReward] Error en checkAndReward:'), error.message);
        }
    }

    async giveRewardsToAllUsers() {
        try {
            if (!global.db || !global.db.data || !global.db.data.users) {
                console.error(chalk.red('[AutoReward] Base de datos no disponible'));
                return;
            }

            const users = global.db.data.users;
            let rewardedCount = 0;
            let skippedCount = 0;

            for (const [userId, userData] of Object.entries(users)) {
                try {
                    // Verificar que el usuario tenga un apodo válido
                    const apodo = (userData.apodo || '').trim().toLowerCase();
                    
                    if (!apodo || apodo === '' || apodo === 'sin apodo') {
                        skippedCount++;
                        continue;
                    }

                    // Dar la recompensa
                    if (typeof userData.money !== 'number') {
                        userData.money = 0;
                    }
                    
                    userData.money += this.rewardAmount;
                    rewardedCount++;
                    
                } catch (error) {
                    console.error(chalk.red(`[AutoReward] Error procesando usuario ${userId}:`), error.message);
                }
            }

            // Guardar cambios en la base de datos
            if (global.db.save) {
                await global.db.save();
            }

            console.log(chalk.green(`✅ Recompensas entregadas (silencioso):`));
            console.log(chalk.cyan(`   💰 ${rewardedCount} usuarios recibieron ${this.rewardAmount.toLocaleString()} monedas`));
            console.log(chalk.gray(`   ⏭️  ${skippedCount} usuarios sin apodo (omitidos)`));
            console.log(chalk.yellow(`   📊 Total de recompensas dadas: ${this.rewardsGiven + 1}`));
            console.log(chalk.blue(`   ⏱️  Próxima recompensa en: 1 minuto\n`));

        } catch (error) {
            console.error(chalk.red('[AutoReward] Error en giveRewardsToAllUsers:'), error.message);
        }
    }

    getStats() {
        return {
            uptime: this.getUptime(),
            uptimeFormatted: this.getUptimeFormatted(),
            rewardsGiven: this.rewardsGiven,
            rewardAmount: this.rewardAmount,
            rewardInterval: this.rewardInterval,
            nextRewardIn: this.rewardInterval - (this.getUptime() % this.rewardInterval),
            lastRewardTime: this.lastRewardTime
        };
    }
}

module.exports = AutoRewardSystem;
