// Sistema automático de recompensas cada 30 minutos
const chalk = require('chalk');

class AutoRewardSystem {
    constructor() {
        this.startTime = Date.now();
        this.rewardInterval = 60 * 60000; // 60 minutos en milisegundos
        this.rewardAmount = 1000;
        this.lastRewardTime = 0;
        this.rewardsGiven = 0;
        this.intervalId = null;
        
        console.log(chalk.cyan('💰 Sistema de recompensas automáticas iniciado'));
    }

    start() {
        // Verificar cada minuto si es momento de dar recompensas
        this.intervalId = setInterval(() => {
            this.checkAndReward();
        }, 60000); // Revisar cada 60 segundos
        
        console.log(chalk.green('✓ Sistema de recompensas activo (1,000 monedas/hora - silencioso)'));
    }

    stop() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log(chalk.yellow('⚠️ Sistema de recompensas detenido'));
        }
    }

    getUptime() {
        return Date.now() - this.startTime;
    }

    getUptimeFormatted() {
        const uptime = this.getUptime();
        const hours = Math.floor(uptime / (60 * 60 * 1000));
        const minutes = Math.floor((uptime % (60 * 60 * 1000)) / (60 * 1000));
        const seconds = Math.floor((uptime % (60 * 1000)) / 1000);
        return `${hours}h ${minutes}m ${seconds}s`;
    }

    async checkAndReward() {
        try {
            const currentUptime = this.getUptime();
            
            // Calcular cuántas recompensas deberían haberse dado hasta ahora
            const expectedRewards = Math.floor(currentUptime / this.rewardInterval);
            
            // Si ya dimos todas las recompensas esperadas, no hacer nada
            if (this.rewardsGiven >= expectedRewards) {
                return;
            }
            
            // Dar todas las recompensas pendientes (normalmente será solo 1)
            const rewardsToDo = expectedRewards - this.rewardsGiven;
            
            for (let i = 0; i < rewardsToDo; i++) {
                await this.giveRewardsToAllUsers();
                this.rewardsGiven++;
            }
            
            this.lastRewardTime = Date.now();
            
        } catch (error) {
            console.error(chalk.red('[AutoReward] Error en checkAndReward:'), error.message);
        }
    }

    async giveRewardsToAllUsers() {
        try {
            if (!global.db || !global.db.data || !global.db.data.users) {
                console.error(chalk.red('[AutoReward] Base de datos no disponible'));
                return;
            }

            const users = global.db.data.users;
            let rewardedCount = 0;

            for (const [userId, userData] of Object.entries(users)) {
                try {
                    // Dar la recompensa a TODOS los usuarios
                    if (typeof userData.money !== 'number') {
                        userData.money = 0;
                    }
                    
                    userData.money += this.rewardAmount;
                    rewardedCount++;
                    
                } catch (error) {
                    console.error(chalk.red(`[AutoReward] Error procesando usuario ${userId}:`), error.message);
                }
            }

            // Guardar cambios en la base de datos
            if (global.db.save) {
                await global.db.save();
            }

            console.log(chalk.green(`💰 Recompensa de ${this.rewardAmount.toLocaleString()} entregada a ${rewardedCount} usuarios`));

        } catch (error) {
            console.error(chalk.red('[AutoReward] Error en giveRewardsToAllUsers:'), error.message);
        }
    }

    getStats() {
        return {
            uptime: this.getUptime(),
            uptimeFormatted: this.getUptimeFormatted(),
            rewardsGiven: this.rewardsGiven,
            rewardAmount: this.rewardAmount,
            rewardInterval: this.rewardInterval,
            nextRewardIn: this.rewardInterval - (this.getUptime() % this.rewardInterval),
            lastRewardTime: this.lastRewardTime
        };
    }
}

module.exports = AutoRewardSystem;
