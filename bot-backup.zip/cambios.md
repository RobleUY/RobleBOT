# Reorganización del sistema de activación/desactivación de subbots

Quiero aplicar esta lista de cambios al sistema actual de subbots.

---

# 1. Activar / desactivar respuestas del bot en chat privado

Agregar estos comandos equivalentes:

* `.bot priv si-no-on-off`
* `.bot privado si-no-on-off`
* `.bot private si-no-on-off`

Esto debe controlar **únicamente** si el subbot responde en chats privados.

---

# 2. Activar / desactivar respuestas del bot en grupos

Agregar estos comandos equivalentes:

* `.bot grupo si-no-on-off`
* `.bot grupos si-no-on-off`
* `.bot group si-no-on-off`
* `.bot groups si-no-on-off`

Esto debe controlar **únicamente** si el subbot responde en grupos.

---

# 3. Sistema global de encendido/apagado del subbot

Agregar un sistema para apagar o encender completamente el subbot en todos lados (privados + grupos).

## Comandos principales

* `.bot encender`
* `.bot apagar`
* `.bot on`
* `.bot off`

## También aceptar

* `.bot encender global`

* `.bot apagar global`

* `.bot on global`

* `.bot off global`

* `.bot encender g`

* `.bot apagar g`

* `.bot on g`

* `.bot off g`

---

# 4. Diferencia entre uso local y global

## Si NO usan `g` o `global`

El cambio debe aplicarse **solo al chat actual**, ya sea privado o grupo.

### Ejemplo

```txt
.bot apagar
```

→ desactiva el subbot únicamente en ese chat.

---

## Si usan `g` o `global`

El cambio debe aplicarse globalmente.

### Ejemplo

```txt
.bot apagar global
```

→ el subbot deja de responder en todos lados.

## Importante

Esto **NO debe modificar** configuraciones locales/manuales de chats específicos.

---

# 5. Reemplazar `offmybot` y `onmybot`

Eliminar el sistema viejo basado en:

* `offmybot`
* `onmybot`

Y hacer que funcionen como alias de:

* `.bot apagar`
* `.bot encender`

Para mantener compatibilidad con usuarios veteranos.

---

# 6. Persistencia de chats desactivados manualmente

## Caso importante

Si un usuario:

1. desactiva el bot en un chat específico
2. luego activa el bot globalmente

Entonces:

* los chats desactivados manualmente deben seguir desactivados
* no deben reactivarse automáticamente

## Importante

El mensaje del comando debe avisar claramente este comportamiento.

---

# 7. Mensajes informativos obligatorios

Cuando alguien active o desactive el bot, el mensaje debe explicar:

* cómo activar/desactivar globalmente
* cómo volver a activar el bot en ese chat
* diferencia entre local y global

## Ejemplo

```txt
Este chat quedó desactivado únicamente.
Para apagar el bot en todos lados usa: .bot apagar global
```

---

# 8. Cambio del sistema `.bot on/off/admins`

Actualmente:

* `.bot on`
* `.bot off`
* `.bot admins`

parecen afectar todos los bots.

## Nuevo comportamiento

`.bot` debe controlar **solo el subbot actual**.

Además:

* estos comandos solo pueden usarse desde el propio subbot

---

# 9. Nuevo comando `.bots`

Agregar comando separado:

* `.bots on`
* `.bots off`
* `.bots activar`
* `.bots desactivar`
* `.bots admins`

## Función

Debe:

* activar/desactivar/configurar modo solo admins para TODOS los bots del grupo
* funcionar únicamente en grupos

---

# 10. Permisos para `.bots`

El comando `.bots`:

* solo puede ser usado por admins del grupo

---

# 11. Diferencia final entre `.bot` y `.bots`

## `.bot`

* controla únicamente el subbot actual
* funciona solo desde el propio subbot

## `.bots`

* controla todos los bots del grupo
* solo puede ser usado por admins del grupo

---

# 12. Conflicto con el comando `.bots`

Actualmente existe un comando `.bots` que muestra la lista de bots.

## Cambio requerido

Quitar el alias `.bots` de esa función para evitar interferencias con el nuevo sistema de administración.

---

# 13. Separar funcionalidades en plugins independientes

Lo mejor sería crear plugins separados dentro de:

```txt
plugins/subbots
```

Para mantener mejor organización.

---

# Estructura propuesta

## `plugins/subbots/subbots-admins.js`

Encargado de:

* `.bots on`
* `.bots off`
* `.bots admins`

Además agregar:

```js
handler.admin = true
```

---

## `plugins/subbots/subbots-onoff.js`

Encargado de:

* lógica de `.bot on`
* lógica de `.bot off`
* activación/desactivación local/global del subbot

---

## `plugins/subbots/subbots-responder.js`

Encargado de:

* configurar si el subbot responde en privados
* configurar si responde en grupos

### Ejemplos

* `.bot priv on`
* `.bot grupo off`

Estos comandos solo pueden ser usados desde el propio subbot.

---

# Limpieza del sistema antiguo

Preferiría que:

* los plugins viejos relacionados a esta lógica sean eliminados
* también se eliminen los archivos de configuración antiguos de bots
* el handler se ajuste para usar únicamente la nueva lógica

---

# Reorganización recomendada

Actualmente veo archivos relacionados dentro de:

```txt
plugins/GRUPOS
```

Creo que lo mejor sería:

* borrar esa lógica vieja
* reemplazarla completamente por el nuevo sistema
* mover toda la lógica nueva a:

```txt
plugins/subbots
```

Para tener un sistema más limpio, mantenible y consistente.
