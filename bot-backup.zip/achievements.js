const ACHIEVEMENT_THRESHOLDS = {
  commands: [10, 50, 100, 500, 1000],
  work: [10, 50, 100, 300, 500],
  betting: [10, 50, 100, 500, 1000],
  daily: [1, 5, 10, 15, 25]
};

const ACHIEVEMENT_REWARDS = {
  commands: {
    10: { exp: 100, money: 5000 },
    50: { exp: 200, money: 15000 },
    100: { exp: 350, money: 30000 },
    500: { exp: 800, money: 75000 },
    1000: { exp: 1500, money: 150000 }
  },
  work: {
    10: { exp: 120, money: 8000 },
    50: { exp: 260, money: 22000 },
    100: { exp: 420, money: 42000 },
    300: { exp: 900, money: 100000 },
    500: { exp: 1700, money: 200000 }
  },
  betting: {
    10: { exp: 130, money: 10000 },
    50: { exp: 280, money: 25000 },
    100: { exp: 480, money: 45000 },
    500: { exp: 950, money: 110000 },
    1000: { exp: 1800, money: 220000 }
  },
  daily: {
    1: { exp: 80, money: 7000 },
    5: { exp: 160, money: 15000 },
    10: { exp: 320, money: 30000 },
    15: { exp: 520, money: 50000 },
    25: { exp: 900, money: 90000 }
  }
};

const ACHIEVEMENT_LABELS = {
  commands: 'Comandos ejecutados',
  work: 'Trabajos completados',
  betting: 'Apuestas realizadas',
  daily: 'Recompensas diarias'
};

const ACHIEVEMENT_EMOJIS = {
  commands: '⚡',
  work: '💼',
  betting: '🎲',
  daily: '🌞'
};

function createDefaultAchievementCategory() {
  return { total: 0, milestones: [] };
}

function createDefaultAchievements() {
  return {
    commands: createDefaultAchievementCategory(),
    work: createDefaultAchievementCategory(),
    betting: createDefaultAchievementCategory(),
    daily: createDefaultAchievementCategory()
  };
}

function ensureAchievements(user) {
  if (!user.achievements || typeof user.achievements !== 'object') {
    user.achievements = createDefaultAchievements();
  }

  for (const category of Object.keys(ACHIEVEMENT_THRESHOLDS)) {
    if (!user.achievements[category] || typeof user.achievements[category] !== 'object') {
      user.achievements[category] = createDefaultAchievementCategory();
    } else {
      if (typeof user.achievements[category].total !== 'number') {
        user.achievements[category].total = Number(user.achievements[category].total) || 0;
      }
      if (!Array.isArray(user.achievements[category].milestones)) {
        user.achievements[category].milestones = [];
      }
    }
  }

  return user;
}

function calculateLevel(exp = 0) {
  let level = 0;
  let xpRemaining = Number(exp) || 0;
  let xpForNext = 100 + level * 50;

  while (xpRemaining >= xpForNext) {
    xpRemaining -= xpForNext;
    level += 1;
    xpForNext = 100 + level * 50;
  }

  return {
    level,
    xpActual: xpRemaining,
    xpTotal: xpForNext,
    xpFaltante: xpForNext - xpRemaining
  };
}

function awardExperience(user, amount) {
  const xp = Number(amount) || 0;
  user.exp = (Number(user.exp) || 0) + xp;
  const levelInfo = calculateLevel(user.exp);
  user.level = levelInfo.level;
  return levelInfo;
}

function addAchievementProgress(user, category, increment = 1) {
  if (!category || !ACHIEVEMENT_THRESHOLDS[category]) return null;
  ensureAchievements(user);

  const categoryData = user.achievements[category];
  // increment puede ser 0 para solo chequear milestones sin sumar
  const inc = (increment === null || increment === undefined) ? 1 : Number(increment);
  categoryData.total = (Number(categoryData.total) || 0) + inc;

  const unlockedMessages = [];
  const thresholds = ACHIEVEMENT_THRESHOLDS[category];

  for (const threshold of thresholds) {
    if (categoryData.total >= threshold && !categoryData.milestones.includes(threshold)) {
      categoryData.milestones.push(threshold);
      categoryData.milestones.sort((a, b) => a - b);

      const reward = ACHIEVEMENT_REWARDS[category][threshold] || { exp: 0, money: 0 };
      awardExperience(user, reward.exp);
      user.money = (Number(user.money) || 0) + Number(reward.money || 0);

      unlockedMessages.push(
        `${ACHIEVEMENT_EMOJIS[category]} *Logro desbloqueado:* ${ACHIEVEMENT_LABELS[category]} ${threshold} veces.
+${reward.exp} XP
+$${(reward.money || 0).toLocaleString()}`
      );
    }
  }

  if (unlockedMessages.length === 0) return null;
  return unlockedMessages.join('\n');
}

function getAchievementSummary(user, category) {
  ensureAchievements(user);

  const buildCategoryBlock = (cat) => {
    const categoryData = user.achievements[cat];
    const total = Number(categoryData.total) || 0;
    const achieved = Array.isArray(categoryData.milestones) ? categoryData.milestones : [];
    const thresholds = ACHIEVEMENT_THRESHOLDS[cat] || [];
    const nextThreshold = thresholds.find((t) => !achieved.includes(t));

    let block = `${ACHIEVEMENT_EMOJIS[cat]} *${ACHIEVEMENT_LABELS[cat]}*
`;
    block += `Total: *${total}*
`;
    block += `Logros desbloqueados: *${achieved.length}/${thresholds.length}*
`;
    block += achieved.length > 0 ? `Completados: ${achieved.join(', ')}
` : 'Completados: ninguno\n';
    block += nextThreshold ? `Siguiente meta: *${nextThreshold}* (${Math.max(0, nextThreshold - total)} más)
` : 'Siguiente meta: *Todos completados* 🎉\n';
    block += `\n`;
    block += thresholds
      .map((threshold) => {
        const reached = achieved.includes(threshold);
        const progress = reached ? '✅' : `⬜ (${Math.max(0, threshold - total)} faltan)`;
        return ` ${progress} ${threshold}`;
      })
      .join('\n');

    return block;
  };

  if (category) {
    if (!ACHIEVEMENT_THRESHOLDS[category]) {
      return null;
    }
    return buildCategoryBlock(category);
  }

  return Object.keys(ACHIEVEMENT_THRESHOLDS)
    .map((cat) => buildCategoryBlock(cat))
    .join('\n━━━━━━━━━━━━━━━━━━━━━━\n\n');
}

module.exports = {
  createDefaultAchievements,
  ensureAchievements,
  calculateLevel,
  addAchievementProgress,
  getAchievementSummary
};
