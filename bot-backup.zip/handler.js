const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand } = require('./botStatsRecorder');
const botConfig = require('./config'); // ← cargar una sola vez, no en cada mensaje

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.regexCommands = []; // comandos con RegExp — se buscan en orden
        this.cooldowns = new Map();
        this.lastMessageId = new Map();
        this.processingMessages = new Set();
        
        this.COOLDOWN_TIME = 10000;
        this.DUPLICATE_WINDOW = 3000;
        
        this.MAX_COOLDOWNS = 300;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;

        this.cooldownWarned = new Map(); // usuarios a los que ya se les avisó del cooldown
        
        this.exemptFromCooldown = new Set([
            '59893900470',
            '59892099606',
            '14907833237384',
            '106502773850321'
        ]);
        
        this.noCooldownCommands = new Set([
            'ppt', 'piedra', 'papel', 'tijera', 
            'aceptar', 'rechazar', 'cancelar'
        ]);
        
        this.loadPlugins();
        
        // Guardar referencia al intervalo para poder limpiarlo al destruir
        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();
        
        if (this.cooldowns.size > 0) {
            const cutoff = now - this.COOLDOWN_TIME;
            for (const [key, time] of this.cooldowns.entries()) {
                if (time < cutoff) {
                    this.cooldowns.delete(key);
                    this.cooldownWarned.delete(key);
                }
            }
        }
        
        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        
        if (this.processingMessages.size > 10) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }
        
        if (global.gc) {
            global.gc();
        }
    }

    cleanId(id) {
        if (!id) return '';
        return id.split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    getCooldownKey(userId, chatId) {
        return `${this.cleanId(userId)}_${this.cleanId(chatId)}`;
    }

    isExemptFromCooldown(userId) {
        return this.exemptFromCooldown.has(this.cleanId(userId));
    }

    normalizeText(text) {
        return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;
        
        this.lastMessageId.set(messageId, Date.now());
        
        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        
        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        this.processingMessages.add(messageId);
        
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);
        
        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);
            
            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    const resolved = require.resolve(fullPath);
                    if (require.cache[resolved]) {
                        delete require.cache[resolved];
                    }
                    
                    const plugin = require(fullPath);
                    
                    if (plugin.command) {
                        if (typeof plugin === 'function') {
                            this.commands.set(plugin.command, {
                                command: plugin.command,
                                handler: plugin,
                                help: plugin.help || 'Sin descripción',
                                tags: plugin.tags || [],
                                group: plugin.group || false,
                                owner: plugin.owner || false
                            });
                        } else {
                            this.commands.set(plugin.command, plugin);
                        }
                    }

                    if (plugin.textReplyHandler) {
                        this.commands.set('__textReplyHandler__' + fullPath, {
                            handler: plugin.textReplyHandler,
                            isTextReplyHandler: true,
                            all: true,
                            filePath: fullPath
                        });
                    }
                    
                    if (plugin.reactionHandler) {
                        this.commands.set('__reaction__' + fullPath, { 
                            handler: plugin.reactionHandler, 
                            isReactionHandler: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    if (plugin.imageCollector) {
                        this.commands.set('__imageCollector__' + fullPath, { 
                            handler: plugin.imageCollector, 
                            isImageCollector: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    for (const [key, value] of Object.entries(plugin)) {
                        if (key !== 'command' && key !== 'handler' && key !== 'help' && 
                            key !== 'tags' && key !== 'textReplyHandler' && 
                            key !== 'reactionHandler' && key !== 'imageCollector' && 
                            value?.command) {
                            this.commands.set(value.command, value);
                        }
                    }
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                const resolved = require.resolve(fullPath);
                
                if (require.cache[resolved]) {
                    delete require.cache[resolved];
                }
                
                const plugin = require(fullPath);
                
                for (const [cmd, command] of this.commands.entries()) {
                    if (command.filePath === fullPath) {
                        this.commands.delete(cmd);
                    }
                }
                
                if (plugin.command) {
                    const commandData = typeof plugin === 'function' ? {
                        command: plugin.command,
                        handler: plugin,
                        help: plugin.help || 'Sin descripción',
                        tags: plugin.tags || [],
                        group: plugin.group || false,
                        owner: plugin.owner || false,
                        filePath: fullPath
                    } : { ...plugin, filePath: fullPath };
                    
                    this.commands.set(plugin.command, commandData);
                }

                if (plugin.textReplyHandler) {
                    this.commands.set('__textReplyHandler__' + fullPath, {
                        handler: plugin.textReplyHandler,
                        isTextReplyHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.reactionHandler) {
                    this.commands.set('__reaction__' + fullPath, {
                        handler: plugin.reactionHandler,
                        isReactionHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.imageCollector) {
                    this.commands.set('__imageCollector__' + fullPath, {
                        handler: plugin.imageCollector,
                        isImageCollector: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;
        // Incluir el número del bot activo en la clave para evitar que el duplicate-check
        // del bot principal bloquee al subbot o viceversa (race condition entre bots)
        const activeBotNum = global.conn?.user?.id?.split('@')[0]?.split(':')[0] || 'unknown';
        const dedupKey = `${activeBotNum}:${messageId}`;
        
        if (!global.conn || !global.conn.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }
        
        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }
        
        this.startProcessing(dedupKey);
        
        try {
            const wrappedMessage = message;
            
            const prefixes = ['.', '/', '❤️', '#', '👅'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }
            
            const userId = message.author || message.sender;
            const chatId = message.from;
            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);

            if (global.plugins?.get('baneos')?.isUserBanned(cleanUserId)) {
                this.finishProcessing(dedupKey);
                return;
            }

            // 🌟 CORRECCIÓN CLAVE: Ejecutar textReplyHandler/imageCollector/all si NO es una reacción y hay texto
            if (!isReaction && typeof text === 'string' && text !== '') {
                for (const [cmd, command] of this.commands) {
                    // Ejecutar handlers que no dependen de un comando con prefijo
                    if ((command.isImageCollector || command.isTextReplyHandler || command.all) && 
                        typeof command.handler === 'function' && 
                        !command.isReactionHandler && 
                        !command.command) { // Asegura que no se ejecuten comandos regulares aquí
                        try {
                            // El handler de "wao" (textReplyHandler) verificará si el texto es "wao" y si hay cita.
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error(`Error handler all (${cmd}):`, error.message);
                        }
                    }
                }
            }

            // REACCIONES
            if (isReaction) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler && command.all) {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error('Error reaction handler:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }
            
            if (typeof text !== 'string' || text === '') {
                // Si no hay texto, solo ejecutar AntiLink si aplica y terminar.
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                
                this.finishProcessing(dedupKey);
                return;
            }
            
            const usedPrefix = prefixes.find(p => text.startsWith(p));
            if (!usedPrefix) {
                // Si hay texto, pero NO hay prefijo, el 'wao' ya se ejecutó arriba.
                // Solo necesitamos ejecutar AntiLink y terminar.
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                
                this.finishProcessing(dedupKey);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            // Buscar primero en comandos string (O(1))
            let matchedCommand = this.commands.get(normalizedCommandName);

            // Si no, buscar en regex (lineal pero solo sobre los regex)
            if (!matchedCommand) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler || command.isImageCollector || command.isTextReplyHandler) continue;
                    if (cmd instanceof RegExp && cmd.test(commandName)) {
                        matchedCommand = command;
                        break;
                    }
                }
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const cleanAuthor = this.cleanId(message.author);
                const isOwner = botConfig.isOwner(cleanAuthor) || 
                                botConfig.isOwner(`${cleanAuthor}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                // 🔒 En grupos, requerir apodo para usar cualquier comando (excepto .apodo)
                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    let senderUser = null;
                    try { senderUser = global.db?.getUser?.(senderNumber); } catch (_) {}
                    const apodo = (senderUser?.apodo || '').trim().toLowerCase();
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                const skipCooldown = this.isExemptFromCooldown(cleanUserId) || 
                                     this.noCooldownCommands.has(normalizedCommandName);
                
                if (!skipCooldown) {
                    const cooldownKey = this.getCooldownKey(userId, chatId);
                    const lastCommandTime = this.cooldowns.get(cooldownKey) || 0;
                    const now = Date.now();
                    const timeLeft = lastCommandTime + this.COOLDOWN_TIME - now;

                    if (timeLeft > 0) {
                        // Solo avisar una vez por período de cooldown
                        if (!this.cooldownWarned.has(cooldownKey)) {
                            this.cooldownWarned.set(cooldownKey, true);
                            await wrappedMessage.reply(`⏳ Espera ${(timeLeft / 1000).toFixed(1)}s antes de usar otro comando.`);
                        }
                        this.finishProcessing(dedupKey);
                        return;
                    }

                    // Cooldown expiró, limpiar el aviso
                    this.cooldownWarned.delete(cooldownKey);
                    this.cooldowns.set(cooldownKey, now);
                }

                const commandParams = { 
                    text: fullText, 
                    args, 
                    conn: global.conn,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                                        (typeof command === 'function' ? command : null);
                
                if (handlerFunction) {
                    try {
                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;
                        try { recordCommand(userId); } catch (_) {}
                        // Sumar XP al usuario por usar un comando
                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser(userNum);
                            if (userData) {
                                userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;
                                global.db.save();
                            }
                        } catch (_) {}
                    } catch (error) {
                        // 🛡️ Manejo especial de errores comunes
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';
                        
                        // Rate limit (429) - WhatsApp está bloqueando por demasiadas peticiones
                        if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                            // No enviar mensaje de error, es temporal
                        }
                        // Permisos de grupo (403) - Solo loguear, no crashear
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            // No loguear si es un error temporal de red
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                            // No enviar mensaje de error - puede ser temporal
                        }
                        // Conexión cerrada
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        // Otros errores - mostrar al usuario
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => {});
                        }
                    }
                }
                
                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }
            
            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;
