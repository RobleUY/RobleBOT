const fs = require('fs'); //asd
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand, updateStatsMeta } = require('./botStatsRecorder');
const achievements = require('./achievements');
const botConfig = require('./config');

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.textReplyHandlers = [];
        this.reactionHandlers = [];
        this.imageCollectors = [];
        this.regexCommands = [];
        this.lastMessageId = new Map();
        this.processingMessages = new Set();

        this.cooldowns = new Map();
        this.COOLDOWN_MS = 5000;

        this.DUPLICATE_WINDOW = 3000;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;

        // ── Anti-automatización ──────────────────────────────────────────────
        // Contador de comandos por usuario (solo en memoria, se resetea al reiniciar)
        this.cmdCount      = new Map(); // userId → número de comandos
        this.pendingVerify = new Map(); // userId → código pendiente (string)
        this.CMD_LIMIT     = 50;       // comandos antes de pedir verificación
        // ────────────────────────────────────────────────────────────────────

        // ── Invitación al canal de WhatsApp ──────────────────────────────────
        this.inviteCommandCount = new Map(); // userId → número de comandos usados
        this.inviteTarget       = new Map(); // userId → meta de comandos para mostrar aviso
        // ────────────────────────────────────────────────────────────────────

        this.loadPlugins();

        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();

        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        if (this.processingMessages.size > 10) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }

        for (const [userId, data] of this.cooldowns.entries()) {
            if (now - data.lastCommandTime >= this.COOLDOWN_MS) {
                this.cooldowns.delete(userId);
            }
        }

        if (global.gc) {
            global.gc();
        }
    }

    cleanId(id) {
        if (!id) return '';
        return id.split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    normalizeText(text) {
        return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;

        this.lastMessageId.set(messageId, Date.now());

        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        this.processingMessages.add(messageId);
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    // ── Anti-automatización helpers ──────────────────────────────────────────

    /** Genera un código numérico aleatorio de 4 dígitos */
    generateVerifyCode() {
        return String(Math.floor(1000 + Math.random() * 9000));
    }

    /** Devuelve true si el userId es owner según config */
    isOwnerUser(userId) {
        const clean = this.cleanId(userId);
        return botConfig.isOwner(clean) || botConfig.isOwner(`${clean}@s.whatsapp.net`);
    }

    /**
     * Incrementa el contador de comandos del usuario.
     * Si llega al límite, genera un código y devuelve { blocked: true, code }.
     * Si ya está bloqueado, devuelve { blocked: true, alreadyNotified: true }.
     * Si no llega al límite, devuelve { blocked: false }.
     */
    checkAntiAutomation(userId) {
        // Todos los usuarios son afectados (owners incluidos)
        // Para excluir owners en el futuro, descomentar la línea de abajo:
        // if (this.isOwnerUser(userId)) return { blocked: false };

        // Ya está pendiente de verificación
        if (this.pendingVerify.has(userId)) {
            return { blocked: true, alreadyNotified: true };
        }

        const count = (this.cmdCount.get(userId) || 0) + 1;
        this.cmdCount.set(userId, count);

        if (count >= this.CMD_LIMIT) {
            const code = this.generateVerifyCode();
            this.pendingVerify.set(userId, code);
            this.cmdCount.delete(userId); // resetear contador
            return { blocked: true, alreadyNotified: false, code };
        }

        return { blocked: false };
    }

    /** Verifica el código. Devuelve true si es correcto y elimina el bloqueo. */
    verifyOnlineCode(userId, inputCode) {
        const expected = this.pendingVerify.get(userId);
        if (!expected) return false; // no estaba bloqueado
        if (expected === String(inputCode).trim()) {
            this.pendingVerify.delete(userId);
            this.cmdCount.delete(userId);
            return true;
        }
        return false;
    }

    // ────────────────────────────────────────────────────────────────────────

    checkCooldown(userId) {
        const now = Date.now();
        const data = this.cooldowns.get(userId);

        if (!data) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        const elapsed = now - data.lastCommandTime;

        if (elapsed >= this.COOLDOWN_MS) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        if (!data.warningSent) {

            data.warningSent = true;
            return { onCooldown: true, shouldWarn: true, remaining: Math.ceil((this.COOLDOWN_MS - elapsed) / 1000) };
        }

        return { onCooldown: true, shouldWarn: false };
    }

    registerPluginCommand(commandKey, commandData) {
        if (!commandKey || !commandData) return;

        this.commands.set(commandKey, commandData);

        if (commandData.isTextReplyHandler) {
            this.textReplyHandlers.push(commandData);
        }

        if (commandData.isReactionHandler) {
            this.reactionHandlers.push(commandData);
        }

        if (commandData.isImageCollector) {
            this.imageCollectors.push(commandData);
        }
    }

    clearPluginCommands(filePath) {
        for (const [key, command] of [...this.commands.entries()]) {
            if (command.filePath === filePath) {
                this.commands.delete(key);
            }
        }

        this.textReplyHandlers = this.textReplyHandlers.filter(cmd => cmd.filePath !== filePath);
        this.reactionHandlers = this.reactionHandlers.filter(cmd => cmd.filePath !== filePath);
        this.imageCollectors = this.imageCollectors.filter(cmd => cmd.filePath !== filePath);
    }

    loadPlugin(fullPath) {
        const resolved = require.resolve(fullPath);
        if (require.cache[resolved]) {
            delete require.cache[resolved];
        }

        const plugin = require(fullPath);
        this.clearPluginCommands(fullPath);

        if (plugin.command) {
            const commandData = typeof plugin === 'function' ? {
                command: plugin.command,
                handler: plugin,
                help: plugin.help || 'Sin descripción',
                tags: plugin.tags || [],
                group: plugin.group || false,
                owner: plugin.owner || false,
                filePath: fullPath
            } : { ...plugin, filePath: fullPath };

            this.registerPluginCommand(plugin.command, commandData);
        }

        if (plugin.textReplyHandler) {
            this.registerPluginCommand('__textReplyHandler__' + fullPath, {
                handler: plugin.textReplyHandler,
                isTextReplyHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.reactionHandler) {
            this.registerPluginCommand('__reaction__' + fullPath, {
                handler: plugin.reactionHandler,
                isReactionHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.imageCollector) {
            this.registerPluginCommand('__imageCollector__' + fullPath, {
                handler: plugin.imageCollector,
                isImageCollector: true,
                all: true,
                filePath: fullPath
            });
        }

        for (const [key, value] of Object.entries(plugin)) {
            if (key !== 'command' && key !== 'handler' && key !== 'help' &&
                key !== 'tags' && key !== 'textReplyHandler' &&
                key !== 'reactionHandler' && key !== 'imageCollector' &&
                value?.command) {
                const commandData = typeof value === 'function' ? {
                    command: value.command,
                    handler: value,
                    help: value.help || [],
                    tags: value.tags || [],
                    group: value.group || false,
                    owner: value.owner || false,
                    filePath: fullPath
                } : { ...value, filePath: fullPath };

                this.registerPluginCommand(value.command, commandData);
            }
        }
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);

        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    this.loadPlugin(fullPath);
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error && error.stack ? error.stack : error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                
                // La función loadPlugin ya maneja la limpieza del caché y comandos anteriores
                this.loadPlugin(fullPath);
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            this.textReplyHandlers = [];
            this.reactionHandlers = [];
            this.imageCollectors = [];

            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;

        // Usar _subNum del mensaje (asignado por subbot-serbot) en vez de global.conn
        // para evitar condiciones de carrera cuando múltiples subbots procesan en paralelo.
        const botId = message._subNum ? `sub${message._subNum}` : 'main';
        const chatId = message.from || message.key?.remoteJid;
        const dedupKey = `${botId}:${chatId}:${messageId}`;

        // Verificar el socket correcto: el del mensaje si es subbot, global.conn si es principal
        const activeSock = message._sock || global.conn;
        if (!activeSock || !activeSock.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }

        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }

        this.startProcessing(dedupKey);

        try {
            const wrappedMessage = message;

            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }

            const userId = message.author || message.sender;
            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);

            // ── Moderación automática de imágenes (solo grupo específico) ────────
            const MODERAR_GRUPO = '120363203689229697@g.us';
            if (isGroup && chatId === MODERAR_GRUPO) {
                // El mimetype y la imagen viven en _baileyMessage.message.imageMessage
                const baileyMsgImg = message._baileyMessage;
                const imageMsg = baileyMsgImg?.message?.imageMessage ||
                                 baileyMsgImg?.message?.viewOnceMessage?.message?.imageMessage ||
                                 baileyMsgImg?.message?.viewOnceMessageV2?.message?.imageMessage;
                const mime = imageMsg?.mimetype || '';
                const esImagen = !!imageMsg || /^image\//.test(mime);

          

                if (esImagen) {
                    console.log(chalk.cyan(`[MOD-IMG] 🚀 Iniciando análisis en background...`));

                    setImmediate(async () => {
                        try {
                            const axios = require('axios');
                            const FormData = require('form-data');
                            const { downloadMediaMessage } = require('@whiskeysockets/baileys');
                            const sock = message._sock || global.conn;

                            // 1. Descargar imagen usando baileys directo
                            console.log(chalk.cyan(`[MOD-IMG] ⬇️  Descargando imagen...`));
                            let imgBuffer;
                            try {
                                // Intentar primero con message.download() del wrapper
                                if (typeof message.download === 'function') {
                                    imgBuffer = await message.download();
                                }
                                // Si no funcionó o devolvió vacío, usar baileys directo
                                if (!imgBuffer || imgBuffer.length < 100) {
                                    imgBuffer = await downloadMediaMessage(baileyMsgImg, 'buffer', {});
                                }
                                console.log(chalk.cyan(`[MOD-IMG] ✅ Descargada (${(imgBuffer.length / 1024).toFixed(1)} KB)`));
                            } catch (dlErr) {
                                console.error(chalk.yellow(`[MOD-IMG] ⚠️  Fallo descarga, imagen pasa. Error: ${dlErr.message}`));
                                return;
                            }

                            // 2. Subir a ImgBB
                            console.log(chalk.cyan(`[MOD-IMG] ☁️  Subiendo a ImgBB...`));
                            let imageUrl;
                            try {
                                const form = new FormData();
                                form.append('image', imgBuffer, { filename: 'image.jpg' });
                                const uploadRes = await axios.post(
                                    'https://api.imgbb.com/1/upload?key=4ce3fe016a9c978bf9c8cba581c22bd3',
                                    form,
                                    { headers: form.getHeaders(), timeout: 15000 }
                                );
                                imageUrl = uploadRes.data.data.url;
                                console.log(chalk.cyan(`[MOD-IMG] ✅ Subida OK → ${imageUrl}`));
                            } catch (upErr) {
                                console.error(chalk.yellow(`[MOD-IMG] ⚠️  Fallo ImgBB, imagen pasa. Error: ${upErr.message}`));
                                return;
                            }

                            // 3. Analizar con IA
                            console.log(chalk.cyan(`[MOD-IMG] 🤖 Analizando imagen con IA...`));
                            let resultado;
                            try {
                                const query = encodeURIComponent('¿Esta imagen contiene contenido inapropiado, sexual, violento, gore, desnudos o explícito? Responde SOLO con SI o NO.');
                                const apiUrl = `https://api.delirius.store/ia/visual?image=${encodeURIComponent(imageUrl)}&query=${query}`;
                                const { data } = await axios.get(apiUrl, { timeout: 20000 });
                                resultado = data?.data?.result || '';
                                console.log(chalk.cyan(`[MOD-IMG] 🤖 Respuesta IA: "${resultado}"`));
                            } catch (apiErr) {
                                console.error(chalk.yellow(`[MOD-IMG] ⚠️  Fallo API IA, imagen pasa. Error: ${apiErr.message}`));
                                return;
                            }

                            // 4. Decidir
                            const confirmaInapropiado = /^(s[íi]|si[,. ])/i.test(resultado.trim()) || resultado.trim().toUpperCase().startsWith('SI');

                            if (confirmaInapropiado) {
                                console.log(chalk.red(`[MOD-IMG] 🚫 IMAGEN NO APTA — eliminando...`));
                                console.log(chalk.red(`[MOD-IMG] 👤 Enviada por: ${cleanUserId}`));
                                try {
                                    const msgKey = baileyMsgImg?.key || message.key || {
                                        remoteJid: chatId,
                                        id: message.id || messageId,
                                        participant: userId,
                                        fromMe: false
                                    };
                                    await sock.sendMessage(chatId, { delete: msgKey });
                                    console.log(chalk.red(`[MOD-IMG] ✅ Imagen eliminada exitosamente`));
                                } catch (delErr) {
                                    console.error(chalk.red(`[MOD-IMG] ❌ Error al eliminar: ${delErr.message}`));
                                }
                            } else {
                                console.log(chalk.green(`[MOD-IMG] ✅ IMAGEN APROBADA — contenido limpio`));
                            }
                            console.log(chalk.magenta(`[MOD-IMG] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`));

                        } catch (modErr) {
                            console.error(chalk.yellow(`[MOD-IMG] ⚠️  Error general, imagen pasa: ${modErr.message}`));
                            console.log(chalk.magenta(`[MOD-IMG] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`));
                        }
                    });
                } else {
                    
                }
            }
            // ────────────────────────────────────────────────────────────────────

            try {
                const banModule = require('./plugins/baneados.js');
                if (banModule && typeof banModule.isUserBanned === 'function') {
                    const groupId = isGroup ? chatId : null;
                    if (banModule.isUserBanned(cleanUserId, groupId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            } catch (banError) {

            }

            // ── Check nivel grupo: .bots on/off/admins (subbots-admins.js) ─────────
            // Se saltea si es el subbot fallback del grupo oficial (responde siempre)
            if (isGroup && !(message._isOfficialGroupFallback)) {
                try {
                    const botsAdminsModule = require('./plugins/SUBBOTS/subbots-admins.js');
                    if (botsAdminsModule && typeof botsAdminsModule.isBotEnabled === 'function') {
                        const botStatus = botsAdminsModule.isBotEnabled(chatId);

                        if (botStatus === false) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^bots$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }

                        if (botStatus === 'admins') {
                            try {
                                // Solo intentar si el bot principal tiene sesión activa
                                if (!global.conn?.user) throw new Error('Bot principal sin sesión');
                                const groupMetadata = await global.conn.groupMetadata(chatId);
                                const userParticipant = groupMetadata.participants.find(p => {
                                    const participantNumber = p.id.split('@')[0].split(':')[0];
                                    return participantNumber === cleanUserId;
                                });

                                const isAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

                                if (!isAdmin) {
                                    const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                                    const usedPrefix = prefixes.find(p => text.startsWith(p));
                                    if (usedPrefix) {
                                        const commandText = text.slice(usedPrefix.length).trim();
                                        const [commandName] = commandText.split(' ');
                                        if (!/^bots$/i.test(commandName)) {
                                            this.finishProcessing(dedupKey);
                                            return;
                                        }
                                    } else {
                                        this.finishProcessing(dedupKey);
                                        return;
                                    }
                                }
                            } catch (metadataError) {
                                // Si falla por falta de sesión del principal, dejar pasar (subbot cubre)
                            }
                        }
                    }
                } catch (botOnOffError) {
                    console.error('[Handler-GroupCheck] Error:', botOnOffError.message);
                }
            }

            // ── Check nivel subbot: subbots-onoff.js (local/global) + responder ────
            if (activeSock._subNum) {
                try {
                    const subBotModule = require('./plugins/SUBBOTS/subbots-onoff.js');

                    // Si es el fallback del grupo oficial, saltear todos los checks de on/off
                    // (el subbot responde siempre ahí cuando el principal no tiene sesión)
                    const isFallback = !!(message._isOfficialGroupFallback);

                    // Check si el subbot responde en privados
                    if (!isFallback && !isGroup && typeof subBotModule.isSubBotRespondsInPriv === 'function') {
                        if (!subBotModule.isSubBotRespondsInPriv(activeSock._subNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Check si el subbot responde en grupos
                    if (!isFallback && isGroup && typeof subBotModule.isSubBotRespondsInGrupos === 'function') {
                        if (!subBotModule.isSubBotRespondsInGrupos(activeSock._subNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Check encendido/apagado local y global del subbot
                    if (!isFallback && typeof subBotModule.isSubBotEnabled === 'function') {
                        const subBotEnabled = subBotModule.isSubBotEnabled(chatId, activeSock._subNum);

                        if (!subBotEnabled) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                // Permitir solo .bot, .onmybot y .bots
                                if (!/^(bot|onmybot|bots)$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }
                    }
                } catch (subBotError) {
                    console.error('[Handler-SubbotCheck] Error:', subBotError.message);
                }
            }

            if (!isReaction && typeof text === 'string' && text !== '') {
                const allHandlers = [...this.textReplyHandlers, ...this.imageCollectors];
                for (const command of allHandlers) {
                    if (typeof command.handler === 'function') {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error(`Error handler all (${command.filePath || 'unknown'}):`, error.message);
                        }
                    }
                }
            }

            if (isReaction) {
                for (const command of this.reactionHandlers) {
                    if (command.all && typeof command.handler === 'function') {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error('Error reaction handler:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            if (typeof text !== 'string' || text === '') {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            const usedPrefix = prefixes.find(p => text.startsWith(p));
            if (!usedPrefix) {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            let matchedCommand = this.commands.get(normalizedCommandName);

            if (!matchedCommand) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler || command.isImageCollector || command.isTextReplyHandler) continue;
                    if (cmd instanceof RegExp && cmd.test(commandName)) {
                        matchedCommand = command;
                        break;
                    }
                }
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const cleanAuthor = this.cleanId(message.author);
                const isOwner = botConfig.isOwner(cleanAuthor) || 
                                botConfig.isOwner(`${cleanAuthor}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    let senderUser = null;
                    try { senderUser = global.db?.getUser?.(senderNumber); } catch (_) {}
                    const apodo = (senderUser?.apodo || '').trim().toLowerCase();
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                if (!isOwner) {
                    const cooldownResult = this.checkCooldown(cleanUserId);

                    if (cooldownResult.onCooldown) {
                        if (cooldownResult.shouldWarn) {
                            await wrappedMessage.reply(
                                `⏳ Vas muy rápido. Espera *${cooldownResult.remaining}s* antes de usar otro comando.`
                            ).catch(() => {});
                        }

                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                // ── Anti-automatización ──────────────────────────────────────
                // Permitir siempre el comando /online aunque el usuario esté bloqueado
                const isOnlineCmd = /^online$/i.test(commandName);
                if (!isOnlineCmd) {
                    const antiAuto = this.checkAntiAutomation(cleanUserId);
                    if (antiAuto.blocked) {
                        if (!antiAuto.alreadyNotified) {
                            // Primera vez que se bloquea: avisar con el código
                            await wrappedMessage.reply(
                                `🤖 *Verificación anti-automatización*\n\n` +
                                `Has ejecutado muchos comandos seguidos.\n` +
                                `Para confirmar que eres una persona real, usa:\n\n` +
                                `*/online ${antiAuto.code}*\n\n` +
                                `⚠️ Hasta que no lo hagas, tus comandos no serán procesados.`
                            ).catch(() => {});
                        }
                        // Si ya fue notificado, simplemente ignorar sin responder
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
                // ── Lógica de invitación al canal de WhatsApp ───────────────────────
                if (!this.inviteTarget.has(cleanUserId)) {
                    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 11) + 20); // 20 a 30 inclusive
                }
                const targetCount = this.inviteTarget.get(cleanUserId);
                const currentCount = (this.inviteCommandCount.get(cleanUserId) || 0) + 1;
                this.inviteCommandCount.set(cleanUserId, currentCount);

                let appendFooter = false;
                if (currentCount >= targetCount) {
                    appendFooter = true;
                    this.inviteCommandCount.set(cleanUserId, 0);
                    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 11) + 20);
                }

                let connToUse = message._sock || global.conn;
                if (appendFooter) {
                    const originalReply = wrappedMessage.reply.bind(wrappedMessage);
                    wrappedMessage.reply = async function (text, options = {}) {
                        if (typeof text === 'string') {
                            const footer = '\n\n_Recuerda unirte a nuestro canal de WhatsApp_\nhttps://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
                            if (!text.includes('whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q')) {
                                text = text + footer;
                            }
                        }
                        return originalReply(text, options);
                    };

                    const originalSendMessage = connToUse.sendMessage.bind(connToUse);
                    connToUse = Object.create(connToUse);
                    connToUse.sendMessage = async function (jid, content, options = {}) {
                        if (content && typeof content.text === 'string') {
                            const footer = '\n\n_Recuerda unirte a nuestro canal de WhatsApp_\nhttps://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
                            if (!content.text.includes('whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q')) {
                                content.text = content.text + footer;
                            }
                        }
                        return originalSendMessage(jid, content, options);
                    };
                }
                // ────────────────────────────────────────────────────────────────────

                const commandParams = { 
                    text: fullText, 
                    args, 
                    conn: connToUse,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                                        (typeof command === 'function' ? command : null);

                if (handlerFunction) {
                    try {
                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;

                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser?.(userNum);
                            const apodo = (userData?.apodo || '').trim() || userNum;
                            const pluginFile = command.filePath ? path.basename(command.filePath) : 'desconocido';
                            const fullCmd = fullText ? `${usedPrefix}${commandName} ${fullText}` : `${usedPrefix}${commandName}`;
                            console.log(chalk.cyan(`[CMD] ${fullCmd} - ${apodo} - ${pluginFile}`));
                        } catch (_) {}

                        try { recordCommand(userId, commandName); } catch (_) {}

                        // ── Trackear comandos del bot principal en el activity tracker ──
                        try {
                            if (!message._subNum) {
                                const activityTracker = require('./plugins/SUBBOTS/subbotActivityTracker');
                                activityTracker.recordActivity('main');
                            }
                        } catch (_) {}
                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser(userNum);
                            if (userData) {
                                // Incrementar contador de comandos
                                userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;

                                // Sincronizar achievements.commands.total con ComandosEjecutados
                                // para que .logros muestre el mismo número que .perfil
                                const { ensureAchievements } = achievements;
                                ensureAchievements(userData);
                                userData.achievements.commands.total = userData.ComandosEjecutados;

                                // Añadir progreso de logro por comandos (chequea milestones)
                                const achievementMessage = achievements.addAchievementProgress(userData, 'commands', 0);

                                // Otorgar XP aleatoria entre 1 y 2 por comando
                                const xpGain = Math.floor(Math.random() * 2) + 1; // 1 o 2
                                userData.exp = (Number(userData.exp) || 0) + xpGain;

                                // Actualizar nivel basado en la XP global
                                try {
                                    const levelInfo = achievements.calculateLevel(userData.exp || 0);
                                    userData.level = levelInfo.level;
                                } catch (_) {}

                                // Guardar cambios y notificar logro si aplica
                                global.db.save();
                                if (achievementMessage) {
                                    await wrappedMessage.reply(achievementMessage).catch(() => {});
                                }
                            }
                        } catch (_) {}
                    } catch (error) {
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';

                        // 🚨 ENOSPC: sin espacio en disco — limpiar temporales inmediatamente
                        if (errorMsg.includes('ENOSPC') || error?.code === 'ENOSPC') {
                            console.error(chalk.red(`[ENOSPC] Sin espacio en disco en comando ${commandName}. Activando limpieza de emergencia...`));
                            try {
                                const { tempCleaner } = require('./tempCleaner');
                                tempCleaner.emergencyCleanup().then(result => {
                                    console.log(chalk.green(`[ENOSPC] Limpieza completada: ${result.cleaned} archivos borrados`));
                                }).catch(e => {
                                    console.error('[ENOSPC] Error en limpieza de emergencia:', e.message);
                                });
                            } catch (cleanErr) {
                                console.error('[ENOSPC] No se pudo importar tempCleaner:', cleanErr.message);
                            }
                            await wrappedMessage.reply('⚠️ Error temporal de espacio en disco. Limpiando automáticamente...').catch(() => {});
                        }
                        else if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                        }
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                        }
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => {});
                        }
                    }
                }

                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }

            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;