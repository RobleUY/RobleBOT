const fs = require('fs'); //asd
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand } = require('./botStatsRecorder');
const { recordPluginUse } = require('./pluginStatsRecorder');
const botConfig = require('./config');

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.textReplyHandlers = [];
        this.reactionHandlers = [];
        this.imageCollectors = [];
        this.regexCommands = [];
        this.lastMessageId = new Map();
        this.processingMessages = new Set();

        this.cooldowns = new Map();
        this.COOLDOWN_MS = 5000;

        this.DUPLICATE_WINDOW = 3000;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;

        // ── Anti-automatización ──────────────────────────────────────────────
        // Contador de comandos por usuario (solo en memoria, se resetea al reiniciar)
        this.cmdCount      = new Map(); // userId → número de comandos
        this.pendingVerify = new Map(); // userId → código pendiente (string)
        this.CMD_LIMIT     = 50;       // comandos antes de pedir verificación
        // ────────────────────────────────────────────────────────────────────

        this.loadPlugins();

        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();

        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        if (this.processingMessages.size > 10) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }

        for (const [userId, data] of this.cooldowns.entries()) {
            if (now - data.lastCommandTime >= this.COOLDOWN_MS) {
                this.cooldowns.delete(userId);
            }
        }

        if (global.gc) {
            global.gc();
        }
    }

    cleanId(id) {
        if (!id) return '';
        return id.split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    normalizeText(text) {
        return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;

        this.lastMessageId.set(messageId, Date.now());

        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        this.processingMessages.add(messageId);
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    // ── Anti-automatización helpers ──────────────────────────────────────────

    /** Genera un código numérico aleatorio de 4 dígitos */
    generateVerifyCode() {
        return String(Math.floor(1000 + Math.random() * 9000));
    }

    /** Devuelve true si el userId es owner según config */
    isOwnerUser(userId) {
        const clean = this.cleanId(userId);
        return botConfig.isOwner(clean) || botConfig.isOwner(`${clean}@s.whatsapp.net`);
    }

    /**
     * Incrementa el contador de comandos del usuario.
     * Si llega al límite, genera un código y devuelve { blocked: true, code }.
     * Si ya está bloqueado, devuelve { blocked: true, alreadyNotified: true }.
     * Si no llega al límite, devuelve { blocked: false }.
     */
    checkAntiAutomation(userId) {
        // Todos los usuarios son afectados (owners incluidos)
        // Para excluir owners en el futuro, descomentar la línea de abajo:
        // if (this.isOwnerUser(userId)) return { blocked: false };

        // Ya está pendiente de verificación
        if (this.pendingVerify.has(userId)) {
            return { blocked: true, alreadyNotified: true };
        }

        const count = (this.cmdCount.get(userId) || 0) + 1;
        this.cmdCount.set(userId, count);

        if (count >= this.CMD_LIMIT) {
            const code = this.generateVerifyCode();
            this.pendingVerify.set(userId, code);
            this.cmdCount.delete(userId); // resetear contador
            return { blocked: true, alreadyNotified: false, code };
        }

        return { blocked: false };
    }

    /** Verifica el código. Devuelve true si es correcto y elimina el bloqueo. */
    verifyOnlineCode(userId, inputCode) {
        const expected = this.pendingVerify.get(userId);
        if (!expected) return false; // no estaba bloqueado
        if (expected === String(inputCode).trim()) {
            this.pendingVerify.delete(userId);
            this.cmdCount.delete(userId);
            return true;
        }
        return false;
    }

    // ────────────────────────────────────────────────────────────────────────

    checkCooldown(userId) {
        const now = Date.now();
        const data = this.cooldowns.get(userId);

        if (!data) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        const elapsed = now - data.lastCommandTime;

        if (elapsed >= this.COOLDOWN_MS) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        if (!data.warningSent) {

            data.warningSent = true;
            return { onCooldown: true, shouldWarn: true, remaining: Math.ceil((this.COOLDOWN_MS - elapsed) / 1000) };
        }

        return { onCooldown: true, shouldWarn: false };
    }

    registerPluginCommand(commandKey, commandData) {
        if (!commandKey || !commandData) return;

        this.commands.set(commandKey, commandData);

        if (commandData.isTextReplyHandler) {
            this.textReplyHandlers.push(commandData);
        }

        if (commandData.isReactionHandler) {
            this.reactionHandlers.push(commandData);
        }

        if (commandData.isImageCollector) {
            this.imageCollectors.push(commandData);
        }
    }

    clearPluginCommands(filePath) {
        for (const [key, command] of [...this.commands.entries()]) {
            if (command.filePath === filePath) {
                this.commands.delete(key);
            }
        }

        this.textReplyHandlers = this.textReplyHandlers.filter(cmd => cmd.filePath !== filePath);
        this.reactionHandlers = this.reactionHandlers.filter(cmd => cmd.filePath !== filePath);
        this.imageCollectors = this.imageCollectors.filter(cmd => cmd.filePath !== filePath);
    }

    loadPlugin(fullPath) {
        const resolved = require.resolve(fullPath);
        if (require.cache[resolved]) {
            delete require.cache[resolved];
        }

        const plugin = require(fullPath);
        this.clearPluginCommands(fullPath);

        if (plugin.command) {
            const commandData = typeof plugin === 'function' ? {
                command: plugin.command,
                handler: plugin,
                help: plugin.help || 'Sin descripción',
                tags: plugin.tags || [],
                group: plugin.group || false,
                owner: plugin.owner || false,
                filePath: fullPath
            } : { ...plugin, filePath: fullPath };

            this.registerPluginCommand(plugin.command, commandData);
        }

        if (plugin.textReplyHandler) {
            this.registerPluginCommand('__textReplyHandler__' + fullPath, {
                handler: plugin.textReplyHandler,
                isTextReplyHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.reactionHandler) {
            this.registerPluginCommand('__reaction__' + fullPath, {
                handler: plugin.reactionHandler,
                isReactionHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.imageCollector) {
            this.registerPluginCommand('__imageCollector__' + fullPath, {
                handler: plugin.imageCollector,
                isImageCollector: true,
                all: true,
                filePath: fullPath
            });
        }

        for (const [key, value] of Object.entries(plugin)) {
            if (key !== 'command' && key !== 'handler' && key !== 'help' &&
                key !== 'tags' && key !== 'textReplyHandler' &&
                key !== 'reactionHandler' && key !== 'imageCollector' &&
                value?.command) {
                const commandData = typeof value === 'function' ? {
                    command: value.command,
                    handler: value,
                    help: value.help || [],
                    tags: value.tags || [],
                    group: value.group || false,
                    owner: value.owner || false,
                    filePath: fullPath
                } : { ...value, filePath: fullPath };

                this.registerPluginCommand(value.command, commandData);
            }
        }
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);

        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    this.loadPlugin(fullPath);
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error && error.stack ? error.stack : error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                this.loadPlugin(fullPath);
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            this.textReplyHandlers = [];
            this.reactionHandlers = [];
            this.imageCollectors = [];

            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;

        // Usar _subNum del mensaje (asignado por subbot-serbot) en vez de global.conn
        // para evitar condiciones de carrera cuando múltiples subbots procesan en paralelo.
        const botId = message._subNum ? `sub${message._subNum}` : 'main';
        const chatId = message.from || message.key?.remoteJid;
        const dedupKey = `${botId}:${chatId}:${messageId}`;

        // Verificar el socket correcto: el del mensaje si es subbot, global.conn si es principal
        const activeSock = message._sock || global.conn;
        if (!activeSock || !activeSock.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }

        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }

        this.startProcessing(dedupKey);

        try {
            const wrappedMessage = message;

            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }

            const userId = message.author || message.sender;
            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);

            try {
                const banModule = require('./plugins/baneados.js');
                if (banModule && typeof banModule.isUserBanned === 'function') {
                    const groupId = isGroup ? chatId : null;
                    if (banModule.isUserBanned(cleanUserId, groupId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            } catch (banError) {

            }

            if (isGroup) {
                try {
                    const botOnOffModule = require('./plugins/bot-on-off.js');
                    if (botOnOffModule && typeof botOnOffModule.isBotEnabled === 'function') {
                        const botStatus = botOnOffModule.isBotEnabled(chatId);

                        if (botStatus === false) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^bot$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }

                        if (botStatus === 'admins') {
                            try {
                                const groupMetadata = await global.conn.groupMetadata(chatId);
                                const userParticipant = groupMetadata.participants.find(p => {
                                    const participantNumber = p.id.split('@')[0].split(':')[0];
                                    return participantNumber === cleanUserId;
                                });

                                const isAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

                                if (!isAdmin) {
                                    const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                                    const usedPrefix = prefixes.find(p => text.startsWith(p));
                                    if (usedPrefix) {
                                        const commandText = text.slice(usedPrefix.length).trim();
                                        const [commandName] = commandText.split(' ');
                                        if (!/^bot$/i.test(commandName)) {
                                            this.finishProcessing(dedupKey);
                                            return;
                                        }
                                    } else {
                                        this.finishProcessing(dedupKey);
                                        return;
                                    }
                                }
                            } catch (metadataError) {

                            }
                        }
                    }
                } catch (botOnOffError) {

                }
            }

            if (isGroup && global.conn._subNum) {
                try {
                    const myBotModule = require('./plugins/GRUPOS/mybot-on-off.js');
                    if (myBotModule && typeof myBotModule.isMyBotEnabled === 'function') {
                        const myBotEnabled = myBotModule.isMyBotEnabled(chatId, global.conn._subNum);

                        if (!myBotEnabled) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^(onmybot)$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }
                    }
                } catch (myBotError) {

                }
            }

            if (!isReaction && typeof text === 'string' && text !== '') {
                const allHandlers = [...this.textReplyHandlers, ...this.imageCollectors];
                for (const command of allHandlers) {
                    if (typeof command.handler === 'function') {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error(`Error handler all (${command.filePath || 'unknown'}):`, error.message);
                        }
                    }
                }
            }

            if (isReaction) {
                for (const command of this.reactionHandlers) {
                    if (command.all && typeof command.handler === 'function') {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error('Error reaction handler:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            if (typeof text !== 'string' || text === '') {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            const usedPrefix = prefixes.find(p => text.startsWith(p));
            if (!usedPrefix) {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            let matchedCommand = this.commands.get(normalizedCommandName);

            if (!matchedCommand) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler || command.isImageCollector || command.isTextReplyHandler) continue;
                    if (cmd instanceof RegExp && cmd.test(commandName)) {
                        matchedCommand = command;
                        break;
                    }
                }
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const cleanAuthor = this.cleanId(message.author);
                const isOwner = botConfig.isOwner(cleanAuthor) || 
                                botConfig.isOwner(`${cleanAuthor}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    let senderUser = null;
                    try { senderUser = global.db?.getUser?.(senderNumber); } catch (_) {}
                    const apodo = (senderUser?.apodo || '').trim().toLowerCase();
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                if (!isOwner) {
                    const cooldownResult = this.checkCooldown(cleanUserId);

                    if (cooldownResult.onCooldown) {
                        if (cooldownResult.shouldWarn) {
                            await wrappedMessage.reply(
                                `⏳ Vas muy rápido. Espera *${cooldownResult.remaining}s* antes de usar otro comando.`
                            ).catch(() => {});
                        }

                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                // ── Anti-automatización ──────────────────────────────────────
                // Permitir siempre el comando /online aunque el usuario esté bloqueado
                const isOnlineCmd = /^online$/i.test(commandName);
                if (!isOnlineCmd) {
                    const antiAuto = this.checkAntiAutomation(cleanUserId);
                    if (antiAuto.blocked) {
                        if (!antiAuto.alreadyNotified) {
                            // Primera vez que se bloquea: avisar con el código
                            await wrappedMessage.reply(
                                `🤖 *Verificación anti-automatización*\n\n` +
                                `Has ejecutado muchos comandos seguidos.\n` +
                                `Para confirmar que eres una persona real, usa:\n\n` +
                                `*/online ${antiAuto.code}*\n\n` +
                                `⚠️ Hasta que no lo hagas, tus comandos no serán procesados.`
                            ).catch(() => {});
                        }
                        // Si ya fue notificado, simplemente ignorar sin responder
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
                // ────────────────────────────────────────────────────────────

                const commandParams = { 
                    text: fullText, 
                    args, 
                    conn: message._sock || global.conn,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                                        (typeof command === 'function' ? command : null);

                if (handlerFunction) {
                    try {
                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;

                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser?.(userNum);
                            const apodo = (userData?.apodo || '').trim() || userNum;
                            const pluginFile = command.filePath ? path.basename(command.filePath) : 'desconocido';
                            const fullCmd = fullText ? `${usedPrefix}${commandName} ${fullText}` : `${usedPrefix}${commandName}`;
                            console.log(chalk.cyan(`[CMD] ${fullCmd} - ${apodo} - ${pluginFile}`));
                        } catch (_) {}

                        try { recordCommand(userId); } catch (_) {}
                        try { recordPluginUse(command.filePath); } catch (_) {}
                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser(userNum);
                            if (userData) {
                                userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;
                                global.db.save();
                            }
                        } catch (_) {}
                    } catch (error) {
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';

                        if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                        }
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                        }
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => {});
                        }
                    }
                }

                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }

            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;