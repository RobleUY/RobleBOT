const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand } = require('./botStatsRecorder');
const botConfig = require('./config');

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.regexCommands = [];
        this.lastMessageId = new Map();
        this.processingMessages = new Set();
        
        // Cooldown global: userId -> { lastCommandTime, warningSent }
        this.cooldowns = new Map();
        this.COOLDOWN_MS = 5000;
        
        this.DUPLICATE_WINDOW = 3000;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;
        
        this.loadPlugins();
        
        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();
        
        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        
        if (this.processingMessages.size > 10) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }

        // Limpiar cooldowns expirados
        for (const [userId, data] of this.cooldowns.entries()) {
            if (now - data.lastCommandTime >= this.COOLDOWN_MS) {
                this.cooldowns.delete(userId);
            }
        }
        
        if (global.gc) {
            global.gc();
        }
    }

    cleanId(id) {
        if (!id) return '';
        return id.split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    normalizeText(text) {
        return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;
        
        this.lastMessageId.set(messageId, Date.now());
        
        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        
        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        this.processingMessages.add(messageId);
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    /**
     * Verifica si el usuario está en cooldown.
     * Retorna:
     *   - { onCooldown: false }                          → puede ejecutar
     *   - { onCooldown: true, shouldWarn: true }         → en cooldown, avisar (primera vez)
     *   - { onCooldown: true, shouldWarn: false }        → en cooldown, ya fue avisado
     */
    checkCooldown(userId) {
        const now = Date.now();
        const data = this.cooldowns.get(userId);

        if (!data) {
            // Sin cooldown previo: registrar y permitir
            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        const elapsed = now - data.lastCommandTime;

        if (elapsed >= this.COOLDOWN_MS) {
            // Cooldown expirado: renovar y permitir
            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        // Todavía en cooldown
        if (!data.warningSent) {
            // Primera vez que choca con el cooldown en este ciclo: avisar
            data.warningSent = true;
            return { onCooldown: true, shouldWarn: true, remaining: Math.ceil((this.COOLDOWN_MS - elapsed) / 1000) };
        }

        // Ya fue avisado: silencio
        return { onCooldown: true, shouldWarn: false };
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);
        
        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);
            
            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    const resolved = require.resolve(fullPath);
                    if (require.cache[resolved]) {
                        delete require.cache[resolved];
                    }
                    
                    const plugin = require(fullPath);
                    
                    if (plugin.command) {
                        if (typeof plugin === 'function') {
                            this.commands.set(plugin.command, {
                                command: plugin.command,
                                handler: plugin,
                                help: plugin.help || 'Sin descripción',
                                tags: plugin.tags || [],
                                group: plugin.group || false,
                                owner: plugin.owner || false,
                                filePath: fullPath
                            });
                        } else {
                            this.commands.set(plugin.command, { ...plugin, filePath: fullPath });
                        }
                    }

                    if (plugin.textReplyHandler) {
                        this.commands.set('__textReplyHandler__' + fullPath, {
                            handler: plugin.textReplyHandler,
                            isTextReplyHandler: true,
                            all: true,
                            filePath: fullPath
                        });
                    }
                    
                    if (plugin.reactionHandler) {
                        this.commands.set('__reaction__' + fullPath, { 
                            handler: plugin.reactionHandler, 
                            isReactionHandler: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    if (plugin.imageCollector) {
                        this.commands.set('__imageCollector__' + fullPath, { 
                            handler: plugin.imageCollector, 
                            isImageCollector: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    for (const [key, value] of Object.entries(plugin)) {
                        if (key !== 'command' && key !== 'handler' && key !== 'help' && 
                            key !== 'tags' && key !== 'textReplyHandler' && 
                            key !== 'reactionHandler' && key !== 'imageCollector' && 
                            value?.command) {
                            this.commands.set(value.command, { ...value, filePath: fullPath });
                        }
                    }
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                const resolved = require.resolve(fullPath);
                
                if (require.cache[resolved]) {
                    delete require.cache[resolved];
                }
                
                const plugin = require(fullPath);
                
                for (const [cmd, command] of this.commands.entries()) {
                    if (command.filePath === fullPath) {
                        this.commands.delete(cmd);
                    }
                }
                
                if (plugin.command) {
                    const commandData = typeof plugin === 'function' ? {
                        command: plugin.command,
                        handler: plugin,
                        help: plugin.help || 'Sin descripción',
                        tags: plugin.tags || [],
                        group: plugin.group || false,
                        owner: plugin.owner || false,
                        filePath: fullPath
                    } : { ...plugin, filePath: fullPath };
                    
                    this.commands.set(plugin.command, commandData);
                }

                if (plugin.textReplyHandler) {
                    this.commands.set('__textReplyHandler__' + fullPath, {
                        handler: plugin.textReplyHandler,
                        isTextReplyHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.reactionHandler) {
                    this.commands.set('__reaction__' + fullPath, {
                        handler: plugin.reactionHandler,
                        isReactionHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.imageCollector) {
                    this.commands.set('__imageCollector__' + fullPath, {
                        handler: plugin.imageCollector,
                        isImageCollector: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;
        
        // 🔑 DEDUPLICACIÓN GLOBAL: usar solo el messageId (sin prefijo de bot)
        // para que si el bot principal ya procesó el mensaje, los subbots no lo
        // vuelvan a procesar (y viceversa). Esto evita que ambos respondan al
        // mismo comando (ej: bot principal envía "creando sticker" y subbot envía el sticker).
        const dedupKey = messageId;
        
        if (!global.conn || !global.conn.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }
        
        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }
        
        this.startProcessing(dedupKey);
        
        try {
            const wrappedMessage = message;
            
            const prefixes = ['.', '/', '❤️', '#', '👅'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }
            
            const userId = message.author || message.sender;
            const chatId = message.from;
            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);

            // 🚫 Verificar si el usuario está baneado
            try {
                const banModule = require('./plugins/baneados.js');
                if (banModule && typeof banModule.isUserBanned === 'function') {
                    const groupId = isGroup ? chatId : null;
                    if (banModule.isUserBanned(cleanUserId, groupId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            } catch (banError) {
                // Si hay error cargando el módulo, continuar sin bloquear
            }

            // 🏠 Grupo oficial: solo responde el bot principal
            if (isGroup && global.conn._subNum) {
                try {
                    const config = require('./config.js');
                    if (config.isExclusiveGroup(chatId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                } catch (configError) {
                    const OFFICIAL_GROUP = '120363203689229697@g.us';
                    if (chatId === OFFICIAL_GROUP) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            }

            // 🤖 Verificar si el bot está habilitado en el grupo
            if (isGroup) {
                try {
                    const botOnOffModule = require('./plugins/bot-on-off.js');
                    if (botOnOffModule && typeof botOnOffModule.isBotEnabled === 'function') {
                        const botStatus = botOnOffModule.isBotEnabled(chatId);
                        
                        if (botStatus === false) {
                            const prefixes = ['.', '/', '❤️', '#', '👅'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^bot$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }
                        
                        if (botStatus === 'admins') {
                            try {
                                const groupMetadata = await global.conn.groupMetadata(chatId);
                                const userParticipant = groupMetadata.participants.find(p => {
                                    const participantNumber = p.id.split('@')[0].split(':')[0];
                                    return participantNumber === cleanUserId;
                                });
                                
                                const isAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                                
                                if (!isAdmin) {
                                    const prefixes = ['.', '/', '❤️', '#', '👅'];
                                    const usedPrefix = prefixes.find(p => text.startsWith(p));
                                    if (usedPrefix) {
                                        const commandText = text.slice(usedPrefix.length).trim();
                                        const [commandName] = commandText.split(' ');
                                        if (!/^bot$/i.test(commandName)) {
                                            this.finishProcessing(dedupKey);
                                            return;
                                        }
                                    } else {
                                        this.finishProcessing(dedupKey);
                                        return;
                                    }
                                }
                            } catch (metadataError) {
                                // Si hay error obteniendo metadata, permitir el comando
                            }
                        }
                    }
                } catch (botOnOffError) {
                    // Si hay error cargando el módulo, continuar sin bloquear
                }
            }

            // 🤖 Verificar si el subbot específico está habilitado en el grupo
            if (isGroup && global.conn._subNum) {
                try {
                    const myBotModule = require('./plugins/GRUPOS/mybot-on-off.js');
                    if (myBotModule && typeof myBotModule.isMyBotEnabled === 'function') {
                        const myBotEnabled = myBotModule.isMyBotEnabled(chatId, global.conn._subNum);
                        
                        if (!myBotEnabled) {
                            const prefixes = ['.', '/', '❤️', '#', '👅'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^(onmybot)$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }
                    }
                } catch (myBotError) {
                    // Si hay error cargando el módulo, continuar sin bloquear
                }
            }

            // 🌟 Ejecutar textReplyHandler/imageCollector/all si NO es una reacción y hay texto
            if (!isReaction && typeof text === 'string' && text !== '') {
                for (const [cmd, command] of this.commands) {
                    if ((command.isImageCollector || command.isTextReplyHandler || command.all) && 
                        typeof command.handler === 'function' && 
                        !command.isReactionHandler && 
                        !command.command) {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error(`Error handler all (${cmd}):`, error.message);
                        }
                    }
                }
            }

            // REACCIONES
            if (isReaction) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler && command.all) {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error('Error reaction handler:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }
            
            if (typeof text !== 'string' || text === '') {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }
            
            const usedPrefix = prefixes.find(p => text.startsWith(p));
            if (!usedPrefix) {
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            // Buscar primero en comandos string (O(1))
            let matchedCommand = this.commands.get(normalizedCommandName);

            // Si no, buscar en regex
            if (!matchedCommand) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler || command.isImageCollector || command.isTextReplyHandler) continue;
                    if (cmd instanceof RegExp && cmd.test(commandName)) {
                        matchedCommand = command;
                        break;
                    }
                }
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const cleanAuthor = this.cleanId(message.author);
                const isOwner = botConfig.isOwner(cleanAuthor) || 
                                botConfig.isOwner(`${cleanAuthor}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                // 🔒 En grupos, requerir apodo para usar cualquier comando (excepto .apodo)
                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    let senderUser = null;
                    try { senderUser = global.db?.getUser?.(senderNumber); } catch (_) {}
                    const apodo = (senderUser?.apodo || '').trim().toLowerCase();
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                // ⏱️ Cooldown global de 5 segundos por usuario
                // El owner está exento del cooldown
                if (!isOwner) {
                    const cooldownResult = this.checkCooldown(cleanUserId);

                    if (cooldownResult.onCooldown) {
                        if (cooldownResult.shouldWarn) {
                            await wrappedMessage.reply(
                                `⏳ Vas muy rápido. Espera *${cooldownResult.remaining}s* antes de usar otro comando.`
                            ).catch(() => {});
                        }
                        // Si shouldWarn es false, silencio total — ya fue avisado
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                const commandParams = { 
                    text: fullText, 
                    args, 
                    conn: global.conn,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                                        (typeof command === 'function' ? command : null);
                
                if (handlerFunction) {
                    try {
                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;

                        // 📋 Log de comando ejecutado: [CMD] .comando args - apodo - plugin.js
                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser?.(userNum);
                            const apodo = (userData?.apodo || '').trim() || userNum;
                            const pluginFile = command.filePath ? path.basename(command.filePath) : 'desconocido';
                            const fullCmd = fullText ? `${usedPrefix}${commandName} ${fullText}` : `${usedPrefix}${commandName}`;
                            console.log(chalk.cyan(`[CMD] ${fullCmd} - ${apodo} - ${pluginFile}`));
                        } catch (_) {}

                        try { recordCommand(userId); } catch (_) {}
                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser(userNum);
                            if (userData) {
                                userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;
                                global.db.save();
                            }
                        } catch (_) {}
                    } catch (error) {
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';
                        
                        if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                        }
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                        }
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => {});
                        }
                    }
                }
                
                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }
            
            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;