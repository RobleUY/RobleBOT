const fs = require('fs');
const path = require('path');
const { ownerNumber } = require('./config');

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.cooldowns = new Map();
        this.lastMessageId = new Map();
        this.processingMessages = new Set();
        
        this.COOLDOWN_TIME = 5000;
        this.DUPLICATE_WINDOW = 3000;
        
        this.MAX_COOLDOWNS = 300;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;
        
        this.exemptFromCooldown = new Set([
            '059893900470',
            '059892099606',
            '0149078365237384',
            '0106502773850321'
        ]);
        
        this.noCooldownCommands = new Set([
            'ppt', 'piedra', 'papel', 'tijera', 
            'aceptar', 'rechazar', 'cancelar'
        ]);
        
        this.loadPlugins();
        
        setInterval(() => this.cleanupMemory(), 120000);
    }

    cleanupMemory() {
        const now = Date.now();
        
        if (this.cooldowns.size > 0) {
            const cutoff = now - this.COOLDOWN_TIME;
            for (const [key, time] of this.cooldowns.entries()) {
                if (time < cutoff) this.cooldowns.delete(key);
            }
        }
        
        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        
        if (this.processingMessages.size > 10) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }
        
        if (global.gc) {
            global.gc();
        }
    }

    wrapMessageWithEnrichment(message) {
        const sock = global.conn;
        const originalReply = message.reply?.bind(message);

        message.reply = async (content, options = {}) => {
            try {
                const shouldQuote = options?.quoted !== false;
                const mentions = options?.mentions || [];

                const contextInfo = {
                    mentionedJid: mentions,
                    ...(shouldQuote && message.key ? {
                        stanzaId: message.key.id,
                        participant: message.key.participant,
                        quotedMessage: message.message,
                        remoteJid: message.key.remoteJid
                    } : {}),
                    externalAdReply: {
                        title: '📢 Únete a nuestro canal',
                        body: 'Mantente actualizado',
                        thumbnailUrl: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
                        sourceUrl: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
                        mediaType: 1,
                        renderLargerThumbnail: false,
                        showAdAttribution: false
                    }
                };

                if (sock && sock.sendMessage) {
                    await sock.sendMessage(message.from, {
                        text: content,
                        contextInfo
                    });
                } else if (originalReply) {
                    await originalReply(content, options);
                } else {
                    console.error('No hay método para enviar respuesta');
                }

            } catch (error) {
                console.error('Error reply:', error.message);
                if (originalReply) {
                    return originalReply(content, options);
                }
            }
        };

        return message;
    }

    cleanId(id) {
        if (!id) return '';
        try {
            const idStr = String(id);
            return idStr.split('@')[0].split(':')[0].replace(/\D/g, '');
        } catch (error) {
            console.error('Error cleanId:', error.message);
            return '';
        }
    }

    getCooldownKey(userId, chatId) {
        return `${this.cleanId(userId)}_${this.cleanId(chatId)}`;
    }

    isExemptFromCooldown(userId) {
        return this.exemptFromCooldown.has(this.cleanId(userId));
    }

    normalizeText(text) {
        if (text === null || text === undefined) return '';
        if (typeof text !== 'string') text = String(text);
        if (typeof text !== 'string' || text === 'undefined' || text === 'null') return '';
        
        try {
            return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
        } catch (error) {
            console.error('Error en normalizeText:', error.message);
            try {
                return String(text).toLowerCase().trim();
            } catch (e) {
                return '';
            }
        }
    }

    normalizeNumber(jidPart) {
        if (!jidPart) return '';
        return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
    }

    hasValidApodo(userNumber) {
        if (!global.db?.data?.users) return false;
        const user = global.db.getUser(userNumber);
        if (!user || !user.apodo) return false;
        const apodo = user.apodo.trim();
        if (apodo === '' || apodo.toLowerCase() === 'sin apodo') return false;
        return true;
    }

    isDuplicateMessage(messageId) {
        if (!messageId) return false;
        if (this.lastMessageId.has(messageId)) return true;
        this.lastMessageId.set(messageId, Date.now());
        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }
        return false;
    }

    isProcessing(messageId) {
        return messageId && this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        if (!messageId) return;
        this.processingMessages.add(messageId);
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        if (messageId) this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    loadPluginsFromDir(dir) {
        if (!fs.existsSync(dir)) {
            console.warn(`Directorio de plugins no existe: ${dir}`);
            return;
        }

        const items = fs.readdirSync(dir);
        
        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);
            
            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    const resolved = require.resolve(fullPath);
                    if (require.cache[resolved]) delete require.cache[resolved];
                    
                    const plugin = require(fullPath);
                    
                    if (plugin.command) {
                        if (typeof plugin === 'function') {
                            this.commands.set(plugin.command, {
                                command: plugin.command,
                                handler: plugin,
                                help: plugin.help || 'Sin descripción',
                                tags: plugin.tags || [],
                                group: plugin.group || false,
                                owner: plugin.owner || false,
                                admin: plugin.admin || false,
                                apodo: plugin.apodo || false
                            });
                        } else {
                            this.commands.set(plugin.command, plugin);
                        }
                    }

                    if (plugin.textReplyHandler) {
                        this.commands.set('__textReplyHandler__' + fullPath, {
                            handler: plugin.textReplyHandler,
                            isTextReplyHandler: true,
                            all: true,
                            filePath: fullPath
                        });
                    }
                    
                    if (plugin.reactionHandler) {
                        this.commands.set('__reaction__' + fullPath, { 
                            handler: plugin.reactionHandler, 
                            isReactionHandler: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    if (plugin.imageCollector) {
                        this.commands.set('__imageCollector__' + fullPath, { 
                            handler: plugin.imageCollector, 
                            isImageCollector: true, 
                            all: true, 
                            filePath: fullPath 
                        });
                    }

                    for (const [key, value] of Object.entries(plugin)) {
                        if (key !== 'command' && key !== 'handler' && key !== 'help' && 
                            key !== 'tags' && key !== 'textReplyHandler' && 
                            key !== 'reactionHandler' && key !== 'imageCollector' && 
                            value?.command) {
                            this.commands.set(value.command, value);
                        }
                    }
                } catch (error) {
                    console.error(`❌ Error cargando ${item}:`, error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                const resolved = require.resolve(fullPath);
                if (require.cache[resolved]) delete require.cache[resolved];
                
                const plugin = require(fullPath);
                
                for (const [cmd, command] of this.commands.entries()) {
                    if (command.filePath === fullPath) this.commands.delete(cmd);
                }
                
                if (plugin.command) {
                    const commandData = typeof plugin === 'function' ? {
                        command: plugin.command,
                        handler: plugin,
                        help: plugin.help || 'Sin descripción',
                        tags: plugin.tags || [],
                        group: plugin.group || false,
                        owner: plugin.owner || false,
                        admin: plugin.admin || false,
                        apodo: plugin.apodo || false,
                        filePath: fullPath
                    } : { ...plugin, filePath: fullPath };
                    
                    this.commands.set(plugin.command, commandData);
                }

                if (plugin.textReplyHandler) {
                    this.commands.set('__textReplyHandler__' + fullPath, {
                        handler: plugin.textReplyHandler,
                        isTextReplyHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.reactionHandler) {
                    this.commands.set('__reaction__' + fullPath, {
                        handler: plugin.reactionHandler,
                        isReactionHandler: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                if (plugin.imageCollector) {
                    this.commands.set('__imageCollector__' + fullPath, {
                        handler: plugin.imageCollector,
                        isImageCollector: true,
                        all: true,
                        filePath: fullPath
                    });
                }
                
                console.log(`✅ Plugin recargado: ${path.basename(specificFile)}`);
                return true;
            } catch (error) {
                console.error(`❌ Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            console.log(`✅ ${this.commands.size} comandos cargados`);
            return true;
        }
    }

    async handleMessage(message) {
        try {
            if (!message) {
                console.warn('Mensaje null o undefined recibido');
                return;
            }

            const messageId = message.id || message.key?.id;
            if (!messageId) {
                console.warn('Mensaje sin ID recibido');
                return;
            }
            
            if (this.isProcessing(messageId) || this.isDuplicateMessage(messageId)) return;
            
            this.startProcessing(messageId);
            
            const wrappedMessage = this.wrapMessageWithEnrichment(message);
            
            const prefixes = ['.', '/', '❤️', '#'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            try {
                if (message.body !== null && message.body !== undefined) {
                    if (typeof message.body === 'string') {
                        text = message.body;
                    } else if (typeof message.body === 'object') {
                        text = message.body.caption || message.body.text || '';
                    } else {
                        text = String(message.body);
                    }
                }
                
                if (!text && message.message) {
                    const msg = message.message;
                    text = msg.conversation || 
                           msg.extendedTextMessage?.text || 
                           msg.imageMessage?.caption || 
                           msg.videoMessage?.caption || '';
                }
            } catch (error) {
                console.error('Error extrayendo texto:', error.message);
                text = '';
            }
            
            const userId = message.author || message.sender || message.key?.participant || message.key?.remoteJid;
            const chatId = message.from || message.key?.remoteJid;
            
            if (!userId || !chatId) {
                console.warn('Mensaje sin userId o chatId');
                this.finishProcessing(messageId);
                return;
            }

            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);

            // ==========================================
            // 🔴 VERIFICACIÓN: BOT DEBE SER ADMIN EN GRUPOS
            // ==========================================
            if (isGroup) {
                try {
                    const groupMetadata = await global.conn.groupMetadata(chatId);
                    const participants = groupMetadata.participants || [];
                    
                    const botJid = global.conn.user?.id;
                    if (!botJid) {
                        this.finishProcessing(messageId);
                        return;
                    }
                    
                    const possibleBotNumbers = [
                        botJid.split(':')[0].split('@')[0],
                        botJid.split('@')[0].split(':')[0]
                    ].filter(Boolean);
                    
                    // Buscar el bot en los participantes
                    let botParticipant = null;
                    
                    for (const participant of participants) {
                        if (!participant || !participant.id) continue;
                        const participantNumber = participant.id.split('@')[0].split(':')[0];
                        
                        if (possibleBotNumbers.includes(participantNumber)) {
                            botParticipant = participant;
                            break;
                        }
                        
                        if (participant.id.includes(possibleBotNumbers[0]) || 
                            (possibleBotNumbers[1] && participant.id.includes(possibleBotNumbers[1]))) {
                            botParticipant = participant;
                            break;
                        }
                    }
                    
                    if (!botParticipant) {
                        botParticipant = participants.find(p => {
                            return p && p.id && p.id.includes('@lid') && 
                                   (p.admin === 'admin' || p.admin === 'superadmin');
                        });
                    }
                    
                    const botIsAdmin = botParticipant && 
                                      (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
                    
                    // Si el bot NO es admin, bloquear TODOS los comandos
                    if (!botIsAdmin) {
                        // Solo responder si es un comando (tiene prefijo)
                        const usedPrefix = prefixes.find(p => text.startsWith(p));
                        if (usedPrefix) {
                            await wrappedMessage.reply(
                                '❌ *Bot no es administrador*\n\n' +
                                'Para que el bot funcione en este grupo, debe ser promovido a *administrador*.\n\n' +
                                '💡 Pide a un administrador del grupo que promueva al bot a administrador.'
                            );
                        }
                        this.finishProcessing(messageId);
                        return;
                    }
                    
                } catch (error) {
                    console.error('[BOT ADMIN CHECK] Error verificando bot admin:', error.message);
                    this.finishProcessing(messageId);
                    return;
                }
            }

            // ==========================================
            // 🔴 VERIFICACIÓN: BOT ENCENDIDO/APAGADO
            // ==========================================
            if (isGroup) {
                let isBotEnabled;
                try {
                    const botPlugin = require('./plugins/bot-on-off.js');
                    isBotEnabled = botPlugin.isBotEnabled;
                } catch (error) {
                    console.error('Error cargando bot-on-off.js:', error.message);
                    isBotEnabled = () => true;
                }

                const botStatus = isBotEnabled(chatId);

                if (botStatus === false) {
                    const usedPrefix = prefixes.find(p => text.startsWith(p));
                    
                    if (usedPrefix) {
                        const commandText = text.slice(usedPrefix.length).trim();
                        const [commandName] = commandText.split(/\s+/);
                        const normalizedCommandName = this.normalizeText(commandName);

                        if (normalizedCommandName !== 'bot') {
                            this.finishProcessing(messageId);
                            return;
                        }
                    } else {
                        this.finishProcessing(messageId);
                        return;
                    }
                }
                
                if (botStatus === 'admins') {
                    try {
                        const groupMetadata = await global.conn.groupMetadata(chatId);
                        const participants = groupMetadata.participants;
                        
                        const userNumber = cleanUserId;
                        const userParticipant = participants.find(p => {
                            const participantNumber = p.id.split('@')[0].split(':')[0];
                            return participantNumber === userNumber;
                        });
                        
                        const userIsAdmin = userParticipant && 
                                          (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                        
                        if (!userIsAdmin) {
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(/\s+/);
                                const normalizedCommandName = this.normalizeText(commandName);

                                if (normalizedCommandName !== 'bot') {
                                    this.finishProcessing(messageId);
                                    return;
                                }
                            } else {
                                this.finishProcessing(messageId);
                                return;
                            }
                        }
                    } catch (error) {
                        console.error('Error verificando admin para modo admins:', error.message);
                    }
                }
            }

            // Verificar baneo
            if (global.plugins?.get('baneos')?.isUserBanned(cleanUserId)) {
                this.finishProcessing(messageId);
                return;
            }

            // HANDLERS 'ALL' (no reacciones)
            if (!isReaction) {
                for (const [cmd, command] of this.commands) {
                    if ((command.isImageCollector || command.isTextReplyHandler || command.all) && 
                        typeof command.handler === 'function' && 
                        !command.isReactionHandler && 
                        !command.command) {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error(`Error handler all (${cmd}):`, error.message);
                        }
                    }
                }
            }

            // REACCIONES
            if (isReaction) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler && command.all) {
                        try {
                            await command.handler(wrappedMessage);
                        } catch (error) {
                            console.error('Error reaction handler:', error.message);
                        }
                    }
                }
                this.finishProcessing(messageId);
                return;
            }
            
            if (typeof text !== 'string' || text.trim() === '') {
                this.finishProcessing(messageId);
                return;
            }
            
            const usedPrefix = prefixes.find(p => text.startsWith(p));
            if (!usedPrefix) {
                this.finishProcessing(messageId);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            if (!commandText) {
                this.finishProcessing(messageId);
                return;
            }
            
            const [commandName, ...args] = commandText.split(/\s+/);
            const fullText = args.join(' ');
            
            if (!commandName || typeof commandName !== 'string') {
                this.finishProcessing(messageId);
                return;
            }
            
            const normalizedCommandName = this.normalizeText(commandName);
            
            if (!normalizedCommandName) {
                this.finishProcessing(messageId);
                return;
            }

            console.log(`🔍 Buscando comando: "${normalizedCommandName}" (original: "${commandName}")`);

            let commandFound = false;

            // Buscar y ejecutar comando
            for (const [cmd, command] of this.commands) {
                if (command.isReactionHandler || command.isImageCollector || 
                    command.isTextReplyHandler || command.all) {
                    continue;
                }

                let match = false;
                
                try {
                    if (cmd instanceof RegExp) {
                        match = cmd.test(commandName);
                    } else if (typeof cmd === 'string') {
                        const normalizedCmd = this.normalizeText(cmd);
                        if (normalizedCmd) {
                            match = normalizedCmd === normalizedCommandName;
                        }
                    }
                } catch (error) {
                    console.error('Error comparando comando:', error.message);
                    continue;
                }

                if (match) {
                    commandFound = true;
                    console.log(`✅ Comando encontrado: ${cmd}`);

                    // ==========================================
                    // 🟡 VERIFICACIÓN: COMANDO ON/OFF POR GRUPO
                    // ==========================================
                    if (isGroup) {
                        let isCommandEnabled, isProtectedCommand;
                        try {
                            const cmdPlugin = require('./plugins/comandos-on-off.js');
                            isCommandEnabled = cmdPlugin.isCommandEnabled;
                            isProtectedCommand = cmdPlugin.isProtectedCommand;
                        } catch (error) {
                            console.error('Error cargando comandos-on-off.js:', error.message);
                            isCommandEnabled = () => true;
                            isProtectedCommand = () => false;
                        }

                        // No verificar comandos protegidos
                        if (!isProtectedCommand(normalizedCommandName)) {
                            const cmdStatus = isCommandEnabled(chatId, normalizedCommandName);

                            // Si el comando está desactivado
                            if (cmdStatus === false) {
                                await wrappedMessage.reply(
                                    `🔴 *Comando Desactivado*\n\n` +
                                    `El comando *${usedPrefix}${normalizedCommandName}* está desactivado en este grupo.\n\n` +
                                    `💡 Un administrador puede activarlo con:\n` +
                                    `*${usedPrefix}oncomando ${normalizedCommandName}*`
                                );
                                this.finishProcessing(messageId);
                                return;
                            }

                            // Si el comando es solo para admins
                            if (cmdStatus === 'admins') {
                                try {
                                    const groupMetadata = await global.conn.groupMetadata(chatId);
                                    const participants = groupMetadata.participants;
                                    
                                    const userNumber = cleanUserId;
                                    const userParticipant = participants.find(p => {
                                        const participantNumber = p.id.split('@')[0].split(':')[0];
                                        return participantNumber === userNumber;
                                    });
                                    
                                    const userIsAdmin = userParticipant && 
                                        (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                                    
                                    if (!userIsAdmin) {
                                        await wrappedMessage.reply(
                                            `🟡 *Comando Solo Admins*\n\n` +
                                            `El comando *${usedPrefix}${normalizedCommandName}* solo puede ser usado por administradores en este grupo.\n\n` +
                                            `💡 Contacta a un admin si necesitas usar este comando.`
                                        );
                                        this.finishProcessing(messageId);
                                        return;
                                    }
                                } catch (error) {
                                    console.error('Error verificando admin para comando:', error.message);
                                }
                            }
                        }
                    }
                    // ==========================================

                    // Verificar si es solo para grupos
                    if (command.group === true && !isGroup) {
                        await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                        this.finishProcessing(messageId);
                        return;
                    }

                    // Verificar si es solo para owner
                    const cleanAuthor = this.cleanId(userId);
                    const isOwner = global.botConfig?.isOwner(cleanAuthor) || 
                                   global.botConfig?.isOwner(`${cleanAuthor}@s.whatsapp.net`);

                    if (command.owner && !isOwner) {
                        await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                        this.finishProcessing(messageId);
                        return;
                    }

                    // Verificar si es solo para admin (owners también pueden usarlo)
                    const isAdmin = global.botConfig?.isAdmin(cleanAuthor) || 
                                   global.botConfig?.isAdmin(`${cleanAuthor}@s.whatsapp.net`);

                    if (command.admin && !isOwner && !isAdmin) {
                        await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner o un administrador del bot.');
                        this.finishProcessing(messageId);
                        return;
                    }

                    // Verificar apodo
                    if (command.apodo === true) {
                        const senderJid = userId;
                        const senderNumber = this.normalizeNumber(senderJid);
                        
                        if (!this.hasValidApodo(senderNumber)) {
                            await wrappedMessage.reply(
                                `🚫 No puedes usar este comando sin tener un apodo.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`
                            );
                            this.finishProcessing(messageId);
                            return;
                        }
                    }

                    // Sistema de cooldown
                    const skipCooldown = this.isExemptFromCooldown(cleanUserId) || 
                                         this.noCooldownCommands.has(normalizedCommandName);
                    
                    if (!skipCooldown) {
                        const cooldownKey = this.getCooldownKey(userId, chatId);
                        const lastCommandTime = this.cooldowns.get(cooldownKey) || 0;
                        const now = Date.now();
                        const timeLeft = lastCommandTime + this.COOLDOWN_TIME - now;

                        if (timeLeft > 0) {
                            await wrappedMessage.reply(`⏳ Espera ${(timeLeft / 1000).toFixed(1)}s antes de usar otro comando.`);
                            this.finishProcessing(messageId);
                            return;
                        }

                        this.cooldowns.set(cooldownKey, now);
                    }
                           
                    // Ejecutar comando
                    const commandParams = { 
                        text: fullText, 
                        args, 
                        conn: global.conn,
                        usedPrefix,
                        command: commandName,
                        fullUserId: userId,
                        isGroup
                    };

                    const handlerFunction = typeof command.handler === 'function' ? command.handler :
                        (typeof command === 'function' ? command : null);
                    
                    if (handlerFunction) {
                        try {
                            console.log(`⚡ Ejecutando comando: ${commandName}`);
                            await handlerFunction(wrappedMessage, commandParams);

                            try {
                                const userNumber = this.cleanId(userId);
                                const userData = global.db.getUser(userNumber);

                                if (userData) {
                                    if (!userData.ComandosEjecutados) userData.ComandosEjecutados = 0;
                                    userData.ComandosEjecutados++;
                                    global.db.save();
                                }
                            } catch (err) {
                                console.error("⚠ Error incrementando ComandosEjecutados:", err.message);
                            }

                        } catch (error) {
                            console.error(`❌ Error ejecutando ${commandName}:`, error.message);
                            console.error(`   Stack:`, error.stack);

                            try {
                                await wrappedMessage.reply('❌ Error al procesar el comando.');
                            } catch (replyError) {
                                console.error('Error enviando mensaje de error:', replyError.message);
                            }
                        }
                    } else {
                        console.error(`Comando ${commandName} sin handler válido`);
                    }

                    this.finishProcessing(messageId);
                    return;
                }
            }
            
            // Comando no encontrado
            if (!commandFound && normalizedCommandName) {
                console.log(`❌ Comando no encontrado: ${normalizedCommandName}`);
                try {
                    await wrappedMessage.reply(
                        `❌ Comando *${usedPrefix}${commandName}* no encontrado.\n\n` +
                        `Usa *${usedPrefix}menu* para ver los comandos disponibles.`
                    );
                } catch (error) {
                    console.error('Error enviando mensaje de comando no encontrado:', error.message);
                }
            }
            
            this.finishProcessing(messageId);
        } catch (error) {
            console.error('❌ Error crítico en handleMessage:', error.message);
            console.error('   Stack:', error.stack);
            const messageId = message?.id || message?.key?.id;
            if (messageId) this.finishProcessing(messageId);
        }
    }
}

module.exports = CommandHandler;