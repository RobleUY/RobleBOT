const fs = require('fs'); //asd
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand, updateStatsMeta } = require('./botStatsRecorder');
const achievements = require('./achievements');
const botConfig = require('./config');
const premium = require('./premium');
const { getGroupMetadataCached } = require('./lib/groupCache');
const banModule = require('./plugins/baneados.js');
const botsAdminsModule = require('./plugins/SUBBOTS/subbots-admins.js');
const subbotOnOffModule = require('./plugins/SUBBOTS/subbots-onoff.js');
let _gofcCache = null;
let _gofcCacheTime = 0;
function getGofcAllowedSubbots() {
    const now = Date.now();
    if (_gofcCache && (now - _gofcCacheTime < 10000)) {
        return _gofcCache;
    }
    try {
        const gofcPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', 'gofc-subbots.json');
        if (fs.existsSync(gofcPath)) {
            const gofcData = JSON.parse(fs.readFileSync(gofcPath, 'utf8'));
            _gofcCache = Array.isArray(gofcData.allowedSubbots) ? gofcData.allowedSubbots : [];
            _gofcCacheTime = now;
            return _gofcCache;
        }
    } catch (e) {}
    _gofcCache = [];
    _gofcCacheTime = now;
    return _gofcCache;
}

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.textReplyHandlers = [];
        this.allMessageHandlers = [];
        this.reactionHandlers = [];
        this.imageCollectors = [];
        this.regexCommands = [];
        this.lastMessageId = new Map();
        this.processingMessages = new Set();

        this.cooldowns = new Map();
        this.COOLDOWN_MS = 5000; // 5s de cooldown entre comandos por usuario

        this.DUPLICATE_WINDOW = 3000;
        this.MAX_LAST_MESSAGE_IDS = 100;
        this.MAX_PROCESSING = 50;

        // ── Invitación al canal de WhatsApp ──────────────────────────────────
        this.inviteCommandCount = new Map(); // userId → número de comandos usados
        this.inviteTarget       = new Map(); // userId → meta de comandos para mostrar aviso
        // ────────────────────────────────────────────────────────────────────

        this.loadPlugins();

        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();

        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        if (this.processingMessages.size > 100) {
            console.log(`⚠️ Limpiando ${this.processingMessages.size} mensajes en procesamiento`);
            this.processingMessages.clear();
        }

        for (const [userId, data] of this.cooldowns.entries()) {
            if (now - data.lastCommandTime >= this.COOLDOWN_MS) {
                this.cooldowns.delete(userId);
            }
        }

        if (this.inviteCommandCount.size > 2000) {
            this.inviteCommandCount.clear();
            this.inviteTarget.clear();
        }
    }

    cleanId(id) {
        if (!id) return '';
        return id.split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    normalizeText(text) {
        return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    getAutoPromoMessage() {
        const promos = [
            '\n\n_Recuerda unirte a nuestro canal de WhatsApp_\nhttps://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
            '\n\n_¿Quieres más ventajas?_ Puedes comprar Premium o monedas:\nhttps://roblebot.vercel.app/tienda.html'
        ];
        return promos[Math.floor(Math.random() * promos.length)];
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;

        this.lastMessageId.set(messageId, Date.now());

        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        this.processingMessages.add(messageId);
        setTimeout(() => {
            this.processingMessages.delete(messageId);
        }, 8000);
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    // ── Helpers de owner ──────────────────────────────────────────────────

    /** Devuelve true si el userId es owner según config */
    isOwnerUser(userId) {
        const clean = this.cleanId(userId);
        return botConfig.isOwner(clean) || botConfig.isOwner(`${clean}@s.whatsapp.net`);
    }

    // ────────────────────────────────────────────────────────────────────────

    checkCooldown(userId) {
        const now = Date.now();
        const data = this.cooldowns.get(userId);

        if (!data) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        const elapsed = now - data.lastCommandTime;

        if (elapsed >= this.COOLDOWN_MS) {

            this.cooldowns.set(userId, { lastCommandTime: now, warningSent: false });
            return { onCooldown: false };
        }

        if (!data.warningSent) {

            data.warningSent = true;
            return { onCooldown: true, shouldWarn: true, remaining: Math.ceil((this.COOLDOWN_MS - elapsed) / 1000) };
        }

        return { onCooldown: true, shouldWarn: false };
    }

    registerPluginCommand(commandKey, commandData) {
        if (!commandKey || !commandData) return;

        this.commands.set(commandKey, commandData);

        if (commandData.isTextReplyHandler) {
            this.textReplyHandlers.push(commandData);
        }

        if (commandData.isAllMessageHandler) {
            this.allMessageHandlers.push(commandData);
        }

        if (commandData.isReactionHandler) {
            this.reactionHandlers.push(commandData);
        }

        if (commandData.isImageCollector) {
            this.imageCollectors.push(commandData);
        }
    }

    clearPluginCommands(filePath) {
        for (const [key, command] of [...this.commands.entries()]) {
            if (command.filePath === filePath) {
                this.commands.delete(key);
            }
        }

        this.textReplyHandlers = this.textReplyHandlers.filter(cmd => cmd.filePath !== filePath);
        this.allMessageHandlers = this.allMessageHandlers.filter(cmd => cmd.filePath !== filePath);
        this.reactionHandlers = this.reactionHandlers.filter(cmd => cmd.filePath !== filePath);
        this.imageCollectors = this.imageCollectors.filter(cmd => cmd.filePath !== filePath);
    }

    loadPlugin(fullPath) {
        const resolved = require.resolve(fullPath);
        if (require.cache[resolved]) {
            delete require.cache[resolved];
        }

        const plugin = require(fullPath);
        this.clearPluginCommands(fullPath);

        if (plugin.command) {
            const commandData = typeof plugin === 'function' ? {
                command: plugin.command,
                handler: plugin,
                help: plugin.help || 'Sin descripción',
                tags: plugin.tags || [],
                group: plugin.group || false,
                owner: plugin.owner || false,
                filePath: fullPath
            } : { ...plugin, filePath: fullPath };

            this.registerPluginCommand(plugin.command, commandData);
        }

        if (plugin.textReplyHandler) {
            this.registerPluginCommand('__textReplyHandler__' + fullPath, {
                handler: plugin.textReplyHandler,
                isTextReplyHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.allMessageHandler) {
            this.registerPluginCommand('__allMessageHandler__' + fullPath, {
                handler: plugin.allMessageHandler,
                isAllMessageHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.reactionHandler) {
            this.registerPluginCommand('__reaction__' + fullPath, {
                handler: plugin.reactionHandler,
                isReactionHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.imageCollector) {
            this.registerPluginCommand('__imageCollector__' + fullPath, {
                handler: plugin.imageCollector,
                isImageCollector: true,
                all: true,
                filePath: fullPath
            });
        }

        for (const [key, value] of Object.entries(plugin)) {
            if (key !== 'command' && key !== 'handler' && key !== 'help' &&
                key !== 'tags' && key !== 'textReplyHandler' && key !== 'allMessageHandler' &&
                key !== 'reactionHandler' && key !== 'imageCollector' &&
                value?.command) {
                const commandData = typeof value === 'function' ? {
                    command: value.command,
                    handler: value,
                    help: value.help || [],
                    tags: value.tags || [],
                    group: value.group || false,
                    owner: value.owner || false,
                    filePath: fullPath
                } : { ...value, filePath: fullPath };

                this.registerPluginCommand(value.command, commandData);
            }
        }
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);

        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    this.loadPlugin(fullPath);
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error && error.stack ? error.stack : error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);
                
                // La función loadPlugin ya maneja la limpieza del caché y comandos anteriores
                this.loadPlugin(fullPath);
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            this.textReplyHandlers = [];
            this.allMessageHandlers = [];
            this.reactionHandlers = [];
            this.imageCollectors = [];

            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;

        // Usar _subNum del mensaje (asignado por subbot-serbot) en vez de global.conn
        // para evitar condiciones de carrera cuando múltiples subbots procesan en paralelo.
        const botId = message._subNum ? `sub${message._subNum}` : 'main';
        const chatId = message.from || message.key?.remoteJid;
        const dedupKey = `${botId}:${chatId}:${messageId}`;

        // Verificar el socket correcto: el del mensaje si es subbot, global.conn si es principal
        const activeSock = message._sock || global.conn;
        if (!activeSock || !activeSock.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }

        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }

        this.startProcessing(dedupKey);

        try {
            const wrappedMessage = message;

            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
            const baileyMsg = global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }

            const userId = message.author || message.sender;
            const cleanUserId = this.cleanId(userId);
            const isGroup = this.isGroupChat(chatId);



            try {
                if (banModule && typeof banModule.isUserBanned === 'function') {
                    const groupId = isGroup ? chatId : null;
                    if (banModule.isUserBanned(cleanUserId, groupId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            } catch (banError) {}

            // ── Bypass para subbots en lista blanca del grupo oficial ───────────────
            const OFFICIAL_GROUP_ID = '120363203689229697@g.us';
            let isAllowedSubbotInOfficial = false;
            if (activeSock._subNum && chatId === OFFICIAL_GROUP_ID) {
                const allowed = getGofcAllowedSubbots();
                isAllowedSubbotInOfficial = allowed.includes(activeSock._subNum);
            }

            // ── Check nivel grupo: .bots on/off/admins (subbots-admins.js) ─────────
            if (isGroup && !isAllowedSubbotInOfficial) {
                try {
                    if (botsAdminsModule && typeof botsAdminsModule.isBotEnabled === 'function') {
                        const botStatus = botsAdminsModule.isBotEnabled(chatId);

                        if (botStatus === false) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                if (!/^bots$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }

                        if (botStatus === 'admins') {
                            try {
                                const groupMetadata = await getGroupMetadataCached(activeSock || global.conn, chatId);
                                const userParticipant = groupMetadata?.participants?.find(p => {
                                    const participantNumber = p.id.split('@')[0].split(':')[0];
                                    return participantNumber === cleanUserId;
                                });

                                const isAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

                                if (!isAdmin) {
                                    const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                                    const usedPrefix = prefixes.find(p => text.startsWith(p));
                                    if (usedPrefix) {
                                        const commandText = text.slice(usedPrefix.length).trim();
                                        const [commandName] = commandText.split(' ');
                                        if (!/^bots$/i.test(commandName)) {
                                            this.finishProcessing(dedupKey);
                                            return;
                                        }
                                    } else {
                                        this.finishProcessing(dedupKey);
                                        return;
                                    }
                                }
                            } catch (metadataError) {
                                console.error('[Handler-GroupAdminsCheck] Error:', metadataError.message);
                            }
                        }
                    }
                } catch (botOnOffError) {
                    console.error('[Handler-GroupCheck] Error:', botOnOffError.message);
                }
            }

            // ── Check nivel subbot: subbots-onoff.js (local/global) + responder ────
            if (activeSock._subNum && !isAllowedSubbotInOfficial) {
                try {
                    // Check si el subbot responde en privados
                    if (!isGroup && typeof subbotOnOffModule.isSubBotRespondsInPriv === 'function') {
                        if (!subbotOnOffModule.isSubBotRespondsInPriv(activeSock._subNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Check si el subbot responde en grupos
                    if (isGroup && typeof subbotOnOffModule.isSubBotRespondsInGrupos === 'function') {
                        if (!subbotOnOffModule.isSubBotRespondsInGrupos(activeSock._subNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Check encendido/apagado local y global del subbot
                    if (typeof subbotOnOffModule.isSubBotEnabled === 'function') {
                        const subBotEnabled = subbotOnOffModule.isSubBotEnabled(chatId, activeSock._subNum);

                        if (!subBotEnabled) {
                            const prefixes = ['.', '/', '❤️', '#', '👅', '😎'];
                            const usedPrefix = prefixes.find(p => text.startsWith(p));
                            if (usedPrefix) {
                                const commandText = text.slice(usedPrefix.length).trim();
                                const [commandName] = commandText.split(' ');
                                // Permitir solo .bot, .onmybot y .bots
                                if (!/^(bot|onmybot|bots)$/i.test(commandName)) {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            } else {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        }
                    }
                } catch (subBotError) {
                    console.error('[Handler-SubbotCheck] Error:', subBotError.message);
                }
            }

            const usedPrefix = typeof text === 'string' ? prefixes.find(p => text.startsWith(p)) : null;

            if (isReaction) {
                // Ejecutar reactionHandlers en paralelo
                await Promise.allSettled(
                    this.reactionHandlers
                        .filter(cmd => cmd.all && typeof cmd.handler === 'function')
                        .map(cmd => cmd.handler(wrappedMessage).catch(error => {
                            console.error('Error reaction handler:', error.message);
                        }))
                );
                this.finishProcessing(dedupKey);
                return;
            }

            // ── Ejecución no bloqueante de Handlers Pasivos en segundo plano ──
            const runPassiveHandlers = () => {
                setImmediate(async () => {
                    try {
                        if (this.allMessageHandlers.length > 0) {
                            await Promise.allSettled(
                                this.allMessageHandlers
                                    .filter(cmd => typeof cmd.handler === 'function')
                                    .map(cmd => cmd.handler(wrappedMessage).catch(error => {
                                        console.error(`Error handler allMessage (${cmd.filePath || 'unknown'}):`, error.message);
                                    }))
                            );
                        }
                        if (!usedPrefix && typeof text === 'string' && text !== '') {
                            const allHandlers = [...this.textReplyHandlers, ...this.imageCollectors];
                            if (allHandlers.length > 0) {
                                await Promise.allSettled(
                                    allHandlers
                                        .filter(cmd => typeof cmd.handler === 'function')
                                        .map(cmd => cmd.handler(wrappedMessage).catch(error => {
                                            console.error(`Error handler all (${cmd.filePath || 'unknown'}):`, error.message);
                                        }))
                                );
                            }
                        }
                    } catch (_) {}
                });
            };

            if (!usedPrefix) {
                // Si NO es un comando con prefijo, ejecutar handlers pasivos de inmediato
                runPassiveHandlers();
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            // Si ES un comando con prefijo, lanzar handlers pasivos en segundo plano
            runPassiveHandlers();

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            let matchedCommand = this.commands.get(normalizedCommandName);

            if (!matchedCommand) {
                for (const [cmd, command] of this.commands) {
                    if (command.isReactionHandler || command.isImageCollector || command.isTextReplyHandler) continue;
                    if (cmd instanceof RegExp && cmd.test(commandName)) {
                        matchedCommand = command;
                        break;
                    }
                }
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const isOwner = botConfig.isOwner(cleanUserId) || 
                                botConfig.isOwner(`${cleanUserId}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                // ── Check NSFW en Sub-Bots ─────────────────────────────────────
                if (activeSock?._subNum) {
                    const isNsfwCmd = command.nsfw === true ||
                        (Array.isArray(command.tags) && command.tags.includes('nsfw')) ||
                        (command.filePath && command.filePath.replace(/\\/g, '/').toLowerCase().includes('/nsfw/')) ||
                        /^(nsfw|xnxx|xvideos|xvsearch|xnxxsearch|pornhub|tetas|hentai|hentaiv|rule34|hotgirl|cpbroma)$/i.test(commandName);

                    if (isNsfwCmd) {
                        try {
                            if (typeof subbotOnOffModule.isSubBotNsfwEnabled === 'function') {
                                if (!subbotOnOffModule.isSubBotNsfwEnabled(activeSock._subNum)) {
                                    await wrappedMessage.reply('🔒 *NSFW Desactivado en este Sub-Bot*\n\nEl dueño de este sub-bot ha desactivado el contenido NSFW con *.bot nsfw off*.');
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            }
                        } catch (e) {
                            console.error('[Handler-SubbotNSFW] Error:', e.message);
                        }
                    }
                }

                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    let senderUser = null;
                    try { senderUser = global.db?.getUser?.(senderNumber); } catch (_) {}
                    const apodo = (senderUser?.apodo || '').trim().toLowerCase();
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                if (!isOwner) {
                    const cooldownResult = this.checkCooldown(cleanUserId);

                    if (cooldownResult.onCooldown) {
                        if (cooldownResult.shouldWarn) {
                            await wrappedMessage.reply(
                                `⏳ Vas muy rápido. Espera *${cooldownResult.remaining}s* antes de usar otro comando.`
                            ).catch(() => {});
                        }

                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                // ── Lógica de invitación al canal de WhatsApp ───────────────────────
                if (!this.inviteTarget.has(cleanUserId)) {
    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 6) + 10); // 10 a 15
}
const targetCount = this.inviteTarget.get(cleanUserId);
const currentCount = (this.inviteCommandCount.get(cleanUserId) || 0) + 1;
this.inviteCommandCount.set(cleanUserId, currentCount);

let appendFooter = false;
let footer = '';
if (currentCount >= targetCount) {
    appendFooter = true;
    this.inviteCommandCount.set(cleanUserId, 0);
    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 6) + 10); // 10 a 15
    footer = this.getAutoPromoMessage();
}

                const baseConn = message._sock || global.conn;
                const isAdminBot = botConfig.adminsbot.includes(cleanUserId) || botConfig.adminsbot.includes(userId);
                const STAFF_SUFFIX = ' \n\n[RobleBOT Staff]';

                function enrichText(t) {
                    if (typeof t !== 'string') return t;
                    let result = premium.isPremium(userId)
                        ? premium.formatPremiumReply(t, userId)
                        : premium.formatTopCoinsReply(t, userId);
                    if (isAdminBot && !result.includes('[RobleBOT Staff]')) {
                        result += STAFF_SUFFIX;
                    }
                    if (appendFooter && footer && !result.includes('whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q') && !result.includes('roblebot.vercel.app/tienda.html')) {
                        result += footer;
                    }
                    return result;
                }

                const originalReply = wrappedMessage.reply.bind(wrappedMessage);
                wrappedMessage.reply = async function (text, options = {}) {
                    return originalReply(enrichText(text), options);
                };

                const originalSendMessage = baseConn.sendMessage.bind(baseConn);
                const connToUse = Object.create(baseConn);
                connToUse.sendMessage = async function (jid, content, options = {}) {
                    if (content && typeof content.text === 'string') {
                        content.text = enrichText(content.text);
                    }
                    return originalSendMessage(jid, content, options);
                };
                // ────────────────────────────────────────────────────────────────────

                const commandParams = { 
                    text: fullText, 
                    args, 
                    conn: connToUse,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                                        (typeof command === 'function' ? command : null);

                if (handlerFunction) {
                    try {
                        try {
                            const rawSender = message.author || message.sender;
                            if (rawSender && connToUse?.signalRepository?.lidMapping) {
                                const lidMap = connToUse.signalRepository.lidMapping;
                                if (rawSender.endsWith('@lid') && typeof lidMap.getPNForLID === 'function') {
                                    lidMap.getPNForLID(rawSender).then(pn => {
                                        if (pn && global.db?.linkUserAlias) global.db.linkUserAlias(pn, rawSender);
                                    }).catch(() => {});
                                } else if (rawSender.endsWith('@s.whatsapp.net') && typeof lidMap.getLIDForPN === 'function') {
                                    lidMap.getLIDForPN(rawSender).then(lid => {
                                        if (lid && global.db?.linkUserAlias) global.db.linkUserAlias(rawSender, lid);
                                    }).catch(() => {});
                                }
                            }
                        } catch (_) {}
                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;

                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser?.(userNum);
                            const apodo = (userData?.apodo || '').trim() || userNum;
                            const pluginFile = command.filePath ? path.basename(command.filePath) : 'desconocido';
                            const fullCmd = fullText ? `${usedPrefix}${commandName} ${fullText}` : `${usedPrefix}${commandName}`;
                            
                            const subNum = message._subNum || connToUse._subNum;
                            const botLabel = subNum ? `Sub-bot #${subNum}` : 'Principal';

                            console.log(chalk.cyan(`[CMD] [${botLabel}] ${fullCmd} - ${apodo} - ${pluginFile}`));
                        } catch (_) {}

                        try { recordCommand(userId, commandName); } catch (_) {}

                        setImmediate(async () => {
                            try {
                                const userNum = this.cleanId(userId);
                                const userData = global.db?.getUser(userNum);
                                if (userData) {
                                    userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;

                                    const { ensureAchievements } = achievements;
                                    ensureAchievements(userData);
                                    userData.achievements.commands.total = userData.ComandosEjecutados;

                                    const achievementMessage = achievements.addAchievementProgress(userData, 'commands', 0);

                                    const xpGain = Math.floor(Math.random() * 2) + 1;
                                    userData.exp = (Number(userData.exp) || 0) + xpGain;

                                    try {
                                        const levelInfo = achievements.calculateLevel(userData.exp || 0);
                                        userData.level = levelInfo.level;
                                    } catch (_) {}

                                    global.db.save(userNum);
                                    if (achievementMessage) {
                                        await wrappedMessage.reply(achievementMessage).catch(() => {});
                                    }
                                }
                            } catch (_) {}
                        });
                    } catch (error) {
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';

                        // 🚨 ENOSPC: sin espacio en disco — limpiar temporales inmediatamente
                        if (errorMsg.includes('ENOSPC') || error?.code === 'ENOSPC') {
                            console.error(chalk.red(`[ENOSPC] Sin espacio en disco en comando ${commandName}. Activando limpieza de emergencia...`));
                            try {
                                const { tempCleaner } = require('./tempCleaner');
                                tempCleaner.emergencyCleanup().then(result => {
                                    console.log(chalk.green(`[ENOSPC] Limpieza completada: ${result.cleaned} archivos borrados`));
                                }).catch(e => {
                                    console.error('[ENOSPC] Error en limpieza de emergencia:', e.message);
                                });
                            } catch (cleanErr) {
                                console.error('[ENOSPC] No se pudo importar tempCleaner:', cleanErr.message);
                            }
                            await wrappedMessage.reply('⚠️ Error temporal de espacio en disco. Limpiando automáticamente...').catch(() => {});
                        }
                        else if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                        }
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                        }
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => {});
                        }
                    }
                }

                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }

            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;