'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    return '';
}

// ── Resuelve JIDs @lid → @s.whatsapp.net ─────────────────────────────────────
// Las cuentas nuevas de WhatsApp usan JIDs @lid que no se pueden usar
// directamente en sendMessage. Hay que resolverlos al número real.
async function resolveLidJid(jid, sock) {
    if (!jid || !jid.endsWith('@lid') || !sock) return jid;
    try {
        if (sock.signalRepository?.lidMapping?.getPNForLID) {
            const pn = await sock.signalRepository.lidMapping.getPNForLID(jid);
            if (pn) {
                const clean = pn.split(':')[0].replace(/\D/g, '');
                if (clean) return `${clean}@s.whatsapp.net`;
            }
        }
    } catch (_) {}
    try {
        if (typeof sock.onWhatsApp === 'function') {
            const [result] = await sock.onWhatsApp(jid);
            if (result?.jid) return result.jid;
        }
    } catch (_) {}
    return jid; // fallback: devolver el original si no se pudo resolver
}

async function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo   = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    // ── Resolver JIDs @lid al crear el mensaje ────────────────────────────────
    // Así todos los plugins que lean message.from / message.author obtienen
    // directamente el JID @s.whatsapp.net válido, sin tener que resolverlo ellos.
    const rawJid         = baileyMessage.key.remoteJid;
    const rawParticipant = baileyMessage.key.participant;

    const resolvedJid         = rawJid?.endsWith('@lid')
        ? await resolveLidJid(rawJid, sock)
        : rawJid;

    const resolvedParticipant = rawParticipant?.endsWith('@lid')
        ? await resolveLidJid(rawParticipant, sock)
        : rawParticipant;
    // ─────────────────────────────────────────────────────────────────────────

    const message = {
        id:          baileyMessage.key.id,
        from:        resolvedJid,
        key:         { ...baileyMessage.key, remoteJid: resolvedJid },
        numberInbox: resolvedJid,
        numberGroup: resolvedParticipant,
        author:      resolvedParticipant || resolvedJid,
        sender:      resolvedParticipant || resolvedJid,
        body:        getMessageText(baileyMessage),
        isGroup:     rawJid?.includes('@g.us') ?? false,
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,
        hasQuotedMsg: !!quotedMessage,
        _data: { quotedMsg: quotedMessage || null },
        _sock:       sock,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   resolvedJid,
                id:          contextInfo.stanzaId || quotedMessage?.key?.id || null,
                participant: contextInfo.participant || resolvedParticipant,
                fromMe:      false
            },
            id:      contextInfo.stanzaId,
            sender:  contextInfo.participant,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                const isSubbotMsg = !!this._subNum;
                const activeSock  = sock;

                if (!activeSock || !activeSock.user) {
                    if (!isSubbotMsg && global.conn && global.conn.user) {
                        return await global.conn.sendMessage(this.from, { text, mentions: options?.mentions || [] }, { quoted: baileyMessage });
                    }
                    return;
                }

                const mentions = options?.mentions || [];

                // this.from ya fue resuelto al crear el mensaje — usar directo
                await activeSock.sendMessage(
                    this.from,
                    { text, mentions },
                    { quoted: baileyMessage }
                );
            } catch (error) {
                if (error.message?.includes('No sessions') || error.message?.includes('no sessions')) {
                    return;
                }
                console.error('[reply] Error:', error.message);
                throw error;
            }
        },

        delete: async function () {
            try {
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) return;
                await activeSock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage };
