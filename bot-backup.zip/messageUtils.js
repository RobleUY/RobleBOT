'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';

    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage) return msg.imageMessage.caption || '«imagen»';
    if (msg.videoMessage) return msg.videoMessage.caption || '«video»';
    if (msg.documentMessage) return msg.documentMessage.caption || '«documento»';
    if (msg.stickerMessage) return '«sticker»';
    if (msg.audioMessage) return '«audio»';
    if (msg.contactMessage) return '«contacto»';
    if (msg.locationMessage) return '«ubicación»';
    if (msg.contactsArrayMessage) return '«contacto»';
    if (msg.productMessage) return '«producto»';
    if (msg.buttonsResponseMessage?.selectedButtonId) return `«respuesta botón: ${msg.buttonsResponseMessage.selectedButtonId}»`;
    if (msg.listResponseMessage?.title) return `«respuesta lista: ${msg.listResponseMessage.title}»`;
    if (msg.templateButtonReplyMessage?.selectedId) return `«respuesta plantilla: ${msg.templateButtonReplyMessage.selectedId}»`;

    return '';
}

async function resolveLidJid(jid, sock) {
    if (!jid || !jid.endsWith('@lid')) return jid;
    try {
        if (sock?.signalRepository?.lidMapping?.getPNForLID) {
            const pn = await sock.signalRepository.lidMapping.getPNForLID(jid);
            if (pn) return pn;
        }
    } catch (e) {
        // No hacemos nada, intentamos fallback.
    }
    try {
        if (typeof sock?.onWhatsApp === 'function') {
            const [result] = await sock.onWhatsApp(jid);
            if (result?.jid) return result.jid;
        }
    } catch (e) {
        // Fallback silencioso.
    }
    return jid;
}

async function createCompatibleMessage(baileyMessage, sock) {
    const msg = baileyMessage.message || {};
    const contextInfo = msg.contextInfo
        || msg.extendedTextMessage?.contextInfo
        || msg.extendedTextMessageV2?.contextInfo
        || msg.buttonsResponseMessage?.contextInfo
        || msg.listResponseMessage?.contextInfo
        || msg.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
        || msg.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
        || msg.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
        || msg.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
        || null;
    const quotedMessage = contextInfo?.quotedMessage || null;
    const quotedId = contextInfo?.stanzaId || quotedMessage?.key?.id || quotedMessage?.id || null;
    const ownerJid = sock?.user?.id || global.conn?.user?.id || null;
    const key = baileyMessage.key || {};
    const rawParticipant = key.participant || key.participantAlt || null;
    const rawRemoteJid = key.remoteJid || key.remoteJidAlt || null;
    const messageParticipant = await resolveLidJid(rawParticipant, sock);
    const messageRemoteJid = await resolveLidJid(rawRemoteJid, sock);
    const messageSender = messageParticipant || (key.fromMe ? ownerJid : messageRemoteJid) || messageRemoteJid;
    const isGroup = messageRemoteJid?.endsWith('@g.us');
    const resolvedKey = Object.assign({}, key, {
        participant: messageParticipant || key.participant,
        remoteJid: messageRemoteJid || key.remoteJid,
    });
    const quotedSender = await resolveLidJid(contextInfo?.participant
        || quotedMessage?.key?.participant
        || quotedMessage?.participant
        || quotedMessage?.participantAlt
        || null, sock);

    const message = {
        id:          resolvedKey.id || key.id,
        from:        resolvedKey.remoteJid,
        key:         resolvedKey,
        numberInbox: resolvedKey.remoteJid,
        numberGroup: resolvedKey.participant || null,
        author:      messageSender || resolvedKey.remoteJid,
        sender:      messageSender || resolvedKey.remoteJid,
        body:        getMessageText(baileyMessage),
        isGroup:     !!isGroup,
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    contextInfo?.mentionedJid || null,
        _baileyMessage: baileyMessage,
        hasQuotedMsg: !!quotedMessage,
        _data: { quotedMsg: quotedMessage || null },
        _sock:       sock,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   baileyMessage.key.remoteJid,
                id:          quotedId,
                participant: quotedSender || baileyMessage.key.participant,
                fromMe:      false
            },
            id:      quotedId,
            sender:  quotedSender,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                // ⚠️ CAMBIO CRÍTICO: Si el mensaje tiene un _sock asignado, DEBE usar ese.
                // Si ese _sock perdió su user, no hacemos fallback al principal, lo cancelamos.
                const isSubbotMsg = !!baileyMessage._subNum || !!this._subNum;
                const activeSock = sock; 

                if (!activeSock || !activeSock.user) {
                    // Solo caemos a global.conn si es un mensaje originalmente del bot principal
                    if (!isSubbotMsg && global.conn && global.conn.user) {
                        return await global.conn.sendMessage(this.from, { text: text, mentions: options?.mentions || [] }, { quoted: baileyMessage });
                    }
                    return; // Si el subbot se desconectó, no responde. Punto.
                }

                const mentions = options?.mentions || [];
                
                await activeSock.sendMessage(
                    this.from,
                    { text: text, mentions: mentions },
                    { quoted: baileyMessage }
                );
            } catch (error) {
                if (error.message?.includes('No sessions') || error.message?.includes('no sessions')) {
                    return;
                }
                console.error('[reply] Error:', error.message);
                throw error;
            }
        },

        delete: async function () {
            try {
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) return;
                await activeSock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage };