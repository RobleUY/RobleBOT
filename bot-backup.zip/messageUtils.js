'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    return '';
}

function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo  = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    const message = {
        id:          baileyMessage.key.id,
        from:        baileyMessage.key.remoteJid,
        key:         baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        sender:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        body:        getMessageText(baileyMessage),
        isGroup:     baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   baileyMessage.key.remoteJid,
                id:          contextInfo.stanzaId,
                participant: contextInfo.participant,
                fromMe:      false
            },
            id:      contextInfo.stanzaId,
            sender:  contextInfo.participant,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                const activeSock = this._sock || global.conn;

                // Verificar que el sock esté realmente activo
                if (!activeSock?.user) {
                    console.error('Socket no disponible para reply');
                    return;
                }

                const shouldQuote = options?.quoted !== false;
                const mentions = options?.mentions || [];

                // Intentar enviar con quote primero
                if (shouldQuote) {
                    try {
                        await activeSock.sendMessage(
                            this.from, 
                            { text: text, mentions: mentions }, 
                            { quoted: baileyMessage }
                        );
                        return;
                    } catch (quoteError) {
                        // Si falla con quote, intentar sin quote
                        console.log('⚠️ Error con quote, reintentando sin quote');
                    }
                }

                // Intentar sin quote
                try {
                    await activeSock.sendMessage(this.from, { 
                        text: text,
                        mentions: mentions
                    });
                } catch (error) {
                    // Si todo falla, solo registrar el error
                    if (!error.message?.includes('Connection Closed')) {
                        console.error('Error reply final:', error.message);
                    }
                }
            } catch (error) {
                if (!error.message?.includes('Connection Closed')) {
                    console.error('Error reply:', error.message);
                }
            }
        },

        delete: async function () {
            try {
                if (!sock?.user) return;
                await sock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage };