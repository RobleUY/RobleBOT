'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';

    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage) return msg.imageMessage.caption || '«imagen»';
    if (msg.videoMessage) return msg.videoMessage.caption || '«video»';
    if (msg.documentMessage) return msg.documentMessage.caption || '«documento»';
    if (msg.stickerMessage) return '«sticker»';
    if (msg.audioMessage) return '«audio»';
    if (msg.contactMessage) return '«contacto»';
    if (msg.locationMessage) return '«ubicación»';
    if (msg.contactsArrayMessage) return '«contacto»';
    if (msg.productMessage) return '«producto»';
    if (msg.buttonsResponseMessage?.selectedButtonId) return `«respuesta botón: ${msg.buttonsResponseMessage.selectedButtonId}»`;
    if (msg.listResponseMessage?.title) return `«respuesta lista: ${msg.listResponseMessage.title}»`;
    if (msg.templateButtonReplyMessage?.selectedId) return `«respuesta plantilla: ${msg.templateButtonReplyMessage.selectedId}»`;

    return '';
}

function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo  = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    const message = {
        id:          baileyMessage.key.id,
        from:        baileyMessage.key.remoteJid,
        key:         baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        sender:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        body:        getMessageText(baileyMessage),
        isGroup:     baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,
        hasQuotedMsg: !!quotedMessage,
        _data: { quotedMsg: quotedMessage || null },
        _sock:       sock,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   baileyMessage.key.remoteJid,
                id:          contextInfo.stanzaId || quotedMessage?.key?.id || null,
                participant: contextInfo.participant || baileyMessage.key.participant,
                fromMe:      false
            },
            id:      contextInfo.stanzaId,
            sender:  contextInfo.participant,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                // ⚠️ CAMBIO CRÍTICO: Si el mensaje tiene un _sock asignado, DEBE usar ese.
                // Si ese _sock perdió su user, no hacemos fallback al principal, lo cancelamos.
                const isSubbotMsg = !!baileyMessage._subNum || !!this._subNum;
                const activeSock = sock; 

                if (!activeSock || !activeSock.user) {
                    // Solo caemos a global.conn si es un mensaje originalmente del bot principal
                    if (!isSubbotMsg && global.conn && global.conn.user) {
                        return await global.conn.sendMessage(this.from, { text: text, mentions: options?.mentions || [] }, { quoted: baileyMessage });
                    }
                    return; // Si el subbot se desconectó, no responde. Punto.
                }

                const mentions = options?.mentions || [];
                
                await activeSock.sendMessage(
                    this.from,
                    { text: text, mentions: mentions },
                    { quoted: baileyMessage }
                );
            } catch (error) {
                if (error.message?.includes('No sessions') || error.message?.includes('no sessions')) {
                    return;
                }
                console.error('[reply] Error:', error.message);
                throw error;
            }
        },

        delete: async function () {
            try {
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) return;
                await activeSock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage };