'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    return '';
}

function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo  = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    const message = {
        id:          baileyMessage.key.id,
        from:        baileyMessage.key.remoteJid,
        key:         baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        sender:      baileyMessage.key.participant || baileyMessage.key.remoteJid,
        body:        getMessageText(baileyMessage),
        isGroup:     baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   baileyMessage.key.remoteJid,
                id:          contextInfo.stanzaId,
                participant: contextInfo.participant,
                fromMe:      false
            },
            id:      contextInfo.stanzaId,
            sender:  contextInfo.participant,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                // Usar el socket que recibió este mensaje (capturado en el closure),
                // NO global.conn — que puede haber sido pisado por un subbot concurrente
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) {
                    console.error('[reply] Socket no disponible');
                    return;
                }

                const mentions = options?.mentions || [];
                
                // Enviar con quote siempre (como la versión vieja que funcionaba)
                await activeSock.sendMessage(
                    this.from,
                    { text: text, mentions: mentions },
                    { quoted: baileyMessage }
                );
            } catch (error) {
                console.error('[reply] Error:', error.message);
                throw error; // Re-lanzar para que el handler sepa que falló
            }
        },

        delete: async function () {
            try {
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) return;
                await activeSock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage };