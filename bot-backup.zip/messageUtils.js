'use strict';

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';

    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage) return msg.imageMessage.caption || '«imagen»';
    if (msg.videoMessage) return msg.videoMessage.caption || '«video»';
    if (msg.documentMessage) return msg.documentMessage.caption || '«documento»';
    if (msg.stickerMessage) return '«sticker»';
    if (msg.audioMessage) return '«audio»';
    if (msg.contactMessage) return '«contacto»';
    if (msg.locationMessage) return '«ubicación»';
    if (msg.contactsArrayMessage) return '«contacto»';
    if (msg.productMessage) return '«producto»';
    if (msg.buttonsResponseMessage?.selectedButtonId) return `«respuesta botón: ${msg.buttonsResponseMessage.selectedButtonId}»`;
    if (msg.listResponseMessage?.title) return `«respuesta lista: ${msg.listResponseMessage.title}»`;
    if (msg.templateButtonReplyMessage?.selectedId) return `«respuesta plantilla: ${msg.templateButtonReplyMessage.selectedId}»`;

    return '';
}

if (!global.subbotLidMap) global.subbotLidMap = new Map();

function getSelfJid(sock) {
    if (sock?.user?.id) return sock.user.id;
    if (sock?._phoneNumber) {
        const cleanP = String(sock._phoneNumber).replace(/\D/g, '');
        if (cleanP) return `${cleanP}@s.whatsapp.net`;
    }
    if (global.conn?.user?.id) return global.conn.user.id;
    return null;
}

function getSelfLid(sock) {
    if (sock?.user?.lid) return sock.user.lid;
    if (sock?._lid) return sock._lid;
    if (global.conn?.user?.lid) return global.conn.user.lid;
    return null;
}

function cleanDigits(val) {
    if (!val) return '';
    return String(val).split('@')[0].split(':')[0].replace(/\D/g, '');
}

function isSamePhone(num1, num2) {
    const d1 = cleanDigits(num1);
    const d2 = cleanDigits(num2);
    if (!d1 || !d2) return false;
    if (d1 === d2) return true;

    // Normalización de prefijos Argentina (549 vs 54)
    const norm1 = d1.startsWith('549') ? '54' + d1.slice(3) : d1;
    const norm2 = d2.startsWith('549') ? '54' + d2.slice(3) : d2;
    if (norm1 === norm2) return true;

    // Coincidencia por sufijo (mínimo 8 dígitos)
    if (d1.length >= 8 && d2.length >= 8 && (d1.endsWith(d2) || d2.endsWith(d1))) return true;

    return false;
}

function getAllSubbotSocks() {
    const socks = [];
    if (Array.isArray(global.subConns)) {
        for (const s of global.subConns) {
            if (s && !socks.includes(s)) socks.push(s);
        }
    }
    try {
        const serbot = require('./plugins/SUBBOTS/subbot-serbot');
        if (serbot?.activeSocks && typeof serbot.activeSocks.values === 'function') {
            for (const s of serbot.activeSocks.values()) {
                if (s && !socks.includes(s)) socks.push(s);
            }
        }
    } catch (_) {}
    return socks;
}

function canBotRespondInPrivate(targetBot, remoteJid) {
    if (!targetBot || !targetBot.sock || !targetBot.sock.user) {
        return false;
    }

    if (targetBot.isMain) {
        return !!(global.conn && global.conn.user);
    }

    if (targetBot.isSubbot) {
        const subNum = targetBot.subNum;

        try {
            const subBotModule = require('./plugins/SUBBOTS/subbots-onoff.js');

            if (subNum && typeof subBotModule.isSubBotRespondsInPriv === 'function') {
                if (!subBotModule.isSubBotRespondsInPriv(subNum)) {
                    return false;
                }
            }

            if (subNum && typeof subBotModule.isSubBotEnabled === 'function') {
                if (!subBotModule.isSubBotEnabled(remoteJid, subNum)) {
                    return false;
                }
            }
        } catch (e) {
            console.error('[canBotRespondInPrivate] Error verificando subbot:', e.message);
        }

        return true;
    }

    return false;
}

function shouldIgnoreFromMePrivateMessage(baileyMessage, currentSock) {
    if (!baileyMessage?.key?.fromMe) return false;

    const remoteJid = baileyMessage.key.remoteJid || '';
    if (!remoteJid || remoteJid.endsWith('@g.us')) return false;

    const destNum = cleanDigits(remoteJid);
    if (!destNum) return false;

    const currentSelfJid = getSelfJid(currentSock);
    const currentBotNum = cleanDigits(currentSelfJid);
    const currentSelfLid = cleanDigits(getSelfLid(currentSock));

    // Si nos mandamos un mensaje a nosotros mismos en nuestro propio número o propio LID, no ignorar
    if (currentBotNum && isSamePhone(currentBotNum, destNum)) return false;
    if (currentSelfLid && isSamePhone(currentSelfLid, destNum)) return false;

    let targetBot = null;

    // 1. ¿Destinatario es el bot principal (conectado)?
    if (global.conn?.user?.id) {
        if (isSamePhone(global.conn.user.id, destNum) || isSamePhone(global.conn.user.lid, destNum)) {
            targetBot = { isMain: true, isSubbot: false, sock: global.conn };
        }
    }

    // 2. ¿Destinatario es un subbot registrado en global.subbotLidMap?
    if (!targetBot && global.subbotLidMap.has(destNum)) {
        const conn = global.subbotLidMap.get(destNum);
        if (conn && conn.user) {
            targetBot = {
                isMain: false,
                isSubbot: true,
                subNum: conn._subNum || cleanDigits(conn.user.id) || cleanDigits(conn._phoneNumber),
                sock: conn
            };
        }
    }

    // 3. ¿Destinatario es uno de los subbots conectados en global.subConns o activeSocks?
    if (!targetBot) {
        const allSubSocks = getAllSubbotSocks();
        for (const conn of allSubSocks) {
            const connUserNum = cleanDigits(conn?.user?.id);
            const connUserLid = cleanDigits(conn?.user?.lid);
            const connLid     = cleanDigits(conn?._lid);
            const connPhone   = cleanDigits(conn?._phoneNumber);
            const connSubNum  = cleanDigits(conn?._subNum);

            if (
                isSamePhone(connUserNum, destNum) ||
                isSamePhone(connUserLid, destNum) ||
                isSamePhone(connLid, destNum) ||
                isSamePhone(connPhone, destNum) ||
                (connSubNum && isSamePhone(connSubNum, destNum))
            ) {
                targetBot = {
                    isMain: false,
                    isSubbot: true,
                    subNum: conn._subNum || connUserNum || connPhone,
                    sock: conn
                };
                if (destNum) global.subbotLidMap.set(destNum, conn);
                break;
            }
        }
    }

    if (!targetBot) return false;

    return canBotRespondInPrivate(targetBot, remoteJid);
}

function createCompatibleMessage(baileyMessage, sock) {
    const msg = baileyMessage.message || {};
    const contextInfo = msg.contextInfo
        || msg.extendedTextMessage?.contextInfo
        || msg.extendedTextMessageV2?.contextInfo
        || msg.buttonsResponseMessage?.contextInfo
        || msg.listResponseMessage?.contextInfo
        || msg.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
        || msg.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
        || msg.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
        || msg.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
        || null;
    const quotedMessage = contextInfo?.quotedMessage || null;
    const quotedId = contextInfo?.stanzaId || quotedMessage?.key?.id || quotedMessage?.id || null;
    const quotedSender = contextInfo?.participant || quotedMessage?.key?.participant || quotedMessage?.participant || null;

    const selfJid = getSelfJid(sock);
    let messageSender;
    if (baileyMessage.key.participant) {
        messageSender = baileyMessage.key.participant;
    } else if (baileyMessage.key.fromMe) {
        messageSender = selfJid || baileyMessage.key.remoteJid;
    } else {
        messageSender = baileyMessage.key.remoteJid;
    }

    const message = {
        id:          baileyMessage.key.id,
        from:        baileyMessage.key.remoteJid,
        key:         baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author:      messageSender || baileyMessage.key.remoteJid,
        sender:      messageSender || baileyMessage.key.remoteJid,
        body:        getMessageText(baileyMessage),
        isGroup:     baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp:   baileyMessage.messageTimestamp,
        mentions:    contextInfo?.mentionedJid || null,
        _baileyMessage: baileyMessage,
        hasQuotedMsg: !!quotedMessage,
        _data: { quotedMsg: quotedMessage || null },
        _sock:       sock,

        quoted: quotedMessage ? {
            key: {
                remoteJid:   baileyMessage.key.remoteJid,
                id:          quotedId,
                participant: quotedSender || baileyMessage.key.participant,
                fromMe:      false
            },
            id:      quotedId,
            sender:  quotedSender,
            fromMe:  false,
            mtype:   Object.keys(quotedMessage)[0],
            download: async () => {
                const type = quotedMessage.imageMessage ? 'image'
                           : quotedMessage.videoMessage ? 'video' : null;
                if (!type) return null;
                const stream = await downloadContentFromMessage(
                    quotedMessage[`${type}Message`], type
                );
                let buffer = Buffer.alloc(0);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                return buffer;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function () {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function () {
                    const type = quotedMessage.imageMessage ? 'image'
                               : quotedMessage.videoMessage ? 'video' : null;
                    if (!type) return null;
                    const stream = await downloadContentFromMessage(
                        quotedMessage[`${type}Message`], type
                    );
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    return { data: buffer, mimetype: quotedMessage[`${type}Message`].mimetype };
                }
            };
        },

        reply: async function (text, options = {}) {
            try {
                const isSubbotMsg = !!baileyMessage._subNum || !!this._subNum;
                const activeSock = sock?.user ? sock : (!isSubbotMsg && global.conn?.user ? global.conn : null);

                if (!activeSock || !activeSock.user) {
                    return;
                }

                const mentions = options?.mentions || [];

                if (options?.skipPresence !== true) {
                    try {
                        await activeSock.sendPresenceUpdate('composing', this.from);
                    } catch (e) {}
                }

                if (options?.skipDelay !== true) {
                    const delayMs = Math.floor(Math.random() * 250) + 300;
                    await new Promise(resolve => setTimeout(resolve, delayMs));
                }

                return await activeSock.sendMessage(
                    this.from,
                    { text: text, mentions: mentions },
                    { quoted: baileyMessage }
                );
            } catch (error) {
                if (error.message?.includes('No sessions') || error.message?.includes('no sessions')) {
                    return;
                }
                if (error.message?.includes('Rate limit') || error.message?.includes('rate-overlimit')) {
                    throw error;
                }
                console.error('[reply] Error:', error.message);
                throw error;
            }
        },

        delete: async function () {
            try {
                const activeSock = sock?.user ? sock : global.conn;
                if (!activeSock?.user) return;
                await activeSock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (e) { /* silencioso */ }
        }
    };

    return message;
}

module.exports = { getMessageText, createCompatibleMessage, shouldIgnoreFromMePrivateMessage, canBotRespondInPrivate };