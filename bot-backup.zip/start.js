/**
 * start.js — Watchdog para RobleBOT
 * Lanza index.js como proceso hijo y lo reinicia automáticamente si cae.
 * Poné este archivo como MAIN FILE en HidenCloud.
 */

// Aumentar pool de hilos de Node.js a 128 para evitar que 70+ subbots bloqueen el DNS (getaddrinfo) y SQLite
process.env.UV_THREADPOOL_SIZE = process.env.UV_THREADPOOL_SIZE || '128';

const dns = require('dns');
try {
    dns.setDefaultResultOrder('ipv4first');
} catch (_) {}

const { spawn } = require('child_process');
const path = require('path');

const INITIAL_RESTART_DELAY_MS = 5000;
const MAX_RESTART_DELAY_MS = 60000;   // Máximo 60 segundos entre reinicios
const RESTART_LOOP_DETECTION_WINDOW = 5 * 60 * 1000; // 5 minutos
const MAX_RESTARTS_IN_WINDOW = 8; // Máximo 8 reinicios en 5 minutos

let restarts = 0;
let isShuttingDown = false;
let restartHistory = []; // Timestamps de reinicios recientes
let currentRestartDelay = INITIAL_RESTART_DELAY_MS;

function shouldStopRestartLoop() {
    const now = Date.now();
    // Limpiar reinicios fuera de la ventana
    restartHistory = restartHistory.filter(ts => now - ts < RESTART_LOOP_DETECTION_WINDOW);
    
    if (restartHistory.length >= MAX_RESTARTS_IN_WINDOW) {
        console.error(
            `\n❌ RESTART LOOP DETECTADO: ${restartHistory.length} reinicios en ${RESTART_LOOP_DETECTION_WINDOW / 1000}s\n` +
            `   El bot está en un bucle de fallos. DETENIENDO reinicios automáticos.\n` +
            `   Por favor:\n` +
            `   1. Revisa los logs del bot para encontrar el error.\n` +
            `   2. Reinicia manualmente cuando esté listo.\n`
        );
        return true;
    }
    
    return false;
}

function getNextRestartDelay() {
    const now = Date.now();
    restartHistory = restartHistory.filter(ts => now - ts < RESTART_LOOP_DETECTION_WINDOW);
    
    // Backoff exponencial: cuantos más reinicios, más espera
    let delayMultiplier = Math.min(restartHistory.length, 8);
    currentRestartDelay = Math.min(
        INITIAL_RESTART_DELAY_MS * delayMultiplier,
        MAX_RESTART_DELAY_MS
    );
    
    return currentRestartDelay;
}

function startBot() {
    if (isShuttingDown) return;

    console.log(`\n▶️  Iniciando RobleBOT... (reinicio #${restarts})`);

    const child = spawn(process.execPath, ['--expose-gc', BOT_FILE], {
        // Usamos 'pipe' para capturar stdout/stderr del proceso hijo
        stdio: ['ignore', 'pipe', 'pipe'],
        env: process.env,
        cwd: __dirname
    });

    // Capturar salida del proceso hijo
    if (child.stdout) {
        child.stdout.on('data', (chunk) => {
            try {
                const text = chunk.toString();
                // Mostrar en la consola del padre
                process.stdout.write(text);
            } catch (e) {}
        });
    }

    if (child.stderr) {
        child.stderr.on('data', (chunk) => {
            try {
                const text = chunk.toString();
                process.stderr.write(text);
            } catch (e) {}
        });
    }

    child.on('exit', (code, signal) => {
        if (isShuttingDown) return;

        if (code === 0) {
            console.log('\n✅ Bot detenido limpiamente (exit 0). No se reinicia.');
            process.exit(0);
            return;
        }

        // Detectar bucle de reinicios
        if (shouldStopRestartLoop()) {
            console.error('\n🛑 Watchdog DETENIDO por seguridad. Requiere reinicio manual.');
            process.exit(1);
            return;
        }

        // Calcular delay con backoff
        const delay = getNextRestartDelay();
        restarts++;
        restartHistory.push(Date.now());
        
        const recentRestarts = restartHistory.length;
        console.log(
            `\n⚠️  Bot cayó (código: ${code ?? signal}).\n` +
            `   Reiniciando en ${delay / 1000}s...\n` +
            `   (${recentRestarts}/${MAX_RESTARTS_IN_WINDOW} reinicios en ventana de ${RESTART_LOOP_DETECTION_WINDOW / 60000}min)`
        );

        // 📊 Información de diagnóstico
        console.log(
            `\n📊 ESTADO DE REINICIOS:\n` +
            `   Total reinicios: ${restarts}\n` +
            `   En últimos 5min: ${recentRestarts}/${MAX_RESTARTS_IN_WINDOW}\n` +
            `   Próximo delay: ${delay / 1000}s\n`
        );

        setTimeout(startBot, delay);
    });

    child.on('error', (err) => {
        console.error('\n❌ Error al lanzar el bot:', err.message);
        
        if (shouldStopRestartLoop()) {
            console.error('\n🛑 Watchdog DETENIDO por seguridad. Requiere reinicio manual.');
            process.exit(1);
            return;
        }
        
        const delay = getNextRestartDelay();
        restarts++;
        restartHistory.push(Date.now());
        
        setTimeout(startBot, delay);
    });
}

// Si el panel de HidenCloud manda SIGTERM (Stop), apagar limpiamente sin reiniciar
process.on('SIGTERM', async () => {
    console.log('\n🛑 SIGTERM recibido — apagando sin reiniciar.');
    isShuttingDown = true;
    process.exit(0);
});

process.on('SIGINT', async () => {
    console.log('\n🛑 SIGINT recibido — apagando sin reiniciar.');
    isShuttingDown = true;
    process.exit(0);
});

const BOT_FILE = path.join(__dirname, 'index.js');
startBot();
