/**
 * start.js — Watchdog para RobleBOT
 * Lanza index.js como proceso hijo y lo reinicia automáticamente si cae.
 * Poné este archivo como MAIN FILE en HidenCloud.
 */

const { spawn } = require('child_process');
const path = require('path');

const RESTART_DELAY_MS = 5000;
const BOT_FILE = path.join(__dirname, 'index.js');

let restarts = 0;
let isShuttingDown = false;

function startBot() {
    if (isShuttingDown) return;

    console.log(`▶️  Iniciando RobleBOT... (reinicio #${restarts})`);

    const child = spawn(process.execPath, ['--expose-gc', BOT_FILE], {
        stdio: 'inherit',  // comparte stdin/stdout/stderr con el proceso padre (visible en consola HidenCloud)
        env: process.env,
        cwd: __dirname
    });

    child.on('exit', (code, signal) => {
        if (isShuttingDown) return;

        if (code === 0) {
            console.log('🛑 Bot detenido limpiamente (exit 0). No se reinicia.');
            process.exit(0);
            return;
        }

        restarts++;
        console.log(`⚠️  Bot cayó (código: ${code ?? signal}). Reiniciando en ${RESTART_DELAY_MS / 1000}s... (reinicio #${restarts})`);
        setTimeout(startBot, RESTART_DELAY_MS);
    });

    child.on('error', (err) => {
        console.error('❌ Error al lanzar el bot:', err.message);
        restarts++;
        setTimeout(startBot, RESTART_DELAY_MS);
    });
}

// Si el panel de HidenCloud manda SIGTERM (Stop), apagar limpiamente sin reiniciar
process.on('SIGTERM', () => {
    console.log('🛑 SIGTERM recibido — apagando sin reiniciar.');
    isShuttingDown = true;
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('🛑 SIGINT recibido — apagando sin reiniciar.');
    isShuttingDown = true;
    process.exit(0);
});

startBot();
