/**
 * Sistema de Coordinación de Bots (SIMPLIFICADO)
 * 
 * ✅ SIN SISTEMA DE PRIORIDAD
 * - Todos los bots responden libremente en grupos
 * - En chats privados, cada bot responde solo a sus propios mensajes
 * 
 * Este módulo mantiene funciones básicas de caché para compatibilidad
 */

const chalk = require('chalk');

// ═══════════════════════════════════════════════════════════════════
// REGISTRO DE MENSAJES (SIMPLIFICADO - SIN BLOQUEO)
// Mantiene compatibilidad con código existente pero no bloquea respuestas
// ═══════════════════════════════════════════════════════════════════
const respondedMessages = new Map(); // messageId -> { botId, timestamp }
const RESPONDED_TTL = 15000; // 15 segundos

// Limpieza automática
setInterval(() => {
    const now = Date.now();
    for (const [key, val] of respondedMessages.entries()) {
        if (now - val.timestamp > RESPONDED_TTL) respondedMessages.delete(key);
    }
}, 10000);

/**
 * Intenta reclamar el derecho a responder un mensaje de grupo.
 * ✅ SIN BLOQUEO: Siempre retorna true para permitir que todos respondan
 * @param {string} messageId
 * @param {string} botId - identificador del bot que intenta reclamar
 * @returns {boolean} true (siempre permite responder)
 */
function claimMessage(messageId, botId) {
    // ✅ Registrar pero no bloquear
    if (messageId) {
        respondedMessages.set(messageId, { botId, timestamp: Date.now() });
    }
    return true; // Siempre permitir
}

/**
 * Verifica si un mensaje ya fue reclamado (sin bloquear).
 * ✅ SIN BLOQUEO: Siempre retorna false para permitir que todos respondan
 * @param {string} messageId
 * @returns {boolean} false (nunca bloquea)
 */
function wasMessageResponded(messageId) {
    // ✅ No bloquear nunca
    return false;
}

// ═══════════════════════════════════════════════════════════════════
// CACHÉ DE METADATA DE GRUPOS
// ═══════════════════════════════════════════════════════════════════

/**
 * Libera un claim previo si este bot lo hizo y la prioridad dice que no debe procesar.
 * @param {string} messageId
 * @param {string} botId
 */
function releaseMessage(messageId, botId) {
    const entry = respondedMessages.get(messageId);
    if (entry && entry.botId === botId) {
        respondedMessages.delete(messageId);
    }
}

/** @deprecated Usar claimMessage en su lugar */
function markMessageAsResponded(messageId, botId) {
    claimMessage(messageId, botId);
}

const METADATA_CACHE = new Map();
const CACHE_DURATION = 60000; // 1 minuto (solo para rate limit, no para permisos)

// Limpieza automática del caché cada 10 minutos
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of METADATA_CACHE.entries()) {
        if (now - value.timestamp > CACHE_DURATION) {
            METADATA_CACHE.delete(key);
        }
    }
}, 600000);

/**
 * Obtener metadata de grupo con caché
 */
async function getGroupMetadataCached(sock, groupJid) {
    try {
        const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
        const cached = METADATA_CACHE.get(cacheKey);
        
        if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
            return cached.data;
        }
        
        const metadata = await sock.groupMetadata(groupJid);
        METADATA_CACHE.set(cacheKey, { data: metadata, timestamp: Date.now() });
        
        return metadata;
    } catch (error) {
        const errorCode = error?.data || error?.output?.statusCode;
        
        // Rate limit - intentar usar caché
        if (error.message?.includes('rate-overlimit')) {
            console.log(chalk.yellow('[BotPriority] ⏳ Rate limit, usando caché'));
            const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
            const cached = METADATA_CACHE.get(cacheKey);
            if (cached) return cached.data;
        }
        
        // Error 403 = Bot no está en el grupo o sin permisos
        if (errorCode === 403 || error?.message?.includes('forbidden')) {
            // NO loguear como error, es esperado cuando un bot no está en un grupo
            // Solo retornar null para que el sistema de prioridades lo maneje
            return null;
        }
        
        // Otros errores: loguear solo si no son de red temporal
        if (!error.message?.includes('ECONNRESET') && !error.message?.includes('ETIMEDOUT')) {
            console.log(chalk.yellow(`[BotPriority] ⚠️ Error obteniendo metadata: ${error.message}`));
        }
        
        return null;
    }
}

/**
 * Limpiar caché manualmente
 */
function clearCache() {
    METADATA_CACHE.clear();
    console.log(chalk.cyan('[BotPriority] 🧹 Caché limpiado'));
}

/**
 * Verifica si un bot puede enviar mensajes en un grupo
 * @param {Object} sock - Socket del bot
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si puede enviar, false si no
 */
async function canBotSendInGroup(sock, groupJid) {
    try {
        if (!sock?.user) return false;
        
        // Obtener metadata del grupo CON CACHÉ
        const groupMeta = await getGroupMetadataCached(sock, groupJid);
        if (!groupMeta) return false;
        
        const botNumber = sock.user.id.split('@')[0].split(':')[0];
        const botParticipant = groupMeta.participants.find(p => 
            p.id.split('@')[0].split(':')[0] === botNumber
        );
        
        // Si el bot no está en el grupo, no puede enviar
        if (!botParticipant) return false;
        
        // Verificar si el grupo está en modo "solo admins"
        const isAnnounce = groupMeta.announce === true;
        
        if (isAnnounce) {
            // Si está en modo solo admins, verificar si el bot es admin
            const isAdmin = botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin';
            return isAdmin;
        }
        
        // Si no está en modo solo admins, puede enviar
        return true;
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando permisos:'), error.message);
        return false;
    }
}

/**
 * Verifica si el bot oficial está en el grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si está, false si no
 */
async function isMainBotInGroup(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        if (!mainBotNum) return false;
        
        const mainSock = global.conn;
        if (!mainSock?.user) return false;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) return false;
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        return participantNums.includes(mainBotNum);
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando bot oficial:'), error.message);
        return false;
    }
}

/**
 * Determina si un bot debe procesar un mensaje
 * ✅ SIN SISTEMA DE PRIORIDAD: Siempre retorna true
 * @param {Object} sock - Socket del bot actual
 * @param {number|null} subBotNum - Número del subbot (null si es el bot oficial)
 * @param {string} chatJid - JID del chat
 * @param {boolean} isGroup - Si es un grupo
 * @returns {Promise<Object>} - { shouldProcess: boolean, reason: string }
 */
async function shouldBotProcessMessage(sock, subBotNum, chatJid, isGroup) {
    try {
        // ✅ SIN PRIORIDAD: Todos los bots procesan todos los mensajes
        // En grupos: todos responden
        // En privado: cada bot recibe solo sus propios mensajes (Baileys lo maneja)
        
        if (isGroup) {
            return { 
                shouldProcess: true, 
                reason: 'Grupo - todos los bots responden libremente' 
            };
        } else {
            return { 
                shouldProcess: true, 
                reason: 'Chat privado - mensaje recibido directamente' 
            };
        }
        
    } catch (error) {
        console.error(chalk.red('[BotCoordination] Error en shouldBotProcessMessage:'), error.message);
        // En caso de error, permitir procesar para no bloquear el bot
        return { shouldProcess: true, reason: 'Error en verificación - procesando por seguridad' };
    }
}

/**
 * Obtiene información de prioridad de todos los bots en un grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<Object>} - Información de prioridad
 */
async function getGroupBotPriority(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        const mainSock = global.conn;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) {
            return { error: 'No se pudo obtener metadata del grupo' };
        }
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        const mainBotInGroup = mainBotNum && participantNums.includes(mainBotNum);
        const mainCanSend = mainBotInGroup ? await canBotSendInGroup(mainSock, groupJid) : false;
        
        const subbotsInGroup = (global.subConns || [])
            .filter(c => c.user && c._subNum != null)
            .filter(c => {
                const botNum = c.user.id.split('@')[0].split(':')[0];
                return participantNums.includes(botNum);
            })
            .sort((a, b) => a._subNum - b._subNum);
        
        const subbotsInfo = [];
        for (const subbot of subbotsInGroup) {
            const canSend = await canBotSendInGroup(subbot, groupJid);
            subbotsInfo.push({
                number: subbot._subNum,
                canSend: canSend,
                botNumber: subbot.user.id.split('@')[0].split(':')[0]
            });
        }
        
        return {
            mainBot: {
                present: mainBotInGroup,
                canSend: mainCanSend,
                number: mainBotNum
            },
            subbots: subbotsInfo,
            activeBotPriority: mainBotInGroup && mainCanSend 
                ? 'Bot oficial' 
                : subbotsInfo.find(s => s.canSend)?.number 
                    ? `SubBot #${subbotsInfo.find(s => s.canSend).number}` 
                    : 'Ninguno'
        };
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error en getGroupBotPriority:'), error.message);
        return { error: error.message };
    }
}

module.exports = {
    canBotSendInGroup,
    isMainBotInGroup,
    shouldBotProcessMessage,
    getGroupBotPriority,
    clearCache,
    claimMessage,
    releaseMessage,
    markMessageAsResponded,
    wasMessageResponded
};
