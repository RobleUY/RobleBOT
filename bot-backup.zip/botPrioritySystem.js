/**
 * Sistema de Prioridad de Bots
 * 
 * Gestiona la prioridad de respuesta entre bot oficial y subbots:
 * - Bot oficial = prioridad 0 (máxima)
 * - Subbots = prioridad 1, 2, 3... (menor número = mayor prioridad)
 * 
 * Reglas:
 * 1. Si el bot oficial está en el grupo y puede responder → subbots NO responden
 * 2. Si el bot oficial NO puede responder → responde el subbot con menor número
 * 3. Si ese subbot tampoco puede → intenta con el siguiente
 */

const chalk = require('chalk');

// ═══════════════════════════════════════════════════════════════════
// REGISTRO DE MENSAJES YA RESPONDIDOS EN GRUPOS
// Evita que múltiples bots/subbots respondan al mismo comando.
//
// Funciona como un mutex atómico: el primer bot que llama
// claimMessage() gana el derecho a responder. Los demás reciben
// false y se callan. Node.js es single-threaded, así que no hay
// race condition real entre llamadas síncronas.
// ═══════════════════════════════════════════════════════════════════
const respondedMessages = new Map(); // messageId -> { botId, timestamp }
const RESPONDED_TTL = 15000; // 15 segundos

// Limpieza automática
setInterval(() => {
    const now = Date.now();
    for (const [key, val] of respondedMessages.entries()) {
        if (now - val.timestamp > RESPONDED_TTL) respondedMessages.delete(key);
    }
}, 10000);

/**
 * Intenta reclamar el derecho a responder un mensaje de grupo.
 * Atómico: el primer llamador gana, los demás reciben false.
 * @param {string} messageId
 * @param {string} botId - identificador del bot que intenta reclamar
 * @returns {boolean} true si este bot puede responder, false si otro ya lo reclamó
 */
function claimMessage(messageId, botId) {
    if (!messageId) return true; // sin ID no podemos coordinar, dejar pasar
    const existing = respondedMessages.get(messageId);
    if (existing) {
        // Ya fue reclamado por otro bot
        if (Date.now() - existing.timestamp > RESPONDED_TTL) {
            // Expiró, este bot puede reclamar
            respondedMessages.set(messageId, { botId, timestamp: Date.now() });
            return true;
        }
        return false;
    }
    // Nadie lo reclamó aún — este bot lo reclama
    respondedMessages.set(messageId, { botId, timestamp: Date.now() });
    return true;
}

/**
 * Verifica si un mensaje ya fue reclamado (sin reclamar).
 * @param {string} messageId
 * @returns {boolean}
 */
function wasMessageResponded(messageId) {
    if (!messageId) return false;
    const entry = respondedMessages.get(messageId);
    if (!entry) return false;
    if (Date.now() - entry.timestamp > RESPONDED_TTL) {
        respondedMessages.delete(messageId);
        return false;
    }
    return true;
}

// ═══════════════════════════════════════════════════════════════════
// CACHÉ DE METADATA DE GRUPOS
// ═══════════════════════════════════════════════════════════════════

/**
 * Libera un claim previo si este bot lo hizo y la prioridad dice que no debe procesar.
 * @param {string} messageId
 * @param {string} botId
 */
function releaseMessage(messageId, botId) {
    const entry = respondedMessages.get(messageId);
    if (entry && entry.botId === botId) {
        respondedMessages.delete(messageId);
    }
}

/** @deprecated Usar claimMessage en su lugar */
function markMessageAsResponded(messageId, botId) {
    claimMessage(messageId, botId);
}

const METADATA_CACHE = new Map();
const CACHE_DURATION = 60000; // 1 minuto (solo para rate limit, no para permisos)

// Limpieza automática del caché cada 10 minutos
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of METADATA_CACHE.entries()) {
        if (now - value.timestamp > CACHE_DURATION) {
            METADATA_CACHE.delete(key);
        }
    }
}, 600000);

/**
 * Obtener metadata de grupo con caché
 */
async function getGroupMetadataCached(sock, groupJid) {
    try {
        const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
        const cached = METADATA_CACHE.get(cacheKey);
        
        console.log(`[BotPriority-Cache] Buscando metadata para ${groupJid}, cacheKey: ${cacheKey}`);
        
        if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
            console.log(`[BotPriority-Cache] ✓ Usando caché (${Math.floor((Date.now() - cached.timestamp) / 1000)}s antiguo)`);
            return cached.data;
        }
        
        console.log(`[BotPriority-Cache] ⚠️ Caché no disponible o expirado, obteniendo metadata fresca...`);
        const metadata = await sock.groupMetadata(groupJid);
        console.log(`[BotPriority-Cache] ✓ Metadata obtenida: ${metadata.participants.length} participantes`);
        METADATA_CACHE.set(cacheKey, { data: metadata, timestamp: Date.now() });
        
        return metadata;
    } catch (error) {
        const errorCode = error?.data || error?.output?.statusCode;
        
        console.log(`[BotPriority-Cache] ❌ Error obteniendo metadata: ${error.message} (código: ${errorCode})`);
        
        // Rate limit - intentar usar caché
        if (error.message?.includes('rate-overlimit')) {
            console.log(chalk.yellow('[BotPriority] ⏳ Rate limit, usando caché'));
            const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
            const cached = METADATA_CACHE.get(cacheKey);
            if (cached) {
                console.log(`[BotPriority-Cache] ✓ Usando caché antiguo por rate limit`);
                return cached.data;
            }
        }
        
        // Error 403 = Bot no está en el grupo o sin permisos
        if (errorCode === 403 || error?.message?.includes('forbidden')) {
            // NO loguear como error, es esperado cuando un bot no está en un grupo
            // Solo retornar null para que el sistema de prioridades lo maneje
            console.log(`[BotPriority-Cache] ⚠️ Error 403 - bot no tiene acceso al grupo`);
            return null;
        }
        
        // Otros errores: loguear solo si no son de red temporal
        if (!error.message?.includes('ECONNRESET') && !error.message?.includes('ETIMEDOUT')) {
            console.log(chalk.yellow(`[BotPriority] ⚠️ Error obteniendo metadata: ${error.message}`));
        }
        
        return null;
    }
}

/**
 * Limpiar caché manualmente
 */
function clearCache() {
    METADATA_CACHE.clear();
    console.log(chalk.cyan('[BotPriority] 🧹 Caché limpiado'));
}

/**
 * Verifica si un bot puede enviar mensajes en un grupo
 * @param {Object} sock - Socket del bot
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si puede enviar, false si no
 */
async function canBotSendInGroup(sock, groupJid) {
    try {
        if (!sock?.user) return false;
        
        // Obtener metadata del grupo CON CACHÉ
        const groupMeta = await getGroupMetadataCached(sock, groupJid);
        if (!groupMeta) return false;
        
        const botNumber = sock.user.id.split('@')[0].split(':')[0];
        const botParticipant = groupMeta.participants.find(p => 
            p.id.split('@')[0].split(':')[0] === botNumber
        );
        
        // Si el bot no está en el grupo, no puede enviar
        if (!botParticipant) return false;
        
        // Verificar si el grupo está en modo "solo admins"
        const isAnnounce = groupMeta.announce === true;
        
        if (isAnnounce) {
            // Si está en modo solo admins, verificar si el bot es admin
            const isAdmin = botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin';
            return isAdmin;
        }
        
        // Si no está en modo solo admins, puede enviar
        return true;
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando permisos:'), error.message);
        return false;
    }
}

/**
 * Verifica si el bot oficial está en el grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si está, false si no
 */
async function isMainBotInGroup(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        if (!mainBotNum) return false;
        
        const mainSock = global.conn;
        if (!mainSock?.user) return false;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) return false;
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        return participantNums.includes(mainBotNum);
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando bot oficial:'), error.message);
        return false;
    }
}

/**
 * Determina si un bot debe procesar un mensaje según la prioridad
 * @param {Object} sock - Socket del bot actual
 * @param {number|null} subBotNum - Número del subbot (null si es el bot oficial)
 * @param {string} chatJid - JID del chat
 * @param {boolean} isGroup - Si es un grupo
 * @returns {Promise<Object>} - { shouldProcess: boolean, reason: string }
 */
async function shouldBotProcessMessage(sock, subBotNum, chatJid, isGroup) {
    try {
        console.log(`[BotPriority] Verificando: subBotNum=${subBotNum}, chatJid=${chatJid}, isGroup=${isGroup}`);
        
        // Si es el bot oficial (subBotNum === null), siempre procesa (prioridad máxima)
        if (subBotNum === null || subBotNum === undefined) {
            console.log(`[BotPriority] ✅ Bot oficial - prioridad máxima`);
            return { shouldProcess: true, reason: 'Bot oficial - prioridad máxima' };
        }
        
        // En chats privados: cada bot responde solo a los mensajes que llegaron a SU socket.
        // Baileys ya garantiza esto — si el mensaje llegó al socket del subbot,
        // es porque el usuario le escribió directamente a ese subbot.
        // El bot principal tiene su propio socket y recibe sus propios mensajes.
        if (!isGroup) {
            console.log(`[BotPriority] ✅ Chat privado - SubBot #${subBotNum} procesa`);
            return { shouldProcess: true, reason: `Chat privado - mensaje recibido por SubBot #${subBotNum} directamente` };
        }
        
        // ═══════════════════════════════════════════════════════════════
        // LÓGICA DE PRIORIDAD EN GRUPOS
        // ═══════════════════════════════════════════════════════════════
        
        // 🔑 PASO 1: Verificar si ESTE bot está en el grupo
        // Si no está, no debe intentar procesar nada
        console.log(`[BotPriority] 📋 Obteniendo metadata del grupo ${chatJid}...`);
        let thisGroupMeta = await getGroupMetadataCached(sock, chatJid);
        if (!thisGroupMeta) {
            // Este bot NO está en el grupo o no tiene acceso
            console.log(`[BotPriority] ❌ SubBot #${subBotNum} no tiene acceso al grupo (metadata null)`);
            return { 
                shouldProcess: false, 
                reason: `SubBot #${subBotNum} no está en este grupo` 
            };
        }
        console.log(`[BotPriority] ✓ Metadata obtenida: ${thisGroupMeta.participants.length} participantes`);
        
        const thisBotNumber = sock.user?.id?.split('@')[0]?.split(':')[0];
        const thisBotInGroup = thisGroupMeta.participants.some(p => 
            p.id.split('@')[0].split(':')[0] === thisBotNumber
        );
        
        console.log(`[BotPriority] 🔍 Verificando participación:`);
        console.log(`[BotPriority]   - Número del SubBot #${subBotNum}: ${thisBotNumber}`);
        console.log(`[BotPriority]   - Participantes en grupo (${thisGroupMeta.participants.length}):`);
        thisGroupMeta.participants.forEach(p => {
            const pNum = p.id.split('@')[0].split(':')[0];
            console.log(`[BotPriority]     • ${pNum} ${pNum === thisBotNumber ? '← ESTE BOT' : ''}`);
        });
        console.log(`[BotPriority]   - ¿Bot en grupo? ${thisBotInGroup}`);
        
        if (!thisBotInGroup) {
            // El bot no está en la lista de participantes del caché.
            // Esto puede ser porque:
            // 1. El bot realmente no está en el grupo
            // 2. El caché está desactualizado (el bot se unió después)
            // 
            // Solución: Limpiar el caché y obtener metadata fresca, luego verificar de nuevo
            console.log(`[BotPriority] ⚠️ Bot no encontrado en caché, limpiando y reintentando...`);
            const cacheKey = `${chatJid}_${sock.user?.id || 'unknown'}`;
            METADATA_CACHE.delete(cacheKey);
            
            // Obtener metadata fresca (sin caché)
            let freshMeta;
            try {
                freshMeta = await sock.groupMetadata(chatJid);
                METADATA_CACHE.set(cacheKey, { data: freshMeta, timestamp: Date.now() });
                console.log(`[BotPriority] ✓ Metadata fresca obtenida: ${freshMeta.participants.length} participantes`);
            } catch (e) {
                console.log(`[BotPriority] ❌ Error obteniendo metadata fresca: ${e.message}`);
                return { 
                    shouldProcess: false, 
                    reason: `SubBot #${subBotNum} no es participante del grupo (error verificando)` 
                };
            }
            
            // Verificar de nuevo con metadata fresca
            const thisBotInGroupFresh = freshMeta.participants.some(p => 
                p.id.split('@')[0].split(':')[0] === thisBotNumber
            );
            
            console.log(`[BotPriority] 🔍 Verificación con metadata fresca:`);
            console.log(`[BotPriority]   - Participantes (${freshMeta.participants.length}):`);
            freshMeta.participants.forEach(p => {
                const pNum = p.id.split('@')[0].split(':')[0];
                console.log(`[BotPriority]     • ${pNum} ${pNum === thisBotNumber ? '← ESTE BOT' : ''}`);
            });
            console.log(`[BotPriority]   - ¿Bot en grupo? ${thisBotInGroupFresh}`);
            
            if (!thisBotInGroupFresh) {
                console.log(`[BotPriority] ❌ SubBot #${subBotNum} (${thisBotNumber}) confirmado NO participante`);
                return { 
                    shouldProcess: false, 
                    reason: `SubBot #${subBotNum} no es participante del grupo` 
                };
            }
            
            // Actualizar la referencia para usar metadata fresca en el resto de la función
            thisGroupMeta = freshMeta;
            console.log(`[BotPriority] ✅ SubBot #${subBotNum} confirmado como participante (metadata fresca)`);
        }
        
        console.log(`[BotPriority] ✓ SubBot #${subBotNum} está en el grupo`);
        
        const mainBotNum = global.mainBotNumber;
        
        // 2. Verificar si el bot oficial está en el grupo
        const mainBotInGroup = await isMainBotInGroup(chatJid);
        console.log(`[BotPriority] Bot oficial en grupo: ${mainBotInGroup}`);
        
        if (mainBotInGroup) {
            // 3. Verificar si el bot oficial puede responder
            const mainSock = global.conn;
            const mainCanSend = await canBotSendInGroup(mainSock, chatJid);
            console.log(`[BotPriority] Bot oficial puede enviar: ${mainCanSend}`);
            
            if (mainCanSend) {
                // Bot oficial puede responder → subbots NO procesan
                console.log(`[BotPriority] ❌ SubBot #${subBotNum} cede prioridad al bot oficial`);
                return { 
                    shouldProcess: false, 
                    reason: `Bot oficial presente y puede responder - SubBot #${subBotNum} cede prioridad` 
                };
            } else {
                // Bot oficial NO puede responder → verificar prioridad entre subbots
                console.log(chalk.yellow(`[BotPriority] Bot oficial sin permisos en grupo - SubBots toman control`));
            }
        }
        
        // 4. Bot oficial no está o no puede responder → verificar prioridad entre subbots
        const participantNums = thisGroupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        // Obtener todos los subbots que están en el grupo
        const subbotsInGroup = (global.subConns || [])
            .filter(c => c.user && c._subNum != null)
            .filter(c => {
                const botNum = c.user.id.split('@')[0].split(':')[0];
                return participantNums.includes(botNum);
            })
            .sort((a, b) => a._subNum - b._subNum); // Ordenar por número ascendente
        
        console.log(`[BotPriority] Subbots en grupo: ${subbotsInGroup.map(s => `#${s._subNum}`).join(', ')}`);
        
        if (subbotsInGroup.length === 0) {
            console.log(`[BotPriority] ✅ SubBot #${subBotNum} es el único subbot`);
            return { shouldProcess: true, reason: 'Único subbot en el grupo' };
        }
        
        // 5. Verificar si este subbot tiene la mayor prioridad (menor número)
        const highestPrioritySubBot = subbotsInGroup[0];
        console.log(`[BotPriority] SubBot con mayor prioridad: #${highestPrioritySubBot._subNum}`);
        
        if (highestPrioritySubBot._subNum === subBotNum) {
            // Este subbot tiene la mayor prioridad, verificar si puede enviar
            const canSend = await canBotSendInGroup(sock, chatJid);
            console.log(`[BotPriority] SubBot #${subBotNum} puede enviar: ${canSend}`);
            
            if (canSend) {
                console.log(`[BotPriority] ✅ SubBot #${subBotNum} tiene mayor prioridad y puede enviar`);
                return { 
                    shouldProcess: true, 
                    reason: `SubBot #${subBotNum} - Mayor prioridad y puede enviar` 
                };
            } else {
                // Este subbot no puede enviar, buscar el siguiente
                console.log(chalk.yellow(`[BotPriority] SubBot #${subBotNum} sin permisos - buscando siguiente`));
                
                // Buscar el siguiente subbot con permisos
                for (let i = 1; i < subbotsInGroup.length; i++) {
                    const nextSubBot = subbotsInGroup[i];
                    const nextCanSend = await canBotSendInGroup(nextSubBot, chatJid);
                    
                    if (nextCanSend && nextSubBot._subNum === subBotNum) {
                        console.log(`[BotPriority] ✅ SubBot #${subBotNum} es el siguiente con permisos`);
                        return { 
                            shouldProcess: true, 
                            reason: `SubBot #${subBotNum} - Siguiente con permisos disponible` 
                        };
                    }
                }
                
                console.log(`[BotPriority] ❌ SubBot #${subBotNum} sin permisos y no es el siguiente`);
                return { 
                    shouldProcess: false, 
                    reason: `SubBot #${subBotNum} sin permisos y no es el siguiente disponible` 
                };
            }
        } else {
            // Este subbot NO tiene la mayor prioridad
            console.log(`[BotPriority] ❌ SubBot #${subBotNum} cede prioridad a SubBot #${highestPrioritySubBot._subNum}`);
            return { 
                shouldProcess: false, 
                reason: `SubBot #${subBotNum} cede prioridad a SubBot #${highestPrioritySubBot._subNum}` 
            };
        }
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error en shouldBotProcessMessage:'), error.message);
        // En caso de error, permitir procesar para no bloquear el bot
        return { shouldProcess: true, reason: 'Error en verificación - procesando por seguridad' };
    }
}

/**
 * Obtiene información de prioridad de todos los bots en un grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<Object>} - Información de prioridad
 */
async function getGroupBotPriority(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        const mainSock = global.conn;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) {
            return { error: 'No se pudo obtener metadata del grupo' };
        }
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        const mainBotInGroup = mainBotNum && participantNums.includes(mainBotNum);
        const mainCanSend = mainBotInGroup ? await canBotSendInGroup(mainSock, groupJid) : false;
        
        const subbotsInGroup = (global.subConns || [])
            .filter(c => c.user && c._subNum != null)
            .filter(c => {
                const botNum = c.user.id.split('@')[0].split(':')[0];
                return participantNums.includes(botNum);
            })
            .sort((a, b) => a._subNum - b._subNum);
        
        const subbotsInfo = [];
        for (const subbot of subbotsInGroup) {
            const canSend = await canBotSendInGroup(subbot, groupJid);
            subbotsInfo.push({
                number: subbot._subNum,
                canSend: canSend,
                botNumber: subbot.user.id.split('@')[0].split(':')[0]
            });
        }
        
        return {
            mainBot: {
                present: mainBotInGroup,
                canSend: mainCanSend,
                number: mainBotNum
            },
            subbots: subbotsInfo,
            activeBotPriority: mainBotInGroup && mainCanSend 
                ? 'Bot oficial' 
                : subbotsInfo.find(s => s.canSend)?.number 
                    ? `SubBot #${subbotsInfo.find(s => s.canSend).number}` 
                    : 'Ninguno'
        };
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error en getGroupBotPriority:'), error.message);
        return { error: error.message };
    }
}

module.exports = {
    canBotSendInGroup,
    isMainBotInGroup,
    shouldBotProcessMessage,
    getGroupBotPriority,
    clearCache,
    claimMessage,
    releaseMessage,
    markMessageAsResponded,
    wasMessageResponded
};
