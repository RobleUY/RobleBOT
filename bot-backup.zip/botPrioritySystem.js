/**
 * Sistema de Prioridad de Bots
 * 
 * Gestiona la prioridad de respuesta entre bot oficial y subbots:
 * - Bot oficial = prioridad 0 (máxima)
 * - Subbots = prioridad 1, 2, 3... (menor número = mayor prioridad)
 * 
 * Reglas:
 * 1. Si el bot oficial está en el grupo y puede responder → subbots NO responden
 * 2. Si el bot oficial NO puede responder → responde el subbot con menor número
 * 3. Si ese subbot tampoco puede → intenta con el siguiente
 */

const chalk = require('chalk');

// ═══════════════════════════════════════════════════════════════════
// CACHÉ DE METADATA DE GRUPOS
// ═══════════════════════════════════════════════════════════════════
const METADATA_CACHE = new Map();
const CACHE_DURATION = 300000; // 5 minutos

// Limpieza automática del caché cada 10 minutos
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of METADATA_CACHE.entries()) {
        if (now - value.timestamp > CACHE_DURATION) {
            METADATA_CACHE.delete(key);
        }
    }
}, 600000);

/**
 * Obtener metadata de grupo con caché
 */
async function getGroupMetadataCached(sock, groupJid) {
    try {
        const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
        const cached = METADATA_CACHE.get(cacheKey);
        
        if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
            return cached.data;
        }
        
        const metadata = await sock.groupMetadata(groupJid);
        METADATA_CACHE.set(cacheKey, { data: metadata, timestamp: Date.now() });
        
        return metadata;
    } catch (error) {
        if (error.message?.includes('rate-overlimit')) {
            console.log(chalk.yellow('[BotPriority] ⏳ Rate limit, usando caché'));
            // Intentar devolver caché aunque esté expirado
            const cacheKey = `${groupJid}_${sock.user?.id || 'unknown'}`;
            const cached = METADATA_CACHE.get(cacheKey);
            if (cached) return cached.data;
        }
        return null;
    }
}

/**
 * Limpiar caché manualmente
 */
function clearCache() {
    METADATA_CACHE.clear();
    console.log(chalk.cyan('[BotPriority] 🧹 Caché limpiado'));
}

/**
 * Verifica si un bot puede enviar mensajes en un grupo
 * @param {Object} sock - Socket del bot
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si puede enviar, false si no
 */
async function canBotSendInGroup(sock, groupJid) {
    try {
        if (!sock?.user) return false;
        
        // Obtener metadata del grupo CON CACHÉ
        const groupMeta = await getGroupMetadataCached(sock, groupJid);
        if (!groupMeta) return false;
        
        const botNumber = sock.user.id.split('@')[0].split(':')[0];
        const botParticipant = groupMeta.participants.find(p => 
            p.id.split('@')[0].split(':')[0] === botNumber
        );
        
        // Si el bot no está en el grupo, no puede enviar
        if (!botParticipant) return false;
        
        // Verificar si el grupo está en modo "solo admins"
        const isAnnounce = groupMeta.announce === true;
        
        if (isAnnounce) {
            // Si está en modo solo admins, verificar si el bot es admin
            const isAdmin = botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin';
            return isAdmin;
        }
        
        // Si no está en modo solo admins, puede enviar
        return true;
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando permisos:'), error.message);
        return false;
    }
}

/**
 * Verifica si el bot oficial está en el grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<boolean>} - true si está, false si no
 */
async function isMainBotInGroup(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        if (!mainBotNum) return false;
        
        const mainSock = global.conn;
        if (!mainSock?.user) return false;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) return false;
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        return participantNums.includes(mainBotNum);
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error verificando bot oficial:'), error.message);
        return false;
    }
}

/**
 * Determina si un bot debe procesar un mensaje según la prioridad
 * @param {Object} sock - Socket del bot actual
 * @param {number|null} subBotNum - Número del subbot (null si es el bot oficial)
 * @param {string} chatJid - JID del chat
 * @param {boolean} isGroup - Si es un grupo
 * @returns {Promise<Object>} - { shouldProcess: boolean, reason: string }
 */
async function shouldBotProcessMessage(sock, subBotNum, chatJid, isGroup) {
    try {
        // Si es el bot oficial (subBotNum === null), siempre procesa (prioridad máxima)
        if (subBotNum === null || subBotNum === undefined) {
            return { shouldProcess: true, reason: 'Bot oficial - prioridad máxima' };
        }
        
        // Si no es un grupo, el subbot solo procesa si el mensaje fue enviado a él directamente
        // (el chatJid coincide con su propio número). Si el mensaje fue al bot principal,
        // el subbot NO debe responder jamás.
        if (!isGroup) {
            if (!sock?.user) {
                return { shouldProcess: false, reason: 'Chat privado - subbot sin usuario identificado' };
            }
            const subBotJidNum = sock.user.id.split('@')[0].split(':')[0];
            const chatNum = chatJid.split('@')[0].split(':')[0];
            if (chatNum !== subBotJidNum) {
                return { 
                    shouldProcess: false, 
                    reason: `Chat privado - mensaje no dirigido a SubBot #${subBotNum}` 
                };
            }
            return { shouldProcess: true, reason: `Chat privado - mensaje dirigido a SubBot #${subBotNum}` };
        }
        
        // ═══════════════════════════════════════════════════════════════
        // LÓGICA DE PRIORIDAD EN GRUPOS
        // ═══════════════════════════════════════════════════════════════
        
        const mainBotNum = global.mainBotNumber;
        
        // 1. Verificar si el bot oficial está en el grupo
        const mainBotInGroup = await isMainBotInGroup(chatJid);
        
        if (mainBotInGroup) {
            // 2. Verificar si el bot oficial puede responder
            const mainSock = global.conn;
            const mainCanSend = await canBotSendInGroup(mainSock, chatJid);
            
            if (mainCanSend) {
                // Bot oficial puede responder → subbots NO procesan
                return { 
                    shouldProcess: false, 
                    reason: `Bot oficial presente y puede responder - SubBot #${subBotNum} cede prioridad` 
                };
            } else {
                // Bot oficial NO puede responder → verificar prioridad entre subbots
                console.log(chalk.yellow(`[BotPriority] Bot oficial sin permisos en grupo - SubBots toman control`));
            }
        }
        
        // 3. Bot oficial no está o no puede responder → verificar prioridad entre subbots
        const groupMeta = await getGroupMetadataCached(sock, chatJid);
        if (!groupMeta) {
            return { shouldProcess: false, reason: 'No se pudo obtener metadata del grupo' };
        }
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        // Obtener todos los subbots que están en el grupo
        const subbotsInGroup = (global.subConns || [])
            .filter(c => c.user && c._subNum != null)
            .filter(c => {
                const botNum = c.user.id.split('@')[0].split(':')[0];
                return participantNums.includes(botNum);
            })
            .sort((a, b) => a._subNum - b._subNum); // Ordenar por número ascendente
        
        if (subbotsInGroup.length === 0) {
            return { shouldProcess: true, reason: 'Único subbot en el grupo' };
        }
        
        // 4. Verificar si este subbot tiene la mayor prioridad (menor número)
        const highestPrioritySubBot = subbotsInGroup[0];
        
        if (highestPrioritySubBot._subNum === subBotNum) {
            // Este subbot tiene la mayor prioridad, verificar si puede enviar
            const canSend = await canBotSendInGroup(sock, chatJid);
            
            if (canSend) {
                return { 
                    shouldProcess: true, 
                    reason: `SubBot #${subBotNum} - Mayor prioridad y puede enviar` 
                };
            } else {
                // Este subbot no puede enviar, buscar el siguiente
                console.log(chalk.yellow(`[BotPriority] SubBot #${subBotNum} sin permisos - buscando siguiente`));
                
                // Buscar el siguiente subbot con permisos
                for (let i = 1; i < subbotsInGroup.length; i++) {
                    const nextSubBot = subbotsInGroup[i];
                    const nextCanSend = await canBotSendInGroup(nextSubBot, chatJid);
                    
                    if (nextCanSend && nextSubBot._subNum === subBotNum) {
                        return { 
                            shouldProcess: true, 
                            reason: `SubBot #${subBotNum} - Siguiente con permisos disponible` 
                        };
                    }
                }
                
                return { 
                    shouldProcess: false, 
                    reason: `SubBot #${subBotNum} sin permisos y no es el siguiente disponible` 
                };
            }
        } else {
            // Este subbot NO tiene la mayor prioridad
            return { 
                shouldProcess: false, 
                reason: `SubBot #${subBotNum} cede prioridad a SubBot #${highestPrioritySubBot._subNum}` 
            };
        }
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error en shouldBotProcessMessage:'), error.message);
        // En caso de error, permitir procesar para no bloquear el bot
        return { shouldProcess: true, reason: 'Error en verificación - procesando por seguridad' };
    }
}

/**
 * Obtiene información de prioridad de todos los bots en un grupo
 * @param {string} groupJid - JID del grupo
 * @returns {Promise<Object>} - Información de prioridad
 */
async function getGroupBotPriority(groupJid) {
    try {
        const mainBotNum = global.mainBotNumber;
        const mainSock = global.conn;
        
        const groupMeta = await getGroupMetadataCached(mainSock, groupJid);
        if (!groupMeta) {
            return { error: 'No se pudo obtener metadata del grupo' };
        }
        
        const participantNums = groupMeta.participants.map(p => 
            p.id.split('@')[0].split(':')[0]
        );
        
        const mainBotInGroup = mainBotNum && participantNums.includes(mainBotNum);
        const mainCanSend = mainBotInGroup ? await canBotSendInGroup(mainSock, groupJid) : false;
        
        const subbotsInGroup = (global.subConns || [])
            .filter(c => c.user && c._subNum != null)
            .filter(c => {
                const botNum = c.user.id.split('@')[0].split(':')[0];
                return participantNums.includes(botNum);
            })
            .sort((a, b) => a._subNum - b._subNum);
        
        const subbotsInfo = [];
        for (const subbot of subbotsInGroup) {
            const canSend = await canBotSendInGroup(subbot, groupJid);
            subbotsInfo.push({
                number: subbot._subNum,
                canSend: canSend,
                botNumber: subbot.user.id.split('@')[0].split(':')[0]
            });
        }
        
        return {
            mainBot: {
                present: mainBotInGroup,
                canSend: mainCanSend,
                number: mainBotNum
            },
            subbots: subbotsInfo,
            activeBotPriority: mainBotInGroup && mainCanSend 
                ? 'Bot oficial' 
                : subbotsInfo.find(s => s.canSend)?.number 
                    ? `SubBot #${subbotsInfo.find(s => s.canSend).number}` 
                    : 'Ninguno'
        };
        
    } catch (error) {
        console.error(chalk.red('[BotPriority] Error en getGroupBotPriority:'), error.message);
        return { error: error.message };
    }
}

module.exports = {
    canBotSendInGroup,
    isMainBotInGroup,
    shouldBotProcessMessage,
    getGroupBotPriority,
    clearCache
};
