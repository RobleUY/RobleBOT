/**
 * Sistema de Coordinación de Bots (ELIMINADO)
 * 
 * ✅ SIN SISTEMA DE PRIORIDAD NI COOLDOWN
 * - Todos los bots responden libremente en grupos
 * - En chats privados, cada bot responde solo a sus propios mensajes
 * 
 * Este módulo mantiene funciones vacías para compatibilidad con código existente
 */

const chalk = require('chalk');

// Funciones vacías para compatibilidad
function claimMessage(messageId, botId) {
    return true; // Siempre permitir
}

function wasMessageResponded(messageId) {
    return false; // Nunca bloquear
}

function releaseMessage(messageId, botId) {
    // No hacer nada
}

function markMessageAsResponded(messageId, botId) {
    // No hacer nada
}

async function shouldBotProcessMessage(sock, subBotNum, chatJid, isGroup) {
    return { shouldProcess: true, reason: 'Sin sistema de prioridad - todos responden' };
}

async function canBotSendInGroup(sock, groupJid) {
    return true; // Asumir que puede enviar
}

async function isMainBotInGroup(groupJid) {
    return false; // No importa
}

async function getGroupBotPriority(groupJid) {
    return { error: 'Sistema de prioridad eliminado' };
}

function clearCache() {
    // No hacer nada
}

module.exports = {
    canBotSendInGroup,
    isMainBotInGroup,
    shouldBotProcessMessage,
    getGroupBotPriority,
    clearCache,
    claimMessage,
    releaseMessage,
    markMessageAsResponded,
    wasMessageResponded
};
