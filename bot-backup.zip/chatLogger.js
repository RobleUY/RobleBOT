'use strict';
/**
 * chatLogger.js
 * 
 * Sistema de guardado de mensajes de usuarios en grupos.
 * - Un .db por usuario (optimiza inodos)
 * - Dentro del .db: mensajes divididos por grupo
 * - Transcribe notas de voz automáticamente
 * - Guarda contexto: mensaje citado + respuesta
 * - Solo funciona en grupos
 */

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { execFile } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const FormData = require('form-data');
const os = require('os');
const crypto = require('crypto');

const execFileAsync = promisify(execFile);
const CHATS_DIR = path.resolve(__dirname, 'data', 'CHATS-USUARIOS');
const GROQ_API_KEY = "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";

if (!fs.existsSync(CHATS_DIR)) fs.mkdirSync(CHATS_DIR, { recursive: true });

// Cache de conexiones DB para no abrir/cerrar constantemente
const dbCache = new Map();

function getUserDb(userNumber) {
    if (dbCache.has(userNumber)) return dbCache.get(userNumber);
    
    const dbPath = path.join(CHATS_DIR, `${userNumber}.db`);
    const db = new Database(dbPath);
    
    // Crear tabla si no existe
    db.exec(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_jid TEXT NOT NULL,
            group_name TEXT,
            timestamp INTEGER NOT NULL,
            message_id TEXT,
            message_type TEXT,
            content TEXT,
            quoted_content TEXT,
            is_voice_note INTEGER DEFAULT 0,
            transcription TEXT,
            bot_number TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_group_timestamp ON messages(group_jid, timestamp);
        CREATE INDEX IF NOT EXISTS idx_timestamp ON messages(timestamp);
    `);
    
    dbCache.set(userNumber, db);
    return db;
}

function tmpFileName(ext = '') {
    return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : ''));
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    return buffer;
}

async function convertToWav(inputPath) {
    const output = tmpFileName('wav');
    await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-ar', '16000', '-ac', '1', output]);
    return output;
}

async function transcribeWithGroq(filePath) {
    try {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath), { filename: 'audio.wav', contentType: 'audio/wav' });
        form.append('model', 'whisper-large-v3');
        form.append('language', 'es');
        form.append('response_format', 'text');

        const res = await axios.post('https://api.groq.com/openai/v1/audio/transcriptions', form, {
            headers: {
                ...form.getHeaders(),
                'Authorization': `Bearer ${GROQ_API_KEY}`
            },
            timeout: 60000
        });

        return typeof res.data === 'string' ? res.data : res.data?.text || null;
    } catch (e) {
        console.error('[ChatLogger] Error transcribiendo:', e.message);
        return null;
    }
}

async function transcribeVoiceNote(audioMessage) {
    try {
        const stream = await downloadContentFromMessage(audioMessage, 'audio');
        const buffer = await streamToBuffer(stream);
        const tempFile = tmpFileName('ogg');
        fs.writeFileSync(tempFile, buffer);
        
        const wav = await convertToWav(tempFile);
        const transcription = await transcribeWithGroq(wav);
        
        fs.unlinkSync(tempFile);
        fs.unlinkSync(wav);
        
        return transcription;
    } catch (e) {
        console.error('[ChatLogger] Error en transcripción:', e.message);
        return null;
    }
}

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return null;
    
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    
    return null;
}

async function logMessage(baileyMessage, sock) {
    try {
        // Solo en grupos
        const chatJid = baileyMessage.key.remoteJid;
        if (!chatJid || !chatJid.endsWith('@g.us')) return;
        
        // Solo mensajes de usuarios (no del bot)
        if (baileyMessage.key.fromMe) return;
        
        const senderJid = baileyMessage.key.participant || baileyMessage.participant;
        if (!senderJid) return;
        
        const userNumber = senderJid.split('@')[0].split(':')[0];
        const botNumber = sock.user?.id?.split('@')[0]?.split(':')[0] || 'unknown';
        
        const msg = baileyMessage.message;
        if (!msg) return;
        
        // Obtener nombre del grupo
        let groupName = 'Desconocido';
        try {
            const groupMeta = await sock.groupMetadata(chatJid);
            groupName = groupMeta.subject || 'Sin nombre';
        } catch {}
        
        const timestamp = (baileyMessage.messageTimestamp || 0) * 1000;
        const messageId = baileyMessage.key.id;
        
        let messageType = 'text';
        let content = null;
        let isVoiceNote = 0;
        let transcription = null;
        let quotedContent = null;
        
        // Detectar tipo de mensaje
        if (msg.conversation || msg.extendedTextMessage) {
            messageType = 'text';
            content = getMessageText(baileyMessage);
        } else if (msg.imageMessage) {
            messageType = 'image';
            content = msg.imageMessage.caption || '(imagen)';
        } else if (msg.videoMessage) {
            messageType = 'video';
            content = msg.videoMessage.caption || '(video)';
        } else if (msg.audioMessage) {
            // Detectar si es nota de voz (ptt = push to talk)
            if (msg.audioMessage.ptt) {
                messageType = 'voice_note';
                isVoiceNote = 1;
                content = '(nota de voz)';
                
                // Transcribir en background (no bloquear)
                transcribeVoiceNote(msg.audioMessage).then(text => {
                    if (text) {
                        const db = getUserDb(userNumber);
                        db.prepare('UPDATE messages SET transcription = ? WHERE message_id = ?')
                          .run(text, messageId);
                        console.log(`[ChatLogger] Transcripción guardada para ${userNumber} en ${groupName}`);
                    }
                }).catch(() => {});
            } else {
                messageType = 'audio';
                content = '(audio)';
            }
        } else if (msg.documentMessage) {
            messageType = 'document';
            content = `(documento: ${msg.documentMessage.fileName || 'sin nombre'})`;
        } else if (msg.stickerMessage) {
            messageType = 'sticker';
            content = '(sticker)';
        } else {
            // Otros tipos no soportados
            return;
        }
        
        // Obtener mensaje citado (contexto)
        if (msg.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.extendedTextMessage.contextInfo.quotedMessage;
            if (quoted.conversation) {
                quotedContent = quoted.conversation;
            } else if (quoted.extendedTextMessage?.text) {
                quotedContent = quoted.extendedTextMessage.text;
            } else if (quoted.imageMessage?.caption) {
                quotedContent = `(imagen) ${quoted.imageMessage.caption || ''}`;
            } else if (quoted.videoMessage?.caption) {
                quotedContent = `(video) ${quoted.videoMessage.caption || ''}`;
            } else if (quoted.audioMessage?.ptt) {
                quotedContent = '(nota de voz citada)';
            }
        }
        
        // Guardar en DB
        const db = getUserDb(userNumber);
        db.prepare(`
            INSERT INTO messages (
                group_jid, group_name, timestamp, message_id, message_type,
                content, quoted_content, is_voice_note, transcription, bot_number
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            chatJid,
            groupName,
            timestamp,
            messageId,
            messageType,
            content,
            quotedContent,
            isVoiceNote,
            transcription,
            botNumber
        );
        
    } catch (e) {
        console.error('[ChatLogger] Error guardando mensaje:', e.message);
    }
}

// Cerrar todas las conexiones DB al salir
process.on('exit', () => {
    for (const db of dbCache.values()) {
        try { db.close(); } catch {}
    }
});

module.exports = { logMessage, getUserDb, CHATS_DIR };
