'use strict';
/**
 * chatLogger.js
 * 
 * Sistema de guardado de mensajes de usuarios en grupos.
 * - UN SOLO .db para TODOS los usuarios (optimiza inodos)
 * - Mensajes organizados por user_number y group_jid
 * - Transcribe notas de voz automáticamente
 * - Guarda contexto: mensaje citado + respuesta
 * - Solo funciona en grupos
 */

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { execFile } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const FormData = require('form-data');
const os = require('os');
const crypto = require('crypto');

const execFileAsync = promisify(execFile);
const DATA_DIR = path.resolve(__dirname, 'data');
const OLD_CHATS_DIR = path.join(DATA_DIR, 'CHATS-USUARIOS');
const DB_PATH = path.join(DATA_DIR, 'user_chats.db');
const GROQ_API_KEY = "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";

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Una sola conexión DB para todos los usuarios
let db = null;
let migracionRealizada = false;

// Cache de nombres de grupos (evita rate limit en groupMetadata)
const groupNameCache = new Map();
const GROUP_NAME_CACHE_TTL = 30 * 60 * 1000; // 30 minutos

function migrarChatsAntiguos() {
    if (migracionRealizada) return;
    if (!fs.existsSync(OLD_CHATS_DIR)) return;
    
    const archivos = fs.readdirSync(OLD_CHATS_DIR).filter(f => f.endsWith('.db'));
    if (archivos.length === 0) return;
    
    console.log(`[ChatLogger] 🔄 Migrando ${archivos.length} archivos antiguos...`);
    
    let totalMensajes = 0;
    const insert = db.prepare(`
        INSERT INTO messages (
            user_number, group_jid, group_name, timestamp, message_id, 
            message_type, content, quoted_content, is_voice_note, 
            transcription, bot_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    for (const archivo of archivos) {
        try {
            const userNumber = path.basename(archivo, '.db');
            const archivoPath = path.join(OLD_CHATS_DIR, archivo);
            const dbAntigua = new Database(archivoPath, { readonly: true });
            
            const tables = dbAntigua.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'").all();
            if (tables.length === 0) {
                dbAntigua.close();
                continue;
            }
            
            const mensajes = dbAntigua.prepare('SELECT * FROM messages').all();
            dbAntigua.close();
            
            const insertMany = db.transaction((msgs) => {
                for (const msg of msgs) {
                    insert.run(
                        userNumber,
                        msg.group_jid,
                        msg.group_name,
                        msg.timestamp,
                        msg.message_id,
                        msg.message_type,
                        msg.content,
                        msg.quoted_content,
                        msg.is_voice_note || 0,
                        msg.transcription,
                        msg.bot_number
                    );
                }
            });
            
            insertMany(mensajes);
            totalMensajes += mensajes.length;
            
        } catch (e) {
            console.error(`[ChatLogger] Error migrando ${archivo}:`, e.message);
        }
    }
    
    console.log(`[ChatLogger] ✅ Migrados ${totalMensajes.toLocaleString()} mensajes`);
    
    // Eliminar carpeta antigua
    try {
        fs.rmSync(OLD_CHATS_DIR, { recursive: true, force: true });
        console.log(`[ChatLogger] 🗑️  Archivos antiguos eliminados`);
    } catch (e) {
        console.error(`[ChatLogger] Error eliminando archivos antiguos:`, e.message);
    }
    
    migracionRealizada = true;
}

function getDb() {
    if (db) return db;
    
    db = new Database(DB_PATH);
    
    // Crear tabla si no existe
    db.exec(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_number TEXT NOT NULL,
            group_jid TEXT NOT NULL,
            group_name TEXT,
            timestamp INTEGER NOT NULL,
            message_id TEXT,
            message_type TEXT,
            content TEXT,
            quoted_content TEXT,
            is_voice_note INTEGER DEFAULT 0,
            transcription TEXT,
            bot_number TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_user_number ON messages(user_number);
        CREATE INDEX IF NOT EXISTS idx_user_group ON messages(user_number, group_jid);
        CREATE INDEX IF NOT EXISTS idx_timestamp ON messages(timestamp);
        CREATE INDEX IF NOT EXISTS idx_user_timestamp ON messages(user_number, timestamp);
    `);
    
    // Migrar archivos antiguos automáticamente
    migrarChatsAntiguos();
    
    return db;
}

// Función de compatibilidad para plugins antiguos
function getUserDb(userNumber) {
    const mainDb = getDb();
    
    // Retornar un objeto que simula la API antigua pero usa la nueva tabla
    return {
        prepare: (sql) => {
            // Adaptar queries antiguas al nuevo esquema
            // Las queries antiguas no tienen user_number en WHERE, así que las modificamos
            let newSql = sql;
            
            // Si es un SELECT y no tiene user_number, agregarlo
            if (sql.includes('SELECT') && !sql.includes('user_number')) {
                newSql = sql.replace(
                    /WHERE\s+/i,
                    `WHERE user_number = '${userNumber}' AND `
                );
            }
            
            // Si es un UPDATE y no tiene user_number, agregarlo
            if (sql.includes('UPDATE') && !sql.includes('user_number')) {
                newSql = sql.replace(
                    /WHERE\s+/i,
                    `WHERE user_number = '${userNumber}' AND `
                );
            }
            
            return mainDb.prepare(newSql);
        },
        exec: (sql) => mainDb.exec(sql),
        close: () => {} // No cerrar la DB compartida
    };
}

async function getGroupName(sock, groupJid) {
    const cached = groupNameCache.get(groupJid);
    if (cached && (Date.now() - cached.timestamp < GROUP_NAME_CACHE_TTL)) {
        return cached.name;
    }
    
    try {
        const groupMeta = await sock.groupMetadata(groupJid);
        const name = groupMeta.subject || 'Sin nombre';
        groupNameCache.set(groupJid, { name, timestamp: Date.now() });
        return name;
    } catch {
        return 'Desconocido';
    }
}

function tmpFileName(ext = '') {
    return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : ''));
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    return buffer;
}

async function convertToWav(inputPath) {
    const output = tmpFileName('wav');
    await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-ar', '16000', '-ac', '1', output]);
    return output;
}

async function transcribeWithGroq(filePath) {
    try {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath), { filename: 'audio.wav', contentType: 'audio/wav' });
        form.append('model', 'whisper-large-v3');
        form.append('language', 'es');
        form.append('response_format', 'text');

        const res = await axios.post('https://api.groq.com/openai/v1/audio/transcriptions', form, {
            headers: {
                ...form.getHeaders(),
                'Authorization': `Bearer ${GROQ_API_KEY}`
            },
            timeout: 60000
        });

        return typeof res.data === 'string' ? res.data : res.data?.text || null;
    } catch (e) {
        console.error('[ChatLogger] Error transcribiendo:', e.message);
        return null;
    }
}

async function transcribeVoiceNote(audioMessage) {
    try {
        const stream = await downloadContentFromMessage(audioMessage, 'audio');
        const buffer = await streamToBuffer(stream);
        const tempFile = tmpFileName('ogg');
        fs.writeFileSync(tempFile, buffer);
        
        const wav = await convertToWav(tempFile);
        const transcription = await transcribeWithGroq(wav);
        
        fs.unlinkSync(tempFile);
        fs.unlinkSync(wav);
        
        return transcription;
    } catch (e) {
        console.error('[ChatLogger] Error en transcripción:', e.message);
        return null;
    }
}

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return null;
    
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    
    return null;
}

async function logMessage(baileyMessage, sock) {
    try {
        // Solo en grupos
        const chatJid = baileyMessage.key.remoteJid;
        if (!chatJid || !chatJid.endsWith('@g.us')) return;
        
        // Solo mensajes de usuarios (no del bot)
        if (baileyMessage.key.fromMe) return;
        
        const senderJid = baileyMessage.key.participant || baileyMessage.participant;
        if (!senderJid) return;
        
        const msg = baileyMessage.message;
        if (!msg) return;
        
        // ── FILTRO 1: NO guardar comandos ────────────────────────────────────
        const messageText = getMessageText(baileyMessage);
        const commandPrefixes = ['.', '/', '❤️', '#'];
        if (messageText && commandPrefixes.some(p => messageText.trim().startsWith(p))) {
            return; // Es un comando, no guardar
        }
        
        // ── FILTRO 2: NO guardar respuestas a comandos ───────────────────────
        const quotedMsg = msg.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quotedMsg) {
            // Obtener texto del mensaje citado
            let quotedText = null;
            if (quotedMsg.conversation) {
                quotedText = quotedMsg.conversation;
            } else if (quotedMsg.extendedTextMessage?.text) {
                quotedText = quotedMsg.extendedTextMessage.text;
            }
            
            // Si el mensaje citado es un comando, no guardar esta respuesta
            if (quotedText && commandPrefixes.some(p => quotedText.trim().startsWith(p))) {
                return; // Es respuesta a un comando, no guardar
            }
        }
        
        const userNumber = senderJid.split('@')[0].split(':')[0];
        const botNumber = sock.user?.id?.split('@')[0]?.split(':')[0] || 'unknown';
        
        // Obtener nombre del grupo (con caché para evitar rate limit)
        const groupName = await getGroupName(sock, chatJid);
        
        const timestamp = (baileyMessage.messageTimestamp || 0) * 1000;
        const messageId = baileyMessage.key.id;
        
        let messageType = 'text';
        let content = null;
        let isVoiceNote = 0;
        let transcription = null;
        let quotedContent = null;
        
        // Detectar tipo de mensaje
        if (msg.conversation || msg.extendedTextMessage) {
            messageType = 'text';
            content = getMessageText(baileyMessage);
        } else if (msg.imageMessage) {
            messageType = 'image';
            content = msg.imageMessage.caption || '(imagen)';
        } else if (msg.videoMessage) {
            messageType = 'video';
            content = msg.videoMessage.caption || '(video)';
        } else if (msg.audioMessage) {
            // Detectar si es nota de voz (ptt = push to talk)
            if (msg.audioMessage.ptt) {
                messageType = 'voice_note';
                isVoiceNote = 1;
                content = '(nota de voz)';
                
                // Transcribir en background (no bloquear)
                transcribeVoiceNote(msg.audioMessage).then(text => {
                    if (text) {
                        const database = getDb();
                        database.prepare('UPDATE messages SET transcription = ? WHERE user_number = ? AND message_id = ?')
                          .run(text, userNumber, messageId);
                        console.log(`[ChatLogger] Transcripción guardada para ${userNumber} en ${groupName}`);
                    }
                }).catch(() => {});
            } else {
                messageType = 'audio';
                content = '(audio)';
            }
        } else if (msg.documentMessage) {
            messageType = 'document';
            content = `(documento: ${msg.documentMessage.fileName || 'sin nombre'})`;
        } else if (msg.stickerMessage) {
            messageType = 'sticker';
            content = '(sticker)';
        } else {
            // Otros tipos no soportados
            return;
        }
        
        // Obtener mensaje citado (contexto)
        if (msg.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.extendedTextMessage.contextInfo.quotedMessage;
            if (quoted.conversation) {
                quotedContent = quoted.conversation;
            } else if (quoted.extendedTextMessage?.text) {
                quotedContent = quoted.extendedTextMessage.text;
            } else if (quoted.imageMessage?.caption) {
                quotedContent = `(imagen) ${quoted.imageMessage.caption || ''}`;
            } else if (quoted.videoMessage?.caption) {
                quotedContent = `(video) ${quoted.videoMessage.caption || ''}`;
            } else if (quoted.audioMessage?.ptt) {
                quotedContent = '(nota de voz citada)';
            }
        }
        
        // Guardar en DB
        const database = getDb();
        database.prepare(`
            INSERT INTO messages (
                user_number, group_jid, group_name, timestamp, message_id, message_type,
                content, quoted_content, is_voice_note, transcription, bot_number
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            userNumber,
            chatJid,
            groupName,
            timestamp,
            messageId,
            messageType,
            content,
            quotedContent,
            isVoiceNote,
            transcription,
            botNumber
        );
        
    } catch (e) {
        console.error('[ChatLogger] Error guardando mensaje:', e.message);
    }
}

// Cerrar la conexión DB al salir
process.on('exit', () => {
    if (db) {
        try { db.close(); } catch {}
    }
});

// Limpiar caché de nombres de grupos cada hora
setInterval(() => {
    const now = Date.now();
    for (const [jid, data] of groupNameCache.entries()) {
        if (now - data.timestamp > GROUP_NAME_CACHE_TTL) {
            groupNameCache.delete(jid);
        }
    }
}, 60 * 60 * 1000);

module.exports = { logMessage, getUserDb, getDb, DB_PATH };
