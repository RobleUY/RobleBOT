// Lanzador simple para evitar el bug del egg
require('./start.js');
