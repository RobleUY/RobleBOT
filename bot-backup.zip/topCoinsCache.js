/**
 * SISTEMA DE MEDALLAS PARA TOP 10 DE COINS
 * 
 * Este módulo mantiene un caché del top 10 de usuarios con más dinero (money + bank)
 * y proporciona funciones para obtener la medalla correspondiente a cada usuario.
 */

const fs = require('fs');
const path = require('path');

// Caché del top 10 de coins
let _topCoinsCache = [];
let _topCoinsCacheTime = 0;
const CACHE_TTL = 60000; // 1 minuto de TTL para el caché

// Medallas para el top 10
const MEDALS = {
    1: '🥇',
    2: '🥈',
    3: '🥉',
    4: '4️⃣',
    5: '5️⃣',
    6: '6️⃣',
    7: '7️⃣',
    8: '8️⃣',
    9: '9️⃣',
    10: '🔟'
};

/**
 * Limpia un número de JID para obtener solo el número limpio
 */
function cleanNumber(jid) {
    if (!jid) return '';
    let str = String(jid).split('@')[0].split(':')[0].trim();
    str = str.replace(/\.0+$/, '');
    return str.replace(/\D/g, '');
}

/**
 * Obtiene el top 10 de usuarios con más dinero (money + bank) desde global.db
 * @returns {Array} Array de objetos { userId, totalMoney, position }
 */
function calculateTop10() {
    try {
        if (!global.db) return [];

        const usersWithMoney = [];
        const seenNumbers = new Set();

        if (typeof global.db._stmts?.getAllUsers?.all === 'function') {
            const rows = global.db._stmts.getAllUsers.all();
            for (const row of rows) {
                const cleanNum = cleanNumber(row.id);
                if (!cleanNum || seenNumbers.has(cleanNum)) continue;

                try {
                    const userData = JSON.parse(row.data);
                    const money = Number(userData.money) || 0;
                    const bank = Number(userData.bank) || 0;
                    const totalMoney = money + bank;
                    if (totalMoney > 0) {
                        seenNumbers.add(cleanNum);
                        usersWithMoney.push({
                            userId: cleanNum,
                            totalMoney: totalMoney
                        });
                    }
                } catch (_) {}
            }
        } else if (global.db.data?.users) {
            const users = global.db.data.users;
            const aliases = global.db.data.aliases || {};
            for (const [userId, userData] of Object.entries(users)) {
                if (aliases[userId] && aliases[userId] !== userId) continue;
                const cleanNum = cleanNumber(userId);
                if (!cleanNum || seenNumbers.has(cleanNum)) continue;
                seenNumbers.add(cleanNum);
                const money = Number(userData.money) || 0;
                const bank = Number(userData.bank) || 0;
                const totalMoney = money + bank;
                if (totalMoney > 0) {
                    usersWithMoney.push({
                        userId: cleanNum,
                        totalMoney: totalMoney
                    });
                }
            }
        }

        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);

        return usersWithMoney.slice(0, 10).map((user, index) => ({
            userId: user.userId,
            totalMoney: user.totalMoney,
            position: index + 1
        }));
    } catch (error) {
        console.error('[TopCoins] Error calculando top 10:', error.message);
        return [];
    }
}

/**
 * Actualiza el caché del top 10 de coins
 */
function updateCache() {
    _topCoinsCache = calculateTop10();
    _topCoinsCacheTime = Date.now();
}

/**
 * Obtiene el top 10 de coins (usa caché si es válido)
 * @returns {Array} Array del top 10
 */
function getTop10() {
    const now = Date.now();
    
    // Si el caché es válido, devolverlo
    if (_topCoinsCache.length > 0 && (now - _topCoinsCacheTime < CACHE_TTL)) {
        return _topCoinsCache;
    }
    
    // Si no, actualizar y devolver
    updateCache();
    return _topCoinsCache;
}

/**
 * Obtiene la posición de un usuario en el top 10
 * @param {string} userId - JID del usuario (puede incluir @s.whatsapp.net)
 * @returns {number|null} Posición del usuario (1-10) o null si no está en el top 10
 */
function getUserPosition(userId) {
    const cleanNum = cleanNumber(userId);
    if (!cleanNum) return null;
    
    const top10 = getTop10();
    const user = top10.find(u => u.userId === cleanNum);
    
    return user ? user.position : null;
}

/**
 * Obtiene la medalla correspondiente a un usuario si está en el top 10
 * @param {string} userId - JID del usuario
 * @returns {string} Medalla (emoji) o string vacío si no está en el top 10
 */
function getUserMedal(userId) {
    const position = getUserPosition(userId);
    if (!position) return '';
    
    return MEDALS[position] || '';
}

/**
 * Verifica si un usuario está en el top 10
 * @param {string} userId - JID del usuario
 * @returns {boolean}
 */
function isInTop10(userId) {
    return getUserPosition(userId) !== null;
}

/**
 * Invalida el caché forzando una actualización en la próxima consulta
 */
function invalidateCache() {
    _topCoinsCacheTime = 0;
}

/**
 * Fuerza una actualización inmediata del caché
 */
function forceUpdate() {
    updateCache();
}

// Actualizar caché cada minuto automáticamente
setInterval(() => {
    updateCache();
}, CACHE_TTL);

// Actualizar caché al cargar el módulo
updateCache();

module.exports = {
    getTop10,
    getUserPosition,
    getUserMedal,
    isInTop10,
    invalidateCache,
    forceUpdate
};
