/**
 * petAutocuidado.js
 * 
 * Scheduler de autocuidado automático para usuarios premium con mascotas.
 * Corre en background cada hora y alimenta, hidrata y hace jugar a las
 * mascotas de usuarios premium 1 vez cada 24 horas, sin que el usuario
 * tenga que ejecutar ningún comando.
 */

const fs   = require('fs');
const path = require('path');
const chalk = require('chalk');
const { isPremium } = require('./premium');

const DATA_DIR      = path.join(__dirname, 'data');
const MASCOTAS_FILE = path.join(DATA_DIR, 'mascotas.json');

const HORA_MS = 60 * 60 * 1000;        // 1 hora  — cooldown de cada acción
const DIA_MS  = 24 * 60 * 60 * 1000;   // 24 horas — frecuencia del autocuidado

let _intervalId = null;

// ─── helpers ────────────────────────────────────────────────────────────────

function cargarMascotas() {
    try {
        if (fs.existsSync(MASCOTAS_FILE)) {
            return JSON.parse(fs.readFileSync(MASCOTAS_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[PetAutocuidado] Error leyendo mascotas.json:', e.message);
    }
    return {};
}

function guardarMascotas(mascotas) {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
        fs.writeFileSync(MASCOTAS_FILE, JSON.stringify(mascotas, null, 2));
    } catch (e) {
        console.error('[PetAutocuidado] Error guardando mascotas.json:', e.message);
    }
}

function necesitaAccion(ultimoTiempo) {
    return (Date.now() - ultimoTiempo) >= HORA_MS;
}

// ─── lógica principal ────────────────────────────────────────────────────────

function runAutocuidado(sock) {
    try {
        const mascotas = cargarMascotas();
        const ahora = Date.now();
        let totalCuidados = 0;

        for (const [numero, m] of Object.entries(mascotas)) {
            // Solo usuarios premium
            if (!isPremium(numero)) continue;

            // Solo 1 vez cada 24 horas
            const ultimoCuidado = m.ultimo_autocuidado || 0;
            if (ahora - ultimoCuidado < DIA_MS) continue;

            const acciones = [];

            if (necesitaAccion(m.ultima_comida)) {
                m.ultima_comida = ahora;
                m.comida_progreso++;
                m.total_comida++;
                acciones.push('🥩');
            }
            if (necesitaAccion(m.ultima_agua)) {
                m.ultima_agua = ahora;
                m.agua_progreso++;
                m.total_agua++;
                acciones.push('💧');
            }
            if (necesitaAccion(m.ultimo_juego)) {
                m.ultimo_juego = ahora;
                m.juego_progreso++;
                m.total_juego++;
                acciones.push('🎾');
            }

            if (acciones.length === 0) continue;

            m.ultimo_autocuidado = ahora;

            // Verificar subida de nivel
            let subioNivel = false;
            while (
                m.comida_progreso >= m.nivel &&
                m.agua_progreso  >= m.nivel &&
                m.juego_progreso >= m.nivel
            ) {
                m.comida_progreso -= m.nivel;
                m.agua_progreso   -= m.nivel;
                m.juego_progreso  -= m.nivel;
                m.nivel++;
                subioNivel = true;
            }

            mascotas[numero] = m;
            totalCuidados++;

            // Notificar al usuario por WhatsApp si el socket está disponible
            if (sock) {
                const jid = `${numero}@s.whatsapp.net`;
                let msg =
                    `★ *Autocuidado Premium* ★\n` +
                    `Tu ${m.tipo} *${m.nombre}* se cuidó sola hoy: ${acciones.join(' ')}\n` +
                    `_Tu mascota está bien gracias a tu suscripción premium. 🌟_`;
                if (subioNivel) {
                    msg += `\n\n⭐ *¡Subió al Nivel ${m.nivel}!*`;
                }
                sock.sendMessage(jid, { text: msg }).catch(() => {});
            }
        }

        if (totalCuidados > 0) {
            guardarMascotas(mascotas);
            console.log(chalk.cyan(`[PetAutocuidado] ✅ Autocuidado aplicado a ${totalCuidados} mascota(s) premium`));
        }

    } catch (err) {
        console.error('[PetAutocuidado] Error en runAutocuidado:', err.message);
    }
}

// ─── API pública ─────────────────────────────────────────────────────────────

/**
 * Inicia el scheduler. Llamar desde index.js tras conectar el socket.
 * @param {object} sock  — socket de Baileys (para enviar notificaciones)
 */
function initPetAutocuidado(sock) {
    if (_intervalId) {
        clearInterval(_intervalId);
        _intervalId = null;
    }

    // Primera pasada inmediata (por si había mascotas que esperaban)
    runAutocuidado(sock);

    // Luego cada hora
    _intervalId = setInterval(() => runAutocuidado(sock), HORA_MS);

    console.log(chalk.cyan('[PetAutocuidado] ✅ Scheduler iniciado — revisión cada hora'));
}

function stopPetAutocuidado() {
    if (_intervalId) {
        clearInterval(_intervalId);
        _intervalId = null;
        console.log(chalk.cyan('[PetAutocuidado] ⏹ Scheduler detenido'));
    }
}

module.exports = { initPetAutocuidado, stopPetAutocuidado };
