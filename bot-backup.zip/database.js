const fs = require('fs');
const path = require('path');

const defaultData = {
    users: {},
    groups: {},
    chats: {},
    groupActivity: {},
    parejas: {},
    personajes: {},
    intercambiosAnime: {},
    futbolistas: {},
    intercambiosFutbol: {},
    figuritas: {},
    famosos: {},
    intercambiosFamosos: {},
    clanes: {}
};

const defaultUserData = {
    name: '',
    warns: 0,
    ComandosEjecutados: 0,
    accesscode: null,
    isBanned: false,
    bank: 0,
    money: 0,
    escudosAntiRobos: 0,
    level: 0,
    exp: 0,
    lastWork: 0,
    workedHours: 0,
    totalWorkedHours: 0,
    totalWorkedTimes: 0,
    lastDaily: 0,
    lastClanAttack: 0,
    registered: false,
    premium: false,
    banned: false,
    reseña: null,
    apodo: '',
    rank: 0,
    respeto: 0,
    cookies: 0,
    auto: 0,
    manual: 0,
    lastCookie: 0,
    lastAuto: Date.now(),
    pet: {
        name: "Mi Mascota",
        type: "perro",
        level: 1,
        food: 0,
        requiredFood: 100
    },
    lastMining: 0,
    lastPremio: 0,
    minerales: {
        CARBON: 0,
        HIERRO: 0,
        PLATA: 0,
        ORO: 0,
        DIAMANTE: 0,
        ESMERALDA: 0,
        RUBI: 0
    },
    prestamo: {
        activo: false,
        monto: 0,
        deuda: 0,
        intereses: 0,
        fechaPrestamo: 0
    },
    betStats: {
        totalBets: 0,
        totalWins: 0,
        totalLosses: 0,
        totalBetAmount: 0,
        totalWonAmount: 0,
        totalLostAmount: 0,
        biggestBet: 0,
        biggestWin: 0,
        biggestLoss: 0,
        currentStreak: 0,
        bestWinStreak: 0,
        worstLoseStreak: 0,
        lastBetTime: 0
    },
    achievements: {
        commands: { total: 0, milestones: [] },
        work: { total: 0, milestones: [] },
        betting: { total: 0, milestones: [] },
        daily: { total: 0, milestones: [] }
    }
};

function createDefaultUserData() {
    return {
        ...defaultUserData,
        pet: { ...defaultUserData.pet },
        minerales: { ...defaultUserData.minerales },
        prestamo: { ...defaultUserData.prestamo },
        betStats: { ...defaultUserData.betStats },
        achievements: {
            commands: { total: 0, milestones: [] },
            work: { total: 0, milestones: [] },
            betting: { total: 0, milestones: [] },
            daily: { total: 0, milestones: [] }
        }
    };
}

class Database {
    constructor() {
        this.data = defaultData;
        this.filePath = path.join(__dirname, 'database.json');
        this.isInitialized = false;
        this.saveTimeout = null;
        this.isSaving = false;
        this.pendingChanges = false;
        this.load();
        
        // Guardado periódico de respaldo (cada 30 segundos)
        this.periodicSaveInterval = setInterval(() => {
            if (this.pendingChanges && !this.isSaving) {
                this.saveNow();
            }
        }, 30000);
    }

    load() {
        try {
            if (fs.existsSync(this.filePath)) {
                const fileData = fs.readFileSync(this.filePath, 'utf8');
                const localData = JSON.parse(fileData);
                
                this.data = {
                    users: localData.users || {},
                    groups: localData.groups || {},
                    chats: localData.chats || {},
                    groupActivity: localData.groupActivity || {},
                    parejas: localData.parejas || {},
                    personajes: localData.personajes || {},
                    intercambiosAnime: localData.intercambiosAnime || {},
                    futbolistas: localData.futbolistas || {},
                    intercambiosFutbol: localData.intercambiosFutbol || {},
                    figuritas: localData.figuritas || {},
                    famosos: localData.famosos || {},
                    intercambiosFamosos: localData.intercambiosFamosos || {},
                    clanes: localData.clanes || {}
                };
                
                this.isInitialized = true;
                console.log('[Database] ✓ Cargada exitosamente');
            } else {
                this.data = { ...defaultData };
                this.saveNow();
                this.isInitialized = true;
                console.log('[Database] ✓ Nueva base de datos creada');
            }
        } catch (error) {
            console.error('[Database] ❌ Error cargando:', error.message);
            this.data = { ...defaultData };
            this.saveNow();
            this.isInitialized = true;
        }
    }

    // Guardado con debounce corto — escribe al disco 500ms después del último cambio
    save() {
        this.pendingChanges = true;
        
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
        }
        
        this.saveTimeout = setTimeout(() => {
            if (!this.isSaving) {
                this.saveNow();
            }
        }, 500);
    }

    // Guardado inmediato con protección contra guardados simultáneos
    saveNow() {
        // Prevenir guardados simultáneos
        if (this.isSaving) {
            console.log('[Database] ⏳ Guardado en progreso, esperando...');
            return;
        }

        this.isSaving = true;
        
        try {
            if (!this.isInitialized) {
                this.isInitialized = true;
            }
            
            const dir = path.dirname(this.filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            
            // Guardar en archivo temporal primero (JSON compacto para máxima velocidad y menor I/O)
            const tempPath = this.filePath + '.tmp';
            fs.writeFileSync(tempPath, JSON.stringify(this.data));
            
            // Renombrar archivo temporal al final
            fs.renameSync(tempPath, this.filePath);
            
            this.pendingChanges = false;
        } catch (error) {
            // 🚨 ENOSPC: sin espacio — activar limpieza de emergencia y reintentar
            if (error.code === 'ENOSPC' || error.message?.includes('ENOSPC')) {
                console.error('[Database] 🚨 ENOSPC detectado — activando limpieza de emergencia...');
                try {
                    const { tempCleaner } = require('./tempCleaner');
                    tempCleaner.emergencyCleanup().then(() => {
                        // Reintentar guardado después de 3 segundos
                        setTimeout(() => {
                            this.isSaving = false;
                            this.saveNow();
                        }, 3000);
                    }).catch(() => { this.isSaving = false; });
                    // No liberar isSaving aún — lo hace el retry
                    return;
                } catch (_) {
                    console.error('[Database] ❌ No se pudo limpiar temp:', error.message);
                }
            } else {
                console.error('[Database] ❌ Error guardando:', error.message);
            }
        } finally {
            // Solo liberar si no se lanzó un retry de ENOSPC
            if (this.isSaving) {
                this.isSaving = false;
            }
        }
    }

    checkInitialization() {
        if (!this.isInitialized) {
            this.load();
            return false;
        }
        return true;
    }

    cleanNumber(sender) {
        return sender.replace(/[^0-9]/g, '');
    }

    getUser(sender) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(sender);
            
            if (!this.data.users[cleanNumber]) {
                this.data.users[cleanNumber] = createDefaultUserData();
                this.save();
            }
            
            const user = this.data.users[cleanNumber];
            let needsUpdate = false;
            
            for (const [key, value] of Object.entries(defaultUserData)) {
                if (user[key] === undefined) {
                    if (key === 'minerales' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'pet' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'prestamo' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'betStats' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'achievements' && typeof value === 'object') {
                        user[key] = {
                            commands: { ...value.commands },
                            work: { ...value.work },
                            betting: { ...value.betting },
                            daily: { ...value.daily }
                        };
                    } else {
                        user[key] = value;
                    }
                    needsUpdate = true;
                }
            }
            
            if (user.minerales) {
                for (const mineral of Object.keys(defaultUserData.minerales)) {
                    if (user.minerales[mineral] === undefined) {
                        user.minerales[mineral] = 0;
                        needsUpdate = true;
                    }
                }
            }

            if (user.prestamo) {
                for (const prop of Object.keys(defaultUserData.prestamo)) {
                    if (user.prestamo[prop] === undefined) {
                        user.prestamo[prop] = defaultUserData.prestamo[prop];
                        needsUpdate = true;
                    }
                }
            }

            if (user.betStats) {
                for (const prop of Object.keys(defaultUserData.betStats)) {
                    if (user.betStats[prop] === undefined) {
                        user.betStats[prop] = defaultUserData.betStats[prop];
                        needsUpdate = true;
                    }
                }
            } else {
                user.betStats = { ...defaultUserData.betStats };
                needsUpdate = true;
            }

            // pene_upgrades, vagina_upgrades y masturbar_cd/masturbar_dado NO se inicializan aquí — solo existen si el usuario usó el comando
            
            // Asignación automática del rango máximo solo para premium comprado
            try {
                const premium = require('./premium');
                if (premium.hasPremiumMaxRank(cleanNumber)) {
                    const rankupPlugin = require('./plugins/rankup');
                    if (rankupPlugin && typeof rankupPlugin.getMaxRango === 'function') {
                        const maxRango = rankupPlugin.getMaxRango();
                        if (user.rango !== maxRango) {
                            user.rango = maxRango;
                            needsUpdate = true;
                        }
                    }
                }
            } catch (_) {}

            if (needsUpdate) {
                this.data.users[cleanNumber] = user;
                this.save();
            }
            
            return this.data.users[cleanNumber];
        } catch (error) {
            console.error('[Database] Error obteniendo usuario:', error.message);
            return null;
        }
    }

    setUser(sender, userData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(sender);
            const currentUserData = this.data.users[cleanNumber] || createDefaultUserData();
            
            const updatedUserData = {
                name: userData.name !== undefined ? userData.name : currentUserData.name || '',
                ComandosEjecutados: userData.ComandosEjecutados !== undefined ? userData.ComandosEjecutados : currentUserData.ComandosEjecutados || 0,
                genero: userData.genero !== undefined ? userData.genero : currentUserData.genero || null,
                rango: userData.rango !== undefined ? userData.rango : currentUserData.rango || '🌱 Novato',
                respeto: userData.respeto !== undefined ? userData.respeto : currentUserData.respeto || 0,
                level: userData.level !== undefined ? userData.level : currentUserData.level || 0,
                exp: userData.exp !== undefined ? userData.exp : currentUserData.exp || 0,
                escudosAntiRobos: userData.escudosAntiRobos !== undefined ? userData.escudosAntiRobos : currentUserData.escudosAntiRobos || 0,
                money: userData.money !== undefined ? userData.money : currentUserData.money || 0,
                bank: userData.bank !== undefined ? userData.bank : currentUserData.bank || 0,
                warns: userData.warns !== undefined ? userData.warns : currentUserData.warns || 0,
                accesscode: userData.accesscode !== undefined ? userData.accesscode : currentUserData.accesscode || null,
                isBanned: userData.isBanned !== undefined ? userData.isBanned : currentUserData.isBanned || false,
                lastWork: userData.lastWork !== undefined ? userData.lastWork : currentUserData.lastWork || 0,
                workedHours: userData.workedHours !== undefined ? userData.workedHours : currentUserData.workedHours || 0,
                totalWorkedHours: userData.totalWorkedHours !== undefined ? userData.totalWorkedHours : currentUserData.totalWorkedHours || 0,
                totalWorkedTimes: userData.totalWorkedTimes !== undefined ? userData.totalWorkedTimes : currentUserData.totalWorkedTimes || 0,
                rank: userData.rank !== undefined ? Number(userData.rank) || 0 : Number(currentUserData.rank) || 0,
                lastDaily: userData.lastDaily !== undefined ? userData.lastDaily : currentUserData.lastDaily || 0,
                lastClanAttack: userData.lastClanAttack !== undefined ? Number(userData.lastClanAttack) || 0 : Number(currentUserData.lastClanAttack) || 0,
                registered: userData.registered !== undefined ? userData.registered : currentUserData.registered || false,
                premium: userData.premium !== undefined ? userData.premium : currentUserData.premium || false,
                banned: userData.banned !== undefined ? userData.banned : currentUserData.banned || false,
                reseña: userData.reseña !== undefined ? userData.reseña : currentUserData.reseña || null,
                apodo: userData.apodo !== undefined ? userData.apodo : currentUserData.apodo || '',
                cookies: userData.cookies !== undefined ? Number(userData.cookies) || 0 : Number(currentUserData.cookies) || 0,
                auto: userData.auto !== undefined ? Number(userData.auto) || 0 : Number(currentUserData.auto) || 0,
                manual: userData.manual !== undefined ? Number(userData.manual) || 0 : Number(currentUserData.manual) || 0,
                lastAuto: userData.lastAuto !== undefined ? Number(userData.lastAuto) || Date.now() : Number(currentUserData.lastAuto) || Date.now(),
                lastCookie: userData.lastCookie !== undefined ? Number(userData.lastCookie) || 0 : Number(currentUserData.lastCookie) || 0,
                pet: userData.pet !== undefined ? {
                    name: userData.pet.name !== undefined ? userData.pet.name : (currentUserData.pet ? currentUserData.pet.name : "Mi Mascota"),
                    type: userData.pet.type !== undefined ? userData.pet.type : (currentUserData.pet ? currentUserData.pet.type : "perro"),
                    level: userData.pet.level !== undefined ? Number(userData.pet.level) || 1 : (currentUserData.pet ? Number(currentUserData.pet.level) || 1 : 1),
                    food: userData.pet.food !== undefined ? Number(userData.pet.food) || 0 : (currentUserData.pet ? Number(currentUserData.pet.food) || 0 : 0),
                    requiredFood: userData.pet.requiredFood !== undefined ? Number(userData.pet.requiredFood) || 100 : (currentUserData.pet ? Number(currentUserData.pet.requiredFood) || 100 : 100)
                } : (currentUserData.pet || {
                    name: "Mi Mascota",
                    type: "perro",
                    level: 1,
                    food: 0,
                    requiredFood: 100
                }),
                lastMining: userData.lastMining !== undefined ? userData.lastMining : currentUserData.lastMining || 0,
                lastPremio: userData.lastPremio !== undefined ? Number(userData.lastPremio) || 0 : Number(currentUserData.lastPremio) || 0,
                minerales: userData.minerales !== undefined ? {
                    ...defaultUserData.minerales,
                    ...userData.minerales
                } : (currentUserData.minerales || { ...defaultUserData.minerales }),
                prestamo: userData.prestamo !== undefined ? {
                    activo: userData.prestamo.activo !== undefined ? userData.prestamo.activo : (currentUserData.prestamo ? currentUserData.prestamo.activo : false),
                    monto: userData.prestamo.monto !== undefined ? Number(userData.prestamo.monto) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.monto) || 0 : 0),
                    deuda: userData.prestamo.deuda !== undefined ? Number(userData.prestamo.deuda) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.deuda) || 0 : 0),
                    intereses: userData.prestamo.intereses !== undefined ? Number(userData.prestamo.intereses) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.intereses) || 0 : 0),
                    fechaPrestamo: userData.prestamo.fechaPrestamo !== undefined ? Number(userData.prestamo.fechaPrestamo) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.fechaPrestamo) || 0 : 0)
                } : (currentUserData.prestamo || {
                    activo: false,
                    monto: 0,
                    deuda: 0,
                    intereses: 0,
                    fechaPrestamo: 0
                }),
                betStats: userData.betStats !== undefined ? {
                    totalBets: userData.betStats.totalBets !== undefined ? Number(userData.betStats.totalBets) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalBets) || 0 : 0),
                    totalWins: userData.betStats.totalWins !== undefined ? Number(userData.betStats.totalWins) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalWins) || 0 : 0),
                    totalLosses: userData.betStats.totalLosses !== undefined ? Number(userData.betStats.totalLosses) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalLosses) || 0 : 0),
                    totalBetAmount: userData.betStats.totalBetAmount !== undefined ? Number(userData.betStats.totalBetAmount) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalBetAmount) || 0 : 0),
                    totalWonAmount: userData.betStats.totalWonAmount !== undefined ? Number(userData.betStats.totalWonAmount) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalWonAmount) || 0 : 0),
                    totalLostAmount: userData.betStats.totalLostAmount !== undefined ? Number(userData.betStats.totalLostAmount) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalLostAmount) || 0 : 0),
                    biggestBet: userData.betStats.biggestBet !== undefined ? Number(userData.betStats.biggestBet) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestBet) || 0 : 0),
                    biggestWin: userData.betStats.biggestWin !== undefined ? Number(userData.betStats.biggestWin) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestWin) || 0 : 0),
                    biggestLoss: userData.betStats.biggestLoss !== undefined ? Number(userData.betStats.biggestLoss) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestLoss) || 0 : 0),
                    currentStreak: userData.betStats.currentStreak !== undefined ? Number(userData.betStats.currentStreak) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.currentStreak) || 0 : 0),
                    bestWinStreak: userData.betStats.bestWinStreak !== undefined ? Number(userData.betStats.bestWinStreak) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.bestWinStreak) || 0 : 0),
                    worstLoseStreak: userData.betStats.worstLoseStreak !== undefined ? Number(userData.betStats.worstLoseStreak) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.worstLoseStreak) || 0 : 0),
                    lastBetTime: userData.betStats.lastBetTime !== undefined ? Number(userData.betStats.lastBetTime) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.lastBetTime) || 0 : 0)
                } : (currentUserData.betStats || {
                    totalBets: 0,
                    totalWins: 0,
                    totalLosses: 0,
                    totalBetAmount: 0,
                    totalWonAmount: 0,
                    totalLostAmount: 0,
                    biggestBet: 0,
                    biggestWin: 0,
                    biggestLoss: 0,
                    currentStreak: 0,
                    bestWinStreak: 0,
                    worstLoseStreak: 0,
                    lastBetTime: 0
                }),
                achievements: userData.achievements !== undefined ? {
                    commands: {
                        total: userData.achievements.commands?.total !== undefined ? Number(userData.achievements.commands.total) || 0 : (currentUserData.achievements?.commands?.total || 0),
                        milestones: Array.isArray(userData.achievements.commands?.milestones) ? userData.achievements.commands.milestones : (currentUserData.achievements?.commands?.milestones || [])
                    },
                    work: {
                        total: userData.achievements.work?.total !== undefined ? Number(userData.achievements.work.total) || 0 : (currentUserData.achievements?.work?.total || 0),
                        milestones: Array.isArray(userData.achievements.work?.milestones) ? userData.achievements.work.milestones : (currentUserData.achievements?.work?.milestones || [])
                    },
                    betting: {
                        total: userData.achievements.betting?.total !== undefined ? Number(userData.achievements.betting.total) || 0 : (currentUserData.achievements?.betting?.total || 0),
                        milestones: Array.isArray(userData.achievements.betting?.milestones) ? userData.achievements.betting.milestones : (currentUserData.achievements?.betting?.milestones || [])
                    },
                    daily: {
                        total: userData.achievements.daily?.total !== undefined ? Number(userData.achievements.daily.total) || 0 : (currentUserData.achievements?.daily?.total || 0),
                        milestones: Array.isArray(userData.achievements.daily?.milestones) ? userData.achievements.daily.milestones : (currentUserData.achievements?.daily?.milestones || [])
                    }
                } : (currentUserData.achievements || {
                    commands: { total: 0, milestones: [] },
                    work: { total: 0, milestones: [] },
                    betting: { total: 0, milestones: [] },
                    daily: { total: 0, milestones: [] }
                }),
                // (Se eliminó noDecor: ya no existe sistema de "enriquecimiento"/decor)
            };

            // Preservar campos extra que no forman parte del schema fijo
            // (ej: pene_upgrades, vagina_upgrades, futuras extensiones de plugins)
            for (const key of Object.keys(currentUserData)) {
                if (!(key in updatedUserData)) {
                    updatedUserData[key] = currentUserData[key];
                }
            }
            
            this.data.users[cleanNumber] = updatedUserData;
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando usuario:', error.message);
            return false;
        }
    }

    getGroup(groupId) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            if (!this.data.groups[groupId]) {
                this.data.groups[groupId] = {
                    name: '',
                    welcome: false,
                    antiLink: false,
                    antiSticker: false,
                    antiToxic: false,
                    level: 0,
                    exp: 0
                };
                this.save();
            }
            return this.data.groups[groupId];
        } catch (error) {
            console.error('[Database] Error obteniendo grupo:', error.message);
            return null;
        }
    }

    getChat(chatId) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            if (!this.data.chats[chatId]) {
                this.data.chats[chatId] = {
                    name: '',
                    messages: 0,
                    commands: 0
                };
                this.save();
            }
            return this.data.chats[chatId];
        } catch (error) {
            console.error('[Database] Error obteniendo chat:', error.message);
            return null;
        }
    }

    // ==========================================
    // MÉTODOS PARA PAREJAS
    // ==========================================
    
    getParejas() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.parejas || {};
        } catch (error) {
            console.error('[Database] Error obteniendo parejas:', error.message);
            return {};
        }
    }

    getPareja(numero) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(numero);
            return this.data.parejas[cleanNumber] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo pareja:', error.message);
            return null;
        }
    }

    setPareja(numero, parejaData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(numero);
            
            if (parejaData === null || parejaData === undefined) {
                delete this.data.parejas[cleanNumber];
            } else {
                this.data.parejas[cleanNumber] = {
                    numero: parejaData.numero,
                    jid: parejaData.jid || null,
                    estado: parejaData.estado || 'pendiente',
                    fecha: parejaData.fecha || new Date().toISOString()
                };
            }
            
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando pareja:', error.message);
            return false;
        }
    }

    deletePareja(numero) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(numero);
            delete this.data.parejas[cleanNumber];
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error eliminando pareja:', error.message);
            return false;
        }
    }

    // ==========================================
    // MÉTODOS PARA PERSONAJES E INTERCAMBIOS ANIME
    // ==========================================

    getPersonajes(numero) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            return this.data.personajes[cleanNumber] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo personajes:', error.message);
            return null;
        }
    }

    setPersonajes(numero, personajesData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            if (personajesData === null || personajesData === undefined) {
                delete this.data.personajes[cleanNumber];
            } else {
                this.data.personajes[cleanNumber] = personajesData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando personajes:', error.message);
            return false;
        }
    }

    getAllPersonajes() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.personajes || {};
        } catch (error) {
            console.error('[Database] Error obteniendo todas las colecciones de personajes:', error.message);
            return {};
        }
    }

    getIntercambiosAnime() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.intercambiosAnime || {};
        } catch (error) {
            console.error('[Database] Error obteniendo intercambios anime:', error.message);
            return {};
        }
    }

    getIntercambioAnime(key) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.intercambiosAnime[key] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo intercambio anime:', error.message);
            return null;
        }
    }

    setIntercambioAnime(key, intercambioData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            if (intercambioData === null || intercambioData === undefined) {
                delete this.data.intercambiosAnime[key];
            } else {
                this.data.intercambiosAnime[key] = intercambioData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando intercambio anime:', error.message);
            return false;
        }
    }

    deleteIntercambioAnime(key) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            delete this.data.intercambiosAnime[key];
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error eliminando intercambio anime:', error.message);
            return false;
        }
    }

    getFutbolistas(numero) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            return this.data.futbolistas[cleanNumber] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo futbolistas:', error.message);
            return null;
        }
    }

    setFutbolistas(numero, futbolistasData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            if (futbolistasData === null || futbolistasData === undefined) {
                delete this.data.futbolistas[cleanNumber];
            } else {
                this.data.futbolistas[cleanNumber] = futbolistasData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando futbolistas:', error.message);
            return false;
        }
    }

    getAllFutbolistas() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.futbolistas || {};
        } catch (error) {
            console.error('[Database] Error obteniendo todas las colecciones de futbolistas:', error.message);
            return {};
        }
    }

    getIntercambiosFutbol() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.intercambiosFutbol || {};
        } catch (error) {
            console.error('[Database] Error obteniendo intercambios futbol:', error.message);
            return {};
        }
    }

    getIntercambioFutbol(key) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.intercambiosFutbol[key] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo intercambio futbol:', error.message);
            return null;
        }
    }

    setIntercambioFutbol(key, intercambioData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            if (intercambioData === null || intercambioData === undefined) {
                delete this.data.intercambiosFutbol[key];
            } else {
                this.data.intercambiosFutbol[key] = intercambioData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando intercambio futbol:', error.message);
            return false;
        }
    }

    deleteIntercambioFutbol(key) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            delete this.data.intercambiosFutbol[key];
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error eliminando intercambio futbol:', error.message);
            return false;
        }
    }

    // ==========================================
    // MÉTODOS PARA FIGURITAS
    // ==========================================

    getFiguritas(numero) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            return this.data.figuritas[cleanNumber] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo figuritas:', error.message);
            return null;
        }
    }

    setFiguritas(numero, figuritasData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            const cleanNumber = this.cleanNumber(numero);
            if (figuritasData === null || figuritasData === undefined) {
                delete this.data.figuritas[cleanNumber];
            } else {
                this.data.figuritas[cleanNumber] = figuritasData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando figuritas:', error.message);
            return false;
        }
    }

    getAllFiguritas() {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            return this.data.figuritas || {};
        } catch (error) {
            console.error('[Database] Error obteniendo todas las colecciones de figuritas:', error.message);
            return {};
        }
    }

    // ==========================================
    // MÉTODOS PARA FAMOSOS E INTERCAMBIOS
    // ==========================================

    getFamosos(numero) {
        try {
            if (!this.checkInitialization()) this.load();
            const cleanNumber = this.cleanNumber(numero);
            return this.data.famosos[cleanNumber] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo famosos:', error.message);
            return null;
        }
    }

    setFamosos(numero, famososData) {
        try {
            if (!this.checkInitialization()) this.load();
            const cleanNumber = this.cleanNumber(numero);
            if (famososData === null || famososData === undefined) {
                delete this.data.famosos[cleanNumber];
            } else {
                this.data.famosos[cleanNumber] = famososData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando famosos:', error.message);
            return false;
        }
    }

    getAllFamosos() {
        try {
            if (!this.checkInitialization()) this.load();
            return this.data.famosos || {};
        } catch (error) {
            console.error('[Database] Error obteniendo todas las colecciones de famosos:', error.message);
            return {};
        }
    }

    getIntercambiosFamosos() {
        try {
            if (!this.checkInitialization()) this.load();
            return this.data.intercambiosFamosos || {};
        } catch (error) {
            console.error('[Database] Error obteniendo intercambios famosos:', error.message);
            return {};
        }
    }

    getIntercambioFamoso(key) {
        try {
            if (!this.checkInitialization()) this.load();
            return this.data.intercambiosFamosos[key] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo intercambio famoso:', error.message);
            return null;
        }
    }

    setIntercambioFamoso(key, intercambioData) {
        try {
            if (!this.checkInitialization()) this.load();
            if (intercambioData === null || intercambioData === undefined) {
                delete this.data.intercambiosFamosos[key];
            } else {
                this.data.intercambiosFamosos[key] = intercambioData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando intercambio famoso:', error.message);
            return false;
        }
    }

    deleteIntercambioFamoso(key) {
        try {
            if (!this.checkInitialization()) this.load();
            delete this.data.intercambiosFamosos[key];
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error eliminando intercambio famoso:', error.message);
            return false;
        }
    }

    // ==========================================
    // MÉTODOS PARA CLANES
    // ==========================================

    getClanes() {
        try {
            if (!this.checkInitialization()) this.load();
            return this.data.clanes || {};
        } catch (error) {
            console.error('[Database] Error obteniendo clanes:', error.message);
            return {};
        }
    }

    getClan(nombreClan) {
        try {
            if (!this.checkInitialization()) this.load();
            // Búsqueda case-insensitive
            const clanes = this.data.clanes || {};
            const key = Object.keys(clanes).find(
                k => k.toLowerCase() === nombreClan.toLowerCase()
            );
            return key ? clanes[key] : null;
        } catch (error) {
            console.error('[Database] Error obteniendo clan:', error.message);
            return null;
        }
    }

    getClanByKey(key) {
        try {
            if (!this.checkInitialization()) this.load();
            return this.data.clanes?.[key] || null;
        } catch (error) {
            console.error('[Database] Error obteniendo clan por clave:', error.message);
            return null;
        }
    }

    setClan(nombreClan, clanData) {
        try {
            if (!this.checkInitialization()) this.load();
            if (!this.data.clanes) this.data.clanes = {};
            if (clanData === null || clanData === undefined) {
                delete this.data.clanes[nombreClan];
            } else {
                this.data.clanes[nombreClan] = clanData;
            }
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error actualizando clan:', error.message);
            return false;
        }
    }

    deleteClan(nombreClan) {
        try {
            if (!this.checkInitialization()) this.load();
            if (!this.data.clanes) return true;
            const clanes = this.data.clanes;
            const key = Object.keys(clanes).find(
                k => k.toLowerCase() === nombreClan.toLowerCase()
            );
            if (key) delete clanes[key];
            this.save();
            return true;
        } catch (error) {
            console.error('[Database] Error eliminando clan:', error.message);
            return false;
        }
    }

    // Obtener el clan al que pertenece un usuario (por número)
    getClanDeUsuario(numero) {
        try {
            if (!this.checkInitialization()) this.load();
            const cleanNumber = this.cleanNumber(numero);
            const clanes = this.data.clanes || {};
            for (const [nombre, clan] of Object.entries(clanes)) {
                if (!clan || !clan.miembros) continue;
                if (clan.miembros.includes(cleanNumber)) {
                    return { nombre, clan };
                }
            }
            return null;
        } catch (error) {
            console.error('[Database] Error buscando clan de usuario:', error.message);
            return null;
        }
    }

    backup() {
        try {
            const backupPath = path.join(__dirname, `database_backup_${Date.now()}.json`);
            fs.writeFileSync(backupPath, JSON.stringify(this.data, null, 2));
            console.log('[Database] ✓ Backup creado:', backupPath);
            return backupPath;
        } catch (error) {
            console.error('[Database] Error creando backup:', error.message);
            return null;
        }
    }

    getStats() {
        return {
            totalUsers: Object.keys(this.data.users).length,
            totalGroups: Object.keys(this.data.groups).length,
            totalChats: Object.keys(this.data.chats).length,
            databaseSize: fs.existsSync(this.filePath) ? fs.statSync(this.filePath).size : 0
        };
    }

    // Método para limpiar intervalos al destruir
    destroy() {
        if (this.periodicSaveInterval) {
            clearInterval(this.periodicSaveInterval);
            console.log('[Database] 🗑️ Intervalo de guardado limpiado');
        }
        
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
        }
        
        // Guardar cambios pendientes
        if (this.pendingChanges && !this.isSaving) {
            this.saveNow();
        }
    }
}

const db = new Database();
global.db = db;

module.exports = db;