const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

// ==========================================
// DEFAULT DATA SCHEMAS (unchanged from before)
// ==========================================

const defaultUserData = {
    name: '',
    warns: 0,
    ComandosEjecutados: 0,
    accesscode: null,
    isBanned: false,
    bank: 0,
    money: 0,
    escudosAntiRobos: 0,
    level: 0,
    exp: 0,
    lastWork: 0,
    workedHours: 0,
    totalWorkedHours: 0,
    totalWorkedTimes: 0,
    lastDaily: 0,
    lastClanAttack: 0,
    registered: false,
    premium: false,
    banned: false,
    reseña: null,
    apodo: '',
    rank: 0,
    respeto: 0,
    cookies: 0,
    auto: 0,
    manual: 0,
    lastCookie: 0,
    lastAuto: Date.now(),
    pet: {
        name: 'Mi Mascota',
        type: 'perro',
        level: 1,
        food: 0,
        requiredFood: 100
    },
    lastMining: 0,
    lastPremio: 0,
    minerales: {
        CARBON: 0,
        HIERRO: 0,
        PLATA: 0,
        ORO: 0,
        DIAMANTE: 0,
        ESMERALDA: 0,
        RUBI: 0
    },
    prestamo: {
        activo: false,
        monto: 0,
        deuda: 0,
        intereses: 0,
        fechaPrestamo: 0
    },
    betStats: {
        totalBets: 0,
        totalWins: 0,
        totalLosses: 0,
        totalBetAmount: 0,
        totalWonAmount: 0,
        totalLostAmount: 0,
        biggestBet: 0,
        biggestWin: 0,
        biggestLoss: 0,
        currentStreak: 0,
        bestWinStreak: 0,
        worstLoseStreak: 0,
        lastBetTime: 0
    },
    achievements: {
        commands: { total: 0, milestones: [] },
        work: { total: 0, milestones: [] },
        betting: { total: 0, milestones: [] },
        daily: { total: 0, milestones: [] }
    }
};

function createDefaultUserData() {
    return {
        ...defaultUserData,
        pet: { ...defaultUserData.pet },
        minerales: { ...defaultUserData.minerales },
        prestamo: { ...defaultUserData.prestamo },
        betStats: { ...defaultUserData.betStats },
        achievements: {
            commands: { total: 0, milestones: [] },
            work: { total: 0, milestones: [] },
            betting: { total: 0, milestones: [] },
            daily: { total: 0, milestones: [] }
        }
    };
}

// ==========================================
// USER DATA MERGE HELPER
// ==========================================

function safeTimestamp(val) {
    if (!val) return 0;
    if (typeof val === 'number') return isNaN(val) ? 0 : val;
    if (val instanceof Date) return val.getTime();
    if (typeof val === 'string') {
        const parsed = new Date(val).getTime();
        return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
}

function mergeUserObjects(u1, u2) {
    if (!u1) return u2 ? JSON.parse(JSON.stringify(u2)) : createDefaultUserData();
    if (!u2) return JSON.parse(JSON.stringify(u1));

    // Determine base user (the one with higher overall activity / commands executed)
    const score1 = (u1.ComandosEjecutados || 0) * 100 + (u1.level || 0) * 10;
    const score2 = (u2.ComandosEjecutados || 0) * 100 + (u2.level || 0) * 10;

    const base = JSON.parse(JSON.stringify(score1 >= score2 ? u1 : u2));
    const secondary = score1 >= score2 ? u2 : u1;

    // Numerical stats (activity/leveling): take max
    const activityMaxFields = [
        'ComandosEjecutados', 'exp', 'level', 'respeto',
        'rank', 'warns', 'escudosAntiRobos', 'workedHours', 'totalWorkedHours',
        'totalWorkedTimes', 'cookies', 'auto', 'manual'
    ];

    for (const field of activityMaxFields) {
        const v1 = Number(base[field]) || 0;
        const v2 = Number(secondary[field]) || 0;
        base[field] = Math.max(v1, v2);
    }

    // Money and Bank: PRESERVE base account balances (NEVER Math.max money or bank, as it restores spent money)
    base.money = typeof base.money === 'number' ? base.money : (typeof secondary.money === 'number' ? secondary.money : 0);
    base.bank  = typeof base.bank  === 'number' ? base.bank  : (typeof secondary.bank  === 'number' ? secondary.bank  : 0);

    // Cooldown timestamps: ALWAYS take max (most recent activity timestamp)
    const cooldownFields = [
        'lastWork', 'lastDaily', 'lastMining', 'lastPremio', 'lastAuto',
        'lastCookie', 'lastClanAttack', 'lastSlut', 'lastHunt', 'lastCrime',
        'lastCazar', 'lastRobar', 'lastPenal'
    ];

    for (const field of cooldownFields) {
        const t1 = safeTimestamp(base[field]);
        const t2 = safeTimestamp(secondary[field]);
        base[field] = Math.max(t1, t2);
    }

    // String fields: take non-empty / preferred
    if (!base.apodo || base.apodo === 'sin apodo') base.apodo = secondary.apodo || base.apodo || '';
    if (!base.name) base.name = secondary.name || '';
    if (!base.genero) base.genero = secondary.genero || null;
    if (!base.rango || base.rango === '🌱 Novato') base.rango = secondary.rango || base.rango || '🌱 Novato';
    if (!base.accesscode) base.accesscode = secondary.accesscode || null;

    // Pet: take pet with higher level or non-default name
    if (secondary.pet) {
        if (!base.pet) {
            base.pet = { ...secondary.pet };
        } else {
            const secLevel = Number(secondary.pet.level) || 1;
            const baseLevel = Number(base.pet.level) || 1;
            if (secLevel > baseLevel || (base.pet.name === 'Mi Mascota' && secondary.pet.name !== 'Mi Mascota')) {
                base.pet = { ...secondary.pet };
            }
        }
    }

    // Minerales: merge by max per mineral
    base.minerales = base.minerales || { ...defaultUserData.minerales };
    if (secondary.minerales) {
        for (const [m, qty] of Object.entries(secondary.minerales)) {
            base.minerales[m] = Math.max(Number(base.minerales[m]) || 0, Number(qty) || 0);
        }
    }

    // Prestamo: keep active prestamo
    if (secondary.prestamo && secondary.prestamo.activo && (!base.prestamo || !base.prestamo.activo)) {
        base.prestamo = { ...secondary.prestamo };
    }

    // BetStats: take max
    if (secondary.betStats) {
        base.betStats = base.betStats || { ...defaultUserData.betStats };
        for (const [k, v] of Object.entries(secondary.betStats)) {
            if (typeof v === 'number') {
                base.betStats[k] = Math.max(Number(base.betStats[k]) || 0, Number(v) || 0);
            }
        }
    }

    // Achievements: merge totals and milestones
    if (secondary.achievements) {
        base.achievements = base.achievements || { ...defaultUserData.achievements };
        for (const cat of ['commands', 'work', 'betting', 'daily']) {
            if (secondary.achievements[cat]) {
                base.achievements[cat] = base.achievements[cat] || { total: 0, milestones: [] };
                base.achievements[cat].total = Math.max(
                    Number(base.achievements[cat].total) || 0,
                    Number(secondary.achievements[cat].total) || 0
                );
                const m1 = base.achievements[cat].milestones || [];
                const m2 = secondary.achievements[cat].milestones || [];
                base.achievements[cat].milestones = Array.from(new Set([...m1, ...m2]));
            }
        }
    }

    // Preserve ANY custom/plugin fields present in secondary that aren't in base
    for (const [key, val] of Object.entries(secondary)) {
        if (base[key] === undefined || base[key] === null) {
            base[key] = val;
        } else if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
            if (typeof base[key] === 'object' && base[key] !== null) {
                for (const [subK, subV] of Object.entries(val)) {
                    if (base[key][subK] === undefined) {
                        base[key][subK] = subV;
                    }
                }
            }
        }
    }

    return base;
}

// ==========================================
// SQLITE DATABASE CLASS  (node:sqlite — built-in, no compilation needed)
// ==========================================

class Database {
    constructor() {
        this.dbPath = path.join(__dirname, 'database.db');
        this.jsonPath = path.join(__dirname, 'database.json');
        this.isInitialized = false;

        // In-memory user cache — replicates the old JSON behavior where getUser()
        // always returned the SAME object reference. Plugins mutate that object
        // and call save(), which flushes dirty entries back to SQLite.
        // Map<canonicalKey, { obj, dirty, aliases: Set<string> }>
        this._userCache = new Map();

        // In-memory KV cache — Map<collectionName, Map<key, { value, dirty }>>
        this._kvCache = new Map();

        // Fast in-memory caches for db.data.users, db.data.groups, db.data.chats
        this._usersMapCache = null;
        this._usersProxyCache = null;
        this._groupsMapCache = null;
        this._chatsMapCache = null;

        // Legacy compat flags
        this.pendingChanges = false;
        this.isSaving = false;
        this.saveTimeout = null;

        this._openDb();
        this._initSchema();
        this._migrateFromJsonIfNeeded();
        this._repairLegacyDotZeroUsers();

        this.isInitialized = true;
        console.log('[Database] ✓ SQLite lista (WAL mode) — node:sqlite built-in');

        // Periodic WAL checkpoint + flush dirty cache every 5 minutes
        this.periodicSaveInterval = setInterval(() => {
            try {
                this._flushDirty();
                this.db.exec('PRAGMA wal_checkpoint(PASSIVE)');
            } catch (e) {
                console.error('[Database] Error en checkpoint WAL:', e.message);
            }
        }, 5 * 60 * 1000);
    }

    _flushDirty() {
        try {
            for (const [key, entry] of this._userCache.entries()) {
                if (entry && entry.dirty && entry.obj) {
                    try {
                        this._stmts.setUser.run(key, JSON.stringify(entry.obj));
                        entry.dirty = false;
                    } catch (_) {}
                }
            }
            // Control de retención en memoria: evitar que _userCache crezca indefinidamente
            if (this._userCache.size > 2000) {
                let toRemove = this._userCache.size - 1500;
                for (const [k, v] of this._userCache.entries()) {
                    if (toRemove <= 0) break;
                    if (!v.dirty) {
                        this._userCache.delete(k);
                        toRemove--;
                    }
                }
            }
            // Limpiar cache de mapa proxy si creció demasiado
            if (this._usersMapCache && Object.keys(this._usersMapCache).length > 2500) {
                this._usersMapCache = null;
                this._usersProxyCache = null;
            }
        } catch (e) {
            console.error('[Database] Error en _flushDirty:', e.message);
        }
    }

    save() {
        if (this.saveTimeout) return;
        this.saveTimeout = setTimeout(() => {
            this.saveTimeout = null;
            this._flushDirty();
        }, 1000);
    }

    saveNow() {
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
            this.saveTimeout = null;
        }
        this._flushDirty();
    }

    // ==========================================
    // INTERNAL: OPEN + CONFIGURE SQLite
    // ==========================================

    _openDb() {
        this.db = new DatabaseSync(this.dbPath);
        this.db.exec('PRAGMA journal_mode=WAL');
        this.db.exec('PRAGMA synchronous=NORMAL');
        this.db.exec('PRAGMA foreign_keys=ON');
        this.db.exec('PRAGMA cache_size=-8000'); // 8 MB RAM cache optimizado (en lugar de 32MB)
        this.db.exec('PRAGMA temp_store=MEMORY');
    }

    _initSchema() {
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS groups (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS chats (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            -- Generic key-value store for:
            -- parejas, personajes, futbolistas, intercambiosAnime,
            -- intercambiosFutbol, figuritas, famosos, intercambiosFamosos,
            -- clanes, aliases, groupActivity
            CREATE TABLE IF NOT EXISTS kv (
                collection TEXT NOT NULL,
                key        TEXT NOT NULL,
                value      TEXT NOT NULL,
                PRIMARY KEY (collection, key)
            );
        `);

        // Prepared statements — compiled once, reused for performance
        this._stmts = {
            getUser:     this.db.prepare('SELECT data FROM users WHERE id = ?'),
            setUser:     this.db.prepare('INSERT OR REPLACE INTO users (id, data) VALUES (?, ?)'),
            getAllUsers:  this.db.prepare('SELECT id, data FROM users'),
            countUsers:  this.db.prepare('SELECT COUNT(*) AS c FROM users'),

            getGroup:    this.db.prepare('SELECT data FROM groups WHERE id = ?'),
            setGroup:    this.db.prepare('INSERT OR REPLACE INTO groups (id, data) VALUES (?, ?)'),
            getAllGroups: this.db.prepare('SELECT id, data FROM groups'),
            countGroups: this.db.prepare('SELECT COUNT(*) AS c FROM groups'),

            getChat:     this.db.prepare('SELECT data FROM chats WHERE id = ?'),
            setChat:     this.db.prepare('INSERT OR REPLACE INTO chats (id, data) VALUES (?, ?)'),
            getAllChats:  this.db.prepare('SELECT id, data FROM chats'),
            countChats:  this.db.prepare('SELECT COUNT(*) AS c FROM chats'),

            kvGet:       this.db.prepare('SELECT value FROM kv WHERE collection = ? AND key = ?'),
            kvSet:       this.db.prepare('INSERT OR REPLACE INTO kv (collection, key, value) VALUES (?, ?, ?)'),
            kvDel:       this.db.prepare('DELETE FROM kv WHERE collection = ? AND key = ?'),
            kvAll:       this.db.prepare('SELECT key, value FROM kv WHERE collection = ?'),
        };
    }

    // ==========================================
    // MIGRATION: database.json → SQLite
    // ==========================================

    _migrateFromJsonIfNeeded() {
        if (!fs.existsSync(this.jsonPath)) return;

        console.log('[Database] 🔄 Procesando y fusionando database.json → SQLite...');
        const startTime = Date.now();

        try {
            const raw = fs.readFileSync(this.jsonPath, 'utf8');
            const jsonData = JSON.parse(raw);

            const insertUsers  = this.db.prepare('INSERT OR REPLACE INTO users (id, data) VALUES (?, ?)');
            const insertGroups = this.db.prepare('INSERT OR REPLACE INTO groups (id, data) VALUES (?, ?)');
            const insertChats  = this.db.prepare('INSERT OR REPLACE INTO chats (id, data) VALUES (?, ?)');
            const insertKv     = this.db.prepare('INSERT OR REPLACE INTO kv (collection, key, value) VALUES (?, ?, ?)');

            this.db.exec('BEGIN');
            try {
                // Users — merge existing SQLite user with JSON user if both exist
                for (const [id, data] of Object.entries(jsonData.users || {})) {
                    if (data && typeof data === 'object') {
                        const existingRow = this._stmts.getUser.get(id);
                        let finalData = data;
                        if (existingRow) {
                            try {
                                const dbUser = JSON.parse(existingRow.data);
                                finalData = mergeUserObjects(dbUser, data);
                            } catch (_) {}
                        }
                        insertUsers.run(id, JSON.stringify(finalData));
                    }
                }

                // Groups
                for (const [id, data] of Object.entries(jsonData.groups || {})) {
                    if (data && typeof data === 'object') {
                        insertGroups.run(id, JSON.stringify(data));
                    }
                }

                // Chats
                for (const [id, data] of Object.entries(jsonData.chats || {})) {
                    if (data && typeof data === 'object') {
                        insertChats.run(id, JSON.stringify(data));
                    }
                }

                // Key-value collections
                const kvCollections = [
                    'parejas', 'personajes', 'intercambiosAnime', 'futbolistas',
                    'intercambiosFutbol', 'figuritas', 'famosos', 'intercambiosFamosos',
                    'clanes', 'groupActivity'
                ];
                for (const collection of kvCollections) {
                    const data = jsonData[collection];
                    if (!data || typeof data !== 'object') continue;
                    for (const [key, value] of Object.entries(data)) {
                        if (value !== undefined && value !== null) {
                            insertKv.run(collection, key, JSON.stringify(value));
                        }
                    }
                }

                // Aliases
                if (jsonData.aliases) {
                    for (const [aliasKey, targetKey] of Object.entries(jsonData.aliases)) {
                        insertKv.run('aliases', aliasKey, targetKey);
                    }
                }

                this.db.exec('COMMIT');

                // Now execute linkUserAlias for all aliases in JSON to ensure 100% data fusion
                if (jsonData.aliases) {
                    for (const [aliasKey, targetKey] of Object.entries(jsonData.aliases)) {
                        this.linkUserAlias(aliasKey, targetKey);
                    }
                }

            } catch (err) {
                this.db.exec('ROLLBACK');
                throw err;
            }

            const elapsed = Date.now() - startTime;
            const userCount = this._stmts.countUsers.get().c;
            console.log(`[Database] ✓ Migración/Fusión completada en ${elapsed}ms — ${userCount} usuarios listos`);

            // Rename JSON as backup (never delete it)
            const backupPath = this.jsonPath + '.migrated';
            try {
                if (fs.existsSync(backupPath)) fs.unlinkSync(backupPath);
                fs.renameSync(this.jsonPath, backupPath);
            } catch (_) {}
            console.log(`[Database] 📦 Backup del JSON guardado en: database.json.migrated`);

        } catch (error) {
            console.error('[Database] ❌ Error en migración:', error.message);
        }
    }

    // ==========================================
    // INTERNAL HELPERS
    // ==========================================

    cleanNumber(sender) {
        if (!sender) return '';
        let str = String(sender).split('@')[0].split(':')[0].trim();
        str = str.replace(/\.0+$/, '');
        return str.replace(/[^0-9]/g, '');
    }

    getCanonicalId(sender) {
        if (!sender) return '';
        const clean = this.cleanNumber(sender);
        if (!clean) return '';
        try {
            const aliasRow = this._stmts && this._stmts.kvGet ? this._stmts.kvGet.get('aliases', clean) : null;
            return aliasRow ? aliasRow.value : clean;
        } catch (_) {
            return clean;
        }
    }


    _repairLegacyDotZeroUsers() {
        try {
            const rows = this._stmts.getAllUsers.all();
            const delStmt = this.db.prepare('DELETE FROM users WHERE id = ?');
            const aliases = this._getKvAll('aliases') || {};
            let cleanedCount = 0;

            for (const row of rows) {
                const cleanId = this.cleanNumber(row.id);
                const targetId = String(aliases[cleanId] || aliases[row.id] || cleanId);

                // Delete non-canonical or duplicate JID / .0 rows from SQLite users table
                if (row.id !== targetId || row.id.includes('@') || row.id.includes(':') || row.id.endsWith('.0')) {
                    let dotData = {};
                    try { dotData = JSON.parse(row.data); } catch (_) {}

                    const canonicalUser = this.getUser(targetId);
                    if (canonicalUser && dotData) {
                        const merged = mergeUserObjects(canonicalUser, dotData);
                        Object.assign(canonicalUser, merged);
                        this._stmts.setUser.run(targetId, JSON.stringify(canonicalUser));
                    }

                    this._stmts.kvSet.run('aliases', row.id, targetId);
                    if (cleanId && cleanId !== targetId) {
                        this._stmts.kvSet.run('aliases', cleanId, targetId);
                    }
                    if (row.id !== targetId) {
                        delStmt.run(row.id);
                        cleanedCount++;
                    }
                }
            }
            // Auto-detect and link unlinked LID <-> Phone Number pairs sharing the same nickname
            const currentUsers = this._stmts.getAllUsers.all();
            const byApodo = {};
            for (const r of currentUsers) {
                try {
                    const u = JSON.parse(r.data);
                    const ap = String(u.apodo || '').trim();
                    if (ap && ap.toLowerCase() !== 'sin apodo' && ap !== '.' && ap !== '-') {
                        byApodo[ap] = byApodo[ap] || [];
                        byApodo[ap].push(r.id);
                    }
                } catch (_) {}
            }

            let linkedLidsCount = 0;
            for (const list of Object.values(byApodo)) {
                if (list.length > 1) {
                    const phoneId = list.find(id => id.length <= 13 && !id.startsWith('14') && !id.startsWith('18') && !id.startsWith('21'));
                    const lidId = list.find(id => id.length > 13 || id.startsWith('14') || id.startsWith('18') || id.startsWith('21'));
                    if (phoneId && lidId && phoneId !== lidId) {
                        this.linkUserAlias(lidId, phoneId);
                        delStmt.run(lidId);
                        linkedLidsCount++;
                    }
                }
            }
            if (cleanedCount > 0 || linkedLidsCount > 0) {
                console.log(`[Database] ✓ Consolidación y vinculación de ${cleanedCount + linkedLidsCount} usuarios LID/duplicados en SQLite completada.`);
            }
        } catch (e) {
            console.error('[Database] Error consolidando claves duplicadas:', e.message);
        }
    }

    _getKvCol(collection) {
        if (!this._kvCache.has(collection)) {
            this._kvCache.set(collection, new Map());
        }
        return this._kvCache.get(collection);
    }

    _getKvAll(collection) {
        const colMap = this._getKvCol(collection);
        const rows = this._stmts.kvAll.all(collection);
        for (const row of rows) {
            if (!colMap.has(row.key)) {
                let val = null;
                try { val = JSON.parse(row.value); } catch (_) { val = row.value; }
                colMap.set(row.key, { value: val, dirty: false });
            }
        }
        const result = {};
        for (const [key, entry] of colMap.entries()) {
            if (entry.value !== null && entry.value !== undefined) {
                result[key] = entry.value;
            }
        }
        return result;
    }

    _getKv(collection, key) {
        if (!key) return null;
        const normKey = (typeof key === 'string' && (key.includes('@') || key.includes(':') || /^\d+$/.test(key))) ? (this.cleanNumber(key) || key) : String(key);
        const colMap = this._getKvCol(collection);
        if (colMap.has(normKey)) {
            return colMap.get(normKey).value;
        }
        const row = this._stmts.kvGet.get(collection, normKey);
        let val = null;
        if (row) {
            try { val = JSON.parse(row.value); } catch (_) { val = row.value; }
        }
        colMap.set(normKey, { value: val, dirty: false });
        return val;
    }

    _setKv(collection, key, value) {
        if (!key) return;
        const normKey = (typeof key === 'string' && (key.includes('@') || key.includes(':') || /^\d+$/.test(key))) ? (this.cleanNumber(key) || key) : String(key);
        const colMap = this._getKvCol(collection);
        colMap.set(normKey, { value, dirty: true });
        if (value === null || value === undefined) {
            this._stmts.kvDel.run(collection, normKey);
        } else {
            this._stmts.kvSet.run(collection, normKey, JSON.stringify(value));
        }
    }

    // ==========================================
    // INTERNAL: flush dirty cache → SQLite
    // ==========================================

    _flushDirtyUsers() {
        for (const [canonicalKey, entry] of this._userCache.entries()) {
            if (!entry.dirty) continue;
            try {
                const jsonStr = JSON.stringify(entry.obj);
                // Write under canonical key ONLY
                this._stmts.setUser.run(canonicalKey, jsonStr);
                // Save alias mappings in KV store
                for (const aliasKey of entry.aliases) {
                    if (aliasKey !== canonicalKey) {
                        this._stmts.kvSet.run('aliases', aliasKey, canonicalKey);
                    }
                }
                entry.dirty = false;
            } catch (e) {
                console.error('[Database] Error flushing user cache:', e.message);
            }
        }
    }

    _flushDirtyKV() {
        for (const [collection, colMap] of this._kvCache.entries()) {
            for (const [key, entry] of colMap.entries()) {
                if (!entry.dirty) continue;
                try {
                    if (entry.value === null || entry.value === undefined) {
                        this._stmts.kvDel.run(collection, key);
                    } else {
                        this._stmts.kvSet.run(collection, key, JSON.stringify(entry.value));
                    }
                    entry.dirty = false;
                } catch (e) {
                    console.error(`[Database] Error flushing KV cache (${collection}/${key}):`, e.message);
                }
            }
        }
    }

    _flushDirty() {
        this._flushDirtyUsers();
        this._flushDirtyKV();
    }

    // ==========================================
    // COMPATIBILITY: save / saveNow / load
    // Plugins call save() after mutating a user or KV object — we flush dirty cache.
    // ==========================================

    markDirty(sender) {
        if (!sender) return;
        try {
            const cleanNumber = this.cleanNumber(sender);
            const aliasRow = this._stmts.kvGet.get('aliases', cleanNumber);
            const targetKey = aliasRow ? aliasRow.value : cleanNumber;
            const entry = this._userCache.get(targetKey) || this._userCache.get(cleanNumber);
            if (entry) {
                entry.dirty = true;
            }
        } catch (_) {}
    }

    save(sender) {
        if (sender) {
            this.markDirty(sender);
        } else {
            for (const entry of this._userCache.values()) {
                entry.dirty = true;
            }
        }
        for (const colMap of this._kvCache.values()) {
            for (const entry of colMap.values()) {
                entry.dirty = true;
            }
        }
        this.pendingChanges = true;
        if (!this.saveTimeout) {
            this.saveTimeout = setTimeout(() => {
                this.saveTimeout = null;
                try {
                    this._flushDirty();
                } catch (_) {}
            }, 1000);
        }
    }

    async saveNow() {
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
            this.saveTimeout = null;
        }
        try {
            this._flushDirty();
        } catch (_) {}
        this.pendingChanges = false;
        this.isSaving = false;
    }

    checkInitialization() {
        return this.isInitialized;
    }



    // ==========================================
    // ALIASES
    // ==========================================

    linkUserAlias(id1, id2) {
        try {
            const c1 = this.cleanNumber(id1);
            const c2 = this.cleanNumber(id2);
            if (!c1 || !c2 || c1 === c2) return;

            const alias1 = this._getKv('aliases', c1);
            const alias2 = this._getKv('aliases', c2);
            const target1 = alias1 || c1;
            const target2 = alias2 || c2;

            const entry1 = this._userCache.get(target1) || this._userCache.get(c1);
            const entry2 = this._userCache.get(target2) || this._userCache.get(c2);

            if (target1 === target2 && entry1 && entry2 && entry1 === entry2) return;

            // Pick primary target ID (prefer non-LID shorter phone number if available)
            let primaryTarget = target1;
            if (target2 && target2.length > 0 && target2.length < target1.length && !target2.startsWith('14')) {
                primaryTarget = target2;
            }

            let mergedUser;
            if (entry1 && !entry2) {
                mergedUser = entry1.obj;
            } else if (entry2 && !entry1) {
                mergedUser = entry2.obj;
            } else if (entry1 && entry2) {
                mergedUser = mergeUserObjects(entry1.obj, entry2.obj);
            } else {
                const u1Raw = this._stmts.getUser.get(target1) || this._stmts.getUser.get(c1);
                const u2Raw = this._stmts.getUser.get(target2) || this._stmts.getUser.get(c2);
                const u1 = u1Raw ? JSON.parse(u1Raw.data) : null;
                const u2 = u2Raw ? JSON.parse(u2Raw.data) : null;
                mergedUser = mergeUserObjects(u1, u2);
            }

            const jsonStr = JSON.stringify(mergedUser);
            const allKeys = Array.from(new Set([c1, c2, target1, target2, primaryTarget]));

            // Save merged user in database under primaryTarget key ONLY, and map aliases in KV
            this._stmts.setUser.run(primaryTarget, jsonStr);
            const delStmt = this.db.prepare('DELETE FROM users WHERE id = ?');
            for (const k of allKeys) {
                this._stmts.kvSet.run('aliases', k, primaryTarget);
                if (k !== primaryTarget) {
                    delStmt.run(k);
                }
            }

            // Update in-memory user cache so ALL keys share the EXACT SAME object reference in memory!
            const aliasSet = new Set(allKeys);
            let cacheEntry = entry1 || entry2 || { obj: mergedUser, dirty: false, aliases: aliasSet };
            Object.assign(cacheEntry.obj, mergedUser);
            cacheEntry.aliases = new Set([...(cacheEntry.aliases || []), ...allKeys]);

            for (const k of allKeys) {
                this._userCache.set(k, cacheEntry);
            }
        } catch (e) {
            console.error('[Database] Error en linkUserAlias:', e.message);
        }
    }

    // ==========================================
    // USERS
    // ==========================================

    getUser(sender) {
        try {
            const cleanNumber = this.cleanNumber(sender);

            // Resolve alias chain
            const aliasRow = this._stmts.kvGet.get('aliases', cleanNumber);
            const targetKey = aliasRow ? aliasRow.value : cleanNumber;

            // ── Cache hit: return the SAME object reference (old JSON behavior) ──
            if (this._userCache.has(targetKey)) {
                const entry = this._userCache.get(targetKey);
                entry.aliases.add(cleanNumber);
                return entry.obj;
            }

            let userRow = this._stmts.getUser.get(targetKey);
            if (!userRow && targetKey !== cleanNumber) {
                userRow = this._stmts.getUser.get(cleanNumber);
            }

            let user = userRow ? JSON.parse(userRow.data) : null;
            if (!user) {
                user = createDefaultUserData();
                this._stmts.setUser.run(targetKey, JSON.stringify(user));
            }

            // Merge any missing default fields (schema evolution)
            let needsUpdate = false;
            for (const [key, value] of Object.entries(defaultUserData)) {
                if (user[key] === undefined) {
                    if (key === 'minerales' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'pet' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'prestamo' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'betStats' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'achievements' && typeof value === 'object') {
                        user[key] = {
                            commands: { ...value.commands },
                            work:     { ...value.work },
                            betting:  { ...value.betting },
                            daily:    { ...value.daily }
                        };
                    } else {
                        user[key] = value;
                    }
                    needsUpdate = true;
                }
            }

            if (user.minerales) {
                for (const mineral of Object.keys(defaultUserData.minerales)) {
                    if (user.minerales[mineral] === undefined) {
                        user.minerales[mineral] = 0;
                        needsUpdate = true;
                    }
                }
            }

            if (user.prestamo) {
                for (const prop of Object.keys(defaultUserData.prestamo)) {
                    if (user.prestamo[prop] === undefined) {
                        user.prestamo[prop] = defaultUserData.prestamo[prop];
                        needsUpdate = true;
                    }
                }
            }

            if (user.betStats) {
                for (const prop of Object.keys(defaultUserData.betStats)) {
                    if (user.betStats[prop] === undefined) {
                        user.betStats[prop] = defaultUserData.betStats[prop];
                        needsUpdate = true;
                    }
                }
            } else {
                user.betStats = { ...defaultUserData.betStats };
                needsUpdate = true;
            }

            // Premium max rank check
            try {
                const premium = require('./premium');
                if (premium.hasPremiumMaxRank(cleanNumber)) {
                    const rankupPlugin = require('./plugins/rankup');
                    if (rankupPlugin && typeof rankupPlugin.getMaxRango === 'function') {
                        const maxRango = rankupPlugin.getMaxRango();
                        if (user.rango !== maxRango) {
                            user.rango = maxRango;
                            needsUpdate = true;
                        }
                    }
                }
            } catch (_) {}

            if (needsUpdate) {
                const jsonStr = JSON.stringify(user);
                this._stmts.setUser.run(targetKey, jsonStr);
                if (cleanNumber !== targetKey) {
                    this._stmts.setUser.run(cleanNumber, jsonStr);
                }
            }

            // ── Store in cache so future calls return the SAME object reference ──
            const aliasSet = new Set([cleanNumber, targetKey]);
            const cacheEntry = { obj: user, dirty: needsUpdate, aliases: aliasSet };
            this._userCache.set(targetKey, cacheEntry);
            this._userCache.set(cleanNumber, cacheEntry);
            if (this._usersMapCache) {
                this._usersMapCache[targetKey] = user;
            }

            return user;
        } catch (error) {
            console.error('[Database] Error obteniendo usuario:', error.message);
            return null;
        }
    }

    setUser(sender, userData) {
        try {
            const cleanNumber = this.cleanNumber(sender);

            // Resolve alias
            const aliasRow = this._stmts.kvGet.get('aliases', cleanNumber);
            const targetKey = aliasRow ? aliasRow.value : cleanNumber;

            const existingCacheEntry = this._userCache.get(targetKey) || this._userCache.get(cleanNumber);
            let baseData = existingCacheEntry ? existingCacheEntry.obj : null;
            if (!baseData) {
                const currentRow = this._stmts.getUser.get(targetKey) || this._stmts.getUser.get(cleanNumber);
                baseData = currentRow ? JSON.parse(currentRow.data) : createDefaultUserData();
            }

            const updatedUserData = {
                ...baseData,
                ...userData
            };

            // Explicitly force numeric values for money and bank from userData
            if (userData.money !== undefined) updatedUserData.money = Number(userData.money) || 0;
            if (userData.bank  !== undefined) updatedUserData.bank  = Number(userData.bank)  || 0;

            const jsonStr = JSON.stringify(updatedUserData);
            this._stmts.setUser.run(targetKey, jsonStr);
            if (cleanNumber !== targetKey) {
                this._stmts.kvSet.run('aliases', cleanNumber, targetKey);
            }

            // ── Actualizar el caché en el lugar, preservando la referencia de objeto ──
            if (existingCacheEntry) {
                Object.assign(existingCacheEntry.obj, updatedUserData);
                existingCacheEntry.dirty = false;
                if (!this._userCache.has(targetKey))  this._userCache.set(targetKey,  existingCacheEntry);
                if (!this._userCache.has(cleanNumber)) this._userCache.set(cleanNumber, existingCacheEntry);
            } else {
                const aliasSet = new Set([cleanNumber, targetKey]);
                const cacheEntry = { obj: updatedUserData, dirty: false, aliases: aliasSet };
                this._userCache.set(targetKey, cacheEntry);
                this._userCache.set(cleanNumber, cacheEntry);
            }

            if (this._usersMapCache) {
                this._usersMapCache[targetKey] = updatedUserData;
            }

            return true;
        } catch (error) {
            console.error('[Database] Error actualizando usuario:', error.message);
            return false;
        }
    }


    // ==========================================
    // GROUPS
    // ==========================================

    getGroup(groupId) {
        try {
            const row = this._stmts.getGroup.get(groupId);
            if (row) return JSON.parse(row.data);
            const defaultGroup = { name: '', welcome: false, antiLink: false, antiSticker: false, antiToxic: false, level: 0, exp: 0 };
            this._stmts.setGroup.run(groupId, JSON.stringify(defaultGroup));
            if (this._groupsMapCache) this._groupsMapCache[groupId] = defaultGroup;
            return defaultGroup;
        } catch (e) { console.error('[Database] Error obteniendo grupo:', e.message); return null; }
    }

    setGroup(groupId, groupData) {
        try {
            this._stmts.setGroup.run(groupId, JSON.stringify(groupData));
            if (this._groupsMapCache) this._groupsMapCache[groupId] = groupData;
            return true;
        }
        catch (e) { console.error('[Database] Error guardando grupo:', e.message); return false; }
    }

    // ==========================================
    // CHATS
    // ==========================================

    getChat(chatId) {
        try {
            const row = this._stmts.getChat.get(chatId);
            if (row) return JSON.parse(row.data);
            const defaultChat = { name: '', messages: 0, commands: 0 };
            this._stmts.setChat.run(chatId, JSON.stringify(defaultChat));
            if (this._chatsMapCache) this._chatsMapCache[chatId] = defaultChat;
            return defaultChat;
        } catch (e) { console.error('[Database] Error obteniendo chat:', e.message); return null; }
    }

    setChat(chatId, chatData) {
        try {
            this._stmts.setChat.run(chatId, JSON.stringify(chatData));
            if (this._chatsMapCache) this._chatsMapCache[chatId] = chatData;
            return true;
        }
        catch (e) { console.error('[Database] Error guardando chat:', e.message); return false; }
    }

    _getUsersMap() {
        if (!this._usersMapCache) {
            const rows = this._stmts.getAllUsers.all();
            const aliases = this._getKvAll('aliases') || {};
            const r = {};
            for (const row of rows) {
                try {
                    const clean = this.cleanNumber(row.id) || row.id;
                    const targetKey = String(aliases[clean] || aliases[row.id] || clean);
                    if (!r[targetKey]) {
                        r[targetKey] = JSON.parse(row.data);
                    } else {
                        r[targetKey] = mergeUserObjects(r[targetKey], JSON.parse(row.data));
                    }
                } catch (_) {}
            }
            for (const [key, entry] of this._userCache.entries()) {
                if (entry && entry.obj) {
                    const clean = this.cleanNumber(key) || key;
                    const targetKey = String(aliases[clean] || aliases[key] || clean);
                    r[targetKey] = entry.obj;
                }
            }
            this._usersMapCache = r;
        }
        return this._usersMapCache;
    }

    _getUsersProxy() {
        if (!this._usersProxyCache) {
            const self = this;
            const map = this._getUsersMap();
            const aliases = self._getKvAll('aliases') || {};
            this._usersProxyCache = new Proxy(map, {
                get(target, prop, receiver) {
                    if (typeof prop !== 'string') return Reflect.get(target, prop, receiver);
                    if (prop in target) return target[prop];
                    const clean = self.cleanNumber(prop) || prop;
                    const resolvedKey = String(aliases[clean] || aliases[prop] || clean);
                    return target[resolvedKey] || target[prop];
                }
            });
        }
        return this._usersProxyCache;
    }

    getUniqueUsers() {
        try {
            const usersMap = this._getUsersMap();
            const uniqueMap = new Map();
            const aliases = this._getKvAll('aliases') || {};

            for (const [id, user] of Object.entries(usersMap)) {
                if (!user) continue;
                const clean = this.cleanNumber(id) || id;
                if (!clean) continue;
                const canonicalId = String(aliases[clean] || aliases[id] || clean);

                if (!uniqueMap.has(canonicalId)) {
                    uniqueMap.set(canonicalId, user);
                } else {
                    const existing = uniqueMap.get(canonicalId);
                    const merged = mergeUserObjects(existing, user);
                    uniqueMap.set(canonicalId, merged);
                }
            }
            return uniqueMap;
        } catch (e) {
            console.error('[Database] Error en getUniqueUsers:', e.message);
            return new Map();
        }
    }

    findUserByMentionOrApodo(messageOrArg, argText) {
        let text = typeof messageOrArg === 'string' ? messageOrArg : argText;
        if (!text && typeof messageOrArg === 'object') {
            const mentions = messageOrArg?.mentions || messageOrArg?.mentionedJid || [];
            if (mentions.length > 0) {
                const num = this.cleanNumber(mentions[0]);
                const user = this.getUser(num);
                return user ? { number: num, data: user } : null;
            }
        }
        if (!text) return null;
        const query = String(text).replace(/^@/, '').trim().toLowerCase();
        if (!query) return null;

        const usersMap = this._getUsersMap();
        let partial = null;
        for (const [key, u] of Object.entries(usersMap)) {
            if (!u || !u.apodo) continue;
            const apodoLower = u.apodo.toLowerCase();
            if (apodoLower === query) return { number: key, data: u };
            if (!partial && apodoLower.includes(query)) partial = { number: key, data: u };
        }
        return partial;
    }

    // Legacy: some code accesses db.data.* directly — expose a fast in-memory getter
    get data() {
        const self = this;
        return {
            get users() {
                return self._getUsersProxy();
            },
            get groups() {
                if (!self._groupsMapCache) {
                    const rows = self._stmts.getAllGroups.all();
                    const r = {};
                    for (const row of rows) {
                        try { r[row.id] = JSON.parse(row.data); } catch (_) {}
                    }
                    self._groupsMapCache = r;
                }
                return self._groupsMapCache;
            },
            get chats() {
                if (!self._chatsMapCache) {
                    const rows = self._stmts.getAllChats.all();
                    const r = {};
                    for (const row of rows) {
                        try { r[row.id] = JSON.parse(row.data); } catch (_) {}
                    }
                    self._chatsMapCache = r;
                }
                return self._chatsMapCache;
            },
            get parejas()            { return self._getKvAll('parejas'); },
            get personajes()         { return self._getKvAll('personajes'); },
            get intercambiosAnime()  { return self._getKvAll('intercambiosAnime'); },
            get futbolistas()        { return self._getKvAll('futbolistas'); },
            get intercambiosFutbol() { return self._getKvAll('intercambiosFutbol'); },
            get figuritas()          { return self._getKvAll('figuritas'); },
            get famosos()            { return self._getKvAll('famosos'); },
            get intercambiosFamosos(){ return self._getKvAll('intercambiosFamosos'); },
            get clanes()             { return self._getKvAll('clanes'); },
            get groupActivity()      { return self._getKvAll('groupActivity'); },
            get aliases()            { return self._getKvAll('aliases'); },
        };
    }

    // ==========================================
    // PAREJAS
    // ==========================================

    getParejas() {
        try { return this._getKvAll('parejas'); }
        catch (e) { console.error('[Database] Error obteniendo parejas:', e.message); return {}; }
    }

    getPareja(numero) {
        try { return this._getKv('parejas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo pareja:', e.message); return null; }
    }

    setPareja(numero, parejaData) {
        try {
            const key = this.cleanNumber(numero);
            if (parejaData === null || parejaData === undefined) {
                // Use _setKv so the in-memory cache is also invalidated
                this._setKv('parejas', key, null);
            } else {
                const value = {
                    numero: parejaData.numero,
                    jid:    parejaData.jid    || null,
                    estado: parejaData.estado || 'pendiente',
                    fecha:  parejaData.fecha  || new Date().toISOString()
                };
                // Use _setKv so the in-memory cache is also updated
                this._setKv('parejas', key, value);
            }
            return true;
        } catch (e) { console.error('[Database] Error actualizando pareja:', e.message); return false; }
    }

    deletePareja(numero) {
        // Use _setKv(null) so the in-memory KV cache is invalidated alongside SQLite
        try { this._setKv('parejas', this.cleanNumber(numero), null); return true; }
        catch (e) { console.error('[Database] Error eliminando pareja:', e.message); return false; }
    }

    // ==========================================
    // PERSONAJES E INTERCAMBIOS ANIME
    // ==========================================

    getPersonajes(numero) {
        try { return this._getKv('personajes', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo personajes:', e.message); return null; }
    }

    setPersonajes(numero, data) {
        try { this._setKv('personajes', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando personajes:', e.message); return false; }
    }

    getAllPersonajes() {
        try { return this._getKvAll('personajes'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de personajes:', e.message); return {}; }
    }

    getIntercambiosAnime() {
        try { return this._getKvAll('intercambiosAnime'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios anime:', e.message); return {}; }
    }

    getIntercambioAnime(key) {
        try { return this._getKv('intercambiosAnime', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio anime:', e.message); return null; }
    }

    setIntercambioAnime(key, data) {
        try { this._setKv('intercambiosAnime', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio anime:', e.message); return false; }
    }

    deleteIntercambioAnime(key) {
        try { this._stmts.kvDel.run('intercambiosAnime', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio anime:', e.message); return false; }
    }

    // ==========================================
    // FUTBOLISTAS E INTERCAMBIOS FÚTBOL
    // ==========================================

    getFutbolistas(numero) {
        try { return this._getKv('futbolistas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo futbolistas:', e.message); return null; }
    }

    setFutbolistas(numero, data) {
        try { this._setKv('futbolistas', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando futbolistas:', e.message); return false; }
    }

    getAllFutbolistas() {
        try { return this._getKvAll('futbolistas'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de futbolistas:', e.message); return {}; }
    }

    getIntercambiosFutbol() {
        try { return this._getKvAll('intercambiosFutbol'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios futbol:', e.message); return {}; }
    }

    getIntercambioFutbol(key) {
        try { return this._getKv('intercambiosFutbol', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio futbol:', e.message); return null; }
    }

    setIntercambioFutbol(key, data) {
        try { this._setKv('intercambiosFutbol', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio futbol:', e.message); return false; }
    }

    deleteIntercambioFutbol(key) {
        try { this._stmts.kvDel.run('intercambiosFutbol', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio futbol:', e.message); return false; }
    }

    // ==========================================
    // FIGURITAS
    // ==========================================

    getFiguritas(numero) {
        try { return this._getKv('figuritas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo figuritas:', e.message); return null; }
    }

    setFiguritas(numero, data) {
        try { this._setKv('figuritas', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando figuritas:', e.message); return false; }
    }

    getAllFiguritas() {
        try { return this._getKvAll('figuritas'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de figuritas:', e.message); return {}; }
    }

    // ==========================================
    // FAMOSOS E INTERCAMBIOS FAMOSOS
    // ==========================================

    getFamosos(numero) {
        try { return this._getKv('famosos', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo famosos:', e.message); return null; }
    }

    setFamosos(numero, data) {
        try { this._setKv('famosos', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando famosos:', e.message); return false; }
    }

    getAllFamosos() {
        try { return this._getKvAll('famosos'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de famosos:', e.message); return {}; }
    }

    getIntercambiosFamosos() {
        try { return this._getKvAll('intercambiosFamosos'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios famosos:', e.message); return {}; }
    }

    getIntercambioFamoso(key) {
        try { return this._getKv('intercambiosFamosos', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio famoso:', e.message); return null; }
    }

    setIntercambioFamoso(key, data) {
        try { this._setKv('intercambiosFamosos', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio famoso:', e.message); return false; }
    }

    deleteIntercambioFamoso(key) {
        try { this._stmts.kvDel.run('intercambiosFamosos', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio famoso:', e.message); return false; }
    }

    // ==========================================
    // CLANES
    // ==========================================

    getClanes() {
        try { return this._getKvAll('clanes'); }
        catch (e) { console.error('[Database] Error obteniendo clanes:', e.message); return {}; }
    }

    getClan(nombreClan) {
        try {
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                if (row.key.toLowerCase() === nombreClan.toLowerCase()) {
                    return JSON.parse(row.value);
                }
            }
            return null;
        } catch (e) { console.error('[Database] Error obteniendo clan:', e.message); return null; }
    }

    getClanByKey(key) {
        try { return this._getKv('clanes', key); }
        catch (e) { console.error('[Database] Error obteniendo clan por clave:', e.message); return null; }
    }

    setClan(nombreClan, clanData) {
        try { this._setKv('clanes', nombreClan, clanData); return true; }
        catch (e) { console.error('[Database] Error actualizando clan:', e.message); return false; }
    }

    deleteClan(nombreClan) {
        try {
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                if (row.key.toLowerCase() === nombreClan.toLowerCase()) {
                    this._stmts.kvDel.run('clanes', row.key);
                    break;
                }
            }
            return true;
        } catch (e) { console.error('[Database] Error eliminando clan:', e.message); return false; }
    }

    getClanDeUsuario(numero) {
        try {
            const cleanNumber = this.cleanNumber(numero);
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                try {
                    const clan = JSON.parse(row.value);
                    if (clan && clan.miembros && clan.miembros.includes(cleanNumber)) {
                        return { nombre: row.key, clan };
                    }
                } catch (_) {}
            }
            return null;
        } catch (e) { console.error('[Database] Error buscando clan de usuario:', e.message); return null; }
    }

    // ==========================================
    // BACKUP & STATS
    // ==========================================

    backup() {
        try {
            const backupPath = path.join(__dirname, `database_backup_${Date.now()}.db`);
            fs.copyFileSync(this.dbPath, backupPath);
            console.log('[Database] ✓ Backup creado:', backupPath);
            return backupPath;
        } catch (error) {
            console.error('[Database] Error creando backup:', error.message);
            return null;
        }
    }

    getStats() {
        try {
            return {
                totalUsers:   this._stmts.countUsers.get().c,
                totalGroups:  this._stmts.countGroups.get().c,
                totalChats:   this._stmts.countChats.get().c,
                databaseSize: fs.existsSync(this.dbPath) ? fs.statSync(this.dbPath).size : 0
            };
        } catch (e) {
            return { totalUsers: 0, totalGroups: 0, totalChats: 0, databaseSize: 0 };
        }
    }

    destroy() {
        if (this.periodicSaveInterval) {
            clearInterval(this.periodicSaveInterval);
            console.log('[Database] 🗑️ Intervalo de checkpoint limpiado');
        }
        if (this.saveTimeout) clearTimeout(this.saveTimeout);
        // Flush any pending user cache before closing
        try { this.save(); } catch (_) {}
        try {
            this.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
            this.db.close();
            console.log('[Database] ✓ Conexión SQLite cerrada correctamente');
        } catch (e) {
            console.error('[Database] Error cerrando SQLite:', e.message);
        }
    }
}

const db = new Database();
global.db = db;

module.exports = db;