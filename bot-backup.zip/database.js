const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

// ==========================================
// DEFAULT DATA SCHEMAS (unchanged from before)
// ==========================================

const defaultUserData = {
    name: '',
    warns: 0,
    ComandosEjecutados: 0,
    accesscode: null,
    isBanned: false,
    bank: 0,
    money: 0,
    escudosAntiRobos: 0,
    level: 0,
    exp: 0,
    lastWork: 0,
    workedHours: 0,
    totalWorkedHours: 0,
    totalWorkedTimes: 0,
    lastDaily: 0,
    lastClanAttack: 0,
    registered: false,
    premium: false,
    banned: false,
    reseña: null,
    apodo: '',
    rank: 0,
    respeto: 0,
    cookies: 0,
    auto: 0,
    manual: 0,
    lastCookie: 0,
    lastAuto: Date.now(),
    pet: {
        name: 'Mi Mascota',
        type: 'perro',
        level: 1,
        food: 0,
        requiredFood: 100
    },
    lastMining: 0,
    lastPremio: 0,
    minerales: {
        CARBON: 0,
        HIERRO: 0,
        PLATA: 0,
        ORO: 0,
        DIAMANTE: 0,
        ESMERALDA: 0,
        RUBI: 0
    },
    prestamo: {
        activo: false,
        monto: 0,
        deuda: 0,
        intereses: 0,
        fechaPrestamo: 0
    },
    betStats: {
        totalBets: 0,
        totalWins: 0,
        totalLosses: 0,
        totalBetAmount: 0,
        totalWonAmount: 0,
        totalLostAmount: 0,
        biggestBet: 0,
        biggestWin: 0,
        biggestLoss: 0,
        currentStreak: 0,
        bestWinStreak: 0,
        worstLoseStreak: 0,
        lastBetTime: 0
    },
    achievements: {
        commands: { total: 0, milestones: [] },
        work: { total: 0, milestones: [] },
        betting: { total: 0, milestones: [] },
        daily: { total: 0, milestones: [] }
    }
};

function createDefaultUserData() {
    return {
        ...defaultUserData,
        pet: { ...defaultUserData.pet },
        minerales: { ...defaultUserData.minerales },
        prestamo: { ...defaultUserData.prestamo },
        betStats: { ...defaultUserData.betStats },
        achievements: {
            commands: { total: 0, milestones: [] },
            work: { total: 0, milestones: [] },
            betting: { total: 0, milestones: [] },
            daily: { total: 0, milestones: [] }
        }
    };
}

// ==========================================
// SQLITE DATABASE CLASS  (node:sqlite — built-in, no compilation needed)
// ==========================================

class Database {
    constructor() {
        this.dbPath = path.join(__dirname, 'database.db');
        this.jsonPath = path.join(__dirname, 'database.json');
        this.isInitialized = false;

        // Legacy compat flags — plugins call save()/saveNow() and we keep them as no-ops
        this.pendingChanges = false;
        this.isSaving = false;
        this.saveTimeout = null;

        this._openDb();
        this._initSchema();
        this._migrateFromJsonIfNeeded();

        this.isInitialized = true;
        console.log('[Database] ✓ SQLite lista (WAL mode) — node:sqlite built-in');

        // Periodic WAL checkpoint every 5 minutes to keep WAL file small
        this.periodicSaveInterval = setInterval(() => {
            try {
                this.db.exec('PRAGMA wal_checkpoint(PASSIVE)');
            } catch (e) {
                console.error('[Database] Error en checkpoint WAL:', e.message);
            }
        }, 5 * 60 * 1000);
    }

    // ==========================================
    // INTERNAL: OPEN + CONFIGURE SQLite
    // ==========================================

    _openDb() {
        this.db = new DatabaseSync(this.dbPath);
        this.db.exec('PRAGMA journal_mode=WAL');
        this.db.exec('PRAGMA synchronous=NORMAL');
        this.db.exec('PRAGMA foreign_keys=ON');
        this.db.exec('PRAGMA cache_size=-32000'); // 32 MB RAM cache
        this.db.exec('PRAGMA temp_store=MEMORY');
    }

    _initSchema() {
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS groups (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS chats (
                id   TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );

            -- Generic key-value store for:
            -- parejas, personajes, futbolistas, intercambiosAnime,
            -- intercambiosFutbol, figuritas, famosos, intercambiosFamosos,
            -- clanes, aliases, groupActivity
            CREATE TABLE IF NOT EXISTS kv (
                collection TEXT NOT NULL,
                key        TEXT NOT NULL,
                value      TEXT NOT NULL,
                PRIMARY KEY (collection, key)
            );
        `);

        // Prepared statements — compiled once, reused for performance
        this._stmts = {
            getUser:     this.db.prepare('SELECT data FROM users WHERE id = ?'),
            setUser:     this.db.prepare('INSERT OR REPLACE INTO users (id, data) VALUES (?, ?)'),
            getAllUsers:  this.db.prepare('SELECT id, data FROM users'),
            countUsers:  this.db.prepare('SELECT COUNT(*) AS c FROM users'),

            getGroup:    this.db.prepare('SELECT data FROM groups WHERE id = ?'),
            setGroup:    this.db.prepare('INSERT OR REPLACE INTO groups (id, data) VALUES (?, ?)'),
            getAllGroups: this.db.prepare('SELECT id, data FROM groups'),
            countGroups: this.db.prepare('SELECT COUNT(*) AS c FROM groups'),

            getChat:     this.db.prepare('SELECT data FROM chats WHERE id = ?'),
            setChat:     this.db.prepare('INSERT OR REPLACE INTO chats (id, data) VALUES (?, ?)'),
            getAllChats:  this.db.prepare('SELECT id, data FROM chats'),
            countChats:  this.db.prepare('SELECT COUNT(*) AS c FROM chats'),

            kvGet:       this.db.prepare('SELECT value FROM kv WHERE collection = ? AND key = ?'),
            kvSet:       this.db.prepare('INSERT OR REPLACE INTO kv (collection, key, value) VALUES (?, ?, ?)'),
            kvDel:       this.db.prepare('DELETE FROM kv WHERE collection = ? AND key = ?'),
            kvAll:       this.db.prepare('SELECT key, value FROM kv WHERE collection = ?'),
        };
    }

    // ==========================================
    // MIGRATION: database.json → SQLite
    // ==========================================

    _migrateFromJsonIfNeeded() {
        if (!fs.existsSync(this.jsonPath)) return;

        // If SQLite already has users, skip migration
        const existing = this._stmts.countUsers.get();
        if (existing && existing.c > 0) {
            console.log('[Database] ✓ SQLite ya tiene datos — migración omitida');
            const migratedPath = this.jsonPath + '.migrated';
            if (!fs.existsSync(migratedPath)) {
                try { fs.renameSync(this.jsonPath, migratedPath); } catch (_) {}
            }
            return;
        }

        console.log('[Database] 🔄 Migrando database.json → SQLite...');
        const startTime = Date.now();

        try {
            const raw = fs.readFileSync(this.jsonPath, 'utf8');
            const jsonData = JSON.parse(raw);

            // Use a transaction for atomic, fast batch insert
            const insertUsers  = this.db.prepare('INSERT OR REPLACE INTO users (id, data) VALUES (?, ?)');
            const insertGroups = this.db.prepare('INSERT OR REPLACE INTO groups (id, data) VALUES (?, ?)');
            const insertChats  = this.db.prepare('INSERT OR REPLACE INTO chats (id, data) VALUES (?, ?)');
            const insertKv     = this.db.prepare('INSERT OR REPLACE INTO kv (collection, key, value) VALUES (?, ?, ?)');

            // node:sqlite wraps a block in a transaction using exec with BEGIN/COMMIT
            this.db.exec('BEGIN');
            try {
                // Users
                for (const [id, data] of Object.entries(jsonData.users || {})) {
                    if (data && typeof data === 'object') {
                        insertUsers.run(id, JSON.stringify(data));
                    }
                }

                // Aliases
                for (const [aliasKey, targetKey] of Object.entries(jsonData.aliases || {})) {
                    insertKv.run('aliases', aliasKey, targetKey);
                }

                // Groups
                for (const [id, data] of Object.entries(jsonData.groups || {})) {
                    if (data && typeof data === 'object') {
                        insertGroups.run(id, JSON.stringify(data));
                    }
                }

                // Chats
                for (const [id, data] of Object.entries(jsonData.chats || {})) {
                    if (data && typeof data === 'object') {
                        insertChats.run(id, JSON.stringify(data));
                    }
                }

                // Key-value collections
                const kvCollections = [
                    'parejas', 'personajes', 'intercambiosAnime', 'futbolistas',
                    'intercambiosFutbol', 'figuritas', 'famosos', 'intercambiosFamosos',
                    'clanes', 'groupActivity'
                ];
                for (const collection of kvCollections) {
                    const data = jsonData[collection];
                    if (!data || typeof data !== 'object') continue;
                    for (const [key, value] of Object.entries(data)) {
                        if (value !== undefined && value !== null) {
                            insertKv.run(collection, key, JSON.stringify(value));
                        }
                    }
                }

                this.db.exec('COMMIT');
            } catch (err) {
                this.db.exec('ROLLBACK');
                throw err;
            }

            const elapsed = Date.now() - startTime;
            const userCount = this._stmts.countUsers.get().c;
            console.log(`[Database] ✓ Migración completada en ${elapsed}ms — ${userCount} usuarios migrados`);

            // Rename JSON as backup (never delete it)
            const backupPath = this.jsonPath + '.migrated';
            fs.renameSync(this.jsonPath, backupPath);
            console.log(`[Database] 📦 Backup del JSON guardado en: database.json.migrated`);

        } catch (error) {
            console.error('[Database] ❌ Error en migración:', error.message);
            // Don't crash — bot keeps running, json untouched
        }
    }

    // ==========================================
    // INTERNAL HELPERS
    // ==========================================

    cleanNumber(sender) {
        if (!sender) return '';
        return String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    }

    _getKvAll(collection) {
        const rows = this._stmts.kvAll.all(collection);
        const result = {};
        for (const row of rows) {
            try { result[row.key] = JSON.parse(row.value); } catch (_) { result[row.key] = row.value; }
        }
        return result;
    }

    _getKv(collection, key) {
        const row = this._stmts.kvGet.get(collection, key);
        if (!row) return null;
        try { return JSON.parse(row.value); } catch (_) { return row.value; }
    }

    _setKv(collection, key, value) {
        if (value === null || value === undefined) {
            this._stmts.kvDel.run(collection, key);
        } else {
            this._stmts.kvSet.run(collection, key, JSON.stringify(value));
        }
    }

    // ==========================================
    // COMPATIBILITY: save / saveNow / load
    // Plugins call these — kept as no-ops since SQLite writes are immediate
    // ==========================================

    load() {
        return true; // No-op: SQLite is always loaded
    }

    save() {
        // No-op: SQLite commits every statement immediately.
        // We keep topCoins cache invalidation to preserve existing behavior.
        this.pendingChanges = false;
        try {
            const topCoins = require('./topCoinsCache');
            topCoins.invalidateCache();
        } catch (_) {}
    }

    async saveNow() {
        this.pendingChanges = false;
        this.isSaving = false;
    }

    checkInitialization() {
        return this.isInitialized;
    }

    // ==========================================
    // ALIASES
    // ==========================================

    linkUserAlias(id1, id2) {
        try {
            const c1 = this.cleanNumber(id1);
            const c2 = this.cleanNumber(id2);
            if (!c1 || !c2 || c1 === c2) return;

            const alias1 = this._getKv('aliases', c1);
            const alias2 = this._getKv('aliases', c2);
            const target1 = alias1 || c1;
            const target2 = alias2 || c2;

            const u1Raw = this._stmts.getUser.get(target1);
            const u2Raw = this._stmts.getUser.get(target2);
            const u1 = u1Raw ? JSON.parse(u1Raw.data) : null;
            const u2 = u2Raw ? JSON.parse(u2Raw.data) : null;

            let primaryTarget = target2;
            let primaryUser = u2 || createDefaultUserData();

            if (u1 && u2 && target1 !== target2) {
                primaryUser.ComandosEjecutados = Math.max(u1.ComandosEjecutados || 0, u2.ComandosEjecutados || 0);
                primaryUser.money  = Math.max(u1.money  || 0, u2.money  || 0);
                primaryUser.bank   = Math.max(u1.bank   || 0, u2.bank   || 0);
                primaryUser.exp    = Math.max(u1.exp    || 0, u2.exp    || 0);
                primaryUser.level  = Math.max(u1.level  || 0, u2.level  || 0);
                if (!primaryUser.apodo || primaryUser.apodo === 'sin apodo') {
                    primaryUser.apodo = u1.apodo || primaryUser.apodo || '';
                }
                if (!primaryUser.name) primaryUser.name = u1.name || '';
            } else if (u1 && !u2) {
                primaryTarget = target1;
                primaryUser = u1;
            } else if (!u1 && !u2) {
                primaryUser = createDefaultUserData();
            }

            const jsonStr = JSON.stringify(primaryUser);
            this._stmts.setUser.run(c1, jsonStr);
            this._stmts.setUser.run(c2, jsonStr);
            this._stmts.setUser.run(target1, jsonStr);
            this._stmts.setUser.run(target2, jsonStr);

            this._stmts.kvSet.run('aliases', c1, primaryTarget);
            this._stmts.kvSet.run('aliases', c2, primaryTarget);
            if (target1 !== primaryTarget) {
                this._stmts.kvSet.run('aliases', target1, primaryTarget);
            }
        } catch (e) {
            console.error('[Database] Error en linkUserAlias:', e.message);
        }
    }

    // ==========================================
    // USERS
    // ==========================================

    getUser(sender) {
        try {
            const cleanNumber = this.cleanNumber(sender);

            // Resolve alias chain
            const aliasRow = this._stmts.kvGet.get('aliases', cleanNumber);
            const targetKey = aliasRow ? aliasRow.value : cleanNumber;

            let userRow = this._stmts.getUser.get(targetKey);
            if (!userRow && targetKey !== cleanNumber) {
                userRow = this._stmts.getUser.get(cleanNumber);
            }

            let user = userRow ? JSON.parse(userRow.data) : null;
            if (!user) {
                user = createDefaultUserData();
                this._stmts.setUser.run(targetKey, JSON.stringify(user));
            }

            // Merge any missing default fields (schema evolution)
            let needsUpdate = false;
            for (const [key, value] of Object.entries(defaultUserData)) {
                if (user[key] === undefined) {
                    if (key === 'minerales' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'pet' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'prestamo' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'betStats' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'achievements' && typeof value === 'object') {
                        user[key] = {
                            commands: { ...value.commands },
                            work:     { ...value.work },
                            betting:  { ...value.betting },
                            daily:    { ...value.daily }
                        };
                    } else {
                        user[key] = value;
                    }
                    needsUpdate = true;
                }
            }

            if (user.minerales) {
                for (const mineral of Object.keys(defaultUserData.minerales)) {
                    if (user.minerales[mineral] === undefined) {
                        user.minerales[mineral] = 0;
                        needsUpdate = true;
                    }
                }
            }

            if (user.prestamo) {
                for (const prop of Object.keys(defaultUserData.prestamo)) {
                    if (user.prestamo[prop] === undefined) {
                        user.prestamo[prop] = defaultUserData.prestamo[prop];
                        needsUpdate = true;
                    }
                }
            }

            if (user.betStats) {
                for (const prop of Object.keys(defaultUserData.betStats)) {
                    if (user.betStats[prop] === undefined) {
                        user.betStats[prop] = defaultUserData.betStats[prop];
                        needsUpdate = true;
                    }
                }
            } else {
                user.betStats = { ...defaultUserData.betStats };
                needsUpdate = true;
            }

            // Premium max rank check
            try {
                const premium = require('./premium');
                if (premium.hasPremiumMaxRank(cleanNumber)) {
                    const rankupPlugin = require('./plugins/rankup');
                    if (rankupPlugin && typeof rankupPlugin.getMaxRango === 'function') {
                        const maxRango = rankupPlugin.getMaxRango();
                        if (user.rango !== maxRango) {
                            user.rango = maxRango;
                            needsUpdate = true;
                        }
                    }
                }
            } catch (_) {}

            if (needsUpdate) {
                const jsonStr = JSON.stringify(user);
                this._stmts.setUser.run(targetKey, jsonStr);
                if (cleanNumber !== targetKey) {
                    this._stmts.setUser.run(cleanNumber, jsonStr);
                }
            }

            return user;
        } catch (error) {
            console.error('[Database] Error obteniendo usuario:', error.message);
            return null;
        }
    }

    setUser(sender, userData) {
        try {
            const cleanNumber = this.cleanNumber(sender);

            // Resolve alias
            const aliasRow = this._stmts.kvGet.get('aliases', cleanNumber);
            const targetKey = aliasRow ? aliasRow.value : cleanNumber;

            const currentRow = this._stmts.getUser.get(targetKey) || this._stmts.getUser.get(cleanNumber);
            const currentUserData = currentRow ? JSON.parse(currentRow.data) : createDefaultUserData();

            const updatedUserData = {
                name:               userData.name               !== undefined ? userData.name               : currentUserData.name               || '',
                ComandosEjecutados: userData.ComandosEjecutados !== undefined ? userData.ComandosEjecutados : currentUserData.ComandosEjecutados  || 0,
                genero:             userData.genero             !== undefined ? userData.genero             : currentUserData.genero              || null,
                rango:              userData.rango              !== undefined ? userData.rango              : currentUserData.rango               || '🌱 Novato',
                respeto:            userData.respeto            !== undefined ? userData.respeto            : currentUserData.respeto             || 0,
                level:              userData.level              !== undefined ? userData.level              : currentUserData.level               || 0,
                exp:                userData.exp                !== undefined ? userData.exp                : currentUserData.exp                 || 0,
                escudosAntiRobos:   userData.escudosAntiRobos   !== undefined ? userData.escudosAntiRobos   : currentUserData.escudosAntiRobos    || 0,
                money:              userData.money              !== undefined ? userData.money              : currentUserData.money               || 0,
                bank:               userData.bank               !== undefined ? userData.bank               : currentUserData.bank                || 0,
                warns:              userData.warns              !== undefined ? userData.warns              : currentUserData.warns               || 0,
                accesscode:         userData.accesscode         !== undefined ? userData.accesscode         : currentUserData.accesscode          || null,
                isBanned:           userData.isBanned           !== undefined ? userData.isBanned           : currentUserData.isBanned            || false,
                lastWork:           userData.lastWork           !== undefined ? userData.lastWork           : currentUserData.lastWork            || 0,
                workedHours:        userData.workedHours        !== undefined ? userData.workedHours        : currentUserData.workedHours         || 0,
                totalWorkedHours:   userData.totalWorkedHours   !== undefined ? userData.totalWorkedHours   : currentUserData.totalWorkedHours    || 0,
                totalWorkedTimes:   userData.totalWorkedTimes   !== undefined ? userData.totalWorkedTimes   : currentUserData.totalWorkedTimes    || 0,
                rank:               userData.rank               !== undefined ? Number(userData.rank)       || 0 : Number(currentUserData.rank)   || 0,
                lastDaily:          userData.lastDaily          !== undefined ? userData.lastDaily          : currentUserData.lastDaily           || 0,
                lastClanAttack:     userData.lastClanAttack     !== undefined ? Number(userData.lastClanAttack)  || 0 : Number(currentUserData.lastClanAttack) || 0,
                registered:         userData.registered         !== undefined ? userData.registered         : currentUserData.registered          || false,
                premium:            userData.premium            !== undefined ? userData.premium            : currentUserData.premium             || false,
                banned:             userData.banned             !== undefined ? userData.banned             : currentUserData.banned              || false,
                reseña:             userData.reseña             !== undefined ? userData.reseña             : currentUserData.reseña              || null,
                apodo:              userData.apodo              !== undefined ? userData.apodo              : currentUserData.apodo               || '',
                cookies:            userData.cookies            !== undefined ? Number(userData.cookies)    || 0 : Number(currentUserData.cookies) || 0,
                auto:               userData.auto               !== undefined ? Number(userData.auto)       || 0 : Number(currentUserData.auto)   || 0,
                manual:             userData.manual             !== undefined ? Number(userData.manual)     || 0 : Number(currentUserData.manual) || 0,
                lastAuto:           userData.lastAuto           !== undefined ? Number(userData.lastAuto)   || Date.now() : Number(currentUserData.lastAuto) || Date.now(),
                lastCookie:         userData.lastCookie         !== undefined ? Number(userData.lastCookie) || 0 : Number(currentUserData.lastCookie) || 0,
                pet: userData.pet !== undefined ? {
                    name:         userData.pet.name         !== undefined ? userData.pet.name         : (currentUserData.pet ? currentUserData.pet.name         : 'Mi Mascota'),
                    type:         userData.pet.type         !== undefined ? userData.pet.type         : (currentUserData.pet ? currentUserData.pet.type         : 'perro'),
                    level:        userData.pet.level        !== undefined ? Number(userData.pet.level)        || 1   : (currentUserData.pet ? Number(currentUserData.pet.level)        || 1   : 1),
                    food:         userData.pet.food         !== undefined ? Number(userData.pet.food)         || 0   : (currentUserData.pet ? Number(currentUserData.pet.food)         || 0   : 0),
                    requiredFood: userData.pet.requiredFood !== undefined ? Number(userData.pet.requiredFood) || 100 : (currentUserData.pet ? Number(currentUserData.pet.requiredFood) || 100 : 100)
                } : (currentUserData.pet || { name: 'Mi Mascota', type: 'perro', level: 1, food: 0, requiredFood: 100 }),
                lastMining:  userData.lastMining  !== undefined ? userData.lastMining                    : currentUserData.lastMining  || 0,
                lastPremio:  userData.lastPremio  !== undefined ? Number(userData.lastPremio)  || 0      : Number(currentUserData.lastPremio)  || 0,
                minerales: userData.minerales !== undefined ? {
                    ...defaultUserData.minerales,
                    ...userData.minerales
                } : (currentUserData.minerales || { ...defaultUserData.minerales }),
                prestamo: userData.prestamo !== undefined ? {
                    activo:       userData.prestamo.activo       !== undefined ? userData.prestamo.activo                    : (currentUserData.prestamo ? currentUserData.prestamo.activo       : false),
                    monto:        userData.prestamo.monto        !== undefined ? Number(userData.prestamo.monto)        || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.monto)        || 0 : 0),
                    deuda:        userData.prestamo.deuda        !== undefined ? Number(userData.prestamo.deuda)        || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.deuda)        || 0 : 0),
                    intereses:    userData.prestamo.intereses    !== undefined ? Number(userData.prestamo.intereses)    || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.intereses)    || 0 : 0),
                    fechaPrestamo:userData.prestamo.fechaPrestamo!== undefined ? Number(userData.prestamo.fechaPrestamo)|| 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.fechaPrestamo)|| 0 : 0)
                } : (currentUserData.prestamo || { activo: false, monto: 0, deuda: 0, intereses: 0, fechaPrestamo: 0 }),
                betStats: userData.betStats !== undefined ? {
                    totalBets:       userData.betStats.totalBets       !== undefined ? Number(userData.betStats.totalBets)       || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalBets)       || 0 : 0),
                    totalWins:       userData.betStats.totalWins       !== undefined ? Number(userData.betStats.totalWins)       || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalWins)       || 0 : 0),
                    totalLosses:     userData.betStats.totalLosses     !== undefined ? Number(userData.betStats.totalLosses)     || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalLosses)     || 0 : 0),
                    totalBetAmount:  userData.betStats.totalBetAmount  !== undefined ? Number(userData.betStats.totalBetAmount)  || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalBetAmount)  || 0 : 0),
                    totalWonAmount:  userData.betStats.totalWonAmount  !== undefined ? Number(userData.betStats.totalWonAmount)  || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalWonAmount)  || 0 : 0),
                    totalLostAmount: userData.betStats.totalLostAmount !== undefined ? Number(userData.betStats.totalLostAmount) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.totalLostAmount) || 0 : 0),
                    biggestBet:      userData.betStats.biggestBet      !== undefined ? Number(userData.betStats.biggestBet)      || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestBet)      || 0 : 0),
                    biggestWin:      userData.betStats.biggestWin      !== undefined ? Number(userData.betStats.biggestWin)      || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestWin)      || 0 : 0),
                    biggestLoss:     userData.betStats.biggestLoss     !== undefined ? Number(userData.betStats.biggestLoss)     || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.biggestLoss)     || 0 : 0),
                    currentStreak:   userData.betStats.currentStreak   !== undefined ? Number(userData.betStats.currentStreak)   || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.currentStreak)   || 0 : 0),
                    bestWinStreak:   userData.betStats.bestWinStreak   !== undefined ? Number(userData.betStats.bestWinStreak)   || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.bestWinStreak)   || 0 : 0),
                    worstLoseStreak: userData.betStats.worstLoseStreak !== undefined ? Number(userData.betStats.worstLoseStreak) || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.worstLoseStreak) || 0 : 0),
                    lastBetTime:     userData.betStats.lastBetTime     !== undefined ? Number(userData.betStats.lastBetTime)     || 0 : (currentUserData.betStats ? Number(currentUserData.betStats.lastBetTime)     || 0 : 0)
                } : (currentUserData.betStats || { ...defaultUserData.betStats }),
                achievements: userData.achievements !== undefined ? {
                    commands: {
                        total:      userData.achievements.commands?.total      !== undefined ? Number(userData.achievements.commands.total)      || 0 : (currentUserData.achievements?.commands?.total      || 0),
                        milestones: Array.isArray(userData.achievements.commands?.milestones) ? userData.achievements.commands.milestones        : (currentUserData.achievements?.commands?.milestones      || [])
                    },
                    work: {
                        total:      userData.achievements.work?.total          !== undefined ? Number(userData.achievements.work.total)          || 0 : (currentUserData.achievements?.work?.total          || 0),
                        milestones: Array.isArray(userData.achievements.work?.milestones)    ? userData.achievements.work.milestones             : (currentUserData.achievements?.work?.milestones          || [])
                    },
                    betting: {
                        total:      userData.achievements.betting?.total       !== undefined ? Number(userData.achievements.betting.total)       || 0 : (currentUserData.achievements?.betting?.total       || 0),
                        milestones: Array.isArray(userData.achievements.betting?.milestones) ? userData.achievements.betting.milestones          : (currentUserData.achievements?.betting?.milestones       || [])
                    },
                    daily: {
                        total:      userData.achievements.daily?.total         !== undefined ? Number(userData.achievements.daily.total)         || 0 : (currentUserData.achievements?.daily?.total         || 0),
                        milestones: Array.isArray(userData.achievements.daily?.milestones)   ? userData.achievements.daily.milestones            : (currentUserData.achievements?.daily?.milestones         || [])
                    }
                } : (currentUserData.achievements || {
                    commands: { total: 0, milestones: [] },
                    work:     { total: 0, milestones: [] },
                    betting:  { total: 0, milestones: [] },
                    daily:    { total: 0, milestones: [] }
                }),
            };

            // Preserve extra fields not in fixed schema (pene_upgrades, vagina_upgrades, etc.)
            for (const key of Object.keys(currentUserData)) {
                if (!(key in updatedUserData)) {
                    updatedUserData[key] = currentUserData[key];
                }
            }

            const jsonStr = JSON.stringify(updatedUserData);
            this._stmts.setUser.run(targetKey, jsonStr);
            if (cleanNumber !== targetKey) {
                this._stmts.setUser.run(cleanNumber, jsonStr);
            }

            return true;
        } catch (error) {
            console.error('[Database] Error actualizando usuario:', error.message);
            return false;
        }
    }

    // ==========================================
    // GROUPS
    // ==========================================

    getGroup(groupId) {
        try {
            const row = this._stmts.getGroup.get(groupId);
            if (row) return JSON.parse(row.data);
            const defaultGroup = { name: '', welcome: false, antiLink: false, antiSticker: false, antiToxic: false, level: 0, exp: 0 };
            this._stmts.setGroup.run(groupId, JSON.stringify(defaultGroup));
            return defaultGroup;
        } catch (e) { console.error('[Database] Error obteniendo grupo:', e.message); return null; }
    }

    setGroup(groupId, groupData) {
        try { this._stmts.setGroup.run(groupId, JSON.stringify(groupData)); return true; }
        catch (e) { console.error('[Database] Error guardando grupo:', e.message); return false; }
    }

    // ==========================================
    // CHATS
    // ==========================================

    getChat(chatId) {
        try {
            const row = this._stmts.getChat.get(chatId);
            if (row) return JSON.parse(row.data);
            const defaultChat = { name: '', messages: 0, commands: 0 };
            this._stmts.setChat.run(chatId, JSON.stringify(defaultChat));
            return defaultChat;
        } catch (e) { console.error('[Database] Error obteniendo chat:', e.message); return null; }
    }

    setChat(chatId, chatData) {
        try { this._stmts.setChat.run(chatId, JSON.stringify(chatData)); return true; }
        catch (e) { console.error('[Database] Error guardando chat:', e.message); return false; }
    }

    // Legacy: some code accesses db.data.* directly — expose a lazy computed getter
    get data() {
        const self = this;
        return {
            get users()            { const rows = self._stmts.getAllUsers.all();  const r = {}; for (const row of rows) { try { r[row.id] = JSON.parse(row.data); } catch (_) {} } return r; },
            get groups()           { const rows = self._stmts.getAllGroups.all(); const r = {}; for (const row of rows) { try { r[row.id] = JSON.parse(row.data); } catch (_) {} } return r; },
            get chats()            { const rows = self._stmts.getAllChats.all();  const r = {}; for (const row of rows) { try { r[row.id] = JSON.parse(row.data); } catch (_) {} } return r; },
            get parejas()            { return self._getKvAll('parejas'); },
            get personajes()         { return self._getKvAll('personajes'); },
            get intercambiosAnime()  { return self._getKvAll('intercambiosAnime'); },
            get futbolistas()        { return self._getKvAll('futbolistas'); },
            get intercambiosFutbol() { return self._getKvAll('intercambiosFutbol'); },
            get figuritas()          { return self._getKvAll('figuritas'); },
            get famosos()            { return self._getKvAll('famosos'); },
            get intercambiosFamosos(){ return self._getKvAll('intercambiosFamosos'); },
            get clanes()             { return self._getKvAll('clanes'); },
            get groupActivity()      { return self._getKvAll('groupActivity'); },
            get aliases()            { return self._getKvAll('aliases'); },
        };
    }

    // ==========================================
    // PAREJAS
    // ==========================================

    getParejas() {
        try { return this._getKvAll('parejas'); }
        catch (e) { console.error('[Database] Error obteniendo parejas:', e.message); return {}; }
    }

    getPareja(numero) {
        try { return this._getKv('parejas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo pareja:', e.message); return null; }
    }

    setPareja(numero, parejaData) {
        try {
            const key = this.cleanNumber(numero);
            if (parejaData === null || parejaData === undefined) {
                this._stmts.kvDel.run('parejas', key);
            } else {
                this._stmts.kvSet.run('parejas', key, JSON.stringify({
                    numero: parejaData.numero,
                    jid:    parejaData.jid    || null,
                    estado: parejaData.estado || 'pendiente',
                    fecha:  parejaData.fecha  || new Date().toISOString()
                }));
            }
            return true;
        } catch (e) { console.error('[Database] Error actualizando pareja:', e.message); return false; }
    }

    deletePareja(numero) {
        try { this._stmts.kvDel.run('parejas', this.cleanNumber(numero)); return true; }
        catch (e) { console.error('[Database] Error eliminando pareja:', e.message); return false; }
    }

    // ==========================================
    // PERSONAJES E INTERCAMBIOS ANIME
    // ==========================================

    getPersonajes(numero) {
        try { return this._getKv('personajes', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo personajes:', e.message); return null; }
    }

    setPersonajes(numero, data) {
        try { this._setKv('personajes', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando personajes:', e.message); return false; }
    }

    getAllPersonajes() {
        try { return this._getKvAll('personajes'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de personajes:', e.message); return {}; }
    }

    getIntercambiosAnime() {
        try { return this._getKvAll('intercambiosAnime'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios anime:', e.message); return {}; }
    }

    getIntercambioAnime(key) {
        try { return this._getKv('intercambiosAnime', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio anime:', e.message); return null; }
    }

    setIntercambioAnime(key, data) {
        try { this._setKv('intercambiosAnime', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio anime:', e.message); return false; }
    }

    deleteIntercambioAnime(key) {
        try { this._stmts.kvDel.run('intercambiosAnime', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio anime:', e.message); return false; }
    }

    // ==========================================
    // FUTBOLISTAS E INTERCAMBIOS FÚTBOL
    // ==========================================

    getFutbolistas(numero) {
        try { return this._getKv('futbolistas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo futbolistas:', e.message); return null; }
    }

    setFutbolistas(numero, data) {
        try { this._setKv('futbolistas', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando futbolistas:', e.message); return false; }
    }

    getAllFutbolistas() {
        try { return this._getKvAll('futbolistas'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de futbolistas:', e.message); return {}; }
    }

    getIntercambiosFutbol() {
        try { return this._getKvAll('intercambiosFutbol'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios futbol:', e.message); return {}; }
    }

    getIntercambioFutbol(key) {
        try { return this._getKv('intercambiosFutbol', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio futbol:', e.message); return null; }
    }

    setIntercambioFutbol(key, data) {
        try { this._setKv('intercambiosFutbol', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio futbol:', e.message); return false; }
    }

    deleteIntercambioFutbol(key) {
        try { this._stmts.kvDel.run('intercambiosFutbol', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio futbol:', e.message); return false; }
    }

    // ==========================================
    // FIGURITAS
    // ==========================================

    getFiguritas(numero) {
        try { return this._getKv('figuritas', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo figuritas:', e.message); return null; }
    }

    setFiguritas(numero, data) {
        try { this._setKv('figuritas', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando figuritas:', e.message); return false; }
    }

    getAllFiguritas() {
        try { return this._getKvAll('figuritas'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de figuritas:', e.message); return {}; }
    }

    // ==========================================
    // FAMOSOS E INTERCAMBIOS FAMOSOS
    // ==========================================

    getFamosos(numero) {
        try { return this._getKv('famosos', this.cleanNumber(numero)); }
        catch (e) { console.error('[Database] Error obteniendo famosos:', e.message); return null; }
    }

    setFamosos(numero, data) {
        try { this._setKv('famosos', this.cleanNumber(numero), data); return true; }
        catch (e) { console.error('[Database] Error actualizando famosos:', e.message); return false; }
    }

    getAllFamosos() {
        try { return this._getKvAll('famosos'); }
        catch (e) { console.error('[Database] Error obteniendo todas las colecciones de famosos:', e.message); return {}; }
    }

    getIntercambiosFamosos() {
        try { return this._getKvAll('intercambiosFamosos'); }
        catch (e) { console.error('[Database] Error obteniendo intercambios famosos:', e.message); return {}; }
    }

    getIntercambioFamoso(key) {
        try { return this._getKv('intercambiosFamosos', key); }
        catch (e) { console.error('[Database] Error obteniendo intercambio famoso:', e.message); return null; }
    }

    setIntercambioFamoso(key, data) {
        try { this._setKv('intercambiosFamosos', key, data); return true; }
        catch (e) { console.error('[Database] Error actualizando intercambio famoso:', e.message); return false; }
    }

    deleteIntercambioFamoso(key) {
        try { this._stmts.kvDel.run('intercambiosFamosos', key); return true; }
        catch (e) { console.error('[Database] Error eliminando intercambio famoso:', e.message); return false; }
    }

    // ==========================================
    // CLANES
    // ==========================================

    getClanes() {
        try { return this._getKvAll('clanes'); }
        catch (e) { console.error('[Database] Error obteniendo clanes:', e.message); return {}; }
    }

    getClan(nombreClan) {
        try {
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                if (row.key.toLowerCase() === nombreClan.toLowerCase()) {
                    return JSON.parse(row.value);
                }
            }
            return null;
        } catch (e) { console.error('[Database] Error obteniendo clan:', e.message); return null; }
    }

    getClanByKey(key) {
        try { return this._getKv('clanes', key); }
        catch (e) { console.error('[Database] Error obteniendo clan por clave:', e.message); return null; }
    }

    setClan(nombreClan, clanData) {
        try { this._setKv('clanes', nombreClan, clanData); return true; }
        catch (e) { console.error('[Database] Error actualizando clan:', e.message); return false; }
    }

    deleteClan(nombreClan) {
        try {
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                if (row.key.toLowerCase() === nombreClan.toLowerCase()) {
                    this._stmts.kvDel.run('clanes', row.key);
                    break;
                }
            }
            return true;
        } catch (e) { console.error('[Database] Error eliminando clan:', e.message); return false; }
    }

    getClanDeUsuario(numero) {
        try {
            const cleanNumber = this.cleanNumber(numero);
            const rows = this._stmts.kvAll.all('clanes');
            for (const row of rows) {
                try {
                    const clan = JSON.parse(row.value);
                    if (clan && clan.miembros && clan.miembros.includes(cleanNumber)) {
                        return { nombre: row.key, clan };
                    }
                } catch (_) {}
            }
            return null;
        } catch (e) { console.error('[Database] Error buscando clan de usuario:', e.message); return null; }
    }

    // ==========================================
    // BACKUP & STATS
    // ==========================================

    backup() {
        try {
            const backupPath = path.join(__dirname, `database_backup_${Date.now()}.db`);
            fs.copyFileSync(this.dbPath, backupPath);
            console.log('[Database] ✓ Backup creado:', backupPath);
            return backupPath;
        } catch (error) {
            console.error('[Database] Error creando backup:', error.message);
            return null;
        }
    }

    getStats() {
        try {
            return {
                totalUsers:   this._stmts.countUsers.get().c,
                totalGroups:  this._stmts.countGroups.get().c,
                totalChats:   this._stmts.countChats.get().c,
                databaseSize: fs.existsSync(this.dbPath) ? fs.statSync(this.dbPath).size : 0
            };
        } catch (e) {
            return { totalUsers: 0, totalGroups: 0, totalChats: 0, databaseSize: 0 };
        }
    }

    destroy() {
        if (this.periodicSaveInterval) {
            clearInterval(this.periodicSaveInterval);
            console.log('[Database] 🗑️ Intervalo de checkpoint limpiado');
        }
        if (this.saveTimeout) clearTimeout(this.saveTimeout);
        try {
            this.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
            this.db.close();
            console.log('[Database] ✓ Conexión SQLite cerrada correctamente');
        } catch (e) {
            console.error('[Database] Error cerrando SQLite:', e.message);
        }
    }
}

const db = new Database();
global.db = db;

module.exports = db;