const fs = require('fs');
const path = require('path');

const defaultData = {
    users: {},
    groups: {},
    chats: {}
};

const defaultUserData = {
    name: '',
    warns: 0,
    accesscode: null,
    isBanned: false,
    bank: 0,
    money: 0,
    escudosAntiRobos: 0,
    level: 0,
    exp: 0,
    lastWork: 0,
    workedHours: 0,
    totalWorkedHours: 0,
    totalWorkedTimes: 0,
    lastDaily: 0,
    registered: false,
    premium: false,
    banned: false,
    reseña: null,
    apodo: '',
    rank: 0,
    respeto: 0,
    cookies: 0,
    auto: 0,
    manual: 0,
    lastCookie: 0,
    lastAuto: Date.now(),
    pet: {
        name: "Mi Mascota",
        type: "perro",
        level: 1,
        food: 0,
        requiredFood: 100
    },
    lastMining: 0,
    minerales: {
        CARBON: 0,
        HIERRO: 0,
        PLATA: 0,
        ORO: 0,
        DIAMANTE: 0,
        ESMERALDA: 0,
        RUBI: 0
    },
    prestamo: {
        activo: false,
        monto: 0,
        deuda: 0,
        intereses: 0,
        fechaPrestamo: 0
    }
};

class Database {
    constructor() {
        this.data = defaultData;
        this.filePath = path.join(__dirname, 'database.json');
        this.isInitialized = false;
        this.saveQueue = null;
        this.saveTimeout = null;
        this.load();
    }

    load() {
        try {
            if (fs.existsSync(this.filePath)) {
                const fileData = fs.readFileSync(this.filePath, 'utf8');
                const localData = JSON.parse(fileData);
                
                this.data = {
                    users: localData.users || {},
                    groups: localData.groups || {},
                    chats: localData.chats || {}
                };
                
                this.isInitialized = true;
            } else {
                this.data = { ...defaultData };
                this.saveNow();
                this.isInitialized = true;
            }
        } catch (error) {
            console.error('Error loading database:', error.message);
            this.data = { ...defaultData };
            this.saveNow();
            this.isInitialized = true;
        }
    }

    // Guardado optimizado con debounce
    save() {
        if (this.saveTimeout) {
            clearTimeout(this.saveTimeout);
        }
        
        this.saveTimeout = setTimeout(() => {
            this.saveNow();
        }, 1000); // Espera 1 segundo antes de guardar
    }

    // Guardado inmediato (solo para casos críticos)
    saveNow() {
        try {
            if (!this.isInitialized) {
                this.isInitialized = true;
            }
            
            const dir = path.dirname(this.filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            
            fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
        } catch (error) {
            console.error('Error saving database:', error.message);
        }
    }

    checkInitialization() {
        if (!this.isInitialized) {
            this.load();
            return false;
        }
        return true;
    }

    cleanNumber(sender) {
        return sender.replace(/[^0-9]/g, '');
    }

    getUser(sender) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(sender);
            
            if (!this.data.users[cleanNumber]) {
                this.data.users[cleanNumber] = { ...defaultUserData };
                this.save();
            }
            
            const user = this.data.users[cleanNumber];
            let needsUpdate = false;
            
            for (const [key, value] of Object.entries(defaultUserData)) {
                if (user[key] === undefined) {
                    if (key === 'minerales' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'pet' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else if (key === 'prestamo' && typeof value === 'object') {
                        user[key] = { ...value };
                    } else {
                        user[key] = value;
                    }
                    needsUpdate = true;
                }
            }
            
            if (user.minerales) {
                for (const mineral of Object.keys(defaultUserData.minerales)) {
                    if (user.minerales[mineral] === undefined) {
                        user.minerales[mineral] = 0;
                        needsUpdate = true;
                    }
                }
            }

            if (user.prestamo) {
                for (const prop of Object.keys(defaultUserData.prestamo)) {
                    if (user.prestamo[prop] === undefined) {
                        user.prestamo[prop] = defaultUserData.prestamo[prop];
                        needsUpdate = true;
                    }
                }
            }
            
            if (needsUpdate) {
                this.data.users[cleanNumber] = user;
                this.save();
            }
            
            return this.data.users[cleanNumber];
        } catch (error) {
            console.error('Error getting user:', error.message);
            return null;
        }
    }

    setUser(sender, userData) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            const cleanNumber = this.cleanNumber(sender);
            const currentUserData = this.data.users[cleanNumber] || { ...defaultUserData };
            
            const updatedUserData = {
                name: userData.name !== undefined ? userData.name : currentUserData.name || '',
                level: userData.level !== undefined ? userData.level : currentUserData.level || 0,
                exp: userData.exp !== undefined ? userData.exp : currentUserData.exp || 0,
                escudosAntiRobos: userData.escudosAntiRobos !== undefined ? userData.escudosAntiRobos : currentUserData.escudosAntiRobos || 0,
                money: userData.money !== undefined ? userData.money : currentUserData.money || 0,
                bank: userData.bank !== undefined ? userData.bank : currentUserData.bank || 0,
                warns: userData.warns !== undefined ? userData.warns : currentUserData.warns || 0,
                accesscode: userData.accesscode !== undefined ? userData.accesscode : currentUserData.accesscode || null,
                isBanned: userData.isBanned !== undefined ? userData.isBanned : currentUserData.isBanned || false,
                lastWork: userData.lastWork !== undefined ? userData.lastWork : currentUserData.lastWork || 0,
                workedHours: userData.workedHours !== undefined ? userData.workedHours : currentUserData.workedHours || 0,
                totalWorkedHours: userData.totalWorkedHours !== undefined ? userData.totalWorkedHours : currentUserData.totalWorkedHours || 0,
                totalWorkedTimes: userData.totalWorkedTimes !== undefined ? userData.totalWorkedTimes : currentUserData.totalWorkedTimes || 0,
                respeto: userData.respeto !== undefined ? userData.respeto : currentUserData.respeto || 0,
                rank: userData.rank !== undefined ? Number(userData.rank) || 0 : Number(currentUserData.rank) || 0,
                lastDaily: userData.lastDaily !== undefined ? userData.lastDaily : currentUserData.lastDaily || 0,
                registered: userData.registered !== undefined ? userData.registered : currentUserData.registered || false,
                premium: userData.premium !== undefined ? userData.premium : currentUserData.premium || false,
                banned: userData.banned !== undefined ? userData.banned : currentUserData.banned || false,
                reseña: userData.reseña !== undefined ? userData.reseña : currentUserData.reseña || null,
                apodo: userData.apodo !== undefined ? userData.apodo : currentUserData.apodo || '',
                cookies: userData.cookies !== undefined ? Number(userData.cookies) || 0 : Number(currentUserData.cookies) || 0,
                auto: userData.auto !== undefined ? Number(userData.auto) || 0 : Number(currentUserData.auto) || 0,
                manual: userData.manual !== undefined ? Number(userData.manual) || 0 : Number(currentUserData.manual) || 0,
                lastAuto: userData.lastAuto !== undefined ? Number(userData.lastAuto) || Date.now() : Number(currentUserData.lastAuto) || Date.now(),
                lastCookie: userData.lastCookie !== undefined ? Number(userData.lastCookie) || 0 : Number(currentUserData.lastCookie) || 0,
                pet: userData.pet !== undefined ? {
                    name: userData.pet.name !== undefined ? userData.pet.name : (currentUserData.pet ? currentUserData.pet.name : "Mi Mascota"),
                    type: userData.pet.type !== undefined ? userData.pet.type : (currentUserData.pet ? currentUserData.pet.type : "perro"),
                    level: userData.pet.level !== undefined ? Number(userData.pet.level) || 1 : (currentUserData.pet ? Number(currentUserData.pet.level) || 1 : 1),
                    food: userData.pet.food !== undefined ? Number(userData.pet.food) || 0 : (currentUserData.pet ? Number(currentUserData.pet.food) || 0 : 0),
                    requiredFood: userData.pet.requiredFood !== undefined ? Number(userData.pet.requiredFood) || 100 : (currentUserData.pet ? Number(currentUserData.pet.requiredFood) || 100 : 100)
                } : (currentUserData.pet || {
                    name: "Mi Mascota",
                    type: "perro",
                    level: 1,
                    food: 0,
                    requiredFood: 100
                }),
                lastMining: userData.lastMining !== undefined ? userData.lastMining : currentUserData.lastMining || 0,
                minerales: userData.minerales !== undefined ? {
                    ...defaultUserData.minerales,
                    ...userData.minerales
                } : (currentUserData.minerales || { ...defaultUserData.minerales }),
                prestamo: userData.prestamo !== undefined ? {
                    activo: userData.prestamo.activo !== undefined ? userData.prestamo.activo : (currentUserData.prestamo ? currentUserData.prestamo.activo : false),
                    monto: userData.prestamo.monto !== undefined ? Number(userData.prestamo.monto) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.monto) || 0 : 0),
                    deuda: userData.prestamo.deuda !== undefined ? Number(userData.prestamo.deuda) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.deuda) || 0 : 0),
                    intereses: userData.prestamo.intereses !== undefined ? Number(userData.prestamo.intereses) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.intereses) || 0 : 0),
                    fechaPrestamo: userData.prestamo.fechaPrestamo !== undefined ? Number(userData.prestamo.fechaPrestamo) || 0 : (currentUserData.prestamo ? Number(currentUserData.prestamo.fechaPrestamo) || 0 : 0)
                } : (currentUserData.prestamo || {
                    activo: false,
                    monto: 0,
                    deuda: 0,
                    intereses: 0,
                    fechaPrestamo: 0
                })
            };
            
            this.data.users[cleanNumber] = updatedUserData;
            this.save();
            return true;
        } catch (error) {
            console.error('Error setting user:', error.message);
            return false;
        }
    }

    getGroup(groupId) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            if (!this.data.groups[groupId]) {
                this.data.groups[groupId] = {
                    name: '',
                    welcome: false,
                    antiLink: false,
                    antiSticker: false,
                    antiToxic: false,
                    level: 0,
                    exp: 0
                };
                this.save();
            }
            return this.data.groups[groupId];
        } catch (error) {
            console.error('Error getting group:', error.message);
            return null;
        }
    }

    getChat(chatId) {
        try {
            if (!this.checkInitialization()) {
                this.load();
            }
            
            if (!this.data.chats[chatId]) {
                this.data.chats[chatId] = {
                    name: '',
                    messages: 0,
                    commands: 0
                };
                this.save();
            }
            return this.data.chats[chatId];
        } catch (error) {
            console.error('Error getting chat:', error.message);
            return null;
        }
    }

    backup() {
        try {
            const backupPath = path.join(__dirname, `database_backup_${Date.now()}.json`);
            fs.writeFileSync(backupPath, JSON.stringify(this.data, null, 2));
            return backupPath;
        } catch (error) {
            console.error('Error creating backup:', error.message);
            return null;
        }
    }

    getStats() {
        return {
            totalUsers: Object.keys(this.data.users).length,
            totalGroups: Object.keys(this.data.groups).length,
            totalChats: Object.keys(this.data.chats).length,
            databaseSize: fs.existsSync(this.filePath) ? fs.statSync(this.filePath).size : 0
        };
    }
}

const db = new Database();
global.db = db;

module.exports = db;