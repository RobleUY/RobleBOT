/**
 * networkGuard.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Circuit breaker global de red + DNS cache.
 *
 * El problema: HidenCloud bloquea/satura periódicamente las conexiones hacia
 * Cloudflare (104.x.x.x, 172.67.x.x) y hacia WhatsApp (31.13.x.x, 57.144.x.x).
 * Cuando eso ocurre, TODOS los plugins intentan sus propios reintentos al mismo
 * tiempo, generando miles de conexiones fallidas que saturan aún más la red.
 *
 * La solución:
 *  1. DNS Cache: guarda resoluciones exitosas para no re-resolver durante cortes.
 *  2. Circuit Breaker: tras N fallos ECONNREFUSED en poco tiempo, declara la red
 *     como "caída" y bloquea nuevos intentos durante RECOVERY_MS milisegundos.
 *  3. API global: cualquier plugin puede llamar isNetworkDown() antes de hacer
 *     requests, y reportNetworkError(err) para contribuir al contador.
 */

'use strict';

const dns = require('dns');
const { promisify } = require('util');

const dnsResolve4 = promisify(dns.resolve4);

// ─── DNS Cache ────────────────────────────────────────────────────────────────
const DNS_CACHE = new Map(); // hostname -> { ips: string[], ts: number }
const DNS_TTL = 5 * 60 * 1000; // 5 minutos

async function cachedResolve(hostname) {
    const cached = DNS_CACHE.get(hostname);
    if (cached && Date.now() - cached.ts < DNS_TTL) {
        return cached.ips;
    }
    try {
        const ips = await dnsResolve4(hostname);
        if (ips && ips.length > 0) {
            DNS_CACHE.set(hostname, { ips, ts: Date.now() });
            return ips;
        }
    } catch (_) {
        // Si falla el DNS pero teníamos cache (aunque vieja), usarla
        if (cached) return cached.ips;
    }
    return null;
}

// Pre-calienta el cache DNS para los dominios más importantes al arrancar
const WARM_DOMAINS = [
    'api.groq.com',
    'api.delirius.online',
    'web.whatsapp.com',
    'mmg.whatsapp.net',
    'media.whatsapp.net',
];

function warmDnsCache() {
    for (const domain of WARM_DOMAINS) {
        cachedResolve(domain).catch(() => {});
    }
}

// ─── Circuit Breaker ──────────────────────────────────────────────────────────
const FAILURE_THRESHOLD = 8;    // N fallos ECONNREFUSED en la ventana de tiempo
const FAILURE_WINDOW_MS = 15000; // 15 segundos
const RECOVERY_MS = 45000;       // 45 segundos de pausa antes de volver a intentar

let failureTimes = [];           // timestamps de errores recientes
let circuitOpen = false;         // true = red caída, bloquear nuevas peticiones
let circuitOpenedAt = 0;         // cuándo se abrió el circuit
let totalOutages = 0;

function isNetworkDown() {
    if (!circuitOpen) return false;

    const elapsed = Date.now() - circuitOpenedAt;
    if (elapsed >= RECOVERY_MS) {
        // Intentar recuperación
        circuitOpen = false;
        failureTimes = [];
        console.log('[NetworkGuard] Período de recuperación terminado. Permitiendo nuevas conexiones...');
        return false;
    }
    return true;
}

function reportNetworkError(err) {
    if (!err) return;
    const msg = err.message || '';
    const code = err.code || '';

    // Solo contar errores de red del host (no rate limits de APIs, etc.)
    const isNetErr = code === 'ECONNREFUSED' || code === 'ETIMEDOUT' ||
                     code === 'ECONNRESET' || code === 'ENETUNREACH' ||
                     msg.includes('ECONNREFUSED') || msg.includes('ETIMEDOUT') ||
                     msg.includes('ENETUNREACH') || msg.includes('ECONNRESET');

    if (!isNetErr) return;

    const now = Date.now();

    // Purgar fallos fuera de la ventana de tiempo
    failureTimes = failureTimes.filter(t => now - t < FAILURE_WINDOW_MS);
    failureTimes.push(now);

    if (!circuitOpen && failureTimes.length >= FAILURE_THRESHOLD) {
        circuitOpen = true;
        circuitOpenedAt = now;
        totalOutages++;
        console.warn(`[NetworkGuard] CIRCUIT BREAKER ABIERTO — Red caída detectada (${failureTimes.length} fallos en ${FAILURE_WINDOW_MS / 1000}s). Pausa de ${RECOVERY_MS / 1000}s. Caída #${totalOutages}.`);
    }
}

function getCircuitStatus() {
    return {
        isDown: isNetworkDown(),
        circuitOpen,
        failuresInWindow: failureTimes.filter(t => Date.now() - t < FAILURE_WINDOW_MS).length,
        totalOutages,
        recoveryIn: circuitOpen ? Math.max(0, RECOVERY_MS - (Date.now() - circuitOpenedAt)) : 0
    };
}

// ─── Axios interceptor ────────────────────────────────────────────────────────
// Llamar setupAxiosInterceptor(axiosInstance) en index.js para que todos los
// requests de axios reporten automáticamente al circuit breaker.
function setupAxiosInterceptor(axiosInstance) {
    // Response error interceptor
    axiosInstance.interceptors.response.use(
        res => res,
        err => {
            reportNetworkError(err);
            return Promise.reject(err);
        }
    );

    // Request interceptor: bloquear si el circuit está abierto
    axiosInstance.interceptors.request.use(
        config => {
            if (isNetworkDown()) {
                const err = new Error('Red caída temporalmente — circuit breaker activo');
                err.code = 'ENETDOWN_CIRCUIT';
                err.isCircuitBreaker = true;
                return Promise.reject(err);
            }
            return config;
        },
        err => Promise.reject(err)
    );
}

// ─── fetch wrapper con circuit breaker ────────────────────────────────────────
// Usar fetchSafe() en plugins que usen fetch nativo en lugar de axios.
async function fetchSafe(url, options = {}) {
    if (isNetworkDown()) {
        const err = new Error('Red caída temporalmente — circuit breaker activo');
        err.code = 'ENETDOWN_CIRCUIT';
        err.isCircuitBreaker = true;
        throw err;
    }

    try {
        const res = await fetch(url, options);
        return res;
    } catch (err) {
        reportNetworkError(err);
        throw err;
    }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = {
    isNetworkDown,
    reportNetworkError,
    getCircuitStatus,
    cachedResolve,
    warmDnsCache,
    setupAxiosInterceptor,
    fetchSafe,
};
