/**
 * chatAudioTranscriber.js
 * Módulo auxiliar para transcribir audios/notas de voz automáticamente
 * y guardarlos en el historial de chat del usuario.
 * Usado por index.js y subbot-serbot.js
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const FormData = require('form-data');

const execFileAsync = promisify(execFile);

const GROQ_API_KEY = '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';
const CHAT_DIR = path.join(__dirname, 'data', 'CHATS-USUARIOS');

function tmpFileName(ext = '') {
    return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : ''));
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    return buffer;
}

async function convertToWav(inputPath) {
    const output = tmpFileName('wav');
    await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-ar', '16000', '-ac', '1', output]);
    return output;
}

async function transcribeWithGroq(filePath) {
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath), { filename: 'audio.wav', contentType: 'audio/wav' });
    form.append('model', 'whisper-large-v3');
    form.append('language', 'es');
    form.append('response_format', 'text');

    const res = await axios.post('https://api.groq.com/openai/v1/audio/transcriptions', form, {
        headers: {
            ...form.getHeaders(),
            'Authorization': `Bearer ${GROQ_API_KEY}`
        },
        timeout: 60000
    });

    return typeof res.data === 'string' ? res.data.trim() : (res.data?.text || '').trim();
}

/**
 * Intenta transcribir un audio de un mensaje de Baileys y guardarlo en el historial.
 * Solo actúa en grupos, solo si el mensaje es de audio/nota de voz, y no es del bot.
 * No lanza errores — falla silenciosamente para no interrumpir el flujo principal.
 *
 * @param {object} baileyMessage - Mensaje crudo de Baileys
 */
async function tryTranscribeAndSave(baileyMessage) {
    try {
        const remoteJid = baileyMessage.key.remoteJid;
        const isFromMe = baileyMessage.key.fromMe;

        // Solo grupos, no del bot
        if (!remoteJid || !remoteJid.endsWith('@g.us') || isFromMe) return;

        const msg = baileyMessage.message;
        if (!msg) return;

        // Detectar si es audio o nota de voz
        const audioMsg = msg.audioMessage || msg.pttMessage;
        if (!audioMsg) return;

        const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
        const cleanSender = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');
        if (!cleanSender || cleanSender.length < 5) return;

        // Descargar audio
        const type = msg.audioMessage ? 'audio' : 'audio'; // ambos son tipo audio en Baileys
        const stream = await downloadContentFromMessage(audioMsg, 'audio');
        let buffer = Buffer.alloc(0);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

        if (!buffer || buffer.length === 0) return;

        // Guardar temporalmente y convertir a WAV
        const tempInput = tmpFileName('ogg');
        fs.writeFileSync(tempInput, buffer);

        let wavPath = null;
        let transcripcion = null;

        try {
            wavPath = await convertToWav(tempInput);
            transcripcion = await transcribeWithGroq(wavPath);
        } finally {
            try { fs.unlinkSync(tempInput); } catch (_) {}
            if (wavPath) { try { fs.unlinkSync(wavPath); } catch (_) {} }
        }

        if (!transcripcion) return;

        // Guardar en el historial con prefijo [Audio]
        const chatDir = path.join(CHAT_DIR, remoteJid);
        if (!fs.existsSync(chatDir)) fs.mkdirSync(chatDir, { recursive: true });

        const chatFile = path.join(chatDir, `${cleanSender}.txt`);
        const linea = `[Audio]: ${transcripcion.replace(/\n/g, ' ')}`;
        fs.appendFileSync(chatFile, linea + '\n', 'utf-8');

    } catch (_) {
        // Falla silenciosa — no interrumpir el flujo principal
    }
}

module.exports = { tryTranscribeAndSave };
