/**
 * Sistema de Muteo de Usuarios - ROBUSTO Y CON DURACIÓN TEMPORAL
 * ✅ Prioridad máxima: elimina mensajes ANTES de cualquier procesamiento
 * ✅ Comandos: .mute @user [tiempo], .unmute @user, .listmutes
 * ✅ Soporta: 10s, 5m, 2h, 1d (segundos, minutos, horas, días)
 * ✅ REPARADO: Mejor manejo de conexión y limpieza de intervalos
 */

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

class MuteSystem {
    constructor(conn) {
        this.conn = conn;
        this.mutesFile = path.join(__dirname, 'data', 'mutes.json');
        this.mutedUsers = {};
        this.expirationInterval = null;
        this.loadMutes();
        this.cleanExpiredMutes();
        this.startExpirationChecker();
        console.log(chalk.green('[MuteSystem] ✓ Sistema inicializado con soporte de duración'));
    }

    loadMutes() {
        try {
            const dataDir = path.dirname(this.mutesFile);
            if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
            if (fs.existsSync(this.mutesFile)) {
                const data = fs.readFileSync(this.mutesFile, 'utf8');
                this.mutedUsers = JSON.parse(data);
            } else {
                this.mutedUsers = {};
                this.saveMutes();
            }
        } catch (err) {
            console.error(chalk.red('[MuteSystem] Error cargando muteos:'), err.message);
            this.mutedUsers = {};
        }
    }

    saveMutes() {
        try {
            const dataDir = path.dirname(this.mutesFile);
            if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
            fs.writeFileSync(this.mutesFile, JSON.stringify(this.mutedUsers, null, 2));
        } catch (err) {
            console.error(chalk.red('[MuteSystem] Error guardando muteos:'), err.message);
        }
    }

    cleanExpiredMutes() {
        const now = Date.now();
        let cleaned = 0;
        
        for (const group in this.mutedUsers) {
            for (const user in this.mutedUsers[group]) {
                const data = this.mutedUsers[group][user];
                if (data.expiresAt && data.expiresAt <= now) {
                    delete this.mutedUsers[group][user];
                    cleaned++;
                }
            }
            if (Object.keys(this.mutedUsers[group]).length === 0) {
                delete this.mutedUsers[group];
            }
        }
        
        if (cleaned > 0) {
            this.saveMutes();
            console.log(chalk.cyan(`[MuteSystem] 🧹 ${cleaned} muteo(s) expirado(s) eliminados`));
        }
    }

    parseDuration(str) {
        if (!str) return null;
        const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
        const matches = [...str.matchAll(/(\d+)\s*([smhd])/gi)];
        let total = 0;
        for (const [_, num, unit] of matches) total += parseInt(num) * (mult[unit.toLowerCase()] || 0);
        return total || null;
    }

    formatDuration(ms) {
        const sec = Math.floor(ms / 1000);
        const min = Math.floor(sec / 60);
        const hrs = Math.floor(min / 60);
        const days = Math.floor(hrs / 24);
        const parts = [];
        if (days) parts.push(`${days} día${days > 1 ? 's' : ''}`);
        if (hrs % 24) parts.push(`${hrs % 24} hora${hrs % 24 > 1 ? 's' : ''}`);
        if (min % 60) parts.push(`${min % 60} minuto${min % 60 > 1 ? 's' : ''}`);
        if (sec % 60 && parts.length < 2) parts.push(`${sec % 60} segundo${sec % 60 > 1 ? 's' : ''}`);
        return parts.join(', ');
    }

    formatExpiration(timestamp) {
        const diff = timestamp - Date.now();
        if (diff <= 0) return 'Expirado';
        return this.formatDuration(diff);
    }

    isUserMuted(group, num) {
        const data = this.mutedUsers[group]?.[num];
        if (!data) return false;
        if (data.expiresAt && Date.now() >= data.expiresAt) return false;
        return true;
    }

    async checkAndAutoUnmute(group, num) {
        const data = this.mutedUsers[group]?.[num];
        if (!data) return false;
        if (data.expiresAt && Date.now() >= data.expiresAt) {
            await this.unmuteUser(group, num, true);
            return false;
        }
        return true;
    }

    // Obtiene el mejor socket disponible: el del mensaje (subbot), o this.conn, o global.conn
    _getConn(message) {
        return (message && message._sock) || this.conn || global.conn || null;
    }

    // Obtiene un socket válido (conectado) para operaciones de red
    _getActiveConn(message) {
        const candidates = [
            message && message._sock,
            this.conn,
            global.conn,
            ...(global.subConns || [])
        ];
        for (const c of candidates) {
            if (c && c.user) return c;
        }
        return null;
    }

    muteUser(group, num, ms, userJid) {
        if (!this.mutedUsers[group]) this.mutedUsers[group] = {};
        const now = Date.now();
        this.mutedUsers[group][num] = { 
            mutedAt: now, 
            expiresAt: now + ms,
            jid: userJid
        };
        this.saveMutes();
        console.log(chalk.yellow(`[MuteSystem] 🔇 ${num} muteado por ${this.formatDuration(ms)}`));
        
        if (ms < 120000) {
            setTimeout(async () => {
                const stillMuted = this.isUserMuted(group, num);
                if (stillMuted) {
                    await this.unmuteUser(group, num, true);
                }
            }, ms);
        }
    }

    async unmuteUser(group, num, auto = false) {
        const data = this.mutedUsers[group]?.[num];
        if (!data) return false;
        const duration = data.expiresAt - data.mutedAt;
        const userJid = data.jid || `${num}@s.whatsapp.net`;
        
        delete this.mutedUsers[group][num];
        if (!Object.keys(this.mutedUsers[group]).length) delete this.mutedUsers[group];
        this.saveMutes();

        console.log(chalk.green(`[MuteSystem] 🔊 ${num} desmuteado`));
        
        if (auto) {
            const activeConn = this._getActiveConn(null);
            if (activeConn) {
                try {
                    await activeConn.sendMessage(group, {
                        text: `🔊 *Usuario Desmuteado Automáticamente*\n\n@${num} ha sido desmuteado tras *${this.formatDuration(duration)}*.\n\n✅ Ya puede hablar.`,
                        mentions: [userJid]
                    });
                } catch (e) {
                    if (!e.message?.includes('Connection Closed')) {
                        console.error(chalk.red('[MuteSystem] Error enviando aviso:'), e.message);
                    }
                }
            }
        }
        return true;
    }

    getMutedUsers(group) {
        return this.mutedUsers[group] || {};
    }

    startExpirationChecker() {
        // Limpiar intervalo anterior si existe
        if (this.expirationInterval) {
            clearInterval(this.expirationInterval);
        }

        this.expirationInterval = setInterval(async () => {
            const now = Date.now();
            const toUnmute = [];
            
            for (const g in this.mutedUsers) {
                for (const u in this.mutedUsers[g]) {
                    if (this.mutedUsers[g][u].expiresAt <= now) {
                        toUnmute.push({ g, u });
                    }
                }
            }
            
            for (const { g, u } of toUnmute) {
                await this.unmuteUser(g, u, true);
            }
            
            if (toUnmute.length) {
                console.log(chalk.cyan(`[MuteSystem] ⏰ ${toUnmute.length} desmuteo(s) automáticos`));
            }
        }, 10000); // Cambiado de 5000 a 10000 (10 segundos) para reducir carga
    }

    async checkAndDeleteMutedMessage(msg, sockOverride) {
        try {
            if (!msg.key.remoteJid.includes('@g.us') || msg.key.fromMe) return false;
            
            const group = msg.key.remoteJid;
            const sender = (msg.key.participant || msg.key.remoteJid).split('@')[0].split(':')[0];
            
            const data = this.mutedUsers[group]?.[sender];
            if (data && data.expiresAt && Date.now() >= data.expiresAt) {
                await this.unmuteUser(group, sender, true);
                return false;
            }
            
            const muted = await this.checkAndAutoUnmute(group, sender);
            if (muted) {
                // Usar el socket que recibió el mensaje (ya sabemos que está en el grupo)
                // Si no se pasó uno explícito, buscar el mejor disponible
                const connToUse = sockOverride || this._getActiveConn(null);
                if (!connToUse) return false;

                await connToUse.sendMessage(group, { delete: msg.key });
                console.log(chalk.yellow(`[MuteSystem] 🔇 Mensaje eliminado de ${sender}`));
                return true;
            }
            return false;
        } catch (e) {
            if (!e.message?.includes('Connection Closed')) {
                console.error(chalk.red('[MuteSystem] Error eliminando mensaje:'), e.message);
            }
            return false;
        }
    }

    async handleMuteCommand(message) {
        try {
            if (!message.isGroup) return message.reply('❌ Solo en grupos.');
            
            const activeConn = this._getActiveConn(message);
            if (!activeConn) {
                return message.reply('❌ No hay ningún bot conectado disponible.');
            }

            const meta = await activeConn.groupMetadata(message.from);
            const sender = message.sender.split('@')[0].split(':')[0];
            const user = meta.participants.find(p => p.id.includes(sender));
            const isAdmin = user && (user.admin === 'admin' || user.admin === 'superadmin');
            const isOwner = global.botConfig?.isOwner(sender) || global.botConfig?.owners?.some(o => o.replace(/\D/g, '') === sender);

            if (!isAdmin && !isOwner)
                return message.reply('❌ Solo los *administradores* pueden usar este comando.');

            // Soporte para "me"
            const bodyParts = message.body.trim().split(' ');
            let target, num;
            if (bodyParts[1]?.toLowerCase() === 'me') {
                num = sender;
                target = message.sender;
            } else {
                if (!message.mentions?.length)
                    return message.reply('⚠️ Debes mencionar a un usuario y el tiempo.\n\nEjemplo: `.mute @usuario 5m` o `.mute me 5m`');
                target = message.mentions[0];
                num = target.split('@')[0].split(':')[0];
                const tdata = meta.participants.find(p => p.id.includes(num));
                if (tdata?.admin && !isOwner) return message.reply('❌ No puedes mutear a un administrador.');
            }

            const args = bodyParts.slice(2).join(' ');
            const ms = this.parseDuration(args);
            if (!ms) return message.reply('❌ Tiempo inválido. Ej: `10s`, `5m`, `2h`, `1d`, `1h 30m`');

            if (this.isUserMuted(message.from, num))
                return message.reply(`⚠️ @${num} ya está muteado.`, { mentions: [target] });

            this.muteUser(message.from, num, ms, target);
            message.reply(
                `🔇 *Usuario Muteado*\n\n@${num} fue silenciado por *${this.formatDuration(ms)}*.\n\nSus mensajes serán eliminados automáticamente.`,
                { mentions: [target] }
            );
        } catch (e) {
            if (!e.message?.includes('Connection Closed')) {
                console.error(chalk.red('[MuteSystem] Error en .mute:'), e.message);
            }
            message.reply('❌ Error al mutear.');
        }
    }

    async handleUnmuteCommand(message) {
        try {
            if (!message.isGroup) return message.reply('❌ Solo en grupos.');
            
            const activeConn = this._getActiveConn(message);
            if (!activeConn) {
                return message.reply('❌ No hay ningún bot conectado disponible.');
            }

            const meta = await activeConn.groupMetadata(message.from);
            const sender = message.sender.split('@')[0].split(':')[0];
            const user = meta.participants.find(p => p.id.includes(sender));
            const isAdmin = user && (user.admin === 'admin' || user.admin === 'superadmin');
            const isOwner = global.botConfig?.isOwner(sender) || global.botConfig?.owners?.some(o => o.replace(/\D/g, '') === sender);

            if (!isAdmin && !isOwner)
                return message.reply('❌ Solo los *administradores* pueden usar este comando.');

            // Soporte para "me"
            const bodyParts = message.body.trim().split(' ');
            let target, num;
            if (bodyParts[1]?.toLowerCase() === 'me') {
                num = sender;
                target = message.sender;
            } else {
                if (!message.mentions?.length)
                    return message.reply('⚠️ Menciona al usuario que deseas desmutear.\nEj: `.unmute @usuario` o `.unmute me`');
                target = message.mentions[0];
                num = target.split('@')[0].split(':')[0];
            }

            if (!this.isUserMuted(message.from, num))
                return message.reply(`⚠️ @${num} no está muteado.`, { mentions: [target] });

            await this.unmuteUser(message.from, num, false);
            message.reply(`🔊 *Usuario Desmuteado*\n\n@${num} ahora puede hablar.`, { mentions: [target] });
        } catch (e) {
            if (!e.message?.includes('Connection Closed')) {
                console.error(chalk.red('[MuteSystem] Error en .unmute:'), e.message);
            }
            message.reply('❌ Error al desmutear.');
        }
    }

    async handleListMutesCommand(message) {
        try {
            if (!message.isGroup) return message.reply('❌ Solo en grupos.');
            const muted = this.getMutedUsers(message.from);
            const list = Object.keys(muted);
            if (!list.length) return message.reply('✅ No hay usuarios muteados.');

            let text = `🔇 *Usuarios Muteados*\n\nTotal: ${list.length}\n\n`;
            list.forEach((n, i) => {
                text += `${i + 1}. @${n}\n   ⏰ Expira en: ${this.formatExpiration(muted[n].expiresAt)}\n\n`;
            });
            text += `_Usa_ *.unmute @usuario* _para desmutear._`;
            const mentions = list.map(n => muted[n].jid || `${n}@s.whatsapp.net`);
            message.reply(text, { mentions });
        } catch (e) {
            if (!e.message?.includes('Connection Closed')) {
                console.error(chalk.red('[MuteSystem] Error en .listmutes:'), e.message);
            }
            message.reply('❌ Error al listar muteados.');
        }
    }

    // Método para limpiar el intervalo al destruir
    destroy() {
        if (this.expirationInterval) {
            clearInterval(this.expirationInterval);
            this.expirationInterval = null;
            console.log(chalk.yellow('[MuteSystem] 🗑️ Intervalo de expiración limpiado'));
        }
    }
}

module.exports = MuteSystem;