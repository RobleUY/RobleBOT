const axios = require('axios');
const fs = require('fs');
const archiver = require('archiver');
const path = require('path');
const moment = require('moment-timezone');

// BANDERA para controlar que solo se ejecute UNA VEZ al iniciar
let backupRealizado = false;

/**
 * Crea ZIP de TODO excepto main-session.db y node_modules
 */
function createZip(outputPath) {
    return new Promise((resolve, reject) => {
        const output = fs.createWriteStream(outputPath);
        const archive = archiver('zip', { zlib: { level: 1 } });
        
        output.on('close', () => resolve(outputPath));
        archive.on('error', reject);
        archive.on('warning', (err) => {
            if (err.code !== 'ENOENT') reject(err);
        });
        
        archive.pipe(output);
        
        // Agregar TODO excepto lo que queremos excluir
        archive.glob('**/*', {
            cwd: __dirname,
            ignore: [
                'node_modules/**',
                'database.json',
                'main-session.db',
                'main-session.db-shm',
                'main-session.db-wal',
                'backup_*.zip',
                'backup_temp_*.zip',
                '.git/**',
                '.env',
                // Include data folder but exclude chats and voice notes
                'data/chats/**',
                'data/**/*.opus',
                'data/**/*.ogg',
                'data/**/*.mp3',
                'CHATS-USUARIOS/**',
                '*.log',
                'tmp/**',
                'logs/**',
                'plugins/tmp/**',
                'plugins/DESCARGADORES/descargas/**',
                'plugins/DESCARGADORES/.temp/**',
                'plugins/SUBBOTS/sesiones/**',
                '**/.temp/**',
                '**/*.mp4',
                '**/*.mp3',
                '**/*.webm',
                '**/*.mkv',
                '**/*.avi'
            ]
        });
        
        archive.finalize();
    });
}

/**
 * Elimina TODOS los archivos del repositorio
 */
async function clearRepository(config) {
    const { token, owner, repo, branch } = config;
    
    try {
        // Obtener todos los archivos en el repo
        const { data: contents } = await axios.get(
            `https://api.github.com/repos/${owner}/${repo}/contents`,
            {
                headers: { Authorization: `Bearer ${token}` },
                params: { ref: branch }
            }
        );
        
        // Eliminar cada archivo
        for (const file of contents) {
            if (file.type === 'file') {
                await axios.delete(
                    `https://api.github.com/repos/${owner}/${repo}/contents/${file.name}`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        data: {
                            message: `Eliminando ${file.name} antes de nuevo backup`,
                            sha: file.sha,
                            branch
                        }
                    }
                );
                console.log(`🗑️  Eliminado: ${file.name}`);
            }
        }
    } catch (error) {
        console.log('ℹ️  Repositorio vacío o error al limpiar:', error.message);
    }
}

/**
 * Sube el nuevo ZIP a GitHub (nombre fijo: bot-backup.zip)
 */
async function uploadToGithub(zipPath, config) {
    const { token, owner, repo, branch } = config;
    
    const zipBuffer = fs.readFileSync(zipPath);
    const zipBase64 = zipBuffer.toString('base64');
    const fileName = 'bot-backup.zip'; // NOMBRE FIJO
    
    // Subir el archivo
    const body = {
        message: `Backup ${moment().tz('America/Montevideo').format('YYYY-MM-DD HH:mm:ss')}`,
        content: zipBase64,
        branch
    };
    
    await axios.put(
        `https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`,
        body,
        {
            headers: { Authorization: `Bearer ${token}` },
            timeout: 300000,
            maxContentLength: 150 * 1024 * 1024
        }
    );
    
    return fileName;
}

/**
 * FUNCIÓN PRINCIPAL - Solo se ejecuta UNA VEZ al iniciar
 */
async function backupToGithub() {
    // VERIFICAR si ya se hizo backup
    if (backupRealizado) {
        console.log('⏭️  Backup ya realizado en esta sesión');
        return false;
    }
    
    require('dotenv').config();
    
    const timestamp = moment().tz('America/Montevideo').format('YYYY-MM-DD_HH-mm-ss');
    const zipName = `backup_temp_${timestamp}.zip`;
    const zipPath = path.join(__dirname, zipName);
    
    try {
        console.log('�️ Ejecutando backup...');
        console.log('🗜️ Creando ZIP...');
        await createZip(zipPath);
        console.log('✓ ZIP creado');
        
        const config = {
            token: process.env.GITHUB_TOKEN,
            owner: process.env.GITHUB_OWNER,
            repo: process.env.GITHUB_REPO,
            branch: process.env.GITHUB_BRANCH || 'main'
        };
        
        console.log('🗑️  Limpiando repositorio...');
        await clearRepository(config);
        
        console.log('� Subiendo nuevo backup a GitHub...');
        await uploadToGithub(zipPath, config);
        
        console.log('✅ Backup completado exitosamente');
        
        // Marcar como realizado
        backupRealizado = true;
        
        // Borrar ZIP local
        fs.unlinkSync(zipPath);
        console.log('🗑️ ZIP local eliminado');
        
        return true;
    } catch (error) {
        console.error('❌ Error en backup:', error.message);
        
        // Limpiar ZIP si falló
        if (fs.existsSync(zipPath)) {
            fs.unlinkSync(zipPath);
        }
        
        return false;
    }
}

/**
 * Resetear bandera (útil si necesitas hacer backup manual)
 */
function resetBackupFlag() {
    backupRealizado = false;
    console.log('🔄 Bandera de backup reseteada');
}

module.exports = { 
    backupToGithub,
    resetBackupFlag 
};

// Ejecutar si se llama directamente
if (require.main === module) {
    backupToGithub();
}