const axios = require('axios');
const fs = require('fs');
const archiver = require('archiver');
const path = require('path');
const moment = require('moment-timezone');

let backupRealizado = false;
let backupEnCurso = false;

/**
 * Crea un ZIP del proyecto excluyendo sesiones, dependencias y archivos temporales.
 */
function createZip(outputPath) {
    return new Promise((resolve, reject) => {
        const output = fs.createWriteStream(outputPath);
        const archive = archiver('zip', { zlib: { level: 1 } });

        output.on('close', () => resolve(outputPath));
        output.on('error', reject);
        archive.on('error', reject);
        archive.on('warning', (err) => {
            if (err.code !== 'ENOENT') reject(err);
        });

        archive.pipe(output);
        archive.glob('**/*', {
            cwd: __dirname,
            ignore: [
                'node_modules/**',
                'database.db',
                'database.db-shm',
                'database.db-wal',
                'main-session.db',
                'main-session.db-shm',
                'main-session.db-wal',
                'backup_*.zip',
                'backup_temp_*.zip',
                'bot-backup.zip',
                'bot-backup/**',
                '.git/**',
                '.env',
                'data/chats/**',
                'data/**/*.opus',
                'data/**/*.ogg',
                'data/**/*.mp3',
                'CHATS-USUARIOS/**',
                '*.log',
                'tmp/**',
                'logs/**',
                'plugins/tmp/**',
                'plugins/DESCARGADORES/descargas/**',
                'plugins/DESCARGADORES/.temp/**',
                'plugins/SUBBOTS/sesiones/**',
                '**/.temp/**',
                '**/*.mp4',
                '**/*.mp3',
                '**/*.webm',
                '**/*.mkv',
                '**/*.avi'
            ]
        });

        archive.finalize();
    });
}

/**
 * Crea o reemplaza únicamente bot-backup.zip en GitHub.
 */
async function uploadToGithub(zipPath, config) {
    const { token, owner, repo, branch } = config;
    const fileName = 'bot-backup.zip';
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`;
    const headers = {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
    };

    let sha;
    try {
        const { data: existingFile } = await axios.get(url, {
            headers,
            params: { ref: branch },
            timeout: 15000
        });
        if (existingFile.type !== 'file' || !existingFile.sha) {
            throw new Error(`${fileName} existe en GitHub, pero no es un archivo reemplazable`);
        }
        sha = existingFile.sha;
    } catch (error) {
        if (error.response?.status !== 404) {
            throw error;
        }
    }

    const zipSize = fs.statSync(zipPath).size;
    if (zipSize > 100 * 1024 * 1024) {
        throw new Error('bot-backup.zip supera el límite de 100 MB de la API de GitHub Contents');
    }

    const zipBuffer = fs.readFileSync(zipPath);
    const body = {
        message: `Backup ${moment().tz('America/Montevideo').format('YYYY-MM-DD HH:mm:ss')}`,
        content: zipBuffer.toString('base64'),
        branch
    };
    if (sha) {
        body.sha = sha;
    }

    await axios.put(url, body, {
        headers,
        timeout: 300000,
        maxContentLength: 10 * 1024 * 1024,
        maxBodyLength: 150 * 1024 * 1024
    });

    return fileName;
}

async function backupToGithub() {
    if (backupRealizado) {
        console.log('⏭️  Backup ya realizado en esta sesión');
        return false;
    }
    if (backupEnCurso) {
        console.log('⏭️  Ya hay un backup en curso');
        return false;
    }

    backupEnCurso = true;
    try {
        return await doBackup();
    } finally {
        backupEnCurso = false;
    }
}

async function doBackup() {
    require('dotenv').config();

    const config = {
        token: process.env.GITHUB_TOKEN,
        owner: process.env.GITHUB_OWNER,
        repo: process.env.GITHUB_REPO,
        branch: process.env.GITHUB_BRANCH || 'main'
    };
    const missingConfig = ['token', 'owner', 'repo']
        .filter(key => !config[key])
        .map(key => `GITHUB_${key.toUpperCase()}`);
    if (missingConfig.length) {
        console.error(`❌ Faltan variables para subir el backup: ${missingConfig.join(', ')}`);
        return false;
    }

    const oldZips = fs.readdirSync(__dirname).filter(file => /^backup_temp_.*\.zip$/.test(file));
    for (const oldZip of oldZips) {
        fs.unlinkSync(path.join(__dirname, oldZip));
        console.log(`🗑️ Limpiando ZIP anterior: ${oldZip}`);
    }

    const timestamp = moment().tz('America/Montevideo').format('YYYY-MM-DD_HH-mm-ss');
    const zipPath = path.join(__dirname, `backup_temp_${timestamp}.zip`);

    try {
        console.log('🗜️ Ejecutando backup...');
        console.log('🗜️ Creando ZIP...');
        await createZip(zipPath);
        console.log('✓ ZIP creado');

        console.log('📤 Subiendo/reemplazando únicamente bot-backup.zip en GitHub...');
        const uploadedFile = await uploadToGithub(zipPath, config);
        console.log(`✅ Backup completado exitosamente: ${uploadedFile}`);

        backupRealizado = true;
        fs.unlinkSync(zipPath);
        console.log('🗑️ ZIP local eliminado');
        return true;
    } catch (error) {
        const githubMessage = error.response?.data?.message;
        console.error('❌ Error en backup:', githubMessage || error.message);
        if (fs.existsSync(zipPath)) {
            fs.unlinkSync(zipPath);
        }
        return false;
    }
}

function resetBackupFlag() {
    backupRealizado = false;
    console.log('🔄 Bandera de backup reseteada');
}

module.exports = {
    backupToGithub,
    resetBackupFlag
};

if (require.main === module) {
    backupToGithub();
}
