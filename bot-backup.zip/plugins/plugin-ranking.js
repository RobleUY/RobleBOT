const { getPluginRanking } = require('../pluginStatsRecorder');

let handler = async (message, { args }) => {
    try {
        const ranking = getPluginRanking();

        if (ranking.length === 0) {
            return await message.reply('📊 Aún no hay datos de uso de plugins. ¡Usa algunos comandos primero!');
        }

        // Límite opcional: .pluginranking 20  (por defecto muestra todos)
        const limit = parseInt(args[0]) || ranking.length;
        const slice = ranking.slice(0, limit);

        const totalUses = ranking.reduce((sum, r) => sum + r.uses, 0);

        // Emojis de podio para los primeros 3
        const medals = ['🥇', '🥈', '🥉'];

        let text = `╔══════════════════════╗\n`;
        text += `║  📊 *RANKING DE PLUGINS*  ║\n`;
        text += `╚══════════════════════╝\n\n`;
        text += `📦 *Total de usos registrados:* ${totalUses.toLocaleString()}\n`;
        text += `📋 *Plugins con actividad:* ${ranking.length}\n\n`;

        slice.forEach((entry, i) => {
            const pos = i + 1;
            const medal = medals[i] || `${pos}.`;
            // Mostrar solo el nombre del archivo sin la ruta completa
            const parts = entry.plugin.split('/');
            const fileName = parts[parts.length - 1].replace('.js', '');
            // Carpeta padre para contexto (ej: ECONOMIA, FUN, etc.)
            const folder = parts.length > 2 ? parts[parts.length - 2] : parts[0];
            const label = folder !== 'plugins' ? `${folder}/${fileName}` : fileName;

            const bar = buildBar(entry.uses, ranking[0].uses);
            text += `${medal} *${label}*\n`;
            text += `   ${bar} ${entry.uses.toLocaleString()} usos\n\n`;
        });

        if (limit < ranking.length) {
            text += `_...y ${ranking.length - limit} plugins más. Usa .pluginranking ${ranking.length} para ver todos._`;
        }

        return await message.reply(text);
    } catch (error) {
        console.error('[plugin-ranking] Error:', error.message);
        return await message.reply('❌ Error al obtener el ranking de plugins.');
    }
};

/**
 * Genera una barra de progreso visual proporcional al máximo.
 * Ej: ████████░░ 
 */
function buildBar(value, max, length = 10) {
    if (!max || max === 0) return '░'.repeat(length);
    const filled = Math.round((value / max) * length);
    return '█'.repeat(filled) + '░'.repeat(length - filled);
}

handler.help = ['pluginranking', 'rankplugins', 'pluginstats'];
handler.tags = ['info', 'owner'];
handler.command = /^(pluginranking|rankplugins|pluginstats)$/i;
handler.owner = true; // Solo el owner puede verlo

module.exports = handler;
