const { loadStats } = require('../botStatsRecorder');

let handler = async (message, { args }) => {
    try {
        const stats = loadStats();
        const ranking = Object.entries(stats.commands || {})
            .map(([command, uses]) => ({ command, uses }))
            .sort((a, b) => b.uses - a.uses);

        if (ranking.length === 0) {
            return await message.reply('📊 Aún no hay datos de uso de comandos. ¡Usa algunos comandos primero!');
        }

        const limit = parseInt(args[0]) || ranking.length;
        const slice = ranking.slice(0, limit);

        const totalUses = ranking.reduce((sum, r) => sum + r.uses, 0);

        let text = `╔══════════════════════╗\n`;
        text += `║  📊 *RANKING DE COMANDOS*  ║\n`;
        text += `╚══════════════════════╝\n\n`;
        text += `📦 *Total de usos registrados:* ${totalUses.toLocaleString()}\n`;
        text += `📋 *Comandos con actividad:* ${ranking.length}\n\n`;

        slice.forEach((entry, i) => {
            const pos = i + 1;
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${pos}.`;
            text += `${medal} *${entry.command}* — ${entry.uses.toLocaleString()} usos\n`;
        });

        if (limit < ranking.length) {
            text += `_...y ${ranking.length - limit} comandos más. Usa .cmdstats ${ranking.length} para ver todos._`;
        }

        return await message.reply(text);
    } catch (error) {
        console.error('[command-ranking] Error:', error.message);
        return await message.reply('❌ Error al obtener el ranking de comandos.');
    }
};

/**
 * Genera una barra de progreso visual proporcional al máximo.
 * Ej: ████████░░ 
 */
function buildBar(value, max, length = 10) {
    if (!max || max === 0) return '░'.repeat(length);
    const filled = Math.round((value / max) * length);
    return '█'.repeat(filled) + '░'.repeat(length - filled);
}

handler.help = ['cmdstats', 'statscmd', 'statscmds', 'topcmds', 'cmdranking'];
handler.tags = ['info', 'owner'];
handler.command = /^(cmdstats|statscmd|statscmds|topcmds|cmdranking|plugins|plugin|pluginstats|pluginstat)$/i;


module.exports = handler;
