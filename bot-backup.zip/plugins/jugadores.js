const axios = require('axios');
const db = require('../database.js');
const premium = require('../premium');

// **IMPORTANTE:** Este código asume acceso a global.conn para @whiskeysockets/baileys
// y global.db para el sistema de monedas

// --- CONFIGURACIÓN DE PRECIOS ---
const PRECIO_BASE_POR_ESTRELLA = 10000; // 10,000 monedas por estrella
// ---

// 🧠 Cache simple para imágenes de Pinterest
const imageCache = new Map();

/**
 * 🔍 Buscar imagen de futbolista en Pinterest
 */
async function buscarImagenFutbolista(nombreJugador, pais) {
    const query = `Jugador ${nombreJugador} seleccion ${pais}`;
    
    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://www.robleuy.site/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 8000 });

        if (!data?.ok || !data?.images?.length) return null;

        const random = data.images[Math.floor(Math.random() * data.images.length)];
        const imageUrl = random?.large || random?.small;
        if (!imageUrl) return null;

        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`Error buscando imagen para ${nombreJugador}:`, error.message);
        return null;
    }
}

// --- DATOS DE FUTBOLISTAS (Mundial Qatar 2022) ---
const FUTBOLISTAS_BASE = [
    // GRUPO A - CATAR
    { nombre: 'Almoez Ali', pais: 'Catar', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Hassan Al-Haydos', pais: 'Catar', posicion: 'Mediocampista', calidad: '☆☆' },
    
    // GRUPO A - ECUADOR
    { nombre: 'Enner Valencia', pais: 'Ecuador', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Moisés Caicedo', pais: 'Ecuador', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO A - SENEGAL
    { nombre: 'Sadio Mané', pais: 'Senegal', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Kalidou Koulibaly', pais: 'Senegal', posicion: 'Defensa', calidad: '☆☆☆☆' },
    { nombre: 'Édouard Mendy', pais: 'Senegal', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO A - PAÍSES BAJOS
    { nombre: 'Virgil van Dijk', pais: 'Países Bajos', posicion: 'Defensa', calidad: '☆☆☆☆☆' },
    { nombre: 'Frenkie de Jong', pais: 'Países Bajos', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Memphis Depay', pais: 'Países Bajos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO B - INGLATERRA
    { nombre: 'Harry Kane', pais: 'Inglaterra', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Raheem Sterling', pais: 'Inglaterra', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Jude Bellingham', pais: 'Inglaterra', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO B - IRÁN
    { nombre: 'Sardar Azmoun', pais: 'Irán', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Alireza Jahanbakhsh', pais: 'Irán', posicion: 'Mediocampista', calidad: '☆☆' },
    
    // GRUPO B - ESTADOS UNIDOS
    { nombre: 'Christian Pulisic', pais: 'Estados Unidos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Weston McKennie', pais: 'Estados Unidos', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO B - GALES
    { nombre: 'Gareth Bale', pais: 'Gales', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Aaron Ramsey', pais: 'Gales', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO C - ARGENTINA
    { nombre: 'Lionel Messi', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Ángel Di María', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Emiliano Martínez', pais: 'Argentina', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    { nombre: 'Lautaro Martínez', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO C - ARABIA SAUDÍ
    { nombre: 'Salem Al-Dawsari', pais: 'Arabia Saudí', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO C - MÉXICO
    { nombre: 'Hirving Lozano', pais: 'México', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Guillermo Ochoa', pais: 'México', posicion: 'Portero', calidad: '☆☆☆' },
    
    // GRUPO C - POLONIA
    { nombre: 'Robert Lewandowski', pais: 'Polonia', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Wojciech Szczęsny', pais: 'Polonia', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO D - FRANCIA
    { nombre: 'Kylian Mbappé', pais: 'Francia', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Antoine Griezmann', pais: 'Francia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'N\'Golo Kanté', pais: 'Francia', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Hugo Lloris', pais: 'Francia', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO D - AUSTRALIA
    { nombre: 'Mathew Leckie', pais: 'Australia', posicion: 'Delantero', calidad: '☆☆' },
    
    // GRUPO D - DINAMARCA
    { nombre: 'Christian Eriksen', pais: 'Dinamarca', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Kasper Schmeichel', pais: 'Dinamarca', posicion: 'Portero', calidad: '☆☆☆' },
    
    // GRUPO D - TÚNEZ
    { nombre: 'Wahbi Khazri', pais: 'Túnez', posicion: 'Delantero', calidad: '☆☆' },
    
    // GRUPO E - ESPAÑA
    { nombre: 'Sergio Busquets', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Pedri', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Gavi', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO E - COSTA RICA
    { nombre: 'Keylor Navas', pais: 'Costa Rica', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO E - ALEMANIA
    { nombre: 'Manuel Neuer', pais: 'Alemania', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    { nombre: 'Thomas Müller', pais: 'Alemania', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Joshua Kimmich', pais: 'Alemania', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO E - JAPÓN
    { nombre: 'Takumi Minamino', pais: 'Japón', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO F - BÉLGICA
    { nombre: 'Kevin De Bruyne', pais: 'Bélgica', posicion: 'Mediocampista', calidad: '☆☆☆☆☆' },
    { nombre: 'Eden Hazard', pais: 'Bélgica', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Romelu Lukaku', pais: 'Bélgica', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Thibaut Courtois', pais: 'Bélgica', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    
    // GRUPO F - CANADÁ
    { nombre: 'Alphonso Davies', pais: 'Canadá', posicion: 'Defensa', calidad: '☆☆☆☆' },
    
    // GRUPO F - MARRUECOS
    { nombre: 'Achraf Hakimi', pais: 'Marruecos', posicion: 'Defensa', calidad: '☆☆☆☆' },
    { nombre: 'Hakim Ziyech', pais: 'Marruecos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO F - CROACIA
    { nombre: 'Luka Modrić', pais: 'Croacia', posicion: 'Mediocampista', calidad: '☆☆☆☆☆' },
    { nombre: 'Ivan Perišić', pais: 'Croacia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO G - BRASIL
    { nombre: 'Neymar Jr', pais: 'Brasil', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Vinícius Júnior', pais: 'Brasil', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Casemiro', pais: 'Brasil', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Alisson Becker', pais: 'Brasil', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    
    // GRUPO G - SERBIA
    { nombre: 'Dušan Vlahović', pais: 'Serbia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Dušan Tadić', pais: 'Serbia', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO G - SUIZA
    { nombre: 'Xherdan Shaqiri', pais: 'Suiza', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Granit Xhaka', pais: 'Suiza', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO G - CAMERÚN
    { nombre: 'André Onana', pais: 'Camerún', posicion: 'Portero', calidad: '☆☆☆☆' },
    { nombre: 'Eric Maxim Choupo-Moting', pais: 'Camerún', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO H - PORTUGAL
    { nombre: 'Cristiano Ronaldo', pais: 'Portugal', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Bruno Fernandes', pais: 'Portugal', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Bernardo Silva', pais: 'Portugal', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO H - GHANA
    { nombre: 'Thomas Partey', pais: 'Ghana', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Mohammed Kudus', pais: 'Ghana', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO H - URUGUAY
    { nombre: 'Luis Suárez', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Edinson Cavani', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Federico Valverde', pais: 'Uruguay', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Darwin Núñez', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO H - REPÚBLICA DE COREA
    { nombre: 'Son Heung-min', pais: 'República de Corea', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Hwang Hee-chan', pais: 'República de Corea', posicion: 'Delantero', calidad: '☆☆☆' },
];

const LISTA_FUTBOLISTAS = FUTBOLISTAS_BASE.map(fb => ({ 
    ...fb, 
    nombreFormateado: fb.nombre,
    nombre: fb.nombre.replace(/\s/g, '').toLowerCase()
}));

/**
 * Convierte el nombre simple al formato legible
 */
function formatoNombre(nombreSimple) {
    const fbData = LISTA_FUTBOLISTAS.find(fb => fb.nombre === nombreSimple);
    if (!fbData) return nombreSimple.toUpperCase();
    return fbData.nombreFormateado.replace(/\s/g, '_');
}

/**
 * Obtiene el precio de venta basado en estrellas
 */
function obtenerPrecioVenta(calidadString) {
    const estrellas = calidadString.length;
    return estrellas * PRECIO_BASE_POR_ESTRELLA;
}

// --- Carga y Guardado de Datos ---
function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.futbolistas) db.data.futbolistas = {};
    if (!db.data.intercambiosFutbol) db.data.intercambiosFutbol = {};
}

function guardarCambios() {
    if (db && typeof db.save === 'function') {
        db.save();
    }
}

// --- FUNCIONES DE MANEJO DE MONEDAS ---
function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

async function restarMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return false;
    const user = await global.db.getUser(jid, groupId);
    let restante = cantidad;

    if (user.money >= restante) {
        user.money -= restante;
    } else {
        restante -= (user.money || 0);
        user.money = 0;
        
        if (user.bank >= restante) {
            user.bank -= restante;
        } else {
            return false;
        }
    }
    await global.db.saveUser(user);
    return true;
}

// --- Otras Funciones de Utilidad ---
function obtenerFutbolistaAleatorio() {
    const totalPeso = LISTA_FUTBOLISTAS.reduce((sum, fb) => {
        const pesoBase = 6 - fb.calidad.length;
        return sum + pesoBase;
    }, 0);

    let random = Math.floor(Math.random() * totalPeso);
    for (const fb of LISTA_FUTBOLISTAS) {
        const pesoBase = 6 - fb.calidad.length;
        if (random < pesoBase) {
            return fb;
        }
        random -= pesoBase;
    }
    return LISTA_FUTBOLISTAS[Math.floor(Math.random() * LISTA_FUTBOLISTAS.length)];
}

function buscarFutbolistaPorNombre(nombreSimple) {
    const nombreLimpio = nombreSimple.replace(/\s/g, '').replace(/_/g, '').toLowerCase();
    return LISTA_FUTBOLISTAS.find(fb => fb.nombre === nombreLimpio);
}

// --- Manejador Principal ---
let handler = async (message, { text, command, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = senderJid?.split('@')[0];
        
        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const futbolistasData = db.data.futbolistas;
        const intercambiosFutbol = db.data.intercambiosFutbol;

        if (!futbolistasData[senderNumber]) {
            futbolistasData[senderNumber] = {
                futbolistas: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            guardarCambios();
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        // COMANDO: /fpj (sin subcomando) -> Muestra comandos
        if (command.match(/^fpj$/i) && !subCommand) {
            return await message.reply(
                '⚽ *COMANDOS DE FUTBOLISTAS* ⚽\n' +
                '━━━━━━━━━━\n\n' +
                '*/fpj reclamar* / *claim* - _Reclama un futbolista aleatorio (1 por hora)._\n' +
                '*/myfpj* - _Ver tu colección de futbolistas._\n' +
                '*/myfpj ver [futbolista]* - _Ver la imagen de un futbolista._\n' +
                '*/fpj regalar @user [futbolista]* - _Regala un futbolista._\n' +
                '*/fpj intercambio @user [mi_fb] [su_fb]* - _Propone intercambio._\n' +
                '*/fpj intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*/fpj intercambio rechazar @user* - _Rechazar intercambio._\n' +
                '*/fpj vender [futbolista] [cantidad]* - _Vende futbolistas._\n' +
                '*/fpj vender all* - _Vende todos tus futbolistas._\n'
            );
        }

        // SUBCOMANDO: vender
        if (subCommand === 'vender') {
            const comandoVender = args[1]?.toLowerCase();
            let totalMonedasGanadas = 0;
            let futbolistasVendidos = 0;
            const inventarioUsuario = futbolistasData[senderNumber].futbolistas;

            if (comandoVender === 'all') {
                if (inventarioUsuario.length === 0) {
                    return await message.reply('❌ *Tu colección está vacía.*');
                }

                const conteo = inventarioUsuario.reduce((acc, name) => {
                    acc[name] = (acc[name] || 0) + 1;
                    return acc;
                }, {});

                const futbolistasNoReconocidos = [];

                for (const nameSimple in conteo) {
                    const count = conteo[nameSimple];
                    const fbData = buscarFutbolistaPorNombre(nameSimple);

                    if (fbData) {
                        const precioPorUnidad = obtenerPrecioVenta(fbData.calidad);
                        const ganancia = precioPorUnidad * count;
                        totalMonedasGanadas += ganancia;
                        futbolistasVendidos += count;
                    } else {
                        // Si no se reconoce el futbolista, se conserva por seguridad
                        for (let i = 0; i < count; i++) {
                            futbolistasNoReconocidos.push(nameSimple);
                        }
                    }
                }

                if (futbolistasVendidos === 0) {
                    return await message.reply('❌ *No tienes futbolistas para vender.*');
                }

                futbolistasData[senderNumber].futbolistas = futbolistasNoReconocidos;

            } else {
                const nombreFutbolistaEntrada = args[1];
                const cantidadAVender = parseInt(args[2] || 1);
                
                if (!nombreFutbolistaEntrada || isNaN(cantidadAVender) || cantidadAVender < 1) {
                    return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj vender [NombreFutbolista] [cantidad]_ o _/fpj vender all_');
                }

                const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);

                if (!futbolista) {
                    return await message.reply(`❌ *Futbolista no encontrado.*`);
                }

                const nombreSimple = futbolista.nombre;
                const conteoEnInventario = inventarioUsuario.filter(name => name === nombreSimple).length;
                
                if (conteoEnInventario < cantidadAVender) {
                    return await message.reply(`❌ Solo tienes *${conteoEnInventario}x ${formatoNombre(nombreSimple)}*`);
                }
                
                const precioPorUnidad = obtenerPrecioVenta(futbolista.calidad);
                totalMonedasGanadas = precioPorUnidad * cantidadAVender;
                futbolistasVendidos = cantidadAVender;
                
                let eliminados = 0;
                futbolistasData[senderNumber].futbolistas = inventarioUsuario.filter(name => {
                    if (name === nombreSimple && eliminados < cantidadAVender) {
                        eliminados++;
                        return false;
                    }
                    return true;
                });
            }

            if (futbolistasVendidos > 0) {
                await añadirMonedas(senderJid, groupJid, totalMonedasGanadas);
                guardarCambios();
                
                userDb = await global.db.getUser(senderJid, groupJid);
                const saldoFinal = obtenerMonedas(userDb).toLocaleString();

                const mensaje = 
                    `💰 *¡Venta Exitosa!* 💰\n` +
                    '━━━━━━━━━━\n\n' +
                    `Has vendido *${futbolistasVendidos} futbolistas* por *${totalMonedasGanadas.toLocaleString()} monedas*.\n` +
                    `Tu saldo total: *${saldoFinal} monedas*.\n\n` +
                    '_¡Sigue coleccionando!_ ⚽';
                    
                return await message.reply(mensaje, { mentions: [senderJid] });
            }
            
            return await message.reply('❌ *Error al procesar la venta.*');
        }

        // SUBCOMANDO: ver
        if (command.match(/^myfpj$/i) && subCommand === 'ver') {
            const nombreFutbolistaEntrada = args.slice(1).join('');
            if (!nombreFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /myfpj ver [NombreFutbolista]_');
            }

            const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);

            if (!futbolista) {
                return await message.reply(`❌ *Futbolista no reconocido.*`);
            }

            const tieneFutbolista = futbolistasData[senderNumber].futbolistas.some(fbName => fbName === futbolista.nombre);

            if (!tieneFutbolista) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(futbolista.nombre)}* en tu colección.`);
            }

            if (!global.conn) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            // Buscar imagen en Pinterest
            await message.reply('🔍 *Buscando imagen del futbolista...*');
            const imagenUrl = await buscarImagenFutbolista(futbolista.nombreFormateado, futbolista.pais);

            const caption =
                `⚽ *FUTBOLISTA EN COLECCIÓN* ⚽\n` +
                `━━━━━━━━━━\n\n` +
                `*Jugador:* ${formatoNombre(futbolista.nombre)}\n` +
                `*Selección:* ${futbolista.pais}\n` +
                `*Posición:* ${futbolista.posicion}\n` +
                `*Calidad:* ${futbolista.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(futbolista.calidad).toLocaleString()} monedas\n\n` +
                `_Este futbolista es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen desde Pinterest._', { mentions: [senderJid] });
            }

            return;
        }

        // SUBCOMANDO: reclamar / claim
        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const ultimaVez = futbolistasData[senderNumber].ultimoClaim || 0;
            const isPremiumUser = premium.isPremium(senderJid);
            const cooldown = isPremiumUser ? 30 * 60 * 1000 : 60 * 60 * 1000;
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Puedes reclamar otro futbolista en *${minutos}m ${segundos}s*`);
            }

            if (!global.conn) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const futbolistaReclamado = obtenerFutbolistaAleatorio();
            futbolistasData[senderNumber].futbolistas.push(futbolistaReclamado.nombre);
            futbolistasData[senderNumber].ultimoClaim = ahora;
            guardarCambios();

            // Buscar imagen en Pinterest
            await message.reply('🔍 *Buscando tu nuevo futbolista...*');
            const imagenUrl = await buscarImagenFutbolista(futbolistaReclamado.nombreFormateado, futbolistaReclamado.pais);

            const caption =
                `🎉 *¡Has reclamado un futbolista!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Jugador:* ${formatoNombre(futbolistaReclamado.nombre)}\n` +
                `*Selección:* ${futbolistaReclamado.pais}\n` +
                `*Posición:* ${futbolistaReclamado.posicion}\n` +
                `*Calidad:* ${futbolistaReclamado.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(futbolistaReclamado.calidad).toLocaleString()} monedas\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclama de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen desde Pinterest._', { mentions: [senderJid] });
            }
            
            return;
        }
        
        // SUBCOMANDO: regalar
        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombreFutbolistaEntrada = args.slice(2).join('');
            
            if (!mentionedJids || mentionedJids.length === 0 || !nombreFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj regalar @usuario [Nombre_Futbolista]_');
            }
            
            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);
            
            if (!futbolista) {
                return await message.reply(`❌ *Futbolista no reconocido.*`);
            }

            const indexEnInventario = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === futbolista.nombre);
            
            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(futbolista.nombre)}* para regalar.`);
            }

            if (!futbolistasData[receptorNumber]) {
                futbolistasData[receptorNumber] = { futbolistas: [], ultimoClaim: 0, jid: receptorJid };
            }

            futbolistasData[senderNumber].futbolistas.splice(indexEnInventario, 1);
            futbolistasData[receptorNumber].futbolistas.push(futbolista.nombre);
            guardarCambios();

            const nombreRegalado = formatoNombre(futbolista.nombre);

            const mensaje = 
                `🎁 *¡REGALO DE FUTBOLISTA!* 🎁\n` +
                `━━━━━━━━━━\n\n` +
                `@${senderNumber} le ha regalado su *${nombreRegalado}* (${futbolista.calidad}) de *${futbolista.pais}* a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio (proponer)
        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miFutbolistaEntrada = args[2];
            const suFutbolistaEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miFutbolistaEntrada || !suFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj intercambio @user [mi_futbolista] [su_futbolista]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            
            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No puedes intercambiar contigo mismo.*');
            }

            const miFB = buscarFutbolistaPorNombre(miFutbolistaEntrada);
            const suFB = buscarFutbolistaPorNombre(suFutbolistaEntrada);

            if (!miFB || !suFB) {
                return await message.reply('❌ *Futbolista no reconocido.*');
            }

            const indexMiFB = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === miFB.nombre);
            if (indexMiFB === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(miFB.nombre)}* para ofrecer.`);
            }

            if (!futbolistasData[receptorNumber] || !futbolistasData[receptorNumber].futbolistas.includes(suFB.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suFB.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosFutbol[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorFB: miFB.nombre,
                receptorFB: suFB.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            setTimeout(async () => {
                if (intercambiosFutbol[tradeKey]) {
                    delete intercambiosFutbol[tradeKey];
                    guardarCambios();
                    const mensajeCancelado = `⏳ *Intercambio Cancelado* ⏳\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} ha expirado.`;
                    
                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: mensajeCancelado,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _propone:_ *${formatoNombre(miFB.nombre)}* (${miFB.calidad}) de *${miFB.pais}*\n` +
                `_por el futbolista de_ *@${receptorNumber}:* *${formatoNombre(suFB.nombre)}* (${suFB.calidad}) de *${suFB.pais}*\n\n` +
                `*Para aceptar:*\n/fpj intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n/fpj intercambio rechazar @${senderNumber}\n\n` +
                `_Tienes 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio aceptar/rechazar
        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: /fpj intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;

            const propuesta = intercambiosFutbol[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosFutbol[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje = 
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* ha rechazado la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será en otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            const miFBSimple = propuesta.receptorFB;
            const suFBSimple = propuesta.emisorFB;

            const indexMiFB = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === miFBSimple);
            const indexSuFB = futbolistasData[emisorNumber].futbolistas.findIndex(fbName => fbName === suFBSimple);

            if (indexMiFB === -1) {
                return await message.reply(`❌ *ERROR: Ya no tienes a ${formatoNombre(miFBSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuFB === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suFBSimple)}*`, { mentions: [emisorJid] });
            }
            
            futbolistasData[senderNumber].futbolistas.splice(indexMiFB, 1);
            futbolistasData[emisorNumber].futbolistas.splice(indexSuFB, 1);

            futbolistasData[senderNumber].futbolistas.push(suFBSimple);
            futbolistasData[emisorNumber].futbolistas.push(miFBSimple);
            
            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* recibe: *${formatoNombre(suFBSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(miFBSimple)}*\n\n` +
                '_¡Nuevos futbolistas para ambos!_ ⚽';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        // COMANDO: /myfpj
        if (command.match(/^(myfpj)$/i)) {
            const inventario = futbolistasData[senderNumber]?.futbolistas || [];
            
            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(`⚽ *COLECCIÓN DE* @${senderNumber} ⚽\n\n_No tienes futbolistas. Usa /fpj reclamar para obtener uno._\n\n*Monedas Totales:* ${monedasActuales} 💰`, { mentions: [senderJid] });
            }

            const conteo = inventario.reduce((acc, name) => {
                acc[name] = (acc[name] || 0) + 1;
                return acc;
            }, {});

            let mensaje = `⚽ *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Futbolistas)_ ⚽\n` +
                          `*Monedas Totales:* ${monedasActuales} 💰\n` +
                          '━━━━━━━━━━\n';
            
            const futbolistasUnicos = Object.keys(conteo).sort();
            
            futbolistasUnicos.forEach(nameSimple => {
                const fbData = buscarFutbolistaPorNombre(nameSimple);
                const count = conteo[nameSimple];
                const calidad = fbData ? fbData.calidad : '???';
                const pais = fbData ? fbData.pais : '???';
                const posicion = fbData ? fbData.posicion : '???';
                const precio = fbData ? obtenerPrecioVenta(fbData.calidad).toLocaleString() : '???';
                
                mensaje += `\n*${formatoNombre(nameSimple)}* x${count}\n` +
                          `└ ${pais} • ${posicion} • ${calidad}\n` +
                          `└ Venta: ${precio} c/u`;
            });

            mensaje += '\n\n_Usa /myfpj ver [futbolista] para ver su imagen._';
            
            return await message.reply(mensaje, { mentions: [senderJid] });
        }
        
        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usa /fpj para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de futbolistas:', error.code || error.message, '\x1b[0m');
        
        let userMessage = '❌ *Error en el sistema*';
        if (error.code === 'EACCES') {
            userMessage += '\n\n_Error de permisos (EACCES). Contacta al administrador._';
        } else {
            userMessage += '\n\n_Ocurrió un error al procesar tu solicitud._';
        }
        
        return await message.reply(userMessage);
    }
};

handler.help = ['fpj', 'fpj reclamar', 'fpj claim', 'myfpj', 'myfpj ver', 'fpj regalar', 'fpj intercambio', 'fpj vender', 'fpj vender all'];
handler.tags = ['juegos'];
handler.command = /^(fpj|myfpj)$/i;

module.exports = handler;
handler.group = false