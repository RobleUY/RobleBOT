// Plugin: .login
// Genera un código de 4 dígitos que el usuario debe ingresar en la página web.

function randomCode() {
    return Math.floor(Math.random() * 10000).toString().padStart(4, '0');
}

let handler = async (message) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid || message?.from;
        if (!senderJid) return await message.reply('❌ No se pudo obtener tu número');
        const number = senderJid.split('@')[0];

        if (!global.pendingLoginCodes) global.pendingLoginCodes = new Map();

        const code = randomCode();

        const timeout = setTimeout(() => {
            try { global.pendingLoginCodes.delete(code); } catch {};
        }, 5 * 60 * 1000); // expira en 5 minutos

        global.pendingLoginCodes.set(code, { jid: number, number, timeout });

        await message.reply(`🔐 Tu código de acceso es: *${code}*
Usalo en la página web en los próximos 5 minutos.`);
    } catch (e) {
        console.error('[login-page] Error:', e);
        return await message.reply('❌ Error generando tu código. Intenta nuevamente.');
    }
};

handler.help = ['login'];
handler.tags = ['owner'];
handler.command = /^(login)$/i;
handler.group = false;

module.exports = handler;
