const fs = require('fs');
const path = require('path');

/**
 * Limpia un número de JID
 */
function cleanNumber(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0].replace(/\D/g, '');
}

/**
 * Obtiene el apodo de un usuario
 */
function getApodo(numero) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const cleanNum = cleanNumber(numero);
    const user = global.db.data.users[cleanNum] || global.db.data.users[`${cleanNum}@s.whatsapp.net`];
    if (!user || !user.apodo || user.apodo.trim() === '' || user.apodo.toLowerCase() === 'sin apodo') {
        return null;
    }
    return user.apodo.trim();
}

/**
 * Busca un usuario por apodo
 */
function findUserByApodo(apodo) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const searchApodo = apodo.toLowerCase().trim();
    
    for (const [userId, userData] of Object.entries(global.db.data.users)) {
        const userApodo = userData.apodo;
        if (userApodo && userApodo.toLowerCase().trim() === searchApodo) {
            return cleanNumber(userId);
        }
    }
    return null;
}

/**
 * Calcula el top 10 de dinero global
 */
function getTopDinero() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithMoney = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const money = userData.money || 0;
            const bank = userData.bank || 0;
            const totalMoney = money + bank;
            
            if (totalMoney > 0) {
                usersWithMoney.push({ userId: userNumber, totalMoney });
            }
        }
        
        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);
        return usersWithMoney.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopDinero:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 de comandos global
 */
function getTopComandos() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithCmds = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const totalCmds = userData.ComandosEjecutados || 0;
            if (totalCmds > 0) {
                usersWithCmds.push({ userId: userNumber, totalCmds });
            }
        }
        
        usersWithCmds.sort((a, b) => b.totalCmds - a.totalCmds);
        return usersWithCmds.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopComandos:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 clanes por dinero depositado (igual que .clan top)
 */
function getTopClanes() {
    try {
        const clanes = global.db.data.clanes || {};
        const clanesArray = [];
        
        for (const [nombre, clan] of Object.entries(clanes)) {
            const depositos = clan.depositos || {};
            let dineroTotal = 0;
            
            // Sumar todos los depósitos del clan
            for (const monto of Object.values(depositos)) {
                dineroTotal += Number(monto) || 0;
            }
            
            clanesArray.push({
                nombre,
                dinero: dineroTotal,
                miembros: clan.miembros?.length || 0,
                data: clan
            });
        }
        
        // Ordenar por dinero (igual que .clan top)
        clanesArray.sort((a, b) => b.dinero - a.dinero);
        return clanesArray.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopClanes:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 comandos personalizados por usos
 */
function getTopComandosPersonalizados() {
    try {
        const comandosPath = path.join(__dirname, '../data/comandos.json');
        if (!fs.existsSync(comandosPath)) return [];
        
        const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf-8'));
        const allComandos = [];
        
        if (comandosData.commands) {
            for (const [creatorId, creatorData] of Object.entries(comandosData.commands)) {
                if (!creatorData.comandos) continue;
                
                for (const [cmdName, cmdData] of Object.entries(creatorData.comandos)) {
                    const uniqueUsers = new Set(cmdData.usuariosUsados || []).size;
                    allComandos.push({
                        nombre: cmdName,
                        creator: cleanNumber(creatorId),
                        usos: uniqueUsers
                    });
                }
            }
        }
        
        allComandos.sort((a, b) => b.usos - a.usos);
        return allComandos.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopComandosPersonalizados:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 parejas por tiempo juntos
 */
function getTopParejas() {
    try {
        const parejas = global.db.data.parejas || {};
        const parejasArray = [];
        const seen = new Set();
        
        for (const [userId, pareja] of Object.entries(parejas)) {
            if (pareja.estado !== 'aceptado') continue;
            if (!pareja.numero || !pareja.fecha) continue;
            
            const cleanUser = cleanNumber(userId);
            const cleanPareja = cleanNumber(pareja.numero);
            
            const key = [cleanUser, cleanPareja].sort().join('-');
            if (seen.has(key)) continue;
            seen.add(key);
            
            const tiempoJuntos = Date.now() - pareja.fecha;
            parejasArray.push({
                user1: cleanUser,
                user2: cleanPareja,
                tiempo: tiempoJuntos
            });
        }
        
        parejasArray.sort((a, b) => b.tiempo - a.tiempo);
        return parejasArray.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopParejas:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 penes
 */
function getTopPenes() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithPene = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const peneSize = userData.pene || 0;
            if (peneSize > 0) {
                usersWithPene.push({ userId: userNumber, size: peneSize });
            }
        }
        
        usersWithPene.sort((a, b) => b.size - a.size);
        return usersWithPene.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopPenes:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 vaginas
 */
function getTopVaginas() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithVagina = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            
            const vaginaDepth = userData.vagina || 0;
            if (vaginaDepth > 0) {
                usersWithVagina.push({ userId: userNumber, depth: vaginaDepth });
            }
        }
        
        usersWithVagina.sort((a, b) => b.depth - a.depth);
        return usersWithVagina.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopVaginas:', error.message);
        return [];
    }
}

/**
 * Obtiene todas las medallas de un usuario
 */
function obtenerMedallas(userNumber) {
    const medallas = [];
    
    // 1. Top Dinero
    const topDinero = getTopDinero();
    const posDinero = topDinero.indexOf(userNumber) + 1;
    if (posDinero > 0) {
        let emoji = '';
        if (posDinero === 1) emoji = '🥇';
        else if (posDinero === 2) emoji = '🥈';
        else if (posDinero === 3) emoji = '🥉';
        else emoji = `${posDinero}°`;
        
        medallas.push({
            nombre: 'Top Dinero Global',
            emoji: '💰',
            posicion: posDinero,
            badge: emoji
        });
    }
    
    // 2. Top Comandos
    const topComandos = getTopComandos();
    const posComandos = topComandos.indexOf(userNumber) + 1;
    if (posComandos > 0) {
        let emoji = '';
        if (posComandos === 1) emoji = '🥇';
        else if (posComandos === 2) emoji = '🥈';
        else if (posComandos === 3) emoji = '🥉';
        else emoji = `${posComandos}°`;
        
        medallas.push({
            nombre: 'Top Comandos Global',
            emoji: '🎮',
            posicion: posComandos,
            badge: emoji
        });
    }
    
    // 3. Clan Top 10
    const topClanes = getTopClanes();
    const clanes = global.db.data.clanes || {};
    for (const [nombre, data] of Object.entries(clanes)) {
        const miembros = data.miembros || [];
        if (miembros.includes(userNumber) || miembros.includes(`${userNumber}@s.whatsapp.net`)) {
            const posClan = topClanes.findIndex(c => c.nombre === nombre) + 1;
            if (posClan > 0) {
                medallas.push({
                    nombre: `Clan Top ${posClan}`,
                    emoji: '⚔️',
                    posicion: posClan,
                    badge: `[${nombre}]`
                });
                break;
            }
        }
    }
    
    // 4. Comando Personalizado Top 10
    const topCmdsPersonalizados = getTopComandosPersonalizados();
    const cmdEnTop = topCmdsPersonalizados.find(cmd => cmd.creator === userNumber);
    if (cmdEnTop) {
        const posCmd = topCmdsPersonalizados.indexOf(cmdEnTop) + 1;
        medallas.push({
            nombre: `Comando Top ${posCmd}`,
            emoji: '✨',
            posicion: posCmd,
            badge: `.${cmdEnTop.nombre}`
        });
    }
    
    // 5. Pareja Top 10
    const topParejas = getTopParejas();
    const parejaEnTop = topParejas.find(p => p.user1 === userNumber || p.user2 === userNumber);
    if (parejaEnTop) {
        const posPareja = topParejas.indexOf(parejaEnTop) + 1;
        medallas.push({
            nombre: `Pareja Top ${posPareja}`,
            emoji: '💕',
            posicion: posPareja,
            badge: `${posPareja}°`
        });
    }
    
    // 6. Top Penes
    const topPenes = getTopPenes();
    const posPene = topPenes.indexOf(userNumber) + 1;
    if (posPene > 0) {
        let emoji = '';
        if (posPene === 1) emoji = '🥇';
        else if (posPene === 2) emoji = '🥈';
        else if (posPene === 3) emoji = '🥉';
        else emoji = `${posPene}°`;
        
        medallas.push({
            nombre: 'Top Pene',
            emoji: '🍆',
            posicion: posPene,
            badge: emoji
        });
    }
    
    // 7. Top Vaginas
    const topVaginas = getTopVaginas();
    const posVagina = topVaginas.indexOf(userNumber) + 1;
    if (posVagina > 0) {
        let emoji = '';
        if (posVagina === 1) emoji = '🥇';
        else if (posVagina === 2) emoji = '🥈';
        else if (posVagina === 3) emoji = '🥉';
        else emoji = `${posVagina}°`;
        
        medallas.push({
            nombre: 'Top Vagina',
            emoji: '🌸',
            posicion: posVagina,
            badge: emoji
        });
    }
    
    return medallas;
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const senderNumber = cleanNumber(message.sender);
    
    let targetNumber = null;
    let targetApodo = null;
    
    // Caso 1: Sin argumentos - ver medallas propias
    if (!text || text.trim() === '') {
        targetNumber = senderNumber;
        targetApodo = getApodo(senderNumber) || 'Tú';
    }
    // Caso 2: Mencionó a alguien
    else if (message.mentions && message.mentions.length > 0) {
        targetNumber = cleanNumber(message.mentions[0]);
        targetApodo = getApodo(targetNumber);
        
        if (!targetApodo) {
            return await message.reply('❌ Ese usuario no tiene un apodo configurado.');
        }
    }
    // Caso 3: Pasó un apodo
    else {
        const apodoSearch = text.trim();
        targetNumber = findUserByApodo(apodoSearch);
        
        if (!targetNumber) {
            // Intentar como número directo
            const cleanNum = cleanNumber(apodoSearch);
            if (cleanNum && cleanNum.length > 5) {
                targetNumber = cleanNum;
            }
        }
        
        if (!targetNumber) {
            return await message.reply('❌ No se encontró ese usuario. Verifica el apodo o menciónalo.');
        }
        
        targetApodo = getApodo(targetNumber);
        if (!targetApodo) {
            targetApodo = 'Usuario';
        }
    }
    
    // Obtener medallas
    const medallas = obtenerMedallas(targetNumber);
    
    const esPropioUsuario = targetNumber === senderNumber;
    
    if (medallas.length === 0) {
        return await message.reply(
            esPropioUsuario
                ? '🏅 *TUS MEDALLAS*\n\nAún no tienes medallas.\n\n_Las medallas se obtienen al estar en el top 10 de diferentes categorías._'
                : `🏅 *MEDALLAS DE ${targetApodo.toUpperCase()}*\n\nEste usuario aún no tiene medallas.`
        );
    }
    
    // Construir mensaje
    let mensaje = `🏅 *${esPropioUsuario ? 'TUS MEDALLAS' : `MEDALLAS DE ${targetApodo.toUpperCase()}`}*\n\n`;
    mensaje += `👤 Usuario: *${targetApodo}*\n`;
    mensaje += `🎖️ Total de medallas: *${medallas.length}*\n\n`;
    
    medallas.forEach((medalla, index) => {
        mensaje += `${index + 1}. ${medalla.emoji} *${medalla.nombre}*\n`;
        mensaje += `   ${medalla.badge}\n\n`;
    });
    
    mensaje += `_Las medallas se actualizan en tiempo real según los rankings._`;
    
    await message.reply(mensaje);
};

handler.help = ['medallas', 'medallas @usuario', 'medallas apodo'];
handler.tags = ['info'];
handler.command = /^(medallas|medals|insignias)$/i;
handler.group = false;

module.exports = handler;
