const fs = require('fs');
const path = require('path');

/**
 * Limpia un número de JID
 */
function cleanNumber(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0].replace(/\D/g, '');
}

/**
 * Obtiene el apodo de un usuario
 */
function getApodo(numero) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const cleanNum = cleanNumber(numero);
    const user = global.db.data.users[cleanNum] || global.db.data.users[`${cleanNum}@s.whatsapp.net`];
    if (!user || !user.apodo || user.apodo.trim() === '' || user.apodo.toLowerCase() === 'sin apodo') {
        return null;
    }
    return user.apodo.trim();
}

/**
 * Busca un usuario por apodo
 */
function findUserByApodo(apodo) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const searchApodo = apodo.toLowerCase().trim();
    
    for (const [userId, userData] of Object.entries(global.db.data.users)) {
        const userApodo = userData.apodo;
        if (userApodo && userApodo.toLowerCase().trim() === searchApodo) {
            return cleanNumber(userId);
        }
    }
    return null;
}

/**
 * Calcula el top 10 de dinero global
 */
function getTopDinero() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithMoney = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const money = Number(userData.money) || 0;
            const bank = Number(userData.bank) || 0;
            const totalMoney = money + bank;
            
            if (totalMoney > 0) {
                usersWithMoney.push({ userId: userNumber, totalMoney });
            }
        }
        
        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);
        return usersWithMoney.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopDinero:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 de comandos global
 */
function getTopComandos() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithCmds = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const totalCmds = Number(userData.ComandosEjecutados) || 0;
            if (totalCmds > 0) {
                usersWithCmds.push({ userId: userNumber, totalCmds });
            }
        }
        
        usersWithCmds.sort((a, b) => b.totalCmds - a.totalCmds);
        return usersWithCmds.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopComandos:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 clanes por dinero depositado (igual que .clan top)
 */
function getTopClanes() {
    try {
        const clanes = global.db.data.clanes || {};
        const clanesArray = [];
        
        for (const [nombre, clan] of Object.entries(clanes)) {
            const depositos = clan.depositos || {};
            let dineroTotal = 0;
            
            for (const monto of Object.values(depositos)) {
                dineroTotal += Number(monto) || 0;
            }
            
            clanesArray.push({
                nombre,
                dinero: dineroTotal,
                miembros: (clan.miembros || []).map(m => cleanNumber(m)),
                data: clan
            });
        }
        
        clanesArray.sort((a, b) => b.dinero - a.dinero);
        return clanesArray.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopClanes:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 comandos personalizados por usos
 */
function getTopComandosPersonalizados() {
    try {
        const comandosPath = path.join(__dirname, '../data/comandos.json');
        if (!fs.existsSync(comandosPath)) return [];
        
        const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf-8'));
        const allComandos = [];
        
        if (comandosData.commands) {
            for (const [creatorId, creatorData] of Object.entries(comandosData.commands)) {
                if (!creatorData.comandos) continue;
                
                const cleanCreator = cleanNumber(creatorId);
                const canonicalCreator = global.db?.getCanonicalId ? global.db.getCanonicalId(cleanCreator) : cleanCreator;

                for (const [cmdName, cmdData] of Object.entries(creatorData.comandos)) {
                    const uniqueUsers = new Set(cmdData.usuariosUsados || []).size;
                    allComandos.push({
                        nombre: cmdName,
                        creator: canonicalCreator,
                        usos: uniqueUsers
                    });
                }
            }
        }
        
        allComandos.sort((a, b) => b.usos - a.usos);
        return allComandos.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopComandosPersonalizados:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 parejas por tiempo juntos
 */
function getTopParejas() {
    try {
        const parejas = global.db.data.parejas || {};
        const parejasArray = [];
        const seen = new Set();
        
        for (const [userId, pareja] of Object.entries(parejas)) {
            if (!pareja || pareja.estado !== 'aceptado') continue;
            if (!pareja.numero || !pareja.fecha) continue;
            
            const cleanUser = cleanNumber(userId);
            const cleanPareja = cleanNumber(pareja.numero);
            
            const canon1 = global.db?.getCanonicalId ? global.db.getCanonicalId(cleanUser) : cleanUser;
            const canon2 = global.db?.getCanonicalId ? global.db.getCanonicalId(cleanPareja) : cleanPareja;
            
            const key = [canon1, canon2].sort().join('-');
            if (seen.has(key)) continue;
            seen.add(key);
            
            let fechaMs = 0;
            if (typeof pareja.fecha === 'number') {
                fechaMs = pareja.fecha;
            } else if (pareja.fecha) {
                fechaMs = new Date(pareja.fecha).getTime();
            }
            if (isNaN(fechaMs) || fechaMs <= 0) continue;

            const tiempoJuntos = Date.now() - fechaMs;
            parejasArray.push({
                user1: canon1,
                user2: canon2,
                tiempo: tiempoJuntos
            });
        }
        
        parejasArray.sort((a, b) => b.tiempo - a.tiempo);
        return parejasArray.slice(0, 10);
    } catch (error) {
        console.error('[Medallas] Error en getTopParejas:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 penes
 */
function getTopPenes() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithPene = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const peneSize = Number(userData.pene) || 0;
            if (peneSize > 0) {
                usersWithPene.push({ userId: userNumber, size: peneSize });
            }
        }
        
        usersWithPene.sort((a, b) => b.size - a.size);
        return usersWithPene.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopPenes:', error.message);
        return [];
    }
}

/**
 * Calcula el top 10 vaginas
 */
function getTopVaginas() {
    try {
        const uniqueUsers = global.db.getUniqueUsers();
        const usersWithVagina = [];
        
        for (const [userNumber, userData] of uniqueUsers.entries()) {
            const vaginaDepth = Number(userData.vagina) || 0;
            if (vaginaDepth > 0) {
                usersWithVagina.push({ userId: userNumber, depth: vaginaDepth });
            }
        }
        
        usersWithVagina.sort((a, b) => b.depth - a.depth);
        return usersWithVagina.slice(0, 10).map(u => u.userId);
    } catch (error) {
        console.error('[Medallas] Error en getTopVaginas:', error.message);
        return [];
    }
}

/**
 * Obtiene todas las medallas de un usuario
 */
function obtenerMedallas(userNumber) {
    const cleanNum = cleanNumber(userNumber);
    const canonicalNum = global.db?.getCanonicalId ? global.db.getCanonicalId(cleanNum) : cleanNum;
    const targetIds = new Set([cleanNum, canonicalNum]);

    const medallas = [];
    
    // 1. Top Dinero
    const topDinero = getTopDinero();
    const posDinero = topDinero.findIndex(id => targetIds.has(id)) + 1;
    if (posDinero > 0) {
        let emoji = posDinero === 1 ? '🥇' : posDinero === 2 ? '🥈' : posDinero === 3 ? '🥉' : `${posDinero}°`;
        medallas.push({
            nombre: 'Top Dinero Global',
            emoji: '💰',
            posicion: posDinero,
            badge: emoji
        });
    }
    
    // 2. Top Comandos
    const topComandos = getTopComandos();
    const posComandos = topComandos.findIndex(id => targetIds.has(id)) + 1;
    if (posComandos > 0) {
        let emoji = posComandos === 1 ? '🥇' : posComandos === 2 ? '🥈' : posComandos === 3 ? '🥉' : `${posComandos}°`;
        medallas.push({
            nombre: 'Top Comandos Global',
            emoji: '🎮',
            posicion: posComandos,
            badge: emoji
        });
    }
    
    // 3. Clan Top 10
    const topClanes = getTopClanes();
    const clanes = global.db.data.clanes || {};
    for (const [nombre, data] of Object.entries(clanes)) {
        const miembros = (data.miembros || []).map(m => cleanNumber(m));
        if (miembros.some(m => targetIds.has(m) || targetIds.has(global.db?.getCanonicalId?.(m)))) {
            const posClan = topClanes.findIndex(c => c.nombre.toLowerCase() === nombre.toLowerCase()) + 1;
            if (posClan > 0) {
                medallas.push({
                    nombre: `Clan Top ${posClan}`,
                    emoji: '⚔️',
                    posicion: posClan,
                    badge: `[${nombre}]`
                });
                break;
            }
        }
    }
    
    // 4. Comando Personalizado Top 10
    const topCmdsPersonalizados = getTopComandosPersonalizados();
    const cmdEnTop = topCmdsPersonalizados.find(cmd => targetIds.has(cmd.creator));
    if (cmdEnTop) {
        const posCmd = topCmdsPersonalizados.indexOf(cmdEnTop) + 1;
        medallas.push({
            nombre: `Comando Top ${posCmd}`,
            emoji: '✨',
            posicion: posCmd,
            badge: `.${cmdEnTop.nombre}`
        });
    }
    
    // 5. Pareja Top 10
    const topParejas = getTopParejas();
    const parejaEnTop = topParejas.find(p => targetIds.has(p.user1) || targetIds.has(p.user2));
    if (parejaEnTop) {
        const posPareja = topParejas.indexOf(parejaEnTop) + 1;
        medallas.push({
            nombre: `Pareja Top ${posPareja}`,
            emoji: '💕',
            posicion: posPareja,
            badge: `${posPareja}°`
        });
    }
    
    // 6. Top Penes
    const topPenes = getTopPenes();
    const posPene = topPenes.findIndex(id => targetIds.has(id)) + 1;
    if (posPene > 0) {
        let emoji = posPene === 1 ? '🥇' : posPene === 2 ? '🥈' : posPene === 3 ? '🥉' : `${posPene}°`;
        medallas.push({
            nombre: 'Top Pene',
            emoji: '🍆',
            posicion: posPene,
            badge: emoji
        });
    }
    
    // 7. Top Vaginas
    const topVaginas = getTopVaginas();
    const posVagina = topVaginas.findIndex(id => targetIds.has(id)) + 1;
    if (posVagina > 0) {
        let emoji = posVagina === 1 ? '🥇' : posVagina === 2 ? '🥈' : posVagina === 3 ? '🥉' : `${posVagina}°`;
        medallas.push({
            nombre: 'Top Vagina',
            emoji: '🌸',
            posicion: posVagina,
            badge: emoji
        });
    }
    
    return medallas;
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const senderNumber = cleanNumber(message.sender);
    
    let targetNumber = null;
    let targetApodo = null;
    
    // Caso 1: Sin argumentos - ver medallas propias
    if (!text || text.trim() === '') {
        targetNumber = senderNumber;
        targetApodo = getApodo(senderNumber) || 'Tú';
    }
    // Caso 2: Mencionó a alguien
    else if (message.mentions && message.mentions.length > 0) {
        targetNumber = cleanNumber(message.mentions[0]);
        targetApodo = getApodo(targetNumber);
        
        if (!targetApodo) {
            return await message.reply('❌ Ese usuario no tiene un apodo configurado.');
        }
    }
    // Caso 3: Pasó un apodo
    else {
        const apodoSearch = text.trim();
        targetNumber = findUserByApodo(apodoSearch);
        
        if (!targetNumber) {
            // Intentar como número directo
            const cleanNum = cleanNumber(apodoSearch);
            if (cleanNum && cleanNum.length > 5) {
                targetNumber = cleanNum;
            }
        }
        
        if (!targetNumber) {
            return await message.reply('❌ No se encontró ese usuario. Verifica el apodo o menciónalo.');
        }
        
        targetApodo = getApodo(targetNumber);
        if (!targetApodo) {
            targetApodo = 'Usuario';
        }
    }
    
    // Obtener medallas
    const medallas = obtenerMedallas(targetNumber);
    
    const esPropioUsuario = targetNumber === senderNumber;
    
    if (medallas.length === 0) {
        return await message.reply(
            esPropioUsuario
                ? '🏅 *TUS MEDALLAS*\n\nAún no tienes medallas.\n\n_Las medallas se obtienen al estar en el top 10 de diferentes categorías._'
                : `🏅 *MEDALLAS DE ${targetApodo.toUpperCase()}*\n\nEste usuario aún no tiene medallas.`
        );
    }
    
    // Construir mensaje
    let mensaje = `🏅 *${esPropioUsuario ? 'TUS MEDALLAS' : `MEDALLAS DE ${targetApodo.toUpperCase()}`}*\n\n`;
    mensaje += `👤 Usuario: *${targetApodo}*\n`;
    mensaje += `🎖️ Total de medallas: *${medallas.length}*\n\n`;
    
    medallas.forEach((medalla, index) => {
        mensaje += `${index + 1}. ${medalla.emoji} *${medalla.nombre}*\n`;
        mensaje += `   ${medalla.badge}\n\n`;
    });
    
    mensaje += `_Las medallas se actualizan en tiempo real según los rankings._`;
    
    await message.reply(mensaje);
};

handler.help = ['medallas', 'medallas @usuario', 'medallas apodo'];
handler.tags = ['info'];
handler.command = /^(medallas|medals|insignias)$/i;
handler.group = false;

module.exports = handler;
module.exports.obtenerMedallas = obtenerMedallas;
