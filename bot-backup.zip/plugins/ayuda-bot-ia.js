const fs = require('fs');
const path = require('path');
const axios = require('axios');

// 🧠 Memoria temporal por usuario
if (!global.chatMemory) global.chatMemory = new Map();

const baseContext = `
Eres el asistente oficial de *RobleBOT*, un bot de WhatsApp multifuncional desarrollado por *RobleUY* (creador uruguayo).

🔧 INFORMACIÓN DEL BOT:
- Nombre: RobleBOT
- Versión: 2.1
- Desarrollador: RobleUY
- Contacto del creador: wa.me/+59893900470
- Instagram: @robleuy
- Canal oficial: https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q

si te consultan por ejemplo como ganar dinero no les digas que usen el comando #ayuda como ganar dinero
directamente revisa el emnu.txt y y responde con las formas de ganar dinero y asi mismo con cualquier otra consulta.

en tus mensajes formatea bien los mensajes, no respondas con dobles * es decir en vez de **hola** usa: hola*
`;

// 🧩 Leer menú y extraer datos dinámicos
function getMenuContext() {
  try {
    const menuPath = path.join(__dirname, '..', 'menu.txt');
    if (!fs.existsSync(menuPath)) return baseContext;

    const menuContent = fs.readFileSync(menuPath, 'utf8').slice(0, 15000);

    // Extraer estadísticas dinámicas
    const stats = {
      ultima: (menuContent.match(/Última actualización::?\s*(.*)/i) || [])[1] || 'Desconocida',
      grupos: (menuContent.match(/Grupos Totales:\*?\s*(\d+)/i) || [])[1] || 'N/D',
      usuarios: (menuContent.match(/Usuarios Activos:\*?\s*(\d+)/i) || [])[1] || 'N/D',
    };

    const dynamicStats = `
📊 ESTADÍSTICAS ACTUALES DEL BOT
⏰ Última actualización: ${stats.ultima}
🌐 Grupos totales: ${stats.grupos}
👥 Usuarios activos: ${stats.usuarios}
`;

    return `${baseContext}\n\n${dynamicStats}\n\n📄 Fragmento del menú actual:\n${menuContent}`;
  } catch (err) {
    console.error('[AYUDA] No se pudo leer o procesar menu.txt:', err.message);
    return baseContext;
  }
}

// 🔑 Sistema de claves API
const apiKeys = [
  { key: "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE", uses: 0, lastUsed: 0, failures: 0, blocked: false },
  { key: "AIzaSyAqad2qjoPDpNWFQg20_3tMpt8CL_Pqw_A", uses: 0, lastUsed: 0, failures: 0, blocked: false },
  { key: "AIzaSyBkHDP5FNjQKuhR-aCbmVkj9Mc7_tHuK3A", uses: 0, lastUsed: 0, failures: 0, blocked: false },
  { key: "AIzaSyAfeiA7ww0eiY-8ukElr7iAahue7BMwaw0", uses: 0, lastUsed: 0, failures: 0, blocked: false }
];

function getBestKey() {
  const now = Date.now();
  const available = apiKeys
    .filter(k => !k.blocked && now - k.lastUsed > 500)
    .sort((a, b) => a.uses - b.uses || a.failures - b.failures || a.lastUsed - b.lastUsed);
  return available[0] || null;
}
function markSuccess(k) { k.uses++; k.lastUsed = Date.now(); k.failures = Math.max(0, k.failures - 1); }
function markFailure(k) { k.failures++; k.lastUsed = Date.now(); if (k.failures >= 3) k.blocked = true; }

// 🚀 Comando principal: /ayuda
let handler = async (message, { text, conn }) => {
  try {
    const sender = message.sender || message.author;
    const userId = sender?.split('@')[0] || 'anon';

    if (!text) {
      return await message.reply(
        '❓ *AYUDA DE ROBLEBOT*\n\n' +
        '_Pregúntame lo que necesites sobre el bot._\n\n' +
        'Ejemplos:\n' +
        '• /ayuda como ganar dinero\n' +
        '• /ayuda sistema de parejas\n' +
        '• /ayuda comandos admin\n\n' +
        '💡 También podés usar `/menu` para ver todos los comandos.'
      );
    }

    await message.reply('🤖 _Consultando..._');

    const keyObj = getBestKey();
    if (!keyObj) return await message.reply('⚠️ Todas las claves están en uso. Esperá unos segundos e intentá de nuevo.');

    // 🔄 Leer el menú actualizado en cada ejecución
    const dynamicContext = getMenuContext();

    // 📚 Obtener historial de usuario
    const history = global.chatMemory.get(userId) || [];
    const shortHistory = history.slice(-5).map(h => `${h.role}: ${h.text}`).join('\n');

    const fullPrompt = `${dynamicContext}\n\n📜 HISTORIAL RECIENTE:\n${shortHistory}\n\n🧍 Usuario: ${text}`;

    const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    const response = await axios.post(`${API_URL}?key=${keyObj.key}`, {
      contents: [{ parts: [{ text: fullPrompt }] }],
      generationConfig: { temperature: 0.7, topK: 40, topP: 0.9, maxOutputTokens: 512 }
    }, {
      headers: { "Content-Type": "application/json" },
      timeout: 20000
    });

    markSuccess(keyObj);

    const aiResponse = response.data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '🤔 No encontré información sobre eso.';
    const cleanResponse = aiResponse.replace(/\[EJECUTAR:.*?\]/g, '').trim();

    if (/menu|comandos|lista/i.test(text))
      return await message.reply('📜 Para ver todos los comandos, usá el comando `/menu`.');

    await message.reply(`🤖 *ASISTENTE ROBLEBOT*\n\n${cleanResponse}`);

    // 🧠 Guardar memoria temporal
    history.push({ role: 'usuario', text });
    history.push({ role: 'bot', text: cleanResponse });
    if (history.length > 10) history.splice(0, history.length - 10);
    global.chatMemory.set(userId, history);

  } catch (error) {
    console.error('[AYUDA] Error:', error.response?.data || error.message);
    const keyObj = getBestKey();
    if (keyObj) markFailure(keyObj);

    return await message.reply(
      '❌ *Error al procesar tu consulta*\n\n' +
      '_Intentalo de nuevo o usá `/menu` para ver los comandos disponibles._'
    );
  }
};

handler.help = ['ayuda <texto>', 'help <texto>'];
handler.tags = ['info'];
handler.command = /^(ayuda|help)$/i;

module.exports = handler;
