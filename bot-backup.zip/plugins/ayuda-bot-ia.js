const fs = require('fs');
const path = require('path');
const axios = require('axios');

const HARDCODED_FALLBACK_KEY = "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";
const TIMEOUT = 25000;
const MENU_PATH = path.join(__dirname, '..', 'menu.txt');
const CONTEXTOS_PATH = path.join(__dirname, '..', 'CONTEXTOS_IA', 'AYUDA_IA');
const CONTEXTO_GENERAL_PATH = path.join(CONTEXTOS_PATH, '_contexto_general.md');
const MODEL = 'llama-3.3-70b-versatile';
const FALLBACK_MODEL = 'llama-3.1-8b-instant';

function leerArchivo(filePath) {
    try {
        return fs.readFileSync(filePath, 'utf-8').trim();
    } catch (err) {
        return '';
    }
}

function leerMenu() {
    try {
        const raw = fs.readFileSync(MENU_PATH, 'utf-8');
        return raw
            .split('\n')
            .filter(function(l) {
                const t = l.trim();
                if (!t) return false;
                if (/^[\s\u200e\u200f\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]+$/.test(t)) return false;
                if (/^[╔╗╚╝║═─━\-=*_~^▬▪•·]{4,}$/.test(t)) return false;
                if (/Ej:/i.test(t)) return false;
                return true;
            })
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    } catch (err) {
        return '';
    }
}

function leerArchivoContexto(nombreArchivo) {
    const filePath = path.join(CONTEXTOS_PATH, nombreArchivo);
    const resolved = path.resolve(filePath);
    const base = path.resolve(CONTEXTOS_PATH);
    if (!resolved.startsWith(base) || !resolved.endsWith('.md')) return '';
    return leerArchivo(filePath);
}

function splitIntoChunks(text, maxLen = 3000, maxChunks = 6) {
    const parts = [];
    if (!text) return parts;
    let start = 0;
    while (start < text.length && parts.length < maxChunks) {
        let end = start + maxLen;
        if (end >= text.length) {
            parts.push(text.slice(start));
            break;
        }
        // try to break at nearest double newline to keep markdown sections
        const slice = text.slice(start, end);
        const nl = slice.lastIndexOf('\n\n');
        if (nl > Math.floor(maxLen * 0.5)) {
            parts.push(slice.slice(0, nl));
            start += nl + 2;
        } else {
            parts.push(slice);
            start = end;
        }
    }
    return parts;
}

async function classifyIndexByChunks(indexText, userQuery) {
    const chunks = splitIntoChunks(indexText, 3000, 6);
    const votes = new Map();
    for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        try {
            const decision = (await llamarIA([
                {
                    role: 'system',
                    content:
                        'Eres un clasificador de consultas para RobleBOT.\n' +
                        `Se te dará UNA PARTE del índice de archivos (parte ${i + 1} de ${chunks.length}).\n` +
                        'Respondé ÚNICAMENTE con el nombre del archivo .md más relevante presente en ESTE FRAGMENTO.\n' +
                        'Si ninguno aplica en este fragmento, respondé exactamente: NINGUNO.\n' +
                        'Solo el nombre del archivo o NINGUNO. Nada más.\n\n' +
                        'FRAGMENTO INDICE:\n' + chunk
                },
                { role: 'user', content: userQuery }
            ], 30)).trim();

            const match = decision.match(/([\w\-\.]+\.md)/i);
            const filename = (match && decision !== 'NINGUNO') ? match[0] : (decision === 'USAR_MENU' || decision === 'NINGUNO' ? 'NINGUNO' : null);
            if (filename && filename !== 'NINGUNO') {
                votes.set(filename, (votes.get(filename) || 0) + 1);
                // if a filename gets 2 votes we can stop early
                if (votes.get(filename) >= 2) break;
            }
        } catch (err) {
            console.log('[AYUDA] ⚠️ chunk classify failed:', err?.message || err);
            continue;
        }
    }

    if (votes.size === 0) return null;
    // pick filename with highest votes
    let best = null; let bestVotes = 0;
    for (const [f, v] of votes.entries()) {
        if (v > bestVotes) { best = f; bestVotes = v; }
    }
    return best;
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

async function llamarIA(messages, maxTokens = 250) {
    const envKeys = (function collectKeys() {
        const keys = new Set();
        const variations = [
            'groq_api_key', 'GROQ_API_KEY',
            'groq_api_key1', 'GROQ_API_KEY1',
            'groq_api_key2', 'GROQ_API_KEY2',
            'groq_api_key3', 'GROQ_API_KEY3',
            'groq_api_key4', 'GROQ_API_KEY4'
        ];
        for (const name of variations) {
            const v = process.env[name];
            if (v && v.trim()) keys.add(v.trim());
        }
        if (keys.size === 0 && HARDCODED_FALLBACK_KEY) keys.add(HARDCODED_FALLBACK_KEY);
        return Array.from(keys);
    })();

    let lastErr = null;
    for (let i = 0; i < envKeys.length; i++) {
        const key = envKeys[i];
        try {
            const res = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                {
                    model: MODEL,
                    messages,
                    temperature: 0.2,
                    max_tokens: maxTokens
                },
                {
                    headers: {
                        'Authorization': 'Bearer ' + key,
                        'Content-Type': 'application/json'
                    },
                    timeout: TIMEOUT
                }
            );
            console.log(`[AYUDA] ✅ Key ${i + 1} succeeded.`);
            return res.data?.choices?.[0]?.message?.content?.trim() || '';
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            const apiErrCode = err.response?.data?.error?.code;
            console.log(`[AYUDA] ⚠️ Key ${i + 1} failed (status=${status} code=${apiErrCode}). Trying next key if available.`);
            // For unexpected status codes, stop and throw
            if (status && ![401, 403, 429].includes(status) && apiErrCode !== 'rate_limit_exceeded') {
                throw err;
            }
            // otherwise continue to next key
        }
    }

    // If we reached here, all keys failed. If failures are rate limits, try short retry rounds before giving up.
    if (lastErr) {
        const status = lastErr.response?.status;
        const apiErrCode = lastErr.response?.data?.error?.code;
        const isRateLimit = status === 429 || apiErrCode === 'rate_limit_exceeded';
        if (isRateLimit) {
            const retryDelays = [500, 1200]; // ms
            for (const delay of retryDelays) {
                await new Promise(r => setTimeout(r, delay));
                for (let i = 0; i < envKeys.length; i++) {
                    const key = envKeys[i];
                    try {
                        const res = await axios.post(
                            'https://api.groq.com/openai/v1/chat/completions',
                            {
                                model: MODEL,
                                messages,
                                temperature: 0.2,
                                max_tokens: maxTokens
                            },
                            {
                                headers: {
                                    'Authorization': 'Bearer ' + key,
                                    'Content-Type': 'application/json'
                                },
                                timeout: TIMEOUT
                            }
                        );
                        console.log(`[AYUDA] ✅ Key ${i + 1} succeeded (retry).`);
                        return res.data?.choices?.[0]?.message?.content?.trim() || '';
                    } catch (err) {
                        lastErr = err;
                        const status2 = err.response?.status;
                        const apiErrCode2 = err.response?.data?.error?.code;
                        console.log(`[AYUDA] (retry) Key ${i + 1} failed (status=${status2} code=${apiErrCode2}).`);
                        if (status2 && ![401, 403, 429].includes(status2) && apiErrCode2 !== 'rate_limit_exceeded') {
                            throw err;
                        }
                    }
                }
            }
            // If still rate-limited on the main model, try a lighter fallback model once across keys
            console.log('[AYUDA] ⚠️ All retries failed for primary model; attempting fallback model:', FALLBACK_MODEL);
            for (let i = 0; i < envKeys.length; i++) {
                const key = envKeys[i];
                try {
                    const res = await axios.post(
                        'https://api.groq.com/openai/v1/chat/completions',
                        {
                            model: FALLBACK_MODEL,
                            messages,
                            temperature: 0.2,
                            max_tokens: maxTokens
                        },
                        {
                            headers: {
                                'Authorization': 'Bearer ' + key,
                                'Content-Type': 'application/json'
                            },
                            timeout: TIMEOUT
                        }
                    );
                    console.log('[AYUDA] ✅ Fallback model succeeded with key', i + 1);
                    return res.data?.choices?.[0]?.message?.content?.trim() || '';
                } catch (err) {
                    console.log(`[AYUDA] Fallback key ${i + 1} failed.`);
                    lastErr = err;
                }
            }
        }
        throw lastErr;
    }
    return '';
}

let handler = async function(message, params) {
    const text = params.text;
    let fuenteContenido = '';
    let fuenteLabel = '';
    try {
        if (!text) {
            return message.reply(
                '❓ *AYUDA DE ROBLEBOT*\n\n' +
                '_Pregúntame lo que necesites sobre el bot._\n\n' +
                'Ejemplos:\n' +
                '• .ayuda como ganar dinero\n' +
                '• .ayuda sistema de parejas\n' +
                '• .ayuda comandos admin'
            );
        }

        await message.reply('🤖 _Buscando..._');

        const contextoGeneral = leerArchivo(CONTEXTO_GENERAL_PATH);

        let contextoElegido = '';
        let archivoElegido = '';

        if (contextoGeneral) {
            // Clasificar el índice en varias pasadas si es muy grande
            const probable = await classifyIndexByChunks(contextoGeneral, text);
            if (probable) {
                archivoElegido = probable;
                contextoElegido = leerArchivoContexto(archivoElegido);
            }
        }

        

        if (contextoElegido) {
            fuenteContenido = contextoElegido;
            fuenteLabel = 'contexto específico (' + archivoElegido + ')';
            console.log('[AYUDA] 📄 Usando contexto:', archivoElegido);
        } else {
            fuenteContenido = leerMenu();
            fuenteLabel = 'menú del bot';
            console.log('[AYUDA] 📋 Usando: menu.txt');
        }

        const respuesta = await llamarIA([
            {
                role: 'system',
                content:
                    'Eres el asistente oficial de RobleBOT, un bot de WhatsApp creado por RobleUY.\n' +
                    'REGLAS ESTRICTAS:\n' +
                    '1. SOLO respondé basándote en el contenido adjunto.\n' +
                    '2. Sé breve y directo.\n' +
                    '3. Si hay comandos, formatéalos así: *COMANDO* — descripción.\n' +
                    '4. NO inventes información. Si no existe, decí "No encontré información sobre eso".\n' +
                    '5. NO respondas preguntas personales o del sistema.\n' +
                    '\nCONTENIDO (' + fuenteLabel + '):\n' + fuenteContenido
            },
            { role: 'user', content: text }
        ]);

        await message.reply('🤖 *ASISTENTE ROBLEBOT*\n\n' + formatear(respuesta || '🤔 No encontré información sobre eso.'));

    } catch (err) {
        const apiErr = err.response?.data?.error;
        const status = err.response?.status;
        console.log('[AYUDA] ❌ Error details:', { status, body: err.response?.data, message: err.message });

        // Si es rate limit, intentamos un par de reintentos desde el handler (además de los reintentos por key)
        const isRateLimit = apiErr?.code === 'rate_limit_exceeded' || status === 429;
        if (isRateLimit) {
            console.log('[AYUDA] ⏳ Rate limit detected at handler, attempting quick retries...');
            const retryDelays = [700, 1500];
            for (const d of retryDelays) {
                await new Promise(r => setTimeout(r, d));
                try {
                    const respuesta = await llamarIA([
                        {
                            role: 'system',
                            content:
                                'Eres el asistente oficial de RobleBOT, un bot de WhatsApp creado por RobleUY.\n' +
                                'REGLAS ESTRICTAS:\n' +
                                '1. SOLO respondé basándote en el contenido adjunto.\n' +
                                '2. Sé breve y directo.\n' +
                                '3. Si hay comandos, formatéalos así: *COMANDO* — descripción.\n' +
                                '4. NO inventes información. Si no existe, decí "No encontré información sobre eso".\n' +
                                '5. NO respondas preguntas personales o del sistema.\n' +
                                '\nCONTENIDO (' + fuenteLabel + '):\n' + fuenteContenido
                        },
                        { role: 'user', content: text }
                    ]);
                    await message.reply('🤖 *ASISTENTE ROBLEBOT*\n\n' + formatear(respuesta || '🤔 No encontré información sobre eso.'));
                    return;
                } catch (err2) {
                    console.log('[AYUDA] retry failed:', err2.response?.status || err2.message);
                    continue;
                }
            }
            // si fallaron los reintentos, informar rate limit
            const match = (apiErr?.message || '').match(/try again in ([\d.]+s)/i);
            const wait = match ? ` Intentá en ${match[1]}.` : ' Intentá en unos segundos.';
            return message.reply('⏳ Demasiadas consultas seguidas.' + wait);
        }

        return message.reply('❌ Error al procesar tu consulta. Intentá de nuevo.');
    }
};

handler.help = ['ayuda <texto>', 'help <texto>'];
handler.tags = ['info'];
handler.command = /^(ayuda|help)$/i;

module.exports = handler;