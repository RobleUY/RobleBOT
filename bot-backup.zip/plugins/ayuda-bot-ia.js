const fs = require('fs');
const path = require('path');
const axios = require('axios');

const API_KEY = "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";
const TIMEOUT = 20000;
const MENU_PATH = path.join(__dirname, '..', 'menu.txt');

function leerMenu() {
    try {
        const raw = fs.readFileSync(MENU_PATH, 'utf-8');
        return raw
            .split('\n')
            .filter(function(l) {
                const t = l.trim();
                if (!t) return false;
                if (/^[\s\u200e\u200f\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]+$/.test(t)) return false;
                if (/^[╔╗╚╝║═─━\-=*_~^▬▪•·]{4,}$/.test(t)) return false;
                return true;
            })
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    } catch (err) {
        console.error('[AYUDA] Error leyendo menu.txt:', err.message);
        return '';
    }
}

function dividirEnSecciones(menu, tamano) {
    tamano = tamano || 2000;
    const secciones = [];
    for (let i = 0; i < menu.length; i += tamano) {
        secciones.push(menu.slice(i, i + tamano));
    }
    return secciones;
}

async function groq(systemPrompt, userPrompt, maxTokens) {
    maxTokens = maxTokens || 300;
    const res = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
            model: 'llama-3.1-8b-instant',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: 0.4,
            max_tokens: maxTokens
        },
        {
            headers: { 'Authorization': 'Bearer ' + API_KEY, 'Content-Type': 'application/json' },
            timeout: TIMEOUT
        }
    );
    return (res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message && res.data.choices[0].message.content || '').trim();
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

let handler = async function(message, params) {
    const text = params.text;
    try {
        if (!text) {
            return message.reply(
                '❓ *AYUDA DE ROBLEBOT*\n\n' +
                '_Pregúntame lo que necesites sobre el bot._\n\n' +
                'Ejemplos:\n' +
                '• .ayuda como ganar dinero\n' +
                '• .ayuda sistema de parejas\n' +
                '• .ayuda comandos admin'
            );
        }

        await message.reply('🤖 _Buscando en el menú..._');

        const menuCompleto = leerMenu();
        const secciones = dividirEnSecciones(menuCompleto);

        let seccionRelevante = '';
        for (let i = 0; i < secciones.length; i++) {
            const seccion = secciones[i];
            const relevancia = await groq(
                'Eres un clasificador. Responde solo "SI" si el fragmento contiene información útil para la pregunta. Responde solo "NO" si no es relevante.',
                'PREGUNTA: ' + text + '\n\nFRAGMENTO:\n' + seccion,
                5
            );
            if (relevancia.toUpperCase().includes('SI')) {
                seccionRelevante += '\n' + seccion;
            }
        }

        if (!seccionRelevante.trim()) {
            seccionRelevante = secciones[0] || '';
        }

        const respuesta = await groq(
            'Eres el asistente oficial de RobleBOT, un bot de WhatsApp desarrollado por RobleUY.\n' +
            'Usa el fragmento del menú adjunto para responder la pregunta del usuario.\n' +
            'Responde en español, directo y conciso. Máximo 200 palabras.\n' +
            'Usa *negrita* con un solo asterisco. No redirijas al usuario a otros comandos.',
            'PREGUNTA: ' + text + '\n\nINFORMACIÓN DEL MENÚ:\n' + seccionRelevante.trim(),
            400
        );

        await message.reply('🤖 *ASISTENTE ROBLEBOT*\n\n' + formatear(respuesta || '🤔 No encontré información sobre eso.'));

    } catch (err) {
        console.error('[AYUDA] Error:', (err.response && err.response.data) || err.message);
        return message.reply('❌ Error al procesar tu consulta. Intentá de nuevo.');
    }
};

handler.help = ['ayuda <texto>', 'help <texto>'];
handler.tags = ['info'];
handler.command = /^(ayuda|help)$/i;

module.exports = handler;
