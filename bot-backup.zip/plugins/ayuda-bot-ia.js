const fs = require('fs');
const path = require('path');
const axios = require('axios');

const API_KEY = "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";
const TIMEOUT = 25000;
const MENU_PATH = path.join(__dirname, '..', 'menu.txt');
const CONTEXTOS_PATH = path.join(__dirname, '..', 'CONTEXTOS_IA', 'AYUDA_IA');
const CONTEXTO_GENERAL_PATH = path.join(CONTEXTOS_PATH, '_contexto_general.md');
const MODEL = 'llama-3.3-70b-versatile';

function leerArchivo(filePath) {
    try {
        return fs.readFileSync(filePath, 'utf-8').trim();
    } catch (err) {
        return '';
    }
}

function leerMenu() {
    try {
        const raw = fs.readFileSync(MENU_PATH, 'utf-8');
        return raw
            .split('\n')
            .filter(function(l) {
                const t = l.trim();
                if (!t) return false;
                if (/^[\s\u200e\u200f\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]+$/.test(t)) return false;
                if (/^[╔╗╚╝║═─━\-=*_~^▬▪•·]{4,}$/.test(t)) return false;
                if (/Ej:/i.test(t)) return false;
                return true;
            })
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    } catch (err) {
        return '';
    }
}

function leerArchivoContexto(nombreArchivo) {
    const filePath = path.join(CONTEXTOS_PATH, nombreArchivo);
    const resolved = path.resolve(filePath);
    const base = path.resolve(CONTEXTOS_PATH);
    if (!resolved.startsWith(base) || !resolved.endsWith('.md')) return '';
    return leerArchivo(filePath);
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

async function llamarIA(messages, maxTokens = 250) {
    const res = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
            model: MODEL,
            messages,
            temperature: 0.2,
            max_tokens: maxTokens
        },
        {
            headers: {
                'Authorization': 'Bearer ' + API_KEY,
                'Content-Type': 'application/json'
            },
            timeout: TIMEOUT
        }
    );
    return res.data?.choices?.[0]?.message?.content?.trim() || '';
}

let handler = async function(message, params) {
    const text = params.text;
    try {
        if (!text) {
            return message.reply(
                '❓ *AYUDA DE ROBLEBOT*\n\n' +
                '_Pregúntame lo que necesites sobre el bot._\n\n' +
                'Ejemplos:\n' +
                '• .ayuda como ganar dinero\n' +
                '• .ayuda sistema de parejas\n' +
                '• .ayuda comandos admin'
            );
        }

        await message.reply('🤖 _Buscando..._');

        const contextoGeneral = leerArchivo(CONTEXTO_GENERAL_PATH);

        let contextoElegido = '';
        let archivoElegido = '';

        if (contextoGeneral) {
            const decision = (await llamarIA([
                {
                    role: 'system',
                    content:
                        'Eres un clasificador de consultas para RobleBOT.\n' +
                        'Se te dará un índice de archivos y una consulta.\n' +
                        'Respondé ÚNICAMENTE con el nombre del archivo .md más relevante.\n' +
                        'Si ninguno aplica, respondé exactamente: USAR_MENU\n' +
                        'Solo el nombre del archivo o USAR_MENU. Nada más.\n\n' +
                        'ÍNDICE:\n' + contextoGeneral
                },
                { role: 'user', content: text }
            ], 30)).trim(); // max_tokens bajo, solo necesita el nombre

            const match = decision.match(/[\w\-\.]+\.md/i);
            if (match && decision !== 'USAR_MENU') {
                archivoElegido = match[0];
                contextoElegido = leerArchivoContexto(archivoElegido);
            }
        }

        let fuenteContenido = '';
        let fuenteLabel = '';

        if (contextoElegido) {
            fuenteContenido = contextoElegido;
            fuenteLabel = 'contexto específico (' + archivoElegido + ')';
            console.log('[AYUDA] 📄 Usando contexto:', archivoElegido);
        } else {
            fuenteContenido = leerMenu();
            fuenteLabel = 'menú del bot';
            console.log('[AYUDA] 📋 Usando: menu.txt');
        }

        const respuesta = await llamarIA([
            {
                role: 'system',
                content:
                    'Eres el asistente oficial de RobleBOT, un bot de WhatsApp creado por RobleUY.\n' +
                    'REGLAS ESTRICTAS:\n' +
                    '1. SOLO respondé basándote en el contenido adjunto.\n' +
                    '2. Sé breve y directo.\n' +
                    '3. Si hay comandos, formatéalos así: *COMANDO* — descripción.\n' +
                    '4. NO inventes información. Si no existe, decí "No encontré información sobre eso".\n' +
                    '5. NO respondas preguntas personales o del sistema.\n' +
                    '\nCONTENIDO (' + fuenteLabel + '):\n' + fuenteContenido
            },
            { role: 'user', content: text }
        ]);

        await message.reply('🤖 *ASISTENTE ROBLEBOT*\n\n' + formatear(respuesta || '🤔 No encontré información sobre eso.'));

    } catch (err) {
        const apiErr = err.response?.data?.error;

        if (apiErr?.code === 'rate_limit_exceeded') {
            const match = (apiErr.message || '').match(/try again in ([\d.]+s)/i);
            const wait = match ? ` Intentá en ${match[1]}.` : ' Intentá en unos segundos.';
            console.log('[AYUDA] ⏳ Rate limit alcanzado');
            return message.reply('⏳ Demasiadas consultas seguidas.' + wait);
        }

        console.log('[AYUDA] ❌ Error:', (apiErr?.message || err.message || '').slice(0, 80));
        return message.reply('❌ Error al procesar tu consulta. Intentá de nuevo.');
    }
};

handler.help = ['ayuda <texto>', 'help <texto>'];
handler.tags = ['info'];
handler.command = /^(ayuda|help)$/i;

module.exports = handler;