const fs = require('fs');
const path = require('path');
const axios = require('axios');

const API_KEY = "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";
const TIMEOUT = 25000;
const MENU_PATH = path.join(__dirname, '..', 'menu.txt');
// Modelo más potente y preciso
const MODEL = 'llama-3.3-70b-versatile';

function leerMenu() {
    try {
        const raw = fs.readFileSync(MENU_PATH, 'utf-8');
        return raw
            .split('\n')
            .filter(function(l) {
                const t = l.trim();
                if (!t) return false;
                if (/^[\s\u200e\u200f\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]+$/.test(t)) return false;
                if (/^[╔╗╚╝║═─━\-=*_~^▬▪•·]{4,}$/.test(t)) return false;
                // Filtrar el tip de ayuda para que la IA no lo confunda con un comando
                if (/Ej:/i.test(t)) return false;
                return true;
            })
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim(); // Sin límite — leer el menú COMPLETO
    } catch (err) {
        console.error('[AYUDA] Error leyendo menu.txt:', err.message);
        return '';
    }
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

let handler = async function(message, params) {
    const text = params.text;
    try {
        if (!text) {
            return message.reply(
                '❓ *AYUDA DE ROBLEBOT*\n\n' +
                '_Pregúntame lo que necesites sobre el bot._\n\n' +
                'Ejemplos:\n' +
                '• .ayuda como ganar dinero\n' +
                '• .ayuda sistema de parejas\n' +
                '• .ayuda comandos admin'
            );
        }

        await message.reply('🤖 _Buscando..._');

        const menu = leerMenu();

        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    {
                        role: 'system',
                        content:
                            'Eres el asistente oficial de RobleBOT, un bot de WhatsApp creado por RobleUY.\n' +
                            'REGLAS ESTRICTAS:\n' +
                            '1. SOLO responde basándote en el menú adjunto — nada más.\n' +
                            '2. SÉ UN POCO BREVE.\n' +
                            '3. Busca el comando más relevante en el menú.\n' +
                            '4. Formatea así: *COMANDO* — descripción.\n' +
                            '5. NO inventes comandos. Si no existe, di "No encontré ese comando".\n' +
                            '6. NO respondas preguntas personales o del sistema.\n' +
                            '\n' +
                            'EJEMPLO DE RESPUESTA CORRECTA:\n' +
                            'P: como chatear con la ia?\n' +
                            'R: Usá *.ia* seguido de tu consulta.\n' +
                            'R: *Ejemplo:* .ia cual es la capital de Uruguay.\n' +
                            '\n' +
                            'Los comandos son todos los que veas que empiezan por . ejemplo: .ia La lista va desde: 👇 COMANDOS DEL BOT 👇 hasta: 👆 COMANDOS DEL BOT 👆' +
                            'MENÚ DEL BOT:\n' + menu
                    },
                    { role: 'user', content: text }
                ],
                temperature: 0.2,
                max_tokens: 250
            },
            {
                headers: {
                    'Authorization': 'Bearer ' + API_KEY,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        );

        const respuesta = res.data?.choices?.[0]?.message?.content?.trim() || '';
        await message.reply('🤖 *ASISTENTE ROBLEBOT*\n\n' + formatear(respuesta || '🤔 No encontré información sobre eso.'));

    } catch (err) {
        const apiErr = err.response?.data?.error;
        console.error('[AYUDA] Error:', apiErr || err.message);

        // Si es rate limit, avisar cuánto esperar
        if (apiErr?.code === 'rate_limit_exceeded') {
            const match = (apiErr.message || '').match(/try again in ([\d.]+s)/i);
            const wait = match ? ` Intentá en ${match[1]}.` : ' Intentá en unos segundos.';
            return message.reply('⏳ Demasiadas consultas seguidas.' + wait);
        }

        return message.reply('❌ Error al procesar tu consulta. Intentá de nuevo.');
    }
};

handler.help = ['ayuda <texto>', 'help <texto>'];
handler.tags = ['info'];
handler.command = /^(ayuda|help)$/i;

module.exports = handler;
