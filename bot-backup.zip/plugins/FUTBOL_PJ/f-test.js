const axios = require('axios');
const fs = require('fs');
const path = require('path');

let handler = async (message, { text, command }) => {
    // 🔑 TU API KEY DE API-FOOTBALL
    const API_KEY = 'TU_API_KEY_AQUI'; 

    // Lista de IDs de Selecciones (Mundial 2026 / Principales)
    // Argentina(26), Brasil(6), Francia(2), España(9), Uruguay(30), 
    // Portugal(27), Alemania(25), Inglaterra(10), México(16), USA(15)
    const SELECCIONES = [26, 6, 2, 9, 30, 27, 25, 10, 16, 15];

    // Ruta donde se guardará (debe coincidir con la que usa tu jugadores.js)
    const FILE_PATH = path.join(__dirname, '../futbolistas_mundial.json');

    await message.reply(`⏳ *Iniciando descarga masiva...* (Procesando ${SELECCIONES.length} países). Esto puede tardar un poco.`);

    try {
        let listaGlobal = [];

        for (let id of SELECCIONES) {
            const config = {
                method: 'get',
                url: `https://v3.football.api-sports.io/players/squads?team=${id}`,
                headers: { 
                    'x-apisports-key': API_KEY,
                    'x-apisports-host': 'v3.football.api-sports.io'
                }
            };

            const { data } = await axios(config);
            
            if (data.response && data.response.length > 0) {
                const pais = data.response[0].team.name;
                const jugadores = data.response[0].players;

                jugadores.forEach(j => {
                    // Traducción automática
                    const posMap = { 
                        "Goalkeeper": "Portero", 
                        "Defender": "Defensa", 
                        "Midfielder": "Mediocampista", 
                        "Attacker": "Delantero" 
                    };

                    // Asignar estrellas al azar (2 a 5)
                    const estrellas = ["☆☆", "☆☆☆", "☆☆☆☆", "☆☆☆☆☆"][Math.floor(Math.random() * 4)];

                    listaGlobal.push({
                        nombre: j.name,
                        pais: pais,
                        posicion: posMap[j.position] || "Mediocampista",
                        calidad: estrellas
                    });
                });
            }
        }

        // Guardar el archivo físicamente
        fs.writeFileSync(FILE_PATH, JSON.stringify(listaGlobal, null, 2));

        await message.reply(
            `✅ *¡Base de datos creada!*\n\n` +
            `• *Archivo:* \`futbolistas_mundial.json\`\n` +
            `• *Jugadores cargados:* ${listaGlobal.length}\n` +
            `• *Países:* ${SELECCIONES.length}\n\n` +
            `_Ahora reinicia el bot para que jugadores.js cargue los nuevos datos._`
        );

    } catch (error) {
        console.error(error);
        await message.reply('💥 *Error fatal:* ' + error.message);
    }
};

handler.command = /^(fget)$/i;
handler.rowner = true; // Recomendado: que solo tú puedas usarlo para no gastar la API
module.exports = handler;