const axios = require('axios')

const BUFFER_DOWNLOAD_TIMEOUT_MS = 25000
const GLOBAL_TWITTER_TIMEOUT_MS = 60000

function withTimeout(promise, ms, timeoutMessage) {
  let timer
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage || `TIMEOUT_${ms}MS`)), ms)
  })
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer))
}

// --- Fuentes de metadata ---

async function getFromDeliriusTwitter(url) {
  console.log('[TWITTER] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/twitter?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const d = res.data
  if (!d?.status || !d?.data?.media?.length) throw new Error('DELIRIUS_FAIL')
  const items = []
  for (const item of d.data.media) {
    if (item.type === 'video' && item.videos?.length) {
      const best = item.videos
        .filter(v => v.content_type === 'video/mp4')
        .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0]
      if (best?.url) items.push({ type: 'video', url: best.url })
    } else if (item.type === 'photo' && item.image) {
      items.push({ type: 'image', url: item.image })
    }
  }
  if (!items.length) throw new Error('DELIRIUS_NO_ITEMS')
  console.log('[TWITTER] ✅ DeliriusAPI entregó resultado')
  return { items, description: d.data.description || '', source: 'DeliriusAPI' }
}

async function getFromRobleTwitter(url) {
  console.log('[TWITTER] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/twitter?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_FAIL')
  console.log('[TWITTER] ✅ RobleAPI entregó resultado')
  return { items: [{ type: 'video', url: res.data.download_url }], description: res.data.title || '', source: 'RobleAPI' }
}

async function getFromSankaTwitter(url) {
  console.log('[TWITTER] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/twitter?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const r = res.data?.result
  if (!res.data?.status || !r) throw new Error('SANKA_FAIL')
  const dl = r.download || r.url || r.video
  if (!dl) throw new Error('SANKA_NO_URL')
  console.log('[TWITTER] ✅ SankaAPI entregó resultado')
  return { items: [{ type: String(dl).includes('.mp4') ? 'video' : 'image', url: dl }], description: r.title || '', source: 'SankaAPI' }
}

// --- Carrera de fuentes: todas a la vez, gana la primera en responder Y descargar ---

async function getWorkingTwitter(twitterUrl) {
  const sources = [
    { name: 'DeliriusAPI', fn: getFromDeliriusTwitter },
    { name: 'RobleAPI',    fn: getFromRobleTwitter },
    { name: 'SankaAPI',    fn: getFromSankaTwitter }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(twitterUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[TWITTER] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[TWITTER] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          const res = await withTimeout(
            axios.get(item.url, { responseType: 'arraybuffer', timeout: BUFFER_DOWNLOAD_TIMEOUT_MS }),
            BUFFER_DOWNLOAD_TIMEOUT_MS,
            'BUFFER_DOWNLOAD_TIMEOUT'
          )
          buffer = Buffer.from(res.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[TWITTER] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, description: result.data.description, source: sourceName }
    } catch (downloadError) {
      console.log(`[TWITTER] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Twitter fallaron. Detalles: ' + errors.join(' | '))
}

// --- Handler /twitter ---

let handlerTwitter = async (message, { conn }) => {
  try {
    const args = (message.body || '').trim().split(/\s+/).slice(1)

    if (!args[0]) {
      return await message.reply(
        '🔎 *Uso correcto:*\n/twitter <enlace>\n\nEjemplo: /twitter https://x.com/usuario/status/123456789'
      )
    }

    await message.reply('⏳ *Descargando contenido de Twitter/X...*')

    const { items, description, source } = await withTimeout(
      getWorkingTwitter(args[0]),
      GLOBAL_TWITTER_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    console.log(`[TWITTER] 🚀 Enviando ${items.length} elemento(s) a WhatsApp vía ${source}...`)

    const caption = description ? `📝 ${description}` : ''

    for (const item of items) {
      if (item.type === 'video') {
        await conn.sendMessage(message.from, { video: item.buffer, caption }, { quoted: message._baileyMessage })
      } else if (item.type === 'image') {
        await conn.sendMessage(message.from, { image: item.buffer, caption }, { quoted: message._baileyMessage })
      }
    }

    console.log('[TWITTER] ✅ Elemento(s) de Twitter enviado(s) a WhatsApp exitosamente')

  } catch (error) {
    console.error('[TWITTER ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    return await message.reply('❌ No se pudo obtener el contenido de Twitter/X. Verifica que el enlace sea público o inténtalo más tarde.')
  }
}

handlerTwitter.help = ['twitter']
handlerTwitter.tags = ['download']
handlerTwitter.command = /^(twitter|x|twdl)$/i

module.exports.twitter = handlerTwitter
