const axios = require('axios');

let handlerTwitter = async (message, { conn }) => {
    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);

        if (args.length === 0) {
            return await message.reply(
                '🔎 *Uso correcto:*\n/twitter <enlace>\n\nEjemplo: /twitter https://x.com/Wendyta_vc/status/1925681330727137327'
            );
        }

        const twitterUrl = args[0];
        const apiUrl = `https://api.delirius.store/download/twitter?url=${encodeURIComponent(twitterUrl)}`;

        // 🟢 MENSAJE INICIAL DE DESCARGA
        await message.reply('⏳ *Descargando el contenido...*\nPor favor, ten paciencia, puede tardar unos segundos si el archivo es pesado.');

        const response = await axios.get(apiUrl);
        const result = response.data;

        if (!result.status || !result.data || !result.data.media || result.data.media.length === 0) {
            return await message.reply('❌ No se pudo obtener el contenido de la publicación. Verifica el enlace o inténtalo más tarde.');
        }

        const { media, description } = result.data;
        const caption = description ? `📝 ${description}` : '✅ *Contenido de Twitter descargado correctamente.*';

        // Recorremos cada elemento de media (puede haber varias fotos, o un video)
        for (const item of media) {
            if (item.type === 'video') {
                // Elegimos la versión de mayor calidad (mayor bitrate) del video
                const bestVideo = item.videos
                    .filter(v => v.content_type === 'video/mp4')
                    .sort((a, b) => b.bitrate - a.bitrate)[0];

                if (!bestVideo) continue;

                const videoResponse = await axios.get(bestVideo.url, { responseType: 'arraybuffer' });
                const videoBuffer = Buffer.from(videoResponse.data);

                await conn.sendMessage(message.from, {
                    video: videoBuffer,
                    caption: `🎬 ${caption}`
                }, { quoted: message._baileyMessage });

            } else if (item.type === 'photo') {
                const imageResponse = await axios.get(item.image, { responseType: 'arraybuffer' });
                const imageBuffer = Buffer.from(imageResponse.data);

                await conn.sendMessage(message.from, {
                    image: imageBuffer,
                    caption: `🖼️ ${caption}`
                }, { quoted: message._baileyMessage });
            }
        }

    } catch (error) {
        console.error('Error en el comando twitter:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.');
    }
};

handlerTwitter.help = ['twitter'];
handlerTwitter.tags = ['download'];
handlerTwitter.command = /^(twitter)$/i;

module.exports.twitter = handlerTwitter;