const axios = require('axios')

let alldlFunc = null
try {
  const ytdl = require('@hiudyy/ytdl')
  alldlFunc = ytdl.alldl || ytdl.default?.alldl
} catch (e) {
  console.warn('[TWITTER] @hiudyy/ytdl alldl no disponible:', e.message)
}

async function getFromHiudyyTwitter(url) {
  if (!alldlFunc) throw new Error('HIUDYY_NOT_AVAILABLE')
  console.log('[TWITTER] Consultando Hiudyy-YTDL...')
  const res = await alldlFunc(url)
  const items = Array.isArray(res) ? res : [res]
  const validItems = items
    .map(i => ({
      type: i?.type === 'image' || i?.type === 'photo' ? 'image' : 'video',
      url: i?.src || i?.url || (typeof i === 'string' ? i : null)
    }))
    .filter(i => i.url)
  if (!validItems.length) throw new Error('HIUDYY_NO_ITEMS')
  console.log('[TWITTER] ✅ Hiudyy-YTDL entregó resultado')
  return { items: validItems, description: '', source: 'Hiudyy-YTDL' }
}

async function getFromDeliriusTwitter(url) {
  console.log('[TWITTER] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/twitter?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const d = res.data
  if (!d?.status || !d?.data?.media?.length) throw new Error('DELIRIUS_FAIL')

  const items = []
  for (const item of d.data.media) {
    if (item.type === 'video' && item.videos?.length) {
      const best = item.videos.filter(v => v.content_type === 'video/mp4').sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0]
      if (best?.url) items.push({ type: 'video', url: best.url })
    } else if (item.type === 'photo' && item.image) {
      items.push({ type: 'image', url: item.image })
    }
  }
  if (!items.length) throw new Error('DELIRIUS_NO_ITEMS')
  console.log('[TWITTER] ✅ DeliriusAPI entregó resultado')
  return { items, description: d.data.description || '', source: 'DeliriusAPI' }
}

async function getFromRobleTwitter(url) {
  console.log('[TWITTER] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/twitter?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_FAIL')
  console.log('[TWITTER] ✅ RobleAPI entregó resultado')
  return { items: [{ type: 'video', url: res.data.download_url }], description: res.data.title || '', source: 'RobleAPI' }
}

async function getFromSankaTwitter(url) {
  console.log('[TWITTER] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/twitter?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const r = res.data?.result
  if (!res.data?.status || !r) throw new Error('SANKA_FAIL')
  const dl = r.download || r.url || r.video
  if (!dl) throw new Error('SANKA_NO_URL')
  console.log('[TWITTER] ✅ SankaAPI entregó resultado')
  return { items: [{ type: String(dl).includes('.mp4') ? 'video' : 'image', url: dl }], description: r.title || '', source: 'SankaAPI' }
}

async function getWorkingTwitter(twitterUrl) {
  const sources = [
    { name: 'Hiudyy-YTDL', fn: getFromHiudyyTwitter },
    { name: 'DeliriusAPI', fn: getFromDeliriusTwitter },
    { name: 'RobleAPI', fn: getFromRobleTwitter },
    { name: 'SankaAPI', fn: getFromSankaTwitter }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(twitterUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[TWITTER] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[TWITTER] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          const res = await axios.get(item.url, { responseType: 'arraybuffer', timeout: 60000 })
          buffer = Buffer.from(res.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[TWITTER] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, description: result.data.description, source: sourceName }
    } catch (downloadError) {
      console.log(`[TWITTER] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Twitter fallaron.')
}

let handlerTwitter = async (message, { conn }) => {
  const sock = conn || message._sock || global.conn
  try {
    const text = message.body || ''
    const args = text.trim().split(' ').slice(1)

    if (args.length === 0) {
      return await message.reply(
        '🔎 *Uso correcto:*\n/twitter <enlace>\n\nEjemplo: /twitter https://x.com/Wendyta_vc/status/1925681330727137327'
      )
    }

    const twitterUrl = args[0]

    await message.reply('⏳ *Descargando contenido de Twitter/X...*')

    const { items, description, source } = await getWorkingTwitter(twitterUrl)

    console.log(`[TWITTER] 🚀 Enviando ${items.length} elemento(s) a WhatsApp vía ${source}...`)

    const caption = description ? `📝 ${description}` : ''

    for (const item of items) {
      if (item.type === 'video') {
        await sock.sendMessage(message.from, { video: item.buffer, caption }, { quoted: message._baileyMessage })
      } else if (item.type === 'image') {
        await sock.sendMessage(message.from, { image: item.buffer, caption }, { quoted: message._baileyMessage })
      }
    }

    console.log(`[TWITTER] ✅ Elemento(s) de Twitter enviado(s) a WhatsApp exitosamente`)

  } catch (error) {
    console.error('[TWITTER ERROR]', error.message || error)
    return await message.reply('❌ No se pudo obtener el contenido de Twitter/X. Verifica que el enlace sea público o inténtalo más tarde.')
  }
}

handlerTwitter.help = ['twitter']
handlerTwitter.tags = ['download']
handlerTwitter.command = /^(twitter|x|twdl)$/i

module.exports.twitter = handlerTwitter