const axios = require('axios');

let handlerTwitter = async (message, { conn }) => {
    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);

        if (args.length === 0) {
            return await message.reply(
                '📎 *Uso correcto:*\n/twitter <enlace>\n\nEjemplo: /twitter https://x.com/Wendyta_vc/status/1925681330727137327'
            );
        }

        const twitterUrl = args[0];
        const apiUrl = `https://delirius-apiofc.vercel.app/download/twitterdl?url=${encodeURIComponent(twitterUrl)}`;

        // 🟢 MENSAJE INICIAL DE DESCARGA
        await message.reply('⏳ *Descargando el contenido...*\nPor favor, ten paciencia, puede tardar unos segundos si el archivo es pesado.');

        const response = await axios.get(apiUrl);
        const data = response.data;

        // ✅ VIDEO
        if (data.found && data.type === 'video' && data.media && data.media.length > 0) {
            const videoUrl = data.media[0].url;
            const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer' });
            const videoBuffer = Buffer.from(videoResponse.data);

            await sock.sendMessage(message.from, {
                video: videoBuffer,
                caption: '✅ *Aquí tienes tu video de Twitter descargado correctamente.* 🎬'
            }, { quoted: message._baileyMessage });

        // 🖼️ IMAGEN
        } else if (data.found && data.type === 'image' && data.media && data.media.length > 0) {
            const imageUrl = data.media[0].url;
            const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(imageResponse.data);

            await sock.sendMessage(message.from, {
                image: imageBuffer,
                caption: '🖼️ *Aquí tienes tu imagen de Twitter descargada correctamente.*'
            }, { quoted: message._baileyMessage });

        } else {
            await message.reply('❌ No se pudo obtener el contenido de la publicación. Verifica el enlace o inténtalo más tarde.');
        }

    } catch (error) {
        console.error('Error en el comando twitter:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.');
    }
};

handlerTwitter.help = ['twitter'];
handlerTwitter.tags = ['download'];
handlerTwitter.command = /^(twitter)$/i;

module.exports.twitter = handlerTwitter;

