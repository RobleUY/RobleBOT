const axios = require('axios');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

let handlerHentaiv = async (message, { conn }) => {
    try {
        // Verificar si el mensaje proviene del grupo bloqueado
        if (message.from === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }

        const apiUrl = 'https://delirius-apiofc.vercel.app/anime/hentaivid';
        const response = await axios.get(apiUrl);
        const videos = response.data; // Array de objetos con videos
        
        if (videos && videos.length > 0) {
            const randomIndex = Math.floor(Math.random() * videos.length);
            const randomVideo = videos[randomIndex];
            const videoUrl = randomVideo.video_1; // Usa video_1 (puedes cambiarlo por video_2 si prefieres)
            
            // 🟢 MENSAJE INICIAL DE DESCARGA
            await message.reply('⏳ *Buscando y descargando video...*\nPor favor, espera unos segundos.');
            
            // Descargar el video
            const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer' });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            
            // Enviar el video como respuesta al mensaje del comando
            await conn.sendMessage(message.from, {
                video: videoBuffer,
                caption: '🔞 *Aquí tienes tu video de hentai.* 😏'
            }, { quoted: message._baileyMessage });
        } else {
            await message.reply('❌ No se encontraron videos disponibles en la API.');
        }
    } catch (error) {
        console.error('Error en el comando hentaiv:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el video. Intenta nuevamente más tarde.');
    }
};

handlerHentaiv.help = ['hentaiv'];
handlerHentaiv.tags = ['videos', 'nsfw'];
handlerHentaiv.command = /^(hentaiv)$/i;

module.exports.hentaiv = handlerHentaiv;