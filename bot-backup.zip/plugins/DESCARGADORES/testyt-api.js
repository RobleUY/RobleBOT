const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true;
const API_BASE_URL = 'http://darli.hidencloud.com:24667';
// ========================================

const LimitAud = 100 * 1024 * 1024; // 100MB para audio
const LimitVid = 500 * 1024 * 1024; // 500MB para video
const sanitizeFilename = (name = 'archivo') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// Función de búsqueda de YouTube
async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) {
            throw new Error('No se encontraron resultados en YouTube');
        }
        return {
            url: r.videos[0].url,
            title: r.videos[0].title,
            duration: r.videos[0].timestamp,
            thumbnail: r.videos[0].thumbnail
        };
    } catch (e) {
        console.error('[TESTYTAPI] Error en búsqueda de YouTube:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

// Descargar MP3 desde la API (descarga directa del stream)
async function downloadMP3Stream(youtubeUrl, videoInfo) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `${API_BASE_URL}/mp3?url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[TESTYTAPI MP3] Descargando directamente desde:', endpoint);
        
        const tempDir = path.join(__dirname, '.temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const tempFile = path.join(tempDir, sanitizeFilename(videoInfo.title) + '.mp3');
        const writer = fs.createWriteStream(tempFile);

        // Descargar el stream directamente
        const response = await axios({
            method: 'GET',
            url: endpoint,
            responseType: 'stream',
            timeout: 120000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => {
                const stats = fs.statSync(tempFile);
                const fileSize = stats.size;
                console.log(`[TESTYTAPI MP3] Archivo descargado: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);
                
                if (fileSize < 1000) {
                    fs.unlinkSync(tempFile);
                    reject(new Error('El archivo descargado es demasiado pequeño o está corrupto'));
                } else {
                    resolve({ tempFile, fileSize });
                }
            });
            writer.on('error', (err) => {
                reject(new Error(`Error escribiendo archivo: ${err.message}`));
            });
        });

    } catch (error) {
        console.error('[TESTYTAPI MP3] Error:', error?.message || error);
        throw error;
    }
}

// Descargar MP4 desde la API (descarga directa del stream)
async function downloadMP4Stream(youtubeUrl, videoInfo) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `${API_BASE_URL}/mp4?url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[TESTYTAPI MP4] Descargando directamente desde:', endpoint);
        
        const tempDir = path.join(__dirname, '.temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const tempFile = path.join(tempDir, sanitizeFilename(videoInfo.title) + '.mp4');
        const writer = fs.createWriteStream(tempFile);

        // Descargar el stream directamente
        const response = await axios({
            method: 'GET',
            url: endpoint,
            responseType: 'stream',
            timeout: 120000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => {
                const stats = fs.statSync(tempFile);
                const fileSize = stats.size;
                console.log(`[TESTYTAPI MP4] Archivo descargado: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);
                
                if (fileSize < 1000) {
                    fs.unlinkSync(tempFile);
                    reject(new Error('El archivo descargado es demasiado pequeño o está corrupto'));
                } else {
                    resolve({ tempFile, fileSize });
                }
            });
            writer.on('error', (err) => {
                reject(new Error(`Error escribiendo archivo: ${err.message}`));
            });
        });

    } catch (error) {
        console.error('[TESTYTAPI MP4] Error:', error?.message || error);
        throw error;
    }
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO) {
        return await message.reply(
            '⚠️ *COMANDO TEMPORALMENTE DESHABILITADO*\n\n' +
            '_Este comando está en mantenimiento y volverá pronto._'
        );
    }

    if (!text) {
        return await message.reply(
            `❌ Por favor envía un link o título de YouTube.\n\n*Ejemplos:*\n` +
            `• ${usedPrefix}testytapi mp3 https://youtu.be/kLpH1nSLJSs\n` +
            `• ${usedPrefix}testytapi mp4 https://youtu.be/kLpH1nSLJSs\n` +
            `• ${usedPrefix}testytapi mp3 Bad Bunny Amorfoda\n` +
            `• ${usedPrefix}testytapi mp4 Lana Del Rey Summertime Sadness`
        );
    }

    // Detectar si es mp3 o mp4
    const args = text.trim().split(/\s+/);
    const format = args[0].toLowerCase();
    
    if (format !== 'mp3' && format !== 'mp4') {
        return await message.reply(
            `❌ Formato inválido. Usa:\n` +
            `• ${usedPrefix}testytapi mp3 <link o título>\n` +
            `• ${usedPrefix}testytapi mp4 <link o título>`
        );
    }

    const query = args.slice(1).join(' ');
    
    if (!query) {
        return await message.reply(
            `❌ Debes proporcionar un link o título después de "${format}".\n\n*Ejemplo:*\n` +
            `${usedPrefix}testytapi ${format} Bad Bunny Amorfoda`
        );
    }

    let tempFile = null;

    try {
        await message.reply(`🔍 Buscando ${format.toUpperCase()} en YouTube...\n_Usando API de prueba_`);

        // Detectar si es link directo o buscar
        let youtubeUrl = query;
        let videoInfo = {
            title: 'Video',
            duration: 'Desconocida',
            thumbnail: null
        };

        if (!query.includes('youtube.com') && !query.includes('youtu.be')) {
            const searchResult = await searchYouTube(query);
            youtubeUrl = searchResult.url;
            videoInfo = searchResult;
        } else {
            // Si es link directo, intentar obtener info
            try {
                const searchResult = await yts({ videoId: youtubeUrl.split('v=')[1] || youtubeUrl.split('/').pop() });
                if (searchResult) {
                    videoInfo.title = searchResult.title || 'Video';
                    videoInfo.duration = searchResult.timestamp || 'Desconocida';
                    videoInfo.thumbnail = searchResult.thumbnail || null;
                }
            } catch (e) {
                console.log('[TESTYTAPI] No se pudo obtener info del video, usando valores por defecto');
            }
        }

        // Enviar miniatura si existe
        if (videoInfo.thumbnail) {
            try {
                await conn.sendMessage(message.from, {
                    image: { url: videoInfo.thumbnail },
                    caption: `${format === 'mp3' ? '🎵' : '🎬'} *${videoInfo.title}*\n⏱️ Duración: ${videoInfo.duration}\n📡 API: Test API\n\n_Descargando ${format.toUpperCase()}..._`
                }, { quoted: message._baileyMessage });
            } catch (imgErr) {
                console.error('[TESTYTAPI] Error al enviar imagen:', imgErr.message);
                await message.reply(`${format === 'mp3' ? '🎵' : '🎬'} *${videoInfo.title}*\n⏱️ Duración: ${videoInfo.duration}\n\n_Descargando ${format.toUpperCase()}..._`);
            }
        } else {
            await message.reply(`${format === 'mp3' ? '🎵' : '🎬'} *${videoInfo.title}*\n⏱️ Duración: ${videoInfo.duration}\n\n_Descargando ${format.toUpperCase()}..._`);
        }

        // Descargar según formato
        let downloadResult;
        if (format === 'mp3') {
            downloadResult = await downloadMP3Stream(youtubeUrl, videoInfo);
        } else {
            downloadResult = await downloadMP4Stream(youtubeUrl, videoInfo);
        }

        tempFile = downloadResult.tempFile;
        const fileSize = downloadResult.fileSize;
        const sizeMB = (fileSize / (1024 * 1024)).toFixed(2);

        const buffer = fs.readFileSync(tempFile);
        const fileName = sanitizeFilename(videoInfo.title) + (format === 'mp3' ? '.mp3' : '.mp4');

        // Enviar según formato y tamaño
        try {
            if (format === 'mp3') {
                // Enviar audio
                if (fileSize > LimitAud) {
                    console.log('[TESTYTAPI] Enviando audio como documento (> 100MB)');
                    await conn.sendMessage(message.from, {
                        document: buffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName
                    }, { quoted: message._baileyMessage });
                } else {
                    console.log('[TESTYTAPI] Enviando como audio');
                    await conn.sendMessage(message.from, {
                        audio: buffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName,
                        ptt: false
                    }, { quoted: message._baileyMessage });
                }
            } else {
                // Enviar video
                if (fileSize > LimitVid) {
                    await message.reply(`⚠️ El video pesa ${sizeMB} MB, supera el límite de 500 MB.`);
                } else if (sizeMB >= 100) {
                    console.log('[TESTYTAPI] Enviando video como documento (>= 100MB)');
                    await conn.sendMessage(message.from, {
                        document: buffer,
                        mimetype: 'video/mp4',
                        fileName: fileName,
                        caption: `🎬 *${videoInfo.title}*\n📦 Tamaño: ${sizeMB} MB`
                    }, { quoted: message._baileyMessage });
                } else {
                    console.log('[TESTYTAPI] Enviando como video');
                    await conn.sendMessage(message.from, {
                        video: buffer,
                        mimetype: 'video/mp4',
                        caption: `🎬 *${videoInfo.title}*\n📦 Tamaño: ${sizeMB} MB`
                    }, { quoted: message._baileyMessage });
                }
            }
            
            console.log(`[TESTYTAPI] ✅ ${format.toUpperCase()} enviado correctamente`);
            
        } catch (sendErr) {
            console.error('[TESTYTAPI] Error enviando archivo:', sendErr.message);
            await message.reply(`❌ Ocurrió un error al enviar el ${format}.`);
        }

        // Limpiar archivo temporal
        if (fs.existsSync(tempFile)) {
            try { 
                fs.unlinkSync(tempFile); 
                console.log('[TESTYTAPI] Archivo temporal eliminado'); 
            } catch (unlinkErr) { 
                console.error('[TESTYTAPI] Error al eliminar archivo:', unlinkErr.message); 
            }
        }

    } catch (e) {
        console.error('[TESTYTAPI] Error general:', e?.message || e);
        
        // Limpiar archivo temporal en caso de error
        if (tempFile && fs.existsSync(tempFile)) {
            try { 
                fs.unlinkSync(tempFile); 
            } catch (unlinkErr) { 
                console.error('[TESTYTAPI] Error al eliminar archivo:', unlinkErr.message); 
            }
        }
        
        await message.reply(
            `❌ No se pudo descargar el ${format === 'mp3' ? 'audio' : 'video'}.\n\n` +
            `💡 *Sugerencias:*\n` +
            `• Verifica que el link sea válido\n` +
            `• Intenta con otro video\n` +
            `• Espera unos minutos y vuelve a intentar\n\n` +
            `_Error: ${e.message}_`
        );
    }
};

handler.help = ['testytapi mp3 <link o título>', 'testytapi mp4 <link o título>'];
handler.tags = ['test', 'youtube', 'downloader'];
handler.command = /^(testytapi)$/i;

module.exports = handler;