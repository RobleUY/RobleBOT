const axios = require('axios');

let handlerFacebook = async (message, { conn }) => {
    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);
        const apiKey = 'planaai'; // Tu API Key para la API de Sanka Vollerei

        if (args.length === 0) {
            return await message.reply(
                '📎 *Uso correcto:*\n/facebook <enlace>\n\nEjemplo: /facebook https://www.facebook.com/reel/1181582400491469'
            );
        }

        const facebookUrl = args[0];
        // Construcción de la URL de la API de Facebook
        const apiUrl = `https://www.sankavollerei.com/download/facebook?apikey=${apiKey}&url=${encodeURIComponent(facebookUrl)}`;

        // 🟢 MENSAJE INICIAL DE DESCARGA
        await message.reply('⏳ *Descargando el contenido de Facebook...*\nPor favor, ten paciencia, puede tardar unos segundos.');

        const response = await axios.get(apiUrl);
        const data = response.data;

        // Verificar el estado de la respuesta y si hay resultados
        if (data.status && data.result && data.result.video && data.result.video.length > 0) {
            
            // Buscar la URL del video de 360p (SD)
            const video360p = data.result.video.find(v => v.quality === '360p (SD)');
            
            let videoUrl;
            let qualityMessage;

            if (video360p) {
                // Usar la URL de 360p si está disponible
                videoUrl = video360p.url;
                qualityMessage = '*360p (SD)*';
            } else if (data.result.media) {
                // Si no se encuentra 360p, usar la URL principal de 'media' como fallback, aunque no se especifique la calidad.
                // Esta URL principal suele ser la de mayor calidad o la más accesible.
                videoUrl = data.result.media;
                qualityMessage = '*calidad predeterminada (posiblemente la mejor disponible)*';
            } else {
                // Si no hay 360p ni 'media', usar el primer video disponible
                videoUrl = data.result.video[0].url;
                qualityMessage = `*${data.result.video[0].quality}* (la mejor disponible)`;
            }

            // Descargar el video
            const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer' });
            const videoBuffer = Buffer.from(videoResponse.data);

            // Enviar el video
            await conn.sendMessage(message.from, {
                video: videoBuffer,
                caption: `✅ *Aquí tienes tu video de Facebook descargado correctamente.* 🎬\n\n*Título:* ${data.result.title || 'Sin título'}\n*Duración:* ${data.result.duration || 'N/A'}\n*Calidad:* ${qualityMessage}`
            }, { quoted: message._baileyMessage });

        } else {
            // Manejar caso donde el enlace no devuelve contenido de video
            await message.reply('❌ No se pudo obtener el video de la publicación. Verifica el enlace de Facebook o inténtalo más tarde. Asegúrate de que no sea un post de solo imagen o que el video sea público.');
        }

    } catch (error) {
        console.error('Error en el comando facebook:', error);
        // Manejar errores de la API o de la descarga
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.');
    }
};

handlerFacebook.help = ['facebook'];
handlerFacebook.tags = ['download'];
handlerFacebook.command = /^(facebook)$/i; // Añado 'fb' y 'fbdl' como alias

module.exports.facebook = handlerFacebook;