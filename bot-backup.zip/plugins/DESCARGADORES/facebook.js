const axios = require('axios')

const BUFFER_DOWNLOAD_TIMEOUT_MS = 25000
const GLOBAL_FACEBOOK_TIMEOUT_MS = 60000

function withTimeout(promise, ms, timeoutMessage) {
  let timer
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage || `TIMEOUT_${ms}MS`)), ms)
  })
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer))
}

// --- Fuentes de metadata ---

async function getFromDeliriusFB(url) {
  console.log('[FACEBOOK] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/facebook?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const dl = res.data?.data?.urls?.[0]?.url || res.data?.data?.sd || res.data?.data?.hd || res.data?.data?.url
  if (!res.data?.status || !dl) throw new Error('DELIRIUS_FAIL')
  console.log('[FACEBOOK] ✅ DeliriusAPI entregó resultado')
  return { downloadUrl: dl, title: res.data.data?.title || '', source: 'DeliriusAPI' }
}

async function getFromRobleFB(url) {
  console.log('[FACEBOOK] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/facebook?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_FAIL')
  console.log('[FACEBOOK] ✅ RobleAPI entregó resultado')
  return { downloadUrl: res.data.download_url, title: res.data.title || '', source: 'RobleAPI' }
}

async function getFromSankaFB(url) {
  console.log('[FACEBOOK] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/facebook?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const r = res.data?.result
  if (!res.data?.status || !r) throw new Error('SANKA_FAIL')
  const video360p = Array.isArray(r.video) ? r.video.find(v => v.quality === '360p (SD)')?.url : null
  const videoUrl = video360p || r.media || (Array.isArray(r.video) ? r.video[0]?.url : null) || r.url
  if (!videoUrl) throw new Error('SANKA_NO_URL')
  console.log('[FACEBOOK] ✅ SankaAPI entregó resultado')
  return { downloadUrl: videoUrl, title: r.title || '', source: 'SankaAPI' }
}

// --- Carrera de fuentes: todas a la vez, gana la primera en responder Y descargar ---

async function getWorkingFacebook(facebookUrl) {
  const sources = [
    { name: 'DeliriusAPI', fn: getFromDeliriusFB },
    { name: 'RobleAPI',    fn: getFromRobleFB },
    { name: 'SankaAPI',    fn: getFromSankaFB }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(facebookUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[FACEBOOK] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[FACEBOOK] ${sourceName} entregó metadata, descargando buffer...`)

    try {
      let videoBuffer
      if (Buffer.isBuffer(result.data.downloadUrl)) {
        videoBuffer = result.data.downloadUrl
      } else {
        const videoResponse = await withTimeout(
          axios.get(result.data.downloadUrl, { responseType: 'arraybuffer', timeout: BUFFER_DOWNLOAD_TIMEOUT_MS }),
          BUFFER_DOWNLOAD_TIMEOUT_MS,
          'BUFFER_DOWNLOAD_TIMEOUT'
        )
        videoBuffer = Buffer.from(videoResponse.data)
      }
      console.log(`[FACEBOOK] 🏆 ¡GANADORA! ${sourceName} descargó el video exitosamente`)
      return { ...result.data, videoBuffer }
    } catch (downloadError) {
      console.log(`[FACEBOOK] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Facebook fallaron. Detalles: ' + errors.join(' | '))
}

// --- Handler /facebook ---

let handlerFacebook = async (message, { conn }) => {
  try {
    const args = (message.body || '').trim().split(/\s+/).slice(1)

    if (!args[0]) {
      return await message.reply(
        '🔎 *Uso correcto:*\n/facebook <enlace>\n\nEjemplo: /facebook https://www.facebook.com/reel/1181582400491469'
      )
    }

    await message.reply('⏳ *Descargando contenido de Facebook...*')

    const { title, videoBuffer, source } = await withTimeout(
      getWorkingFacebook(args[0]),
      GLOBAL_FACEBOOK_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    console.log(`[FACEBOOK] 🚀 Enviando a WhatsApp video descargado vía ${source}...`)

    const caption = title ? `🎬 *${title}*` : '🎬 *Video de Facebook*'

    await conn.sendMessage(message.from, { video: videoBuffer, caption }, { quoted: message._baileyMessage })

    console.log('[FACEBOOK] ✅ Video de Facebook enviado a WhatsApp exitosamente')

  } catch (error) {
    console.error('[FACEBOOK ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    return await message.reply('❌ No se pudo obtener el video de Facebook. Verifica que el enlace sea público o inténtalo más tarde.')
  }
}

handlerFacebook.help = ['facebook']
handlerFacebook.tags = ['download']
handlerFacebook.command = /^(facebook|fb|fbdl)$/i

module.exports.facebook = handlerFacebook
