const axios = require('axios')

let alldlFunc = null
try {
  const ytdl = require('@hiudyy/ytdl')
  alldlFunc = ytdl.alldl || ytdl.default?.alldl
} catch (e) {
  console.warn('[FACEBOOK] @hiudyy/ytdl alldl no disponible:', e.message)
}

async function getFromHiudyyFB(url) {
  if (!alldlFunc) throw new Error('HIUDYY_NOT_AVAILABLE')
  console.log('[FACEBOOK] Consultando Hiudyy-YTDL...')
  const res = await alldlFunc(url)
  const item = Array.isArray(res) ? res[0] : res
  const downloadUrl = item?.src || item?.url || item?.downloadUrl || item?.result || (typeof res === 'string' ? res : null)
  if (!downloadUrl) throw new Error('HIUDYY_NO_URL')
  console.log('[FACEBOOK] ✅ Hiudyy-YTDL entregó resultado')
  return { downloadUrl, title: item?.title || '', source: 'Hiudyy-YTDL' }
}

async function getFromSankaFB(url) {
  console.log('[FACEBOOK] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/facebook?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const r = res.data?.result
  if (!res.data?.status || !r) throw new Error('SANKA_FAIL')
  const video360p = r.video?.find(v => v.quality === '360p (SD)')?.url
  const videoUrl = video360p || r.media || r.video?.[0]?.url
  if (!videoUrl) throw new Error('SANKA_NO_URL')
  console.log('[FACEBOOK] ✅ SankaAPI entregó resultado')
  return { downloadUrl: videoUrl, title: r.title || '', source: 'SankaAPI' }
}

async function getFromRobleFB(url) {
  console.log('[FACEBOOK] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/facebook?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_FAIL')
  console.log('[FACEBOOK] ✅ RobleAPI entregó resultado')
  return { downloadUrl: res.data.download_url, title: res.data.title || '', source: 'RobleAPI' }
}

async function getFromDeliriusFB(url) {
  console.log('[FACEBOOK] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/facebook?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const dl = res.data?.data?.urls?.[0]?.url || res.data?.data?.sd || res.data?.data?.hd || res.data?.data?.url
  if (!res.data?.status || !dl) throw new Error('DELIRIUS_FAIL')
  console.log('[FACEBOOK] ✅ DeliriusAPI entregó resultado')
  return { downloadUrl: dl, title: res.data.data?.title || '', source: 'DeliriusAPI' }
}

async function getWorkingFacebook(facebookUrl) {
  const sources = [
    { name: 'Hiudyy-YTDL', fn: getFromHiudyyFB },
    { name: 'SankaAPI', fn: getFromSankaFB },
    { name: 'RobleAPI', fn: getFromRobleFB },
    { name: 'DeliriusAPI', fn: getFromDeliriusFB }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(facebookUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[FACEBOOK] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[FACEBOOK] ${sourceName} entregó metadata, descargando buffer...`)

    try {
      let videoBuffer
      if (Buffer.isBuffer(result.data.downloadUrl)) {
        videoBuffer = result.data.downloadUrl
      } else {
        const videoResponse = await axios.get(result.data.downloadUrl, { responseType: 'arraybuffer', timeout: 60000 })
        videoBuffer = Buffer.from(videoResponse.data)
      }
      console.log(`[FACEBOOK] 🏆 ¡GANADORA! ${sourceName} descargó el video de Facebook exitosamente`)
      return { ...result.data, videoBuffer }
    } catch (downloadError) {
      console.log(`[FACEBOOK] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Facebook fallaron.')
}

let handlerFacebook = async (message, { conn }) => {
  const sock = conn || message._sock || global.conn
  try {
    const text = message.body || ''
    const args = text.trim().split(' ').slice(1)

    if (args.length === 0) {
      return await message.reply(
        '🔎 *Uso correcto:*\n/facebook <enlace>\n\nEjemplo: /facebook https://www.facebook.com/reel/1181582400491469'
      )
    }

    const facebookUrl = args[0]

    await message.reply('⏳ *Descargando contenido de Facebook...*')

    const { title, videoBuffer, source } = await getWorkingFacebook(facebookUrl)

    console.log(`[FACEBOOK] 🚀 Enviando a WhatsApp video descargado vía ${source}...`)

    const caption = title ? `🎬 *${title}*` : '🎬 *Video de Facebook*'

    await sock.sendMessage(
      message.from,
      {
        video: videoBuffer,
        caption
      },
      { quoted: message._baileyMessage }
    )

    console.log(`[FACEBOOK] ✅ Video de Facebook enviado a WhatsApp exitosamente`)

  } catch (error) {
    console.error('[FACEBOOK ERROR]', error.message || error)
    return await message.reply('❌ No se pudo obtener el video de Facebook. Verifica que el enlace sea público o inténtalo más tarde.')
  }
}

handlerFacebook.help = ['facebook']
handlerFacebook.tags = ['download']
handlerFacebook.command = /^(facebook|fb|fbdl)$/i

module.exports.facebook = handlerFacebook