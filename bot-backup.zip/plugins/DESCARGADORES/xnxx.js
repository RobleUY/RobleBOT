const axios = require('axios');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

// Función para extraer solo la duración del campo info
function extractDuration(info) {
    if (!info) return 'N/A';
    // Busca un patrón como "8min", "12min", "39min", etc.
    const match = info.match(/(\d+min)/);
    return match ? match[1] : 'N/A';
}

// Handler para /xnxxsearch <titulo> - Busca videos en la API y muestra URLs
let handlerXnxxSearch = async (message, { conn }) => {
    try {
        // Verificar si el mensaje proviene del grupo bloqueado
        if (message.from === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }

        // Extraer el argumento después del comando
        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1); // Divide por espacios y toma desde el segundo elemento
        const query = args.join(' ');

        if (!query) {
            return await message.reply('❌ Proporciona un título para buscar. Ejemplo: /xnxxsearch milf');
        }

        const apiUrl = `https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status && data.result && data.result.length > 0) {
            let msg = '🔍 *Resultados de búsqueda para "' + query + '":*\n\n';
            data.result.slice(0, 10).forEach((item, index) => { // Limita a 10 resultados
                msg += `*${index + 1}.*\n`;
                msg += `📌 *Título:* ${item.title || 'Sin título'}\n`;
                msg += `⏱️ *Duración:* ${extractDuration(item.info)}\n`;
                msg += `🔗 *Link:* ${item.link || 'N/A'}\n`;
                msg += `─────────────────\n\n`;
            });
            await message.reply(msg);
        } else {
            await message.reply('❌ No se encontraron resultados para esa búsqueda.');
        }
    } catch (error) {
        console.error('Error en xnxxsearch:', error);
        await message.reply('❌ Ocurrió un error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXnxxSearch.help = ['xnxxsearch <titulo>'];
handlerXnxxSearch.tags = ['videos', 'nsfw'];
handlerXnxxSearch.command = /^(xnxxsearch)$/i;

// Handler para /xnxx <titulo o link> - Descarga y envía el video
let handlerXnxx = async (message, { conn }) => {
    try {
        // Verificar si el mensaje proviene del grupo bloqueado
        if (message.from === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }

        // Extraer el argumento después del comando
        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1); // Divide por espacios y toma desde el segundo elemento
        const arg = args.join(' ');

        if (!arg) {
            return await message.reply('❌ Proporciona un título o link. Ejemplo: /xnxx milf o /xnxx https://www.xnxx.com/video-abc123');
        }

        let videoUrl;
        if (arg.startsWith('http')) {
            // Si es un link directo, obtén los datos de descarga
            const downloadApiUrl = `https://www.sankavollerei.com/download/xnxx?apikey=planaai&url=${encodeURIComponent(arg)}`;
            const downloadResponse = await axios.get(downloadApiUrl);
            const data = downloadResponse.data;
            if (data.status && data.result && data.result.files && data.result.files.low) {
                videoUrl = data.result.files.low; // Siempre usar la menor calidad
            } else {
                return await message.reply('❌ No se pudo obtener el video desde ese link.');
            }
        } else {
            // Si es un título, busca primero y toma el primer resultado
            const searchUrl = `https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(arg)}`;
            const searchResponse = await axios.get(searchUrl);
            const searchData = searchResponse.data;
            if (!searchData.status || !searchData.result || searchData.result.length === 0) {
                return await message.reply('❌ No se encontraron videos para ese título.');
            }
            const firstResult = searchData.result[0];
            const downloadApiUrl = `https://www.sankavollerei.com/download/xnxx?apikey=planaai&url=${encodeURIComponent(firstResult.link)}`;
            const downloadResponse = await axios.get(downloadApiUrl);
            const data = downloadResponse.data;
            if (data.status && data.result && data.result.files && data.result.files.low) {
                videoUrl = data.result.files.low; // Siempre usar la menor calidad
            } else {
                return await message.reply('❌ No se pudo obtener el video del primer resultado.');
            }
        }

        // Mensaje inicial de descarga
        await message.reply('⏳ *Buscando y descargando video...*\nPor favor, espera unos segundos.');

        // Descargar el video desde el enlace directo
        const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer' });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');

        // Enviar el video
        await conn.sendMessage(message.from, {
            video: videoBuffer,
            caption: '🔞 *Aquí tienes tu video.* 😏'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en xnxx:', error);
        await message.reply('❌ Ocurrió un error al obtener o enviar el video. Intenta nuevamente.');
    }
};

handlerXnxx.help = ['xnxx <titulo o link>'];
handlerXnxx.tags = ['videos', 'nsfw'];
handlerXnxx.command = /^(xnxx)$/i;

// Exportar ambos handlers
module.exports.xnxxsearch = handlerXnxxSearch;
module.exports.xnxx = handlerXnxx;