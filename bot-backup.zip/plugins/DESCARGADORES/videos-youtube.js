const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300 // Límite de 300 MB para videos
const TIMEOUT_MS = 60000

// ===============================
// API ROBLEUY
// ===============================
async function getFromRobleuy(url) {
  const endpoint = `https://www.robleuy.site/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('Robleuy: no download_url')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    duration: null,
    thumbnail: null
  }
}

// ===============================
// API SANKA
// ===============================
async function getFromSanka(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.status) throw new Error('Sanka: API error')
  const { download, title, duration, thumbnail } = res.data.result
  if (!download) throw new Error('Sanka: No download link')
  return { download, title, duration, thumbnail }
}

// ===============================
// OBTENER VIDEO (ambas en paralelo, gana la más rápida)
// ===============================
async function getVideoData(url) {
  return Promise.any([
    getFromRobleuy(url),
    getFromSanka(url)
  ])
}

// ===============================
// BUSCAR VIDEO
// ===============================
async function searchYouTube(query) {
  const result = await yts(query)
  if (!result?.videos?.length) throw new Error('No se encontraron resultados')
  return result.videos[0].url
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    let youtubeUrl = text

    if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
      await message.reply('🔎 Buscando video...')
      youtubeUrl = await searchYouTube(text)
    }

    await message.reply('⏳ Descargando video...')

    const { download, title, duration, thumbnail } = await getVideoData(youtubeUrl)

    let tempFile = null;

    try {
      // Descargar con límite de tamaño
      const downloadData = await downloadWithLimit(download, LIMIT_MB)
      tempFile = downloadData.tempFile
      const sizeMB = downloadData.sizeMB

      console.log(`[VIDEO] ${title} | ${sizeMB} MB`)

      // Enviar thumbnail primero
      if (thumbnail) {
        await conn.sendMessage(
          message.from,
          {
            image: { url: thumbnail },
            caption: `🎬 *${title}*\n⏱️ Duración: ${duration}\n📦 Tamaño: ${sizeMB} MB\n\n_El video se está enviando..._`
          },
          { quoted: message._baileyMessage }
        )
      }

      // Enviar video
      await conn.sendMessage(
        message.from,
        {
          video: downloadData.buffer,
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption: `🎬 *${title}*`
        },
        { quoted: message._baileyMessage }
      )

      console.log('[VIDEO] Enviado correctamente')

    } catch (downloadError) {
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      // Limpiar archivo temporal
      if (tempFile) {
        cleanupTempFile(tempFile)
      }
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ Error descargando el video\n\nPosibles causas:\n• link inválido\n• video privado\n• servidor caído`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler