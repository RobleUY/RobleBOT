const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yts = require('yt-search');

// ===============================
const COMANDO_ACTIVADO = true;
const LIMIT_MB = 500;
const DOCUMENT_THRESHOLD_MB = 100;
const TIMEOUT_MS = 60000;
const DESCARGAS_DIR = path.join(__dirname, '.temp');
const COOLDOWN_MS = 30 * 1000;

// Usuarios sin cooldown
const NO_COOLDOWN_USERS = [
'59893900470@s.whatsapp.net',
'149078365237384@lid',
'59892099606@s.whatsapp.net',
'106502773850321@lid'
];

require('events').EventEmitter.defaultMaxListeners = 50;

if (!fs.existsSync(DESCARGAS_DIR)) fs.mkdirSync(DESCARGAS_DIR, { recursive: true });

// ===============================
const cooldowns = new Map();
const enDescarga = new Set();

// ===============================
function estimateUploadTime(sizeMB) {

const uploadSpeedMBPerSecond = 3.17;
const estimatedSeconds = Math.ceil(sizeMB / uploadSpeedMBPerSecond);

if (estimatedSeconds < 30) {
return 'unos pocos segundos';
}

else if (estimatedSeconds < 60) {
return `aproximadamente ${estimatedSeconds} segundos`;
}

else {

const minutes = Math.ceil(estimatedSeconds / 60);

if (minutes === 1) return 'aproximadamente 1 minuto';

return `aproximadamente ${minutes} minutos`;

}

}

// ===============================
async function getYouTubeInfo(url) {

try {

const videoId = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/))([^&\n?#]+)/)?.[1];

if (!videoId) throw new Error('ID inválido');

const search = await yts({ videoId });

return {

title: search.title || 'Video de YouTube',
thumbnail: search.thumbnail || search.image || null

};

}

catch {

return {

title: 'Video de YouTube',
thumbnail: null

};

}

}

// ===============================
async function getFromDarli(url) {

const endpoint = `http://darli.hidencloud.com:24667/mp4?url=${encodeURIComponent(url)}`;

try {

return {

success: true,
download: endpoint,
api: 'Darli API'

};

}

catch (e) {

return { success: false };

}

}

// ===============================
async function getFromDelirius(url) {

try {

const endpoint = `https://delirius-apiofc.vercel.app/download/ytmp4?url=${encodeURIComponent(url)}`;

const res = await axios.get(endpoint, { timeout: TIMEOUT_MS });

if (!res.data?.status) throw new Error();

return {

success: true,
download: res.data.data.download.url,
api: 'Delirius API'

};

}

catch {

return { success: false };

}

}

// ===============================
async function getFromSanka(url) {

try {

const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`;

const res = await axios.get(endpoint, { timeout: TIMEOUT_MS });

if (!res.data?.status) throw new Error();

const result = res.data.result;

if (!result?.download) throw new Error();

return {

success: true,
download: result.download,
title: result.title,
thumbnail: result.thumbnail,
api: 'Sanka API'

};

}

catch (e) {

console.log('[SANKA] Error', e?.message);

return { success: false };

}

}

// ===============================
async function getVideoData(url) {

console.log('Buscando API funcional...');

let res = await getFromDarli(url);

if (res.success) return res;

res = await getFromDelirius(url);

if (res.success) return res;

res = await getFromSanka(url);

if (res.success) return res;

throw new Error('Todas las APIs fallaron');

}

// ===============================
async function searchYouTube(query) {

const res = await yts(query);

if (!res.videos.length) throw new Error();

return res.videos[0].url;

}

// ===============================
let handler = async (m, { conn, text, command, usedPrefix }) => {

if (!COMANDO_ACTIVADO)
return m.reply('⚠️ Comando desactivado');

if (!text)
return m.reply(`❌ Envíe un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} lana del rey`);

const sender = m.sender;
const now = Date.now();

if (enDescarga.has(sender))
return m.reply('⚠️ Ya tienes una descarga en curso');

if (!NO_COOLDOWN_USERS.includes(sender)) {

const last = cooldowns.get(sender);

if (last && now - last < COOLDOWN_MS) {

const restante = Math.ceil((COOLDOWN_MS - (now - last)) / 1000);

return m.reply(`⏳ Espera ${restante}s`);

}

}

enDescarga.add(sender);

try {

await m.reply('🔎 Buscando video...');

let youtubeUrl = text;

if (!youtubeUrl.includes('youtu'))

youtubeUrl = await searchYouTube(text);

const videoInfo = await getYouTubeInfo(youtubeUrl);

const apiData = await getVideoData(youtubeUrl);

const title = apiData.title || videoInfo.title;
const thumb = apiData.thumbnail || videoInfo.thumbnail;

const safeName = title.replace(/[\\/:*?"<>|]/g, '').slice(0,60)+'.mp4';

const filePath = path.join(DESCARGAS_DIR, safeName);

const response = await axios({

url: apiData.download,
method: 'GET',
responseType: 'stream',
timeout: 120000

});

const contentLength = response.headers['content-length'];

const sizeMB = contentLength
? (contentLength / 1024 / 1024).toFixed(2)
: 'desconocido';

if (thumb) {

await conn.sendMessage(m.chat,{
image:{url:thumb},
caption:
`📹 *Información del Video*\n\n`+
`📌 *Título:* ${title}\n`+
`📦 *Tamaño:* ${sizeMB} MB\n`+
`🌐 *API:* ${apiData.api}\n\n`+
`⏳ Descargando...`
},{quoted:m})

}

const writer = fs.createWriteStream(filePath);

let size = 0;

response.data.on('data', chunk => size += chunk.length);

response.data.pipe(writer);

await new Promise((res,rej)=>{
writer.on('finish',res);
writer.on('error',rej);
});

const finalSize = (size/1024/1024).toFixed(2);

if (finalSize > LIMIT_MB) {

fs.unlinkSync(filePath);

return m.reply(`⚠️ El video pesa ${finalSize}MB y supera el límite`);

}

if (finalSize >= DOCUMENT_THRESHOLD_MB) {

await conn.sendMessage(m.chat,{
document:{url:filePath},
mimetype:'video/mp4',
fileName:title+'.mp4',
caption:`🎬 ${title}\n📦 ${finalSize} MB`
},{quoted:m})

}

else {

await conn.sendMessage(m.chat,{
video:{url:filePath},
mimetype:'video/mp4',
caption:`🎬 ${title}\n📦 ${finalSize} MB`
},{quoted:m})

}

if (!NO_COOLDOWN_USERS.includes(sender))
cooldowns.set(sender, Date.now());

await fs.promises.unlink(filePath).catch(()=>{});

}

catch(e){

console.log(e);

m.reply(`❌ Error descargando el video`);

}

finally{

enDescarga.delete(sender);

}

};

handler.help = ['ytvideo','videoyt','ytmp4'];
handler.tags = ['downloader'];
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video)$/i;

module.exports = handler;