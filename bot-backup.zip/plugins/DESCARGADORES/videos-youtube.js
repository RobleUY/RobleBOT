const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000
const DESCARGAS_DIR = path.join(__dirname, 'descargas')

if (!fs.existsSync(DESCARGAS_DIR)) {
  fs.mkdirSync(DESCARGAS_DIR, { recursive: true })
}

// ===============================
// API ROBLEUY
// ===============================
async function getFromRobleuy(url) {
  const endpoint = `https://www.robleuy.site/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('Robleuy: no download_url')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    duration: null,
    thumbnail: null
  }
}

// ===============================
// API SANKA
// ===============================
async function getFromSanka(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.status) throw new Error('Sanka: API error')
  const { download, title, duration, thumbnail } = res.data.result
  if (!download) throw new Error('Sanka: No download link')
  return { download, title, duration, thumbnail }
}

// ===============================
// OBTENER VIDEO (ambas en paralelo, gana la más rápida)
// ===============================
async function getVideoData(url) {
  return Promise.any([
    getFromRobleuy(url),
    getFromSanka(url)
  ])
}

// ===============================
// BUSCAR VIDEO
// ===============================
async function searchYouTube(query) {
  const result = await yts(query)
  if (!result?.videos?.length) throw new Error('No se encontraron resultados')
  return result.videos[0].url
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    let youtubeUrl = text

    if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
      await message.reply('🔎 Buscando video...')
      youtubeUrl = await searchYouTube(text)
    }

    await message.reply('⏳ Descargando video...')

    const { download, title, duration, thumbnail } = await getVideoData(youtubeUrl)

    const safeName = title.replace(/[\\/:*?"<>|]/g, '').slice(0, 60) + '.mp4'
    const filePath = path.join(DESCARGAS_DIR, safeName)

    const response = await axios({
      url: download,
      method: 'GET',
      responseType: 'stream',
      timeout: 120000
    })

    const writer = fs.createWriteStream(filePath)
    let size = 0
    response.data.on('data', chunk => size += chunk.length)
    response.data.pipe(writer)

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve)
      writer.on('error', reject)
    })

    const sizeMB = (size / (1024 * 1024)).toFixed(2)
    console.log(`[VIDEO] ${title} | ${sizeMB} MB`)

    if (sizeMB > LIMIT_MB) {
      // Demasiado grande: enviar como documento
      if (thumbnail) {
        await conn.sendMessage(
          message.from,
          {
            image: { url: thumbnail },
            caption: `🎬 *${title}*\n⏱️ Duración: ${duration}\n📦 Tamaño: ${sizeMB} MB\n\n_El video se está enviando..._`
          },
          { quoted: message._baileyMessage }
        )
      }

      await conn.sendMessage(
        message.from,
        {
          document: { url: filePath },
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption: `🎬 *${title}*\n⚠️ Archivo grande (${sizeMB} MB), enviado como documento`
        },
        { quoted: message._baileyMessage }
      )
    } else {
      // Tamaño normal: enviar como video
      if (thumbnail) {
        await conn.sendMessage(
          message.from,
          {
            image: { url: thumbnail },
            caption: `🎬 *${title}*\n⏱️ Duración: ${duration}\n📦 Tamaño: ${sizeMB} MB\n\n_El video se está enviando..._`
          },
          { quoted: message._baileyMessage }
        )
      }

      await conn.sendMessage(
        message.from,
        {
          video: { url: filePath },
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption: `🎬 *${title}*`
        },
        { quoted: message._baileyMessage }
      )
    }

    await fs.promises.unlink(filePath).catch(() => {})
    console.log('[VIDEO] Archivo eliminado')

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ Error descargando el video\n\nPosibles causas:\n• link inválido\n• video privado\n• servidor caído`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler