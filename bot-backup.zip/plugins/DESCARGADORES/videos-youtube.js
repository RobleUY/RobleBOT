const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { execFile } = require('child_process')
const { promisify } = require('util')
const downloadUtils = require('../../downloadUtils')
const { downloadWithLimit, cleanupTempFile, TEMP_DIR } = downloadUtils
const downloadYouTubeMedia = typeof downloadUtils.downloadYouTubeMedia === 'function'
  ? downloadUtils.downloadYouTubeMedia
  : async (url, format, timeout = 60000) => {
      if (format !== 'ytmp3' && format !== 'ytmp4') {
        throw new Error(`Formato de descarga de YouTube no soportado: ${format}`)
      }
      const response = await axios.get(
        `https://robleapi.vercel.app/download/${format}?url=${encodeURIComponent(url)}`,
        { timeout }
      )
      const data = response.data
      if (!data?.ok || typeof data.download_url !== 'string' || !data.download_url) {
        throw new Error(`RobleAPI no devolvió un enlace válido para ${format}`)
      }
      return {
        download: data.download_url,
        title: data.title || (format === 'ytmp3' ? 'Audio' : 'Video'),
        source: 'RobleAPI'
      }
    }
const execFileAsync = promisify(execFile)

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 200 // Límite de 200 MB para videos
const TIMEOUT_MS = 60000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

// ===============================
// EXTRACCIÓN E INFO DE YOUTUBE
// ===============================
function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function parseISODuration(iso) {
  if (!iso) return null
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return null
  const h = parseInt(m[1] || '0', 10)
  const min = parseInt(m[2] || '0', 10)
  const s = parseInt(m[3] || '0', 10)
  const pad = n => String(n).padStart(2, '0')
  if (h > 0) return `${h}:${pad(min)}:${pad(s)}`
  return `${min}:${pad(s)}`
}

function buildInfo(videoId, snippet, contentDetails) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl,
    duration: parseISODuration(contentDetails?.duration)
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró video en Data API')
  return buildInfo(videoId, item.snippet, item.contentDetails)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=id&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item?.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return await getVideoInfoById(item.id.videoId)
}

async function searchVideoInfoByHtml(query) {
  console.log('[VIDEO INFO] Consultando búsqueda YouTube HTML fallback...')
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  const videoId = match[1]
  return await getVideoInfoById(videoId)
}

// Carrera ultra veloz para resolver título y miniatura al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search (muy rápido)
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null,
        duration: v.timestamp || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[VIDEO INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[VIDEO INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    if (!isLink && typeof text === 'string') {
      try {
        return await searchVideoInfoByHtml(text)
      } catch (htmlErr) {
        console.error('[VIDEO INFO] Fallback HTML falló:', htmlErr.message)
      }
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ===============================
// DESCARGA DE VIDEO
// ===============================

async function downloadVideo(url) {
  console.log('[VIDEO] Consultando RobleAPI...')
  return downloadYouTubeMedia(url, 'ytmp4', TIMEOUT_MS)
}

const { 
  isDownloading, 
  startDownload, 
  trackTempFile, 
  cancelDownload, 
  finishDownload 
} = require('../../lib/downloadManager')

// ===============================
// FIX COMPATIBILIDAD MÓVIL
// ===============================
// WhatsApp Android requiere H.264/AAC con moov atom al inicio (faststart).
// Usamos fs.promises (asíncrono) para NO congelar el Event Loop de Node.js durante la conversión.

async function fixVideoForMobile(inputBuffer, signal = null) {
  if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
  const inputPath = path.join(TEMP_DIR, `fix_in_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  const outputPath = path.join(TEMP_DIR, `fix_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  try {
    await fs.promises.writeFile(inputPath, inputBuffer)
    if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')

    // Paso 1: intentar remuxing sin recodificar (instantáneo, mismo tamaño)
    try {
      await execFileAsync('ffmpeg', [
        '-y', '-i', inputPath,
        '-c', 'copy',
        '-movflags', '+faststart',
        outputPath
      ], { windowsHide: true, timeout: 30_000 })

      if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
      const fixed = await fs.promises.readFile(outputPath)
      if (fixed.length > 50 * 1024) {
        console.log(`[VIDEO] ✅ Fix móvil (remux, sin recodificar): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
        return fixed
      }
    } catch (remuxErr) {
      if (remuxErr.message === 'DOWNLOAD_ABORTED' || signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
      console.log(`[VIDEO] Remux directo no aplicable, recodificando...`)
      try { await fs.promises.unlink(outputPath) } catch {}
    }

    if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')

    // Paso 2: recodificar a H.264/AAC solo si el remux falló
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-c:v', 'libx264',
      '-c:a', 'aac',
      '-movflags', '+faststart',
      '-preset', 'fast',
      '-crf', '28',
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      outputPath
    ], { windowsHide: true, timeout: 120_000 })

    if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
    const fixed = await fs.promises.readFile(outputPath)
    console.log(`[VIDEO] ✅ Fix móvil (recodificado H.264): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
    return fixed
  } finally {
    try { await fs.promises.unlink(inputPath) } catch {}
    try { await fs.promises.unlink(outputPath) } catch {}
  }
}

// ===============================
// VALIDACIÓN DE BUFFER
// ===============================
function isValidVideoBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 100 * 1024) return false // menos de 100 KB = inválido
  // MP4: "ftyp" en bytes 4-7
  if (buffer.length >= 8 &&
      buffer[4] === 0x66 && buffer[5] === 0x74 &&
      buffer[6] === 0x79 && buffer[7] === 0x70) return true
  // MP4 alternativo: box size en bytes 0-3
  if (buffer[0] === 0x00 && buffer[1] === 0x00 &&
      buffer[2] === 0x00 && buffer[3] >= 0x08) return true
  // Si pesa más de 1 MB asumimos válido
  if (buffer.length > 1024 * 1024) return true
  return false
}

// ===============================
// DESCARGA Y VALIDACION DEL BUFFER
// ===============================
async function getWorkingVideo(url, limitMb, signal = null) {
  if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')

  try {
    const data = await downloadVideo(url)
    if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')

    const downloadData = await downloadWithLimit(data.download, limitMb, {}, signal)
    if (!isValidVideoBuffer(downloadData.buffer)) {
      throw new Error('RobleAPI: downloaded video buffer is invalid or too small')
    }

    console.log(`[VIDEO] Video descargado mediante RobleAPI (${downloadData.sizeMB} MB)`)
    return { ...data, downloadData }
  } catch (error) {
    if (signal?.aborted || error.message === 'DOWNLOAD_ABORTED') {
      throw new Error('DOWNLOAD_ABORTED')
    }
    if (error.message?.startsWith('LIMIT_EXCEEDED:')) throw error
    console.error('[VIDEO] Error en RobleAPI:', error.message)
    throw new Error('No se pudo descargar el video en este momento.')
  }
}

// ===============================

// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn
  const userId = message.author || message.sender
  const chatId = message.from
  const cleanInput = (text || '').trim().toLowerCase()

  // 1. Comando de Cancelación/Detener
  if (['stop', 'cancel', 'detener', 'cancelar'].includes(cleanInput)) {
    const wasCanceled = cancelDownload(chatId, userId)
    if (wasCanceled) {
      return await message.reply('🛑 *Descarga de video cancelada correctamente.*')
    } else {
      return await message.reply('ℹ️ *No tienes ninguna descarga en curso para cancelar.*')
    }
  }

  if (!text) {
    return message.reply(
      `❌ Debes enviar un enlace o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda\n*Para cancelar:* ${usedPrefix + command} stop`
    )
  }

  // 2. Control de Concurrencia por Usuario: 1 sola descarga activa a la vez
  if (isDownloading(chatId, userId)) {
    return await message.reply(
      `⚠️ *Ya tienes una descarga en curso.*\nPor favor espera a que termine o usa *${usedPrefix + command} stop* para cancelarla.`
    )
  }

  let downloadObj = null
  let tempFile = null

  try {
    downloadObj = startDownload(chatId, userId, 'video', text)
    const { signal } = downloadObj

    const isLink = text.includes('youtube.com') || text.includes('youtu.be')

    await message.reply(isLink ? '⏳ Descargando video...' : '🔎 Buscando video...')

    if (signal.aborted) return

    // 1) Resolver la información y miniatura lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    if (signal.aborted) return

    const youtubeUrl = videoInfo.url

    // 2) Enviar la miniatura inmediatamente
    const sendThumbnailTask = (async () => {
      try {
        if (videoInfo.thumbnailUrl && !signal.aborted) {
          await sock.sendMessage(
            message.from,
            {
              image: { url: videoInfo.thumbnailUrl },
              caption: `🎬 *${videoInfo.title}*${videoInfo.duration ? `\n⏱️ Duración: ${videoInfo.duration}` : ''}\n\n_Descargando video..._\n_Para cancelar usa: ${usedPrefix + command} stop_`
            },
            { quoted: message._baileyMessage }
          )
        }
      } catch (thumbError) {
        console.error('[VIDEO] No se pudo enviar la miniatura:', thumbError.message)
      }
    })()

    // 3) Descargar video y enviar el archivo
    const sendVideoTask = (async () => {
      const { title, source, downloadData } = await getWorkingVideo(youtubeUrl, LIMIT_MB, signal)
      if (signal.aborted) return

      tempFile = downloadData.tempFile
      if (tempFile) trackTempFile(chatId, userId, tempFile)

      const sizeMB = downloadData.sizeMB

      let videoBuffer = downloadData.buffer
      try {
        console.log(`[VIDEO] Aplicando fix H.264/faststart para compatibilidad Android/iOS...`)
        videoBuffer = await fixVideoForMobile(videoBuffer, signal)
      } catch (fixErr) {
        if (fixErr.message === 'DOWNLOAD_ABORTED' || signal.aborted) return
        console.warn(`[VIDEO] ⚠️ Fix móvil falló (${fixErr.message}), enviando buffer original`)
      }

      if (signal.aborted) return
      console.log(`[VIDEO] 🚀 Enviando a WhatsApp video descargado vía ${source} (${sizeMB} MB)...`)

      await sock.sendMessage(
        message.from,
        {
          video: videoBuffer,
          mimetype: 'video/mp4',
          fileName: `${videoInfo.title || title}.mp4`,
          caption: `🎬 *${videoInfo.title || title}*`
        },
        { quoted: message._baileyMessage }
      )

      console.log(`[VIDEO] ✅ Video enviado a WhatsApp con éxito (vía ${source})`)
    })()

    await Promise.all([sendThumbnailTask, sendVideoTask])

  } catch (downloadError) {
    if (downloadError.message === 'DOWNLOAD_ABORTED' || downloadObj?.signal?.aborted) {
      console.log('[VIDEO] 🛑 Descarga cancelada por el usuario.')
      return
    }
    console.error('[VIDEO] Error en descarga:', downloadError.message)
    if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
      const sizeMB = downloadError.message.split(':')[1]
      return await message.reply(
        `❌ *EL VIDEO SUPERA EL LÍMITE PERMITIDO*\n\n` +
        `📦 *Tamaño del video:* ${sizeMB} MB\n` +
        `⚠️ *Límite máximo para video:* ${LIMIT_MB} MB\n\n` +
        `💡 _Intenta con un video más corto o de menor resolución._`
      )
    }
    await message.reply(
      `❌ *NO SE PUDO DESCARGAR EL VIDEO*\n\n` +
      `📌 *Motivo:* ${downloadError.message?.includes('No se obtuvo') || downloadError.message?.includes('No se pudo resolver') ? 'No se encontraron resultados para tu búsqueda.' : 'Las fuentes de descarga no están disponibles en este momento o el video es privado.'}\n\n` +
      `💡 _Verifica el enlace o nombre e intenta nuevamente._`
    )
  } finally {
    finishDownload(chatId, userId)
    if (tempFile) cleanupTempFile(tempFile)
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>', 'video stop']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler