const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000
const DESCARGAS_DIR = path.join(__dirname, 'descargas')

// crear carpeta
if (!fs.existsSync(DESCARGAS_DIR)) {
fs.mkdirSync(DESCARGAS_DIR, { recursive: true })
}

// ===============================
// API SANKA
// ===============================
async function getFromSanka(url) {

const endpoint =
`https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`

const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

if (!res.data?.status) throw new Error('API error')

const { download, title, duration, thumbnail } = res.data.result

if (!download) throw new Error('No download link')

return { download, title, duration, thumbnail }

}

// ===============================
// BUSCAR VIDEO
// ===============================
async function searchYouTube(query) {

const result = await yts(query)

if (!result?.videos?.length)
throw new Error('No se encontraron resultados')

return result.videos[0].url

}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {

try {

if (!text) {
return message.reply(
`❌ Debes enviar un link o búsqueda

Ejemplo:
${usedPrefix + command} https://youtu.be/kLpH1nSLJSs
${usedPrefix + command} Bad Bunny Amorfoda`
)
}

let youtubeUrl = text

// buscar si no es link
if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {

await message.reply('🔎 Buscando video...')

youtubeUrl = await searchYouTube(text)

}

await message.reply('⏳ Descargando video...')

// obtener datos
const { download, title, duration, thumbnail } =
await getFromSanka(youtubeUrl)

// nombre seguro
const safeName =
title.replace(/[\\/:*?"<>|]/g, '').slice(0, 60) + '.mp4'

const filePath = path.join(DESCARGAS_DIR, safeName)

// descargar
const response = await axios({
url: download,
method: 'GET',
responseType: 'stream',
timeout: 120000
})

const writer = fs.createWriteStream(filePath)

let size = 0

response.data.on('data', chunk => size += chunk.length)

response.data.pipe(writer)

await new Promise((resolve, reject) => {
writer.on('finish', resolve)
writer.on('error', reject)
})

const sizeMB = (size / (1024 * 1024)).toFixed(2)

console.log(`[VIDEO] ${title} | ${sizeMB} MB`)

// verificar peso
if (sizeMB > LIMIT_MB) {

await message.reply(
`⚠️ El video pesa ${sizeMB}MB y supera el límite de ${LIMIT_MB}MB`
)

fs.unlinkSync(filePath)

return
}

// enviar thumbnail
if (thumbnail) {

await conn.sendMessage(
message.from,
{
image: { url: thumbnail },
caption:
`🎬 *${title}*
⏱️ Duración: ${duration}
📦 Tamaño: ${sizeMB} MB

_El video se está enviando..._`
},
{ quoted: message._baileyMessage }
)

}

// enviar documento
await conn.sendMessage(
message.from,
{
document: { url: filePath },
mimetype: 'video/mp4',
fileName: `${title}.mp4`,
caption: `🎬 *${title}*`
},
{ quoted: message._baileyMessage }
)

// limpiar
await fs.promises.unlink(filePath).catch(()=>{})

console.log('[VIDEO] Archivo eliminado')

} catch (err) {

console.error('[VIDEO ERROR]', err?.message || err)

await message.reply(
`❌ Error descargando el video

Posibles causas:
• link inválido
• video privado
• servidor caído`
)

}

}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video)$/i

module.exports = handler