const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { execFile } = require('child_process')
const { promisify } = require('util')
const { downloadWithLimit, cleanupTempFile, TEMP_DIR } = require('../../downloadUtils')
const execFileAsync = promisify(execFile)

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

// ===============================
// EXTRACCIÓN E INFO DE YOUTUBE
// ===============================
function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function parseISODuration(iso) {
  if (!iso) return null
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return null
  const h = parseInt(m[1] || '0', 10)
  const min = parseInt(m[2] || '0', 10)
  const s = parseInt(m[3] || '0', 10)
  const pad = n => String(n).padStart(2, '0')
  if (h > 0) return `${h}:${pad(min)}:${pad(s)}`
  return `${min}:${pad(s)}`
}

function buildInfo(videoId, snippet, contentDetails) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl,
    duration: parseISODuration(contentDetails?.duration)
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró video en Data API')
  return buildInfo(videoId, item.snippet, item.contentDetails)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=id&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item?.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return await getVideoInfoById(item.id.videoId)
}

// Carrera ultra veloz para resolver título y miniatura al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search (muy rápido)
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null,
        duration: v.timestamp || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[VIDEO INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[VIDEO INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    return {
      videoId: null,
      title: 'video',
      url: text,
      thumbnailUrl: null,
      duration: null
    }
  }
}

// ===============================
// APIS DE DESCARGA (4 FUENTES EN PARALELO)
// ===============================

// Fuente 1: Roble
async function getFromAPI1(url) {
  const endpoint = `https://robleuy.vercel.app/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente API1-Roble...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('API1_FAIL')
  console.log('[VIDEO] ✅ Fuente API1-Roble entregó resultado')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    source: 'API1-Roble'
  }
}

// Fuente 2: Sanka .com
async function getFromAPI2(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente API2-SankaCom...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.status || (!res.data.result?.download && !res.data.result?.downloadURL)) throw new Error('API2_FAIL')
  const downloadUrl = res.data.result.download || res.data.result.downloadURL
  console.log('[VIDEO] ✅ Fuente API2-SankaCom entregó resultado')
  return {
    download: downloadUrl,
    title: res.data.result.title || 'video',
    source: 'API2-SankaCom'
  }
}

// Fuente 3: Delirius
async function getFromAPI3(url) {
  const endpoint = `https://api.delirius.store/download/ytmp4?url=${encodeURIComponent(url)}&format=360p`
  console.log('[VIDEO] Consultando fuente API3-Delirius...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.status || !res.data?.data?.download) throw new Error('API3_FAIL')
  console.log('[VIDEO] ✅ Fuente API3-Delirius entregó resultado')
  return {
    download: res.data.data.download,
    title: res.data.data.title || 'video',
    source: 'API3-Delirius'
  }
}

// Fuente 4: Sanka .web.id
async function getFromAPI4(url) {
  const endpoint = `https://www.sankavollerei.web.id/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente API4-SankaWebId...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.status || (!res.data.result?.download && !res.data.result?.downloadURL)) throw new Error('API4_FAIL')
  const downloadUrl = res.data.result.download || res.data.result.downloadURL
  console.log('[VIDEO] ✅ Fuente API4-SankaWebId entregó resultado')
  return {
    download: downloadUrl,
    title: res.data.result.title || 'video',
    source: 'API4-SankaWebId'
  }
}

// ===============================
// FIX COMPATIBILIDAD MÓVIL
// ===============================
// WhatsApp Android requiere H.264/AAC con moov atom al inicio (faststart).
// Siempre recodificamos el video descargado para garantizar compatibilidad,
// independientemente del codec o formato que entregue la fuente (VP9, AV1, etc.)

async function fixVideoForMobile(inputBuffer) {
  const inputPath = path.join(TEMP_DIR, `fix_in_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  const outputPath = path.join(TEMP_DIR, `fix_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  try {
    fs.writeFileSync(inputPath, inputBuffer)

    // Paso 1: intentar remuxing sin recodificar (instantáneo, mismo tamaño)
    // Funciona si el video ya viene en H.264/AAC — solo mueve el moov al inicio
    try {
      await execFileAsync('ffmpeg', [
        '-y', '-i', inputPath,
        '-c', 'copy',
        '-movflags', '+faststart',
        outputPath
      ], { windowsHide: true, timeout: 30_000 })

      const fixed = fs.readFileSync(outputPath)
      // Verificar que el output es un MP4 válido y tiene tamaño razonable
      if (fixed.length > 50 * 1024) {
        console.log(`[VIDEO] ✅ Fix móvil (remux, sin recodificar): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
        return fixed
      }
    } catch (remuxErr) {
      console.log(`[VIDEO] Remux directo no aplicable (${remuxErr.message.split('\n')[0]}), recodificando...`)
      // Limpiar output parcial si existe
      try { fs.unlinkSync(outputPath) } catch {}
    }

    // Paso 2: recodificar a H.264/AAC solo si el remux falló (video en VP9/AV1/OPUS)
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-c:v', 'libx264',
      '-c:a', 'aac',
      '-movflags', '+faststart',
      '-preset', 'fast',
      '-crf', '28',
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      outputPath
    ], { windowsHide: true, timeout: 120_000 })

    const fixed = fs.readFileSync(outputPath)
    console.log(`[VIDEO] ✅ Fix móvil (recodificado H.264): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
    return fixed
  } finally {
    try { fs.unlinkSync(inputPath) } catch {}
    try { fs.unlinkSync(outputPath) } catch {}
  }
}

// ===============================
// VALIDACIÓN DE BUFFER
// ===============================
function isValidVideoBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 100 * 1024) return false // menos de 100 KB = inválido
  // MP4: "ftyp" en bytes 4-7
  if (buffer.length >= 8 &&
      buffer[4] === 0x66 && buffer[5] === 0x74 &&
      buffer[6] === 0x79 && buffer[7] === 0x70) return true
  // MP4 alternativo: box size en bytes 0-3
  if (buffer[0] === 0x00 && buffer[1] === 0x00 &&
      buffer[2] === 0x00 && buffer[3] >= 0x08) return true
  // Si pesa más de 1 MB asumimos válido
  if (buffer.length > 1024 * 1024) return true
  return false
}

// ===============================
// CARRERA DE DESCARGA: TODAS EN PARALELO, GANA LA PRIMERA EN COMPLETAR EL BUFFER
// ===============================
async function getWorkingVideo(url, limitMb) {
  const sources = [
    { name: 'API1-Roble', fn: getFromAPI1 },
    { name: 'API2-SankaCom', fn: getFromAPI2 },
    { name: 'API3-Delirius', fn: getFromAPI3 },
    { name: 'API4-SankaWebId', fn: getFromAPI4 }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(url)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []
  let limitExceededError = null

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[VIDEO] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[VIDEO] ${sourceName} entregó metadata, descargando archivo...`)

    try {
      let downloadData
      if (Buffer.isBuffer(result.data.download)) {
        // Validar buffer directo
        if (!isValidVideoBuffer(result.data.download)) {
          console.log(`[VIDEO] ${sourceName} buffer directo inválido o muy pequeño, probando siguiente...`)
          errors.push(`${sourceName}: buffer inválido`)
          continue
        }
        downloadData = {
          buffer: result.data.download,
          size: result.data.download.length,
          tempFile: null,
          sizeMB: (result.data.download.length / (1024 * 1024)).toFixed(2)
        }
      } else {
        downloadData = await downloadWithLimit(result.data.download, limitMb)
        // Validar buffer descargado
        if (!isValidVideoBuffer(downloadData.buffer)) {
          console.log(`[VIDEO] ${sourceName} buffer descargado inválido o muy pequeño, probando siguiente...`)
          errors.push(`${sourceName}: buffer descargado inválido`)
          continue
        }
      }
      console.log(`[VIDEO] 🏆 ¡GANADORA DE VIDEO! ${sourceName} descargó el video exitosamente (${downloadData.sizeMB} MB)`)
      return { ...result.data, downloadData }
    } catch (downloadError) {
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        limitExceededError = downloadError
        console.log(`[VIDEO] ${sourceName} excede el límite de peso, probando siguiente...`)
        continue
      }
      console.log(`[VIDEO] ${sourceName} tuvo error en descarga (${downloadError.message}), probando siguiente...`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  if (limitExceededError) throw limitExceededError
  console.error('[VIDEO] Todas las fuentes de video fallaron:', errors.join(' | '))
  throw new Error('No se pudo descargar el video en este momento.')
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un enlace o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    const isLink = text.includes('youtube.com') || text.includes('youtu.be')

    await message.reply(isLink ? '⏳ Descargando video...' : '🔎 Buscando video...')

    // 1) Resolver la información y miniatura lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    const youtubeUrl = videoInfo.url

    let tempFile = null

    try {
      // 2) Tarea A: Enviar la miniatura inmediatamente
      const sendThumbnailTask = (async () => {
        try {
          if (videoInfo.thumbnailUrl) {
            await sock.sendMessage(
              message.from,
              {
                image: { url: videoInfo.thumbnailUrl },
                caption: `🎬 *${videoInfo.title}*${videoInfo.duration ? `\n⏱️ Duración: ${videoInfo.duration}` : ''}\n\n_Descargando video..._`
              },
              { quoted: message._baileyMessage }
            )
          }
        } catch (thumbError) {
          console.error('[VIDEO] No se pudo enviar la miniatura:', thumbError.message)
        }
      })()

      // 3) Tarea B: Carrera de las 4 fuentes para descargar y enviar el video
      const sendVideoTask = (async () => {
        const { title, source, downloadData } = await getWorkingVideo(youtubeUrl, LIMIT_MB)
        tempFile = downloadData.tempFile
        const sizeMB = downloadData.sizeMB

        // Aplicar fix de compatibilidad móvil siempre:
        // - Garantiza codec H.264/AAC (WhatsApp Android rechaza VP9, AV1, OPUS)
        // - Mueve el moov atom al inicio (faststart) para reproducción sin descarga completa
        let videoBuffer = downloadData.buffer
        try {
          console.log(`[VIDEO] Aplicando fix H.264/faststart para compatibilidad Android/iOS...`)
          videoBuffer = await fixVideoForMobile(videoBuffer)
        } catch (fixErr) {
          console.warn(`[VIDEO] ⚠️ Fix móvil falló (${fixErr.message}), enviando buffer original`)
        }

        console.log(`[VIDEO] 🚀 Enviando a WhatsApp video descargado vía ${source} (${sizeMB} MB)...`)

        await sock.sendMessage(
          message.from,
          {
            video: videoBuffer,
            mimetype: 'video/mp4',
            fileName: `${videoInfo.title || title}.mp4`,
            caption: `🎬 *${videoInfo.title || title}*`
          },
          { quoted: message._baileyMessage }
        )

        console.log(`[VIDEO] ✅ Video enviado a WhatsApp con éxito (vía ${source})`)
      })()

      // Corren en paralelo
      await Promise.all([sendThumbnailTask, sendVideoTask])

    } catch (downloadError) {
      console.error('[VIDEO] Error en descarga:', downloadError.message)
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      if (tempFile) cleanupTempFile(tempFile)
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ *No se pudo descargar el video*\n\n` +
      `_Posibles causas: link inválido, video privado o no disponible en tu región._`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler