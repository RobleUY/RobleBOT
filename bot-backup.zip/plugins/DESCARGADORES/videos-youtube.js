const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ===============================
// CONFIGj
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000

// ===============================
// API 1
// ===============================
async function getFromAPI1(url) {
  const endpoint = `https://www.robleuy.site/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 1...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) {
    console.error('[VIDEO] API 1 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_1_FAIL')
  }
  console.log('[VIDEO] ✅ API 1 respondió primero')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    duration: null,
    thumbnail: null,
    source: 'API1'
  }
}

// ===============================
// API 2
// ===============================
async function getFromAPI2(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 2...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status) {
    console.error('[VIDEO] API 2 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_2_FAIL')
  }

  const result = res.data.result
  const downloadUrl = result?.download || result?.downloadURL
  if (!downloadUrl) {
    console.error('[VIDEO] API 2 sin URL de descarga:', JSON.stringify(result).slice(0, 200))
    throw new Error('API_2_NO_URL')
  }

  console.log('[VIDEO] ✅ API 2 respondió primero')
  return {
    download: downloadUrl,
    title: result.title || 'video',
    duration: result.duration || null,
    thumbnail: result.thumbnail || null,
    source: 'API2'
  }
}

// ===============================
// OBTENER VIDEO (ambas en paralelo, gana la más rápida)
// ===============================
async function getVideoData(url) {
  try {
    return await Promise.any([
      getFromAPI1(url),
      getFromAPI2(url)
    ])
  } catch (aggregateError) {
    const errors = aggregateError.errors?.map(e => e.message).join(' | ') ?? aggregateError.message
    console.error('[VIDEO] Todas las APIs fallaron:', errors)
    throw new Error('No se pudo obtener el video en este momento.')
  }
}

// ===============================
// BUSCAR VIDEO
// ===============================
async function searchYouTube(query) {
  const result = await yts(query)
  if (!result?.videos?.length) throw new Error('No se encontraron resultados en YouTube')
  return result.videos[0].url
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    let youtubeUrl = text

    if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
      await message.reply('🔎 Buscando video...')
      youtubeUrl = await searchYouTube(text)
    }

    await message.reply('⏳ Descargando video...')

    const { download, title, duration, thumbnail, source } = await getVideoData(youtubeUrl)
    console.log(`[VIDEO] Descargando desde ${source}: ${title}`)
    console.log(`[VIDEO] URL: ${download.slice(0, 80)}...`)

    let tempFile = null

    try {
      // downloadWithLimit ya incluye los headers necesarios internamente
      const downloadData = await downloadWithLimit(download, LIMIT_MB)
      tempFile = downloadData.tempFile
      const sizeMB = downloadData.sizeMB

      console.log(`[VIDEO] ✅ ${title} | ${sizeMB} MB | ${source}`)

      // Enviar thumbnail primero si está disponible
      if (thumbnail) {
        await sock.sendMessage(
          message.from,
          {
            image: { url: thumbnail },
            caption: `🎬 *${title}*${duration ? `\n⏱️ Duración: ${duration}` : ''}\n📦 Tamaño: ${sizeMB} MB\n\n_Enviando video..._`
          },
          { quoted: message._baileyMessage }
        )
      }

      // Enviar video
      await sock.sendMessage(
        message.from,
        {
          video: downloadData.buffer,
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption: `🎬 *${title}*`
        },
        { quoted: message._baileyMessage }
      )

      console.log('[VIDEO] Enviado correctamente')

    } catch (downloadError) {
      console.error('[VIDEO] Error en descarga:', downloadError.message)
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      if (tempFile) cleanupTempFile(tempFile)
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ *No se pudo descargar el video*\n\n` +
      `_Posibles causas: link inválido, video privado o no disponible en tu región._`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler
