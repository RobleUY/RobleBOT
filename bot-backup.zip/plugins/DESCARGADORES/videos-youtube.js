const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000

// ⚠️ Recomendado: mover a variable de entorno (process.env.YOUTUBE_API_KEY)
// y restringir la key en Google Cloud Console (solo YouTube Data API v3 + IP/referer).
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

// ===============================
// YOUTUBE DATA API V3 (miniatura + título + duración confiables)
// ===============================

function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

// Convierte duración ISO 8601 (PT1H2M10S) a "1:02:10" / "2:10"
function parseISODuration(iso) {
  if (!iso) return null
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return null
  const h = parseInt(m[1] || '0', 10)
  const min = parseInt(m[2] || '0', 10)
  const s = parseInt(m[3] || '0', 10)
  const pad = n => String(n).padStart(2, '0')
  if (h > 0) return `${h}:${pad(min)}:${pad(s)}`
  return `${min}:${pad(s)}`
}

function buildInfo(videoId, snippet, contentDetails) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl,
    duration: parseISODuration(contentDetails?.duration)
  }
}

// videos.list (1 unidad de cuota) - trae snippet + duración de una sola vez
async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 15000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró información del video en YouTube Data API')
  return buildInfo(videoId, item.snippet, item.contentDetails)
}

// search.list (100 unidades) solo para obtener el videoId, luego reusamos
// getVideoInfoById (1 unidad extra) para traer snippet+duración completos.
async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=id&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 15000 })
  const item = res.data.items?.[0]
  if (!item?.id?.videoId) throw new Error('No se encontraron resultados en YouTube')
  return await getVideoInfoById(item.id.videoId)
}

// Punto único de verdad: resuelve id/título/miniatura/duración, con
// respaldo a yt-search si la Data API falla (cuota, key inválida, etc.)
async function resolveVideoInfo(text, isLink) {
  try {
    if (isLink) {
      const videoId = extractVideoId(text)
      if (!videoId) throw new Error('No se pudo extraer el ID del video del link')
      return await getVideoInfoById(videoId)
    } else {
      return await searchVideoInfo(text)
    }
  } catch (ytApiError) {
    console.error('[VIDEO] YouTube Data API falló, usando respaldo yt-search:', ytApiError.message)
    if (isLink) {
      return { videoId: null, title: 'video', url: text, thumbnailUrl: null, duration: null }
    }
    const result = await yts(text)
    if (!result?.videos?.length) throw new Error('No se encontraron resultados en YouTube')
    const v = result.videos[0]
    return { videoId: null, title: v.title, url: v.url, thumbnailUrl: v.thumbnail || null, duration: v.timestamp || null }
  }
}

// ===============================
// API 1 - robleuy
// ===============================
async function getFromAPI1(url) {
  const endpoint = `https://robleuy.vercel.app/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 1 (Roble)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) {
    console.error('[VIDEO] API 1 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_1_FAIL')
  }
  console.log('[VIDEO] ✅ API 1 (Roble) respondió primero')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    duration: null,
    thumbnail: null,
    source: 'API1-Roble'
  }
}

// ===============================
// API 2 - sankavollerei.com
// ===============================
async function getFromAPI2(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 2 (Sanka .com)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status) {
    console.error('[VIDEO] API 2 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_2_FAIL')
  }

  const result = res.data.result
  const downloadUrl = result?.download || result?.downloadURL
  if (!downloadUrl) {
    console.error('[VIDEO] API 2 sin URL de descarga:', JSON.stringify(result).slice(0, 200))
    throw new Error('API_2_NO_URL')
  }

  console.log('[VIDEO] ✅ API 2 (Sanka .com) respondió primero')
  return {
    download: downloadUrl,
    title: result.title || 'video',
    duration: result.duration || null,
    thumbnail: result.thumbnail || null,
    source: 'API2-SankaCom'
  }
}

// ===============================
// API 3 - Delirius
// ===============================
async function getFromAPI3(url) {
  const endpoint = `https://api.delirius.store/download/ytmp4?url=${encodeURIComponent(url)}&format=360p`
  console.log('[VIDEO] Consultando API 3 (Delirius)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status || !res.data?.data?.download) {
    console.error('[VIDEO] API 3 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_3_FAIL')
  }

  const data = res.data.data
  console.log('[VIDEO] ✅ API 3 (Delirius) respondió primero')
  return {
    download: data.download,
    title: data.title || 'video',
    duration: null,
    thumbnail: data.image || null,
    source: 'API3-Delirius'
  }
}

// ===============================
// API 4 - sankavollerei.web.id
// ===============================
async function getFromAPI4(url) {
  const endpoint = `https://www.sankavollerei.web.id/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 4 (Sanka .web.id)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status) {
    console.error('[VIDEO] API 4 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_4_FAIL')
  }

  const result = res.data.result
  const downloadUrl = result?.download || result?.downloadURL
  if (!downloadUrl) {
    console.error('[VIDEO] API 4 sin URL de descarga:', JSON.stringify(result).slice(0, 200))
    throw new Error('API_4_NO_URL')
  }

  console.log('[VIDEO] ✅ API 4 (Sanka .web.id) respondió primero')
  return {
    download: downloadUrl,
    title: result.title || 'video',
    duration: result.duration || null,
    thumbnail: result.thumbnail || null,
    source: 'API4-SankaWebId'
  }
}

// ===============================
// OBTENER VIDEO + DESCARGAR (las 4 en paralelo, pero con fallback real)
// ===============================
// Importante: no basta con quedarse con la metadata más rápida (Promise.any),
// porque algunas APIs devuelven links directos de googlevideo.com que pueden
// dar 403 (expiran rápido o quedan atados a la IP del servidor que los generó).
// Por eso acá se prueba la DESCARGA de cada fuente en orden de llegada, y si
// una falla se pasa automáticamente a la siguiente sin tirar error.
async function getWorkingVideo(url, limitMb) {
  const sources = [
    { name: 'API1-Roble', fn: getFromAPI1 },
    { name: 'API2-SankaCom', fn: getFromAPI2 },
    { name: 'API3-Delirius', fn: getFromAPI3 },
    { name: 'API4-SankaWebId', fn: getFromAPI4 }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(url)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []
  let limitExceededError = null

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[VIDEO] ${sourceName} falló al obtener metadata: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[VIDEO] ${sourceName} respondió, probando descarga...`)

    try {
      const downloadData = await downloadWithLimit(result.data.download, limitMb)
      console.log(`[VIDEO] ✅ Descarga exitosa desde ${sourceName}`)
      return { ...result.data, downloadData }
    } catch (downloadError) {
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        limitExceededError = downloadError
        console.log(`[VIDEO] ${sourceName} excede el límite de tamaño, probando siguiente...`)
        continue
      }
      console.log(`[VIDEO] ${sourceName} obtuvo metadata pero la descarga falló (${downloadError.message}), probando siguiente...`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  if (limitExceededError) throw limitExceededError
  console.error('[VIDEO] Todas las fuentes fallaron:', errors.join(' | '))
  throw new Error('No se pudo descargar el video en este momento.')
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    const isLink = text.includes('youtube.com') || text.includes('youtu.be')

    await message.reply(isLink ? '⏳ Descargando video...' : '🔎 Buscando video...')

    // 1) Resolvemos el video UNA sola vez con YouTube Data API v3
    //    (mismo videoId/URL para la miniatura y para las 4 APIs de descarga)
    const videoInfo = await resolveVideoInfo(text, isLink)
    const youtubeUrl = videoInfo.url

    let tempFile = null

    try {
      // 2) Tarea A: enviar la miniatura ya (no espera la descarga del video)
      const sendThumbnailTask = (async () => {
        try {
          if (videoInfo.thumbnailUrl) {
            await sock.sendMessage(
              message.from,
              {
                image: { url: videoInfo.thumbnailUrl },
                caption: `🎬 *${videoInfo.title}*${videoInfo.duration ? `\n⏱️ Duración: ${videoInfo.duration}` : ''}\n\n_Descargando video..._`
              },
              { quoted: message._baileyMessage }
            )
          }
        } catch (thumbError) {
          console.error('[VIDEO] No se pudo enviar la miniatura:', thumbError.message)
        }
      })()

      // 3) Tarea B: probar las 4 fuentes y enviar el video (usa el MISMO youtubeUrl)
      const sendVideoTask = (async () => {
        const { title, source, downloadData } = await getWorkingVideo(youtubeUrl, LIMIT_MB)
        tempFile = downloadData.tempFile
        const sizeMB = downloadData.sizeMB

        console.log(`[VIDEO] ✅ ${title} | ${sizeMB} MB | ${source}`)

        await sock.sendMessage(
          message.from,
          {
            video: downloadData.buffer,
            mimetype: 'video/mp4',
            fileName: `${videoInfo.title || title}.mp4`,
            caption: `🎬 *${videoInfo.title || title}*`
          },
          { quoted: message._baileyMessage }
        )

        console.log('[VIDEO] Enviado correctamente')
      })()

      // 4) Ambas corren en paralelo: la miniatura llega casi al instante
      // mientras el video se descarga y se envía por detrás.
      await Promise.all([sendThumbnailTask, sendVideoTask])

    } catch (downloadError) {
      console.error('[VIDEO] Error en descarga:', downloadError.message)
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      if (tempFile) cleanupTempFile(tempFile)
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ *No se pudo descargar el video*\n\n` +
      `_Posibles causas: link inválido, video privado o no disponible en tu región._`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler