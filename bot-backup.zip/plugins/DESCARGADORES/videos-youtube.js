const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000

// ===============================
// API 1 - robleuy
// ===============================
async function getFromAPI1(url) {
  const endpoint = `https://www.robleuy.site/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 1 (Roble)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) {
    console.error('[VIDEO] API 1 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_1_FAIL')
  }
  console.log('[VIDEO] ✅ API 1 (Roble) respondió primero')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    duration: null,
    thumbnail: null,
    source: 'API1-Roble'
  }
}

// ===============================
// API 2 - sankavollerei.com
// ===============================
async function getFromAPI2(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 2 (Sanka .com)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status) {
    console.error('[VIDEO] API 2 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_2_FAIL')
  }

  const result = res.data.result
  const downloadUrl = result?.download || result?.downloadURL
  if (!downloadUrl) {
    console.error('[VIDEO] API 2 sin URL de descarga:', JSON.stringify(result).slice(0, 200))
    throw new Error('API_2_NO_URL')
  }

  console.log('[VIDEO] ✅ API 2 (Sanka .com) respondió primero')
  return {
    download: downloadUrl,
    title: result.title || 'video',
    duration: result.duration || null,
    thumbnail: result.thumbnail || null,
    source: 'API2-SankaCom'
  }
}

// ===============================
// API 3 - Delirius
// ===============================
async function getFromAPI3(url) {
  const endpoint = `https://api.delirius.store/download/ytmp4?url=${encodeURIComponent(url)}&format=360p`
  console.log('[VIDEO] Consultando API 3 (Delirius)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status || !res.data?.data?.download) {
    console.error('[VIDEO] API 3 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_3_FAIL')
  }

  const data = res.data.data
  console.log('[VIDEO] ✅ API 3 (Delirius) respondió primero')
  return {
    download: data.download,
    title: data.title || 'video',
    duration: null,
    thumbnail: data.image || null,
    source: 'API3-Delirius'
  }
}

// ===============================
// API 4 - sankavollerei.web.id
// ===============================
async function getFromAPI4(url) {
  const endpoint = `https://www.sankavollerei.web.id/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando API 4 (Sanka .web.id)...')
  const res = await axios.get(endpoint, { timeout: TIMEOUT_MS })

  if (!res.data?.status) {
    console.error('[VIDEO] API 4 respuesta inválida:', JSON.stringify(res.data).slice(0, 200))
    throw new Error('API_4_FAIL')
  }

  const result = res.data.result
  const downloadUrl = result?.download || result?.downloadURL
  if (!downloadUrl) {
    console.error('[VIDEO] API 4 sin URL de descarga:', JSON.stringify(result).slice(0, 200))
    throw new Error('API_4_NO_URL')
  }

  console.log('[VIDEO] ✅ API 4 (Sanka .web.id) respondió primero')
  return {
    download: downloadUrl,
    title: result.title || 'video',
    duration: result.duration || null,
    thumbnail: result.thumbnail || null,
    source: 'API4-SankaWebId'
  }
}

// ===============================
// OBTENER VIDEO + DESCARGAR (las 4 en paralelo, pero con fallback real)
// ===============================
// Importante: no basta con quedarse con la metadata más rápida (Promise.any),
// porque algunas APIs devuelven links directos de googlevideo.com que pueden
// dar 403 (expiran rápido o quedan atados a la IP del servidor que los generó).
// Por eso acá se prueba la DESCARGA de cada fuente en orden de llegada, y si
// una falla se pasa automáticamente a la siguiente sin tirar error.
async function getWorkingVideo(url, limitMb) {
  const sources = [
    { name: 'API1-Roble', fn: getFromAPI1 },
    { name: 'API2-SankaCom', fn: getFromAPI2 },
    { name: 'API3-Delirius', fn: getFromAPI3 },
    { name: 'API4-SankaWebId', fn: getFromAPI4 }
  ]

  // Cada promesa se "auto-captura" (nunca rechaza) para poder usarlas con
  // Promise.race e ir consumiéndolas en el orden en que realmente terminan.
  const wrapped = sources.map((s, idx) =>
    s.fn(url)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []
  let limitExceededError = null

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[VIDEO] ${sourceName} falló al obtener metadata: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[VIDEO] ${sourceName} respondió, probando descarga...`)

    try {
      // downloadWithLimit ya incluye los headers necesarios internamente
      const downloadData = await downloadWithLimit(result.data.download, limitMb)
      console.log(`[VIDEO] ✅ Descarga exitosa desde ${sourceName}`)
      return { ...result.data, downloadData }
    } catch (downloadError) {
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        // Puede que otra fuente (otro formato/itag) sí entre en el límite,
        // así que seguimos probando pero guardamos este error por si ninguna funciona.
        limitExceededError = downloadError
        console.log(`[VIDEO] ${sourceName} excede el límite de tamaño, probando siguiente...`)
        continue
      }
      console.log(`[VIDEO] ${sourceName} obtuvo metadata pero la descarga falló (${downloadError.message}), probando siguiente...`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  if (limitExceededError) throw limitExceededError
  console.error('[VIDEO] Todas las fuentes fallaron:', errors.join(' | '))
  throw new Error('No se pudo descargar el video en este momento.')
}

// ===============================
// BUSCAR VIDEO
// ===============================
async function searchYouTube(query) {
  const result = await yts(query)
  if (!result?.videos?.length) throw new Error('No se encontraron resultados en YouTube')
  return result.videos[0].url
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    let youtubeUrl = text

    if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
      await message.reply('🔎 Buscando video...')
      youtubeUrl = await searchYouTube(text)
    }

    await message.reply('⏳ Descargando video...')

    let tempFile = null

    try {
      // getWorkingVideo ya prueba las 4 fuentes y descarga con la primera que
      // funcione de verdad (no solo la que responda metadata más rápido)
      const { title, duration, thumbnail, source, downloadData } = await getWorkingVideo(youtubeUrl, LIMIT_MB)
      tempFile = downloadData.tempFile
      const sizeMB = downloadData.sizeMB

      console.log(`[VIDEO] ✅ ${title} | ${sizeMB} MB | ${source}`)

      // Enviar thumbnail primero si está disponible
      if (thumbnail) {
        await sock.sendMessage(
          message.from,
          {
            image: { url: thumbnail },
            caption: `🎬 *${title}*${duration ? `\n⏱️ Duración: ${duration}` : ''}\n📦 Tamaño: ${sizeMB} MB\n\n_Enviando video..._`
          },
          { quoted: message._baileyMessage }
        )
      }

      // Enviar video
      await sock.sendMessage(
        message.from,
        {
          video: downloadData.buffer,
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          caption: `🎬 *${title}*`
        },
        { quoted: message._baileyMessage }
      )

      console.log('[VIDEO] Enviado correctamente')

    } catch (downloadError) {
      console.error('[VIDEO] Error en descarga:', downloadError.message)
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      if (tempFile) cleanupTempFile(tempFile)
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ *No se pudo descargar el video*\n\n` +
      `_Posibles causas: link inválido, video privado o no disponible en tu región._`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler