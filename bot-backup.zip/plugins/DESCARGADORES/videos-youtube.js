const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { execFile } = require('child_process')
const { promisify } = require('util')
const { downloadWithLimit, cleanupTempFile, TEMP_DIR } = require('../../downloadUtils')
const execFileAsync = promisify(execFile)

// ===============================
// CONFIG
// ===============================
const LIMIT_MB = 300
const TIMEOUT_MS = 60000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

// ===============================
// EXTRACCIÓN E INFO DE YOUTUBE
// ===============================
function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function parseISODuration(iso) {
  if (!iso) return null
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return null
  const h = parseInt(m[1] || '0', 10)
  const min = parseInt(m[2] || '0', 10)
  const s = parseInt(m[3] || '0', 10)
  const pad = n => String(n).padStart(2, '0')
  if (h > 0) return `${h}:${pad(min)}:${pad(s)}`
  return `${min}:${pad(s)}`
}

function buildInfo(videoId, snippet, contentDetails) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl,
    duration: parseISODuration(contentDetails?.duration)
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró video en Data API')
  return buildInfo(videoId, item.snippet, item.contentDetails)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=id&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item?.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return await getVideoInfoById(item.id.videoId)
}

async function searchVideoInfoByHtml(query) {
  console.log('[VIDEO INFO] Consultando búsqueda YouTube HTML fallback...')
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  const videoId = match[1]
  return await getVideoInfoById(videoId)
}

// Carrera ultra veloz para resolver título y miniatura al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search (muy rápido)
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null,
        duration: v.timestamp || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[VIDEO INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[VIDEO INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    if (!isLink && typeof text === 'string') {
      try {
        return await searchVideoInfoByHtml(text)
      } catch (htmlErr) {
        console.error('[VIDEO INFO] Fallback HTML falló:', htmlErr.message)
      }
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ===============================
// APIS DE DESCARGA
// ===============================

async function downloadFromRobleVideoAPI(url) {
  const endpoint = `https://robleuy.vercel.app/robleapi/download/ytmp4?url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente RobleAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Referer': 'https://robleuy.vercel.app/'
    }
  })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_VIDEO_FAIL')
  console.log('[VIDEO] ✅ Fuente RobleAPI entregó resultado')
  return {
    download: res.data.download_url,
    title: res.data.title || 'video',
    source: 'RobleAPI'
  }
}

async function downloadFromDeliriusOnlineVideoAPI(url, format = '360p') {
  const endpoint = `https://api.delirius.online/download/ytmp4?url=${encodeURIComponent(url)}&format=${encodeURIComponent(format)}`
  console.log('[VIDEO] Consultando fuente DeliriusOnline...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.data || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('DELIRIUS_ONLINE_VIDEO_FAIL')
  console.log('[VIDEO] ✅ Fuente DeliriusOnline entregó resultado')
  return {
    download,
    title: data?.title || data?.creator || 'video',
    source: 'DeliriusOnline'
  }
}

async function downloadFromSankaVideoAPI(url) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente SankaAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.result || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('SANKA_VIDEO_FAIL')
  console.log('[VIDEO] ✅ Fuente SankaAPI entregó resultado')
  return {
    download,
    title: data?.title || res.data?.title || 'video',
    source: 'SankaAPI'
  }
}

async function downloadFromOliviaVideoAPI(url) {
  const endpoint = `http://olivia.hidencloud.com:24733/robleapi/downloads/ytvideo?link=${encodeURIComponent(url)}`
  console.log('[VIDEO] Consultando fuente OliviaAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const result = res.data?.result
  const download = result?.download
  if (!res.data?.status || !download) throw new Error('OLIVIA_VIDEO_FAIL')
  console.log('[VIDEO] ✅ Fuente OliviaAPI entregó resultado')
  return {
    download,
    title: result?.title || 'video',
    source: 'OliviaAPI'
  }
}

// ===============================
// FIX COMPATIBILIDAD MÓVIL
// ===============================
// WhatsApp Android requiere H.264/AAC con moov atom al inicio (faststart).
// Siempre recodificamos el video descargado para garantizar compatibilidad,
// independientemente del codec o formato que entregue la fuente (VP9, AV1, etc.)

async function fixVideoForMobile(inputBuffer) {
  const inputPath = path.join(TEMP_DIR, `fix_in_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  const outputPath = path.join(TEMP_DIR, `fix_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  try {
    fs.writeFileSync(inputPath, inputBuffer)

    // Paso 1: intentar remuxing sin recodificar (instantáneo, mismo tamaño)
    // Funciona si el video ya viene en H.264/AAC — solo mueve el moov al inicio
    try {
      await execFileAsync('ffmpeg', [
        '-y', '-i', inputPath,
        '-c', 'copy',
        '-movflags', '+faststart',
        outputPath
      ], { windowsHide: true, timeout: 30_000 })

      const fixed = fs.readFileSync(outputPath)
      // Verificar que el output es un MP4 válido y tiene tamaño razonable
      if (fixed.length > 50 * 1024) {
        console.log(`[VIDEO] ✅ Fix móvil (remux, sin recodificar): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
        return fixed
      }
    } catch (remuxErr) {
      console.log(`[VIDEO] Remux directo no aplicable (${remuxErr.message.split('\n')[0]}), recodificando...`)
      // Limpiar output parcial si existe
      try { fs.unlinkSync(outputPath) } catch {}
    }

    // Paso 2: recodificar a H.264/AAC solo si el remux falló (video en VP9/AV1/OPUS)
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-c:v', 'libx264',
      '-c:a', 'aac',
      '-movflags', '+faststart',
      '-preset', 'fast',
      '-crf', '28',
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      outputPath
    ], { windowsHide: true, timeout: 120_000 })

    const fixed = fs.readFileSync(outputPath)
    console.log(`[VIDEO] ✅ Fix móvil (recodificado H.264): ${(inputBuffer.length / 1024 / 1024).toFixed(1)} MB → ${(fixed.length / 1024 / 1024).toFixed(1)} MB`)
    return fixed
  } finally {
    try { fs.unlinkSync(inputPath) } catch {}
    try { fs.unlinkSync(outputPath) } catch {}
  }
}

// ===============================
// VALIDACIÓN DE BUFFER
// ===============================
function isValidVideoBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 100 * 1024) return false // menos de 100 KB = inválido
  // MP4: "ftyp" en bytes 4-7
  if (buffer.length >= 8 &&
      buffer[4] === 0x66 && buffer[5] === 0x74 &&
      buffer[6] === 0x79 && buffer[7] === 0x70) return true
  // MP4 alternativo: box size en bytes 0-3
  if (buffer[0] === 0x00 && buffer[1] === 0x00 &&
      buffer[2] === 0x00 && buffer[3] >= 0x08) return true
  // Si pesa más de 1 MB asumimos válido
  if (buffer.length > 1024 * 1024) return true
  return false
}

// ===============================
// CARRERA DE DESCARGA: TODAS EN PARALELO, GANA LA PRIMERA EN COMPLETAR EL BUFFER
// ===============================
async function getWorkingVideo(url, limitMb) {
  const sources = [
    { name: 'RobleAPI', fn: downloadFromRobleVideoAPI },
    { name: 'DeliriusOnline', fn: downloadFromDeliriusOnlineVideoAPI },
    { name: 'SankaAPI', fn: downloadFromSankaVideoAPI },
    { name: 'OliviaAPI', fn: downloadFromOliviaVideoAPI }
  ]

  const tasks = sources.map((source) =>
    source.fn(url)
      .then(async (data) => {
        const sourceName = source.name
        console.log(`[VIDEO] ${sourceName} entregó metadata, iniciando descarga de video...`)

        if (Buffer.isBuffer(data.download)) {
          if (!isValidVideoBuffer(data.download)) {
            throw new Error(`${sourceName}: buffer inválido o muy pequeño`)
          }
          return {
            ...data,
            downloadData: {
              buffer: data.download,
              size: data.download.length,
              tempFile: null,
              sizeMB: (data.download.length / (1024 * 1024)).toFixed(2)
            }
          }
        }

        const downloadData = await downloadWithLimit(data.download, limitMb)
        if (!isValidVideoBuffer(downloadData.buffer)) {
          throw new Error(`${sourceName}: buffer descargado inválido o muy pequeño`)
        }

        return {
          ...data,
          downloadData
        }
      })
      .catch((error) => {
        const message = error?.message || String(error)
        console.log(`[VIDEO] ❌ ${source.name} falló: ${message}`)
        throw new Error(`${source.name}: ${message}`)
      })
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[VIDEO] 🏆 ¡GANADORA DE VIDEO! ${winner.source} descargó el video exitosamente (${winner.downloadData.sizeMB} MB)`)
    return winner
  } catch (e) {
    console.error('[VIDEO] Todas las fuentes de video fallaron:', e)
    throw new Error('No se pudo descargar el video en este momento.')
  }
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  try {
    if (!text) {
      return message.reply(
        `❌ Debes enviar un enlace o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
      )
    }

    const isLink = text.includes('youtube.com') || text.includes('youtu.be')

    await message.reply(isLink ? '⏳ Descargando video...' : '🔎 Buscando video...')

    // 1) Resolver la información y miniatura lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    const youtubeUrl = videoInfo.url

    let tempFile = null

    try {
      // 2) Tarea A: Enviar la miniatura inmediatamente
      const sendThumbnailTask = (async () => {
        try {
          if (videoInfo.thumbnailUrl) {
            await sock.sendMessage(
              message.from,
              {
                image: { url: videoInfo.thumbnailUrl },
                caption: `🎬 *${videoInfo.title}*${videoInfo.duration ? `\n⏱️ Duración: ${videoInfo.duration}` : ''}\n\n_Descargando video..._`
              },
              { quoted: message._baileyMessage }
            )
          }
        } catch (thumbError) {
          console.error('[VIDEO] No se pudo enviar la miniatura:', thumbError.message)
        }
      })()

      // 3) Tarea B: Descargar video desde RobleAPI y enviar el archivo
      const sendVideoTask = (async () => {
        const { title, source, downloadData } = await getWorkingVideo(youtubeUrl, LIMIT_MB)
        tempFile = downloadData.tempFile
        const sizeMB = downloadData.sizeMB

        // Aplicar fix de compatibilidad móvil siempre:
        // - Garantiza codec H.264/AAC (WhatsApp Android rechaza VP9, AV1, OPUS)
        // - Mueve el moov atom al inicio (faststart) para reproducción sin descarga completa
        let videoBuffer = downloadData.buffer
        try {
          console.log(`[VIDEO] Aplicando fix H.264/faststart para compatibilidad Android/iOS...`)
          videoBuffer = await fixVideoForMobile(videoBuffer)
        } catch (fixErr) {
          console.warn(`[VIDEO] ⚠️ Fix móvil falló (${fixErr.message}), enviando buffer original`)
        }

        console.log(`[VIDEO] 🚀 Enviando a WhatsApp video descargado vía ${source} (${sizeMB} MB)...`)

        await sock.sendMessage(
          message.from,
          {
            video: videoBuffer,
            mimetype: 'video/mp4',
            fileName: `${videoInfo.title || title}.mp4`,
            caption: `🎬 *${videoInfo.title || title}*`
          },
          { quoted: message._baileyMessage }
        )

        console.log(`[VIDEO] ✅ Video enviado a WhatsApp con éxito (vía ${source})`)
      })()

      // Corren en paralelo
      await Promise.all([sendThumbnailTask, sendVideoTask])

    } catch (downloadError) {
      console.error('[VIDEO] Error en descarga:', downloadError.message)
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        const sizeMB = downloadError.message.split(':')[1]
        return message.reply(
          `❌ *El video es demasiado grande*\n\n` +
          `📦 Tamaño: ${sizeMB} MB\n` +
          `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
          `_Intenta con un video más corto._`
        )
      }
      throw downloadError
    } finally {
      if (tempFile) cleanupTempFile(tempFile)
    }

  } catch (err) {
    console.error('[VIDEO ERROR]', err?.message || err)
    await message.reply(
      `❌ *No se pudo descargar el video*\n\n` +
      `_Posibles causas: link inválido, video privado o no disponible en tu región._`
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['video <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(ytvideo|videoyt|ytmp4|ytv|video|vídeo)$/i

module.exports = handler