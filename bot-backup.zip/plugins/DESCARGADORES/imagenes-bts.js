const axios = require('axios');

const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];
const GOOGLE_CX = '635e6b14f7cf84f2c';

const BTS_TERMS = [
    'BTS group photo',
    'BTS members',
    'BTS Jungkook',
    'BTS RM',
    'BTS Jimin',
    'BTS V',
    'BTS Suga',
    'BTS J-Hope',
    'BTS Jin',
    'BTS concert',
    'BTS performance',
    'BTS band photo',
    'BTS official photo',
    'BTS ARMY',
    'BTS music video stills'
];

const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Headers que simulan un navegador real para evitar 403
const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': 'https://www.google.com/',
    'Connection': 'keep-alive'
};

async function buscarImagenesBTS(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];

    if (keyIndex >= GOOGLE_API_KEYS.length) return [];

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=active`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            // Devuelve TODOS los links válidos, no solo uno
            return response.data.items
                .filter(item => item.link && item.mime && item.mime.startsWith('image/'))
                .map(item => item.link);
        }
    } catch (error) {
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`⚠️ Clave de API agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarImagenesBTS(termsArray, keyIndex + 1, retries - 1);
        }
        console.error('Error en la búsqueda de imágenes de BTS:', error.message);
    }

    return [];
}

async function descargarImagen(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 10000, // 10 segundos máximo
            headers: BROWSER_HEADERS // <-- Esto soluciona el 403
        });

        // Verificar que realmente es una imagen por su content-type
        const contentType = response.headers['content-type'] || '';
        if (!contentType.startsWith('image/')) {
            console.warn(`⚠️ URL no devolvió imagen: ${contentType}`);
            return null;
        }

        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.warn(`⚠️ No se pudo descargar imagen (${error.response?.status || error.message}): ${url}`);
        return null;
    }
}

let handlerBts = async (message, { conn }) => {
    try {
        // Obtener lista de URLs candidatas
        const imageUrls = await buscarImagenesBTS(BTS_TERMS);

        if (!imageUrls.length) {
            return message.reply('❌ No se encontraron imágenes de BTS. Intenta de nuevo más tarde.');
        }

        // Intentar descargar cada URL hasta encontrar una que funcione
        let imageBuffer = null;
        for (const url of imageUrls) {
            imageBuffer = await descargarImagen(url);
            if (imageBuffer) break; // Encontró una válida, salir del loop
        }

        if (!imageBuffer) {
            return message.reply('❌ No se pudo descargar ninguna imagen. Intenta de nuevo más tarde.');
        }

        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: 'BTS 😍💜'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /bts:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
};

handlerBts.command = /^bts/i;
handlerBts.help = ['bts'];
handlerBts.tags = ['fun', 'kpop'];

module.exports = { bts: handlerBts };