const axios = require('axios');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

// 🔑 Claves API de Google
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];

// 🔍 ID del motor de búsqueda (Custom Search Engine)
const GOOGLE_CX = '635e6b14f7cf84f2c';

// 🍑 Términos de búsqueda específicos para tetas (NSFW)
const TETAS_TERMS = [
    'TETAS DESNUDAS', 
    'TETAS HOT Y DESNUDAS', 
    'TETAS DE MUJER DESNUDA', 
    'MUJER MOSTRANDO LAS TETAS DESNUDAS', 
    'TETAS XXX HOT', 
    'SENOS DESNUDOS Y HOT', 
    'SENOS DE MUJERES SEXY Y DESNUDAS', 
    'PECHOS GRANDES Y DESNUDOS CALIENTES', 
    'PECHOS CALIENTES DE MUJERES DESNUDAS', 
    'MUJERES DESNUDAS MOSTRANDO TETAS HOT', 
    'TETAS EN POSE SEXY Y DESNUDA', 
    'TETAS XXX HOT Y DESNUDAS', 
    'SENOS EROTICOS Y DESNUDOS CALIENTES', 
    'MUJERES CON TETAS GRATIS Y DESNUDAS HOT', 
    'TETAS DE PORNO DESNUDAS', 
    'TETAS CALIENTES Y SEXY DESNUDAS', 
    'SENOS DE ESTRELLAS PORNO DESNUDAS', 
    'MUJERES HOT CON TETAS GRANDES Y DESNUDAS', 
    'TETAS EN FOTOS HOT Y DESNUDAS', 
    'PECHOS DE MUJERES ATRACTIVAS Y DESNUDAS SEXY',
    'PACKS DE TETAS DESNUDAS Y SEXY',
    'FOTOS DE TETAS COMPLETAMENTE DESNUDAS',
    'TETAS PERFECTAS Y DESNUDAS',
    'MUJERES CON TETAS GRANDES Y EXPLICITAS'
];

// 🧠 Cache simple + delay para evitar exceso de peticiones
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Palabras clave explícitas (adaptadas para este contexto)
const explicitKeywords = [
    'hot', 'sexy', 'desnuda', 'caliente', 'xxx', 'erotic', 'desnudo', 'packs',
    'tetas', 'senos', 'pechos', 'desnudas', 'perfectas', 'completas',
    'expuestas', 'explicitas'
];

async function buscarImagen(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];

    // Usa cache si ya existe una imagen para ese término
    if (imageCache.has(randomTerm)) return imageCache.get(randomTerm);
    if (keyIndex >= GOOGLE_API_KEYS.length) return null;

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=off`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => 
                item.link && item.mime && item.mime.startsWith('image/') &&
                explicitKeywords.some(keyword => 
                    item.title?.toLowerCase().includes(keyword) || 
                    item.snippet?.toLowerCase().includes(keyword)
                )
            );
            if (validImages.length > 0) {
                const randomImage = validImages[Math.floor(Math.random() * validImages.length)];
                imageCache.set(randomTerm, randomImage.link);
                return randomImage.link;
            }
        }
    } catch (error) {
        // Si la API key se agota, pasa a la siguiente
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`⚠️ Clave de API agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarImagen(termsArray, keyIndex + 1, retries - 1);
        }
        console.error('Error en la búsqueda de imágenes:', error.message);
    }

    return null;
}

// 🍑 Handler principal del comando /tetas
let handlerTetas = async (message, { conn }) => {
    try {
        // Verificar si el mensaje proviene del grupo bloqueado
        if (message.from === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }

        const imageUrl = await buscarImagen(TETAS_TERMS);
        if (!imageUrl) return message.reply('❌ No se encontraron imágenes explícitas de tetas. Intenta de nuevo más tarde.');

        // Descargar imagen
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // Enviar al chat como respuesta
        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: '🥵🥵 '
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /tetas:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
};

// 📦 Exportación del comando
handlerTetas.command = /^tetas/i;
handlerTetas.help = ['tetas'];
handlerTetas.tags = ['fun', 'nsfw'];

module.exports = { tetas: handlerTetas };