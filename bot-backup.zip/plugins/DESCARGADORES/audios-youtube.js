const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true;
const ROBLE_API_BASE = 'https://robleuy.vercel.app/robleapi/download/ytmp3';
const SANKA_API_BASE = 'https://www.sankavollerei.com/download/ytmp3';
const SANKA_API_KEY  = 'planaai';
const LIMIT_MB = 100; // Límite de 100 MB para audios

// ⚠️ Recomendado: mover esto a una variable de entorno (process.env.YOUTUBE_API_KEY)
// y restringir la key en Google Cloud Console (solo YouTube Data API v3 + IP/referer).
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw';
// ========================================

const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// ========================================
// YOUTUBE DATA API V3 (miniatura + info confiable)
// ========================================

function extractVideoId(url) {
    const patterns = [
        /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
        /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
        /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
        /youtu\.be\/([a-zA-Z0-9_-]{11})/
    ];
    for (const p of patterns) {
        const m = url.match(p);
        if (m) return m[1];
    }
    return null;
}

function buildInfo(videoId, snippet) {
    const thumbs = snippet.thumbnails || {};
    const thumbnailUrl =
        thumbs.maxres?.url ||
        thumbs.standard?.url ||
        thumbs.high?.url ||
        thumbs.medium?.url ||
        thumbs.default?.url ||
        null;

    return {
        videoId,
        title: snippet.title,
        url: `https://www.youtube.com/watch?v=${videoId}`,
        thumbnailUrl
    };
}

// Cuando ya tenemos un link -> videos.list (1 unidad de cuota)
async function getVideoInfoById(videoId) {
    const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YT_API_KEY}`;
    const res = await axios.get(endpoint, { timeout: 15000 });
    const item = res.data.items?.[0];
    if (!item) throw new Error('No se encontró información del video en YouTube Data API');
    return buildInfo(videoId, item.snippet);
}

// Cuando el usuario busca por texto -> search.list (100 unidades de cuota)
async function searchVideoInfo(query) {
    const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`;
    const res = await axios.get(endpoint, { timeout: 15000 });
    const item = res.data.items?.[0];
    if (!item || !item.id?.videoId) throw new Error('No se encontraron resultados en YouTube');
    return buildInfo(item.id.videoId, item.snippet);
}

// ========================================
// RESPALDO CON yt-search (si la Data API falla: cuota, key inválida, etc.)
// ========================================

async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) throw new Error('No se encontraron resultados en YouTube');
        return r.videos[0];
    } catch (e) {
        console.error('[MUSICYT] Error en búsqueda de respaldo:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

// ========================================
// APIS DE DESCARGA (RobleAPI + SankaAPI en paralelo, gana la más rápida)
// ========================================

async function downloadFromRobleAPI(youtubeUrl) {
    const endpoint = `${ROBLE_API_BASE}?url=${encodeURIComponent(youtubeUrl)}`;
    console.log('[MUSICYT] Solicitando a RobleAPI...');

    const res = await axios.get(endpoint, { timeout: 30000 });
    const data = res.data;

    if (!data.ok || !data.download_url) {
        throw new Error('La API de Roble no devolvió un enlace válido');
    }

    console.log('[MUSICYT] ✅ RobleAPI respondió primero');
    return {
        download: data.download_url,
        title: data.title || 'Audio',
        source: 'RobleAPI'
    };
}

async function downloadFromSankaAPI(youtubeUrl) {
    const endpoint = `${SANKA_API_BASE}?apikey=${SANKA_API_KEY}&url=${encodeURIComponent(youtubeUrl)}`;
    console.log('[MUSICYT] Solicitando a SankaAPI...');

    const res = await axios.get(endpoint, { timeout: 30000 });
    const data = res.data;

    if (!data.status || !data.result?.download) {
        throw new Error('La API de Sanka no devolvió un enlace válido');
    }

    console.log('[MUSICYT] ✅ SankaAPI respondió primero');
    return {
        download: data.result.download,
        title: data.result.title || 'Audio',
        source: 'SankaAPI'
    };
}

async function getDownloadLink(youtubeUrl) {
    try {
        return await Promise.any([
            downloadFromRobleAPI(youtubeUrl),
            downloadFromSankaAPI(youtubeUrl),
        ]);
    } catch (aggregateError) {
        const errors = aggregateError.errors?.map(e => e.message).join(' | ') ?? aggregateError.message;
        console.error('[MUSICYT] Todas las APIs fallaron:', errors);
        throw new Error(`No se pudo obtener el audio. Errores: ${errors}`);
    }
}

// ========================================
// RESOLVER INFO DEL VIDEO (link o texto) - un solo punto de verdad
// ========================================

async function resolveVideoInfo(text, isLink) {
    try {
        if (isLink) {
            const videoId = extractVideoId(text);
            if (!videoId) throw new Error('No se pudo extraer el ID del video del link');
            return await getVideoInfoById(videoId);
        } else {
            return await searchVideoInfo(text);
        }
    } catch (ytApiError) {
        console.error('[MUSICYT] YouTube Data API falló, usando respaldo yt-search:', ytApiError.message);
        // Respaldo: si es link, lo usamos directo (sin miniatura garantizada por API);
        // si es texto, buscamos con yt-search (que también trae thumbnail).
        if (isLink) {
            return { videoId: null, title: 'Audio', url: text, thumbnailUrl: null };
        }
        const searchResult = await searchYouTube(text);
        return {
            videoId: null,
            title: searchResult.title,
            url: searchResult.url,
            thumbnailUrl: searchResult.thumbnail || null
        };
    }
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    const sock = conn || message._sock || global.conn;
    if (!COMANDO_ACTIVADO) {
        return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*');
    }

    if (!text) {
        return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up`);
    }

    let tempFile = null;

    try {
        const isLink = /https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text);

        await message.reply(isLink ? '📥 Descargando...' : '🔍 Buscando...');

        // 1) Resolvemos el video UNA sola vez (mismo videoId para miniatura y descarga)
        const videoInfo = await resolveVideoInfo(text, isLink);
        const { url: youtubeUrl, title: videoTitle, thumbnailUrl } = videoInfo;

        // 2) Tarea A: enviar la miniatura ya (no bloquea nada)
        const sendThumbnailTask = (async () => {
            try {
                if (thumbnailUrl) {
                    await sock.sendMessage(message.from, {
                        image: { url: thumbnailUrl },
                        caption: `🎧 *${videoTitle}*\n⏳ Descargando audio...`
                    }, { quoted: message._baileyMessage });
                }
            } catch (thumbError) {
                console.error('[MUSICYT] No se pudo enviar la miniatura:', thumbError.message);
            }
        })();

        // 3) Tarea B: obtener el link de descarga y enviar el audio (usa el MISMO youtubeUrl)
        const sendAudioTask = (async () => {
            const result = await getDownloadLink(youtubeUrl);
            const { download, title, source } = result;

            console.log(`[MUSICYT] Descargando audio vía ${source}...`);

            try {
                const downloadData = await downloadWithLimit(download, LIMIT_MB);
                tempFile = downloadData.tempFile;
                const sizeMB = downloadData.sizeMB;

                console.log(`[MUSICYT] Audio descargado: ${title} | ${sizeMB} MB | Fuente: ${source}`);

                const fileName = sanitizeFilename(title || videoTitle) + '.mp3';

                await sock.sendMessage(message.from, {
                    audio: downloadData.buffer,
                    mimetype: 'audio/mpeg',
                    fileName: fileName,
                    ptt: false
                }, { quoted: message._baileyMessage });

                console.log(`[MUSICYT] ✅ Enviado: ${title}`);

            } catch (downloadError) {
                if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
                    const sizeMB = downloadError.message.split(':')[1];
                    await message.reply(
                        `❌ *El audio es demasiado grande*\n\n` +
                        `📦 Tamaño: ${sizeMB} MB\n` +
                        `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
                        `_Intenta con un audio más corto._`
                    );
                    return;
                }
                throw downloadError;
            } finally {
                if (tempFile) {
                    cleanupTempFile(tempFile);
                }
            }
        })();

        // 4) Ambas tareas corren en paralelo: la miniatura llega rápido
        // mientras el audio se descarga y se envía por detrás.
        await Promise.all([sendThumbnailTask, sendAudioTask]);

    } catch (e) {
        console.error('[MUSICYT] Error:', e.message);
        await message.reply(`❌ *Error:* ${e.message}`);
    }
};

handler.help = ['play <título/link>'];
handler.tags = ['audio'];
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i;

module.exports = handler;