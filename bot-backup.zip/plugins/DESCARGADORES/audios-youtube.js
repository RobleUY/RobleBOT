const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true; 
const ROBLE_API_BASE = 'https://www.robleuy.site/robleapi/download/ytmp3';
const SANKA_API_BASE = 'https://www.sankavollerei.com/download/ytmp3';
const SANKA_API_KEY  = 'planaai';
const LIMIT_MB = 100; // Límite de 100 MB para audios
// ========================================

const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// ========================================
// FUNCIONES DE YOUTUBE
// ========================================

async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) throw new Error('No se encontraron resultados en YouTube');
        return r.videos[0];
    } catch (e) {
        console.error('[MUSICYT] Error en búsqueda:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

async function downloadFromRobleAPI(youtubeUrl) {
    const endpoint = `${ROBLE_API_BASE}?url=${encodeURIComponent(youtubeUrl)}`;
    console.log('[MUSICYT] Solicitando a RobleAPI...');

    const res = await axios.get(endpoint, { timeout: 30000 });
    const data = res.data;

    if (!data.ok || !data.download_url) {
        throw new Error('La API de Roble no devolvió un enlace válido');
    }

    console.log('[MUSICYT] ✅ RobleAPI respondió primero');
    return {
        download: data.download_url,
        title: data.title || 'Audio',
        source: 'RobleAPI'
    };
}

async function downloadFromSankaAPI(youtubeUrl) {
    const endpoint = `${SANKA_API_BASE}?apikey=${SANKA_API_KEY}&url=${encodeURIComponent(youtubeUrl)}`;
    console.log('[MUSICYT] Solicitando a SankaAPI...');

    const res = await axios.get(endpoint, { timeout: 30000 });
    const data = res.data;

    if (!data.status || !data.result?.download) {
        throw new Error('La API de Sanka no devolvió un enlace válido');
    }

    console.log('[MUSICYT] ✅ SankaAPI respondió primero');
    return {
        download: data.result.download,
        title: data.result.title || 'Audio',
        source: 'SankaAPI'
    };
}

// Lanza todas las APIs en paralelo y usa la que responda primero con éxito.
// Promise.any() ignora los rechazos individuales y solo falla si TODAS fallan.
async function getDownloadLink(youtubeUrl) {
    try {
        return await Promise.any([
            downloadFromRobleAPI(youtubeUrl),
            downloadFromSankaAPI(youtubeUrl),
        ]);
    } catch (aggregateError) {
        // AggregateError: todas las APIs fallaron
        const errors = aggregateError.errors?.map(e => e.message).join(' | ') ?? aggregateError.message;
        console.error('[MUSICYT] Todas las APIs fallaron:', errors);
        throw new Error(`No se pudo obtener el audio. Errores: ${errors}`);
    }
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    const sock = conn || message._sock || global.conn;
    if (!COMANDO_ACTIVADO) {
        return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*');
    }

    if (!text) {
        return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up`);
    }

    let tempFile = null;

    try {
        await message.reply('🔍 Buscando y enviando el audio...');

        let youtubeUrl = text;
        let videoTitle = 'Audio';

        // Si no es un link, buscar en YouTube
        if (!/https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)) {
            const searchResult = await searchYouTube(text);
            youtubeUrl = searchResult.url;
            videoTitle = searchResult.title;
        }

        // Obtener link de descarga (RobleAPI con fallback a SankaAPI)
        const result = await getDownloadLink(youtubeUrl);
        const { download, title, source } = result;

        console.log(`[MUSICYT] Descargando audio vía ${source}...`);

        try {
            // Descargar con límite de tamaño
            const downloadData = await downloadWithLimit(download, LIMIT_MB);
            tempFile = downloadData.tempFile;
            const sizeMB = downloadData.sizeMB;

            console.log(`[MUSICYT] Audio descargado: ${title} | ${sizeMB} MB | Fuente: ${source}`);

            const fileName = sanitizeFilename(title) + '.mp3';

            // Enviar el archivo
            await sock.sendMessage(message.from, {
                audio: downloadData.buffer,
                mimetype: 'audio/mpeg',
                fileName: fileName,
                ptt: false
            }, { quoted: message._baileyMessage });

            console.log(`[MUSICYT] ✅ Enviado: ${title}`);

        } catch (downloadError) {
            if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
                const sizeMB = downloadError.message.split(':')[1];
                return message.reply(
                    `❌ *El audio es demasiado grande*\n\n` +
                    `📦 Tamaño: ${sizeMB} MB\n` +
                    `⚠️ Límite: ${LIMIT_MB} MB\n\n` +
                    `_Intenta con un audio más corto._`
                );
            }
            throw downloadError;
        } finally {
            // Limpiar archivo temporal
            if (tempFile) {
                cleanupTempFile(tempFile);
            }
        }

    } catch (e) {
        console.error('[MUSICYT] Error:', e.message);
        await message.reply(`❌ *Error:* ${e.message}`);
    }
};

handler.help = ['play <título/link>'];
handler.tags = ['audio'];
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i;

module.exports = handler;
