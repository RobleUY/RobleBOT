const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true; // Cambiar a false para desactivar el comando
const API_NUEVA_URL = 'http://darli.hidencloud.com:24667'; // Nueva API como principal
// ========================================

const LimitAud = 100 * 1024 * 1024; // 100MB
const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// Validar si una URL es válida
function isValidUrl(url) {
    if (!url || url === 'undefined' || url.includes('undefined')) return false;
    try {
        const parsed = new URL(url);
        return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (e) {
        return false;
    }
}

// ========================================
// FUNCIONES DE YOUTUBE
// ========================================

// Función de búsqueda de YouTube (usando yt-search)
async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) throw new Error('No se encontraron resultados en YouTube');
        return {
            url: r.videos[0].url,
            title: r.videos[0].title,
            duration: r.videos[0].timestamp,
            thumbnail: r.videos[0].thumbnail
        };
    } catch (e) {
        console.error('[MUSICYT] Error en búsqueda de YouTube:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

// Nueva API Principal (Darli - PRIORIDAD 1)
async function downloadYoutubeAudioApiNueva(youtubeUrl, videoInfo) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `${API_NUEVA_URL}/mp3?url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[MUSICYT] Solicitando a Nueva API Principal (RobleAPI)...');
        
        const tempDir = path.join(__dirname, '.temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const tempFile = path.join(tempDir, sanitizeFilename(videoInfo.title) + '_temp.mp3');
        const writer = fs.createWriteStream(tempFile);

        // Descargar el stream directamente
        const response = await axios({
            method: 'GET',
            url: endpoint,
            responseType: 'stream',
            timeout: 90000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => {
                const stats = fs.statSync(tempFile);
                const fileSize = stats.size;
                console.log(`[MUSICYT] Nueva API - Archivo descargado: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);
                
                if (fileSize < 1000) {
                    fs.unlinkSync(tempFile);
                    reject(new Error('El archivo descargado es demasiado pequeño o está corrupto'));
                } else {
                    resolve({
                        tempFile,
                        title: videoInfo.title,
                        duration: videoInfo.duration || 'Desconocida',
                        thumbnail: videoInfo.thumbnail || null,
                        source: 'YouTube',
                        fileSize
                    });
                }
            });
            writer.on('error', (err) => {
                reject(new Error(`Error escribiendo archivo: ${err.message}`));
            });
        });

    } catch (error) {
        console.error('[MUSICYT] Error en Nueva API Principal:', error?.message || error);
        throw error;
    }
}

// YouTube Download API 2 (Sanka - PRIORIDAD 2)
async function downloadYoutubeAudioApi1(youtubeUrl) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `https://www.sankavollerei.com/download/ytmp3?apikey=planaai&url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[MUSICYT] Solicitando a YouTube API 2 (Sanka)...');
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
        const json = res.data;

        if (!json?.status) throw new Error('El servidor rechazó la solicitud (API 2)');
        if (!json?.result) throw new Error('Sin resultado en la respuesta (API 2)');

        const { download, title, duration, thumbnail } = json.result;

        if (!download || download === 'undefined' || !isValidUrl(download)) {
            throw new Error('No se obtuvo link de descarga válido (API 2)');
        }
        if (!title) throw new Error('No se obtuvo el título del video (API 2)');

        console.log('[MUSICYT] Datos de YouTube 2 obtenidos correctamente:', { title, duration });

        return {
            download,
            title: title || 'Audio',
            duration: duration || 'Desconocida',
            thumbnail: thumbnail || null,
            source: 'YouTube'
        };

    } catch (error) {
        console.error('[MUSICYT] Error en downloadYoutubeAudioApi1:', error?.message || error);
        throw error;
    }
}

// YouTube Download API 3 (Delirius - PRIORIDAD 3)
async function downloadYoutubeAudioApi2(youtubeUrl) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `https://delirius-apiofc.vercel.app/download/ytmp3?url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[MUSICYT] Solicitando a YouTube API 3 (Delirius)...');
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
        const json = res.data;

        if (!json?.status || !json?.data) throw new Error('El servidor rechazó la solicitud o sin datos (API 3)');

        const { download, title, duration, image } = json.data;

        if (!download?.url || !isValidUrl(download.url)) {
            throw new Error('No se obtuvo link de descarga válido (API 3)');
        }
        if (!title) throw new Error('No se obtuvo el título del video (API 3)');

        const formattedDuration = duration ? `${Math.floor(duration / 60)}m ${duration % 60}s` : 'Desconocida';

        console.log('[MUSICYT] Datos de YouTube 3 obtenidos correctamente:', { title, duration: formattedDuration });

        return {
            download: download.url,
            title: title || 'Audio',
            duration: formattedDuration,
            thumbnail: image || null,
            source: 'YouTube'
        };

    } catch (error) {
        console.error('[MUSICYT] Error en downloadYoutubeAudioApi2:', error?.message || error);
        throw error;
    }
}

// ========================================
// FUNCIONES DE SPOTIFY
// ========================================

// Spotify Search API 1 (Sanka - PRIORIDAD 1)
async function searchSpotifyApi1(query) {
    try {
        console.log('[SPOTIFY] Buscando en Spotify (API 1 - Sanka):', query);
        const endpoint = `https://www.sankavollerei.com/search/spotify?apikey=planaai&q=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.result || res.data.result.length === 0) {
            throw new Error('No se encontraron resultados en Spotify (API 1)');
        }

        console.log('[SPOTIFY] Encontrado (API 1):', res.data.result[0].title);
        return res.data.result[0].track_url;
    } catch (e) {
        console.error('[SPOTIFY] Error en búsqueda API 1:', e.message);
        throw e;
    }
}

// Spotify Search API 2 (Delirius - PRIORIDAD 2)
async function searchSpotifyApi2(query) {
    try {
        console.log('[SPOTIFY] Buscando en Spotify (API 2 - Delirius):', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/spotify?q=${encodeURIComponent(query)}&limit=20`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.data || res.data.data.length === 0) {
            throw new Error('No se encontraron resultados en Spotify (API 2)');
        }

        console.log('[SPOTIFY] Encontrado (API 2):', res.data.data[0].title);
        return res.data.data[0].url;
    } catch (e) {
        console.error('[SPOTIFY] Error en búsqueda API 2:', e.message);
        throw e;
    }
}

// Spotify Download API 1 (Delirius V1)
async function downloadSpotifyAudioApi1(spotifyUrl) {
    try {
        console.log('[SPOTIFY] Intentando descarga API 1 (Delirius V1)...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/spotifydl?url=${encodeURIComponent(spotifyUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos de descarga Spotify (API 1/V1)');

        const { url, title, author, image, duration } = res.data.data;
        
        if (!url || !isValidUrl(url)) {
            throw new Error('URL de descarga Spotify API 1/V1 inválida');
        }

        console.log('[SPOTIFY] API 1/V1 OK - URL:', url);

        return {
            download: url,
            title: `${author} - ${title}`,
            duration: duration ? `${Math.floor(duration / 1000)}s` : 'Desconocida',
            thumbnail: image,
            source: 'Spotify'
        };
    } catch (e) {
        console.error('[SPOTIFY] Error API 1/V1:', e.message);
        throw e;
    }
}

// Spotify Download API 2 (Delirius V2)
async function downloadSpotifyAudioApi2(spotifyUrl) {
    try {
        console.log('[SPOTIFY] Intentando descarga API 2 (Delirius V2)...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/spotifydlv2?url=${encodeURIComponent(spotifyUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos de descarga Spotify (API 2/V2)');

        const { url, title, artist, duration, image } = res.data.data;
        
        if (!url || !isValidUrl(url)) {
            throw new Error('URL de descarga Spotify API 2/V2 inválida');
        }

        console.log('[SPOTIFY] API 2/V2 OK - URL:', url);

        return {
            download: url,
            title: `${artist} - ${title}`,
            duration: duration || 'Desconocida',
            thumbnail: image,
            source: 'Spotify'
        };
    } catch (e) {
        console.error('[SPOTIFY] Error API 2/V2:', e.message);
        throw e;
    }
}

// ========================================
// FUNCIONES DE APPLE MUSIC
// ========================================

// Apple Music Search API 1 (Delirius V1)
async function searchAppleMusicApi1(query) {
    try {
        console.log('[APPLE MUSIC] Buscando en Apple Music (API 1):', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/applemusic?text=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data || !Array.isArray(res.data) || res.data.length === 0) {
            throw new Error('No se encontraron resultados en Apple Music (API 1)');
        }

        const track = res.data.find(item => item.type === 'Canción') || res.data[0];
        
        console.log('[APPLE MUSIC] Encontrado (API 1):', track.title, '-', track.artists);
        return track.url;
    } catch (e) {
        console.error('[APPLE MUSIC] Error en búsqueda API 1:', e.message);
        throw e;
    }
}

// Apple Music Search API 2 (Delirius V2)
async function searchAppleMusicApi2(query) {
    try {
        console.log('[APPLE MUSIC] Buscando en Apple Music (API 2):', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/applemusicv2?query=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.data || res.data.data.length === 0) {
            throw new Error('No se encontraron resultados en Apple Music (API 2)');
        }

        console.log('[APPLE MUSIC] Encontrado (API 2):', res.data.data[0].title, '-', res.data.data[0].artist);
        return res.data.data[0].url;
    } catch (e) {
        console.error('[APPLE MUSIC] Error en búsqueda API 2:', e.message);
        throw e;
    }
}

// Apple Music Download API 1
async function downloadAppleMusicAudioApi1(appleMusicUrl) {
    try {
        console.log('[APPLE MUSIC] Intentando descarga...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/applemusicdl?url=${encodeURIComponent(appleMusicUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos de Apple Music');

        const { download, name, artists, duration, image } = res.data.data;
        
        if (!download || !isValidUrl(download)) {
            throw new Error('URL de descarga de Apple Music inválida');
        }

        console.log('[APPLE MUSIC] OK - URL:', download);

        return {
            download,
            title: `${artists} - ${name}`,
            duration: duration || 'Desconocida',
            thumbnail: image,
            source: 'Apple Music'
        };
    } catch (e) {
        console.error('[APPLE MUSIC] Error en descarga:', e.message);
        throw e;
    }
}

// ========================================
// FUNCIÓN PRINCIPAL CON FALLBACK
// ========================================

async function downloadAudioWithFallback(query, isDirectLink = false) {
    const errors = [];
    let youtubeUrl = query;
    let videoInfo = { title: 'Audio', duration: 'Desconocida', thumbnail: null };
    let spotifyUrl = null;
    let appleMusicUrl = null;

    // --- INTENTOS DE YOUTUBE (PRIORIDAD: Nueva API 1 -> Sanka 2 -> Delirius 3) ---
    try {
        console.log('[FALLBACK] Intento 1: YouTube Búsqueda / Link');
        
        // Si no es un link directo de YT, buscar primero
        if (!isDirectLink || (!query.includes('youtube.com') && !query.includes('youtu.be'))) {
            const searchResult = await searchYouTube(query);
            youtubeUrl = searchResult.url;
            videoInfo = searchResult;
        } else {
            // Si es link directo, intentar obtener info
            try {
                const searchResult = await yts({ videoId: youtubeUrl.split('v=')[1] || youtubeUrl.split('/').pop() });
                if (searchResult) {
                    videoInfo.title = searchResult.title || 'Audio';
                    videoInfo.duration = searchResult.timestamp || 'Desconocida';
                    videoInfo.thumbnail = searchResult.thumbnail || null;
                }
            } catch (e) {
                console.log('[FALLBACK] No se pudo obtener info del video, usando valores por defecto');
            }
        }

        // Intento 2 (PRIORIDAD Nueva API Darli): API Principal
        try {
            console.log('[FALLBACK] Intento 2: Descarga YouTube API 1 (RobleAPI - Darli)');
            const result = await downloadYoutubeAudioApiNueva(youtubeUrl, videoInfo);
            // Esta API ya descarga el archivo, así que retornamos con flag especial
            result.isDownloaded = true;
            return result;
        } catch (e) {
            errors.push(`Descarga YouTube 1 (RobleAPI): ${e.message}`);
        }
        
        // Intento 3 (PRIORIDAD Sanka): API 2
        try {
            console.log('[FALLBACK] Intento 3: Descarga YouTube API 2 (Sanka)');
            return await downloadYoutubeAudioApi1(youtubeUrl);
        } catch (e) {
            errors.push(`Descarga YouTube 2 (Sanka): ${e.message}`);
        }
        
        // Intento 4 (PRIORIDAD Delirius): API 3
        try {
            console.log('[FALLBACK] Intento 4: Descarga YouTube API 3 (Delirius)');
            return await downloadYoutubeAudioApi2(youtubeUrl);
        } catch (e) {
            errors.push(`Descarga YouTube 3 (Delirius): ${e.message}`);
        }

    } catch (e) {
        errors.push(`YouTube Búsqueda/URL: ${e.message}`);
        console.log('[FALLBACK] Fallo inicial de YouTube, intentando Spotify...');
    }

    // --- INTENTOS DE SPOTIFY ---
    
    if (query.includes('spotify.com')) {
        spotifyUrl = query;
        console.log('[FALLBACK] Link directo de Spotify detectado');
    } else {
        try {
            console.log('[FALLBACK] Intento 5: Buscando en Spotify (API 1 - Sanka)');
            spotifyUrl = await searchSpotifyApi1(query);
        } catch (e) {
            errors.push(`Búsqueda Spotify 1 (Sanka): ${e.message}`);
            
            try {
                console.log('[FALLBACK] Intento 6: Buscando en Spotify (API 2 - Delirius)');
                spotifyUrl = await searchSpotifyApi2(query);
            } catch (e2) {
                errors.push(`Búsqueda Spotify 2 (Delirius): ${e2.message}`);
            }
        }
    }

    if (spotifyUrl) {
        console.log('[FALLBACK] URL de Spotify obtenida:', spotifyUrl);

        try {
            console.log('[FALLBACK] Intento 7: Descarga Spotify API 2 (Delirius V2)');
            return await downloadSpotifyAudioApi2(spotifyUrl);
        } catch (e) {
            errors.push(`Descarga Spotify 2 (V2): ${e.message}`);
        }

        try {
            console.log('[FALLBACK] Intento 8: Descarga Spotify API 1 (Delirius V1)');
            return await downloadSpotifyAudioApi1(spotifyUrl);
        } catch (e) {
            errors.push(`Descarga Spotify 1 (V1): ${e.message}`);
        }
    } else {
        errors.push('No se pudo obtener URL de Spotify');
    }

    // --- INTENTOS DE APPLE MUSIC ---
    
    if (query.includes('music.apple.com')) {
        appleMusicUrl = query;
        console.log('[FALLBACK] Link directo de Apple Music detectado');
    } else {
        try {
            console.log('[FALLBACK] Intento 9: Buscando en Apple Music (API 1)');
            appleMusicUrl = await searchAppleMusicApi1(query);
        } catch (e) {
            errors.push(`Búsqueda Apple Music 1: ${e.message}`);
            try {
                console.log('[FALLBACK] Intento 10: Buscando en Apple Music (API 2)');
                appleMusicUrl = await searchAppleMusicApi2(query);
            } catch (e2) {
                errors.push(`Búsqueda Apple Music 2: ${e2.message}`);
            }
        }
    }

    if (appleMusicUrl) {
        console.log('[FALLBACK] URL de Apple Music obtenida:', appleMusicUrl);

        try {
            console.log('[FALLBACK] Intento 11: Descarga Apple Music API 1');
            return await downloadAppleMusicAudioApi1(appleMusicUrl);
        } catch (e) {
            errors.push(`Descarga Apple Music 1: ${e.message}`);
        }
    } else {
        errors.push('No se pudo obtener URL de Apple Music');
    }

    // Si llegamos aquí, todo falló
    console.error('[FALLBACK] Todos los métodos fallaron');
    throw new Error(`No se pudo descargar de ninguna fuente.\n\n❌ *Errores encontrados:*\n${errors.map((e, i) => `${i + 1}. ${e}`).join('\n')}`);
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO) {
        return await message.reply(
            '⚠️ *COMANDO TEMPORALMENTE DESHABILITADO*\n\n' +
            '_Este comando está en mantenimiento y volverá pronto._\n\n' +
            '💡 _Disculpa las molestias_'
        );
    }

    if (!text) {
        return await message.reply(
            `❌ Por favor envía un link o título de canción.\n\n*Ejemplos:*\n` +
            `• ${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n` +
            `• ${usedPrefix + command} https://open.spotify.com/track/...\n` +
            `• ${usedPrefix + command} https://music.apple.com/...\n` +
            `• ${usedPrefix + command} Bad Bunny Amorfoda`
        );
    }

    let tempFile = null;

    try {
        await message.reply('🔍 Buscando audio en múltiples fuentes...\n_RobleAPI → YouTube → Spotify → Apple Music_');

        // Detectar si es link directo
        const isDirectLink = text.includes('youtube.com') || 
                            text.includes('youtu.be') || 
                            text.includes('spotify.com') || 
                            text.includes('music.apple.com');

        // Intentar descarga con fallback automático
        const result = await downloadAudioWithFallback(text, isDirectLink);
        const { download, title, duration, thumbnail, source, isDownloaded, fileSize } = result;

        // Enviar miniatura si existe
        if (thumbnail) {
            try {
                await conn.sendMessage(message.from, {
                    image: { url: thumbnail },
                    caption: `🎵 *${title}*\n⏱️ Duración: ${duration}\n📡 Fuente: ${source}\n\n_Enviando audio..._`
                }, { quoted: message._baileyMessage });
            } catch (imgErr) {
                console.error('[MUSICYT] Error al enviar imagen:', imgErr.message);
                await message.reply(`🎵 *${title}*\n⏱️ Duración: ${duration}\n📡 Fuente: ${source}\n\n_Enviando audio..._`);
            }
        } else {
             await message.reply(`🎵 *${title}*\n⏱️ Duración: ${duration}\n📡 Fuente: ${source}\n\n_Enviando audio..._`);
        }

        // Si la Nueva API ya descargó el archivo
        if (isDownloaded && result.tempFile) {
            tempFile = result.tempFile;
            const audioBuffer = fs.readFileSync(tempFile);
            const fileName = sanitizeFilename(title) + '.mp3';

            try {
                if (fileSize > LimitAud) {
                    console.log('[MUSICYT] Enviando como documento (archivo > 100MB)');
                    await conn.sendMessage(message.from, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName
                    }, { quoted: message._baileyMessage });
                } else {
                    console.log('[MUSICYT] Enviando como audio');
                    await conn.sendMessage(message.from, {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName,
                        ptt: false
                    }, { quoted: message._baileyMessage });
                }
                
                console.log(`[MUSICYT] ✅ Audio enviado correctamente desde ${source}`);
                
            } catch (sendErr) {
                console.error('[MUSICYT] Error enviando audio:', sendErr.message);
                await message.reply('❌ Ocurrió un error al enviar el audio.');
            }
        } else {
            // Descargar desde URL (APIs antiguas)
            const tempDir = path.join(__dirname, '.temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

            tempFile = path.join(tempDir, sanitizeFilename(title) + '.mp3');

            console.log('[MUSICYT] Descargando desde:', download);
            const response = await axios.get(download, { 
                responseType: 'arraybuffer', 
                timeout: 90000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('La descarga del audio está vacía');
            }

            fs.writeFileSync(tempFile, Buffer.from(response.data, 'binary'));
            const stats = fs.statSync(tempFile);
            const fileSizeDownloaded = stats.size;
            console.log(`[MUSICYT] Archivo descargado: ${(fileSizeDownloaded / 1024 / 1024).toFixed(2)} MB`);

            if (fileSizeDownloaded < 1000) {
                throw new Error('El archivo descargado es demasiado pequeño o está corrupto');
            }

            const audioBuffer = fs.readFileSync(tempFile);
            const fileName = sanitizeFilename(title) + '.mp3';

            try {
                if (fileSizeDownloaded > LimitAud) {
                    console.log('[MUSICYT] Enviando como documento (archivo > 100MB)');
                    await conn.sendMessage(message.from, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName
                    }, { quoted: message._baileyMessage });
                } else {
                    console.log('[MUSICYT] Enviando como audio');
                    await conn.sendMessage(message.from, {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: fileName,
                        ptt: false
                    }, { quoted: message._baileyMessage });
                }
                
                console.log(`[MUSICYT] ✅ Audio enviado correctamente desde ${source}`);
                
            } catch (sendErr) {
                console.error('[MUSICYT] Error enviando audio:', sendErr.message);
                await message.reply('❌ Ocurrió un error al enviar el audio.');
            }
        }

        // Limpiar archivo temporal
        if (tempFile && fs.existsSync(tempFile)) {
            try { 
                fs.unlinkSync(tempFile); 
                console.log('[MUSICYT] Archivo temporal eliminado'); 
            } catch (unlinkErr) { 
                console.error('[MUSICYT] Error al eliminar archivo:', unlinkErr.message); 
            }
        }

    } catch (e) {
        console.error('[MUSICYT] Error general:', e?.message || e);
        
        // Limpiar archivo temporal en caso de error
        if (tempFile && fs.existsSync(tempFile)) {
            try { 
                fs.unlinkSync(tempFile); 
            } catch (unlinkErr) { 
                console.error('[MUSICYT] Error al eliminar archivo:', unlinkErr.message); 
            }
        }
        
        await message.reply(
            `❌ No se pudo descargar el audio después de intentar con todas las fuentes disponibles.\n\n` +
            `💡 *Sugerencias:*\n` +
            `• Intenta con otro título o link\n` +
            `• Verifica que el link sea válido\n` +
            `• Espera unos minutos y vuelve a intentar\n\n` +
            `_${e.message}_`
        );
    }
};

handler.help = ['musicyt <link o título>', 'ytmusic <link o título>', 'spotify <link o título>', 'applemusic <link o título>'];
handler.tags = ['audio', 'youtube', 'musica', 'spotify', 'applemusic'];
handler.command = /^(musicyt|ytaudio|audioyt|yt|ytmusic|music|musica|música|spotify|applemusic|apple|play|audio)$/i;

module.exports = handler;