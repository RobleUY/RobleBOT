const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ========================================
// CONFIGURACIÓN
// ========================================
const COMANDO_ACTIVADO = true
const LIMIT_MB = 100 // Límite de 100 MB para audios
const TIMEOUT_MS = 30000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 150)

// ========================================
// YOUTUBE DATA API V3 + YT-SEARCH (INFO ULTRA RÁPIDA)
// ========================================

function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function buildInfo(videoId, snippet) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró información en Data API')
  return buildInfo(videoId, item.snippet)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item || !item.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return buildInfo(item.id.videoId, item.snippet)
}

async function searchVideoInfoByHtml(query) {
  console.log('[MUSICYT INFO] Consultando búsqueda YouTube HTML fallback...')
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    maxRedirects: 10,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Referer': 'https://www.youtube.com/'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  const videoId = match[1]
  return await getVideoInfoById(videoId)
}

// Carrera en paralelo para obtener miniatura y título al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[MUSICYT INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[MUSICYT INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    if (!isLink && typeof text === 'string') {
      try {
        return await searchVideoInfoByHtml(text)
      } catch (htmlErr) {
        console.error('[MUSICYT INFO] Fallback HTML falló:', htmlErr.message)
      }
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ========================================
// APIS DE DESCARGA DE AUDIO
// ========================================

async function downloadFromRobleAPI(youtubeUrl) {
  const endpoint = `https://robleuy.vercel.app/robleapi/download/ytmp3?url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente RobleAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Referer': 'https://robleuy.vercel.app/'
    }
  })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_API_FAIL')
  console.log('[MUSICYT] ✅ Fuente RobleAPI entregó resultado')
  return {
    download: res.data.download_url,
    title: res.data.title || 'Audio',
    source: 'RobleAPI'
  }
}

// ========================================
// VALIDACIÓN DE BUFFER
// ========================================
function isValidAudioBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 50 * 1024) return false // menos de 50 KB = inválido
  // MP3: ID3 header
  if (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33) return true
  // MP3: sync bytes FF FB / FF F3 / FF F2
  if (buffer[0] === 0xFF && (buffer[1] === 0xFB || buffer[1] === 0xF3 || buffer[1] === 0xF2)) return true
  // Si pesa más de 500 KB asumimos válido
  if (buffer.length > 500 * 1024) return true
  return false
}

// ========================================
// CARRERA DE DESCARGA: TODAS EN PARALELO, GANA LA PRIMERA EN COMPLETAR EL BUFFER
// ========================================
async function getWorkingAudio(url, limitMb) {
  const sources = [
    { name: 'RobleAPI', fn: downloadFromRobleAPI }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(url)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []
  let limitExceededError = null

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[MUSICYT] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[MUSICYT] ${sourceName} entregó metadata, descargando archivo de audio...`)

    try {
      let downloadData
      if (Buffer.isBuffer(result.data.download)) {
        // Validar buffer directo si la fuente devuelve datos binarios
        if (!isValidAudioBuffer(result.data.download)) {
          console.log(`[MUSICYT] ${sourceName} buffer directo inválido o muy pequeño, probando siguiente...`)
          errors.push(`${sourceName}: buffer inválido`)
          continue
        }
        downloadData = {
          buffer: result.data.download,
          size: result.data.download.length,
          tempFile: null,
          sizeMB: (result.data.download.length / (1024 * 1024)).toFixed(2)
        }
      } else {
        downloadData = await downloadWithLimit(result.data.download, limitMb)
        // Validar buffer descargado
        if (!isValidAudioBuffer(downloadData.buffer)) {
          console.log(`[MUSICYT] ${sourceName} buffer descargado inválido o muy pequeño, probando siguiente...`)
          errors.push(`${sourceName}: buffer descargado inválido`)
          continue
        }
      }
      console.log(`[MUSICYT] 🏆 ¡GANADORA DE AUDIO! ${sourceName} descargó el audio exitosamente (${downloadData.sizeMB} MB)`)
      return { ...result.data, downloadData }
    } catch (downloadError) {
      if (downloadError.message?.startsWith('LIMIT_EXCEEDED:')) {
        limitExceededError = downloadError
        console.log(`[MUSICYT] ${sourceName} excede el límite de peso, probando siguiente...`)
        continue
      }
      console.log(`[MUSICYT] ${sourceName} tuvo error en descarga (${downloadError.message}), probando siguiente...`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  if (limitExceededError) throw limitExceededError
  console.error('[MUSICYT] Todas las fuentes de audio fallaron:', errors.join(' | '))
  throw new Error('No se pudo descargar el audio en este momento.')
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn
  if (!COMANDO_ACTIVADO) {
    return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*')
  }

  if (!text) {
    return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up`)
  }

  let tempFile = null

  try {
    const isLink = /https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)

    await message.reply(isLink ? '📥 Descargando...' : '🔍 Buscando...')

    // 1) Resolver la información y miniatura lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    const { url: youtubeUrl, title: videoTitle, thumbnailUrl } = videoInfo
    if (!extractVideoId(youtubeUrl)) {
      throw new Error('No se obtuvo un link válido de YouTube para descargar.')
    }

    // 2) Tarea A: Enviar la miniatura inmediatamente
    const sendThumbnailTask = (async () => {
      try {
        if (thumbnailUrl) {
          await sock.sendMessage(message.from, {
            image: { url: thumbnailUrl },
            caption: `🎧 *${videoTitle}*\n⏳ Descargando audio...`
          }, { quoted: message._baileyMessage })
        }
      } catch (thumbError) {
        console.error('[MUSICYT] No se pudo enviar la miniatura:', thumbError.message)
      }
    })()

    // 3) Tarea B: Descargar audio desde RobleAPI y enviar el archivo
    const sendAudioTask = (async () => {
      const { title, source, downloadData } = await getWorkingAudio(youtubeUrl, LIMIT_MB)
      tempFile = downloadData.tempFile
      const sizeMB = downloadData.sizeMB

      console.log(`[MUSICYT] 🚀 Enviando a WhatsApp audio descargado vía ${source} (${sizeMB} MB)...`)

      const fileName = sanitizeFilename(title || videoTitle) + '.mp3'

      await sock.sendMessage(message.from, {
        audio: downloadData.buffer,
        mimetype: 'audio/mpeg',
        fileName: fileName,
        ptt: false
      }, { quoted: message._baileyMessage })

      console.log(`[MUSICYT] ✅ Audio enviado a WhatsApp con éxito (vía ${source})`)
    })()

    // Corren en paralelo
    await Promise.all([sendThumbnailTask, sendAudioTask])

  } catch (e) {
    console.error('[MUSICYT] Error:', e.message)
    await message.reply(`❌ *No se pudo descargar el audio en este momento.*`)
  } finally {
    if (tempFile) {
      cleanupTempFile(tempFile)
    }
  }
}

handler.help = ['play <título/link>']
handler.tags = ['audio']
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i

module.exports = handler