const axios = require('axios')
const yts = require('yt-search')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

// ========================================
// CONFIGURACIÓN
// ========================================
const COMANDO_ACTIVADO = true
const LIMIT_MB = 100 // Límite de 100 MB para audios
const TIMEOUT_MS = 30000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyA1o_w-x8EMPwUzoqdSMhEyzmyvtRoXVHw'

const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 150)

// ========================================
// YOUTUBE DATA API V3 + YT-SEARCH (INFO ULTRA RÁPIDA)
// ========================================

function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function buildInfo(videoId, snippet) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró información en Data API')
  return buildInfo(videoId, item.snippet)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item || !item.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return buildInfo(item.id.videoId, item.snippet)
}

async function searchVideoInfoByHtml(query) {
  console.log('[MUSICYT INFO] Consultando búsqueda YouTube HTML fallback...')
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    maxRedirects: 10,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Referer': 'https://www.youtube.com/'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  const videoId = match[1]
  return await getVideoInfoById(videoId)
}

// Carrera en paralelo para obtener miniatura y título al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[MUSICYT INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[MUSICYT INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    if (!isLink && typeof text === 'string') {
      try {
        return await searchVideoInfoByHtml(text)
      } catch (htmlErr) {
        console.error('[MUSICYT INFO] Fallback HTML falló:', htmlErr.message)
      }
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ========================================
// APIS DE DESCARGA DE AUDIO
// ========================================

async function downloadFromRobleAPI(youtubeUrl) {
  const endpoint = `http://olivia.hidencloud.com:24733/robleapi/downloads/ytaudio?link=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente RobleAPI (Olivia)...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.result || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('ROBLE_API_FAIL')
  console.log('[MUSICYT] ✅ Fuente RobleAPI (Olivia) entregó resultado')
  return {
    download,
    title: data?.title || res.data?.title || 'Audio',
    source: 'RobleAPI'
  }
}

async function downloadFromOliviaAPI(youtubeUrl) {
  const endpoint = `http://olivia.hidencloud.com:24733/robleapi/downloads/ytaudio?link=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente OliviaAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.result || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('OLIVIA_API_FAIL')
  console.log('[MUSICYT] ✅ Fuente OliviaAPI entregó resultado')
  return {
    download,
    title: data?.title || res.data?.title || 'Audio',
    source: 'OliviaAPI'
  }
}

async function downloadFromDeliriusAPI(youtubeUrl) {
  // API actualizada según documentación: https://api.delirius.online/download/ytmp3
  const endpoint = `https://api.delirius.online/download/ytmp3?url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente DeliriusAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  // Según ejemplo: {"creator": "Delirius (神志不清)", "status": true, "data": {"download": "...", "title": "..."}}
  const data = res.data?.data || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('DELIRIUS_FAIL')
  console.log('[MUSICYT] ✅ Fuente DeliriusAPI entregó resultado')
  return {
    download,
    title: data?.title || data?.creator || 'Audio',
    source: 'DeliriusAPI'
  }
}

async function downloadFromDeliriusOnlineAPI(youtubeUrl) {
  const endpoint = `https://api.delirius.online/download/ytmp3?url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente DeliriusOnline...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.data || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('DELIRIUS_ONLINE_FAIL')
  console.log('[MUSICYT] ✅ Fuente DeliriusOnline entregó resultado')
  return {
    download,
    title: data?.title || data?.creator || 'Audio',
    source: 'DeliriusOnline'
  }
}

async function downloadFromSankaAPI(youtubeUrl) {
  const endpoint = `https://www.sankavollerei.com/download/ytmp3?apikey=planaai&url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente SankaAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  const data = res.data?.result || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('SANKA_FAIL')
  console.log('[MUSICYT] ✅ Fuente SankaAPI entregó resultado')
  return {
    download,
    title: data?.title || res.data?.title || 'Audio',
    source: 'SankaAPI'
  }
}

async function downloadFromSankaWebId(youtubeUrl) {
  // Endpoint actualizado según documentación
  const endpoint = `https://www.sankavollerei.web.id/download/ytmp3?apikey=planaai&url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente SankaWebID...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*'
    }
  })
  // Según ejemplo: {"status": true, "creator": "Sanka Vollerei", "result": {"download": "...", "title": "..."}}
  const data = res.data?.result || res.data
  const download = data?.download || data?.download_url || res.data?.download_url
  if (!res.data?.status || !download) throw new Error('SANKA_WEBID_FAIL')
  console.log('[MUSICYT] ✅ Fuente SankaWebID entregó resultado')
  return {
    download,
    title: data?.title || res.data?.result?.title || 'Audio',
    source: 'SankaWebID'
  }
}

async function downloadFromYTDL(youtubeUrl) {
  const endpoint = `https://api.agatz.xyz/api/ytmp3?url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente YTDL-Agatz...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'application/json'
    }
  })
  const data = res.data?.data || res.data
  const download = data?.download || data?.dl_link || data?.url
  if (!download) throw new Error('YTDL_AGATZ_FAIL')
  console.log('[MUSICYT] ✅ Fuente YTDL-Agatz entregó resultado')
  return {
    download,
    title: data?.title || 'Audio',
    source: 'YTDL-Agatz'
  }
}

async function downloadFromNezuko(youtubeUrl) {
  const endpoint = `https://api.nexoracle.com/downloader/ytmp3?apikey=free_key@maher_apis&url=${encodeURIComponent(youtubeUrl)}`
  console.log('[MUSICYT] Consultando fuente Nezuko...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'application/json'
    }
  })
  const data = res.data?.result || res.data
  const download = data?.download || data?.url || data?.link
  if (!res.data?.status || !download) throw new Error('NEZUKO_FAIL')
  console.log('[MUSICYT] ✅ Fuente Nezuko entregó resultado')
  return {
    download,
    title: data?.title || 'Audio',
    source: 'Nezuko'
  }
}

async function downloadFromVihangaAPI(youtubeUrl) {
  const videoId = extractVideoId(youtubeUrl)
  if (!videoId) throw new Error('No se pudo extraer video ID')
  const endpoint = `https://vihangayt.me/download/ytmp3?url=https://www.youtube.com/watch?v=${videoId}`
  console.log('[MUSICYT] Consultando fuente VihangaAPI...')
  const res = await axios.get(endpoint, {
    timeout: TIMEOUT_MS,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'application/json'
    }
  })
  const data = res.data?.data || res.data
  const download = data?.download || data?.dl_link || data?.url
  if (!res.data?.status || !download) throw new Error('VIHANGA_FAIL')
  console.log('[MUSICYT] ✅ Fuente VihangaAPI entregó resultado')
  return {
    download,
    title: data?.title || 'Audio',
    source: 'VihangaAPI'
  }
}

// ========================================
// VALIDACIÓN DE BUFFER
// ========================================
function isValidAudioBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 50 * 1024) return false // menos de 50 KB = inválido
  // MP3: ID3 header
  if (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33) return true
  // MP3: sync bytes FF FB / FF F3 / FF F2
  if (buffer[0] === 0xFF && (buffer[1] === 0xFB || buffer[1] === 0xF3 || buffer[1] === 0xF2)) return true
  // Si pesa más de 500 KB asumimos válido
  if (buffer.length > 500 * 1024) return true
  return false
}

const { 
  isDownloading, 
  startDownload, 
  trackTempFile, 
  cancelDownload, 
  finishDownload 
} = require('../../lib/downloadManager')

// ========================================
// CARRERA DE DESCARGA: TODAS EN PARALELO, GANA LA PRIMERA EN COMPLETAR EL BUFFER
// ========================================
async function getWorkingAudio(url, limitMb, signal = null) {
  const sources = [
    { name: 'OliviaAPI', fn: downloadFromOliviaAPI },
    { name: 'RobleAPI', fn: downloadFromRobleAPI },
    { name: 'DeliriusOnline', fn: downloadFromDeliriusOnlineAPI },
    { name: 'DeliriusAPI', fn: downloadFromDeliriusAPI },
    { name: 'YTDL-Agatz', fn: downloadFromYTDL },
    { name: 'Nezuko', fn: downloadFromNezuko },
    { name: 'SankaWebID', fn: downloadFromSankaWebId },
    { name: 'SankaAPI', fn: downloadFromSankaAPI },
    { name: 'VihangaAPI', fn: downloadFromVihangaAPI }
  ]

  const tasks = sources.map((source) =>
    source.fn(url)
      .then(async (data) => {
        if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
        const sourceName = source.name
        console.log(`[MUSICYT] ${sourceName} entregó metadata, iniciando descarga de audio...`)

        if (Buffer.isBuffer(data.download)) {
          if (!isValidAudioBuffer(data.download)) {
            throw new Error(`${sourceName}: buffer inválido o muy pequeño`)
          }
          return {
            ...data,
            downloadData: {
              buffer: data.download,
              size: data.download.length,
              tempFile: null,
              sizeMB: (data.download.length / (1024 * 1024)).toFixed(2)
            }
          }
        }

        const downloadData = await downloadWithLimit(data.download, limitMb, {}, signal)
        if (!isValidAudioBuffer(downloadData.buffer)) {
          throw new Error(`${sourceName}: buffer descargado inválido o muy pequeño`)
        }

        return {
          ...data,
          downloadData
        }
      })
      .catch((error) => {
        const message = error?.message || String(error)
        console.log(`[MUSICYT] ❌ ${source.name} falló: ${message}`)
        throw new Error(`${source.name}: ${message}`)
      })
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[MUSICYT] 🏆 ¡GANADORA DE AUDIO! ${winner.source} descargó el audio exitosamente (${winner.downloadData.sizeMB} MB)`)
    return winner
  } catch (e) {
    if (signal?.aborted || e.message === 'DOWNLOAD_ABORTED') {
      throw new Error('DOWNLOAD_ABORTED')
    }
    console.error('[MUSICYT] Todas las fuentes de audio fallaron.')
    throw new Error('No se pudo descargar el audio en este momento.')
  }
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn
  if (!COMANDO_ACTIVADO) {
    return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*')
  }

  const userId = message.author || message.sender
  const chatId = message.from
  const cleanInput = (text || '').trim().toLowerCase()

  // 1. Comando de Cancelación/Detener
  if (['stop', 'cancel', 'detener', 'cancelar'].includes(cleanInput)) {
    const wasCanceled = cancelDownload(chatId, userId)
    if (wasCanceled) {
      return await message.reply('🛑 *Descarga de audio cancelada correctamente.*')
    } else {
      return await message.reply('ℹ️ *No tienes ninguna descarga en curso para cancelar.*')
    }
  }

  if (!text) {
    return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up\n*Para cancelar:* ${usedPrefix + command} stop`)
  }

  // 2. Control de Concurrencia por Usuario: 1 sola descarga activa a la vez
  if (isDownloading(chatId, userId)) {
    return await message.reply(
      `⚠️ *Ya tienes una descarga en curso.*\nPor favor espera a que termine o usa *${usedPrefix + command} stop* para cancelarla.`
    )
  }

  let downloadObj = null
  let tempFile = null

  try {
    downloadObj = startDownload(chatId, userId, 'audio', text)
    const { signal } = downloadObj

    // Verificar si la red del servidor está caída antes de intentar descargas
    if (global.networkGuard && global.networkGuard.isNetworkDown()) {
      const status = global.networkGuard.getCircuitStatus()
      const secsLeft = Math.ceil(status.recoveryIn / 1000)
      finishDownload(chatId, userId)
      return await message.reply(`⚠️ *La red del servidor está caída temporalmente.*\nSe detectaron errores masivos de conexión. Intenta en ~${secsLeft}s.`)
    }

    const isLink = /https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)

    await message.reply(isLink ? '📥 Descargando audio...' : '🔍 Buscando audio...')

    if (signal.aborted) return

    // 1) Resolver información lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    if (signal.aborted) return

    const { url: youtubeUrl, title: videoTitle, thumbnailUrl } = videoInfo
    if (!extractVideoId(youtubeUrl)) {
      throw new Error('No se obtuvo un link válido de YouTube para descargar.')
    }

    // 2) Enviar miniatura inmediatamente
    const sendThumbnailTask = (async () => {
      try {
        if (thumbnailUrl && !signal.aborted) {
          await sock.sendMessage(message.from, {
            image: { url: thumbnailUrl },
            caption: `🎧 *${videoTitle}*\n⏳ Descargando audio...\n_Para cancelar usa: ${usedPrefix + command} stop_`
          }, { quoted: message._baileyMessage })
        }
      } catch (thumbError) {
        console.error('[MUSICYT] No se pudo enviar la miniatura:', thumbError.message)
      }
    })()

    // 3) Descargar audio y enviar archivo
    const sendAudioTask = (async () => {
      const { title, source, downloadData } = await getWorkingAudio(youtubeUrl, LIMIT_MB, signal)
      if (signal.aborted) return

      tempFile = downloadData.tempFile
      if (tempFile) trackTempFile(chatId, userId, tempFile)

      const sizeMB = downloadData.sizeMB
      console.log(`[MUSICYT] 🚀 Enviando a WhatsApp audio descargado vía ${source} (${sizeMB} MB)...`)

      const fileName = sanitizeFilename(title || videoTitle) + '.mp3'

      if (signal.aborted) return

      await sock.sendMessage(message.from, {
        audio: downloadData.buffer,
        mimetype: 'audio/mpeg',
        fileName: fileName,
        ptt: false
      }, { quoted: message._baileyMessage })

      console.log(`[MUSICYT] ✅ Audio enviado a WhatsApp con éxito (vía ${source})`)
    })()

    await Promise.all([sendThumbnailTask, sendAudioTask])

  } catch (e) {
    if (e.message === 'DOWNLOAD_ABORTED' || downloadObj?.signal?.aborted) {
      console.log('[MUSICYT] 🛑 Descarga cancelada por el usuario.')
      return
    }
    console.error('[MUSICYT] Error:', e.message)
    if (e.message?.startsWith('LIMIT_EXCEEDED:')) {
      const sizeMB = e.message.split(':')[1]
      return await message.reply(
        `❌ *EL AUDIO SUPERA EL LÍMITE PERMITIDO*\n\n` +
        `📦 *Tamaño del audio:* ${sizeMB} MB\n` +
        `⚠️ *Límite máximo para audio:* ${LIMIT_MB} MB\n\n` +
        `💡 _Intenta con una canción o audio más corto._`
      )
    }
    await message.reply(
      `❌ *NO SE PUDO DESCARGAR EL AUDIO*\n\n` +
      `📌 *Motivo:* ${e.message?.includes('No se obtuvo') || e.message?.includes('No se pudo resolver') ? 'No se encontraron resultados para tu búsqueda.' : 'Las fuentes de descarga no están disponibles en este momento o el enlace es privado/inválido.'}\n\n` +
      `💡 _Verifica el nombre o enlace e intenta nuevamente._`
    )
  } finally {
    finishDownload(chatId, userId)
    if (tempFile) {
      cleanupTempFile(tempFile)
    }
  }
}

handler.help = ['play <título/link>', 'play stop']
handler.tags = ['audio']
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i

module.exports = handler