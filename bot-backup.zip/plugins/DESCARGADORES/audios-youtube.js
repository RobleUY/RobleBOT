const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true; 
const ROBLE_API_BASE = 'https://www.robleuy.site/robleapi/download/ytmp3';
// ========================================

const LimitAud = 100 * 1024 * 1024; // 100MB
const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// ========================================
// FUNCIONES DE YOUTUBE
// ========================================

async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) throw new Error('No se encontraron resultados en YouTube');
        return r.videos[0];
    } catch (e) {
        console.error('[MUSICYT] Error en búsqueda:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

async function downloadFromRobleAPI(youtubeUrl) {
    try {
        const endpoint = `${ROBLE_API_BASE}?url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[MUSICYT] Solicitando a RobleAPI...');
        
        const res = await axios.get(endpoint, { timeout: 30000 });
        const data = res.data;

        if (!data.ok || !data.download_url) {
            throw new Error('La API de Roble no devolvió un enlace válido');
        }

        return {
            download: data.download_url,
            title: data.title || 'Audio',
            source: 'RobleAPI'
        };
    } catch (error) {
        console.error('[MUSICYT] Error en RobleAPI:', error.message);
        throw error;
    }
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO) {
        return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*');
    }

    if (!text) {
        return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up`);
    }

    let tempFile = null;

    try {
        await message.reply('🔍 Buscando y enviando el audio...');

        let youtubeUrl = text;
        let videoTitle = 'Audio';

        // Si no es un link, buscar en YouTube
        if (!/https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)) {
            const searchResult = await searchYouTube(text);
            youtubeUrl = searchResult.url;
            videoTitle = searchResult.title;
        }

        // Obtener link de descarga de la API
        const result = await downloadFromRobleAPI(youtubeUrl);
        const { download, title } = result;

        // Preparar archivo temporal
        const tempDir = path.join(__dirname, '.temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        tempFile = path.join(tempDir, sanitizeFilename(title) + '.mp3');

        console.log('[MUSICYT] Descargando buffer...');
        const response = await axios.get(download, { 
            responseType: 'arraybuffer', 
            timeout: 60000 
        });

        if (!response.data || response.data.length < 1000) {
            throw new Error('El archivo descargado no es válido.');
        }

        fs.writeFileSync(tempFile, Buffer.from(response.data, 'binary'));
        const stats = fs.statSync(tempFile);
        const fileName = sanitizeFilename(title) + '.mp3';

        // Enviar el archivo
        if (stats.size > LimitAud) {
            await conn.sendMessage(message.from, {
                document: fs.readFileSync(tempFile),
                mimetype: 'audio/mpeg',
                fileName: fileName
            }, { quoted: message._baileyMessage });
        } else {
            await conn.sendMessage(message.from, {
                audio: fs.readFileSync(tempFile),
                mimetype: 'audio/mpeg',
                fileName: fileName,
                ptt: false
            }, { quoted: message._baileyMessage });
        }

        console.log(`[MUSICYT] ✅ Enviado: ${title}`);

    } catch (e) {
        console.error('[MUSICYT] Error:', e.message);
        await message.reply(`❌ *Error:* ${e.message}`);
    } finally {
        // Limpiar archivo temporal
        if (tempFile && fs.existsSync(tempFile)) {
            try { fs.unlinkSync(tempFile); } catch (err) {}
        }
    }
};

handler.help = ['play <título/link>'];
handler.tags = ['audio'];
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i;

module.exports = handler;