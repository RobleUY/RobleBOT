const axios = require('axios');
const fs = require('fs');
const path = require('path');
const yts = require('yt-search');

// ========================================
// CONFIGURACIÓN DE ACTIVACIÓN DEL COMANDO
// ========================================
const COMANDO_ACTIVADO = true; // Cambiar a false para desactivar el comando
// ========================================

const LimitAud = 100 * 1024 * 1024; // 700MB
const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 200);

// Validar si una URL es válida
function isValidUrl(url) {
    if (!url || url === 'undefined' || url.includes('undefined')) return false;
    try {
        const parsed = new URL(url);
        return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (e) {
        return false;
    }
}

// ========================================
// FUNCIONES DE YOUTUBE
// ========================================

async function getFromSanka(youtubeUrl) {
    try {
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            throw new Error('No es una URL válida de YouTube');
        }

        const endpoint = `https://www.sankavollerei.com/download/ytmp3?apikey=planaai&url=${encodeURIComponent(youtubeUrl)}`;
        console.log('[MUSICYT] Solicitando a Sanka Vollerei (YouTube)...');
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
        const json = res.data;

        if (!json?.status) throw new Error('El servidor rechazó la solicitud');
        if (!json?.result) throw new Error('Sin resultado en la respuesta');

        const { download, title, duration, thumbnail } = json.result;

        if (!download || download === 'undefined' || !isValidUrl(download)) {
            throw new Error('No se obtuvo link de descarga válido');
        }
        if (!title) throw new Error('No se obtuvo el título del video');

        console.log('[MUSICYT] Datos de YouTube obtenidos correctamente:', { title, duration });

        return {
            download,
            title: title || 'Audio',
            duration: duration || 'Desconocida',
            thumbnail: thumbnail || null,
            source: 'YouTube'
        };

    } catch (error) {
        console.error('[MUSICYT] Error en getFromSanka:', error?.message || error);
        throw error;
    }
}

async function searchYouTube(query) {
    try {
        const r = await yts(query);
        if (!r || !r.videos || r.videos.length === 0) throw new Error('No se encontraron resultados en YouTube');
        return r.videos[0].url;
    } catch (e) {
        console.error('[MUSICYT] Error en búsqueda de YouTube:', e.message);
        throw new Error('Error buscando el video en YouTube');
    }
}

// ========================================
// FUNCIONES DE SPOTIFY
// ========================================

async function searchSpotify(query) {
    try {
        console.log('[SPOTIFY] Buscando en Spotify (Sanka):', query);
        const endpoint = `https://www.sankavollerei.com/search/spotify?apikey=planaai&q=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.result || res.data.result.length === 0) {
            throw new Error('No se encontraron resultados en Spotify');
        }

        console.log('[SPOTIFY] Encontrado:', res.data.result[0].title);
        return res.data.result[0].track_url;
    } catch (e) {
        console.error('[SPOTIFY] Error en búsqueda Sanka:', e.message);
        throw e;
    }
}

async function searchSpotifyDelirius(query) {
    try {
        console.log('[SPOTIFY] Buscando en Spotify (Delirius):', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/spotify?q=${encodeURIComponent(query)}&limit=20`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.data || res.data.data.length === 0) {
            throw new Error('No se encontraron resultados en Spotify');
        }

        console.log('[SPOTIFY] Encontrado:', res.data.data[0].title);
        return res.data.data[0].url;
    } catch (e) {
        console.error('[SPOTIFY] Error en búsqueda Delirius:', e.message);
        throw e;
    }
}

async function downloadSpotifyV1(spotifyUrl) {
    try {
        console.log('[SPOTIFY] Intentando descarga V1...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/spotifydl?url=${encodeURIComponent(spotifyUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos V1');

        const { url, title, author, image, duration } = res.data.data;
        
        if (!url || !isValidUrl(url)) {
            throw new Error('URL de descarga V1 inválida o undefined');
        }

        console.log('[SPOTIFY] V1 OK - URL:', url);

        return {
            download: url,
            title: `${author} - ${title}`,
            duration: duration ? `${Math.floor(duration / 1000)}s` : 'Desconocida',
            thumbnail: image,
            source: 'Spotify (V1)'
        };
    } catch (e) {
        console.error('[SPOTIFY] Error V1:', e.message);
        throw e;
    }
}

async function downloadSpotifyV2(spotifyUrl) {
    try {
        console.log('[SPOTIFY] Intentando descarga V2...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/spotifydlv2?url=${encodeURIComponent(spotifyUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos V2');

        const { url, title, artist, duration, image } = res.data.data;
        
        if (!url || !isValidUrl(url)) {
            throw new Error('URL de descarga V2 inválida o undefined');
        }

        console.log('[SPOTIFY] V2 OK - URL:', url);

        return {
            download: url,
            title: `${artist} - ${title}`,
            duration: duration || 'Desconocida',
            thumbnail: image,
            source: 'Spotify (V2)'
        };
    } catch (e) {
        console.error('[SPOTIFY] Error V2:', e.message);
        throw e;
    }
}

// ========================================
// FUNCIONES DE APPLE MUSIC
// ========================================

async function searchAppleMusicV1(query) {
    try {
        console.log('[APPLE MUSIC] Buscando en Apple Music V1:', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/applemusic?text=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data || !Array.isArray(res.data) || res.data.length === 0) {
            throw new Error('No se encontraron resultados en Apple Music V1');
        }

        // Priorizar canciones sobre álbumes/videos
        const track = res.data.find(item => item.type === 'Canción') || res.data[0];
        
        console.log('[APPLE MUSIC] Encontrado:', track.title, '-', track.artists);
        return track.url;
    } catch (e) {
        console.error('[APPLE MUSIC] Error en búsqueda V1:', e.message);
        throw e;
    }
}

async function searchAppleMusicV2(query) {
    try {
        console.log('[APPLE MUSIC] Buscando en Apple Music V2:', query);
        const endpoint = `https://delirius-apiofc.vercel.app/search/applemusicv2?query=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.data || res.data.data.length === 0) {
            throw new Error('No se encontraron resultados en Apple Music V2');
        }

        console.log('[APPLE MUSIC] Encontrado:', res.data.data[0].title, '-', res.data.data[0].artist);
        return res.data.data[0].url;
    } catch (e) {
        console.error('[APPLE MUSIC] Error en búsqueda V2:', e.message);
        throw e;
    }
}

async function downloadAppleMusic(appleMusicUrl) {
    try {
        console.log('[APPLE MUSIC] Intentando descarga...');
        const endpoint = `https://delirius-apiofc.vercel.app/download/applemusicdl?url=${encodeURIComponent(appleMusicUrl)}`;
        const res = await axios.get(endpoint, { timeout: 45000 });

        if (!res.data?.status || !res.data?.data) throw new Error('Sin datos de Apple Music');

        const { download, name, artists, duration, image } = res.data.data;
        
        if (!download || !isValidUrl(download)) {
            throw new Error('URL de descarga de Apple Music inválida');
        }

        console.log('[APPLE MUSIC] OK - URL:', download);

        return {
            download,
            title: `${artists} - ${name}`,
            duration: duration || 'Desconocida',
            thumbnail: image,
            source: 'Apple Music'
        };
    } catch (e) {
        console.error('[APPLE MUSIC] Error en descarga:', e.message);
        throw e;
    }
}

// ========================================
// FUNCIÓN PRINCIPAL CON FALLBACK
// ========================================

async function downloadAudioWithFallback(query, isDirectLink = false) {
    const errors = [];

    // INTENTO 1: YouTube (si es link directo o búsqueda)
    try {
        console.log('[FALLBACK] Intento 1: YouTube');
        let youtubeUrl = query;

        if (!isDirectLink || (!query.includes('youtube.com') && !query.includes('youtu.be'))) {
            youtubeUrl = await searchYouTube(query);
        }

        return await getFromSanka(youtubeUrl);
    } catch (e) {
        errors.push(`YouTube: ${e.message}`);
        console.log('[FALLBACK] YouTube falló, intentando Spotify...');
    }

    // INTENTO 2-6: SPOTIFY
    let spotifyUrl = null;
    
    if (query.includes('spotify.com')) {
        spotifyUrl = query;
        console.log('[FALLBACK] Link directo de Spotify detectado');
    } else {
        // Intenta buscar en Spotify (dos APIs)
        try {
            console.log('[FALLBACK] Intento 2: Buscando en Spotify (Sanka)');
            spotifyUrl = await searchSpotify(query);
        } catch (e) {
            errors.push(`Búsqueda Spotify Sanka: ${e.message}`);
            try {
                console.log('[FALLBACK] Intento 3: Buscando en Spotify (Delirius)');
                spotifyUrl = await searchSpotifyDelirius(query);
            } catch (e2) {
                errors.push(`Búsqueda Spotify Delirius: ${e2.message}`);
            }
        }
    }

    if (spotifyUrl) {
        console.log('[FALLBACK] URL de Spotify obtenida:', spotifyUrl);

        // INTENTO 4: Spotify V2
        try {
            console.log('[FALLBACK] Intento 4: Descarga Spotify V2');
            return await downloadSpotifyV2(spotifyUrl);
        } catch (e) {
            errors.push(`Spotify V2: ${e.message}`);
        }

        // INTENTO 5: Spotify V1
        try {
            console.log('[FALLBACK] Intento 5: Descarga Spotify V1');
            return await downloadSpotifyV1(spotifyUrl);
        } catch (e) {
            errors.push(`Spotify V1: ${e.message}`);
        }
    } else {
        errors.push('No se pudo obtener URL de Spotify');
    }

    // INTENTO 6-8: APPLE MUSIC
    let appleMusicUrl = null;

    if (query.includes('music.apple.com')) {
        appleMusicUrl = query;
        console.log('[FALLBACK] Link directo de Apple Music detectado');
    } else {
        // Intenta buscar en Apple Music (dos APIs)
        try {
            console.log('[FALLBACK] Intento 6: Buscando en Apple Music V1');
            appleMusicUrl = await searchAppleMusicV1(query);
        } catch (e) {
            errors.push(`Búsqueda Apple Music V1: ${e.message}`);
            try {
                console.log('[FALLBACK] Intento 7: Buscando en Apple Music V2');
                appleMusicUrl = await searchAppleMusicV2(query);
            } catch (e2) {
                errors.push(`Búsqueda Apple Music V2: ${e2.message}`);
            }
        }
    }

    if (appleMusicUrl) {
        console.log('[FALLBACK] URL de Apple Music obtenida:', appleMusicUrl);

        // INTENTO 8: Apple Music Download
        try {
            console.log('[FALLBACK] Intento 8: Descarga Apple Music');
            return await downloadAppleMusic(appleMusicUrl);
        } catch (e) {
            errors.push(`Apple Music: ${e.message}`);
        }
    } else {
        errors.push('No se pudo obtener URL de Apple Music');
    }

    // Si llegamos aquí, todo falló
    console.error('[FALLBACK] Todos los métodos fallaron');
    throw new Error(`No se pudo descargar de ninguna fuente.\n\n❌ *Errores encontrados:*\n${errors.map((e, i) => `${i + 1}. ${e}`).join('\n')}`);
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO) {
        return await message.reply(
            '⚠️ *COMANDO TEMPORALMENTE DESHABILITADO*\n\n' +
            '_Este comando está en mantenimiento y volverá pronto._\n\n' +
            '💡 _Disculpa las molestias_'
        );
    }

    if (!text) {
        return await message.reply(
            `❌ Por favor envía un link o título de canción.\n\n*Ejemplos:*\n` +
            `• ${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n` +
            `• ${usedPrefix + command} https://open.spotify.com/track/...\n` +
            `• ${usedPrefix + command} https://music.apple.com/...\n` +
            `• ${usedPrefix + command} Bad Bunny Amorfoda`
        );
    }

    try {
        await message.reply('🔍 Buscando audio en múltiples fuentes...\n_YouTube → Spotify → Apple Music_');

        // Detectar si es link directo
        const isDirectLink = text.includes('youtube.com') || 
                            text.includes('youtu.be') || 
                            text.includes('spotify.com') || 
                            text.includes('music.apple.com');

        // Intentar descarga con fallback automático
        const result = await downloadAudioWithFallback(text, isDirectLink);
        const { download, title, duration, thumbnail, source } = result;

        // Enviar miniatura si existe
        if (thumbnail) {
            try {
                await conn.sendMessage(message.from, {
                    image: { url: thumbnail },
                    caption: `🎵 *${title}*\n⏱️ Duración: ${duration}\n📡 Fuente: ${source}\n\n_Enviando audio..._`
                }, { quoted: message._baileyMessage });
            } catch (imgErr) {
                console.error('[MUSICYT] Error al enviar imagen:', imgErr.message);
            }
        }

        // Preparar archivo temporal
        const tempDir = path.join(__dirname, '.temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const tempFile = path.join(tempDir, sanitizeFilename(title) + '.mp3');

        // Descargar audio
        console.log('[MUSICYT] Descargando desde:', download);
        const response = await axios.get(download, { 
            responseType: 'arraybuffer', 
            timeout: 90000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
        
        if (!response.data || response.data.length === 0) {
            throw new Error('La descarga del audio está vacía');
        }

        fs.writeFileSync(tempFile, Buffer.from(response.data, 'binary'));
        const stats = fs.statSync(tempFile);
        const fileSize = stats.size;
        console.log(`[MUSICYT] Archivo descargado: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);

        if (fileSize < 1000) {
            throw new Error('El archivo descargado es demasiado pequeño o está corrupto');
        }

        const audioBuffer = fs.readFileSync(tempFile);
        const fileName = sanitizeFilename(title) + '.mp3';

        // Enviar según tamaño
        try {
            if (fileSize > LimitAud) {
                console.log('[MUSICYT] Enviando como documento (archivo > 700MB)');
                await conn.sendMessage(message.from, {
                    document: audioBuffer,
                    mimetype: 'audio/mpeg',
                    fileName: fileName
                }, { quoted: message._baileyMessage });
            } else {
                console.log('[MUSICYT] Enviando como audio');
                await conn.sendMessage(message.from, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    fileName: fileName,
                    ptt: false
                }, { quoted: message._baileyMessage });
            }
            
            console.log(`[MUSICYT] ✅ Audio enviado correctamente desde ${source}`);
            
        } catch (sendErr) {
            console.error('[MUSICYT] Error enviando audio:', sendErr.message);
            await message.reply('❌ Ocurrió un error al enviar el audio.');
        }

        // Limpiar archivo temporal
        if (fs.existsSync(tempFile)) {
            try { 
                fs.unlinkSync(tempFile); 
                console.log('[MUSICYT] Archivo temporal eliminado'); 
            } catch (unlinkErr) { 
                console.error('[MUSICYT] Error al eliminar archivo:', unlinkErr.message); 
            }
        }

    } catch (e) {
        console.error('[MUSICYT] Error general:', e?.message || e);
        await message.reply(
            `❌ No se pudo descargar el audio después de intentar con todas las fuentes disponibles.\n\n` +
            `💡 *Sugerencias:*\n` +
            `• Intenta con otro título o link\n` +
            `• Verifica que el link sea válido\n` +
            `• Espera unos minutos y vuelve a intentar\n\n` +
            `_${e.message}_`
        );
    }
};

handler.help = ['musicyt <link o título>', 'ytmusic <link o título>', 'spotify <link o título>', 'applemusic <link o título>'];
handler.tags = ['audio', 'youtube', 'musica', 'spotify', 'applemusic'];
handler.command = /^(musicyt|ytaudio|audioyt|yt|ytmusic|music|musica|música|spotify|applemusic|apple|play|audio)$/i;

module.exports = handler;