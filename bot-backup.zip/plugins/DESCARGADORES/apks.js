const axios = require('axios');
const fs = require('fs');
const path = require('path');

let handlerApk = async (message) => {
    let conn = global.conn;

    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);

        if (args.length === 0) {
            return await message.reply('📦 *Uso correcto:*\n/apk <nombre del APK>\n\nEjemplo: /apk Whatsapp');
        }

        const query = args.join(' ');
        const apiUrl = `https://delirius-apiofc.vercel.app/download/apk?query=${encodeURIComponent(query)}`;

        await message.reply(`🔍 *Buscando el APK "${query}"...*\nPor favor, espera unos segundos mientras obtenemos la información.`);

        const response = await axios.get(apiUrl);
        const data = response.data;

        if (!data.status || !data.data) {
            return await message.reply('❌ No se encontró ningún APK con ese nombre. Intenta con otro término.');
        }

        const app = data.data;
        const recipient = message.key.remoteJid;

        const maxSize = 200 * 1024 * 1024; // 200 MB
        const apkSize = parseInt(app.sizeByte);

        // 📱 Mostrar información del APK
        await conn.sendMessage(recipient, {
            image: { url: app.image },
            caption: `📱 *${app.name}*\n
👨‍💻 *Desarrollador:* ${app.developer}
📦 *Tamaño:* ${app.size}
⭐ *Valoración:* ${app.stats.rating.average.toFixed(2)} (${app.stats.rating.total} votos)
⬇️ *Descargas:* ${app.stats.downloads.toLocaleString()}
🏪 *Tienda:* ${app.store.name}

${apkSize > maxSize
    ? '⚠️ *El archivo es demasiado grande para enviarlo directamente (MAX 200 mb).*\n\nTe enviaré el enlace de descarga directa para que lo bajes manualmente.'
    : '⏳ *El archivo será descargado y enviado.* Esto puede tardar unos minutos si el APK es pesado, por favor espera...'}`
        });

        // ⚠️ Si es demasiado grande, enviar enlace y salir
        if (apkSize > maxSize) {
            return await conn.sendMessage(recipient, {
                text: `🔗 *Descarga directa:*\n${app.download}`
            });
        }

        // 📥 Descargar archivo temporalmente
        const tempFile = path.join(__dirname, `${app.id}.apk`);
        const writer = fs.createWriteStream(tempFile);

        const downloadRes = await axios({
            url: app.download,
            method: 'GET',
            responseType: 'stream'
        });

        downloadRes.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        // 📤 Enviar archivo
        await conn.sendMessage(recipient, {
            document: fs.readFileSync(tempFile),
            mimetype: 'application/vnd.android.package-archive',
            fileName: `${app.name}.apk`,
            caption: `✅ *${app.name}* enviado correctamente.\n\n👨‍💻 *Desarrollador:* ${app.developer}\n📏 *Tamaño:* ${app.size}`
        });

        fs.unlinkSync(tempFile); // 🧹 Limpiar archivo temporal

    } catch (error) {
        console.error('Error en el comando apk:', error);
        await message.reply('❌ Ocurrió un error al descargar o enviar el APK. Intenta nuevamente más tarde.');
    }
};

handlerApk.help = ['apk'];
handlerApk.tags = ['download'];
handlerApk.command = /^(apk)$/i;

module.exports.apk = handlerApk;
