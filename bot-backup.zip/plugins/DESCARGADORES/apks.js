const axios = require('axios')

// ===============================
// API 1 — Aptoide
// ===============================
async function buscarAptoide(query) {
    const res = await axios.get(
        `https://ws75.aptoide.com/api/7/apps/search/query=${encodeURIComponent(query)}&limit=25&store_name=aptoide-web`,
        { timeout: 15000 }
    )
    const list = res.data?.datalist?.list
    if (!list?.length) throw new Error('Aptoide: sin resultados')

    const q = query.toLowerCase()
    let app = list.find(a =>
        a.file?.path && (
            a.name?.toLowerCase().includes(q) ||
            a.package?.toLowerCase().includes(q.replace(/\s+/g, ''))
        )
    )
    if (!app) app = list.find(a =>
        a.file?.path &&
        !a.package?.startsWith('cm.aptoide') &&
        !a.package?.startsWith('com.aptoide')
    )
    if (!app) app = list.find(a => a.file?.path)
    if (!app?.file?.path) throw new Error('Aptoide: sin link de descarga')

    return {
        name:      app.name || 'Sin nombre',
        dev:       app.developer?.name || 'N/A',
        pkg:       app.package || 'N/A',
        version:   app.file?.vername || 'N/A',
        sizeByte:  app.file?.filesize || 0,
        icon:      app.icon || null,
        download:  app.file.path,
        rating:    app.stats?.prating?.avg || 0,
        downloads: app.stats?.downloads || 0
    }
}

// ===============================
// API 2 — Delirius
// ===============================
async function buscarDelirius(query) {
    const res = await axios.get(
        `https://delirius-apiofc.vercel.app/download/apk?query=${encodeURIComponent(query)}`,
        { timeout: 15000 }
    )
    const app = res.data?.data
    if (!res.data?.status || !app) throw new Error('Delirius: sin resultados')
    if (!app.download) throw new Error('Delirius: sin link de descarga')

    return {
        name:      app.name || 'Sin nombre',
        dev:       app.developer || 'N/A',
        pkg:       app.package || 'N/A',
        version:   app.version || 'N/A',
        sizeByte:  parseInt(app.sizeByte) || 0,
        icon:      app.image || null,
        download:  app.download,
        rating:    app.stats?.rating?.average || 0,
        downloads: app.stats?.downloads || 0
    }
}

// ===============================
// Elegir el mejor resultado
// ===============================
function elegirMejor(query, resultados) {
    const q = query.toLowerCase()

    // Puntuar cada resultado
    const puntuados = resultados.map(app => {
        let score = 0
        if (app.name?.toLowerCase().includes(q)) score += 10
        if (app.pkg?.toLowerCase().includes(q.replace(/\s+/g, ''))) score += 5
        if (app.downloads) score += Math.min(app.downloads / 1_000_000, 5) // hasta 5 puntos por descargas
        if (app.rating)    score += Math.min(app.rating, 5)                // hasta 5 puntos por rating
        if (app.sizeByte > 0) score += 1                                   // tiene tamaño real
        return { app, score }
    })

    puntuados.sort((a, b) => b.score - a.score)
    return puntuados[0].app
}

// ===============================
// HANDLER PRINCIPAL
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
    try {
        if (!text?.trim()) {
            return await message.reply(
                `📦 *Uso correcto:*\n${usedPrefix}${command} <nombre del APK>\n\nEjemplo: ${usedPrefix}${command} Minecraft`
            )
        }

        const query = text.trim()
        await message.reply(`🔍 *Buscando "${query}"...*`)

        // ── Lanzar ambas APIs en paralelo ──
        const resultados = await Promise.allSettled([
            buscarAptoide(query),
            buscarDelirius(query)
        ])

        const exitosos = resultados
            .filter(r => r.status === 'fulfilled')
            .map(r => r.value)

        if (!exitosos.length) {
            return await message.reply('❌ No se encontró ningún APK con ese nombre. Intenta con otro término.')
        }

        // ── Elegir el mejor resultado ──
        const app = exitosos.length === 1 ? exitosos[0] : elegirMejor(query, exitosos)

        const sizeMB    = (app.sizeByte / (1024 * 1024)).toFixed(2)
        const maxSize   = 200 * 1024 * 1024
        const demasiado = app.sizeByte > maxSize

        // ── Info con imagen ──
        const caption =
            `📱 *${app.name}*\n\n` +
            `👨‍💻 *Desarrollador:* ${app.dev}\n` +
            `📦 *Paquete:* ${app.pkg}\n` +
            `🔖 *Versión:* ${app.version}\n` +
            `📏 *Tamaño:* ${sizeMB} MB\n` +
            `⭐ *Valoración:* ${app.rating ? Number(app.rating).toFixed(2) : 'N/A'}\n` +
            `⬇️ *Descargas:* ${app.downloads ? Number(app.downloads).toLocaleString() : 'N/A'}\n\n` +
            (demasiado
                ? '⚠️ *Archivo demasiado grande (MAX 200 MB).*\nTe envío el enlace directo.'
                : '⏳ *Enviando APK...* Puede tardar unos segundos.')

        if (app.icon) {
            await conn.sendMessage(
                message.from,
                { image: { url: app.icon }, caption },
                { quoted: message._baileyMessage }
            )
        } else {
            await message.reply(caption)
        }

        // ── Si pesa más de 200MB → solo link ──
        if (demasiado) {
            return await conn.sendMessage(
                message.from,
                { text: `🔗 *Descarga directa:*\n${app.download}` },
                { quoted: message._baileyMessage }
            )
        }

        // ── Enviar APK ──
        await conn.sendMessage(
            message.from,
            {
                document: { url: app.download },
                mimetype: 'application/vnd.android.package-archive',
                fileName: `${app.name}.apk`,
                caption: `✅ *${app.name}* v${app.version} — ${sizeMB} MB`
            },
            { quoted: message._baileyMessage }
        )

    } catch (error) {
        console.error('[APK ERROR]', error?.message || error)
        await message.reply('❌ Error al buscar o enviar el APK. Intenta más tarde.')
    }
}

handler.help = ['apk <nombre de la app>']
handler.tags = ['descargas']
handler.command = /^(apk)$/i

module.exports = handler