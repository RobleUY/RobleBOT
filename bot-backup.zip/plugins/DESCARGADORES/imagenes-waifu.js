﻿const axios = require('axios');

const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];
const GOOGLE_CX = '635e6b14f7cf84f2c';

const WAIFU_TERMS = [
    'waifu girl hd',
    'waifu cute girl',
    'waifu picture hd'
];

const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': 'https://www.google.com/',
    'Connection': 'keep-alive'
};

async function buscarImagenesWaifu(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];

    if (keyIndex >= GOOGLE_API_KEYS.length) return [];

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=active`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            return response.data.items
                .filter(item => item.link && item.mime && item.mime.startsWith('image/'))
                .map(item => item.link);
        }
    } catch (error) {
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`⚠️ Clave de API agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarImagenesWaifu(termsArray, keyIndex + 1, retries - 1);
        }
        console.error('Error en la búsqueda de imágenes de waifu:', error.message);
    }

    return [];
}

async function descargarImagen(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: BROWSER_HEADERS
        });

        const contentType = response.headers['content-type'] || '';
        if (!contentType.startsWith('image/')) {
            console.warn(`⚠️ URL no devolvió imagen: ${contentType}`);
            return null;
        }

        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.warn(`⚠️ No se pudo descargar imagen (${error.response?.status || error.message}): ${url}`);
        return null;
    }
}

let handlerWaifu = async (message, { conn }) => {
    try {
        const imageUrls = await buscarImagenesWaifu(WAIFU_TERMS);

        if (!imageUrls.length) {
            return message.reply('❌ No se encontraron imágenes de waifu. Intenta de nuevo más tarde.');
        }

        let imageBuffer = null;
        for (const url of imageUrls) {
            imageBuffer = await descargarImagen(url);
            if (imageBuffer) break;
        }

        if (!imageBuffer) {
            return message.reply('❌ No se pudo descargar ninguna imagen. Intenta de nuevo más tarde.');
        }

        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: '☺️ Waifu'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /waifu:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
};

handlerWaifu.command = /^waifu/i;
handlerWaifu.help = ['waifu'];
handlerWaifu.tags = ['waifu', 'anime'];

module.exports = { waifu: handlerWaifu };