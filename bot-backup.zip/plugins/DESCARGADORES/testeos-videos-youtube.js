const axios = require('axios')
const yts = require('yt-search')

// ===============================
// IMPORTACIÓN DE @hiudyy/ytdl (CJS / ESM compatibility)
// ===============================
let ytmp4Func = null
try {
  const ytdlModule = require('@hiudyy/ytdl')
  ytmp4Func = ytdlModule.ytmp4 || ytdlModule.default?.ytmp4
} catch (err) {
  console.warn('[YTDLTEST] @hiudyy/ytdl no instalado o no disponible:', err.message)
}

const LimitVid = 450 * 1024 * 1024 // 450MB

async function getFileSize(url) {
  try {
    const res = await axios.head(url, { timeout: 10000 })
    return parseInt(res.headers['content-length'] || 0)
  } catch {
    return 0
  }
}

async function searchYouTube(query) {
  const res = await yts.search({ query, hl: 'es', gl: 'ES' })
  return res.videos || []
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  if (!ytmp4Func) {
    return message.reply(
      '⚠️ *La librería `@hiudyy/ytdl` no está instalada.*\n' +
      'Por favor, ejecuta `npm install @hiudyy/ytdl` en la terminal para poder probar este comando.'
    )
  }

  if (!text) {
    return message.reply(
      `❌ *Uso incorrecto del comando*\n\n` +
      `Debes enviar un enlace de YouTube o el nombre de un video.\n\n` +
      `*Ejemplos:*\n` +
      `• ${usedPrefix + command} https://youtu.be/c5gJRzCi0f0\n` +
      `• ${usedPrefix + command} Bad Bunny Amorfoda`
    )
  }

  const isLink = text.includes('youtube.com') || text.includes('youtu.be')
  let targetUrl = ''
  let videoTitle = ''

  try {
    if (isLink) {
      targetUrl = text.trim()
    } else {
      await message.reply('🔎 Buscando video en YouTube...')
      const searchResults = await searchYouTube(text)
      if (!searchResults || searchResults.length === 0) {
        return message.reply(`❌ No se encontraron resultados en YouTube para: *${text}*`)
      }
      targetUrl = searchResults[0].url
      videoTitle = searchResults[0].title
    }

    await message.reply('⏳ Procesando y descargando video con `@hiudyy/ytdl`...')

    const data = await ytmp4Func(targetUrl)

    const out = typeof data === 'string'
      ? data
      : data?.url || data?.result || data?.downloadUrl || data?.dl || data

    if (!out) {
      throw new Error('No se obtuvo un enlace de descarga o stream válido de @hiudyy/ytdl.')
    }

    const isUrl = typeof out === 'string'
    const size = isUrl ? await getFileSize(out) : 0

    console.log(
      `[YTDLTEST] 🔗 Obtenido: ${isUrl ? out.slice(0, 100) + '...' : '[Buffer/Stream]'} | size ≈ ${(size / (1024 * 1024)).toFixed(2)} MB`
    )

    const caption = `🎬 *Video Descargado (@hiudyy/ytdl)*\n` +
      `📌 *Título:* ${videoTitle || 'Video de YouTube'}\n` +
      `🔗 *Enlace:* ${targetUrl}`

    const messageOptions = {
      fileName: `${videoTitle || 'video'}.mp4`,
      caption,
      mimetype: 'video/mp4'
    }

    if (isUrl) {
      if (size > LimitVid) {
        await sock.sendMessage(
          message.from,
          { document: { url: out }, ...messageOptions },
          { quoted: message._baileyMessage }
        )
      } else {
        await sock.sendMessage(
          message.from,
          { video: { url: out }, ...messageOptions },
          { quoted: message._baileyMessage }
        )
      }
    } else {
      await sock.sendMessage(
        message.from,
        { video: out, ...messageOptions },
        { quoted: message._baileyMessage }
      )
    }

    console.log('[YTDLTEST] ✅ Video enviado correctamente')

  } catch (e) {
    console.error('[YTDLTEST ERROR]', e)
    await message.reply(
      `❌ *Error al procesar el video con @hiudyy/ytdl*\n\n` +
      `*Detalle:* ${e?.message || e}`
    )
  }
}

// ===============================
// CONFIGURACIÓN DEL COMANDO
// ===============================
handler.help = ['ytdltest <url o búsqueda>']
handler.tags = ['descargas', 'test']
handler.command = /^(ytdltest|ytdltestv|ytdltestmp4)$/i

module.exports = handler
