const axios = require('axios')
const yts = require('yt-search')

// ===============================
// IMPORTACIÓN DE @hiudyy/ytdl (CJS / ESM compatibility)
// ===============================
let ytmp4Func = null
let ytmp3Func = null
try {
  const ytdlModule = require('@hiudyy/ytdl')
  ytmp4Func = ytdlModule.ytmp4 || ytdlModule.default?.ytmp4
  ytmp3Func = ytdlModule.ytmp3 || ytdlModule.default?.ytmp3
} catch (err) {
  console.warn('[YTDLTEST] Módulo no instalado o no disponible:', err.message)
}

const LimitVid = 450 * 1024 * 1024 // 450MB
const LimitAud = 700 * 1024 * 1024 // 700MB

function sanitizeFilename(name = 'archivo') {
  return String(name).replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 150)
}

async function getFileSize(url) {
  try {
    const res = await axios.head(url, { timeout: 10000 })
    return parseInt(res.headers['content-length'] || 0)
  } catch {
    return 0
  }
}

async function searchYouTube(query) {
  try {
    const res = await yts(query)
    return res?.videos || []
  } catch (err) {
    console.error('[YTDLTEST] Error en yt-search:', err.message)
    return []
  }
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  // Detectar si el usuario ejecutó la versión de audio (.ytdltest2) o de video (.ytdltest)
  const isAudio = /2|a|mp3/i.test(command)
  const dlFunc = isAudio ? ytmp3Func : ytmp4Func

  if (!dlFunc) {
    return message.reply(
      `⚠️ *El servicio de descarga de ${isAudio ? 'audio' : 'video'} no está listo en este momento.*`
    )
  }

  if (!text) {
    return message.reply(
      `❌ *Uso incorrecto del comando*\n\n` +
      `Debes enviar un enlace de YouTube o el nombre de un video/canción.\n\n` +
      `*Ejemplos:*\n` +
      `• Video: ${usedPrefix}ytdltest https://youtu.be/c5gJRzCi0f0\n` +
      `• Audio: ${usedPrefix}ytdltest2 Bad Bunny Amorfoda`
    )
  }

  const isLink = text.includes('youtube.com') || text.includes('youtu.be')
  let targetUrl = isLink ? text.trim() : ''
  let videoTitle = ''
  let videoDuration = ''

  try {
    await message.reply(
      isLink
        ? `⏳ Buscando e iniciando descarga de ${isAudio ? 'audio' : 'video'}...`
        : `🔎 Buscando en YouTube...`
    )

    // Buscar información (funciona para enlaces y búsquedas por texto)
    const searchResults = await searchYouTube(text.trim())

    if (searchResults && searchResults.length > 0) {
      const info = searchResults[0]
      if (!isLink) {
        targetUrl = info.url
      }
      videoTitle = info.title || ''
      videoDuration = info.timestamp || ''
    }

    if (!targetUrl) {
      return message.reply(`❌ No se encontraron resultados para: *${text}*`)
    }

    const data = await dlFunc(targetUrl)

    const out = typeof data === 'string'
      ? data
      : data?.url || data?.result || data?.downloadUrl || data?.dl || data

    if (!out) {
      throw new Error(`No se obtuvo un enlace de descarga o stream válido de ${isAudio ? 'audio' : 'video'}.`)
    }

    const fetchedTitle = videoTitle || data?.title || data?.result?.title || (isAudio ? 'Audio de YouTube' : 'Video de YouTube')
    const safeTitle = sanitizeFilename(fetchedTitle)
    const isUrl = typeof out === 'string'
    const size = isUrl ? await getFileSize(out) : 0

    console.log(
      `[YTDLTEST] 🔗 (${isAudio ? 'Audio' : 'Video'}) Obtenido: ${isUrl ? out.slice(0, 100) + '...' : '[Buffer/Stream]'} | size ≈ ${(size / (1024 * 1024)).toFixed(2)} MB`
    )

    let caption = `🎬 *${fetchedTitle}*`
    if (videoDuration) {
      caption += `\n⏱️ *Duración:* ${videoDuration}`
    }

    const limit = isAudio ? LimitAud : LimitVid

    if (isAudio) {
      // ENVIAR AUDIO
      const audioOptions = {
        fileName: `${safeTitle}.mp3`,
        mimetype: 'audio/mpeg',
        ptt: false
      }

      if (isUrl) {
        if (size > limit) {
          await sock.sendMessage(
            message.from,
            { document: { url: out }, ...audioOptions },
            { quoted: message._baileyMessage }
          )
        } else {
          await sock.sendMessage(
            message.from,
            { audio: { url: out }, ...audioOptions },
            { quoted: message._baileyMessage }
          )
        }
      } else {
        await sock.sendMessage(
          message.from,
          { audio: out, ...audioOptions },
          { quoted: message._baileyMessage }
        )
      }
    } else {
      // ENVIAR VIDEO
      const videoOptions = {
        fileName: `${safeTitle}.mp4`,
        caption,
        mimetype: 'video/mp4'
      }

      if (isUrl) {
        if (size > limit) {
          await sock.sendMessage(
            message.from,
            { document: { url: out }, ...videoOptions },
            { quoted: message._baileyMessage }
          )
        } else {
          await sock.sendMessage(
            message.from,
            { video: { url: out }, ...videoOptions },
            { quoted: message._baileyMessage }
          )
        }
      } else {
        await sock.sendMessage(
          message.from,
          { video: out, ...videoOptions },
          { quoted: message._baileyMessage }
        )
      }
    }

    console.log(`[YTDLTEST] ✅ ${isAudio ? 'Audio' : 'Video'} enviado correctamente`)

  } catch (e) {
    console.error('[YTDLTEST ERROR]', e)
    await message.reply(
      `❌ *No se pudo descargar el ${isAudio ? 'audio' : 'video'}*\n\n` +
      `_Intenta nuevamente más tarde o verifica que la fuente sea válida._`
    )
  }
}

// ===============================
// CONFIGURACIÓN DEL COMANDO
// ===============================
handler.help = ['ytdltest <url o búsqueda>', 'ytdltest2 <url o búsqueda>']
handler.tags = ['descargas', 'test']
handler.command = /^(ytdltest|ytdltestv|ytdltestmp4|ytdltest2|ytdltesta|ytdltestmp3)$/i

module.exports = handler
