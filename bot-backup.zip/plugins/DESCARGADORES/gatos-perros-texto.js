const axios = require('axios');
const sharp = require('sharp');

// 🧠 Cache para evitar saturar las APIs
const animalCache = new Map();

/**
 * 🔍 Obtener imagen desde la API de Delirius
 */
async function obtenerImagenAnimal(tipo, texto) {
    const cacheKey = `${tipo}_${texto}`;
    
    if (animalCache.has(cacheKey)) {
        return animalCache.get(cacheKey);
    }

    try {
        let url;
        
        // Para gatos: usar API con texto específico o carácter invisible
        if (tipo === 'cat') {
            url = `https://api.delirius.store/random/${tipo}?text=${encodeURIComponent(texto || '­')}`;
        } 
        // Para perros: usar API sin texto
        else if (tipo === 'dog') {
            url = `https://api.delirius.store/random/${tipo}`;
        }
        
        console.log(`🔍 Probando URL: ${url}`);
        
        const response = await axios.get(url, { 
            responseType: 'arraybuffer',
            timeout: 10000
        });
        
        console.log(`📊 Status de respuesta para ${tipo}: ${response.status}`);
        
        if (response.status === 200 && response.data && response.data.length > 0) {
            animalCache.set(cacheKey, url);
            return url;
        }
        
        console.log(`⚠️ Respuesta vacía o inválida para ${tipo}`);
        return null;
    } catch (error) {
        console.error(`❌ Error API ${tipo}:`, error.message);
        
        // Fallback para perros
        if (tipo === 'dog') {
            console.log(`🔄 Usando API alternativa para perros...`);
            try {
                const fallbackUrl = 'https://dog.ceo/api/breeds/image/random';
                const fallbackResponse = await axios.get(fallbackUrl);
                
                if (fallbackResponse.data && fallbackResponse.data.message) {
                    return fallbackResponse.data.message;
                }
            } catch (fallbackError) {
                console.error(`❌ Error en API alternativa:`, fallbackError.message);
            }
        }
        
        return null;
    }
}

/**
 * 🎨 Agregar texto a imagen usando Sharp (como en stickers-texto.js)
 */
async function agregarTextoAImagen(imageUrl, texto) {
    try {
        console.log('🎨 Iniciando proceso de agregar texto con Sharp...');
        
        // Descargar la imagen primero
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data);
        
        // Obtener información de la imagen
        const { width, height } = await sharp(imageBuffer).metadata();
        console.log(`📐 Dimensiones de imagen: ${width}x${height}`);
        
        // Calcular tamaño de fuente dinámico
        const fontSize = Math.max(20, Math.min(width / 15, 60));
        console.log(`📝 Tamaño de fuente calculado: ${fontSize}`);
        
        // Crear SVG con el texto
        const textColor = '#ffffff';
        const strokeColor = '#000000';
        const strokeWidth = 3;
        
        // Posición del texto (centrado horizontalmente, parte inferior)
        const textY = height - fontSize - 20; // 20px desde abajo
        
        // Escape de caracteres especiales XML
        const escapedText = texto
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
        
        const svgOverlay = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <style>
                .text-main {
                    fill: ${textColor};
                    font-size: ${fontSize}px;
                    font-family: "Arial Black", "Arial", sans-serif;
                    font-weight: 900;
                    text-anchor: middle;
                    dominant-baseline: middle;
                    stroke: ${strokeColor};
                    stroke-width: ${strokeWidth}px;
                    paint-order: stroke fill;
                }
            </style>
            <text x="50%" y="${textY}" class="text-main">${escapedText}</text>
        </svg>`;
        
        console.log(`📍 Posición del texto: x=50%, y=${textY}`);
        
        // Combinar imagen original con el texto usando Sharp
        const finalImage = await sharp(imageBuffer)
            .composite([{
                input: Buffer.from(svgOverlay),
                top: 0,
                left: 0
            }])
            .jpeg({ quality: 90 })
            .toBuffer();
        
        console.log('✅ Texto agregado correctamente con Sharp');
        console.log(`📦 Buffer generado: ${finalImage.length} bytes`);
        
        return finalImage;
        
    } catch (error) {
        console.error('❌ Error detallado al agregar texto a imagen:', error);
        
        // Método de respaldo más simple
        try {
            console.log('🔄 Intentando método alternativo con Sharp...');
            
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data);
            
            // Método más simple: solo agregar texto sin muchos cálculos
            const { width, height } = await sharp(imageBuffer).metadata();
            
            const simpleSvg = `
            <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
                <text x="50%" y="${height - 40}" 
                      fill="white" 
                      stroke="black" 
                      stroke-width="2" 
                      font-size="32" 
                      font-family="Arial" 
                      font-weight="bold" 
                      text-anchor="middle">${texto}</text>
            </svg>`;
            
            const result = await sharp(imageBuffer)
                .composite([{
                    input: Buffer.from(simpleSvg),
                    top: 0,
                    left: 0
                }])
                .jpeg({ quality: 90 })
                .toBuffer();
            
            console.log('✅ Método alternativo exitoso');
            return result;
            
        } catch (fallbackError) {
            console.error('❌ Error en método alternativo:', fallbackError);
            return null;
        }
    }
}

/**
 * 🎯 Handler Unificado para Gatos y Perros
 */
let handlerAnimales = async (message, { conn, text, usedPrefix, command }) => {
    try {
        // 1️⃣ Averiguar exactamente qué pidió el usuario (gato o perro) y si lleva el '2'
        const requiereTexto = command.endsWith('2');
        
        // Saber si es gato limpiando el '2' del comando si es que lo tiene
        const comandoLimpio = command.replace('2', '').toLowerCase();
        const esGato = ['cat', 'cats', 'gato', 'gatos'].includes(comandoLimpio);
        
        const tipo = esGato ? 'cat' : 'dog';
        const titulo = esGato ? '🐱 *Gatito*' : '🐶 *Perrito*';

        console.log(`🎯 Comando ejecutado: ${command}, Tipo: ${tipo}, Requiere texto: ${requiereTexto}`);

        // 2️⃣ Validar si el comando pide texto y el usuario no mandó nada
        if (requiereTexto && (!text || !text.trim())) {
            return await message.reply(
                `❌ *Uso correcto:*\n> ${usedPrefix}${command} <texto>\n\n*Ejemplo:* ${usedPrefix}${command} Firulais 🐶`
            );
        }

        // 3️⃣ Asignar el texto final
        const textoFinal = requiereTexto ? text.trim() : null;

        console.log(`📝 Texto final para ${tipo}: "${textoFinal}"`);

        if (requiereTexto) {
            await message.reply(`🔎 *Generando imagen con texto...*\n> ${textoFinal}`);
        } else {
            await message.reply(`🔎 *Buscando una imagen aleatoria...*`);
        }

        // 4️⃣ Obtener la imagen base (sin texto para perros, con carácter invisible para gatos)
        const imageUrl = await obtenerImagenAnimal(tipo, '­');

        if (!imageUrl) {
            return await message.reply(`❌ Hubo un problema al obtener la imagen de la API. Intenta de nuevo en unos momentos.`);
        }

        let finalImage;
        let caption = titulo;

        // 5️⃣ Si requiere texto (tanto perro como gato), agregar texto con Sharp
        if (requiereTexto && textoFinal) {
            console.log(`🎨 Agregando texto con Sharp para ${tipo}...`);
            const imageBuffer = await agregarTextoAImagen(imageUrl, textoFinal);
            
            if (imageBuffer) {
                finalImage = imageBuffer;
                caption = `${titulo}\n\n📝 *Texto:* ${textoFinal}`;
            } else {
                // Si falla Sharp, enviar imagen sin texto
                finalImage = { url: imageUrl };
                caption = `${titulo}\n\n⚠️ *Error al agregar texto, imagen sin texto*`;
            }
        }
        // 6️⃣ Imagen sin texto (comandos normales)
        else {
            finalImage = { url: imageUrl };
        }

        // 8️⃣ Enviar el mensaje con la foto al chat de WhatsApp
        await conn.sendMessage(
            message.from,
            {
                image: finalImage,
                caption: caption
            },
            { quoted: message._baileyMessage }
        );

        console.log(`✅ Imagen de ${tipo} enviada correctamente`);

    } catch (error) {
        console.error('💥 Error en comando Animales:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando. Intenta de nuevo.');
    }
};

// ⚙️ Configuración de comandos y alias (Soporta versiones normales y con "2")
handlerAnimales.command = /^(cat|cats|gato|gatos|dog|dogs|perro|perros)2?$/i;
handlerAnimales.help = [
    'gato', 'gato2 <texto>', 
    'perro', 'perro2 <texto>', 
    'cat', 'cat2 <texto>', 
    'dog', 'dog2 <texto>'
];
handlerAnimales.tags = ['imagenes', 'divertido'];

module.exports = handlerAnimales;