const axios = require('axios');
const sharp = require('sharp');

// 🧠 Cache para evitar saturar las APIs
const animalCache = new Map();

/**
 * 🔍 Obtener imagen desde la API de Delirius
 */
async function obtenerImagenAnimal(tipo, texto) {
    const cacheKey = `${tipo}_${texto}`;

    if (animalCache.has(cacheKey)) {
        return animalCache.get(cacheKey);
    }

    try {
        let url;

        // Para gatos: usar API con texto específico o carácter invisible
        if (tipo === 'cat') {
            url = `https://api.delirius.store/random/${tipo}?text=${encodeURIComponent(texto || '­')}`;
        }
        // Para perros: usar API sin texto
        else if (tipo === 'dog') {
            url = `https://api.delirius.store/random/${tipo}`;
        }

        console.log(`🔍 Probando URL: ${url}`);

        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 10000
        });

        console.log(`📊 Status de respuesta para ${tipo}: ${response.status}`);

        if (response.status === 200 && response.data && response.data.length > 0) {
            animalCache.set(cacheKey, url);
            return url;
        }

        console.log(`⚠️ Respuesta vacía o inválida para ${tipo}`);
        return null;
    } catch (error) {
        console.error(`❌ Error API ${tipo}:`, error.message);

        // Fallback para perros
        if (tipo === 'dog') {
            console.log(`🔄 Usando API alternativa para perros...`);
            try {
                const fallbackUrl = 'https://dog.ceo/api/breeds/image/random';
                const fallbackResponse = await axios.get(fallbackUrl);

                if (fallbackResponse.data && fallbackResponse.data.message) {
                    return fallbackResponse.data.message;
                }
            } catch (fallbackError) {
                console.error(`❌ Error en API alternativa:`, fallbackError.message);
            }
        }

        return null;
    }
}

/**
 * 📏 Divide un texto en líneas según el ancho disponible y un tamaño de fuente dado.
 * Usa un factor de ancho por carácter ajustado para fuentes bold tipo "Arial Black".
 */
function dividirTextoEnLineas(texto, maxWidth, fontSize) {
    const palabras = texto.split(' ');
    const lineas = [];
    let lineaActual = '';

    // Factor empírico para Arial Black / bold en mayúsculas y mixto
    const charWidth = fontSize * 0.58;
    const maxCharsPerLine = Math.max(1, Math.floor(maxWidth / charWidth));

    for (const palabra of palabras) {
        const lineaConPalabra = lineaActual ? `${lineaActual} ${palabra}` : palabra;

        if (lineaConPalabra.length > maxCharsPerLine) {
            if (lineaActual) {
                lineas.push(lineaActual);
                lineaActual = palabra;
            } else {
                // Una sola palabra ya es más larga que el ancho disponible: se corta
                if (palabra.length > maxCharsPerLine) {
                    let palabraCortada = palabra;
                    while (palabraCortada.length > maxCharsPerLine) {
                        lineas.push(palabraCortada.substring(0, maxCharsPerLine));
                        palabraCortada = palabraCortada.substring(maxCharsPerLine);
                    }
                    lineaActual = palabraCortada;
                } else {
                    lineaActual = palabra;
                }
            }
        } else {
            lineaActual = lineaConPalabra;
        }
    }

    if (lineaActual) {
        lineas.push(lineaActual);
    }

    return lineas;
}

/**
 * 📐 Calcula el tamaño de fuente óptimo y las líneas resultantes para que el texto
 * SIEMPRE quepa dentro de la imagen (ni se sale, ni queda desproporcionadamente chico).
 *
 * Estrategia:
 *  1. Arranca con un fontSize proporcional al ANCHO de la imagen (no a un tope fijo bajo).
 *  2. Parte el texto en líneas con ese tamaño.
 *  3. Si el bloque total de texto (todas las líneas) ocupa más de cierto % del ALTO
 *     de la imagen, reduce el fontSize y vuelve a partir el texto. Repite hasta que
 *     quepa o hasta llegar a un tamaño mínimo legible.
 */
function calcularAjusteDeTexto(texto, width, height) {
    const maxTextWidthRatio = 0.92;   // % del ancho que puede ocupar cada línea
    const maxBlockHeightRatio = 0.38; // % del alto que puede ocupar el bloque de texto completo
    const minFontSize = 20;           // nunca bajar de esto, aunque no quepa "perfecto"
    const lineHeightFactor = 1.22;

    // Tamaño inicial: proporcional al ancho, sin techo artificial bajo.
    // Para imágenes grandes (1080p+) esto da fuentes bastante más grandes que el "48" anterior.
    let fontSize = Math.round(width / 13);
    fontSize = Math.max(minFontSize, Math.min(fontSize, 160)); // techo alto, solo por seguridad

    const maxTextWidth = width * maxTextWidthRatio;
    let lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
    let lineHeight = fontSize * lineHeightFactor;
    let totalHeight = lineas.length * lineHeight;

    // Reducimos el tamaño hasta que el bloque completo entre en el alto permitido
    while (totalHeight > height * maxBlockHeightRatio && fontSize > minFontSize) {
        fontSize -= 2;
        lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
        lineHeight = fontSize * lineHeightFactor;
        totalHeight = lineas.length * lineHeight;
    }

    return { fontSize, lineas, lineHeight, totalHeight };
}

/**
 * 🎨 Agregar texto a imagen usando Sharp con múltiples líneas, tamaño adaptable
 */
async function agregarTextoAImagen(imageUrl, texto) {
    try {
        console.log('🎨 Iniciando proceso de agregar texto con Sharp...');

        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data);

        const { width, height } = await sharp(imageBuffer).metadata();
        console.log(`📐 Dimensiones de imagen: ${width}x${height}`);

        // Cálculo unificado de tamaño de fuente + líneas, adaptado a esta imagen
        const { fontSize, lineas, lineHeight, totalHeight } = calcularAjusteDeTexto(texto, width, height);
        console.log(`📝 Tamaño de fuente calculado: ${fontSize}px, ${lineas.length} línea(s):`, lineas);

        const textColor = '#ffffff';
        const strokeColor = '#000000';
        const strokeWidth = Math.max(2, fontSize / 14);

        // Margen inferior proporcional a la imagen (nunca menor a 15px)
        const bottomMargin = Math.max(15, height * 0.03);

        // Posición inicial del bloque de texto, pegado abajo pero sin salirse por arriba
        let startY = height - totalHeight - bottomMargin + (fontSize / 2);
        const topLimit = height * 0.05 + (fontSize / 2);
        if (startY < topLimit) startY = topLimit; // seguridad extra si el texto es muy largo

        const escapeXml = (str) => str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');

        const textElements = lineas.map((linea, index) => {
            const y = startY + (index * lineHeight);
            const escapedText = escapeXml(linea);
            return `<text x="50%" y="${y}" class="text-main">${escapedText}</text>`;
        }).join('\n            ');

        const svgOverlay = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <style>
                .text-main {
                    fill: ${textColor};
                    font-size: ${fontSize}px;
                    font-family: "Arial Black", "Arial", sans-serif;
                    font-weight: 900;
                    text-anchor: middle;
                    dominant-baseline: middle;
                    stroke: ${strokeColor};
                    stroke-width: ${strokeWidth}px;
                    paint-order: stroke fill;
                }
            </style>
            ${textElements}
        </svg>`;

        console.log(`📍 Posición del texto: desde y=${startY.toFixed(0)} hasta y=${(startY + totalHeight).toFixed(0)} (imagen alto=${height})`);

        const finalImage = await sharp(imageBuffer)
            .composite([{
                input: Buffer.from(svgOverlay),
                top: 0,
                left: 0
            }])
            .jpeg({ quality: 90 })
            .toBuffer();

        console.log('✅ Texto multilínea agregado correctamente con Sharp');
        console.log(`📦 Buffer generado: ${finalImage.length} bytes`);

        return finalImage;

    } catch (error) {
        console.error('❌ Error detallado al agregar texto a imagen:', error);

        // Método de respaldo: mismo algoritmo adaptable, pero por si algo falló arriba
        // (ej. metadata parcial), reintentamos una vez más de forma aislada.
        try {
            console.log('🔄 Intentando método alternativo con Sharp...');

            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data);
            const { width, height } = await sharp(imageBuffer).metadata();

            const { fontSize, lineas, lineHeight, totalHeight } = calcularAjusteDeTexto(texto, width, height);
            const bottomMargin = Math.max(15, height * 0.03);
            let startY = height - totalHeight - bottomMargin + (fontSize / 2);
            const topLimit = height * 0.05 + (fontSize / 2);
            if (startY < topLimit) startY = topLimit;

            const strokeWidth = Math.max(2, fontSize / 14);

            const escapeXml = (str) => str
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&apos;');

            const textElements = lineas.map((linea, index) => {
                const y = startY + (index * lineHeight);
                return `<text x="50%" y="${y}" class="text-main">${escapeXml(linea)}</text>`;
            }).join('\n                ');

            const simpleSvg = `
            <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
                <style>
                    .text-main {
                        fill: #ffffff;
                        stroke: #000000;
                        stroke-width: ${strokeWidth}px;
                        font-size: ${fontSize}px;
                        font-family: "Arial Black", "Arial", sans-serif;
                        font-weight: 900;
                        text-anchor: middle;
                        dominant-baseline: middle;
                        paint-order: stroke fill;
                    }
                </style>
                ${textElements}
            </svg>`;

            const result = await sharp(imageBuffer)
                .composite([{
                    input: Buffer.from(simpleSvg),
                    top: 0,
                    left: 0
                }])
                .jpeg({ quality: 90 })
                .toBuffer();

            console.log('✅ Método alternativo exitoso');
            return result;

        } catch (fallbackError) {
            console.error('❌ Error en método alternativo:', fallbackError);
            return null;
        }
    }
}

/**
 * 🎯 Handler Unificado para Gatos y Perros
 */
let handlerAnimales = async (message, { conn, text, usedPrefix, command }) => {
    try {
        // 1️⃣ Averiguar exactamente qué pidió el usuario (gato o perro) y si lleva el '2'
        const requiereTexto = command.endsWith('2');

        // Saber si es gato limpiando el '2' del comando si es que lo tiene
        const comandoLimpio = command.replace('2', '').toLowerCase();
        const esGato = ['cat', 'cats', 'gato', 'gatos'].includes(comandoLimpio);

        const tipo = esGato ? 'cat' : 'dog';
        const titulo = esGato ? '🐱 *Gatito*' : '🐶 *Perrito*';

        console.log(`🎯 Comando ejecutado: ${command}, Tipo: ${tipo}, Requiere texto: ${requiereTexto}`);

        // 2️⃣ Validar si el comando pide texto y el usuario no mandó nada
        if (requiereTexto && (!text || !text.trim())) {
            return await message.reply(
                `❌ *Uso correcto:*\n> ${usedPrefix}${command} <texto>\n\n*Ejemplo:* ${usedPrefix}${command} Firulais 🐶`
            );
        }

        // 3️⃣ Asignar el texto final
        const textoFinal = requiereTexto ? text.trim() : null;

        console.log(`📝 Texto final para ${tipo}: "${textoFinal}"`);

        if (requiereTexto) {
            await message.reply(`🔎 *Generando imagen con texto...*\n> ${textoFinal}`);
        } else {
            await message.reply(`🔎 *Buscando una imagen aleatoria...*`);
        }

        // 4️⃣ Obtener la imagen base (sin texto para perros, con carácter invisible para gatos)
        const imageUrl = await obtenerImagenAnimal(tipo, '­');

        if (!imageUrl) {
            return await message.reply(`❌ Hubo un problema al obtener la imagen de la API. Intenta de nuevo en unos momentos.`);
        }

        let finalImage;
        let caption = titulo;

        // 5️⃣ Si requiere texto (tanto perro como gato), agregar texto con Sharp
        if (requiereTexto && textoFinal) {
            console.log(`🎨 Agregando texto con Sharp para ${tipo}...`);
            const imageBuffer = await agregarTextoAImagen(imageUrl, textoFinal);

            if (imageBuffer) {
                finalImage = imageBuffer;
                caption = `${titulo}\n\n📝 *Texto:* ${textoFinal}`;
            } else {
                // Si falla Sharp, enviar imagen sin texto
                finalImage = { url: imageUrl };
                caption = `${titulo}\n\n⚠️ *Error al agregar texto, imagen sin texto*`;
            }
        }
        // 6️⃣ Imagen sin texto (comandos normales)
        else {
            finalImage = { url: imageUrl };
        }

        // 8️⃣ Enviar el mensaje con la foto al chat de WhatsApp
        await conn.sendMessage(
            message.from,
            {
                image: finalImage,
                caption: caption
            },
            { quoted: message._baileyMessage }
        );

        console.log(`✅ Imagen de ${tipo} enviada correctamente`);

    } catch (error) {
        console.error('💥 Error en comando Animales:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando. Intenta de nuevo.');
    }
};

// ⚙️ Configuración de comandos y alias (Soporta versiones normales y con "2")
handlerAnimales.command = /^(cat|cats|gato|gatos|dog|dogs|perro|perros)2?$/i;
handlerAnimales.help = [
    'gato', 'gato2 <texto>',
    'perro', 'perro2 <texto>',
    'cat', 'cat2 <texto>',
    'dog', 'dog2 <texto>'
];
handlerAnimales.tags = ['imagenes', 'divertido'];

module.exports = handlerAnimales;