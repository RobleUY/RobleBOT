const axios = require('axios');

// 🧠 Cache para evitar saturar las APIs
const animalCache = new Map();

/**
 * 🔍 Obtener imagen desde la API de Delirius
 */
async function obtenerImagenAnimal(tipo, texto) {
    const cacheKey = `${tipo}_${texto}`;
    
    if (animalCache.has(cacheKey)) {
        return animalCache.get(cacheKey);
    }

    try {
        const url = `https://api.delirius.store/random/${tipo}?text=${encodeURIComponent(texto)}`;
        
        // Validamos que la URL responda bien
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        
        if (response.status === 200) {
            animalCache.set(cacheKey, url);
            return url;
        }
        return null;
    } catch (error) {
        console.error(`❌ Error API ${tipo}:`, error.message);
        return null;
    }
}

/**
 * 🎯 Handler Unificado para Gatos y Perros
 */
let handlerAnimales = async (message, { conn, text, usedPrefix, command }) => {
    try {
        // 1️⃣ Averiguar exactamente qué pidió el usuario (gato o perro) y si lleva el '2'
        const requiereTexto = command.endsWith('2');
        
        // Saber si es gato limpiando el '2' del comando si es que lo tiene
        const comandoLimpio = command.replace('2', '').toLowerCase();
        const esGato = ['cat', 'cats', 'gato', 'gatos'].includes(comandoLimpio);
        
        const tipo = esGato ? 'cat' : 'dog';
        const titulo = esGato ? '🐱 *Gatito*' : '🐶 *Perrito*';

        // 2️⃣ Validar si el comando pide texto y el usuario no mandó nada
        if (requiereTexto && (!text || !text.trim())) {
            return await message.reply(
                `❌ *Uso correcto:*\n> ${usedPrefix}${command} <texto>\n\n*Ejemplo:* ${usedPrefix}${command} Firulais 🐶`
            );
        }

        // 3️⃣ Asignar el texto final: Si no requiere texto, aplicamos tu truco del carácter invisible
        const textoFinal = requiereTexto ? text.trim() : '­';

        if (requiereTexto) {
            await message.reply(`🔎 *Generando imagen con texto...*\n> ${textoFinal}`);
        } else {
            await message.reply(`🔎 *Buscando una imagen aleatoria...*`);
        }

        // 4️⃣ Llamar a la API con los parámetros exactos y limpios
        const imageUrl = await obtenerImagenAnimal(tipo, textoFinal);

        if (!imageUrl) {
            return await message.reply(`❌ Hubo un problema al obtener la imagen de la API.`);
        }

        // 5️⃣ Enviar el mensaje con la foto al chat de WhatsApp
        await conn.sendMessage(
            message.from,
            {
                image: { url: imageUrl },
                caption: requiereTexto ? `${titulo}\n\n📝 *Texto:* ${textoFinal}` : titulo
            },
            { quoted: message._baileyMessage }
        );

    } catch (error) {
        console.error('💥 Error en comando Animales:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando.');
    }
};

// ⚙️ Configuración de comandos y alias (Soporta versiones normales y con "2")
handlerAnimales.command = /^(cat|cats|gato|gatos|dog|dogs|perro|perros)2?$/i;
handlerAnimales.help = [
    'gato', 'gato2 <texto>', 
    'perro', 'perro2 <texto>', 
    'cat', 'cat2 <texto>', 
    'dog', 'dog2 <texto>'
];
handlerAnimales.tags = ['imagenes', 'divertido'];

module.exports = handlerAnimales;