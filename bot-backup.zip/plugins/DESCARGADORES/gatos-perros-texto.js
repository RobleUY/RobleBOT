const axios = require('axios');
const sharp = require('sharp');

// ============================================================
// 🐾 CONFIG (RobleAPI - olivia.hidencloud.com)
// ============================================================
const ROBLE_BASE_URL = 'http://olivia.hidencloud.com:24733/robleapi/random';

// Lista de animales soportados por la API (según /robleapi/random/list)
// api    -> segmento que se usa en la URL (http://.../random/{api})
// emoji  -> emoji para el caption
// nombre -> nombre bonito en español para el caption
// aliases-> palabras que el usuario puede escribir para invocar el comando
const ANIMALS = [
    { api: 'cats',       emoji: '🐱', nombre: 'Gato',      aliases: ['cat', 'cats', 'gato', 'gatos'] },
    { api: 'dogs',       emoji: '🐶', nombre: 'Perro',     aliases: ['dog', 'dogs', 'perro', 'perros'] },
    { api: 'monkeys',    emoji: '🐵', nombre: 'Mono',      aliases: ['monkey', 'monkeys', 'mono', 'monos'] },
    { api: 'foxes',      emoji: '🦊', nombre: 'Zorro',     aliases: ['fox', 'foxes', 'zorro', 'zorros'] },
    { api: 'wolves',     emoji: '🐺', nombre: 'Lobo',      aliases: ['wolf', 'wolves', 'lobo', 'lobos'] },
    { api: 'bears',      emoji: '🐻', nombre: 'Oso',       aliases: ['bear', 'bears', 'oso', 'osos'] },
    { api: 'lions',      emoji: '🦁', nombre: 'León',      aliases: ['lion', 'lions', 'leon', 'leones'] },
    { api: 'tigers',     emoji: '🐯', nombre: 'Tigre',     aliases: ['tiger', 'tigers', 'tigre', 'tigres'] },
    { api: 'elephants',  emoji: '🐘', nombre: 'Elefante',  aliases: ['elephant', 'elephants', 'elefante', 'elefantes'] },
    { api: 'pandas',     emoji: '🐼', nombre: 'Panda',     aliases: ['panda', 'pandas'] },
    { api: 'penguins',   emoji: '🐧', nombre: 'Pingüino',  aliases: ['penguin', 'penguins', 'pinguino', 'pinguinos'] },
    { api: 'owls',       emoji: '🦉', nombre: 'Búho',      aliases: ['owl', 'owls', 'buho', 'buhos'] },
    { api: 'dolphins',   emoji: '🐬', nombre: 'Delfín',    aliases: ['dolphin', 'dolphins', 'delfin', 'delfines'] },
    { api: 'horses',     emoji: '🐴', nombre: 'Caballo',   aliases: ['horse', 'horses', 'caballo', 'caballos'] },
    { api: 'rabbits',    emoji: '🐰', nombre: 'Conejo',    aliases: ['rabbit', 'rabbits', 'conejo', 'conejos'] },
    { api: 'birds',      emoji: '🐦', nombre: 'Pájaro',    aliases: ['bird', 'birds', 'pajaro', 'pajaros', 'ave', 'aves'] },
    { api: 'fish',       emoji: '🐟', nombre: 'Pez',       aliases: ['fish', 'pez', 'peces'] },
    { api: 'sharks',     emoji: '🦈', nombre: 'Tiburón',   aliases: ['shark', 'sharks', 'tiburon', 'tiburones'] },
    { api: 'crocodiles', emoji: '🐊', nombre: 'Cocodrilo', aliases: ['crocodile', 'crocodiles', 'cocodrilo', 'cocodrilos'] },
    { api: 'snakes',     emoji: '🐍', nombre: 'Serpiente', aliases: ['snake', 'snakes', 'serpiente', 'serpientes'] },
    { api: 'giraffes',   emoji: '🦒', nombre: 'Jirafa',    aliases: ['giraffe', 'giraffes', 'jirafa', 'jirafas'] },
    { api: 'zebras',     emoji: '🦓', nombre: 'Cebra',     aliases: ['zebra', 'zebras', 'cebra', 'cebras'] },
    { api: 'deer',       emoji: '🦌', nombre: 'Ciervo',    aliases: ['deer', 'deers', 'ciervo', 'ciervos'] },
    { api: 'frogs',      emoji: '🐸', nombre: 'Rana',      aliases: ['frog', 'frogs', 'rana', 'ranas'] },
    { api: 'turtles',    emoji: '🐢', nombre: 'Tortuga',   aliases: ['turtle', 'turtles', 'tortuga', 'tortugas'] },
];

// Comandos especiales para listar los animales disponibles
const LISTA_ALIASES = ['animales', 'animals'];

// Mapa alias -> animal (para resolución rápida en el handler)
const ALIAS_TO_ANIMAL = new Map();
for (const animal of ANIMALS) {
    for (const alias of animal.aliases) {
        ALIAS_TO_ANIMAL.set(alias.toLowerCase(), animal);
    }
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function descargarImagenValidada(url, timeout = 10000) {
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
            'Accept': 'image/*,*/*',
            // Evita que un proxy/CDN intermedio (o el propio servidor) devuelva
            // siempre la misma respuesta cacheada para esta URL.
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache'
        }
    });

    if (res.status !== 200 || !res.data || res.data.length === 0) {
        throw new Error(`Respuesta vacía o status ${res.status}`);
    }

    const buffer = Buffer.from(res.data);

    try {
        await sharp(buffer).metadata();
    } catch (err) {
        const contentType = res.headers['content-type'] || 'desconocido';
        const preview = buffer.slice(0, 120).toString('utf8').replace(/\s+/g, ' ').trim();
        console.error(`🔬 Respuesta no decodificable de ${url}\n   content-type: ${contentType}\n   primeros bytes: ${preview}`);
        throw new Error(`La respuesta no es una imagen válida (${err.message})`);
    }

    return buffer;
}

/**
 * 🐾 Descarga una imagen aleatoria de un animal desde la RobleAPI.
 * Reintenta un par de veces por si el servidor falla puntualmente.
 */
async function obtenerImagenAnimalBuffer(apiName, intentos = 3) {
    for (let intento = 1; intento <= intentos; intento++) {
        // Query param único (timestamp + random) en cada intento para evitar
        // que el servidor/CDN devuelva siempre la misma imagen cacheada.
        const cacheBuster = `${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
        const url = `${ROBLE_BASE_URL}/${apiName}?_=${cacheBuster}`;

        try {
            console.log(`🔍 [Intento ${intento}/${intentos}] Pidiendo "${apiName}" a RobleAPI...`);
            const buffer = await descargarImagenValidada(url);
            console.log(`🚀 Imagen de "${apiName}" obtenida de RobleAPI (${buffer.length} bytes)`);
            return buffer;
        } catch (error) {
            console.warn(`⚠️ Falló intento ${intento} para "${apiName}": ${error.message}`);
            if (intento < intentos) await sleep(1000);
        }
    }

    console.error(`❌ No se pudo obtener imagen de "${apiName}" tras ${intentos} intentos (RobleAPI)`);
    return null;
}

/**
 * 📏 Divide un texto en líneas según el ancho disponible y un tamaño de fuente dado.
 * Usa un factor de ancho por carácter ajustado para fuentes bold tipo "Arial Black".
 */
function dividirTextoEnLineas(texto, maxWidth, fontSize) {
    const palabras = texto.split(' ');
    const lineas = [];
    let lineaActual = '';

    const charWidth = fontSize * 0.58;
    const maxCharsPerLine = Math.max(1, Math.floor(maxWidth / charWidth));

    for (const palabra of palabras) {
        const lineaConPalabra = lineaActual ? `${lineaActual} ${palabra}` : palabra;

        if (lineaConPalabra.length > maxCharsPerLine) {
            if (lineaActual) {
                lineas.push(lineaActual);
                lineaActual = palabra;
            } else {
                if (palabra.length > maxCharsPerLine) {
                    let palabraCortada = palabra;
                    while (palabraCortada.length > maxCharsPerLine) {
                        lineas.push(palabraCortada.substring(0, maxCharsPerLine));
                        palabraCortada = palabraCortada.substring(maxCharsPerLine);
                    }
                    lineaActual = palabraCortada;
                } else {
                    lineaActual = palabra;
                }
            }
        } else {
            lineaActual = lineaConPalabra;
        }
    }

    if (lineaActual) {
        lineas.push(lineaActual);
    }

    return lineas;
}

/**
 * 📐 Calcula el tamaño de fuente óptimo y las líneas resultantes para que el texto
 * SIEMPRE quepa dentro de la imagen (ni se sale, ni queda desproporcionadamente chico).
 */
function calcularAjusteDeTexto(texto, width, height) {
    const maxTextWidthRatio = 0.92;
    const maxBlockHeightRatio = 0.38;
    const minFontSize = 20;
    const lineHeightFactor = 1.22;

    let fontSize = Math.round(width / 13);
    fontSize = Math.max(minFontSize, Math.min(fontSize, 160));

    const maxTextWidth = width * maxTextWidthRatio;
    let lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
    let lineHeight = fontSize * lineHeightFactor;
    let totalHeight = lineas.length * lineHeight;

    while (totalHeight > height * maxBlockHeightRatio && fontSize > minFontSize) {
        fontSize -= 2;
        lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
        lineHeight = fontSize * lineHeightFactor;
        totalHeight = lineas.length * lineHeight;
    }

    return { fontSize, lineas, lineHeight, totalHeight };
}

function escapeXml(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

function construirSvgOverlay(texto, width, height) {
    const { fontSize, lineas, lineHeight, totalHeight } = calcularAjusteDeTexto(texto, width, height);

    const textColor = '#ffffff';
    const strokeColor = '#000000';
    const strokeWidth = Math.max(2, fontSize / 14);
    const bottomMargin = Math.max(15, height * 0.03);

    let startY = height - totalHeight - bottomMargin + (fontSize / 2);
    const topLimit = height * 0.05 + (fontSize / 2);
    if (startY < topLimit) startY = topLimit;

    const textElements = lineas.map((linea, index) => {
        const y = startY + (index * lineHeight);
        return `<text x="50%" y="${y}" class="text-main">${escapeXml(linea)}</text>`;
    }).join('\n            ');

    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <style>
                .text-main {
                    fill: ${textColor};
                    font-size: ${fontSize}px;
                    font-family: "Arial Black", "Arial", sans-serif;
                    font-weight: 900;
                    text-anchor: middle;
                    dominant-baseline: middle;
                    stroke: ${strokeColor};
                    stroke-width: ${strokeWidth}px;
                    paint-order: stroke fill;
                }
            </style>
            ${textElements}
        </svg>`;

    console.log(`📝 fontSize=${fontSize}px, ${lineas.length} línea(s):`, lineas);
    console.log(`📍 Texto desde y=${startY.toFixed(0)} hasta y=${(startY + totalHeight).toFixed(0)} (alto imagen=${height})`);

    return svg;
}

async function agregarTextoAImagen(imageBuffer, texto) {
    try {
        console.log('🎨 Iniciando proceso de agregar texto con Sharp...');

        const { width, height, format } = await sharp(imageBuffer).metadata();
        console.log(`📐 Imagen ${format}, ${width}x${height}`);

        const svgOverlay = construirSvgOverlay(texto, width, height);

        const finalImage = await sharp(imageBuffer)
            .composite([{ input: Buffer.from(svgOverlay), top: 0, left: 0 }])
            .jpeg({ quality: 90 })
            .toBuffer();

        console.log(`✅ Texto agregado correctamente (${finalImage.length} bytes)`);
        return finalImage;

    } catch (error) {
        console.error('❌ Error al agregar texto a imagen:', error);
        return null;
    }
}

/**
 * 📋 Genera el texto con la lista de animales disponibles.
 */
function construirListaAnimales(usedPrefix) {
    const lineas = ANIMALS.map(a => `${a.emoji} *${a.nombre}* → _${a.aliases[0]}_ / _${a.aliases[a.aliases.length - 1]}_`);
    return (
        `🐾 *Animales disponibles* (${ANIMALS.length})\n\n` +
        lineas.join('\n') +
        `\n\n📌 *Uso:*\n> ${usedPrefix}<animal>          → imagen aleatoria\n> ${usedPrefix}<animal>2 <texto>  → imagen con texto\n\n` +
        `*Ejemplo:* ${usedPrefix}gato2 Firulais 🐱`
    );
}

/**
 * 🎯 Handler Unificado para todos los animales soportados por RobleAPI
 */
let handlerAnimales = async (message, { conn, text, usedPrefix, command }) => {
    try {
        const comandoOriginal = command.toLowerCase();

        // Comando de listado: animales / animals
        if (LISTA_ALIASES.includes(comandoOriginal)) {
            return await message.reply(construirListaAnimales(usedPrefix));
        }

        const requiereTexto = comandoOriginal.endsWith('2');
        const comandoLimpio = requiereTexto ? comandoOriginal.slice(0, -1) : comandoOriginal;

        const animal = ALIAS_TO_ANIMAL.get(comandoLimpio);
        if (!animal) {
            // No debería pasar si el regex está bien armado, pero por las dudas
            return await message.reply('❌ Animal no reconocido. Usa el comando *animales* para ver la lista completa.');
        }

        console.log(`🎯 Comando: ${command}, Animal: ${animal.api}, Requiere texto: ${requiereTexto}`);

        if (requiereTexto && (!text || !text.trim())) {
            return await message.reply(
                `❌ *Uso correcto:*\n> ${usedPrefix}${command} <texto>\n\n*Ejemplo:* ${usedPrefix}${command} Firulais ${animal.emoji}`
            );
        }

        const textoFinal = requiereTexto ? text.trim() : null;

        if (requiereTexto) {
            await message.reply(`🔎 *Generando imagen con texto...*\n> ${textoFinal}`);
        } else {
            await message.reply('🔎 *Buscando una imagen aleatoria...*');
        }

        // 1️⃣ Descargar la imagen desde RobleAPI (ya validada como imagen real)
        const imageBuffer = await obtenerImagenAnimalBuffer(animal.api);

        if (!imageBuffer) {
            return await message.reply('❌ Hubo un problema al obtener la imagen de la API. Intenta de nuevo en unos momentos.');
        }

        let finalImageBuffer = imageBuffer;
        let caption = `${animal.emoji} *${animal.nombre}*`;

        // 2️⃣ Si requiere texto, se lo agregamos nosotros con sharp
        if (requiereTexto && textoFinal) {
            const conTexto = await agregarTextoAImagen(imageBuffer, textoFinal);

            if (conTexto) {
                finalImageBuffer = conTexto;
                caption = `${animal.emoji} *${animal.nombre}*\n\n📝 *Texto:* ${textoFinal}`;
            } else {
                caption = `${animal.emoji} *${animal.nombre}*\n\n⚠️ *Error al agregar texto, imagen sin texto*`;
                // finalImageBuffer se queda con la imagen original sin texto
            }
        }

        await conn.sendMessage(
            message.from,
            { image: finalImageBuffer, caption },
            { quoted: message._baileyMessage }
        );

        console.log(`✅ Imagen de "${animal.api}" enviada correctamente`);

    } catch (error) {
        console.error('💥 Error en comando Animales:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando. Intenta de nuevo.');
    }
};

// Construye el regex del comando dinámicamente a partir de todos los aliases + '2' opcional,
// más los comandos de listado (animales/animals, sin '2' porque no aplica).
const todosLosAliases = ANIMALS.flatMap(a => a.aliases);
const patronAnimales = `(?:${todosLosAliases.join('|')})2?`;
const patronLista = `(?:${LISTA_ALIASES.join('|')})`;
handlerAnimales.command = new RegExp(`^(?:${patronAnimales}|${patronLista})$`, 'i');

handlerAnimales.help = [
    ...ANIMALS.flatMap(a => [a.aliases[0], `${a.aliases[0]}2 <texto>`]),
    'animales',
    'animals'
];
handlerAnimales.tags = ['imagenes', 'divertido'];

module.exports = handlerAnimales;