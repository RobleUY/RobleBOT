const axios = require('axios');
const sharp = require('sharp');

// 🧠 Cache liviano: recordamos qué fuente ganó últimamente para cada tipo,
// así evitamos re-correr la carrera completa en cada request.
const ultimaFuenteGanadora = new Map(); // tipo -> 'delirius' | 'secundaria'

async function descargarImagenValidada(url, timeout = 8000) {
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout,
        headers: {
            // Varias de estas APIs públicas bloquean o degradan la respuesta
            // si detectan el User-Agent por defecto de axios/node.
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
            'Accept': 'image/*,*/*'
        }
    });

    if (res.status !== 200 || !res.data || res.data.length === 0) {
        throw new Error(`Respuesta vacía o status ${res.status}`);
    }

    const buffer = Buffer.from(res.data);

    try {
        await sharp(buffer).metadata();
    } catch (err) {
        // Vista previa de qué vino realmente (para diagnosticar sin adivinar:
        // JSON, HTML de error, etc.)
        const contentType = res.headers['content-type'] || 'desconocido';
        const preview = buffer.slice(0, 120).toString('utf8').replace(/\s+/g, ' ').trim();
        console.error(`🔬 Respuesta no decodificable de ${url}\n   content-type: ${contentType}\n   primeros bytes: ${preview}`);
        throw new Error(`La respuesta no es una imagen válida (${err.message})`);
    }

    return buffer;
}


async function obtenerImagenAnimalBuffer(tipo) {
    if (tipo === 'cat') {
        console.log('🔍 Pidiendo gato a TheCatAPI...');
        try {
            const res = await axios.get('https://api.thecatapi.com/v1/images/search', { timeout: 8000 });
            const imgUrl = res.data && res.data[0] && res.data[0].url;

            if (!imgUrl) {
                throw new Error('TheCatAPI no devolvió una URL de imagen');
            }

            const buffer = await descargarImagenValidada(imgUrl);
            console.log(`🚀 Gato obtenido de TheCatAPI (${buffer.length} bytes)`);
            return buffer;

        } catch (error) {
            console.error(`❌ Falló TheCatAPI: ${error.message}`);
            return null;
        }
    }

    if (tipo === 'dog') {
        const promesas = [];
        const urlDelirius = 'https://api.delirius.store/random/dog';

        console.log('🔍 Compitiendo APIs para perros (Delirius vs Dog.ceo)...');

        promesas.push(
            descargarImagenValidada(urlDelirius)
                .then(buffer => ({ buffer, fuente: 'delirius' }))
                .catch(err => { throw new Error(`Delirius (dog): ${err.message}`); })
        );

        // Dog.ceo es en dos pasos: primero pide un JSON con la URL de la imagen,
        // después baja esa imagen puntual.
        promesas.push(
            axios.get('https://dog.ceo/api/breeds/image/random', { timeout: 8000 })
                .then(res => {
                    const imgUrl = res.data && res.data.message;
                    if (!imgUrl) throw new Error('Dog.ceo no devolvió una URL de imagen');
                    return descargarImagenValidada(imgUrl);
                })
                .then(buffer => ({ buffer, fuente: 'secundaria' }))
                .catch(err => { throw new Error(`Dog.ceo: ${err.message}`); })
        );

        try {
            const ganador = await Promise.any(promesas);
            console.log(`🚀 Fuente ganadora para dog: ${ganador.fuente} (${ganador.buffer.length} bytes)`);
            return ganador.buffer;
        } catch (error) {
            const detalles = error.errors ? error.errors.map(e => e.message).join(' | ') : error.message;
            console.error(`❌ Todas las APIs fallaron para dog: ${detalles}`);
            return null;
        }
    }

    throw new Error(`Tipo de animal desconocido: ${tipo}`);
}

/**
 * 📏 Divide un texto en líneas según el ancho disponible y un tamaño de fuente dado.
 * Usa un factor de ancho por carácter ajustado para fuentes bold tipo "Arial Black".
 */
function dividirTextoEnLineas(texto, maxWidth, fontSize) {
    const palabras = texto.split(' ');
    const lineas = [];
    let lineaActual = '';

    const charWidth = fontSize * 0.58;
    const maxCharsPerLine = Math.max(1, Math.floor(maxWidth / charWidth));

    for (const palabra of palabras) {
        const lineaConPalabra = lineaActual ? `${lineaActual} ${palabra}` : palabra;

        if (lineaConPalabra.length > maxCharsPerLine) {
            if (lineaActual) {
                lineas.push(lineaActual);
                lineaActual = palabra;
            } else {
                if (palabra.length > maxCharsPerLine) {
                    let palabraCortada = palabra;
                    while (palabraCortada.length > maxCharsPerLine) {
                        lineas.push(palabraCortada.substring(0, maxCharsPerLine));
                        palabraCortada = palabraCortada.substring(maxCharsPerLine);
                    }
                    lineaActual = palabraCortada;
                } else {
                    lineaActual = palabra;
                }
            }
        } else {
            lineaActual = lineaConPalabra;
        }
    }

    if (lineaActual) {
        lineas.push(lineaActual);
    }

    return lineas;
}

/**
 * 📐 Calcula el tamaño de fuente óptimo y las líneas resultantes para que el texto
 * SIEMPRE quepa dentro de la imagen (ni se sale, ni queda desproporcionadamente chico).
 */
function calcularAjusteDeTexto(texto, width, height) {
    const maxTextWidthRatio = 0.92;
    const maxBlockHeightRatio = 0.38;
    const minFontSize = 20;
    const lineHeightFactor = 1.22;

    let fontSize = Math.round(width / 13);
    fontSize = Math.max(minFontSize, Math.min(fontSize, 160));

    const maxTextWidth = width * maxTextWidthRatio;
    let lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
    let lineHeight = fontSize * lineHeightFactor;
    let totalHeight = lineas.length * lineHeight;

    while (totalHeight > height * maxBlockHeightRatio && fontSize > minFontSize) {
        fontSize -= 2;
        lineas = dividirTextoEnLineas(texto, maxTextWidth, fontSize);
        lineHeight = fontSize * lineHeightFactor;
        totalHeight = lineas.length * lineHeight;
    }

    return { fontSize, lineas, lineHeight, totalHeight };
}

function escapeXml(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

function construirSvgOverlay(texto, width, height) {
    const { fontSize, lineas, lineHeight, totalHeight } = calcularAjusteDeTexto(texto, width, height);

    const textColor = '#ffffff';
    const strokeColor = '#000000';
    const strokeWidth = Math.max(2, fontSize / 14);
    const bottomMargin = Math.max(15, height * 0.03);

    let startY = height - totalHeight - bottomMargin + (fontSize / 2);
    const topLimit = height * 0.05 + (fontSize / 2);
    if (startY < topLimit) startY = topLimit;

    const textElements = lineas.map((linea, index) => {
        const y = startY + (index * lineHeight);
        return `<text x="50%" y="${y}" class="text-main">${escapeXml(linea)}</text>`;
    }).join('\n            ');

    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <style>
                .text-main {
                    fill: ${textColor};
                    font-size: ${fontSize}px;
                    font-family: "Arial Black", "Arial", sans-serif;
                    font-weight: 900;
                    text-anchor: middle;
                    dominant-baseline: middle;
                    stroke: ${strokeColor};
                    stroke-width: ${strokeWidth}px;
                    paint-order: stroke fill;
                }
            </style>
            ${textElements}
        </svg>`;

    console.log(`📝 fontSize=${fontSize}px, ${lineas.length} línea(s):`, lineas);
    console.log(`📍 Texto desde y=${startY.toFixed(0)} hasta y=${(startY + totalHeight).toFixed(0)} (alto imagen=${height})`);

    return svg;
}


async function agregarTextoAImagen(imageBuffer, texto) {
    try {
        console.log('🎨 Iniciando proceso de agregar texto con Sharp...');

        const { width, height, format } = await sharp(imageBuffer).metadata();
        console.log(`📐 Imagen ${format}, ${width}x${height}`);

        const svgOverlay = construirSvgOverlay(texto, width, height);

        const finalImage = await sharp(imageBuffer)
            .composite([{ input: Buffer.from(svgOverlay), top: 0, left: 0 }])
            .jpeg({ quality: 90 })
            .toBuffer();

        console.log(`✅ Texto agregado correctamente (${finalImage.length} bytes)`);
        return finalImage;

    } catch (error) {
        console.error('❌ Error al agregar texto a imagen:', error);
        return null;
    }
}

/**
 * 🎯 Handler Unificado para Gatos y Perros
 */
let handlerAnimales = async (message, { conn, text, usedPrefix, command }) => {
    try {
        const requiereTexto = command.endsWith('2');
        const comandoLimpio = command.replace('2', '').toLowerCase();
        const esGato = ['cat', 'cats', 'gato', 'gatos'].includes(comandoLimpio);

        const tipo = esGato ? 'cat' : 'dog';
        const titulo = esGato ? '🐱 *Gatito*' : '🐶 *Perrito*';

        console.log(`🎯 Comando: ${command}, Tipo: ${tipo}, Requiere texto: ${requiereTexto}`);

        if (requiereTexto && (!text || !text.trim())) {
            return await message.reply(
                `❌ *Uso correcto:*\n> ${usedPrefix}${command} <texto>\n\n*Ejemplo:* ${usedPrefix}${command} Firulais 🐶`
            );
        }

        const textoFinal = requiereTexto ? text.trim() : null;

        if (requiereTexto) {
            await message.reply(`🔎 *Generando imagen con texto...*\n> ${textoFinal}`);
        } else {
            await message.reply('🔎 *Buscando una imagen aleatoria...*');
        }

        // 1️⃣ Descargar la imagen (ya validada como imagen real, no JSON/HTML)
        const imageBuffer = await obtenerImagenAnimalBuffer(tipo);

        if (!imageBuffer) {
            return await message.reply('❌ Hubo un problema al obtener la imagen de la API. Intenta de nuevo en unos momentos.');
        }

        let finalImageBuffer = imageBuffer;
        let caption = titulo;

        // 2️⃣ Si requiere texto, se lo agregamos nosotros con sharp
        if (requiereTexto && textoFinal) {
            const conTexto = await agregarTextoAImagen(imageBuffer, textoFinal);

            if (conTexto) {
                finalImageBuffer = conTexto;
                caption = `${titulo}\n\n📝 *Texto:* ${textoFinal}`;
            } else {
                caption = `${titulo}\n\n⚠️ *Error al agregar texto, imagen sin texto*`;
                // finalImageBuffer se queda con la imagen original sin texto
            }
        }


        await conn.sendMessage(
            message.from,
            { image: finalImageBuffer, caption },
            { quoted: message._baileyMessage }
        );

        console.log(`✅ Imagen de ${tipo} enviada correctamente`);

    } catch (error) {
        console.error('💥 Error en comando Animales:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando. Intenta de nuevo.');
    }
};

handlerAnimales.command = /^(cat|cats|gato|gatos|dog|dogs|perro|perros)2?$/i;
handlerAnimales.help = [
    'gato', 'gato2 <texto>',
    'perro', 'perro2 <texto>',
    'cat', 'cat2 <texto>',
    'dog', 'dog2 <texto>'
];
handlerAnimales.tags = ['imagenes', 'divertido'];

module.exports = handlerAnimales;