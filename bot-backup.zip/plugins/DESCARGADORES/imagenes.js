const axios = require('axios');

// ============================================================
// GOOGLE
// ============================================================
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];
const GOOGLE_CX = '635e6b14f7cf84f2c';

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Referer': 'https://www.google.com/',
    'Sec-Fetch-Dest': 'image',
    'Sec-Fetch-Mode': 'no-cors',
    'Sec-Fetch-Site': 'cross-site',
};

// ============================================================
// PINTEREST
// ============================================================
const PINTEREST_API = 'https://robleuy.vercel.app/robleapi/buscador/pinterest';

// ============================================================
// CACHÉ — guarda listas completas para poder rotar en repetidos
// googleCache: text -> string[] (lista de URLs)
// pinterestCache: text -> string[] (lista de URLs)
// lastUsed: text -> { url, source } (último enviado, para repetir)
// ============================================================
const googleCache    = new Map(); // text -> url[]
const pinterestCache = new Map(); // text -> url[]
const lastUsed       = new Map(); // text -> { url, source }

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Saca una URL aleatoria distinta a la última usada si es posible
function elegirAleatoria(lista, ultimaUrl) {
    if (lista.length === 1) return lista[0];
    const filtrada = lista.filter(u => u !== ultimaUrl);
    return filtrada[Math.floor(Math.random() * filtrada.length)];
}

// ============================================================
// BUSCAR EN GOOGLE
// ============================================================
async function buscarGoogle(text, keyIndex = 0) {
    if (keyIndex >= GOOGLE_API_KEYS.length) return null;

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(text)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5`;

    try {
        const response = await axios.get(url);
        const items = response.data.items || [];
        const urls = items
            .map(i => i.link)
            .filter(link => link && /\.(jpg|jpeg|png|gif|webp|bmp)(\?.*)?$/i.test(link));
        return urls.length > 0 ? urls : null;
    } catch (error) {
        const status = error.response?.status;
        const errStatus = error.response?.data?.error?.status;
        if (status === 429 || errStatus === 'RESOURCE_EXHAUSTED') {
            console.warn(`[imagen] Clave agotada (...${key.slice(-6)}), rotando...`);
            await sleep(2000);
            return buscarGoogle(text, keyIndex + 1);
        }
        console.error(`[imagen] Error Google API: ${status || error.message}`);
        return null;
    }
}

// ============================================================
// BUSCAR EN PINTEREST
// ============================================================
async function buscarPinterest(query) {
    try {
        const response = await axios.get(`${PINTEREST_API}?q=${encodeURIComponent(query)}`);
        const data = response.data;
        if (!data.ok || !Array.isArray(data.images) || data.images.length === 0) return null;
        return data.images.map(img => img.large || img.small).filter(Boolean);
    } catch (error) {
        console.error('[imagen] Error Pinterest API:', error?.message || error);
        return null;
    }
}

// ============================================================
// DESCARGAR IMAGEN CON RETRY
// ============================================================
async function descargarImagen(imageUrl, intento = 1) {
    try {
        const res = await axios.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        return Buffer.from(res.data, 'binary');
    } catch (error) {
        const status = error.response?.status;
        if (intento < 3 && status !== 404 && status !== 410) {
            await sleep(1500);
            return descargarImagen(imageUrl, intento + 1);
        }
        console.error(`[imagen] Error descarga (${status || error.message}): ${imageUrl}`);
        return null;
    }
}

// ============================================================
// LÓGICA PRINCIPAL: Google → Pinterest como fallback
// Devuelve { url, source } donde source es 'google' o 'pinterest'
// ============================================================
async function obtenerImagen(text) {
    const ultima = lastUsed.get(text);

    // --- Intentar Google ---
    let listaGoogle = googleCache.get(text);
    if (!listaGoogle) {
        listaGoogle = await buscarGoogle(text);
        if (listaGoogle) googleCache.set(text, listaGoogle);
    }

    if (listaGoogle) {
        const url = elegirAleatoria(listaGoogle, ultima?.url);
        return { url, source: 'google' };
    }

    // --- Fallback: Pinterest ---
    let listaPinterest = pinterestCache.get(text);
    if (!listaPinterest) {
        listaPinterest = await buscarPinterest(text);
        if (listaPinterest) pinterestCache.set(text, listaPinterest);
    }

    if (listaPinterest) {
        const url = elegirAleatoria(listaPinterest, ultima?.url);
        return { url, source: 'pinterest' };
    }

    return null;
}

// ============================================================
// COMANDO NORMAL: .imagen / .img
// ============================================================
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('❌ Proporciona un término de búsqueda. Ejemplo: .imagen árboles');

        await message.reply(`🔍 Buscando imágenes sobre *${text}*...`);

        const resultado = await obtenerImagen(text);
        if (!resultado) return await message.reply('❌ No se encontraron imágenes. Intenta con otro término.');

        const imageBuffer = await descargarImagen(resultado.url);
        if (!imageBuffer) return await message.reply('❌ No se pudo descargar la imagen. Intenta de nuevo.');

        // Guardar como último usado
        lastUsed.set(text, resultado);

        const esPinterest = resultado.source === 'pinterest';
        const caption = `🤖 *RobleBOT*\n\n📝 *Solicitud:* ${text}${esPinterest ? '\n\n⚠️ La API de imágenes falló, se usó Pinterest como alternativa.' : ''}`;

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[imagen] Error inesperado:', error.message);
        return await message.reply('❌ Ocurrió un error al procesar tu solicitud.');
    }
};

handler.help = ['imagen <texto>', 'img <texto>'];
handler.tags = ['imagenes', 'busqueda'];
handler.command = /^(imagen|img)$/i;

module.exports = handler;