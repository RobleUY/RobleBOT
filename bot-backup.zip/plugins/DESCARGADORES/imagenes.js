const axios = require('axios');

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Referer': 'https://www.google.com/',
    'Sec-Fetch-Dest': 'image',
    'Sec-Fetch-Mode': 'no-cors',
    'Sec-Fetch-Site': 'cross-site',
};

// ============================================================
// FUENTES DE BÚSQUEDA — todas devuelven string[] de URLs o null
// ============================================================

// Pixabay via Delirius
async function buscarPixabay(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pixabay?query=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.data;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.map(i => i.image).filter(Boolean);
    } catch (e) {
        return null;
    }
}

// Bing via Delirius
async function buscarBing(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/bingimage?query=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.data;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.map(i => i.direct || i.thumbnail).filter(Boolean);
    } catch (e) {
        return null;
    }
}

// Pinterest v1 via Delirius
async function buscarPinterestV1(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pinterest?text=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.results;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.filter(Boolean);
    } catch (e) {
        return null;
    }
}

// Pinterest v2 via Delirius
async function buscarPinterestV2(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pinterestv2?text=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.data;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.map(i => i.image).filter(Boolean);
    } catch (e) {
        return null;
    }
}

// Pinterest viejo (robleuy.vercel.app)
async function buscarPinterestLegacy(query) {
    try {
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`, { timeout: 10000 });
        const data = res.data;
        if (!data.ok || !Array.isArray(data.images) || data.images.length === 0) return null;
        return data.images.map(img => img.large || img.small).filter(Boolean);
    } catch (e) {
        return null;
    }
}

// ============================================================
// DESCARGAR IMAGEN como buffer
// ============================================================
async function descargarImagen(url) {
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        const buf = Buffer.from(res.data, 'binary');
        if (buf.length < 5000) return null; // descartar buffers vacíos/inválidos
        return buf;
    } catch (e) {
        return null;
    }
}

// ============================================================
// CARRERA: lanza todas las fuentes a la vez, la primera en
// devolver un buffer válido gana. Las demás se ignoran.
// ============================================================
async function buscarEnCarrera(query) {
    // Cada promesa: busca URLs → elige una aleatoria → descarga → resuelve buffer o null
    const fuente = async (buscarFn) => {
        try {
            const urls = await buscarFn(query);
            if (!urls || urls.length === 0) return null;
            // Elegir URL aleatoria de la lista
            const url = urls[Math.floor(Math.random() * urls.length)];
            const buffer = await descargarImagen(url);
            return buffer || null;
        } catch (e) {
            return null;
        }
    };

    const promesas = [
        fuente(buscarPixabay),
        fuente(buscarBing),
        fuente(buscarPinterestV1),
        fuente(buscarPinterestV2),
        fuente(buscarPinterestLegacy),
    ];

    return new Promise((resolve) => {
        let resolved = false;
        let pendientes = promesas.length;

        for (const p of promesas) {
            p.then(result => {
                if (resolved) return;
                if (result) {
                    resolved = true;
                    resolve(result);
                } else {
                    pendientes--;
                    if (pendientes === 0) resolve(null);
                }
            }).catch(() => {
                if (resolved) return;
                pendientes--;
                if (pendientes === 0) resolve(null);
            });
        }
    });
}

// ============================================================
// COMANDO: .imagen / .img
// ============================================================
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('❌ Proporciona un término de búsqueda. Ejemplo: .imagen árboles');

        await message.reply(`🔍 Buscando imágenes sobre *${text}*...`);

        const imageBuffer = await buscarEnCarrera(text);
        if (!imageBuffer) return await message.reply('❌ No se encontraron imágenes. Intenta con otro término.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `🤖 *RobleBOT*\n\n📝 *Solicitud:* ${text}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[imagen] Error inesperado:', error.message);
        return await message.reply('❌ Ocurrió un error al procesar tu solicitud.');
    }
};

handler.help = ['imagen <texto>', 'img <texto>'];
handler.tags = ['imagenes', 'busqueda'];
handler.command = /^(imagen|img)$/i;

module.exports = handler;
