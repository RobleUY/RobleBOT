const axios = require('axios');

// Array de claves API
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];
const GOOGLE_CX = '635e6b14f7cf84f2c';

// Cache simple para resultados frecuentes
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function buscarImagenGoogle(text, keyIndex = 0, retries = 3) {
    // Verificar cache primero
    if (imageCache.has(text)) return imageCache.get(text);

    if (keyIndex >= GOOGLE_API_KEYS.length) return null; // Se acabaron las claves

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(text)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => item.fileFormat && item.fileFormat.startsWith('image/'));
            if (validImages.length > 0) {
                const randomImage = validImages[Math.floor(Math.random() * validImages.length)];
                imageCache.set(text, randomImage.link);
                return randomImage.link;
            }
        }
    } catch (error) {
        if (error.response) {
            if ((error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
                console.warn(`Clave actual agotada o 429. Probando siguiente clave... (${GOOGLE_API_KEYS[keyIndex]})`);
                await sleep(2000);
                // Pasar a la siguiente clave
                return buscarImagenGoogle(text, keyIndex + 1, 3);
            } else {
                console.error('Error HTTP:', error.response.status, error.response.data);
            }
        } else {
            console.error('Error al buscar imagen en Google:', error.message);
        }
    }

    return null;
}

// Comando normal
let handler = async (message, { text, conn }) => {
    try {
        if (!text) return await message.reply('❌ Por favor, proporciona un término de búsqueda. Ejemplo: .imagen árboles');

        const imageUrl = await buscarImagenGoogle(text);
        if (!imageUrl) return await message.reply('❌ No se encontraron imágenes o se agotaron las claves API.');

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // Enviar como respuesta al mensaje del comando (quoted)
        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: `🤖 *RobleBOT*\n\n📝 *Solicitud:*\n${text}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en el comando de imágenes:', error);
        return await message.reply('❌ Ocurrió un error al procesar tu solicitud de imagen.');
    }
};

// Comando view-once
let handlerViewOnce = async (message, { text, conn }) => {
    try {
        if (!text) return await message.reply('❌ Por favor, proporciona un término de búsqueda. Ejemplo: .imgv1 árboles');

        const imageUrl = await buscarImagenGoogle(text);
        if (!imageUrl) return await message.reply('❌ No se encontraron imágenes o se agotaron las claves API.');

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');
        
        // Enviar como respuesta al mensaje del comando (quoted) con viewOnce
        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: `🤖 *RobleBOT*\n\n📝 *Solicitud:*\n${text}\n\n⚠️ Esta imagen se puede ver una sola vez.`,
            viewOnce: true
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en el comando de imágenes (view once):', error);
        return await message.reply('❌ Ocurrió un error al procesar tu solicitud de imagen.');
    }
};

handler.help = ['imagen <texto>', 'img <texto>'];
handler.tags = ['imagenes', 'busqueda'];
handler.command = /^(imagen|img)$/i;

handlerViewOnce.help = ['imgv1 <texto>'];
handlerViewOnce.tags = ['imagenes', 'busqueda', 'view-once'];
handlerViewOnce.command = /^(imgv1)$/i;

module.exports = handler;
module.exports.imgv1 = handlerViewOnce;