/**
 * Plugin de Spotify
 * Permite descargar música de Spotify por link o por nombre
 * 
 * Comandos:
 * - .spotify <link o nombre> - Descargar canción
 * - .spotifydl <link o nombre> - Descargar canción
 * - .dlspotify <link o nombre> - Descargar canción
 */

const axios = require('axios');

const API_BASE = 'https://www.robleuy.site/robleapi';

/**
 * Descargar canción de Spotify por link
 */
async function downloadSpotify(url) {
    try {
        const response = await axios.get(`${API_BASE}/download/spotify`, {
            params: { url },
            timeout: 60000
        });
        
        if (response.data && response.data.ok) {
            return {
                success: true,
                data: response.data
            };
        } else {
            return {
                success: false,
                error: 'No se pudo obtener la información de la canción'
            };
        }
    } catch (error) {
        console.error('Error descargando de Spotify:', error.message);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Buscar canciones en Spotify
 */
async function searchSpotify(query) {
    try {
        const response = await axios.get(`${API_BASE}/buscador/spotify`, {
            params: { q: query },
            timeout: 30000
        });
        
        if (response.data && response.data.ok) {
            return {
                success: true,
                data: response.data
            };
        } else {
            return {
                success: false,
                error: 'No se encontraron resultados'
            };
        }
    } catch (error) {
        console.error('Error buscando en Spotify:', error.message);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Detectar si el texto es un link de Spotify
 */
function isSpotifyLink(text) {
    return text.includes('open.spotify.com/track/');
}

// ═══════════════════════════════════════════════════════════════════
// HANDLER PRINCIPAL - DESCARGAR POR LINK O NOMBRE
// ═══════════════════════════════════════════════════════════════════

let handler = async (message, { text, conn }) => {
    try {
        if (!text || text.trim() === '') {
            return await message.reply(
                `🎵 *SPOTIFY DOWNLOADER* 🎵\n\n` +
                `📝 *Uso:*\n` +
                `   .spotify <link o nombre>\n` +
                `   .spotifydl <link o nombre>\n` +
                `   .dlspotify <link o nombre>\n\n` +
                `📌 *Ejemplos:*\n` +
                `   .spotify https://open.spotify.com/track/...\n` +
                `   .spotify twice i can't stop me\n` +
                `   .spotifydl eminem lose yourself\n\n` +
                `🔍 *Para buscar sin descargar:*\n` +
                `   .spotifysearch <nombre>`
            );
        }
        
        const input = text.trim();
        let trackUrl = null;
        
        // Verificar si es un link o un nombre
        if (isSpotifyLink(input)) {
            trackUrl = input;
            await message.reply('⏳ Descargando de Spotify...');
        } else {
            await message.reply(`🔍 Buscando "${input}" en Spotify...`);
            
            const searchResult = await searchSpotify(input);
            
            if (!searchResult.success || !searchResult.data.tracks || searchResult.data.tracks.length === 0) {
                return await message.reply(
                    `❌ *No se encontraron resultados*\n\n` +
                    `No se encontraron canciones para: "${input}"\n\n` +
                    `💡 Intenta con otro término de búsqueda.`
                );
            }
            
            const firstTrack = searchResult.data.tracks[0];
            trackUrl = firstTrack.track_url;
        }
        
        // Descargar la canción
        const result = await downloadSpotify(trackUrl);
        
        if (!result.success) {
            return await message.reply(
                `❌ *Error al descargar*\n\n` +
                `${result.error}\n\n` +
                `💡 Verifica que el link sea correcto y que la canción esté disponible.`
            );
        }
        
        const { title, artist, image, download_url } = result.data;
        // Usar la URL que se usó para descargar (puede ser link directo o el track_url encontrado)
        const spotifyUrl = isSpotifyLink(input) ? input : (result.data.track_url || trackUrl || '');

        // Armar caption con toda la info + url de spotify
        let infoText = `🎵 *${title}*\n`;
        infoText += `� *Artista:* ${artist}\n`;
        if (result.data.album) infoText += `💿 *Álbum:* ${result.data.album}\n`;
        if (result.data.duration) infoText += `⏱️ *Duración:* ${result.data.duration}\n`;
        if (spotifyUrl) infoText += `\n🔗 ${spotifyUrl}`;

        // Enviar miniatura con toda la info (un solo mensaje)
        if (image) {
            try {
                await conn.sendMessage(message.from, {
                    image: { url: image },
                    caption: infoText
                }, { quoted: message._baileyMessage });
            } catch (e) {
                await message.reply(infoText);
            }
        } else {
            await message.reply(infoText);
        }
        
        // Descargar y enviar el audio
        try {
            const audioResponse = await axios.get(download_url, {
                responseType: 'arraybuffer',
                timeout: 120000,
                maxContentLength: 100 * 1024 * 1024,
                maxBodyLength: 100 * 1024 * 1024
            });
            
            await conn.sendMessage(message.from, {
                audio: audioResponse.data,
                mimetype: 'audio/mpeg',
                fileName: `${artist} - ${title}.mp3`,
                ptt: false
            }, { quoted: message._baileyMessage });
            
        } catch (error) {
            console.error('Error enviando audio:', error.message);
            await message.reply(
                `❌ *Error al enviar el audio*\n\n` +
                `El archivo puede ser muy grande o hubo un problema con la descarga.\n\n` +
                `🔗 *Link directo:*\n${download_url}`
            );
        }
        
    } catch (error) {
        console.error('Error en comando spotify:', error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud. Intenta de nuevo.');
    }
};

handler.help = ['spotify <link o nombre>', 'spotifydl <link o nombre>', 'dlspotify <link o nombre>'];
handler.tags = ['downloader'];
handler.command = /^(spotify|spotifydl|dlspotify)$/i;

module.exports = handler;
