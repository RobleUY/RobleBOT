const axios = require('axios')
const yts = require('yt-search')
const fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args))
const Jimp = require('jimp')

// ===============================
// CONFIG
// ===============================
const TIMEOUT_MS = 60000

// ===============================
// HELPER: Resize thumbnail
// ===============================
async function resizeImage(buffer, size = 300) {
    try {
        const image = await Jimp.read(buffer)
        return await image.resize(size, size).getBufferAsync(Jimp.MIME_JPEG)
    } catch {
        return buffer
    }
}

// ===============================
// HELPER: fetch buffer compatible (sin .buffer() deprecado)
// ===============================
async function fetchBuffer(url) {
    const res = await fetch(url)
    const arrayBuffer = await res.arrayBuffer()
    return Buffer.from(arrayBuffer)
}

// ===============================
// API SAVENOW / Y2DOWN
// ===============================
const savenowApi = {
    key: "dfcb6d76f2f6a9894gjkege8a4ab232222",
    agent: "Mozilla/5.0 (Android 13; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0",
    referer: "https://y2down.cc/enSB/",

    ytdl: async function (url, format) {
        const initUrl = `https://p.savenow.to/ajax/download.php?copyright=0&format=${format}&url=${encodeURIComponent(url)}&api=${this.key}`
        const init = await fetch(initUrl, {
            headers: { "User-Agent": this.agent, "Referer": this.referer }
        })
        const data = await init.json()
        if (!data.success) throw new Error(data.message || "Savenow: failed to start")

        const id = data.id
        const progressUrl = `https://p.savenow.to/api/progress?id=${id}`

        for (let i = 0; i < 30; i++) {
            await new Promise(r => setTimeout(r, 2000))
            const response = await fetch(progressUrl, {
                headers: { "User-Agent": this.agent, "Referer": this.referer }
            })
            const status = await response.json()
            if (status.progress === 1000) return {
                title: data.title || data.info?.title || null,
                image: data.info?.image || null,
                link: status.download_url
            }
        }
        throw new Error("Savenow: timeout")
    },

    download: async function (link, type = "audio") {
        const videoId = link.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]
        if (!videoId) throw new Error("Savenow: ID inválido")

        const videoInfo = await yts({ videoId })
        let result

        if (type === "audio") {
            try { result = await this.ytdl(link, "mp3") }
            catch { result = await this.ytdl(link, "m4a") }
        } else {
            for (const fmt of ["720", "360", "480", "240", "144", "1080"]) {
                try { result = await this.ytdl(link, fmt); break }
                catch { continue }
            }
            if (!result) throw new Error("Savenow: ningún formato de video disponible")
        }

        return {
            title: result.title || videoInfo?.title || "Sin título",
            author: videoInfo?.author?.name || "Desconocido",
            format: type === "audio" ? "mp3" : "mp4",
            download: result.link,
            thumbnail: result.image || videoInfo?.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
        }
    }
}

// ===============================
// API AM SCRAPER
// ===============================
const amScraperApi = {
    baseUrl: "https://scrapers.hostrta.win/scraper/24",

    download: async (link, type = "audio") => {
        const videoId = link.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]
        if (!videoId) throw new Error("AmScraper: ID inválido")

        const videoInfo = await yts({ videoId })
        const response = await axios.get(
            `${amScraperApi.baseUrl}?url=${encodeURIComponent(link)}`,
            { timeout: TIMEOUT_MS }
        )

        if (!response.data || response.data.error)
            throw new Error(response.data?.error || "AmScraper: error en API")

        const data = response.data
        const downloadUrl = type === "audio" ? data.audio?.url : data.video?.url
        if (!downloadUrl) throw new Error("AmScraper: formato no disponible")

        return {
            title: videoInfo?.title || "Sin título",
            author: videoInfo?.author?.name || "Desconocido",
            format: type === "audio" ? "mp3" : "mp4",
            download: downloadUrl,
            thumbnail: videoInfo?.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
        }
    }
}

// ===============================
// TODAS LAS APIS EN PARALELO → gana la más rápida
// ===============================
async function downloadFastest(url, type = 'audio') {
    const result = await Promise.any([
        savenowApi.download(url, type),
        amScraperApi.download(url, type)
    ]).catch(() => null)

    if (!result) throw new Error("Todas las APIs fallaron")
    return result
}

// ===============================
// HELPER: Tamaño legible
// ===============================
function formatSize(bytes) {
    if (!bytes || isNaN(bytes)) return 'Desconocido'
    const units = ['B', 'KB', 'MB', 'GB']
    let i = 0
    bytes = Number(bytes)
    while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++ }
    return `${bytes.toFixed(2)} ${units[i]}`
}

async function getSize(url) {
    try {
        const res = await axios.head(url, { timeout: 10000 })
        return parseInt(res.headers['content-length'], 10) || 0
    } catch { return 0 }
}

// ===============================
// HANDLER PRINCIPAL
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
    try {
        if (!text) {
            return message.reply(
                `❌ Debes enviar un link o búsqueda\n\nEjemplo:\n${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n${usedPrefix + command} Bad Bunny Amorfoda`
            )
        }

        const isAudio = command === 'audio2'
        const type = isAudio ? 'audio' : 'video'

        // ── Resolver URL ──
        let youtubeUrl, title, thumbnail

        if (/youtube\.com|youtu\.be/.test(text)) {
            const videoId = text.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]
            if (!videoId) return message.reply('❌ URL de YouTube inválida')
            youtubeUrl = `https://www.youtube.com/watch?v=${videoId}`
            const info = await yts({ videoId })
            title = info?.title || 'Sin título'
            thumbnail = info?.thumbnail || null
        } else {
            await message.reply('🔎 Buscando...')
            const search = await yts(text)
            if (!search?.videos?.length) return message.reply('❌ No se encontraron resultados')
            const video = search.videos[0]
            youtubeUrl = video.url
            title = video.title || 'Sin título'
            thumbnail = video.thumbnail || null
        }

        await message.reply(`⏳ Descargando ${isAudio ? 'audio 🎵' : 'video 🎬'}...\n🔎 *${title}*`)

        // ── Thumbnail ──
        let thumbResized = null
        if (thumbnail) {
            try {
                const thumbBuffer = await fetchBuffer(thumbnail)
                thumbResized = await resizeImage(thumbBuffer, 300)
            } catch { thumbResized = null }
        }

        // ── Descarga: todas las APIs en paralelo, gana la más rápida ──
        const dl = await downloadFastest(youtubeUrl, type)

        const finalTitle = (dl.title || title || 'Sin título')
            .replace(/[\\/:*?"<>|]/g, '')
            .trim()

        // ── Envío ──
        if (isAudio) {
            await conn.sendMessage(
                message.from,
                {
                    audio: { url: dl.download },
                    mimetype: 'audio/mpeg',
                    fileName: `${finalTitle}.mp3`
                },
                { quoted: message._baileyMessage }
            )
        } else {
            const size = await getSize(dl.download)

            if (size > 200 * 1024 * 1024) {
                // Muy grande → documento
                if (thumbResized) {
                    await conn.sendMessage(
                        message.from,
                        {
                            image: thumbResized,
                            caption: `🎬 *${finalTitle}*\n📦 ${formatSize(size)}\n\n_Archivo grande, enviando como documento..._`
                        },
                        { quoted: message._baileyMessage }
                    )
                }
                await conn.sendMessage(
                    message.from,
                    {
                        document: { url: dl.download },
                        mimetype: 'video/mp4',
                        fileName: `${finalTitle}.mp4`,
                        caption: `🎬 *${finalTitle}*\n⚠️ Enviado como documento (${formatSize(size)})`
                    },
                    { quoted: message._baileyMessage }
                )
            } else {
                await conn.sendMessage(
                    message.from,
                    {
                        video: { url: dl.download },
                        mimetype: 'video/mp4',
                        fileName: `${finalTitle}.mp4`,
                        caption: `🎬 *${finalTitle}*`,
                        ...(thumbResized && { jpegThumbnail: thumbResized })
                    },
                    { quoted: message._baileyMessage }
                )
            }
        }

    } catch (err) {
        console.error('[AUDIO2/VIDEO2 ERROR]', err?.message || err)
        await message.reply(
            `❌ Error al procesar\n\nPosibles causas:\n• Link inválido\n• Video privado o eliminado\n• Todas las APIs caídas`
        )
    }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['audio2 <link o búsqueda>', 'video2 <link o búsqueda>']
handler.tags = ['descargas']
handler.command = /^(audio2|video2)$/i

module.exports = handler