const axios = require('axios');
const cheerio = require('cheerio');
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils');

const FASTREAM_URL = 'https://fastream.to/ywq9c5gb1bs4';
const BASE_URL = 'https://fastream.to';
const TIMEOUT = 30000;

const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
    'Origin': BASE_URL,
    'Referer': BASE_URL + '/',
};

/**
 * Extrae la URL directa del video en fastream.to sin Puppeteer.
 * Flujo: GET page → extraer form fields → POST → extraer video URL del HTML
 */
async function extractFastreamVideoUrl(pageUrl) {
    // ── Paso 1: GET de la página principal ───────────────────────────────────
    const step1 = await axios.get(pageUrl, {
        headers: HEADERS,
        timeout: TIMEOUT,
        maxRedirects: 5,
    });

    const $1 = cheerio.load(step1.data);

    // Extraer todos los campos ocultos del form
    const formData = new URLSearchParams();
    $1('form input').each((_, el) => {
        const name  = $1(el).attr('name');
        const value = $1(el).attr('value') || '';
        if (name) formData.append(name, value);
    });
    // El botón de submit también se envía
    formData.append('imhuman', 'Proceed to video');

    const action = $1('form').attr('action') || '/' + pageUrl.split('/').pop();

    console.log('[FASTREAM] Form action:', action);
    console.log('[FASTREAM] Campos:', Object.fromEntries(formData));

    // Esperar los 5 segundos del countdown (el servidor verifica timing)
    await new Promise(r => setTimeout(r, 6000));

    // ── Paso 2: POST con los campos del form ─────────────────────────────────
    const postUrl = action.startsWith('http') ? action : BASE_URL + action;

    const step2 = await axios.post(postUrl, formData.toString(), {
        headers: {
            ...HEADERS,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': pageUrl,
        },
        timeout: TIMEOUT,
        maxRedirects: 5,
    });

    const html2 = step2.data;
    console.log('[FASTREAM] POST response length:', html2.length);

    // ── Paso 3: Extraer la URL del video del HTML resultante ─────────────────
    // Patrones comunes de reproductores (JWPlayer, VideoJS, custom)
    const patterns = [
        /file\s*:\s*["']([^"']+\.mp4[^"']*)/i,
        /file\s*:\s*["']([^"']+\.m3u8[^"']*)/i,
        /"file"\s*:\s*"([^"]+\.mp4[^"]*)"/i,
        /"file"\s*:\s*"([^"]+\.m3u8[^"]*)"/i,
        /sources\s*:\s*\[.*?["']([^"']+\.mp4[^"']*)["']/is,
        /src\s*:\s*["']([^"']+\.mp4[^"']*)/i,
        /video_url\s*=\s*["']([^"']+)/i,
        /"url"\s*:\s*"(https?:\/\/[^"]+\.mp4[^"]*)"/i,
        /player\.setup\([^)]*file\s*:\s*["']([^"']+)/i,
        /<source[^>]+src=["']([^"']+\.mp4[^"']*)/i,
        /<video[^>]+src=["']([^"']+\.mp4[^"']*)/i,
        /https?:\/\/[^\s"'<>]+\.mp4(?:[^\s"'<>]*)/i,
        /https?:\/\/[^\s"'<>]+\.m3u8(?:[^\s"'<>]*)/i,
    ];

    for (const pattern of patterns) {
        const match = html2.match(pattern);
        if (match) {
            let url = match[1] || match[0];
            // Limpiar URL si tiene escapes de JS
            url = url.replace(/\\u002F/gi, '/').replace(/\\/g, '');
            if (url.startsWith('//')) url = 'https:' + url;
            if (url.startsWith('http')) {
                console.log('[FASTREAM] URL encontrada:', url.substring(0, 80));
                return url;
            }
        }
    }

    // Si no encontramos nada, guardar el HTML para debug
    console.log('[FASTREAM] HTML paso 2 (primeros 2000 chars):\n', html2.substring(0, 2000));
    throw new Error('No se pudo extraer la URL del video. El sitio puede requerir login o ha cambiado su estructura.');
}

// ── HANDLER PRINCIPAL ─────────────────────────────────────────────────────────
let handler = async (message, { conn }) => {
    await message.reply('⏳ *Obteniendo video...*\nEspera ~6 segundos (countdown del sitio).');

    let tempFile = null;
    try {
        const videoUrl = await extractFastreamVideoUrl(FASTREAM_URL);

        await message.reply('📥 *Descargando video...*');

        const download = await downloadWithLimit(videoUrl, 300, {
            'Referer': BASE_URL + '/',
            'Origin': BASE_URL,
        });
        tempFile = download.tempFile;

        await conn.sendMessage(
            message.from,
            {
                video: download.buffer,
                caption: `🎬 *The Rookie S05E21*\n📦 ${download.sizeMB} MB`
            },
            { quoted: message._baileyMessage }
        );

    } catch (err) {
        console.error('[FASTREAM] Error:', err.message);

        if (err.message?.startsWith('LIMIT_EXCEEDED:')) {
            const sizeMB = err.message.split(':')[1];
            await message.reply(`❌ El video es demasiado grande (${sizeMB} MB). Límite: 300 MB`);
        } else {
            await message.reply(`❌ No se pudo descargar el video.\n\n*Error:* ${err.message}`);
        }
    } finally {
        if (tempFile) cleanupTempFile(tempFile);
    }
};

handler.help = ['thd'];
handler.tags = ['descargas'];
handler.command = /^thd$/i;

module.exports = handler;
