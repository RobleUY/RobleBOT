const axios = require('axios');

/**
 * 🎨 Handler para editar imágenes con IA
 */
let handlerEditIA = async (message, { conn, text, usedPrefix, command }) => {
    try {
        console.log(`🎯 Comando ejecutado: ${command}`);

        // 1️⃣ Validar que el usuario haya enviado texto
        if (!text || !text.trim()) {
            return await message.reply(
                `❌ *Uso incorrecto:*\n> ${usedPrefix}${command} <URL_IMAGEN> <Instrucción>\n\n*Ejemplo:*\n> ${usedPrefix}${command} https://midominio.com/imagen.jpg quiero que le quites el fondo`
            );
        }

        // 2️⃣ Separar la URL del prompt
        const partes = text.trim().split(/\s+/); // Divide por espacios
        const imagenURL = partes[0];
        const prompt = partes.slice(1).join(' '); // El resto del texto es el prompt

        // 3️⃣ Validar que haya tanto URL como prompt
        if (!imagenURL.startsWith('http')) {
            return await message.reply('❌ La URL proporcionada no es válida. Asegúrate de que empiece con http o https.');
        }

        if (!prompt) {
            return await message.reply('❌ Olvidaste escribir el prompt. ¿Qué quieres que la IA le haga a la imagen?');
        }

        await message.reply(`🔎 *Procesando imagen con IA...*\n> 📝 Instrucción: "${prompt}"\n⏳ _Esto puede tomar unos segundos._`);

        // 4️⃣ Construir la URL de la API
        const apikey = 'planaai';
        const apiUrl = `https://www.sankavollerei.web.id/ai/editimg?apikey=${apikey}&url=${encodeURIComponent(imagenURL)}&prompt=${encodeURIComponent(prompt)}`;
        
        console.log(`🔍 Consultando API: ${apiUrl}`);

        // 5️⃣ Hacer la petición a la API
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer', // Importante para recibir la imagen en formato buffer
            timeout: 30000 // Le damos 30 segundos porque la IA puede tardar en procesar
        });

        console.log(`📊 Status de respuesta: ${response.status}`);

        // 6️⃣ Validar respuesta y enviar la imagen al usuario
        if (response.status === 200 && response.data && response.data.length > 0) {
            const imageBuffer = Buffer.from(response.data);

            await conn.sendMessage(
                message.from,
                {
                    image: imageBuffer,
                    caption: `✨ *Imagen editada con éxito*\n\n📝 *Prompt:* ${prompt}`
                },
                { quoted: message._baileyMessage }
            );
            console.log(`✅ Imagen enviada correctamente`);
        } else {
            console.log(`⚠️ Respuesta vacía o inválida de la API`);
            await message.reply('❌ La API no devolvió una imagen válida. Intenta con otra imagen o instrucción.');
        }

    } catch (error) {
        console.error('💥 Error en comando Edit IA:', error.message);
        await message.reply('❌ Ocurrió un error al intentar editar la imagen. Es posible que el servidor de la API esté saturado o la URL de la imagen no sea accesible.');
    }
};

// ⚙️ Configuración de comandos y alias
handlerEditIA.command = /^(editia|editai|iaedit|editaria|iaedita)$/i;
handlerEditIA.help = [
    'editia <url> <prompt>'
];
handlerEditIA.tags = ['ia', 'herramientas'];

module.exports = handlerEditIA;