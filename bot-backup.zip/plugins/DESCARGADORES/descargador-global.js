const axios = require('axios');
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils');

const ROBLE_API = 'https://www.robleuy.site/robleapi/download';
const SANKA_API = 'https://www.sankavollerei.com/download';
const TIMEOUT = 60000;

// ── Detectar plataforma por URL ──────────────────────────────────────────────
function detectPlatform(url) {
    if (/tiktok\.com|vt\.tiktok\.com/i.test(url))       return 'tiktok';
    if (/instagram\.com/i.test(url))                     return 'instagram';
    if (/youtube\.com|youtu\.be/i.test(url))             return 'youtube';
    if (/facebook\.com|fb\.watch/i.test(url))            return 'facebook';
    if (/twitter\.com|x\.com/i.test(url))                return 'twitter';
    if (/threads\.net/i.test(url))                       return 'threads';
    if (/open\.spotify\.com/i.test(url))                 return 'spotify';
    if (/pinterest\./i.test(url))                        return 'pinterest';
    return null;
}

// ── Descargadores por plataforma ─────────────────────────────────────────────

async function downloadTikTok(url) {
    const res = await axios.get(`${ROBLE_API}/tiktok?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    if (!res.data?.ok || !res.data?.download_url) throw new Error('Sin link de descarga');
    return { type: 'video', url: res.data.download_url, caption: `🎬 *${res.data.title || ''}*\n👤 ${res.data.author || ''}` };
}

async function downloadInstagram(url) {
    const res = await axios.get(`${ROBLE_API}/instagram?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    if (!res.data?.ok || !res.data?.items?.length) throw new Error('Sin contenido');
    // Devolver todos los items (puede ser carrusel)
    return res.data.items.map(item => ({
        type: item.type === 'video' ? 'video' : 'image',
        url: item.download_url,
        caption: ''
    }));
}

async function downloadYouTube(url) {
    // Intentar ambas APIs en paralelo
    const res = await Promise.any([
        axios.get(`${ROBLE_API}/ytmp4?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT })
            .then(r => { if (!r.data?.ok || !r.data?.download_url) throw new Error('no url'); return r; }),
        axios.get(`${SANKA_API}/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT })
            .then(r => { if (!r.data?.status) throw new Error('no url'); return r; })
    ]);

    const d = res.data;
    const dlUrl  = d.download_url || d.result?.download;
    const title  = d.title        || d.result?.title || 'video';
    const thumb  = d.thumbnail    || d.result?.thumbnail || null;
    if (!dlUrl) throw new Error('Sin link de descarga');
    return { type: 'video', url: dlUrl, caption: `🎬 *${title}*`, thumbnail: thumb };
}

async function downloadFacebook(url) {
    const res = await axios.get(`${SANKA_API}/facebook?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    if (!res.data?.status || !res.data?.result) throw new Error('Sin contenido');
    const r = res.data.result;
    const videoUrl = r.video?.find(v => v.quality === '360p (SD)')?.url || r.media || r.video?.[0]?.url;
    if (!videoUrl) throw new Error('Sin link de video');
    return { type: 'video', url: videoUrl, caption: `🎬 *${r.title || 'Facebook'}*` };
}

async function downloadTwitter(url) {
    const res = await axios.get(`https://delirius-apiofc.vercel.app/download/twitterdl?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    const d = res.data;
    if (!d.found || !d.media?.length) throw new Error('Sin contenido');
    return { type: d.type === 'video' ? 'video' : 'image', url: d.media[0].url, caption: '' };
}

async function downloadThreads(url) {
    const res = await axios.get(`https://delirius-apiofc.vercel.app/download/threads?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    if (!res.data?.status || !res.data?.data?.length) throw new Error('Sin contenido');
    return res.data.data
        .filter(i => i.type === 'image' && i.url)
        .map(i => ({ type: 'image', url: i.url, caption: '' }));
}

async function downloadSpotify(url) {
    const res = await axios.get(`${ROBLE_API}/spotify?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT });
    if (!res.data?.ok || !res.data?.download_url) throw new Error('Sin link de descarga');
    const d = res.data;
    return {
        type: 'audio',
        url: d.download_url,
        caption: `🎵 *${d.title}*\n🎤 ${d.artist}`,
        thumbnail: d.image || null,
        fileName: `${d.artist} - ${d.title}.mp3`
    };
}

// ── Enviar un item descargado ─────────────────────────────────────────────────
async function sendItem(conn, message, item) {
    let tempFile = null;
    
    try {
        // Descargar con límite de tamaño (300 MB por defecto)
        const download = await downloadWithLimit(item.url);
        tempFile = download.tempFile;
        
        const buf = download.buffer;

        if (item.type === 'video') {
            await sock.sendMessage(message.from, { video: buf, caption: item.caption || '' }, { quoted: message._baileyMessage });
        } else if (item.type === 'image') {
            await sock.sendMessage(message.from, { image: buf, caption: item.caption || '' }, { quoted: message._baileyMessage });
        } else if (item.type === 'audio') {
            if (item.thumbnail) {
                await sock.sendMessage(message.from, {
                    image: { url: item.thumbnail },
                    caption: item.caption || ''
                }, { quoted: message._baileyMessage });
            }
            await sock.sendMessage(message.from, {
                audio: buf,
                mimetype: 'audio/mpeg',
                fileName: item.fileName || 'audio.mp3',
                ptt: false
            }, { quoted: message._baileyMessage });
        }
    } catch (error) {
        if (error.message?.startsWith('LIMIT_EXCEEDED:')) {
            const sizeMB = error.message.split(':')[1];
            throw new Error(`El archivo es demasiado grande (${sizeMB} MB). Límite: 300 MB`);
        }
        throw error;
    } finally {
        // Limpiar archivo temporal
        if (tempFile) {
            cleanupTempFile(tempFile);
        }
    }
}

// ── HANDLER PRINCIPAL ─────────────────────────────────────────────────────────
const PLATFORM_NAMES = {
    tiktok: 'TikTok', instagram: 'Instagram', youtube: 'YouTube',
    facebook: 'Facebook', twitter: 'Twitter / X', threads: 'Threads',
    spotify: 'Spotify', pinterest: 'Pinterest'
};

let handler = async (message, { text, conn, usedPrefix, command }) => {
    const sock = conn || message._sock || global.conn;
    if (!text?.trim()) {
        return message.reply(
            `📥 *Descargador Global*\n\n` +
            `Uso: *${usedPrefix}${command} <enlace>*\n\n` +
            `Plataformas soportadas:\n` +
            `• TikTok  • Instagram  • YouTube\n` +
            `• Facebook  • Twitter/X  • Threads\n` +
            `• Spotify  • Pinterest`
        );
    }

    const url = text.trim().split(/\s+/)[0]; // tomar solo el primer token (el link)
    const platform = detectPlatform(url);

    if (!platform) {
        return message.reply(
            `❌ No reconozco ese enlace.\n\n` +
            `Plataformas soportadas: TikTok, Instagram, YouTube, Facebook, Twitter/X, Threads, Spotify, Pinterest.`
        );
    }

    await message.reply(`⏳ Descargando de *${PLATFORM_NAMES[platform]}*...`);

    try {
        let items;

        switch (platform) {
            case 'tiktok':    items = [await downloadTikTok(url)];    break;
            case 'instagram': items = await downloadInstagram(url);   break;
            case 'youtube':   items = [await downloadYouTube(url)];   break;
            case 'facebook':  items = [await downloadFacebook(url)];  break;
            case 'twitter':   items = [await downloadTwitter(url)];   break;
            case 'threads':   items = await downloadThreads(url);     break;
            case 'spotify':   items = [await downloadSpotify(url)];   break;
            default: return message.reply('❌ Plataforma no soportada.');
        }

        if (!Array.isArray(items)) items = [items];
        if (!items.length) return message.reply('❌ No se encontró contenido en ese enlace.');

        for (const item of items) {
            await sendItem(conn, message, item);
        }

    } catch (err) {
        console.error(`[DL-GLOBAL] Error (${platform}):`, err.message);
        await message.reply(
            `❌ No se pudo descargar el contenido.\n\n` +
            `Posibles causas: enlace privado, expirado o plataforma caída.`
        );
    }
};

handler.help = ['descargar <enlace>'];
handler.tags = ['descargas'];
handler.command = /^(descargar|download|dl|bajar)$/i;

module.exports = handler;

