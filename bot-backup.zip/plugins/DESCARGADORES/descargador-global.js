const axios = require('axios')
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils')

const ROBLE_API = 'https://robleuy.vercel.app/robleapi/download'
const SANKA_API = 'https://www.sankavollerei.com/download'
const DELIRIUS_API = 'https://api.delirius.online/download'
const TIMEOUT = 60000
const MAX_LIMIT_MB = 300 // Límite de 300 MB

function getDynamicHeaders(url) {
  let origin = 'https://www.google.com'
  try {
    const parsed = new URL(url)
    origin = parsed.origin
  } catch (e) {}

  return {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/*,video/*,audio/*,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Referer': origin + '/'
  }
}

function parseBase64(dataUri) {
  const matches = dataUri.match(/^data:(.+?);base64,(.+)$/)
  if (!matches) return null
  const mimetype = matches[1]
  const buffer = Buffer.from(matches[2], 'base64')
  let type = 'document'
  if (mimetype.startsWith('image/')) type = 'image'
  else if (mimetype.startsWith('video/')) type = 'video'
  else if (mimetype.startsWith('audio/')) type = 'audio'
  return { type, buffer, mimetype }
}

function isDirectMediaUrl(url = '') {
  return /\.(jpg|jpeg|png|webp|gif|bmp|mp4|webm|mkv|mov|avi|mp3|ogg|wav|m4a)(\?.*)?$/i.test(url) ||
         /i\.imgur\.com|ichef\.bbci\.co\.uk|gstatic\.com|googleusercontent\.com|media\.giphy\.com/i.test(url)
}

function detectTypeFromUrl(url = '') {
  if (/\.(jpg|jpeg|png|webp|gif|bmp)(\?.*)?$/i.test(url)) return 'image'
  if (/\.(mp4|webm|mkv|mov|avi)(\?.*)?$/i.test(url)) return 'video'
  if (/\.(mp3|ogg|wav|m4a)(\?.*)?$/i.test(url)) return 'audio'
  if (/i\.imgur\.com|ichef\.bbci\.co\.uk|gstatic\.com|googleusercontent\.com/i.test(url)) return 'image'
  return null
}

// ── Detectar plataforma por URL ──────────────────────────────────────────────
function detectPlatform(url) {
  if (/tiktok\.com|vt\.tiktok\.com/i.test(url)) return 'tiktok'
  if (/instagram\.com/i.test(url)) return 'instagram'
  if (/youtube\.com|youtu\.be/i.test(url)) return 'youtube'
  if (/facebook\.com|fb\.watch/i.test(url)) return 'facebook'
  if (/twitter\.com|x\.com/i.test(url)) return 'twitter'
  if (/threads\.net/i.test(url)) return 'threads'
  if (/open\.spotify\.com/i.test(url)) return 'spotify'
  if (/pinterest\.|pin\.it/i.test(url)) return 'pinterest'
  if (/xvideos\.com|pornhub\.com|rule34|redtube\.com|xnxx\.com|hentai/i.test(url)) return 'nsfw'
  return null
}

// ── Descarga directa HTTP/CDN optimizada ──────────────────────────────────────
async function fetchDirectMedia(url) {
  let targetUrl = url

  // Manejo especial de Imgur gallery -> imagen directa
  if (url.includes('imgur.com/gallery/') || url.includes('imgur.com/a/')) {
    const parts = url.split('/')
    const id = parts[parts.length - 1].split('?')[0]
    targetUrl = `https://i.imgur.com/${id}.jpg`
  }

  // Intento 1: Con Headers dinámicos basados en la propia URL (bypass hotlink CDN)
  try {
    const res = await axios.get(targetUrl, {
      responseType: 'arraybuffer',
      timeout: TIMEOUT,
      maxContentLength: MAX_LIMIT_MB * 1024 * 1024,
      headers: getDynamicHeaders(targetUrl)
    })

    const contentType = res.headers['content-type'] || ''
    const buffer = Buffer.from(res.data)

    if (buffer && buffer.length > 30) {
      let type = 'image'
      if (contentType.startsWith('video/')) type = 'video'
      else if (contentType.startsWith('audio/')) type = 'audio'
      else if (contentType.startsWith('image/')) type = 'image'
      else if (detectTypeFromUrl(targetUrl)) type = detectTypeFromUrl(targetUrl)

      console.log(`[DL-GLOBAL] ✅ Descarga directa HTTP exitosa (${type}, ${(buffer.length / 1024).toFixed(1)} KB)`)
      return [{ type, buffer }]
    }
  } catch (e1) {
    console.warn('[DL-GLOBAL] Intento 1 descarga directa falló:', e1.message)
  }

  // Intento 2: Headers mínimos (sin referer)
  try {
    const res = await axios.get(targetUrl, {
      responseType: 'arraybuffer',
      timeout: TIMEOUT,
      maxContentLength: MAX_LIMIT_MB * 1024 * 1024,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': '*/*'
      }
    })

    const contentType = res.headers['content-type'] || ''
    const buffer = Buffer.from(res.data)

    if (buffer && buffer.length > 30) {
      let type = 'image'
      if (contentType.startsWith('video/')) type = 'video'
      else if (contentType.startsWith('audio/')) type = 'audio'
      else if (contentType.startsWith('image/')) type = 'image'
      else if (detectTypeFromUrl(targetUrl)) type = detectTypeFromUrl(targetUrl)

      console.log(`[DL-GLOBAL] ✅ Descarga directa HTTP (sin referer) exitosa (${type}, ${(buffer.length / 1024).toFixed(1)} KB)`)
      return [{ type, buffer }]
    }
  } catch (e2) {
    console.warn('[DL-GLOBAL] Intento 2 descarga directa falló:', e2.message)
  }

  throw new Error('Falló la descarga directa HTTP')
}

// ── Descargadores por plataforma (Carrera de APIs en paralelo) ────────────────

async function downloadTikTok(url) {
  const tasks = []
  tasks.push(
    axios.get(`${ROBLE_API}/tiktok?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.ok || !r.data?.download_url) throw new Error('no url')
      return { type: 'video', url: r.data.download_url, caption: `🎬 *${r.data.title || ''}*`, source: 'RobleAPI' }
    })
  )
  tasks.push(
    axios.get(`${SANKA_API}/tiktok?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const u = r.data?.result?.download || r.data?.result?.video
      if (!r.data?.status || !u) throw new Error('no url')
      return { type: 'video', url: u, caption: '', source: 'SankaAPI' }
    })
  )
  tasks.push(
    axios.get(`${DELIRIUS_API}/tiktok?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const dl = r.data?.data?.meta?.media?.find(m => m.type === 'video')?.org || r.data?.data?.meta?.media?.[0]?.url
      if (!r.data?.status || !dl) throw new Error('no url')
      return { type: 'video', url: dl, caption: `🎬 *${r.data.data?.meta?.title || ''}*`, source: 'DeliriusAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 TikTok descargado vía ${winner.source}`)
  return winner
}

function getInstagramCdnHeaders() {
  return {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Referer': 'https://www.instagram.com/',
    'Accept': '*/*',
    'Accept-Language': 'es-ES,es;q=0.9'
  }
}

function isInstagramCdn(url = '') {
  return /cdninstagram\.com|fbcdn\.net/i.test(url)
}

async function downloadInstagram(url) {
  const tasks = []

  // Delirius v1: URLs proxy rapidcdn.app
  tasks.push(
    axios.get(`${DELIRIUS_API}/instagram?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.data?.length) throw new Error('no items')
      const valid = r.data.data.filter(i => i.url).map(i => ({
        type: i.type === 'image' ? 'image' : 'video',
        url: i.url
      }))
      if (!valid.length) throw new Error('no items')
      return { items: valid, source: 'DeliriusAPI-v1' }
    })
  )

  // Delirius v2: URLs directas del CDN de Instagram
  tasks.push(
    axios.get(`${DELIRIUS_API}/instagramv2?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const download = r.data?.data?.download
      if (!r.data?.status || !Array.isArray(download) || !download.length) throw new Error('no items')
      const valid = download.filter(i => i.url).map(i => ({
        type: i.type === 'image' ? 'image' : 'video',
        url: i.url,
        headers: isInstagramCdn(i.url) ? getInstagramCdnHeaders() : undefined
      }))
      if (!valid.length) throw new Error('no items')
      return { items: valid, source: 'DeliriusAPI-v2' }
    })
  )

  // RobleAPI
  tasks.push(
    axios.get(`${ROBLE_API}/instagram?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.ok || !r.data?.items?.length) throw new Error('no url')
      const valid = r.data.items.map(i => ({ type: i.type === 'image' ? 'image' : 'video', url: i.download_url }))
      return { items: valid, source: 'RobleAPI' }
    })
  )

  // SankaAPI
  tasks.push(
    axios.get(`${SANKA_API}/instagram?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const result = r.data?.result
      if (!r.data?.status || !result) throw new Error('no result')
      const urls = Array.isArray(result) ? result : [result.url || result.download || result]
      const valid = urls.filter(Boolean).map(u => ({
        type: String(u).includes('.mp4') ? 'video' : 'image',
        url: typeof u === 'string' ? u : (u.url || u.download)
      })).filter(i => i.url)
      if (!valid.length) throw new Error('no items')
      return { items: valid, source: 'SankaAPI' }
    })
  )

  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 Instagram descargado vía ${winner.source}`)
  return winner.items
}

async function downloadYouTube(url) {
  const tasks = []
  tasks.push(
    axios.get(`http://olivia.hidencloud.com:24733/robleapi/downloads/ytvideo?link=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const result = r.data?.result || r.data
      const download = result?.download || r.data?.download_url
      if (!r.data?.status || !download) throw new Error('no url')
      return { type: 'video', url: download, caption: `🎬 *${result.title || r.data?.title || 'Video'}*`, source: 'OliviaAPI' }
    })
  )
  tasks.push(
    axios.get(`${SANKA_API}/ytmp4?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.result?.download) throw new Error('no url')
      return { type: 'video', url: r.data.result.download, caption: `🎬 *${r.data.result.title || 'Video'}*`, source: 'SankaAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 YouTube descargado vía ${winner.source}`)
  return winner
}

async function downloadFacebook(url) {
  const tasks = []
  tasks.push(
    axios.get(`${SANKA_API}/facebook?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.result) throw new Error('no url')
      const videoUrl = r.data.result.video?.find(v => v.quality === '360p (SD)')?.url || r.data.result.media || r.data.result.video?.[0]?.url
      if (!videoUrl) throw new Error('no url')
      return { type: 'video', url: videoUrl, caption: `🎬 *${r.data.result.title || 'Facebook'}*`, source: 'SankaAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 Facebook descargado vía ${winner.source}`)
  return winner
}

async function downloadTwitter(url) {
  const tasks = []
  tasks.push(
    axios.get(`${DELIRIUS_API}/twitter?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const d = r.data
      if (!d?.status || !d?.data?.media?.length) throw new Error('no url')
      const first = d.data.media[0]
      const u = first.type === 'video' ? first.videos?.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0]?.url : first.image
      if (!u) throw new Error('no url')
      return { type: first.type === 'video' ? 'video' : 'image', url: u, caption: d.data.description || '', source: 'DeliriusAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 Twitter descargado vía ${winner.source}`)
  return winner
}

async function downloadThreads(url) {
  const tasks = []

  tasks.push(
    axios.get(`${DELIRIUS_API}/threads?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.data?.length) throw new Error('no items')
      return r.data.data.filter(i => i.url).map(i => ({
        type: i.type === 'image' ? 'image' : 'video',
        url: i.url,
        caption: ''
      }))
    })
  )

  tasks.push(
    axios.get(`${ROBLE_API}/threads?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.ok) throw new Error('no items')
      const items = []
      if (r.data?.download_url) items.push({ type: 'video', url: r.data.download_url, caption: '' })
      else if (Array.isArray(r.data?.items)) {
        for (const i of r.data.items) {
          if (i.download_url) items.push({ type: i.type === 'image' ? 'image' : 'video', url: i.download_url, caption: '' })
        }
      }
      if (!items.length) throw new Error('no items')
      return items
    })
  )

  tasks.push(
    axios.get(`${SANKA_API}/threads?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      const result = r.data?.result
      if (!r.data?.status || !result) throw new Error('no result')
      const dl = result.download || result.url || result.video || result.media
      if (!dl) throw new Error('no url')
      return [{ type: String(dl).includes('.mp4') ? 'video' : 'image', url: dl, caption: '' }]
    })
  )

  const winner = await Promise.any(tasks)
  console.log('[DL-GLOBAL] 🏆 Threads descargado')
  return winner
}

async function downloadSpotify(url) {
  const tasks = []
  tasks.push(
    axios.get(`${ROBLE_API}/spotify?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.ok || !r.data?.download_url) throw new Error('no url')
      const d = r.data
      return { type: 'audio', url: d.download_url, caption: `🎵 *${d.title}*\n🎤 ${d.artist}`, thumbnail: d.image || null, fileName: `${d.artist} - ${d.title}.mp3`, source: 'RobleAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 Spotify descargado vía ${winner.source}`)
  return winner
}

async function downloadPinterest(url) {
  const tasks = []
  tasks.push(
    axios.get(`${ROBLE_API}/pinterest?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.ok || !r.data?.download_url) throw new Error('no url')
      return { type: r.data.download_url.includes('.mp4') ? 'video' : 'image', url: r.data.download_url, caption: '', source: 'RobleAPI' }
    })
  )
  tasks.push(
    axios.get(`${DELIRIUS_API}/pinterest?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.data?.url) throw new Error('no url')
      return { type: r.data.data.type === 'video' ? 'video' : 'image', url: r.data.data.url, caption: '', source: 'DeliriusAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 Pinterest descargado vía ${winner.source}`)
  return [winner]
}

async function downloadNSFW(url) {
  const tasks = []
  tasks.push(
    axios.get(`${DELIRIUS_API}/xvideos?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT }).then(r => {
      if (!r.data?.status || !r.data?.data?.url) throw new Error('no url')
      return { type: 'video', url: r.data.data.url, caption: `🔞 *${r.data.data.title || 'NSFW Video'}*`, source: 'DeliriusAPI' }
    })
  )
  const winner = await Promise.any(tasks)
  console.log(`[DL-GLOBAL] 🏆 NSFW descargado vía ${winner.source}`)
  return winner
}

// ── Descarga universal para cualquier otro enlace o archivo directo ───────────
async function downloadUniversal(url) {
  // 1. Base64 URI
  if (url.startsWith('data:')) {
    const b64 = parseBase64(url)
    if (b64) return [{ type: b64.type, buffer: b64.buffer }]
  }

  // 2. Si es un enlace directo a archivo multimedia/imagen (como BBC, Imgur, CDN, webp, jpg, mp4)
  if (isDirectMediaUrl(url)) {
    try {
      console.log('[DL-GLOBAL] Detectado enlace multimedia directo, priorizando descarga HTTP...')
      return await fetchDirectMedia(url)
    } catch (eDirect) {
      console.warn('[DL-GLOBAL] Descarga directa preliminar falló, continuando con opciones universales:', eDirect.message)
    }
  }

  // 3. Plataforma conocida
  const platform = detectPlatform(url)
  if (platform) {
    try {
      switch (platform) {
        case 'tiktok': return [await downloadTikTok(url)]
        case 'instagram': return await downloadInstagram(url)
        case 'youtube': return [await downloadYouTube(url)]
        case 'facebook': return [await downloadFacebook(url)]
        case 'twitter': return [await downloadTwitter(url)]
        case 'threads': return await downloadThreads(url)
        case 'spotify': return [await downloadSpotify(url)]
        case 'pinterest': return await downloadPinterest(url)
        case 'nsfw': return [await downloadNSFW(url)]
      }
    } catch (e) {
      console.warn(`[DL-GLOBAL] Plataforma ${platform} falló, intentando descarga directa o universal:`, e.message)
    }
  }

  // 4. Carrera de descargadores universales y directa (Imgur, gstatic, CDN, etc.)
  const tasks = []

  // Intento A: Descarga directa HTTP con bypass de headers
  tasks.push(fetchDirectMedia(url))

  // Intento B: Delirius universal
  tasks.push(
    (async () => {
      console.log('[DL-GLOBAL] Consultando Delirius universal (alldl)...')
      const res = await axios.get(`${DELIRIUS_API}/alldl?url=${encodeURIComponent(url)}`, { timeout: TIMEOUT })
      const data = res.data
      if (!data?.status || !data?.data) throw new Error('Delirius no url')
      const items = Array.isArray(data.data) ? data.data : [data.data]
      const valid = items.map(i => ({
        type: i.type === 'image' ? 'image' : 'video',
        url: i.url || i.download
      })).filter(i => i.url)
      if (!valid.length) throw new Error('Delirius no url')
      console.log('[DL-GLOBAL] ✅ Delirius universal devolvió resultado')
      return valid
    })()
  )

  try {
    return await Promise.any(tasks)
  } catch (e) {
    console.error('[DL-GLOBAL] Todas las opciones de descarga universal fallaron:', e.message)
    throw new Error('No se pudo extraer contenido de ese enlace.')
  }
}

// ── Enviar un item descargado ─────────────────────────────────────────────────
async function sendItem(conn, message, item) {
  let tempFile = null

  try {
    let buf
    if (Buffer.isBuffer(item.buffer)) {
      buf = item.buffer
      if (buf.length > MAX_LIMIT_MB * 1024 * 1024) {
        throw new Error('LIMIT_EXCEEDED:' + (buf.length / (1024 * 1024)).toFixed(2))
      }
    } else if (item.url) {
      const download = await downloadWithLimit(item.url, MAX_LIMIT_MB)
      tempFile = download.tempFile
      buf = download.buffer
    } else {
      throw new Error('Sin contenido para enviar')
    }

    if (item.type === 'video') {
      await conn.sendMessage(message.from, { video: buf, caption: item.caption || '' }, { quoted: message._baileyMessage })
    } else if (item.type === 'image') {
      await conn.sendMessage(message.from, { image: buf, caption: item.caption || '' }, { quoted: message._baileyMessage })
    } else if (item.type === 'audio') {
      if (item.thumbnail) {
        await conn.sendMessage(message.from, { image: { url: item.thumbnail }, caption: item.caption || '' }, { quoted: message._baileyMessage })
      }
      await conn.sendMessage(message.from, { audio: buf, mimetype: 'audio/mpeg', fileName: item.fileName || 'audio.mp3', ptt: false }, { quoted: message._baileyMessage })
    } else {
      await conn.sendMessage(message.from, { document: buf, mimetype: 'application/octet-stream', fileName: 'archivo' }, { quoted: message._baileyMessage })
    }

  } catch (error) {
    if (error.message?.startsWith('LIMIT_EXCEEDED:')) {
      const sizeMB = error.message.split(':')[1]
      throw new Error(`El archivo es demasiado grande (${sizeMB} MB). Límite: ${MAX_LIMIT_MB} MB`)
    }
    throw error
  } finally {
    if (tempFile) {
      cleanupTempFile(tempFile)
    }
  }
}

// ── HANDLER PRINCIPAL ─────────────────────────────────────────────────────────
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn
  if (!text?.trim()) {
    return message.reply(
      `📥 *Descargador Global*\n\n` +
      `Uso: *${usedPrefix}${command} <enlace o base64>*\n\n` +
      `Soporta enlaces de:\n` +
      `• YouTube, TikTok, Instagram, Facebook, Twitter/X, Threads, Spotify, Pinterest, NSFW\n` +
      `• Imágenes directas, Imgur, CDN, Gstatic, Base64 o videos directos.`
    )
  }

  const url = text.trim().split(/\s+/)[0]

  await message.reply('⏳ Procesando y descargando contenido...')

  try {
    const items = await downloadUniversal(url)

    if (!items || !items.length) {
      return message.reply('❌ No se encontró contenido en ese enlace.')
    }

    for (const item of items) {
      await sendItem(conn, message, item)
    }

    console.log(`[DL-GLOBAL] ✅ Contenido enviado exitosamente a WhatsApp`)

  } catch (err) {
    console.error(`[DL-GLOBAL ERROR]`, err.message || err)
    if (err.message?.includes('demasiado grande')) {
      await message.reply(`❌ *${err.message}*`)
    } else {
      await message.reply(
        `❌ *No se pudo descargar el contenido*\n\n` +
        `_Posibles causas: enlace privado, expirado, archivo demasiado pesado o no soportado._`
      )
    }
  }
}

handler.help = ['descargar <enlace>']
handler.tags = ['descargas']
handler.command = /^(descargar|download|dl|bajar)$/i

module.exports = handler