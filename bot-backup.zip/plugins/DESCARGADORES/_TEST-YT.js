const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { downloadWithLimit, cleanupTempFile } = require('../../downloadUtils');

const ROBLE_API_BASE = 'http://olivia.hidencloud.com:24733/robleapi/downloads';

const TEMP_DIR = path.join(process.cwd(), '.temp', 'test-yt');
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

function getYoutubeUrl(text = '') {
  if (!text || !text.trim()) return null;
  const match = text.match(/https?:\/\/[^\s]+/i) || text.match(/youtu\.be\/[^\s]+|youtube\.com\/[^\s]+/i);
  return match ? match[0].replace(/[),.;]+$/, '') : null;
}

function sanitizeFilename(name = 'archivo') {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120) || 'archivo';
}

function normalizeRobleResult(payload, mode = 'audio') {
  if (!payload || !payload.status) {
    throw new Error(payload?.message || 'ROBLEAPI_NO_OK');
  }

  const result = payload.result;
  if (!result || !result.download) {
    throw new Error('ROBLEAPI_SIN_DOWNLOAD');
  }

  const type = String(result.type || mode).toLowerCase();
  const downloadUrl = result.download;
  const title = result.title || `youtube_${Date.now()}`;
  const extension = type === 'audio' || mode === 'audio' ? '.mp3' : '.mp4';
  const fileName = sanitizeFilename(`${title}${extension}`);

  return { downloadUrl, fileName, title, type };
}

async function resolveRobleDownload(url, mode = 'audio') {
  const endpoint = `${ROBLE_API_BASE}/${mode === 'audio' ? 'ytaudio' : 'ytvideo'}?link=${encodeURIComponent(url)}`;

  const response = await axios.get(endpoint, {
    timeout: 30000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      Referer: 'https://www.youtube.com/'
    }
  });

  const payload = response && response.data ? response.data : {};
  const info = normalizeRobleResult(payload, mode);

  const downloaded = await downloadWithLimit(info.downloadUrl, 250, {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    Referer: 'https://www.youtube.com/'
  });

  return {
    fileName: info.fileName,
    buffer: downloaded.buffer,
    tempFile: downloaded.tempFile,
    sizeMB: downloaded.sizeMB,
    title: info.title,
    directUrl: info.downloadUrl
  };
}

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn;

  if (!text || !text.trim()) {
    return message.reply(
      `❌ Debes enviar el enlace del video de YouTube.

Ejemplo:
${usedPrefix}${command} https://youtu.be/xxxxxxxxxxx`
    );
  }

  const link = getYoutubeUrl(text);
  if (!link) {
    return message.reply('❌ El texto no parece un enlace válido de YouTube.');
  }

  const isAudio = String(command).toLowerCase() === 'testyta';
  const mode = isAudio ? 'audio' : 'video';
  let tempFile = null;

  try {
    await message.reply(`⏳ Descargando ${mode === 'audio' ? 'audio' : 'video'} desde RobleAPI...`);

    const result = await resolveRobleDownload(link, mode);
    tempFile = result.tempFile;
    const buffer = result.buffer;
    const fileName = result.fileName;

    if (mode === 'audio') {
      await sock.sendMessage(
        message.from,
        {
          audio: buffer,
          mimetype: 'audio/mpeg',
          fileName,
          caption: '🎵 *Audio descargado desde RobleAPI*'
        },
        { quoted: message._baileyMessage }
      );
    } else {
      await sock.sendMessage(
        message.from,
        {
          video: buffer,
          mimetype: 'video/mp4',
          fileName,
          caption: '🎬 *Video descargado desde RobleAPI*'
        },
        { quoted: message._baileyMessage }
      );
    }

    console.log(`[TEST-YT] ✅ Archivo enviado: ${fileName} (${result.sizeMB} MB)`);
  } catch (error) {
    const msg = error && error.message ? error.message : String(error);
    console.error('[TEST-YT] Error:', msg);

    const friendly = `❌ No se pudo descargar el archivo desde RobleAPI.\n\n*Motivo:* ${msg}`;
    await message.reply(friendly);
  } finally {
    if (tempFile) cleanupTempFile(tempFile);
  }
};

handler.help = ['testyta <link>', 'testytv <link>'];
handler.tags = ['descargas'];
handler.command = /^(testyta|testytv)$/i;

module.exports = handler;
