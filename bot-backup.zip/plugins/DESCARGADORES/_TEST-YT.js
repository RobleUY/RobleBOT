const fetch = require('node-fetch')
const { JSDOM } = require('jsdom')

const ytIdRegex =
  /(?:http(?:s|):\/\/|)(?:(?:www\.|)youtube(?:\-nocookie|)\.com\/(?:shorts\/)?(?:watch\?.*(?:|\&)v=|embed\/|v\/)|youtu\.be\/)([-_0-9A-Za-z]{11})/

function post(url, formdata) {
  return fetch(url, {
    method: 'POST',
    headers: {
      accept: '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
    },
    body: new URLSearchParams(Object.entries(formdata))
  })
}

async function yt(url, quality, type, bitrate, server = 'en68') {
  if (!ytIdRegex.test(url)) throw 'Link inválido'

  const ytId = ytIdRegex.exec(url)
  url = 'https://youtu.be/' + ytId[1]

  const res = await post(`https://www.y2mate.com/mates/${server}/analyze/ajax`, {
    url,
    q_auto: 0,
    ajax: 1
  })

  const json = await res.json()

  if (!json.result) throw 'Y2Mate no devolvió resultados'

  const { document } = new JSDOM(json.result).window

  const table = document.querySelectorAll('table')[1]

  const filesize =
    table.querySelector('td > a[href="#"]')
      .parentElement.nextSibling.nextSibling.innerHTML

  const id =
    /var k__id = "(.*?)"/.exec(document.body.innerHTML) || ['', '']

  const thumb = document.querySelector('img').src
  const title = document.querySelector('b').innerHTML

  const res2 = await post(`https://www.y2mate.com/mates/${server}/convert`, {
    type: 'youtube',
    _id: id[1],
    v_id: ytId[1],
    ajax: '1',
    token: '',
    ftype: type,
    fquality: bitrate
  })

  const json2 = await res2.json()

  const dl_link = /<a.+?href="(.+?)"/.exec(json2.result)?.[1]

  if (!dl_link) throw 'No se pudo obtener el link de descarga'

  return {
    dl_link,
    thumb,
    title,
    filesize
  }
}

let handler = async (m, { conn }) => {
  try {
    await m.reply('🧪 Probando descarga Rick Roll...')

    const data = await yt(
      'https://youtu.be/dQw4w9WgXcQ',
      '128kbps',
      'mp3',
      '128'
    )

    const audio = await fetch(data.dl_link)
    const buffer = await audio.buffer()

    await conn.sendMessage(
      m.chat,
      {
        audio: buffer,
        mimetype: 'audio/mpeg',
        fileName: `${data.title}.mp3`,
        ptt: false
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('❌ Error:\n' + e)
  }
}

handler.help = ['testyt']
handler.tags = ['test']
handler.command = ['testyt']

module.exports = handler