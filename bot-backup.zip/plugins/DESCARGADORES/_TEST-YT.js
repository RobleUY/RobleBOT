const fetch = (...args) =>
  import('node-fetch').then(({ default: fetch }) => fetch(...args))

const { JSDOM } = require('jsdom')

// ===============================
// CONFIG
// ===============================
const BASE = 'https://es1.y2mate.tube'
const SERVER = 'en68'

// ===============================
// REGEX YOUTUBE
// ===============================
const ytIdRegex =
  /(?:http(?:s|):\/\/|)(?:(?:www\.|)youtube(?:\-nocookie|)\.com\/(?:shorts\/)?(?:watch\?.*(?:|\&)v=|embed\/|v\/)|youtu\.be\/)([-_0-9A-Za-z]{11})/

// ===============================
// POST
// ===============================
function post(url, formdata) {
  return fetch(url, {
    method: 'POST',
    headers: {
      accept: '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      origin: BASE,
      referer: BASE + '/'
    },
    body: new URLSearchParams(Object.entries(formdata))
  })
}

// ===============================
// YTMP3
// ===============================
async function ytmp3(url) {

  if (!ytIdRegex.test(url)) {
    throw new Error('URL inválida')
  }

  const ytId = ytIdRegex.exec(url)[1]

  url = 'https://youtu.be/' + ytId

  // ===============================
  // ANALYZE
  // ===============================
  const analyze = await post(
    `${BASE}/mates/${SERVER}/analyze/ajax`,
    {
      url,
      q_auto: 0,
      ajax: 1
    }
  )

  const raw = await analyze.text()

console.log(raw)

throw new Error('Mira consola')

  if (!analyzeJson.result) {
    throw new Error('Y2Mate no devolvió resultado')
  }

  const { document } = new JSDOM(analyzeJson.result).window

  const title =
    document.querySelector('b')?.textContent || 'audio'

  const thumb =
    document.querySelector('img')?.src || null

  const id =
    /var k__id = "(.*?)"/.exec(document.body.innerHTML)?.[1]

  if (!id) {
    throw new Error('No se pudo obtener el ID')
  }

  // ===============================
  // CONVERT
  // ===============================
  const convert = await post(
    `${BASE}/mates/${SERVER}/convert`,
    {
      type: 'youtube',
      _id: id,
      v_id: ytId,
      ajax: '1',
      token: '',
      ftype: 'mp3',
      fquality: '128'
    }
  )

  const convertJson = await convert.json()

  const dl_link =
    /<a.+?href="(.+?)"/.exec(convertJson.result)?.[1]

  if (!dl_link) {
    throw new Error('No se pudo obtener link de descarga')
  }

  return {
    title,
    thumb,
    dl_link
  }
}

// ===============================
// HANDLER
// ===============================
let handler = async (message, { conn }) => {

  const sock = conn || message._sock || global.conn

  try {

    await message.reply('🧪 Probando Y2Mate...')

    const data = await ytmp3(
      'https://youtu.be/dQw4w9WgXcQ'
    )

    console.log('[TESTYT] Descargando:', data.title)

    // ===============================
    // DESCARGAR AUDIO
    // ===============================
    const audioRes = await fetch(data.dl_link)

    const buffer = Buffer.from(
      await audioRes.arrayBuffer()
    )

    // ===============================
    // ENVIAR THUMB
    // ===============================
    if (data.thumb) {
      await sock.sendMessage(
        message.from,
        {
          image: { url: data.thumb },
          caption:
            `🎵 *${data.title}*\n\n` +
            `🧪 Descargado usando Y2Mate`
        },
        { quoted: message._baileyMessage }
      )
    }

    // ===============================
    // ENVIAR AUDIO
    // ===============================
    await sock.sendMessage(
      message.from,
      {
        audio: buffer,
        mimetype: 'audio/mpeg',
        fileName: `${data.title}.mp3`,
        ptt: false
      },
      { quoted: message._baileyMessage }
    )

    console.log('[TESTYT] Audio enviado')

  } catch (err) {

    console.error('[TESTYT ERROR]', err)

    await message.reply(
      '❌ Error:\n\n' +
      (err.message || String(err))
    )
  }
}

// ===============================
// EXPORT
// ===============================
handler.help = ['testyt']
handler.tags = ['test']
handler.command = /^(testyt)$/i

module.exports = handler