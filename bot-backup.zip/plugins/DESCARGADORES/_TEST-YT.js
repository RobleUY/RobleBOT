const fs = require('fs');
const path = require('path');

let youtubedl = null;
try {
  youtubedl = require('youtube-dl-exec');
} catch (error) {
  console.warn('[TEST-YT] youtube-dl-exec no está instalado aún:', error.message);
}

const TEMP_DIR = path.join(process.cwd(), '.temp', 'test-yt');
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

function getYoutubeUrl(text = '') {
  if (!text || !text.trim()) return null;
  const match = text.match(/https?:\/\/[^\s]+/i) || text.match(/youtu\.be\/[^\s]+|youtube\.com\/[^\s]+/i);
  return match ? match[0].replace(/[),.;]+$/, '') : null;
}

async function downloadWithYoutubeDl(url, mode = 'video') {
  if (!youtubedl) {
    throw new Error('DEPENDENCIA_FALTANTE');
  }

  const baseName = `yt_test_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const outputTemplate = path.join(TEMP_DIR, `${baseName}.%(ext)s`);

  const options = {
    output: outputTemplate,
    noWarnings: true,
    noPlaylist: true,
    noCheckCertificate: true,
    noColor: true,
    quiet: true,
    format: mode === 'audio' ? 'bestaudio/best' : 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    mergeOutputFormat: mode === 'audio' ? 'mp3' : 'mp4',
    socketTimeout: 30,
    timeout: 60,
    youtubeSkipDashManifest: true
  };

  if (mode === 'audio') {
    options.extractAudio = true;
    options.audioFormat = 'mp3';
    options.audioQuality = 0;
  }

  await youtubedl(url, options);

  const files = fs.readdirSync(TEMP_DIR)
    .filter((file) => file.startsWith(baseName))
    .sort((a, b) => fs.statSync(path.join(TEMP_DIR, b)).mtimeMs - fs.statSync(path.join(TEMP_DIR, a)).mtimeMs);

  const preferredExt = mode === 'audio' ? /\.(mp3|m4a|aac|wav|webm)$/i : /\.(mp4|webm|mkv)$/i;
  const selected = files.find((file) => preferredExt.test(file)) || files[0];

  if (!selected) {
    throw new Error('No se generó ningún archivo descargado.');
  }

  const filePath = path.join(TEMP_DIR, selected);
  const stats = fs.statSync(filePath);
  if (!stats || stats.size < 20 * 1024) {
    throw new Error('El archivo generado está vacío o corrupto.');
  }

  return { filePath, fileName: selected };
}

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn;

  if (!text || !text.trim()) {
    return message.reply(
      `❌ Debes enviar el enlace del video de YouTube.

Ejemplo:
${usedPrefix}${command} https://youtu.be/xxxxxxxxxxx`
    );
  }

  const link = getYoutubeUrl(text);
  if (!link) {
    return message.reply('❌ El texto no parece un enlace válido de YouTube.');
  }

  if (!youtubedl) {
    return message.reply(
      '⚠️ La dependencia youtube-dl-exec aún no está instalada en este servidor.\n\n' +
      'Ejecuta: npm install --save youtube-dl-exec@^3.0.0\n' +
      'y luego reincia el bot.'
    );
  }

  const isAudio = String(command).toLowerCase() === 'testyta';
  const mode = isAudio ? 'audio' : 'video';

  try {
    await message.reply(`⏳ Descargando ${mode === 'audio' ? 'audio' : 'video'} con youtube-dl-exec...`);

    const { filePath, fileName } = await downloadWithYoutubeDl(link, mode);
    const buffer = fs.readFileSync(filePath);

    if (mode === 'audio') {
      await sock.sendMessage(
        message.from,
        {
          audio: buffer,
          mimetype: 'audio/mpeg',
          fileName,
          caption: '🎵 *Audio descargado por youtube-dl-exec*'
        },
        { quoted: message._baileyMessage }
      );
    } else {
      await sock.sendMessage(
        message.from,
        {
          video: buffer,
          mimetype: 'video/mp4',
          fileName,
          caption: '🎬 *Video descargado por youtube-dl-exec*'
        },
        { quoted: message._baileyMessage }
      );
    }

    console.log(`[TEST-YT] ✅ Archivo enviado: ${fileName}`);
  } catch (error) {
    console.error('[TEST-YT] Error:', error && error.message ? error.message : error);
    await message.reply(
      `❌ No se pudo descargar el archivo de YouTube con youtube-dl-exec.\n\n` +
      `*Motivo:* ${error && error.message ? error.message : 'desconocido'}`
    );
  }
};

handler.help = ['testyta <link>', 'testytv <link>'];
handler.tags = ['descargas'];
handler.command = /^(testyta|testytv)$/i;

module.exports = handler;
