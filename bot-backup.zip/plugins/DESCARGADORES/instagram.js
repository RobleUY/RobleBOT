const axios = require('axios')

const BUFFER_DOWNLOAD_TIMEOUT_MS = 25000
const GLOBAL_INSTAGRAM_TIMEOUT_MS = 60000

function withTimeout(promise, ms, timeoutMessage) {
  let timer
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage || `TIMEOUT_${ms}MS`)), ms)
  })
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer))
}

// Las URLs directas del CDN de Instagram necesitan estos headers o devuelven 403 / se cuelgan
function getInstagramCdnHeaders() {
  return {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Referer': 'https://www.instagram.com/',
    'Accept': '*/*',
    'Accept-Language': 'es-ES,es;q=0.9'
  }
}

function isInstagramCdn(url = '') {
  return /cdninstagram\.com|fbcdn\.net/i.test(url)
}

// Normaliza items de cualquier API:
// - Si todos son video → es un reel, devuelve solo el PRIMERO (los demás son la misma pieza en distintas calidades)
// - Si hay imágenes (carrusel) → devuelve todos
function normalizeItems(rawItems) {
  const items = rawItems
    .filter(i => i.url)
    .map(i => ({ type: i.type === 'image' ? 'image' : 'video', url: i.url }))
  if (!items.length) return []
  const allVideos = items.every(i => i.type === 'video')
  return allVideos ? [items[0]] : items
}

// --- Fuentes de metadata ---

async function getFromDeliriusV1IG(url) {
  console.log('[INSTAGRAM] Consultando DeliriusAPI v1...')
  const res = await axios.get(`https://api.delirius.online/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  // { status: true, data: [ { type, url } ] }
  if (!res.data?.status || !res.data?.data?.length) throw new Error('DELIRIUS_V1_FAIL')
  const items = normalizeItems(res.data.data)
  if (!items.length) throw new Error('DELIRIUS_V1_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ DeliriusAPI v1 entregó resultado')
  return { items, source: 'DeliriusAPI-v1' }
}

async function getFromDeliriusV2IG(url) {
  console.log('[INSTAGRAM] Consultando DeliriusAPI v2...')
  const res = await axios.get(`https://api.delirius.online/download/instagramv2?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  // { status: true, data: { download: [ { type, url } ] } }
  const download = res.data?.data?.download
  if (!res.data?.status || !Array.isArray(download) || !download.length) throw new Error('DELIRIUS_V2_FAIL')
  const items = normalizeItems(download)
  if (!items.length) throw new Error('DELIRIUS_V2_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ DeliriusAPI v2 entregó resultado')
  return { items, source: 'DeliriusAPI-v2' }
}

async function getFromRobleIG(url) {
  console.log('[INSTAGRAM] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.items?.length) throw new Error('ROBLE_FAIL')
  const items = normalizeItems(res.data.items.map(i => ({ type: i.type, url: i.download_url })))
  if (!items.length) throw new Error('ROBLE_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ RobleAPI entregó resultado')
  return { items, source: 'RobleAPI' }
}

async function getFromSankaIG(url) {
  console.log('[INSTAGRAM] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/instagram?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const result = res.data?.result
  if (!res.data?.status || !result) throw new Error('SANKA_FAIL')
  const urls = Array.isArray(result) ? result : [result.url || result.download || result]
  const raw = urls.filter(Boolean).map(u => ({
    type: String(u).includes('.mp4') ? 'video' : 'image',
    url: typeof u === 'string' ? u : (u.url || u.download)
  }))
  const items = normalizeItems(raw)
  if (!items.length) throw new Error('SANKA_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ SankaAPI entregó resultado')
  return { items, source: 'SankaAPI' }
}

// --- Carrera de fuentes: todas a la vez, gana la primera en responder Y descargar ---

async function getWorkingInstagram(instagramUrl) {
  const sources = [
    { name: 'DeliriusAPI-v1', fn: getFromDeliriusV1IG },
    { name: 'DeliriusAPI-v2', fn: getFromDeliriusV2IG },
    { name: 'RobleAPI',       fn: getFromRobleIG },
    { name: 'SankaAPI',       fn: getFromSankaIG }
  ]

  // Lanzar todas las fuentes a la vez
  const wrapped = sources.map((s, idx) =>
    s.fn(instagramUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[INSTAGRAM] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[INSTAGRAM] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          // CDN directo de Instagram requiere headers especiales para no dar 403 ni colgarse
          const headers = isInstagramCdn(item.url) ? getInstagramCdnHeaders() : {}
          const contentResponse = await withTimeout(
            axios.get(item.url, { responseType: 'arraybuffer', timeout: BUFFER_DOWNLOAD_TIMEOUT_MS, headers }),
            BUFFER_DOWNLOAD_TIMEOUT_MS,
            'BUFFER_DOWNLOAD_TIMEOUT'
          )
          buffer = Buffer.from(contentResponse.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[INSTAGRAM] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, source: sourceName }
    } catch (downloadError) {
      console.log(`[INSTAGRAM] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Instagram fallaron. Detalles: ' + errors.join(' | '))
}

// --- Handler /instagram ---

let handlerInstagram = async (message, { conn }) => {
  try {
    const args = (message.body || '').trim().split(/\s+/).slice(1)

    if (!args[0]) {
      return await message.reply('🔎 *Uso correcto:*\n/instagram <enlace>\n\nEjemplo: /instagram https://www.instagram.com/p/C6goPSpyytx/')
    }

    await message.reply('⏳ Descargando Instagram...')

    const { items, source } = await withTimeout(
      getWorkingInstagram(args[0]),
      GLOBAL_INSTAGRAM_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    console.log(`[INSTAGRAM] 🚀 Enviando ${items.length} elemento(s) a WhatsApp vía ${source}...`)

    for (const item of items) {
      if (item.type === 'image') {
        await conn.sendMessage(message.from, { image: item.buffer }, { quoted: message._baileyMessage })
      } else if (item.type === 'video') {
        await conn.sendMessage(message.from, { video: item.buffer }, { quoted: message._baileyMessage })
      }
    }

    console.log('[INSTAGRAM] ✅ Elemento(s) de Instagram enviado(s) a WhatsApp exitosamente')

  } catch (error) {
    console.error('[INSTAGRAM ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.')
  }
}

handlerInstagram.help = ['instagram']
handlerInstagram.tags = ['download']
handlerInstagram.command = /^(instagram|ig|igdl)$/i

// --- Handler /igreel <url o búsqueda> ---

let handlerIgReel = async (message, { conn }) => {
  try {
    const text = (message.body || '').trim().split(/\s+/).slice(1).join(' ').trim()

    if (!text) {
      return await message.reply('🎬 *Uso correcto:*\n/igreel <enlace o búsqueda>\n\nEjemplos:\n/igreel https://www.instagram.com/reel/...\n/igreel drift cars')
    }

    const esEnlace = /instagram\.com\/(reel|p|tv)\//i.test(text)
    let reelUrl = null

    if (esEnlace) {
      reelUrl = text
      await message.reply('⏳ Descargando reel...')
    } else {
      await message.reply(`🔍 Buscando reels sobre *${text}*...`)
      const searchRes = await axios.get(
        `https://api.delirius.online/search/instagramreels?query=${encodeURIComponent(text)}&language=es`,
        { timeout: 15000 }
      )
      const resultados = searchRes.data?.data
      if (!Array.isArray(resultados) || !resultados.length) {
        return await message.reply('❌ No se encontraron reels para esa búsqueda. Intenta con otro término.')
      }
      reelUrl = resultados[Math.floor(Math.random() * resultados.length)].url
      console.log(`[IGREEL] Reel encontrado: ${reelUrl}`)
    }

    // Usa el mismo sistema multi-fuente
    const { items } = await withTimeout(
      getWorkingInstagram(reelUrl),
      GLOBAL_INSTAGRAM_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    const videoItem = items.find(i => i.type === 'video') || items[0]
    if (!videoItem) return await message.reply('❌ No se pudo descargar el reel. Intenta con otro enlace o búsqueda.')

    await conn.sendMessage(message.from, {
      video: videoItem.buffer,
      caption: '🎬',
      gifPlayback: false
    }, { quoted: message._baileyMessage })

    console.log('[IGREEL] ✅ Reel enviado correctamente')

  } catch (error) {
    console.error('[IGREEL ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    return await message.reply('❌ Ocurrió un error al procesar el reel. Intenta nuevamente.')
  }
}

handlerIgReel.help = ['igreel <enlace o búsqueda>']
handlerIgReel.tags = ['download', 'instagram']
handlerIgReel.command = /^igreel$/i

module.exports.instagram = handlerInstagram
module.exports.igreel = handlerIgReel
