const axios = require('axios');

let handlerInstagram = async (message, { conn }) => {
    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);
        
        if (args.length === 0) {
            return await message.reply('📎 *Uso correcto:*\n/instagram <enlace>\n\nEjemplo: /instagram https://www.instagram.com/p/C6goPSpyytx/');
        }

        const instagramUrl = args[0];
        const apiUrl = `https://www.robleuy.site/robleapi/download/instagram?url=${encodeURIComponent(instagramUrl)}`;

        await message.reply('⏳ Descargando...');

        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;

        if (data.ok && data.items?.length > 0) {
            for (const item of data.items) {
                const contentResponse = await axios.get(item.download_url, { responseType: 'arraybuffer', timeout: 60000 });
                const buffer = Buffer.from(contentResponse.data)

                if (item.type === 'image') {
                    await sock.sendMessage(message.from, { image: buffer }, { quoted: message._baileyMessage });
                } else if (item.type === 'video') {
                    await sock.sendMessage(message.from, { video: buffer }, { quoted: message._baileyMessage });
                }
            }
        } else {
            await message.reply('❌ No se pudo obtener el contenido. Verifica el enlace.')
        }
    } catch (error) {
        console.error('Error en el comando instagram:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.');
    }
};

handlerInstagram.help = ['instagram'];
handlerInstagram.tags = ['download'];
handlerInstagram.command = /^(instagram)$/i;

module.exports.instagram = handlerInstagram;
