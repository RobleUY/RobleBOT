const axios = require('axios');

let handlerInstagram = async (message, { conn }) => {
    try {
        const text = message.body;
        const args = text.trim().split(' ').slice(1);
        
        if (args.length === 0) {
            return await message.reply('📎 *Uso correcto:*\n/instagram <enlace>\n\nEjemplo: /instagram https://www.instagram.com/p/C6goPSpyytx/');
        }

        const instagramUrl = args[0];
        const apiUrl = `https://delirius-apiofc.vercel.app/download/instagram?url=${encodeURIComponent(instagramUrl)}`;

        // 🟢 MENSAJE INICIAL DE DESCARGA
        await message.reply('⏳ *Descargando el contenido...*\nPor favor, ten paciencia, puede tardar unos segundos si el archivo es pesado.');

        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status && data.data && data.data.length > 0) {
            const firstItem = data.data[0];
            const contentType = firstItem.type;
            const contentUrl = firstItem.url;

            const contentResponse = await axios.get(contentUrl, { responseType: 'arraybuffer' });
            const contentBuffer = Buffer.from(contentResponse.data, 'binary');

            // Enviar como respuesta al mensaje del comando (quoted)
            if (contentType === 'image') {
                await conn.sendMessage(message.from, {
                    image: contentBuffer,
                    caption: '✅ *Aquí tienes tu imagen de Instagram descargada correctamente.* 🖼️'
                }, { quoted: message._baileyMessage });
            } else if (contentType === 'video') {
                await conn.sendMessage(message.from, {
                    video: contentBuffer,
                    caption: '✅ *Aquí tienes tu video de Instagram descargado correctamente.* 🎬'
                }, { quoted: message._baileyMessage });
            } else {
                await message.reply('❌ El tipo de contenido no es compatible. Solo se admiten imágenes o videos.');
            }
        } else {
            await message.reply('❌ No se pudo obtener el contenido de la publicación. Verifica el enlace e intenta de nuevo.');
        }
    } catch (error) {
        console.error('Error en el comando instagram:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.');
    }
};

handlerInstagram.help = ['instagram'];
handlerInstagram.tags = ['download'];
handlerInstagram.command = /^(instagram)$/i;

module.exports.instagram = handlerInstagram;