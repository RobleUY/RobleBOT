const axios = require('axios')

let alldlFunc = null
try {
  const ytdl = require('@hiudyy/ytdl')
  alldlFunc = ytdl.alldl || ytdl.default?.alldl
} catch (e) {
  console.warn('[INSTAGRAM] @hiudyy/ytdl alldl no disponible:', e.message)
}

async function getFromHiudyyIG(url) {
  if (!alldlFunc) throw new Error('HIUDYY_NOT_AVAILABLE')
  console.log('[INSTAGRAM] Consultando Hiudyy-YTDL...')
  const res = await alldlFunc(url)
  const items = Array.isArray(res) ? res : [res]
  const validItems = items
    .map(i => ({
      type: i?.type === 'image' ? 'image' : 'video',
      url: i?.src || i?.url || (typeof i === 'string' ? i : null)
    }))
    .filter(i => i.url)
  if (!validItems.length) throw new Error('HIUDYY_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ Hiudyy-YTDL entregó resultado')
  return { items: validItems, source: 'Hiudyy-YTDL' }
}

async function getFromRobleIG(url) {
  console.log('[INSTAGRAM] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.items?.length) throw new Error('ROBLE_FAIL')
  const items = res.data.items.map(item => ({
    type: item.type === 'image' ? 'image' : 'video',
    url: item.download_url
  }))
  console.log('[INSTAGRAM] ✅ RobleAPI entregó resultado')
  return { items, source: 'RobleAPI' }
}

async function getFromSankaIG(url) {
  console.log('[INSTAGRAM] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/instagram?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const result = res.data?.result
  if (!res.data?.status || !result) throw new Error('SANKA_FAIL')
  const urls = Array.isArray(result) ? result : [result.url || result.download || result]
  const items = urls.filter(Boolean).map(u => ({
    type: String(u).includes('.mp4') ? 'video' : 'image',
    url: typeof u === 'string' ? u : u.url || u.download
  }))
  if (!items.length) throw new Error('SANKA_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ SankaAPI entregó resultado')
  return { items, source: 'SankaAPI' }
}

async function getFromDeliriusIG(url) {
  console.log('[INSTAGRAM] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.status || !res.data?.data?.length) throw new Error('DELIRIUS_FAIL')
  const items = res.data.data.map(item => ({
    type: item.type === 'image' ? 'image' : 'video',
    url: item.url
  }))
  console.log('[INSTAGRAM] ✅ DeliriusAPI entregó resultado')
  return { items, source: 'DeliriusAPI' }
}

async function getWorkingInstagram(instagramUrl) {
  const sources = [
    { name: 'Hiudyy-YTDL', fn: getFromHiudyyIG },
    { name: 'RobleAPI', fn: getFromRobleIG },
    { name: 'SankaAPI', fn: getFromSankaIG },
    { name: 'DeliriusAPI', fn: getFromDeliriusIG }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(instagramUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[INSTAGRAM] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[INSTAGRAM] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          const contentResponse = await axios.get(item.url, { responseType: 'arraybuffer', timeout: 60000 })
          buffer = Buffer.from(contentResponse.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[INSTAGRAM] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, source: sourceName }
    } catch (downloadError) {
      console.log(`[INSTAGRAM] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Instagram fallaron.')
}

let handlerInstagram = async (message, { conn }) => {
  const sock = conn || message._sock || global.conn
  try {
    const text = message.body || ''
    const args = text.trim().split(' ').slice(1)

    if (args.length === 0) {
      return await message.reply('🔎 *Uso correcto:*\n/instagram <enlace>\n\nEjemplo: /instagram https://www.instagram.com/p/C6goPSpyytx/')
    }

    const instagramUrl = args[0]
    await message.reply('⏳ Descargando Instagram...')

    const { items, source } = await getWorkingInstagram(instagramUrl)

    console.log(`[INSTAGRAM] 🚀 Enviando ${items.length} elemento(s) a WhatsApp vía ${source}...`)

    for (const item of items) {
      if (item.type === 'image') {
        await sock.sendMessage(message.from, { image: item.buffer }, { quoted: message._baileyMessage })
      } else if (item.type === 'video') {
        await sock.sendMessage(message.from, { video: item.buffer }, { quoted: message._baileyMessage })
      }
    }

    console.log(`[INSTAGRAM] ✅ Elemento(s) de Instagram enviado(s) a WhatsApp exitosamente`)

  } catch (error) {
    console.error('[INSTAGRAM ERROR]', error.message || error)
    return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.')
  }
}

handlerInstagram.help = ['instagram']
handlerInstagram.tags = ['download']
handlerInstagram.command = /^(instagram|ig|igdl)$/i

// ============================================================
// HANDLER: .igreel <url o búsqueda>
// Si recibe un enlace de Instagram → descarga directo
// Si recibe texto → busca reels con Delirius y descarga el primero
// ============================================================
let handlerIgReel = async (message, { conn }) => {
  const sock = conn || message._sock || global.conn
  try {
    const text = (message.body || '').trim().split(' ').slice(1).join(' ').trim()

    if (!text) {
      return await message.reply('🎬 *Uso correcto:*\n.igreel <enlace o búsqueda>\n\nEjemplos:\n.igreel https://www.instagram.com/reel/...\n.igreel drift cars')
    }

    const esEnlace = /instagram\.com\/(reel|p|tv)\//i.test(text)

    let reelUrl = null

    if (esEnlace) {
      reelUrl = text
      await message.reply('⏳ Descargando reel...')
    } else {
      // Buscar reels con Delirius
      await message.reply(`🔍 Buscando reels sobre *${text}*...`)
      try {
        const searchRes = await axios.get(`https://api.delirius.online/search/instagramreels?query=${encodeURIComponent(text)}&language=es`, { timeout: 15000 })
        const resultados = searchRes.data?.data
        if (!Array.isArray(resultados) || resultados.length === 0) {
          return await message.reply('❌ No se encontraron reels para esa búsqueda. Intenta con otro término.')
        }
        // Elegir uno aleatorio de los resultados
        const elegido = resultados[Math.floor(Math.random() * resultados.length)]
        reelUrl = elegido.url
        console.log(`[IGREEL] Reel encontrado: ${reelUrl}`)
      } catch (e) {
        console.error('[IGREEL] Error búsqueda:', e.message)
        return await message.reply('❌ No se pudo buscar reels. Intenta de nuevo más tarde.')
      }
    }

    // Descargar el reel con la API de Delirius
    let videoBuffer = null
    try {
      const dlRes = await axios.get(`https://api.delirius.online/download/instagram?url=${encodeURIComponent(reelUrl)}`, { timeout: 30000 })
      const items = dlRes.data?.data
      if (!Array.isArray(items) || items.length === 0) throw new Error('Sin items')
      // Tomar el primer item de tipo video (o el primero disponible)
      const videoItem = items.find(i => i.type === 'video') || items[0]
      if (!videoItem?.url) throw new Error('Sin URL de video')

      const vidRes = await axios.get(videoItem.url, { responseType: 'arraybuffer', timeout: 60000 })
      videoBuffer = Buffer.from(vidRes.data)
    } catch (e) {
      console.error('[IGREEL] Error descarga Delirius:', e.message)
      // Fallback: intentar con las otras fuentes del handler de Instagram
      try {
        const { items } = await getWorkingInstagram(reelUrl)
        const videoItem = items.find(i => i.type === 'video') || items[0]
        if (videoItem) videoBuffer = videoItem.buffer
      } catch (e2) {
        console.error('[IGREEL] Fallback también falló:', e2.message)
      }
    }

    if (!videoBuffer) {
      return await message.reply('❌ No se pudo descargar el reel. Intenta con otro enlace o búsqueda.')
    }

    await sock.sendMessage(message.from, {
      video: videoBuffer,
      caption: '🎬',
      gifPlayback: false
    }, { quoted: message._baileyMessage })

    console.log('[IGREEL] ✅ Reel enviado correctamente')

  } catch (error) {
    console.error('[IGREEL ERROR]', error.message || error)
    return await message.reply('❌ Ocurrió un error al procesar el reel. Intenta nuevamente.')
  }
}

handlerIgReel.help = ['igreel <enlace o búsqueda>']
handlerIgReel.tags = ['download', 'instagram']
handlerIgReel.command = /^igreel$/i

module.exports.instagram = handlerInstagram
module.exports.igreel = handlerIgReel