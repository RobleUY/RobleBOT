const axios = require('axios')

let alldlFunc = null
try {
  const ytdl = require('@hiudyy/ytdl')
  alldlFunc = ytdl.alldl || ytdl.default?.alldl
} catch (e) {
  console.warn('[INSTAGRAM] @hiudyy/ytdl alldl no disponible:', e.message)
}

async function getFromHiudyyIG(url) {
  if (!alldlFunc) throw new Error('HIUDYY_NOT_AVAILABLE')
  console.log('[INSTAGRAM] Consultando Hiudyy-YTDL...')
  const res = await alldlFunc(url)
  const items = Array.isArray(res) ? res : [res]
  const validItems = items
    .map(i => ({
      type: i?.type === 'image' ? 'image' : 'video',
      url: i?.src || i?.url || (typeof i === 'string' ? i : null)
    }))
    .filter(i => i.url)
  if (!validItems.length) throw new Error('HIUDYY_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ Hiudyy-YTDL entregó resultado')
  return { items: validItems, source: 'Hiudyy-YTDL' }
}

async function getFromRobleIG(url) {
  console.log('[INSTAGRAM] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok || !res.data?.items?.length) throw new Error('ROBLE_FAIL')
  const items = res.data.items.map(item => ({
    type: item.type === 'image' ? 'image' : 'video',
    url: item.download_url
  }))
  console.log('[INSTAGRAM] ✅ RobleAPI entregó resultado')
  return { items, source: 'RobleAPI' }
}

async function getFromSankaIG(url) {
  console.log('[INSTAGRAM] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/instagram?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const result = res.data?.result
  if (!res.data?.status || !result) throw new Error('SANKA_FAIL')
  const urls = Array.isArray(result) ? result : [result.url || result.download || result]
  const items = urls.filter(Boolean).map(u => ({
    type: String(u).includes('.mp4') ? 'video' : 'image',
    url: typeof u === 'string' ? u : u.url || u.download
  }))
  if (!items.length) throw new Error('SANKA_NO_ITEMS')
  console.log('[INSTAGRAM] ✅ SankaAPI entregó resultado')
  return { items, source: 'SankaAPI' }
}

async function getFromDeliriusIG(url) {
  console.log('[INSTAGRAM] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.store/download/instagram?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.status || !res.data?.data?.length) throw new Error('DELIRIUS_FAIL')
  const items = res.data.data.map(item => ({
    type: item.type === 'image' ? 'image' : 'video',
    url: item.url
  }))
  console.log('[INSTAGRAM] ✅ DeliriusAPI entregó resultado')
  return { items, source: 'DeliriusAPI' }
}

async function getWorkingInstagram(instagramUrl) {
  const sources = [
    { name: 'Hiudyy-YTDL', fn: getFromHiudyyIG },
    { name: 'RobleAPI', fn: getFromRobleIG },
    { name: 'SankaAPI', fn: getFromSankaIG },
    { name: 'DeliriusAPI', fn: getFromDeliriusIG }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(instagramUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[INSTAGRAM] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[INSTAGRAM] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          const contentResponse = await axios.get(item.url, { responseType: 'arraybuffer', timeout: 60000 })
          buffer = Buffer.from(contentResponse.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[INSTAGRAM] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, source: sourceName }
    } catch (downloadError) {
      console.log(`[INSTAGRAM] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Instagram fallaron.')
}

let handlerInstagram = async (message, { conn }) => {
  const sock = conn || message._sock || global.conn
  try {
    const text = message.body || ''
    const args = text.trim().split(' ').slice(1)

    if (args.length === 0) {
      return await message.reply('🔎 *Uso correcto:*\n/instagram <enlace>\n\nEjemplo: /instagram https://www.instagram.com/p/C6goPSpyytx/')
    }

    const instagramUrl = args[0]
    await message.reply('⏳ Descargando Instagram...')

    const { items, source } = await getWorkingInstagram(instagramUrl)

    console.log(`[INSTAGRAM] 🚀 Enviando ${items.length} elemento(s) a WhatsApp vía ${source}...`)

    for (const item of items) {
      if (item.type === 'image') {
        await sock.sendMessage(message.from, { image: item.buffer }, { quoted: message._baileyMessage })
      } else if (item.type === 'video') {
        await sock.sendMessage(message.from, { video: item.buffer }, { quoted: message._baileyMessage })
      }
    }

    console.log(`[INSTAGRAM] ✅ Elemento(s) de Instagram enviado(s) a WhatsApp exitosamente`)

  } catch (error) {
    console.error('[INSTAGRAM ERROR]', error.message || error)
    return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta nuevamente más tarde.')
  }
}

handlerInstagram.help = ['instagram']
handlerInstagram.tags = ['download']
handlerInstagram.command = /^(instagram|ig|igdl)$/i

module.exports.instagram = handlerInstagram