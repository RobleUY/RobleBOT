const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yts = require('yt-search');

// ===============================
// CONFIGURACIÓN
// ===============================
const COMANDO_ACTIVADO = true; // cambia a false si querés desactivarlo
const LIMIT_MB = 300; // límite máximo permitido en MB
const DOCUMENT_THRESHOLD_MB = 100; // umbral para enviar como documento
const TIMEOUT_MS = 60000; // tiempo máximo de descarga
const DESCARGAS_DIR = path.join(__dirname, 'descargas');
const COOLDOWN_MS = 30 * 1000; // 30 segundos

// Usuarios sin cooldown
const NO_COOLDOWN_USERS = [
    '59893900470@s.whatsapp.net',
    '149078365237384@lid',
    '59892099606@s.whatsapp.net',
    '106502773850321@lid'
];

// Aumenta el límite de listeners para evitar el warning
require('events').EventEmitter.defaultMaxListeners = 50;

// Crear carpeta si no existe
if (!fs.existsSync(DESCARGAS_DIR)) fs.mkdirSync(DESCARGAS_DIR, { recursive: true });

// ===============================
// SISTEMAS DE CONTROL
// ===============================
const cooldowns = new Map(); // Map para cooldowns (user -> timestamp)
const enDescarga = new Set(); // Set para usuarios con descarga activa

// ===============================
// FUNCIÓN PARA CONVERTIR SEGUNDOS A FORMATO LEGIBLE
// ===============================
function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) {
        return 'Desconocido';
    }

    const numSeconds = parseInt(seconds);

    if (numSeconds < 60) {
        return `${numSeconds}s`;
    }

    const hours = Math.floor(numSeconds / 3600);
    const minutes = Math.floor((numSeconds % 3600) / 60);
    const secs = numSeconds % 60;

    if (hours > 0) {
        return `${hours}h ${minutes}m ${secs}s`;
    } else {
        if (secs > 0) {
            return `${minutes}m ${secs}s`;
        } else {
            return `${minutes}m`;
        }
    }
}

// ===============================
// FUNCIÓN PARA ESTIMAR TIEMPO DE ENVÍO
// ===============================
function estimateUploadTime(sizeMB) {
    const uploadSpeedMBPerSecond = 3.17;
    const estimatedSeconds = Math.ceil(sizeMB / uploadSpeedMBPerSecond);

    if (estimatedSeconds < 30) {
        return 'unos pocos segundos';
    } else if (estimatedSeconds < 60) {
        return `aproximadamente ${estimatedSeconds} segundos`;
    } else {
        const minutes = Math.ceil(estimatedSeconds / 60);
        if (minutes === 1) {
            return 'aproximadamente 1 minuto';
        } else {
            return `aproximadamente ${minutes} minutos`;
        }
    }
}

// ===============================
// FUNCIÓN PARA OBTENER VIDEO DE DELIRIUS API
// ===============================
async function getFromDelirius(youtubeUrl) {
    const endpoint = `https://delirius-apiofc.vercel.app/download/ytmp4?url=${encodeURIComponent(youtubeUrl)}`;
    
    try {
        const res = await axios.get(endpoint, { timeout: TIMEOUT_MS });
        
        if (!res.data?.status) {
            throw new Error('Error al obtener datos de la API');
        }

        const { data } = res.data;
        
        if (!data || !data.download || !data.download.url) {
            throw new Error('No se encontró el link de descarga');
        }

        return {
            download: data.download.url,
            title: data.title || 'Video sin título',
            thumbnail: data.image || data.image_max_resolution || null,
            duration: data.duration || null,
            author: data.author || 'Desconocido',
            views: data.views || '0',
            likes: data.likes || '0',
            quality: data.download.quality || 'Desconocida',
            estimatedSize: data.download.size || 'Desconocido'
        };
    } catch (error) {
        console.error('[DELIRIUS API] Error:', error?.message || error);
        throw new Error('No se pudo obtener el video de la API');
    }
}

// ===============================
// FUNCIÓN PARA BUSCAR EN YOUTUBE
// ===============================
async function searchYouTube(query) {
    const result = await yts(query);
    if (!result?.videos?.length) throw new Error('No se encontraron resultados');
    return result.videos[0].url;
}

// ===============================
// HANDLER PRINCIPAL
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO)
        return await message.reply('⚠️ *Este comando está temporalmente deshabilitado.*');

    if (!text)
        return await message.reply(
            `❌ Debes enviar un enlace o título de YouTube.\n\nEjemplo:\n` +
            `• ${usedPrefix + command} https://youtu.be/TdrL3QxjyVw\n` +
            `• ${usedPrefix + command} Lana Del Rey Summertime Sadness`
        );

    const sender = message?.sender || message?.key?.participant || message?.from;
    const now = Date.now();

    // ⛔ Bloquear si el usuario ya tiene una descarga activa
    if (enDescarga.has(sender)) {
        return await message.reply('⚠️ Ya tienes una descarga en curso. Espera a que termine antes de pedir otro video.');
    }

    // 🕒 Revisar cooldown (excepto usuarios sin cooldown)
    if (!NO_COOLDOWN_USERS.includes(sender)) {
        const lastUse = cooldowns.get(sender);
        if (lastUse && now - lastUse < COOLDOWN_MS) {
            const restante = Math.ceil((COOLDOWN_MS - (now - lastUse)) / 1000);
            return await message.reply(`⏳ Espera ${restante} segundos antes de volver a usar este comando.`);
        }
    }

    enDescarga.add(sender); // Marcar que el usuario está descargando

    try {
        // Mensaje inicial de búsqueda
        await message.reply('🔍 Buscando video, por favor espere...');

        let youtubeUrl = text;
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            youtubeUrl = await searchYouTube(text);
        }

        const videoData = await getFromDelirius(youtubeUrl);
        console.log('[VIDEOYT] Datos obtenidos correctamente:', { title: videoData.title });

        const safeName = videoData.title.replace(/[\\/:*?"<>|]/g, '').slice(0, 60) + '.mp4';
        const filePath = path.join(DESCARGAS_DIR, safeName);

        // Iniciar la descarga del video
        console.log('[VIDEOYT] Iniciando descarga desde:', videoData.download);
        
        const response = await axios({
            url: videoData.download,
            method: 'GET',
            responseType: 'stream',
            timeout: 120000,
            maxRedirects: 5, // Seguir redirecciones
            validateStatus: (status) => status >= 200 && status < 400
        });

        // Obtener tamaño del header de la respuesta
        const contentLength = response.headers['content-length'];
        const estimatedSizeMB = contentLength 
            ? (contentLength / (1024 * 1024)).toFixed(2) 
            : videoData.estimatedSize;
        
        // Calcular tiempo estimado
        const estimatedTime = typeof estimatedSizeMB === 'number' || !isNaN(parseFloat(estimatedSizeMB))
            ? estimateUploadTime(parseFloat(estimatedSizeMB))
            : 'variable según el tamaño';

        // Mostrar miniatura con toda la información
        if (videoData.thumbnail) {
            const durationFormatted = videoData.duration ? formatDuration(videoData.duration) : 'Desconocida';
            
            await conn.sendMessage(message.from, {
                image: { url: videoData.thumbnail },
                caption: 
                    `📹 *Información del Video*\n\n` +
                    `📌 *Título:* ${videoData.title}\n` +
                    `👤 *Canal:* ${videoData.author}\n` +
                    `⏱️ *Duración:* ${durationFormatted}\n` +
                    `👁️ *Vistas:* ${parseInt(videoData.views).toLocaleString()}\n` +
                    `👍 *Likes:* ${parseInt(videoData.likes).toLocaleString()}\n` +
                    `📦 *Tamaño:* ${estimatedSizeMB} MB\n` +
                    `🎬 *Calidad:* ${videoData.quality}\n` +
                    `🔗 *Link:* ${youtubeUrl}\n\n` +
                    `⏳ *Tiempo estimado de envío:* ${estimatedTime}\n\n` +
                    `🔄 Descargando y enviando...\n\n` +
                    `_La demora varía según el tamaño del archivo. Videos más pesados tardan más en enviarse._`
            }, { quoted: message._baileyMessage });
        }

        const writer = fs.createWriteStream(filePath);
        let size = 0;
        response.data.on('data', chunk => size += chunk.length);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        const sizeMB = (size / (1024 * 1024)).toFixed(2);
        console.log(`[VIDEOYT] Tamaño descargado: ${sizeMB} MB`);

        if (sizeMB > LIMIT_MB) {
            await message.reply(`⚠️ El video pesa ${sizeMB} MB, supera el límite de ${LIMIT_MB} MB.`);
            fs.unlinkSync(filePath);
            enDescarga.delete(sender);
            return;
        }

        // 📤 Enviar como video normal o como documento según el tamaño
        if (sizeMB >= DOCUMENT_THRESHOLD_MB) {
            // Enviar como documento si pesa 100 MB o más
            await conn.sendMessage(
                message.from,
                {
                    document: { url: filePath },
                    mimetype: 'video/mp4',
                    fileName: `${videoData.title}.mp4`,
                    caption: `🎬 *${videoData.title}*\n👤 Canal: ${videoData.author}\n📦 Tamaño: ${sizeMB} MB`
                },
                { quoted: message._baileyMessage }
            );
            console.log('[VIDEOYT] Video enviado como documento');
        } else {
            // Enviar como video normal si pesa menos de 100 MB
            await conn.sendMessage(
                message.from,
                {
                    video: { url: filePath },
                    mimetype: 'video/mp4',
                    caption: `🎬 *${videoData.title}*\n👤 Canal: ${videoData.author}\n📦 Tamaño: ${sizeMB} MB`
                },
                { quoted: message._baileyMessage }
            );
            console.log('[VIDEOYT] Video enviado como archivo de video');
        }

        // ✅ Cooldown empieza recién ahora (excepto usuarios sin cooldown)
        if (!NO_COOLDOWN_USERS.includes(sender)) {
            cooldowns.set(sender, Date.now());
        }

        // 🧹 Limpiar archivo y liberar descarga
        await fs.promises.unlink(filePath).catch(() => { });
        console.log('[LIMPIEZA] Archivo eliminado:', filePath);

    } catch (e) {
        console.error('[VIDEOYT] Error general:', e?.message || e);
        await message.reply(
            `❌ Ocurrió un error al descargar el video.\n\n` +
            `*Error:* ${e?.message || 'Desconocido'}\n\n` +
            `Intentalo de nuevo.\n` +
            `• Si sigue fallando solo espera unos minutos.\n` +
            `*Estos errores suelen solucionarse solos.*`
        );
    } finally {
        // Siempre liberar el bloqueo aunque haya error
        enDescarga.delete(sender);
    }
};

// ===============================
// EXPORTAR HANDLER
// ===============================
handler.help = ['testyt <link o título>'];
handler.tags = ['video', 'youtube', 'downloader'];
handler.command = /^(testyt)$/i;

module.exports = handler;