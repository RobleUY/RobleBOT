const axios = require('axios');

// ─── Google Custom Search ───────────────────────────────────────────────────
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];
const GOOGLE_CX = '635e6b14f7cf84f2c';

// ─── Términos de búsqueda ───────────────────────────────────────────────────
const THERIANS_TERMS = [
    'therians photo',
    'juntada de therians',
    'therians imagenes HD',
    'therians fotos',
    'therian community',
    'therian aesthetic',
    'therian wolf',
    'therian fox',
    'therian art'
];

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': 'https://www.google.com/',
    'Connection': 'keep-alive'
};

// ─── Fuente 1: Google Custom Search ────────────────────────────────────────
async function buscarEnGoogle(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];
    if (keyIndex >= GOOGLE_API_KEYS.length) return [];

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=active`;

    try {
        const response = await axios.get(url, { timeout: 10000 });
        if (response.data.items?.length > 0) {
            return response.data.items
                .filter(item => item.link && item.mime?.startsWith('image/'))
                .map(item => item.link);
        }
    } catch (error) {
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`⚠️ [Therians] Clave Google agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarEnGoogle(termsArray, keyIndex + 1, retries - 1);
        }
        console.warn(`⚠️ [Therians] Google falló: ${error.message}`);
    }
    return [];
}

// ─── Fuente 2: Pinterest (robleuy.site) ────────────────────────────────────
async function buscarEnPinterest(termsArray) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];
    try {
        const response = await axios.get('https://www.robleuy.site/robleapi/buscador/pinterest', {
            params: { q: randomTerm },
            timeout: 10000
        });
        if (response.data?.ok && response.data.images?.length > 0) {
            return response.data.images.map(img => img.large || img.small).filter(Boolean);
        }
    } catch (error) {
        console.warn(`⚠️ [Therians] Pinterest falló: ${error.message}`);
    }
    return [];
}

// ─── Fuente 3: Bing Images (robleuy.site) ──────────────────────────────────
async function buscarEnBing(termsArray) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];
    try {
        const response = await axios.get('https://www.robleuy.site/robleapi/buscador/bingimages', {
            params: { q: randomTerm },
            timeout: 10000
        });
        if (response.data?.ok && response.data.images?.length > 0) {
            return response.data.images.map(img => img.direct || img.thumbnail).filter(Boolean);
        }
    } catch (error) {
        console.warn(`⚠️ [Therians] Bing falló: ${error.message}`);
    }
    return [];
}

// ─── Descargador con validación ────────────────────────────────────────────
async function descargarImagen(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 12000,
            headers: BROWSER_HEADERS
        });
        const contentType = response.headers['content-type'] || '';
        if (!contentType.startsWith('image/')) {
            console.warn(`⚠️ URL no devolvió imagen: ${contentType}`);
            return null;
        }
        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.warn(`⚠️ No se pudo descargar imagen (${error.response?.status || error.message}): ${url}`);
        return null;
    }
}

// ─── Buscar en todas las fuentes con fallback ──────────────────────────────
async function buscarImagenes() {
    let urls = await buscarEnGoogle(THERIANS_TERMS);
    if (!urls.length) {
        console.log('🔄 [Therians] Google sin resultados, probando Pinterest...');
        urls = await buscarEnPinterest(THERIANS_TERMS);
    }
    if (!urls.length) {
        console.log('🔄 [Therians] Pinterest sin resultados, probando Bing...');
        urls = await buscarEnBing(THERIANS_TERMS);
    }
    return urls;
}

// ─── Handler principal ─────────────────────────────────────────────────────
let handlerTherians = async (message, { conn }) => {
    try {
        const imageUrls = await buscarImagenes();

        if (!imageUrls.length) {
            return message.reply('❌ No se encontraron imágenes de therians. Intenta de nuevo más tarde.');
        }

        let imageBuffer = null;
        for (const url of imageUrls) {
            imageBuffer = await descargarImagen(url);
            if (imageBuffer) break;
        }

        if (!imageBuffer) {
            return message.reply('❌ No se pudo descargar ninguna imagen. Intenta de nuevo más tarde.');
        }

        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: 'Therians 🦊'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /therians:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
};

handlerTherians.command = /^therians/i;
handlerTherians.help = ['therians'];
handlerTherians.tags = ['fun', 'kpop'];

module.exports = { blackpink: handlerTherians };
