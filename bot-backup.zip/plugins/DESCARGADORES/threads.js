﻿const axios = require('axios');

let handlerThreads = async (message, { conn }) => {
    try {
        const text = message.body;
        // Asume que message.body es una cadena y que message.reply, message.from, y conn.sendMessage están disponibles
        // en el entorno de ejecución (ej. @whiskeysockets/baileys o similar).
        
        const args = text.trim().split(' ').slice(1);

        if (args.length === 0) {
            return await message.reply('🔎 *Uso correcto:*\n/threads <enlace>\n\nEjemplo: /threads https://www.threads.net/@momojypx/post/C52-OaTL3al');
        }

        let isAll = false;
        let threadsUrl;

        if (args[0] === 'todo') {
            if (args.length < 2) {
                return await message.reply('🔎 *Uso correcto:*\n/threads todo <enlace>\n\nEjemplo: /threads todo https://www.threads.net/@momojypx/post/C52-OaTL3al');
            }
            isAll = true;
            threadsUrl = args[1];
        } else {
            threadsUrl = args[0];
        }

        // 🟢 MENSAJE INICIAL DE DESCARGA
        await message.reply('⏳ *Descargando el contenido...*\nPor favor, ten paciencia, puede tardar unos segundos si el archivo es pesado.');

        // 💡 LÍNEA REPARADA: Se usa Template Literal (comillas invertidas)
        const apiUrl = `https://delirius-apiofc.vercel.app/download/threads?url=${encodeURIComponent(threadsUrl)}`;
        
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status && data.data && data.data.length > 0) {
            if (isAll) {
                // 📸 Enviar todas las imágenes como respuesta al comando
                for (const item of data.data) {
                    if (item.type === 'image' && item.url) {
                        const imageResponse = await axios.get(item.url, { responseType: 'arraybuffer' });
                        const imageBuffer = Buffer.from(imageResponse.data);

                        await conn.sendMessage(message.from, {
                            image: imageBuffer,
                            caption: '📸 Imagen descargada de Threads.'
                        }, { quoted: message._baileyMessage });
                    }
                }
                await message.reply('✅ *Todas las imágenes de Threads han sido enviadas correctamente.*');
            } else {
                // 📸 Enviar solo la primera imagen como respuesta al comando
                const firstItem = data.data[0];
                if (firstItem.type === 'image' && firstItem.url) {
                    const imageResponse = await axios.get(firstItem.url, { responseType: 'arraybuffer' });
                    const imageBuffer = Buffer.from(imageResponse.data);

                    await conn.sendMessage(message.from, {
                        image: imageBuffer,
                        caption: '✅ Imagen de Threads descargada correctamente.\n\n💡 Usa: */threads todo <link>* si el post contiene más de una imagen.'
                    }, { quoted: message._baileyMessage });
                } else {
                    await message.reply('❌ El contenido no es una imagen o no se encontró.');
                }
            }
        } else {
            await message.reply('❌ No se pudo obtener el contenido. Verifica el enlace o intenta más tarde.');
        }

    } catch (error) {
        // Mejor registro de errores, incluyendo la URL en caso de que falle la petición
        console.error('Error en el comando threads:', error.message || error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Intenta de nuevo más tarde.');
    }
};

handlerThreads.help = ['threads'];
handlerThreads.tags = ['download'];
handlerThreads.command = /^(threads)$/i;

module.exports.threads = handlerThreads;