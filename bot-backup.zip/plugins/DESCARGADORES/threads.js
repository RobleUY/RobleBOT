﻿const axios = require('axios')

const BUFFER_DOWNLOAD_TIMEOUT_MS = 25000
const GLOBAL_THREADS_TIMEOUT_MS = 60000

function withTimeout(promise, ms, timeoutMessage) {
  let timer
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage || `TIMEOUT_${ms}MS`)), ms)
  })
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer))
}

// --- Fuentes de metadata ---

async function getFromDeliriusThreads(url) {
  console.log('[THREADS] Consultando DeliriusAPI...')
  const res = await axios.get(`https://api.delirius.online/download/threads?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.status || !res.data?.data?.length) throw new Error('DELIRIUS_FAIL')
  const items = res.data.data
    .filter(i => i.url)
    .map(i => ({ type: i.type === 'image' ? 'image' : 'video', url: i.url }))
  if (!items.length) throw new Error('DELIRIUS_NO_ITEMS')
  console.log('[THREADS] ✅ DeliriusAPI entregó resultado')
  return { items, source: 'DeliriusAPI' }
}

async function getFromRobleThreads(url) {
  console.log('[THREADS] Consultando RobleAPI...')
  const res = await axios.get(`https://robleuy.vercel.app/robleapi/download/threads?url=${encodeURIComponent(url)}`, { timeout: 30000 })
  if (!res.data?.ok) throw new Error('ROBLE_FAIL')
  const items = []
  if (res.data?.download_url) {
    items.push({ type: 'video', url: res.data.download_url })
  } else if (Array.isArray(res.data?.items)) {
    for (const i of res.data.items) {
      if (i.download_url) items.push({ type: i.type === 'image' ? 'image' : 'video', url: i.download_url })
    }
  }
  if (!items.length) throw new Error('ROBLE_NO_ITEMS')
  console.log('[THREADS] ✅ RobleAPI entregó resultado')
  return { items, source: 'RobleAPI' }
}

async function getFromSankaThreads(url) {
  console.log('[THREADS] Consultando SankaAPI...')
  const res = await axios.get(`https://www.sankavollerei.com/download/threads?apikey=planaai&url=${encodeURIComponent(url)}`, { timeout: 30000 })
  const r = res.data?.result
  if (!res.data?.status || !r) throw new Error('SANKA_FAIL')
  const dl = r.download || r.url || r.video || r.media
  if (!dl) throw new Error('SANKA_NO_URL')
  console.log('[THREADS] ✅ SankaAPI entregó resultado')
  return { items: [{ type: String(dl).includes('.mp4') ? 'video' : 'image', url: dl }], source: 'SankaAPI' }
}

// --- Carrera de fuentes: todas a la vez, gana la primera en responder Y descargar ---

async function getWorkingThreads(threadsUrl) {
  const sources = [
    { name: 'DeliriusAPI', fn: getFromDeliriusThreads },
    { name: 'RobleAPI',    fn: getFromRobleThreads },
    { name: 'SankaAPI',    fn: getFromSankaThreads }
  ]

  const wrapped = sources.map((s, idx) =>
    s.fn(threadsUrl)
      .then(data => ({ idx, ok: true, data }))
      .catch(error => ({ idx, ok: false, error }))
  )

  const pending = new Map(wrapped.map((p, idx) => [idx, p]))
  const errors = []

  while (pending.size > 0) {
    const result = await Promise.race(pending.values())
    pending.delete(result.idx)
    const sourceName = sources[result.idx].name

    if (!result.ok) {
      console.log(`[THREADS] ❌ ${sourceName} falló: ${result.error.message}`)
      errors.push(`${sourceName}: ${result.error.message}`)
      continue
    }

    console.log(`[THREADS] ${sourceName} entregó metadata, descargando archivos...`)

    try {
      const downloadedItems = []
      for (const item of result.data.items) {
        let buffer
        if (Buffer.isBuffer(item.url)) {
          buffer = item.url
        } else {
          const contentResponse = await withTimeout(
            axios.get(item.url, { responseType: 'arraybuffer', timeout: BUFFER_DOWNLOAD_TIMEOUT_MS }),
            BUFFER_DOWNLOAD_TIMEOUT_MS,
            'BUFFER_DOWNLOAD_TIMEOUT'
          )
          buffer = Buffer.from(contentResponse.data)
        }
        downloadedItems.push({ type: item.type, buffer })
      }
      console.log(`[THREADS] 🏆 ¡GANADORA! ${sourceName} descargó ${downloadedItems.length} elementos exitosamente`)
      return { items: downloadedItems, source: sourceName }
    } catch (downloadError) {
      console.log(`[THREADS] ${sourceName} error en descarga: ${downloadError.message}`)
      errors.push(`${sourceName} (descarga): ${downloadError.message}`)
      continue
    }
  }

  throw new Error('Todas las fuentes de Threads fallaron. Detalles: ' + errors.join(' | '))
}

// --- Handler /threads ---

let handlerThreads = async (message, { conn }) => {
  try {
    const args = (message.body || '').trim().split(/\s+/).slice(1)

    if (!args[0]) {
      return await message.reply(
        '🔎 *Uso correcto:*\n/threads <enlace>\n\nEjemplo: /threads https://www.threads.net/@usuario/post/abc123\n\n' +
        '💡 Usa */threads todo <enlace>* para descargar todos los archivos del post.'
      )
    }

    let isAll = false
    let threadsUrl

    if (args[0] === 'todo') {
      if (!args[1]) {
        return await message.reply('🔎 *Uso correcto:*\n/threads todo <enlace>')
      }
      isAll = true
      threadsUrl = args[1]
    } else {
      threadsUrl = args[0]
    }

    await message.reply('⏳ *Descargando el contenido de Threads...*')

    const { items, source } = await withTimeout(
      getWorkingThreads(threadsUrl),
      GLOBAL_THREADS_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    console.log(`[THREADS] 🚀 Enviando ${isAll ? items.length : 1} elemento(s) a WhatsApp vía ${source}...`)

    const itemsToSend = isAll ? items : [items[0]]

    for (const item of itemsToSend) {
      if (item.type === 'image') {
        await conn.sendMessage(message.from, {
          image: item.buffer,
          caption: isAll
            ? '📸 Imagen de Threads.'
            : '✅ Imagen de Threads descargada.\n\n💡 Usa */threads todo <link>* si hay más de una imagen.'
        }, { quoted: message._baileyMessage })
      } else if (item.type === 'video') {
        await conn.sendMessage(message.from, {
          video: item.buffer,
          caption: '🎬 Video de Threads.'
        }, { quoted: message._baileyMessage })
      }
    }

    if (isAll && itemsToSend.length > 1) {
      await message.reply(`✅ *${itemsToSend.length} archivos de Threads enviados correctamente.*`)
    }

    console.log('[THREADS] ✅ Contenido de Threads enviado a WhatsApp exitosamente')

  } catch (error) {
    console.error('[THREADS ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    return await message.reply('❌ Ocurrió un error al obtener o enviar el contenido. Verifica el enlace e intenta de nuevo más tarde.')
  }
}

handlerThreads.help = ['threads']
handlerThreads.tags = ['download']
handlerThreads.command = /^(threads)$/i

module.exports.threads = handlerThreads
