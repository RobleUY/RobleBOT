const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yts = require('yt-search');

// ===============================
// CONFIGURACIÓN
// ===============================
const COMANDO_ACTIVADO = true; // cambia a false si querés desactivarlo
const LIMIT_MB = 700; // límite máximo permitido en MB
const TIMEOUT_MS = 60000; // tiempo máximo de descarga
const DESCARGAS_DIR = path.join(__dirname, 'descargas');

// Aumenta el límite de listeners para evitar el warning
require('events').EventEmitter.defaultMaxListeners = 50;

// Crear carpeta si no existe
if (!fs.existsSync(DESCARGAS_DIR)) fs.mkdirSync(DESCARGAS_DIR, { recursive: true });

// ===============================
// FUNCIÓN PARA OBTENER VIDEO
// ===============================
async function getFromSanka(youtubeUrl) {
    const endpoint = `https://www.sankavollerei.com/download/ytmp4?apikey=planaai&url=${encodeURIComponent(youtubeUrl)}`;
    const res = await axios.get(endpoint, { timeout: TIMEOUT_MS });
    if (!res.data?.status) throw new Error('Error al obtener datos de la API');

    const { download, title, duration, thumbnail } = res.data.result || {};
    if (!download) throw new Error('No se encontró el link de descarga');
    return { download, title, duration, thumbnail };
}

// ===============================
// FUNCIÓN PARA BUSCAR EN YOUTUBE
// ===============================
async function searchYouTube(query) {
    const result = await yts(query);
    if (!result?.videos?.length) throw new Error('No se encontraron resultados');
    return result.videos[0].url;
}

// ===============================
// HANDLER PRINCIPAL
// ===============================
let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO)
        return await message.reply('⚠️ *Este comando está temporalmente deshabilitado.*');

    if (!text)
        return await message.reply(
            `❌ Debes enviar un enlace o título de YouTube.\n\nEjemplo:\n` +
            `• ${usedPrefix + command} https://youtu.be/kLpH1nSLJSs\n` +
            `• ${usedPrefix + command} Bad Bunny Amorfoda`
        );

    try {
        let youtubeUrl = text;
        if (!youtubeUrl.includes('youtube.com') && !youtubeUrl.includes('youtu.be')) {
            await message.reply('🔍 Buscando video en YouTube...');
            youtubeUrl = await searchYouTube(text);
        }

        await message.reply('⏳ Descargando el video de YouTube...\n\nEl archivo de video se está enviando y puede demorar un poco si el archivo es pesado.');

        const { download, title, duration, thumbnail } = await getFromSanka(youtubeUrl);
        console.log('[VIDEOYT] Datos obtenidos correctamente:', { title, duration });

        // Nombre del archivo local
        const safeName = title.replace(/[\\/:*?"<>|]/g, '').slice(0, 60) + '.mp4';
        const filePath = path.join(DESCARGAS_DIR, safeName);

        // Descargar al disco
        const response = await axios({
            url: download,
            method: 'GET',
            responseType: 'stream',
            timeout: 120000
        });

        const writer = fs.createWriteStream(filePath);
        let size = 0;
        response.data.on('data', chunk => size += chunk.length);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        const sizeMB = (size / (1024 * 1024)).toFixed(2);
        console.log(`[VIDEOYT] Tamaño descargado: ${sizeMB} MB`);

        if (sizeMB > LIMIT_MB) {
            await message.reply(`⚠️ El video pesa ${sizeMB} MB, supera el límite de ${LIMIT_MB} MB.`);
            fs.unlinkSync(filePath);
            return;
        }

        // Mostrar miniatura (opcional)
        if (thumbnail) {
            await conn.sendMessage(message.from, {
                image: { url: thumbnail },
                caption: `🎬 *${title}*\n⏱️ Duración: ${duration} segundos\n\nEl archivo de video se está enviando y puede demorar un poco si el archivo es pesado.`
            }, { quoted: message._baileyMessage });
        }

        // 📦 Enviar como documento SIEMPRE
        await conn.sendMessage(
            message.from,
            {
                document: { url: filePath },
                mimetype: 'video/mp4',
                fileName: `${title}.mp4`,
                caption: `🎬 *${title}*`
            },
            { quoted: message._baileyMessage }
        );

        console.log('[VIDEOYT] Documento enviado correctamente');
        await fs.promises.unlink(filePath).catch(() => { });
        console.log('[LIMPIEZA] Archivo eliminado:', filePath);

    } catch (e) {
        console.error('[VIDEOYT] Error general:', e?.message || e);
        await message.reply(
            `❌ Ocurrió un error al descargar el video.\n\nPosibles causas:\n` +
            `• El link no es válido\n• El video está protegido\n• El servidor está caído\n• El video es demasiado pesado`
        );
    }
};

// ===============================
// EXPORTAR HANDLER
// ===============================
handler.help = ['ytvideo <link o título>', 'videoyt <link o título>', 'ytmp4 <link o título>'];
handler.tags = ['video', 'youtube', 'downloader'];
handler.command = /^(zzyt)$/i;

module.exports = handler;
