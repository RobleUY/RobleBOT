﻿const axios = require('axios');

const PINTEREST_API = 'https://robleuy.vercel.app/robleapi/buscador/pinterest';

const pinterestCache = new Map();

async function buscarImagenPinterest(query) {
    if (!query) return null;
    if (pinterestCache.has(query)) return pinterestCache.get(query);

    const url = `${PINTEREST_API}?q=${encodeURIComponent(query)}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (!data.ok || !Array.isArray(data.images) || data.images.length === 0) return null;

        const randomImage = data.images[Math.floor(Math.random() * data.images.length)];
        pinterestCache.set(query, data.images);
        return randomImage.large || randomImage.small || null;
    } catch (error) {
        console.error('Error al buscar imagen en Pinterest:', error?.message || error);
        return null;
    }
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) {
            return await message.reply('Por favor, proporciona un termino de busqueda. Ejemplo: .pinterest aesthetic');
        }

        await message.reply('Buscando en Pinterest...');

        const imageUrl = await buscarImagenPinterest(text);
        if (!imageUrl) {
            return await message.reply('No se encontraron imagenes para ese termino.');
        }

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBusqueda: ${text}`
        }, { quoted: message._baileyMessage });
    } catch (error) {
        console.error('Error en el comando Pinterest:', error && error.stack ? error.stack : error);
        return await message.reply('Ocurrio un error al buscar la imagen.');
    }
};

let handlerViewOnce = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) {
            return await message.reply('Por favor, proporciona un termino de busqueda. Ejemplo: .pinterestv1 aesthetic');
        }

        await message.reply('Buscando en Pinterest...');

        const imageUrl = await buscarImagenPinterest(text);
        if (!imageUrl) {
            return await message.reply('No se encontraron imagenes para ese termino.');
        }

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBusqueda: ${text}\n\nEsta imagen se puede ver una sola vez.`,
            viewOnce: true
        }, { quoted: message._baileyMessage });
    } catch (error) {
        console.error('Error en el comando Pinterest (view once):', error && error.stack ? error.stack : error);
        return await message.reply('Ocurrio un error al buscar la imagen.');
    }
};

handler.help = ['pinterest <texto>', 'pin <texto>'];
handler.tags = ['imagenes', 'busqueda', 'pinterest'];
handler.command = /^(pinterest|pin)$/i;

handlerViewOnce.help = ['pinterestv1 <texto>', 'pinv1 <texto>'];
handlerViewOnce.tags = ['imagenes', 'busqueda', 'pinterest', 'view-once'];
handlerViewOnce.command = /^(pinterestv1|pinv1)$/i;

module.exports = handler;
module.exports.pinterestv1 = handlerViewOnce;
