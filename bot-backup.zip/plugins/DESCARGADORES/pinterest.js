﻿ccccconst axios = require('axios');

// 🧠 Cache: ahora guarda arrays
const imageCache = new Map();

/**
 * 🔍 Buscar imágenes en tu API
 */
async function buscarPinterestTexto(query) {
    try {
        let images;

        // 📦 Si ya está en cache, usarlo
        if (imageCache.has(query)) {
            images = imageCache.get(query);
        } else {
            const url = `https://www.robleuy.site/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
            const { data } = await axios.get(url);

            if (!data?.ok || !data?.images?.length) return null;

            images = data.images
                .map(img => img.large)
                .filter(url => typeof url === 'string' && url.startsWith('http'));

            if (!images.length) return null;

            imageCache.set(query, images);
        }

        // 🎯 elegir imagen aleatoria distinta
        const random = images[Math.floor(Math.random() * images.length)];
        return random;

    } catch (error) {
        console.error('❌ Error API Pinterest:', error.message);
        return null;
    }
}

/**
 * 🎯 Handler
 */
let handlerPinterest = async (message, { conn, text }) => {
    try {
        if (!text) {
            return await message.reply(
                '❌ *Uso correcto:*\n> .pinterest <búsqueda>'
            );
        }

        await message.reply(`🔎 *Buscando...*\n> ${text}`);

        const imageUrl = await buscarPinterestTexto(text);

        if (!imageUrl) {
            return await message.reply(`❌ Sin resultados para: *${text}*`);
        }

        await conn.sendMessage(
            message.from,
            {
                image: { url: imageUrl },
                caption: `📌 *Pinterest*\n\n🔎 ${text}`
            },
            { quoted: message._baileyMessage }
        );

    } catch (error) {
        console.error('💥 Error:', error);
        await message.reply('❌ Error en Pinterest.');
    }
};

handlerPinterest.command = /^pinterest$/i;
handlerPinterest.help = ['pinterest <texto>'];
handlerPinterest.tags = ['imagenes'];

module.exports = handlerPinterest;