const axios = require('axios');

// 🧠 Cache simple
const imageCache = new Map();

/**
 * 🔍 Buscar imágenes en tu API
 */
async function buscarPinterestTexto(query) {
    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://www.robleuy.site/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url);

        if (!data?.ok || !data?.images?.length) return null;

        const valid = data.images
            .map(img => img.large)
            .filter(url => typeof url === 'string' && url.startsWith('http'));

        if (!valid.length) return null;

        const random = valid[Math.floor(Math.random() * valid.length)];

        // guardar en cache
        imageCache.set(query, random);

        return random;

    } catch (error) {
        console.error('❌ Error API Pinterest:', error.message);
        return null;
    }
}

/**
 * 🎯 Handler principal
 */
let handlerPinterest = async (message, { conn, text }) => {
    try {
        if (!text) {
            return await message.reply(
                '❌ *Uso correcto:*\n> .pinterest <búsqueda>\n\n📌 Ejemplo:\n.pinterest aesthetic'
            );
        }

        await message.reply(`🔎 *Buscando en Pinterest...*\n> ${text}`);

        const imageUrl = await buscarPinterestTexto(text);

        if (!imageUrl) {
            return await message.reply(`❌ No se encontraron resultados para: *${text}*`);
        }

        // 🚀 envío directo por URL (más rápido, sin buffer)
        await conn.sendMessage(
            message.from,
            {
                image: { url: imageUrl },
                caption: `🎯 *Resultado de Pinterest*\n\n📌 *Búsqueda:* ${text}`
            },
            { quoted: message._baileyMessage }
        );

    } catch (error) {
        console.error('💥 Error en /pinterest:', error);
        await message.reply('❌ Error al obtener resultados de Pinterest.');
    }
};

// 📦 Configuración
handlerPinterest.command = /^pinterest$/i;
handlerPinterest.help = ['pinterest <texto>'];
handlerPinterest.tags = ['imagenes'];

module.exports = { pinterest: handlerPinterest };