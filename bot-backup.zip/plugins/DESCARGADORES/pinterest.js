﻿const axios = require('axios');
const { searchPinterest, searchPinterestVideo } = require('../../lib/apiHelper');

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Language': 'es-ES,es;q=0.9',
};

// ============================================================
// DESCARGAR IMAGEN como buffer
// ============================================================
async function descargarImagen(url) {
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        const buf = Buffer.from(res.data, 'binary');
        if (buf.length < 5000) return null;
        return buf;
    } catch (e) { return null; }
}

// ============================================================
// CARRERA DE IMÁGENES: usa el helper con fallback automático
// ============================================================
async function buscarImagenEnCarrera(query) {
    try {
        const urls = await searchPinterest(query);
        if (!urls || urls.length === 0) return null;
        
        const url = urls[Math.floor(Math.random() * urls.length)];
        return await descargarImagen(url);
    } catch (e) {
        return null;
    }
}

// ============================================================
// BUSCAR VIDEO via helper
// ============================================================
async function buscarVideo(query) {
    try {
        const videoData = await searchPinterestVideo(query);
        if (!videoData || !videoData.video) return null;

        const vidRes = await axios.get(videoData.video, {
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        const buf = Buffer.from(vidRes.data);
        if (buf.length < 10000) return null;
        return buf;
    } catch (e) {
        return null;
    }
}

// ============================================================
// HANDLER: .pinterest / .pin  → imagen (carrera)
// ============================================================
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterest aesthetic');

        await message.reply('Buscando en Pinterest...');

        const imageBuffer = await buscarImagenEnCarrera(text);
        if (!imageBuffer) return await message.reply('No se encontraron imágenes para ese término.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBúsqueda: ${text}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterest] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar la imagen.');
    }
};

// ============================================================
// HANDLER: .pinterest2 / .pin2  → video
// ============================================================
let handlerVideo = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterest2 drift cars');

        await message.reply('Buscando video en Pinterest...');

        const videoBuffer = await buscarVideo(text);
        if (!videoBuffer) return await message.reply('No se encontró ningún video para ese término.');

        await sock.sendMessage(message.from, {
            video: videoBuffer,
            caption: `Pinterest 🎬\n\nBúsqueda: ${text}`,
            gifPlayback: false
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterest2] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar el video.');
    }
};

// ============================================================
// HANDLER: .pinterestv1 / .pinv1  → imagen view once
// ============================================================
let handlerViewOnce = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterestv1 aesthetic');

        await message.reply('Buscando en Pinterest...');

        const imageBuffer = await buscarImagenEnCarrera(text);
        if (!imageBuffer) return await message.reply('No se encontraron imágenes para ese término.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBúsqueda: ${text}\n\nEsta imagen se puede ver una sola vez.`,
            viewOnce: true
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterestv1] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar la imagen.');
    }
};

handler.help = ['pinterest <texto>', 'pin <texto>'];
handler.tags = ['imagenes', 'busqueda', 'pinterest'];
handler.command = /^(pinterest|pin)$/i;

handlerVideo.help = ['pinterest2 <texto>', 'pin2 <texto>'];
handlerVideo.tags = ['imagenes', 'busqueda', 'pinterest', 'video'];
handlerVideo.command = /^(pinterest2|pin2)$/i;

handlerViewOnce.help = ['pinterestv1 <texto>', 'pinv1 <texto>'];
handlerViewOnce.tags = ['imagenes', 'busqueda', 'pinterest', 'view-once'];
handlerViewOnce.command = /^(pinterestv1|pinv1)$/i;

module.exports = handler;
module.exports.pinterestv1 = handlerViewOnce;
module.exports.pinterest2 = handlerVideo;
