const axios = require('axios');

const PINTEREST_API = 'https://www.robleuy.site/robleapi/buscador/pinterest';

// Cache simple
const pinterestCache = new Map();

async function buscarImagenPinterest(query) {
    if (pinterestCache.has(query)) return pinterestCache.get(query);

    const url = `${PINTEREST_API}?q=${encodeURIComponent(query)}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (!data.ok || !data.images || data.images.length === 0) return null;

        // Elegir imagen aleatoria
        const randomImage = data.images[Math.floor(Math.random() * data.images.length)];
        pinterestCache.set(query, data.images); // Guardar todas para no repetir si se llama de nuevo
        return randomImage.large || randomImage.small;

    } catch (error) {
        console.error('Error al buscar imagen en Pinterest:', error.message);
        return null;
    }
}

// Comando normal
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('❌ Por favor, proporciona un término de búsqueda.\nEjemplo: .pinterest aesthetic');

        await message.reply('🔍 Buscando en Pinterest...');

        const imageUrl = await buscarImagenPinterest(text);
        if (!imageUrl) return await message.reply('❌ No se encontraron imágenes para ese término.');

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `📌 Pinterest\n\n📝 *Búsqueda:* ${text}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en el comando Pinterest:', error);
        return await message.reply('❌ Ocurrió un error al buscar la imagen.');
    }
};

// Comando view-once
let handlerViewOnce = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('❌ Por favor, proporciona un término de búsqueda.\nEjemplo: .pinterestv1 aesthetic');

        await message.reply('🔍 Buscando en Pinterest...');

        const imageUrl = await buscarImagenPinterest(text);
        if (!imageUrl) return await message.reply('❌ No se encontraron imágenes para ese término.');

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `📌 Pinterest\n\n📝 *Búsqueda:* ${text}\n\n⚠️ Esta imagen se puede ver una sola vez.`,
            viewOnce: true
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en el comando Pinterest (view once):', error);
        return await message.reply('❌ Ocurrió un error al buscar la imagen.');
    }
};

handler.help = ['pinterest <texto>', 'pin <texto>'];
handler.tags = ['imagenes', 'busqueda', 'pinterest'];
handler.command = /^(pinterest|pin)$/i;

handlerViewOnce.help = ['pinterestv1 <texto>', 'pinv1 <texto>'];
handlerViewOnce.tags = ['imagenes', 'busqueda', 'pinterest', 'view-once'];
handlerViewOnce.command = /^(pinterestv1|pinv1)$/i;

module.exports = handler;
module.exports.pinterestv1 = handlerViewOnce;