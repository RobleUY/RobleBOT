﻿const axios = require('axios');

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Language': 'es-ES,es;q=0.9',
};

// ============================================================
// FUENTES DE IMÁGENES — todas devuelven string[] de URLs o null
// ============================================================

// Pinterest legacy (robleuy.vercel.app)
async function buscarPinterestLegacy(query) {
    try {
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`, { timeout: 10000 });
        const data = res.data;
        if (!data.ok || !Array.isArray(data.images) || data.images.length === 0) return null;
        return data.images.map(img => img.large || img.small).filter(Boolean);
    } catch (e) { return null; }
}

// Pinterest v1 via Delirius
async function buscarPinterestV1(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pinterest?text=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.results;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.filter(Boolean);
    } catch (e) { return null; }
}

// Pinterest v2 via Delirius
async function buscarPinterestV2(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pinterestv2?text=${encodeURIComponent(query)}`, { timeout: 10000 });
        const items = res.data?.data;
        if (!Array.isArray(items) || items.length === 0) return null;
        return items.map(i => i.image).filter(Boolean);
    } catch (e) { return null; }
}

// ============================================================
// DESCARGAR IMAGEN como buffer
// ============================================================
async function descargarImagen(url) {
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        const buf = Buffer.from(res.data, 'binary');
        if (buf.length < 5000) return null;
        return buf;
    } catch (e) { return null; }
}

// ============================================================
// CARRERA DE IMÁGENES: lanza las 3 fuentes a la vez,
// gana la primera que descargue un buffer válido
// ============================================================
async function buscarImagenEnCarrera(query) {
    const fuente = async (buscarFn) => {
        try {
            const urls = await buscarFn(query);
            if (!urls || urls.length === 0) return null;
            const url = urls[Math.floor(Math.random() * urls.length)];
            return await descargarImagen(url);
        } catch (e) { return null; }
    };

    const promesas = [
        fuente(buscarPinterestLegacy),
        fuente(buscarPinterestV1),
        fuente(buscarPinterestV2),
    ];

    return new Promise((resolve) => {
        let resolved = false;
        let pendientes = promesas.length;

        for (const p of promesas) {
            p.then(result => {
                if (resolved) return;
                if (result) {
                    resolved = true;
                    resolve(result);
                } else {
                    pendientes--;
                    if (pendientes === 0) resolve(null);
                }
            }).catch(() => {
                if (resolved) return;
                pendientes--;
                if (pendientes === 0) resolve(null);
            });
        }
    });
}

// ============================================================
// BUSCAR VIDEO via Delirius pinterestvideo
// ============================================================
async function buscarVideo(query) {
    try {
        const res = await axios.get(`https://api.delirius.online/search/pinterestvideo?query=${encodeURIComponent(query)}`, { timeout: 15000 });
        const videoUrl = res.data?.data?.video;
        if (!videoUrl) return null;

        const vidRes = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: BROWSER_HEADERS,
            maxRedirects: 5,
        });
        const buf = Buffer.from(vidRes.data);
        if (buf.length < 10000) return null;
        return buf;
    } catch (e) {
        console.error('[pinterest video] Error:', e.message);
        return null;
    }
}

// ============================================================
// HANDLER: .pinterest / .pin  → imagen (carrera)
// ============================================================
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterest aesthetic');

        await message.reply('Buscando en Pinterest...');

        const imageBuffer = await buscarImagenEnCarrera(text);
        if (!imageBuffer) return await message.reply('No se encontraron imágenes para ese término.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBúsqueda: ${text}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterest] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar la imagen.');
    }
};

// ============================================================
// HANDLER: .pinterest2 / .pin2  → video
// ============================================================
let handlerVideo = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterest2 drift cars');

        await message.reply('Buscando video en Pinterest...');

        const videoBuffer = await buscarVideo(text);
        if (!videoBuffer) return await message.reply('No se encontró ningún video para ese término.');

        await sock.sendMessage(message.from, {
            video: videoBuffer,
            caption: `Pinterest 🎬\n\nBúsqueda: ${text}`,
            gifPlayback: false
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterest2] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar el video.');
    }
};

// ============================================================
// HANDLER: .pinterestv1 / .pinv1  → imagen view once
// ============================================================
let handlerViewOnce = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('Por favor, proporciona un término de búsqueda. Ejemplo: .pinterestv1 aesthetic');

        await message.reply('Buscando en Pinterest...');

        const imageBuffer = await buscarImagenEnCarrera(text);
        if (!imageBuffer) return await message.reply('No se encontraron imágenes para ese término.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `Pinterest\n\nBúsqueda: ${text}\n\nEsta imagen se puede ver una sola vez.`,
            viewOnce: true
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('[pinterestv1] Error:', error.message);
        return await message.reply('Ocurrió un error al buscar la imagen.');
    }
};

handler.help = ['pinterest <texto>', 'pin <texto>'];
handler.tags = ['imagenes', 'busqueda', 'pinterest'];
handler.command = /^(pinterest|pin)$/i;

handlerVideo.help = ['pinterest2 <texto>', 'pin2 <texto>'];
handlerVideo.tags = ['imagenes', 'busqueda', 'pinterest', 'video'];
handlerVideo.command = /^(pinterest2|pin2)$/i;

handlerViewOnce.help = ['pinterestv1 <texto>', 'pinv1 <texto>'];
handlerViewOnce.tags = ['imagenes', 'busqueda', 'pinterest', 'view-once'];
handlerViewOnce.command = /^(pinterestv1|pinv1)$/i;

module.exports = handler;
module.exports.pinterestv1 = handlerViewOnce;
module.exports.pinterest2 = handlerVideo;
