const axios = require('axios');

// ─── Fuentes de búsqueda de imágenes ─────────────────────────────────────────
const PINTEREST_API = 'https://robleuy.vercel.app/robleapi/buscador/pinterest';
const BING_API = 'https://robleuy.vercel.app/robleapi/buscador/bingimages';

// ─── Categorías random en español (cuando no se especifica término) ─────────
const MEME_TERMS = [
    'memes en español',
    'memes de bob esponja',
    'memes de batman',
    'memes de spiderman',
    'memes de gatos',
    'memes de perros',
    'memes de la escuela',
    'memes de mr increible',
    'memes de shrek',
    'memes de goku',
    'memes de among us',
    'memes de minecraft',
    'memes de anime',
    'memes de trabajo',
    'memes de lunes',
    'memes de universidad',
    'memes random',
    'memes de programadores',
    'memes de futbol',
    'memes de whatsapp'
];

const BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Referer': 'https://www.google.com/',
    'Connection': 'keep-alive'
};

// ─── Memoria anti-repetición (en RAM, por chat) ──────────────────────────────
// Guarda: último término random usado y las últimas imágenes enviadas por chat
const ULTIMO_TERMINO_RANDOM = new Map();      // chatId -> string
const IMAGENES_RECIENTES = new Map();         // chatId -> Set<url>
const MAX_IMAGENES_RECORDADAS = 25;           // cuántas URLs recordar antes de "olvidar"

function getRecientes(chatId) {
    if (!IMAGENES_RECIENTES.has(chatId)) {
        IMAGENES_RECIENTES.set(chatId, new Set());
    }
    return IMAGENES_RECIENTES.get(chatId);
}

function marcarComoUsada(chatId, url) {
    const set = getRecientes(chatId);
    set.add(url);
    // Si se llena demasiado, limpiamos las más viejas (Set conserva orden de inserción)
    if (set.size > MAX_IMAGENES_RECORDADAS) {
        const primero = set.values().next().value;
        set.delete(primero);
    }
}

// ─── Shuffle Fisher-Yates ─────────────────────────────────────────────────────
function shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

// ─── Construye el término de búsqueda final ──────────────────────────────────
function construirTermino(text, chatId) {
    if (text && text.trim()) {
        const limpio = text.trim();
        return `memes de ${limpio}`;
    }

    // Random, evitando repetir el mismo término que la última vez en este chat
    const ultimo = ULTIMO_TERMINO_RANDOM.get(chatId);
    let candidatos = MEME_TERMS;
    if (ultimo) {
        candidatos = MEME_TERMS.filter(t => t !== ultimo);
    }
    const elegido = candidatos[Math.floor(Math.random() * candidatos.length)];
    ULTIMO_TERMINO_RANDOM.set(chatId, elegido);
    return elegido;
}

// ─── Fuente 1: Pinterest ──────────────────────────────────────────────────────
async function buscarEnPinterest(query) {
    try {
        const response = await axios.get(PINTEREST_API, {
            params: { q: query },
            timeout: 10000
        });
        if (response.data?.ok && response.data.images?.length > 0) {
            return response.data.images.map(img => img.large || img.small).filter(Boolean);
        }
    } catch (error) {
        console.warn(`⚠️ [MEME] Pinterest falló: ${error.message}`);
    }
    return [];
}

// ─── Fuente 2: Bing Images (fallback) ────────────────────────────────────────
async function buscarEnBing(query) {
    try {
        const response = await axios.get(BING_API, {
            params: { q: query },
            timeout: 10000
        });
        if (response.data?.ok && response.data.images?.length > 0) {
            return response.data.images.map(img => img.direct || img.thumbnail).filter(Boolean);
        }
    } catch (error) {
        console.warn(`⚠️ [MEME] Bing falló: ${error.message}`);
    }
    return [];
}

// ─── Descargador con validación ──────────────────────────────────────────────
async function descargarImagen(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 12000,
            headers: BROWSER_HEADERS
        });
        const contentType = response.headers['content-type'] || '';
        if (!contentType.startsWith('image/')) {
            console.warn(`⚠️ URL no devolvió imagen: ${contentType}`);
            return null;
        }
        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.warn(`⚠️ No se pudo descargar imagen (${error.response?.status || error.message}): ${url}`);
        return null;
    }
}

// ─── Buscar en todas las fuentes con fallback ────────────────────────────────
async function buscarMemes(query) {
    let urls = await buscarEnPinterest(query);
    if (!urls.length) {
        console.log('🔄 [MEME] Pinterest sin resultados, probando Bing...');
        urls = await buscarEnBing(query);
    }
    return urls;
}

// ─── Handler principal ───────────────────────────────────────────────────────
let handlerMeme = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        const esRandom = !text || !text.trim();
        const query = construirTermino(text, chatId);

        await message.reply(esRandom ? '🔎 Buscando un meme random...' : `🔎 Buscando un meme de ${text.trim()}...`);

        let imageUrls = await buscarMemes(query);

        if (!imageUrls.length) {
            return message.reply('❌ No se encontraron memes para eso. Intenta con otro término o de nuevo más tarde.');
        }

        // Barajamos para no quedarnos siempre con la primera imagen de la lista
        imageUrls = shuffle(imageUrls);

        const recientes = getRecientes(chatId);

        // Primero intentamos con imágenes que NO se hayan mandado antes en este chat
        const nuevas = imageUrls.filter(url => !recientes.has(url));
        const ordenFinal = nuevas.length ? nuevas : imageUrls; // si todas se repiten, igual mandamos algo

        let imageBuffer = null;
        let urlUsada = null;

        for (const url of ordenFinal) {
            imageBuffer = await descargarImagen(url);
            if (imageBuffer) {
                urlUsada = url;
                break;
            }
        }

        if (!imageBuffer) {
            return message.reply('❌ No se pudo descargar ningún meme. Intenta de nuevo más tarde.');
        }

        marcarComoUsada(chatId, urlUsada);

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `😂 ${query.charAt(0).toUpperCase() + query.slice(1)}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /meme:', error && error.stack ? error.stack : error);
        await message.reply('❌ Ocurrió un error al obtener el meme. Intenta de nuevo más tarde.');
    }
};

handlerMeme.command = /^(meme|memes)$/i;
handlerMeme.help = ['meme <texto opcional>', 'memes <texto opcional>'];
handlerMeme.tags = ['fun', 'imagenes'];

module.exports = { meme: handlerMeme, memes: handlerMeme };