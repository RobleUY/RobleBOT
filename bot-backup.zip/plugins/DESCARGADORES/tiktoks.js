const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Configuración
const DESCARGAS_DIR = path.join(__dirname, '.temp');
const DOCUMENT_THRESHOLD_MB = 100;
const TIMEOUT_MS = 120000;
const MAX_VIDEOS = 5; // Reducido de 10 a 5 para mayor velocidad

// Crear carpeta si no existe
if (!fs.existsSync(DESCARGAS_DIR)) {
    fs.mkdirSync(DESCARGAS_DIR, { recursive: true });
}

// Control de descargas activas
const enDescargaCompilacion = new Set();

// --- 1. MANEJADOR /tiktok (DESCARGA POR ENLACE SIN MARCA DE AGUA) ---
let handlerTikTokDownload = async (message, { conn }) => {
    try {
        const text = message.body.trim();
        const args = text.trim().split(/\s+/).slice(1);
        const tiktokUrl = args[0];

        if (!tiktokUrl) {
            return await message.reply('📎 *Uso correcto:*\n/tiktok <enlace>\n\nEjemplo: /tiktok https://vt.tiktok.com/ZSB2HNoKR/');
        }

        const apiUrl = `https://delirius-apiofc.vercel.app/download/tiktok?url=${encodeURIComponent(tiktokUrl)}`;

        await message.reply('⏳ *Descargando el video de TikTok...*\nPor favor, ten paciencia, puede tardar unos segundos si el archivo es pesado.');

        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status && data.data && data.data.meta && data.data.meta.media && data.data.meta.media.length > 0) {
            const videoUrl = data.data.meta.media[0].org;

            const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer' });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');

            await conn.sendMessage(message.from, {
                video: videoBuffer,
                caption: '✅ *Aquí tienes tu video de TikTok descargado correctamente.* 🎬'
            }, { quoted: message._baileyMessage });

        } else {
            await message.reply('❌ No se pudo obtener el video. Verifica el enlace o inténtalo nuevamente más tarde.');
        }
    } catch (error) {
        const errorDetail = error.response ? `[${error.response.status}] ${error.response.statusText}` : error.message;
        console.error('Error en el manejador /tiktok (Descarga):', errorDetail);
        let userErrorMsg = '❌ Ocurrió un error al procesar tu solicitud. Verifica que el enlace sea correcto y público.';
        return await message.reply(userErrorMsg);
    }
};

// --- 2. MANEJADOR /ttsearch (BÚSQUEDA POR TÍTULO) ---
let handlerTikTokSearch = async (message, { conn }) => {
    try {
        const text = message.body.trim();
        const args = text.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (query.length === 0) {
            return await message.reply('🔍 *Uso correcto:*\n/ttsearch <título o palabras clave>\n\nEjemplo: /ttsearch duki Givenchy');
        }

        const searchApiUrl = `https://delirius-apiofc.vercel.app/search/tiktoksearch?query=${encodeURIComponent(query)}`;

        await message.reply(`🔎 *Buscando videos de TikTok para:* "${query}"\n\n_Obteniendo resultados, espera un momento..._`);

        const searchResponse = await axios.get(searchApiUrl);
        const searchData = searchResponse.data;

        if (searchData.status === 200 && searchData.meta && searchData.meta.length > 0) {
            const results = searchData.meta.slice(0, 5);
            let replyMessage = `✨ *Top 5 Resultados de Búsqueda de TikTok*\n\n`;

            results.forEach((item, index) => {
                const cleanTitle = item.title.replace(/\s+/g, ' ').trim();
                const durationSeconds = item.duration || 0;
                const durationMinutes = Math.floor(durationSeconds / 60);
                const remainingSeconds = durationSeconds % 60;
                const formattedDuration = `${durationMinutes}:${remainingSeconds.toString().padStart(2, '0')}`;

                replyMessage += `*${index + 1}. Título:* ${cleanTitle.substring(0, 80)}...\n`;
                replyMessage += `  *Usuario:* ${item.author.nickname} (@${item.author.username})\n`;
                replyMessage += `  *Duración:* ${formattedDuration}\n`;
                replyMessage += `  *Enlace:* ${item.url}\n`;
                replyMessage += `---\n`;
            });

            replyMessage += `\n💡 Para descargar cualquiera de estos videos, usa el comando */tiktok <enlace>* con la URL correspondiente de la lista.`;

            await message.reply(replyMessage);

        } else {
            await message.reply(`😔 No se encontraron videos de TikTok para la búsqueda: "${query}".`);
        }
    } catch (error) {
        const errorDetail = error.response ? `[${error.response.status}] ${error.response.statusText}` : error.message;
        console.error('Error en el manejador /ttsearch (Búsqueda):', errorDetail);
        let userErrorMsg = '❌ Ocurrió un error al procesar tu solicitud. Asegúrate de que la API de búsqueda esté disponible.';
        return await message.reply(userErrorMsg);
    }
};

// Categorías predefinidas para búsqueda random (en español)
const RANDOM_CATEGORIES = [
    'videos graciosos', 'comedia tiktok', 'momentos virales', 'bailes',
    'bromas', 'animales tiernos', 'recetas de cocida', 'trucos útiles',
    'trucos de magia', 'videos satisfactorios', 'motivación gym', 'viajes',
    'momentos gaming', 'arte y manualidades', 'covers cantando', 'moda tendencia',
    'deportes', 'autos deportivos', 'naturaleza hermosa', 'memes',
    'maquillaje tutorial', 'tips de cocina', 'mascotas graciosas', 'rutina ejercicio',
    'comida callejera', 'talento increíble', 'fails graciosos', 'transformaciones'
];

// --- 3. MANEJADOR /tiktoks (COMPILACIÓN DE MÚLTIPLES VIDEOS) ---
let handlerTikTokCompilation = async (message, { conn }) => {
    const sender = message?.sender || message?.key?.participant || message?.from;

    // Bloquear si ya tiene una compilación en proceso
    if (enDescargaCompilacion.has(sender)) {
        return await message.reply('⚠️ Ya tienes una compilación en proceso. Espera a que termine antes de iniciar otra.');
    }

    try {
        const text = message.body.trim();
        const args = text.trim().split(/\s+/).slice(1);
        let query = args.join(' ');
        let isRandom = false;

        // Verificar si es modo random
        if (query.toLowerCase() === 'random' || query.length === 0) {
            isRandom = true;
            // Seleccionar 3 categorías aleatorias para más variedad
            const randomCategories = [];
            const categoriesCopy = [...RANDOM_CATEGORIES];
            
            for (let i = 0; i < 3; i++) {
                const randomIndex = Math.floor(Math.random() * categoriesCopy.length);
                randomCategories.push(categoriesCopy[randomIndex]);
                categoriesCopy.splice(randomIndex, 1);
            }
            
            query = randomCategories.join(' OR ');
            
            if (args.length === 0) {
                return await message.reply(
                    '🎬 *Uso correcto:*\n/tiktoks <palabras clave o random>\n\n' +
                    'Ejemplos:\n' +
                    '• /tiktoks videos de risa\n' +
                    '• /tiktoks random\n\n' +
                    '🎲 *Modo Random:* Descargará videos de categorías aleatorias mezcladas.\n' +
                    '⚡ Se compilarán 10 videos en un solo archivo.'
                );
            }
        }

        enDescargaCompilacion.add(sender);

        // Mensaje inicial
        const initialMessage = isRandom 
            ? `🎲 *Compilación Random de TikToks*\n\n` +
              `🎯 Categorías seleccionadas aleatoriamente\n` +
              `📊 Videos a descargar: ${MAX_VIDEOS}\n\n` +
              `⏳ _Este proceso puede tardar varios minutos. Ten paciencia..._`
            : `🔍 *Buscando y compilando videos de TikTok*\n\n` +
              `📝 Búsqueda: "${args.join(' ')}"\n` +
              `📊 Videos a descargar: ${MAX_VIDEOS}\n\n` +
              `⏳ _Este proceso puede tardar varios minutos. Ten paciencia..._`;
        
        await message.reply(initialMessage);

        // Para modo random, hacer múltiples búsquedas con diferentes categorías
        let allVideos = [];
        
        if (isRandom) {
            // Buscar en cada categoría seleccionada
            const selectedCategories = query.split(' OR ');
            
            for (const category of selectedCategories) {
                try {
                    const searchApiUrl = `https://delirius-apiofc.vercel.app/search/tiktoksearch?query=${encodeURIComponent(category.trim())}`;
                    const searchResponse = await axios.get(searchApiUrl, { timeout: TIMEOUT_MS });
                    const searchData = searchResponse.data;
                    
                    if (searchData.status === 200 && searchData.meta && searchData.meta.length > 0) {
                        // Tomar solo 2 videos de cada categoría (3 categorías x 2 = 6 videos máximo)
                        const videosFromCategory = searchData.meta.slice(0, 2);
                        allVideos.push(...videosFromCategory);
                    }
                } catch (error) {
                    console.error(`[TIKTOKS] Error buscando categoría "${category}":`, error.message);
                }
            }
            
            // Mezclar aleatoriamente todos los videos recopilados
            allVideos = allVideos.sort(() => Math.random() - 0.5);
            
        } else {
            // Búsqueda normal con el query del usuario
            const searchApiUrl = `https://delirius-apiofc.vercel.app/search/tiktoksearch?query=${encodeURIComponent(query)}`;
            const searchResponse = await axios.get(searchApiUrl, { timeout: TIMEOUT_MS });
            const searchData = searchResponse.data;
            
            if (searchData.status === 200 && searchData.meta && searchData.meta.length > 0) {
                allVideos = searchData.meta;
            }
        }

        if (allVideos.length === 0) {
            enDescargaCompilacion.delete(sender);
            const errorMsg = isRandom 
                ? `😔 No se encontraron videos en las categorías aleatorias. Intenta de nuevo.`
                : `😔 No se encontraron videos de TikTok para: "${args.join(' ')}".`;
            return await message.reply(errorMsg);
        }

        // Obtener videos únicos y variados
        const allResults = allVideos;
        const selectedVideos = [];
        const usedAuthors = new Set();

        // Priorizar variedad de autores
        for (const video of allResults) {
            if (selectedVideos.length >= MAX_VIDEOS) break;
            
            // Intentar no repetir autores para mayor variedad
            if (!usedAuthors.has(video.author.username) || selectedVideos.length >= MAX_VIDEOS / 2) {
                selectedVideos.push(video);
                usedAuthors.add(video.author.username);
            }
        }

        // Si no hay suficientes, completar con cualquier video
        if (selectedVideos.length < MAX_VIDEOS) {
            for (const video of allResults) {
                if (selectedVideos.length >= MAX_VIDEOS) break;
                if (!selectedVideos.includes(video)) {
                    selectedVideos.push(video);
                }
            }
        }

        const videosToDownload = selectedVideos.slice(0, MAX_VIDEOS);

        const downloadingMsg = isRandom
            ? `📥 *Descargando ${videosToDownload.length} videos aleatorios...*\n_Esto puede tardar unos minutos._`
            : `📥 *Descargando ${videosToDownload.length} videos...*\n_Esto puede tardar unos minutos._`;
        
        await message.reply(downloadingMsg);

        // Crear carpeta temporal para esta compilación
        const timestamp = Date.now();
        const tempDir = path.join(DESCARGAS_DIR, `compilation_${timestamp}`);
        fs.mkdirSync(tempDir, { recursive: true });

        const downloadedFiles = [];
        let successCount = 0;

        // Descargar cada video
        for (let i = 0; i < videosToDownload.length; i++) {
            try {
                const video = videosToDownload[i];
                const downloadApiUrl = `https://delirius-apiofc.vercel.app/download/tiktok?url=${encodeURIComponent(video.url)}`;
                
                const downloadResponse = await axios.get(downloadApiUrl, { timeout: TIMEOUT_MS });
                const downloadData = downloadResponse.data;

                if (downloadData.status && downloadData.data?.meta?.media?.[0]?.org) {
                    const videoUrl = downloadData.data.meta.media[0].org;
                    
                    const videoResponse = await axios.get(videoUrl, { 
                        responseType: 'arraybuffer',
                        timeout: TIMEOUT_MS 
                    });
                    
                    const fileName = `video_${i.toString().padStart(2, '0')}.mp4`;
                    const filePath = path.join(tempDir, fileName);
                    
                    fs.writeFileSync(filePath, Buffer.from(videoResponse.data, 'binary'));
                    downloadedFiles.push(filePath);
                    successCount++;
                    
                    console.log(`[TIKTOKS] Descargado ${successCount}/${videosToDownload.length}: ${fileName}`);
                }
            } catch (error) {
                console.error(`[TIKTOKS] Error descargando video ${i + 1}:`, error.message);
                // Continuar con el siguiente video
            }
        }

        if (downloadedFiles.length === 0) {
            // Limpiar y salir
            fs.rmSync(tempDir, { recursive: true, force: true });
            enDescargaCompilacion.delete(sender);
            return await message.reply('❌ No se pudo descargar ningún video. Intenta con otra búsqueda.');
        }

        await message.reply(
            `✅ *Descargados ${downloadedFiles.length} videos*\n\n` +
            `🎬 Compilando en un solo video...\n` +
            `_Esto puede tardar un poco más..._`
        );

        // Normalizar todos los videos antes de compilar
        const normalizedFiles = [];
        
        for (let i = 0; i < downloadedFiles.length; i++) {
            try {
                const inputFile = downloadedFiles[i];
                const normalizedFile = path.join(tempDir, `normalized_${i.toString().padStart(2, '0')}.mp4`);
                
                // Normalizar con configuración más rápida: preset ultrafast y escala fija 720p
                const normalizeCommand = `ffmpeg -i "${inputFile}" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 96k -ar 44100 -ac 2 -vf "scale=720:-2:flags=fast_bilinear,fps=30" -movflags +faststart "${normalizedFile}"`;
                
                await execPromise(normalizeCommand, { cwd: tempDir, timeout: 30000 });
                normalizedFiles.push(normalizedFile);
                
                console.log(`[TIKTOKS] Normalizado ${i + 1}/${downloadedFiles.length}`);
            } catch (error) {
                console.error(`[TIKTOKS] Error normalizando video ${i}:`, error.message);
                // Si falla la normalización, intentar usar el original
                normalizedFiles.push(downloadedFiles[i]);
            }
        }

        // Crear archivo de lista para FFmpeg con videos normalizados
        const listFilePath = path.join(tempDir, 'filelist.txt');
        const listContent = normalizedFiles.map(f => `file '${path.basename(f)}'`).join('\n');
        fs.writeFileSync(listFilePath, listContent);

        // Compilar videos con FFmpeg usando concatenación más rápida
        const outputFileName = `tiktok_compilation_${timestamp}.mp4`;
        const outputPath = path.join(tempDir, outputFileName);

        // Usar preset ultrafast para compilación más rápida
        const ffmpegCommand = `ffmpeg -f concat -safe 0 -i "${listFilePath}" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 96k -movflags +faststart "${outputPath}"`;
        
        try {
            await execPromise(ffmpegCommand, { cwd: tempDir, timeout: 60000 });
            console.log('[TIKTOKS] Compilación completada con éxito');
        } catch (error) {
            console.error('[TIKTOKS] Error en compilación final:', error.message);
            throw new Error('No se pudo compilar el video final');
        }

        // Verificar tamaño del archivo final
        const stats = fs.statSync(outputPath);
        const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);

        console.log(`[TIKTOKS] Tamaño final: ${sizeMB} MB`);

        // Enviar el video compilado
        if (sizeMB >= DOCUMENT_THRESHOLD_MB) {
            // Enviar como documento
            const caption = isRandom
                ? `🎲 *Compilación Random de TikToks*\n\n` +
                  `🎯 Videos de categorías variadas\n` +
                  `📊 Videos incluidos: ${downloadedFiles.length}\n` +
                  `📦 Tamaño: ${sizeMB} MB\n\n` +
                  `✨ _Videos compilados exitosamente_`
                : `🎬 *Compilación de TikToks*\n\n` +
                  `📝 Búsqueda: "${args.join(' ')}"\n` +
                  `📊 Videos incluidos: ${downloadedFiles.length}\n` +
                  `📦 Tamaño: ${sizeMB} MB\n\n` +
                  `✨ _Videos compilados exitosamente_`;
            
            await conn.sendMessage(
                message.from,
                {
                    document: { url: outputPath },
                    mimetype: 'video/mp4',
                    fileName: outputFileName,
                    caption: caption
                },
                { quoted: message._baileyMessage }
            );
        } else {
            // Enviar como video normal
            const caption = isRandom
                ? `🎲 *Compilación Random de TikToks*\n\n` +
                  `🎯 Videos de categorías variadas\n` +
                  `📊 Videos incluidos: ${downloadedFiles.length}\n` +
                  `📦 Tamaño: ${sizeMB} MB\n\n` +
                  `✨ _Videos compilados exitosamente_`
                : `🎬 *Compilación de TikToks*\n\n` +
                  `📝 Búsqueda: "${args.join(' ')}"\n` +
                  `📊 Videos incluidos: ${downloadedFiles.length}\n` +
                  `📦 Tamaño: ${sizeMB} MB\n\n` +
                  `✨ _Videos compilados exitosamente_`;
            
            await conn.sendMessage(
                message.from,
                {
                    video: { url: outputPath },
                    mimetype: 'video/mp4',
                    caption: caption
                },
                { quoted: message._baileyMessage }
            );
        }

        // Limpiar archivos temporales
        setTimeout(() => {
            try {
                fs.rmSync(tempDir, { recursive: true, force: true });
                console.log('[TIKTOKS] Archivos temporales eliminados');
            } catch (error) {
                console.error('[TIKTOKS] Error al limpiar:', error);
            }
        }, 5000);

    } catch (error) {
        console.error('[TIKTOKS] Error general:', error.message);
        await message.reply(
            `❌ *Error al crear la compilación*\n\n` +
            `Posibles causas:\n` +
            `• FFmpeg no está instalado en el servidor\n` +
            `• Problemas de conectividad con la API\n` +
            `• Videos no disponibles o privados\n\n` +
            `_Intenta de nuevo en unos minutos._`
        );
    } finally {
        enDescargaCompilacion.delete(sender);
    }
};

// Configuración y Exportación de los Handlers
handlerTikTokDownload.help = ['tiktok <enlace>'];
handlerTikTokDownload.tags = ['download'];
handlerTikTokDownload.command = /^(tiktok)$/i;

handlerTikTokSearch.help = ['ttsearch <titulo>'];
handlerTikTokSearch.tags = ['search'];
handlerTikTokSearch.command = /^(ttsearch)$/i;

handlerTikTokCompilation.help = ['tiktoks <palabras clave o random>'];
handlerTikTokCompilation.tags = ['compilation'];
handlerTikTokCompilation.command = /^(tiktoks)$/i;

// Exportamos los tres handlers
module.exports.tiktok = handlerTikTokDownload;
module.exports.ttsearch = handlerTikTokSearch;
module.exports.tiktoks = handlerTikTokCompilation;