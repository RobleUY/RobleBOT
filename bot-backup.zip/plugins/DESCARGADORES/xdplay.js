const axios = require('axios')
const fs = require('fs')
const path = require('path')
const yts = require('yt-search')

const API = 'https://www.sankavollerei.com/download/ytmp3?apikey=planaai&url='

const sanitizeFilename = (name='audio') =>
String(name).replace(/[\\/:*?"<>|]/g,'').slice(0,200)

async function searchYouTube(query){
let r = await yts(query)
if(!r.videos.length) throw 'No se encontró el video'
return r.videos[0]
}

let handler = async (m,{conn,text,usedPrefix,command}) => {

if(!text){
return m.reply(`❌ Envia un link o nombre

Ejemplo:
${usedPrefix+command} bad bunny amorfoda
${usedPrefix+command} https://youtu.be/xxxx`)
}

let video
let url = text

try{

if(!text.includes('youtube.com') && !text.includes('youtu.be')){
m.reply("🔎 Buscando en YouTube...")
video = await searchYouTube(text)
url = video.url
}

m.reply("⬇️ Descargando audio...")

const api = API + encodeURIComponent(url)
const res = await axios.get(api)

if(!res.data.status) throw 'API sin resultado'

const data = res.data.result
const download = data.download
const title = data.title || 'audio'
const thumb = data.thumbnail

const tempDir = path.join(__dirname,'../tmp')
if(!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)

const filePath = path.join(tempDir,sanitizeFilename(title)+'.mp3')

const audio = await axios.get(download,{
responseType:'arraybuffer',
headers:{
'User-Agent':'Mozilla/5.0',
'Referer':'https://www.youtube.com/'
}
})

fs.writeFileSync(filePath,audio.data)

if(thumb){
await conn.sendMessage(m.chat,{
image:{url:thumb},
caption:`🎵 ${title}`
},{quoted:m})
}

await conn.sendMessage(m.chat,{
audio:fs.readFileSync(filePath),
mimetype:'audio/mpeg',
fileName:sanitizeFilename(title)+'.mp3'
},{quoted:m})

fs.unlinkSync(filePath)

}catch(e){
console.log(e)
m.reply('❌ Error descargando el audio')
}

}

handler.help = ['xzplay <link o busqueda>']
handler.tags = ['audio']
handler.command = /^(xzplay)$/i

module.exports = handler