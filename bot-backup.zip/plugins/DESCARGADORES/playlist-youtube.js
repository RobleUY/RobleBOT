const fs = require('fs')
const path = require('path')
const axios = require('axios')
const yts = require('yt-search')
const { execFile } = require('child_process')
const { promisify } = require('util')
const downloadUtils = require('../../downloadUtils')
const { downloadWithLimit, cleanupTempFile, TEMP_DIR } = downloadUtils
const downloadYouTubeMedia = typeof downloadUtils.downloadYouTubeMedia === 'function'
  ? downloadUtils.downloadYouTubeMedia
  : async (url, format, timeout = 60000) => {
      if (format !== 'ytmp3' && format !== 'ytmp4') {
        throw new Error(`Formato de descarga de YouTube no soportado: ${format}`)
      }
      const response = await axios.get(
        `https://robleapi.vercel.app/download/${format}?url=${encodeURIComponent(url)}`,
        { timeout }
      )
      const data = response.data
      if (!data?.ok || typeof data.download_url !== 'string' || !data.download_url) {
        throw new Error(`RobleAPI no devolvió un enlace válido para ${format}`)
      }
      return {
        download: data.download_url,
        title: data.title || (format === 'ytmp3' ? 'Audio' : 'Video'),
        source: 'RobleAPI'
      }
    }
const execFileAsync = promisify(execFile)

// ========================================
// CONFIGURACIÓN
// ========================================
const COMANDO_ACTIVADO = true
const LIMIT_MB_AUDIO = 100
const LIMIT_MB_VIDEO = 300
const TIMEOUT_MS = 60000
const YT_API_KEY = process.env.YOUTUBE_API_KEY || '';
const PLAYLIST_FILE = path.join(__dirname, '../../data/playlist_usuarios.json')
const MAX_ITEMS_POR_PLAYLIST = 50
const MAX_PLAYLISTS_POR_USUARIO = 10

// ========================================
// PERSISTENCIA
// ========================================

function loadPlaylists() {
  try {
    if (!fs.existsSync(PLAYLIST_FILE)) {
      fs.writeFileSync(PLAYLIST_FILE, '{}', 'utf8')
      return {}
    }
    return JSON.parse(fs.readFileSync(PLAYLIST_FILE, 'utf8'))
  } catch (e) {
    console.error('[PLAYLIST] Error leyendo playlist_usuarios.json:', e.message)
    return {}
  }
}

function savePlaylists(data) {
  try {
    fs.writeFileSync(PLAYLIST_FILE, JSON.stringify(data, null, 2), 'utf8')
  } catch (e) {
    console.error('[PLAYLIST] Error guardando playlist_usuarios.json:', e.message)
  }
}

function getUserPlaylists(data, userId) {
  if (!data[userId]) data[userId] = {}
  return data[userId]
}

// ========================================
// INFO DE YOUTUBE
// ========================================

function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function parseISODuration(iso) {
  if (!iso) return null
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return null
  const h = parseInt(m[1] || '0', 10)
  const min = parseInt(m[2] || '0', 10)
  const s = parseInt(m[3] || '0', 10)
  const pad = n => String(n).padStart(2, '0')
  return h > 0 ? `${h}:${pad(min)}:${pad(s)}` : `${min}:${pad(s)}`
}

function buildInfo(videoId, snippet, contentDetails) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url || thumbs.standard?.url || thumbs.high?.url ||
    thumbs.medium?.url || thumbs.default?.url || null
  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl,
    duration: parseISODuration(contentDetails?.duration)
  }
}

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró video en Data API')
  return buildInfo(videoId, item.snippet, item.contentDetails)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=id&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item?.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return await getVideoInfoById(item.id.videoId)
}

async function searchVideoInfoByHtml(query) {
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  return await getVideoInfoById(match[1])
}

async function resolveVideoInfoFast(text) {
  const isLink = /https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)
  const tasks = []

  if (YT_API_KEY) {
    tasks.push(
      isLink
        ? getVideoInfoById(extractVideoId(text)).catch(e => { throw e })
        : searchVideoInfo(text).catch(e => { throw e })
    )
  }

  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return { videoId: v.videoId || null, title: v.title, url: v.url, thumbnailUrl: v.thumbnail || null, duration: v.timestamp || null }
    })()
  )

  try {
    return await Promise.any(tasks)
  } catch {
    if (!isLink) {
      try { return await searchVideoInfoByHtml(text) } catch {}
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ========================================
// DESCARGA DE AUDIO
// ========================================

async function downloadPlaylistAudio(url) {
  return downloadYouTubeMedia(url, 'ytmp3', TIMEOUT_MS)
}

function isValidAudioBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 50 * 1024) return false
  if (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33) return true
  if (buffer[0] === 0xFF && (buffer[1] === 0xFB || buffer[1] === 0xF3 || buffer[1] === 0xF2)) return true
  if (buffer.length > 500 * 1024) return true
  return false
}

async function getWorkingAudio(url) {
  const data = await downloadPlaylistAudio(url)
  const downloadData = await downloadWithLimit(data.download, LIMIT_MB_AUDIO)
  if (!isValidAudioBuffer(downloadData.buffer)) {
    throw new Error('RobleAPI: downloaded audio buffer is invalid or too small')
  }

  console.log(`[PLAYLIST] Audio: RobleAPI (${downloadData.sizeMB} MB)`)
  return { ...data, downloadData }
}

// ========================================

async function downloadPlaylistVideo(url) {
  return downloadYouTubeMedia(url, 'ytmp4', TIMEOUT_MS)
}

function isValidVideoBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 100 * 1024) return false
  if (buffer.length >= 8 && buffer[4] === 0x66 && buffer[5] === 0x74 && buffer[6] === 0x79 && buffer[7] === 0x70) return true
  if (buffer[0] === 0x00 && buffer[1] === 0x00 && buffer[2] === 0x00 && buffer[3] >= 0x08) return true
  if (buffer.length > 1024 * 1024) return true
  return false
}

async function fixVideoForMobile(inputBuffer) {
  const inputPath = path.join(TEMP_DIR, `pl_in_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  const outputPath = path.join(TEMP_DIR, `pl_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  try {
    fs.writeFileSync(inputPath, inputBuffer)
    // Intento 1: remux sin recodificar (rápido)
    try {
      await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-c', 'copy', '-movflags', '+faststart', outputPath], { windowsHide: true, timeout: 30_000 })
      const fixed = fs.readFileSync(outputPath)
      if (fixed.length > 50 * 1024) return fixed
    } catch {
      try { fs.unlinkSync(outputPath) } catch {}
    }
    // Intento 2: recodificar H.264/AAC
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-c:v', 'libx264', '-c:a', 'aac',
      '-movflags', '+faststart', '-preset', 'fast', '-crf', '28',
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      outputPath
    ], { windowsHide: true, timeout: 120_000 })
    return fs.readFileSync(outputPath)
  } finally {
    try { fs.unlinkSync(inputPath) } catch {}
    try { fs.unlinkSync(outputPath) } catch {}
  }
}

async function getWorkingVideo(url) {
  const data = await downloadPlaylistVideo(url)
  const downloadData = await downloadWithLimit(data.download, LIMIT_MB_VIDEO)
  if (!isValidVideoBuffer(downloadData.buffer)) {
    throw new Error('RobleAPI: downloaded video buffer is invalid or too small')
  }

  console.log(`[PLAYLIST] Video: RobleAPI (${downloadData.sizeMB} MB)`)
  return { ...data, downloadData }
}

// ========================================

// UTILIDADES
// ========================================

const sanitizeFilename = (name = 'media') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 150)

// ========================================
// SUBCOMANDOS
// ========================================

async function cmdCrear(message, userId, nombre) {
  if (!nombre || !/^[a-zA-Z0-9_\-áéíóúÁÉÍÓÚñÑ]+$/.test(nombre)) {
    return await message.reply('❌ El nombre debe ser una sola palabra sin espacios.\n*Ejemplo:* .playlist crear mimusica')
  }

  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (user[nombre]) return await message.reply(`❌ Ya tenés una playlist llamada *${nombre}*.`)
  if (Object.keys(user).length >= MAX_PLAYLISTS_POR_USUARIO) {
    return await message.reply(`❌ Límite de ${MAX_PLAYLISTS_POR_USUARIO} playlists por usuario alcanzado.`)
  }

  user[nombre] = { canciones: [], creadaEn: Date.now() }
  savePlaylists(data)

  await message.reply(
    `✅ Playlist *${nombre}* creada!\n\n` +
    `Agregá canciones con:\n*.playlist add ${nombre} artista - canción*`
  )
}

async function cmdAgregar(message, userId, nombre, query) {
  if (!nombre) return await message.reply('❌ Indicá el nombre de la playlist.\n*Ejemplo:* .playlist add mimusica duki - goteo')
  if (!query) return await message.reply(`❌ Indicá el nombre de la canción.\n*Ejemplo:* .playlist add ${nombre} duki - goteo`)

  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (!user[nombre]) {
    return await message.reply(`❌ No tenés una playlist llamada *${nombre}*.\nCreala con: *.playlist crear ${nombre}*`)
  }
  if (user[nombre].canciones.length >= MAX_ITEMS_POR_PLAYLIST) {
    return await message.reply(`❌ La playlist *${nombre}* ya tiene ${MAX_ITEMS_POR_PLAYLIST} canciones (máximo permitido).`)
  }

  await message.reply(`🔍 Buscando *${query}*...`)

  try {
    const info = await resolveVideoInfoFast(query)
    user[nombre].canciones.push({
      titulo: info.title,
      query,
      url: info.url,
      duration: info.duration || null,
      agregadaEn: Date.now()
    })
    savePlaylists(data)

    const num = user[nombre].canciones.length
    const durStr = info.duration ? ` ⏱️ ${info.duration}` : ''
    await message.reply(`✅ *#${num}. ${info.title}*${durStr}\nAgregada a *${nombre}* 🎵`)
  } catch (e) {
    console.error('[PLAYLIST ADD]', e.message)
    await message.reply(`❌ No se encontró ningún resultado para: *${query}*`)
  }
}

async function cmdVer(message, usedPrefix, isVideo, nombre, canciones) {
  const emoji = isVideo ? '🎬' : '🎵'
  const cmd = isVideo ? 'playlist2' : 'playlist'
  const cmdPrefix = usedPrefix + cmd

  if (!canciones.length) {
    return await message.reply(
      `📭 La playlist *${nombre}* está vacía.\n\n` +
      `Agregá canciones con:\n*.playlist add ${nombre} artista - canción*`
    )
  }

  const lista = canciones.map((c, i) => {
    const dur = c.duration ? ` ⏱️ ${c.duration}` : ''
    return `*${i + 1}.* ${c.titulo}${dur}`
  }).join('\n')

  await message.reply(
    `${emoji} *Playlist: ${nombre}*\n` +
    `📋 ${canciones.length} canción${canciones.length !== 1 ? 'es' : ''}\n\n` +
    `${lista}\n\n` +
    `▶️ Descargar: *${cmdPrefix} ${nombre} [número]*\n` +
    `🗑️ Borrar canción: *.playlist borrar ${nombre} [número]*`
  )
}

async function cmdDescargarAudio(message, sock, userId, nombre, numStr) {
  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (!user[nombre]) return await message.reply(`❌ No tenés una playlist llamada *${nombre}*.`)

  const canciones = user[nombre].canciones
  const num = parseInt(numStr, 10)
  if (isNaN(num) || num < 1 || num > canciones.length) {
    return await message.reply(`❌ Número inválido. La playlist *${nombre}* tiene ${canciones.length} canción${canciones.length !== 1 ? 'es' : ''}.`)
  }

  const cancion = canciones[num - 1]
  await message.reply(`📥 Descargando audio *#${num}. ${cancion.titulo}*...`)

  let tempFile = null
  try {
    const info = await resolveVideoInfoFast(cancion.url || cancion.query)

    const thumbTask = (async () => {
      try {
        if (info.thumbnailUrl) {
          await sock.sendMessage(message.from, {
            image: { url: info.thumbnailUrl },
            caption: `🎧 *${info.title}*\n📋 Playlist: *${nombre}* (${num}/${canciones.length})`
          }, { quoted: message._baileyMessage })
        }
      } catch (_) {}
    })()

    const audioTask = (async () => {
      const { source, downloadData } = await getWorkingAudio(info.url)
      tempFile = downloadData.tempFile
      await sock.sendMessage(message.from, {
        audio: downloadData.buffer,
        mimetype: 'audio/mpeg',
        fileName: sanitizeFilename(info.title || cancion.titulo) + '.mp3',
        ptt: false
      }, { quoted: message._baileyMessage })
      console.log(`[PLAYLIST] ✅ Audio enviado (${source}, ${downloadData.sizeMB} MB)`)
    })()

    await Promise.all([thumbTask, audioTask])

  } catch (e) {
    console.error('[PLAYLIST AUDIO]', e.message)
    await message.reply(`❌ No se pudo descargar *${cancion.titulo}* en este momento.`)
  } finally {
    if (tempFile) cleanupTempFile(tempFile)
  }
}

async function cmdDescargarVideo(message, sock, userId, nombre, numStr) {
  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (!user[nombre]) return await message.reply(`❌ No tenés una playlist llamada *${nombre}*.`)

  const canciones = user[nombre].canciones
  const num = parseInt(numStr, 10)
  if (isNaN(num) || num < 1 || num > canciones.length) {
    return await message.reply(`❌ Número inválido. La playlist *${nombre}* tiene ${canciones.length} canción${canciones.length !== 1 ? 'es' : ''}.`)
  }

  const cancion = canciones[num - 1]
  await message.reply(`📥 Descargando video *#${num}. ${cancion.titulo}*...`)

  let tempFile = null
  try {
    const info = await resolveVideoInfoFast(cancion.url || cancion.query)

    const thumbTask = (async () => {
      try {
        if (info.thumbnailUrl) {
          await sock.sendMessage(message.from, {
            image: { url: info.thumbnailUrl },
            caption:
              `🎬 *${info.title}*` +
              `${info.duration ? `\n⏱️ ${info.duration}` : ''}` +
              `\n📋 Playlist: *${nombre}* (${num}/${canciones.length})\n\n_Descargando video..._`
          }, { quoted: message._baileyMessage })
        }
      } catch (_) {}
    })()

    const videoTask = (async () => {
      const { source, downloadData } = await getWorkingVideo(info.url)
      tempFile = downloadData.tempFile

      let videoBuffer = downloadData.buffer
      try {
        videoBuffer = await fixVideoForMobile(videoBuffer)
      } catch (fixErr) {
        console.warn(`[PLAYLIST] Fix móvil falló: ${fixErr.message}`)
      }

      await sock.sendMessage(message.from, {
        video: videoBuffer,
        mimetype: 'video/mp4',
        fileName: sanitizeFilename(info.title || cancion.titulo) + '.mp4',
        caption: `🎬 *${info.title || cancion.titulo}*`
      }, { quoted: message._baileyMessage })

      console.log(`[PLAYLIST] ✅ Video enviado (${source}, ${downloadData.sizeMB} MB)`)
    })()

    await Promise.all([thumbTask, videoTask])

  } catch (e) {
    console.error('[PLAYLIST VIDEO]', e.message)
    if (e.message?.startsWith('LIMIT_EXCEEDED:')) {
      const sizeMB = e.message.split(':')[1]
      return await message.reply(`❌ *El video es demasiado grande* (${sizeMB} MB)\nLímite: ${LIMIT_MB_VIDEO} MB`)
    }
    await message.reply(`❌ No se pudo descargar *${cancion.titulo}* en este momento.`)
  } finally {
    if (tempFile) cleanupTempFile(tempFile)
  }
}

async function cmdBorrarCancion(message, userId, nombre, numStr) {
  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (!user[nombre]) return await message.reply(`❌ No tenés una playlist llamada *${nombre}*.`)

  const canciones = user[nombre].canciones
  const num = parseInt(numStr, 10)
  if (isNaN(num) || num < 1 || num > canciones.length) {
    return await message.reply(`❌ Número inválido. Usá *.playlist ${nombre}* para ver la lista.`)
  }

  const eliminada = canciones.splice(num - 1, 1)[0]
  savePlaylists(data)
  await message.reply(`🗑️ Se eliminó *#${num}. ${eliminada.titulo}* de la playlist *${nombre}*.`)
}

async function cmdBorrarPlaylist(message, userId, nombre) {
  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)

  if (!user[nombre]) return await message.reply(`❌ No tenés una playlist llamada *${nombre}*.`)

  const total = user[nombre].canciones.length
  delete user[nombre]
  savePlaylists(data)
  await message.reply(`🗑️ Playlist *${nombre}* eliminada (tenía ${total} canción${total !== 1 ? 'es' : ''}).`)
}

async function cmdMisPlaylists(message, userId) {
  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)
  const nombres = Object.keys(user)

  if (!nombres.length) {
    return await message.reply('📭 No tenés ninguna playlist todavía.\n\nCreá una con: *.playlist crear nombre*')
  }

  const lista = nombres.map(n => `🎵 *${n}* — ${user[n].canciones.length} canción${user[n].canciones.length !== 1 ? 'es' : ''}`).join('\n')
  await message.reply(
    `📋 *Tus playlists:*\n\n${lista}\n\n` +
    `_Usá *.playlist [nombre]* para ver las canciones._\n` +
    `_Usá *.playlist2 [nombre] [nro]* para descargar como video._`
  )
}

// ========================================
// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  if (!COMANDO_ACTIVADO) return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*')

  // Detectar si es el comando de video (.playlist2 / .pl2)
  const isVideo = /^(playlist2|pl2)$/i.test(command)
  const cmdAudio = usedPrefix + 'playlist'
  const cmdVideo = usedPrefix + 'playlist2'

  if (!text) {
    return await message.reply(
      `${isVideo ? '🎬' : '🎵'} *SISTEMA DE PLAYLISTS${isVideo ? ' (VIDEO)' : ''}*\n\n` +
      `📌 *Crear:* ${cmdAudio} crear [nombre]\n` +
      `➕ *Agregar:* ${cmdAudio} add [nombre] artista - canción\n` +
      `📋 *Ver lista:* ${cmdAudio} [nombre]\n` +
      `🎧 *Descargar audio:* ${cmdAudio} [nombre] [número]\n` +
      `🎬 *Descargar video:* ${cmdVideo} [nombre] [número]\n` +
      `🗑️ *Borrar canción:* ${cmdAudio} borrar [nombre] [número]\n` +
      `❌ *Eliminar playlist:* ${cmdAudio} eliminar [nombre]\n` +
      `📂 *Mis playlists:* ${cmdAudio} mis\n\n` +
      `*Ejemplo:*\n` +
      `${cmdAudio} crear mimusica\n` +
      `${cmdAudio} add mimusica duki - goteo\n` +
      `${cmdAudio} mimusica\n` +
      `${cmdAudio} mimusica 1  ← descarga audio\n` +
      `${cmdVideo} mimusica 1  ← descarga video`
    )
  }

  const userId = message.sender || message.from || ''
  const args = text.trim().split(/\s+/)
  const subcmd = args[0]?.toLowerCase()

  // ── Subcomandos de gestión (disponibles con cualquier variante del comando) ──

  if (subcmd === 'crear' || subcmd === 'create') {
    return await cmdCrear(message, userId, args[1])
  }
  if (subcmd === 'add' || subcmd === 'agregar') {
    return await cmdAgregar(message, userId, args[1], args.slice(2).join(' '))
  }
  if (subcmd === 'mis' || subcmd === 'mias' || subcmd === 'lista') {
    return await cmdMisPlaylists(message, userId)
  }
  if (subcmd === 'eliminar' || subcmd === 'delete') {
    if (!args[1]) return await message.reply('❌ Indicá el nombre.\n*Ejemplo:* .playlist eliminar mimusica')
    return await cmdBorrarPlaylist(message, userId, args[1])
  }
  if (subcmd === 'borrar' || subcmd === 'remove' || subcmd === 'quitar') {
    if (!args[1] || !args[2]) return await message.reply('❌ Uso: *.playlist borrar [nombre] [número]*')
    return await cmdBorrarCancion(message, userId, args[1], args[2])
  }

  // ── .playlist nombreplaylist [numero?]  o  .playlist2 nombreplaylist numero ──

  const data = loadPlaylists()
  const user = getUserPlaylists(data, userId)
  const nombrePlaylist = args[0]

  if (!user[nombrePlaylist]) {
    return await message.reply(
      `❓ No se reconoció el comando *${subcmd}*.\n\n` +
      `Escribí *${isVideo ? cmdVideo : cmdAudio}* sin nada para ver la ayuda.`
    )
  }

  // Con número: descargar
  if (args[1]) {
    return isVideo
      ? await cmdDescargarVideo(message, sock, userId, nombrePlaylist, args[1])
      : await cmdDescargarAudio(message, sock, userId, nombrePlaylist, args[1])
  }

  // Sin número: mostrar lista
  return await cmdVer(message, usedPrefix, isVideo, nombrePlaylist, user[nombrePlaylist].canciones)
}

handler.help = ['playlist <crear|add|mis|borrar|eliminar|nombre> ...']
handler.tags = ['audio', 'video']
handler.command = /^(playlist|pl|playlist2|pl2)$/i

module.exports = handler
