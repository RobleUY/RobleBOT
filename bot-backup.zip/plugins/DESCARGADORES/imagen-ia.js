const axios = require('axios')

// ============================================================
// IMPORTACIÓN DE @hiudyy/ytdl (Módulo AI)
// ============================================================
let aiModule = null
try {
  const ytdl = require('@hiudyy/ytdl')
  aiModule = ytdl.ai || ytdl.default?.ai
} catch (e) {
  console.warn('[IMAGENIA] @hiudyy/ytdl no disponible:', e.message)
}

const BROWSER_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
}

async function descargarImagenBuffer(url) {
  try {
    const res = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 25000,
      headers: BROWSER_HEADERS
    })
    return Buffer.from(res.data)
  } catch (err) {
    console.error('[IMAGENIA] Error descargando buffer de imagen:', err.message)
    return null
  }
}

function extractImageFromResponse(response) {
  if (!response) return null
  if (typeof response === 'string') return response
  if (Buffer.isBuffer(response)) return response
  if (Array.isArray(response) && response.length > 0) {
    return response[0]?.src || response[0]?.url || response[0]
  }
  if (typeof response === 'object') {
    return response.src || response.url || response.result || response.data
  }
  return null
}

// ============================================================
// LÓGICA DE GENERACIÓN CON MOTORES DE ALTA CALIDAD (FLUX 1.0)
// ============================================================
async function generarImagenIA(prompt) {
  // 1. Intentar con @hiudyy/ytdl (ai.image)
  if (aiModule && typeof aiModule.image === 'function') {
    try {
      console.log('[IMAGENIA] Intentando generar con @hiudyy/ytdl ai.image...')
      const response = await aiModule.image(prompt)
      const imgSource = extractImageFromResponse(response)
      if (imgSource) {
        if (Buffer.isBuffer(imgSource)) {
          console.log('[IMAGENIA] ✅ Generado con @hiudyy/ytdl (Buffer)')
          return imgSource
        }
        const buffer = await descargarImagenBuffer(imgSource)
        if (buffer && buffer.length > 5000) {
          console.log('[IMAGENIA] ✅ Generado con @hiudyy/ytdl (URL downloaded)')
          return buffer
        }
      }
    } catch (err) {
      console.warn(`[IMAGENIA] @hiudyy/ytdl ai.image falló (${err.message}), activando motor de alta calidad...`)
    }
  }

  // 2. Respaldo Alta Calidad: Delirius Flux AI (Black Forest Labs FLUX.1)
  try {
    console.log('[IMAGENIA] Intentando generar con motor Delirius Flux.1...')
    const deliriusUrl = `https://api.delirius.store/ia/flux?prompt=${encodeURIComponent(prompt)}`
    const res = await axios.get(deliriusUrl, { timeout: 25000 })
    const imageUrl = res.data?.image || res.data?.url || res.data?.result || res.data?.data
    if (imageUrl) {
      const buffer = await descargarImagenBuffer(imageUrl)
      if (buffer && buffer.length > 5000) {
        console.log('[IMAGENIA] ✅ Generado exitosamente con Delirius Flux.1')
        return buffer
      }
    }
  } catch (err) {
    console.warn('[IMAGENIA] Motor Delirius Flux.1 falló:', err.message)
  }

  // 3. Respaldo Alta Calidad: Pollinations con modelo FLUX.1 (HD Realismo)
  try {
    console.log('[IMAGENIA] Intentando generar con motor Pollinations FLUX.1...')
    const seed = Math.floor(Math.random() * 1000000)
    // Se fuerza el modelo 'flux' de máxima definición y realismo
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1080&height=1080&model=flux&nologo=true&enhance=true&seed=${seed}`
    const buffer = await descargarImagenBuffer(pollinationsUrl)
    if (buffer && buffer.length > 5000) {
      console.log('[IMAGENIA] ✅ Generado exitosamente con Pollinations FLUX.1 HD')
      return buffer
    }
  } catch (err) {
    console.warn('[IMAGENIA] Motor Pollinations FLUX.1 falló:', err.message)
  }

  // 4. Respaldo 4: Pollinations Flux-Realism
  try {
    console.log('[IMAGENIA] Intentando generar con motor Pollinations Flux-Realism...')
    const seed = Math.floor(Math.random() * 1000000)
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1080&height=1080&model=flux-realism&nologo=true&seed=${seed}`
    const buffer = await descargarImagenBuffer(pollinationsUrl)
    if (buffer && buffer.length > 5000) {
      console.log('[IMAGENIA] ✅ Generado exitosamente con Pollinations Flux-Realism')
      return buffer
    }
  } catch (err) {
    console.warn('[IMAGENIA] Motor Pollinations Flux-Realism falló:', err.message)
  }

  throw new Error('Servicio de IA no disponible temporalmente en las fuentes actuales. Intenta de nuevo en un momento.')
}

// ============================================================
// HANDLER PRINCIPAL (.imagenia / .imgia)
// ============================================================
let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn

  if (!text) {
    return message.reply(
      `❌ *Ingresa una descripción para generar la imagen.*\n\n` +
      `*Ejemplo:*\n` +
      `• ${usedPrefix + command} un gato astronauta en el espacio`
    )
  }

  try {
    await message.reply('🎨 Generando imagen con IA (FLUX HD)...')

    const imageBuffer = await generarImagenIA(text.trim())

    const caption = `🎨 *Imagen Generada por IA (FLUX HD)*\n\n📝 *Prompt:* ${text.trim()}`

    await sock.sendMessage(
      message.from,
      {
        image: imageBuffer,
        caption
      },
      { quoted: message._baileyMessage }
    )

    console.log(`[IMAGENIA] ✅ Imagen enviada a WhatsApp exitosamente`)

  } catch (error) {
    console.error('[IMAGENIA ERROR]', error)
    await message.reply(
      `❌ *Ocurrió un error al generar la imagen con IA*\n\n` +
      `_Detalle: ${error?.message || error}_`
    )
  }
}

// ============================================================
// CONFIGURACIÓN DEL COMANDO
// ============================================================
handler.help = ['imagenia <descripción>', 'imgia <descripción>']
handler.tags = ['ia', 'descargas']
handler.command = /^(imagenia|iaimagen|imgia|imagenai|iaimg)$/i

module.exports = handler
