/**
 * Comando SerBot - Genera QR para vincular como subbot
 * Uso: .serbot
 */

const { createSubbotQR, getSubbotsList, removeSubbot, isSubbot } = require('../subbots');

let handler = async (message, { text, args, usedPrefix }) => {
    try {
        const sender = message.author || message.sender;
        const senderNumber = sender.split('@')[0].split(':')[0];
        const chatJid = message.from;
        
        // Verificar si es owner
        const isOwner = global.botConfig?.isOwner(senderNumber);
        
        if (!isOwner) {
            return await message.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
        }
        
        // Subcomandos
        const subCommand = args[0]?.toLowerCase();
        
        // Listar subbots
        if (subCommand === 'list' || subCommand === 'lista') {
            const subbots = getSubbotsList();
            
            if (subbots.length === 0) {
                return await message.reply('📋 *Lista de SubBots*\n\nNo hay subbots registrados.');
            }
            
            let listText = '📋 *Lista de SubBots*\n\n';
            subbots.forEach((bot, index) => {
                const status = bot.active ? '🟢 Activo' : '🔴 Desconectado';
                listText += `${index + 1}. +${bot.number} - ${status}\n`;
            });
            
            return await message.reply(listText);
        }
        
        // Eliminar subbot
        if (subCommand === 'del' || subCommand === 'eliminar' || subCommand === 'remove') {
            const number = args[1]?.replace(/[^0-9]/g, '');
            
            if (!number) {
                return await message.reply(`⚠️ Especifica el número a eliminar.\n\nUso: ${usedPrefix}serbot del <número>`);
            }
            
            if (!isSubbot(number)) {
                return await message.reply(`⚠️ El número +${number} no es un subbot registrado.`);
            }
            
            removeSubbot(number);
            return await message.reply(`✅ SubBot +${number} eliminado correctamente.`);
        }
        
        // Generar QR para vincular
        await message.reply(
            `🤖 *SerBot - Vinculación por QR*\n\n` +
            `⏳ Generando código QR...\n\n` +
            `📱 Cuando aparezca el QR:\n` +
            `1. Abre WhatsApp en el teléfono del subbot\n` +
            `2. Ve a ⚙️ Configuración > Dispositivos vinculados\n` +
            `3. Toca "Vincular dispositivo"\n` +
            `4. Escanea el código QR\n\n` +
            `⏰ El QR expira en ~60 segundos`
        );
        
        // ID único para esta sesión de vinculación
        const subbotId = `new_${Date.now()}`;
        
        // Crear QR
        createSubbotQR(
            subbotId,
            chatJid,
            // onQR - cuando se genera un QR
            async (qrBuffer, qrCount) => {
                try {
                    await global.conn.sendMessage(chatJid, {
                        image: qrBuffer,
                        caption: `📱 *Código QR #${qrCount}*\n\nEscanea este código con WhatsApp.\n\n⏰ Si expira, se generará uno nuevo automáticamente.`
                    });
                } catch (e) {
                    console.error('[SerBot] Error enviando QR:', e.message);
                }
            },
            // onSuccess - cuando se vincula exitosamente
            async (subbotNumber) => {
                try {
                    await global.conn.sendMessage(chatJid, {
                        text: `✅ *SubBot Vinculado Exitosamente*\n\n` +
                              `📱 Número: +${subbotNumber}\n\n` +
                              `El subbot ya está activo y responderá en grupos donde no esté el bot principal.\n\n` +
                              `📋 Usa *${usedPrefix}serbot list* para ver todos los subbots.`
                    });
                } catch (e) {
                    console.error('[SerBot] Error enviando confirmación:', e.message);
                }
            },
            // onFail - cuando falla
            async (errorMsg) => {
                try {
                    await global.conn.sendMessage(chatJid, {
                        text: `❌ *Error de Vinculación*\n\n${errorMsg}\n\nIntenta de nuevo con *${usedPrefix}serbot*`
                    });
                } catch (e) {
                    console.error('[SerBot] Error enviando error:', e.message);
                }
            }
        );
        
    } catch (error) {
        console.error('[SerBot] Error general:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando.');
    }
};

handler.help = ['serbot', 'serbot list', 'serbot del <número>'];
handler.tags = ['owner'];
handler.command = /^(serbot|subbot)$/i;
handler.owner = true;

module.exports = handler;
