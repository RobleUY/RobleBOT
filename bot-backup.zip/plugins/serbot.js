/**
 * Comando SerBot - Genera código de 8 dígitos para vincular como subbot
 * Uso: .serbot <número>
 */

const { createPairingCode, getSubbotsList, removeSubbot, isSubbot } = require('../subbots');

let handler = async (message, { text, args, usedPrefix }) => {
    try {
        const sender = message.author || message.sender;
        const senderNumber = sender.split('@')[0].split(':')[0];
        
        // Verificar si es owner
        const isOwner = global.botConfig?.isOwner(senderNumber);
        
        if (!isOwner) {
            return await message.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
        }
        
        // Subcomandos
        const subCommand = args[0]?.toLowerCase();
        
        // Listar subbots
        if (subCommand === 'list' || subCommand === 'lista') {
            const subbots = getSubbotsList();
            
            if (subbots.length === 0) {
                return await message.reply('📋 *Lista de SubBots*\n\nNo hay subbots registrados.');
            }
            
            let listText = '📋 *Lista de SubBots*\n\n';
            subbots.forEach((bot, index) => {
                const status = bot.active ? '🟢 Activo' : '🔴 Desconectado';
                listText += `${index + 1}. +${bot.number} - ${status}\n`;
            });
            
            return await message.reply(listText);
        }
        
        // Eliminar subbot
        if (subCommand === 'del' || subCommand === 'eliminar' || subCommand === 'remove') {
            const number = args[1]?.replace(/[^0-9]/g, '');
            
            if (!number) {
                return await message.reply(`⚠️ Especifica el número a eliminar.\n\nUso: ${usedPrefix}serbot del <número>`);
            }
            
            if (!isSubbot(number)) {
                return await message.reply(`⚠️ El número +${number} no es un subbot registrado.`);
            }
            
            removeSubbot(number);
            return await message.reply(`✅ SubBot +${number} eliminado correctamente.`);
        }
        
        // Generar código de vinculación
        const phoneNumber = text?.replace(/[^0-9]/g, '');
        
        if (!phoneNumber || phoneNumber.length < 10) {
            return await message.reply(
                `🤖 *SerBot - Sistema de SubBots*\n\n` +
                `Genera un código de 8 dígitos para vincular un número como subbot.\n\n` +
                `*Uso:*\n` +
                `${usedPrefix}serbot <número>\n` +
                `${usedPrefix}serbot list\n` +
                `${usedPrefix}serbot del <número>\n\n` +
                `*Ejemplo:*\n` +
                `${usedPrefix}serbot 5491123456789\n\n` +
                `📱 El código generado se usa en WhatsApp Web:\n` +
                `1. Abre WhatsApp en el teléfono del subbot\n` +
                `2. Ve a Dispositivos vinculados\n` +
                `3. Selecciona "Vincular con número de teléfono"\n` +
                `4. Ingresa el código de 8 dígitos`
            );
        }
        
        // Verificar si ya es subbot
        if (isSubbot(phoneNumber)) {
            return await message.reply(
                `⚠️ El número +${phoneNumber} ya está registrado como subbot.\n\n` +
                `Si deseas regenerar el código, primero elimínalo con:\n` +
                `${usedPrefix}serbot del ${phoneNumber}`
            );
        }
        
        await message.reply(
            `⏳ *Generando código de vinculación...*\n\n` +
            `Número: +${phoneNumber}\n\n` +
            `Por favor espera unos segundos...`
        );
        
        try {
            const pairingCode = await createPairingCode(phoneNumber, senderNumber);
            
            // Formatear código con guiones para mejor legibilidad
            const formattedCode = pairingCode.match(/.{1,4}/g).join('-');
            
            await message.reply(
                `✅ *Código de Vinculación Generado*\n\n` +
                `📱 Número: +${phoneNumber}\n` +
                `🔑 Código: *${formattedCode}*\n\n` +
                `*Instrucciones:*\n` +
                `1. Abre WhatsApp en el teléfono +${phoneNumber}\n` +
                `2. Ve a ⚙️ Configuración > Dispositivos vinculados\n` +
                `3. Toca "Vincular dispositivo"\n` +
                `4. Selecciona "Vincular con número de teléfono"\n` +
                `5. Ingresa el código: *${formattedCode}*\n\n` +
                `⏰ El código expira en 5 minutos.\n\n` +
                `💡 Una vez vinculado, el subbot responderá automáticamente en grupos donde no esté el bot principal.`
            );
            
        } catch (error) {
            console.error('[SerBot] Error:', error);
            await message.reply(
                `❌ *Error al generar código*\n\n` +
                `${error.message}\n\n` +
                `Posibles causas:\n` +
                `• El número no tiene WhatsApp\n` +
                `• El número ya está vinculado\n` +
                `• Error de conexión\n\n` +
                `Intenta nuevamente en unos minutos.`
            );
        }
        
    } catch (error) {
        console.error('[SerBot] Error general:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando.');
    }
};

handler.help = ['serbot <número>', 'serbot list', 'serbot del <número>'];
handler.tags = ['owner'];
handler.command = /^(serbot|subbot|vincular)$/i;
handler.owner = true;

module.exports = handler;
