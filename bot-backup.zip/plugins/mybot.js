const command = /^(mybot|mibot)$/i;
const help = 'Muestra si estás interactuando con el Bot Principal o un Sub-Bot';
const tags = ['subbots'];

async function handler(message, { conn }) {
    // Si el mensaje tiene la propiedad _subNum, significa que fue procesado por un sub-bot
    if (message._subNum) {
        await message.reply(
            `🤖 *Estás interactuando con un Sub-Bot*\n\n` +
            `🔹 *ID de este Sub-Bot:* #${message._subNum}`
        );
    } else {
        // Si no la tiene, es el bot principal
        await message.reply(
            `👑 *Estás interactuando con el Bot Principal*`
        );
    }
}

module.exports = { command, help, tags, handler };