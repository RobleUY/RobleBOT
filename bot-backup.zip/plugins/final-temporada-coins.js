const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON de temporadas (mismo directorio que el plugin)
const TEMPORADAS_FILE = path.join(__dirname, 'temporadas_coins.json');

// Función para cargar datos de temporadas
function loadTemporadas() {
    try {
        if (fs.existsSync(TEMPORADAS_FILE)) {
            const data = fs.readFileSync(TEMPORADAS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error al cargar temporadas:', error);
    }
    return { temporadaActual: 0, temporadas: {} };
}

// Función para guardar datos de temporadas
function saveTemporadas(data) {
    try {
        const dir = path.dirname(TEMPORADAS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(TEMPORADAS_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error al guardar temporadas:', error);
        return false;
    }
}

// Función para obtener el apodo actual de un usuario
function getApodoActual(userNumber) {
    const allUsers = global.db.data.users || {};
    const userData = allUsers[userNumber];
    return (userData && userData.apodo && userData.apodo.trim() !== '') 
        ? userData.apodo 
        : 'Sin apodo';
}

let handler = async (message, { conn }) => {
    try {
        // Obtener todos los usuarios
        const allUsers = global.db.data.users || {};
        
        // Crear array con TODOS los usuarios y sus coins totales
        const usersWithCoins = [];
        
        for (let [number, userData] of Object.entries(allUsers)) {
            const totalCoins = (userData.money || 0) + (userData.bank || 0);
            usersWithCoins.push({
                number: number,
                totalCoins: totalCoins
            });
        }
        
        // Ordenar por coins (mayor a menor)
        usersWithCoins.sort((a, b) => b.totalCoins - a.totalCoins);
        
        if (usersWithCoins.length === 0) {
            return await message.reply('❌ No hay usuarios con coins para crear una temporada.');
        }
        
        // Cargar datos de temporadas
        const temporadasData = loadTemporadas();
        
        // Incrementar número de temporada
        temporadasData.temporadaActual += 1;
        const numeroTemporada = temporadasData.temporadaActual;
        
        // Inicializar temporada si no existe
        if (!temporadasData.temporadas[numeroTemporada]) {
            temporadasData.temporadas[numeroTemporada] = {};
        }
        
        // Guardar posiciones de TODOS los usuarios SOLO EN EL JSON (SIN APODO)
        for (let i = 0; i < usersWithCoins.length; i++) {
            const user = usersWithCoins[i];
            const position = i + 1;
            
            // Guardar SOLO en el JSON de temporadas (sin apodo)
            temporadasData.temporadas[numeroTemporada][user.number] = {
                posicion: position,
                coins: user.totalCoins
            };
        }
        
        // Obtener solo el top 10 para mostrar en el mensaje
        const top10 = usersWithCoins.slice(0, 10);
        
        // Crear mensaje solo con el top 10
        let resultMessage = `🏆 *FIN DE TEMPORADA ${numeroTemporada}* 🏆\n\n`;
        resultMessage += `📊 *TOP 10 DE COINS*\n\n`;
        
        for (let i = 0; i < top10.length; i++) {
            const user = top10[i];
            const position = i + 1;
            
            // Emojis según posición
            let emoji = '';
            if (position === 1) emoji = '🥇';
            else if (position === 2) emoji = '🥈';
            else if (position === 3) emoji = '🥉';
            else emoji = `${position}º`;
            
            // Obtener apodo actual del usuario
            const apodoActual = getApodoActual(user.number);
            
            resultMessage += `${emoji} ${apodoActual}\n`;
            resultMessage += `💰 ${user.totalCoins.toLocaleString()} coins\n\n`;
        }
        
        // Guardar datos de temporadas en el JSON
        if (saveTemporadas(temporadasData)) {
            resultMessage += `✅ Temporada ${numeroTemporada} finalizada.\n`;
            resultMessage += `📜 Se guardaron ${usersWithCoins.length} usuarios en el ranking.`;
            
            // Crear array de menciones solo del top 10
            const mentions = top10.map(user => `${user.number}@s.whatsapp.net`);
            
            await message.reply(resultMessage, { mentions: mentions });
        } else {
            await message.reply('❌ Error al guardar los datos de la temporada.');
        }
        
    } catch (error) {
        console.error('Error en comando fintemporada:', error);
        await message.reply('❌ Ocurrió un error al finalizar la temporada.');
    }
};

handler.help = ['fintemporada'];
handler.tags = ['owner'];
handler.command = /^(fintemporada|fintempo)$/i;
handler.owner = true;

module.exports = handler;