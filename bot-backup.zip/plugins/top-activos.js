/**
 * top-activos.js
 * Muestra el top de usuarios más activos (por mensajes enviados) en el grupo actual.
 * Usa los datos de chatHistory.js (data/chats/chats-usuarios.db).
 *
 * Uso:
 *   .topactivos        → página 1 (primeros 10)
 *   .topactivos 2      → página 2, etc.
 */

'use strict';

const normalizeNumber = (jid) =>
    jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim();

const handler = async (message, { conn, args }) => {
    try {
        if (!message.isGroup)
            return await message.reply('❌ Este comando solo puede usarse en grupos.');

        const chatHistory = require('../chatHistory');
        if (!chatHistory.isReady)
            return await message.reply('❌ El historial de chat no está disponible aún.');

        const groupId    = message.from;
        const body       = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const cmdName    = (body.slice(1).trim().split(/\s+/)[0] || 'topactivos').toLowerCase();

        // ── Página solicitada ────────────────────────────────────────────────
        const pageArg = args && args[0] ? parseInt(args[0]) : 1;
        const page    = !isNaN(pageArg) && pageArg > 0 ? pageArg : 1;

        // ── Stats del grupo ──────────────────────────────────────────────────
        const stats = chatHistory.getGroupStats(groupId);
        if (!stats || stats.length === 0)
            return await message.reply('📊 Aún no hay mensajes registrados en este grupo.');

        // ── Obtener participantes reales del grupo para tener los JIDs exactos ──
        const metadata     = await conn.groupMetadata(groupId);
        const participants = metadata.participants; // [{ id: "numero@s.whatsapp.net", ... }]

        // Mapa numero_limpio → JID completo real
        const jidMap = new Map();
        for (const p of participants) {
            jidMap.set(normalizeNumber(p.id), p.id);
        }

        // ── Paginación ───────────────────────────────────────────────────────
        const total        = stats.length;
        const itemsPerPage = 10;
        const totalPages   = Math.max(1, Math.ceil(total / itemsPerPage));
        const currentPage  = Math.min(page, totalPages);

        // ── Posición del usuario que ejecuta ─────────────────────────────────
        const senderNum   = normalizeNumber(message.sender || message.author || '');
        const senderIndex = stats.findIndex(e => e.userId === senderNum);
        const senderPos   = senderIndex >= 0 ? senderIndex + 1 : 0;
        const senderPage  = senderPos > 0 ? Math.ceil(senderPos / itemsPerPage) : 0;

        // ── Slice de la página ───────────────────────────────────────────────
        const start     = (currentPage - 1) * itemsPerPage;
        const pageUsers = stats.slice(start, start + itemsPerPage);

        // ── JIDs reales para mentions (solo los de esta página) ──────────────
        const mentionJids = pageUsers
            .map(u => jidMap.get(u.userId))
            .filter(Boolean);

        // ── Construir mensaje ────────────────────────────────────────────────
        let text = `*🏆 TOP ACTIVOS DEL GRUPO 💬*\n\n`;
        text += `👥 *Total registrados:* ${total} usuarios\n`;

        if (senderPos > 0) {
            const senderJid = jidMap.get(senderNum);
            const senderTag = senderJid ? `@${normalizeNumber(senderJid)}` : `#${senderPos}`;
            text += `📍 *Tu posición:* #${senderPos} — ${senderTag} (Pág. ${senderPage})\n`;
            if (senderPage !== currentPage)
                text += `   ↳ Usa *${usedPrefix}${cmdName} ${senderPage}* para ir a tu página\n`;
        } else {
            text += `📍 *Tu posición:* No estás en el ranking aún\n`;
        }

        text += `\n_Página_ *${currentPage}* _de_ *${totalPages}*\n`;

        // Navegación entre páginas
        if (totalPages > 1) {
            const prev = currentPage > 1          ? currentPage - 1 : null;
            const next = currentPage < totalPages ? currentPage + 1 : null;
            text += `\n`;
            if (prev) text += `⬅️ *${usedPrefix}${cmdName} ${prev}* página anterior\n`;
            if (next) text += `➡️ *${usedPrefix}${cmdName} ${next}* siguiente página\n`;
        }

        text += `\n`;

        // ── Lista ────────────────────────────────────────────────────────────
        for (let i = 0; i < pageUsers.length; i++) {
            const u   = pageUsers[i];
            const pos = start + i + 1;

            let medal;
            if      (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else                medal = `${pos}.`;

            // Tiempo desde el último mensaje
            const diffMs  = Date.now() - (u.lastMsgTs || 0);
            const diffMin = Math.floor(diffMs / 60000);
            const diffH   = Math.floor(diffMin / 60);
            const diffD   = Math.floor(diffH / 24);

            let lastSeen;
            if      (diffD   > 0) lastSeen = `hace ${diffD}d`;
            else if (diffH   > 0) lastSeen = `hace ${diffH}h`;
            else if (diffMin > 0) lastSeen = `hace ${diffMin}min`;
            else                  lastSeen = 'ahora';

            // Usar JID real del mapa; si ya no está en el grupo poner solo el número
            const realJid = jidMap.get(u.userId);
            const tag     = realJid ? `@${normalizeNumber(realJid)}` : u.userId;

            text += `${medal} ${tag}\n`;
            text += `💬 ${u.msgCount.toLocaleString()} mensajes · 🕐 ${lastSeen}\n\n`;
        }

        await message.reply(text.trimEnd(), { mentions: mentionJids });

    } catch (error) {
        console.error('[TOPACTIVOS] Error:', error);
        await message.reply('⚠️ Error al obtener el top de activos.');
    }
};

handler.help    = ['topactivos'];
handler.tags    = ['grupos', 'stats'];
handler.command = /^topactivos$/i;
handler.group   = true;

module.exports = handler;
