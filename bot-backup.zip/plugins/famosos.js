const axios = require('axios');
const db = require('../database.js');
const premium = require('../premium');

const PRECIO_BASE_POR_ESTRELLA = 2500;

const imageCache = new Map();

async function buscarImagenFamoso(nombreFamoso, categoria) {
    const query = `${nombreFamoso} ${categoria} celebrity`;

    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://api.delirius.online/search/pinterest?text=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 10000 });

        if (!data?.status || !Array.isArray(data.results) || data.results.length === 0) {
            return null;
        }

        const imageUrl = data.results[Math.floor(Math.random() * data.results.length)];
        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`[Famosos] Error buscando imagen: ${error.message}`);
        return null;
    }
}

const FAMOSOS_BASE = [
    { nombre: 'Ilia Topuria', categoria: 'Deporte', descripcion: 'Luchador de artes marciales', calidad: '☆☆☆☆☆' },
    { nombre: 'Conor McGregor', categoria: 'Deporte', descripcion: 'Luchador de artes marciales', calidad: '☆☆☆☆☆' },
    { nombre: 'Charles Oliveira', categoria: 'Deporte', descripcion: 'Luchador de artes marciales', calidad: '☆☆☆☆☆' },
    { nombre: 'Michael Jackson', categoria: 'Música', descripcion: 'Rey del Pop', calidad: '☆☆☆☆☆' },
    { nombre: 'Madonna', categoria: 'Música', descripcion: 'Reina del Pop', calidad: '☆☆☆☆' },
    { nombre: 'Freddie Mercury', categoria: 'Música', descripcion: 'Vocalista de Queen', calidad: '☆☆☆☆' },
    { nombre: 'Elvis Presley', categoria: 'Música', descripcion: 'El Rey del Rock', calidad: '☆☆☆☆☆' },
    { nombre: 'David Bowie', categoria: 'Música', descripcion: 'El Camaleón del Rock', calidad: '☆☆☆' },
    { nombre: 'Taylor Swift', categoria: 'Música', descripcion: 'Cantautora pop country', calidad: '☆☆☆☆☆' },
    { nombre: 'Beyoncé', categoria: 'Música', descripcion: 'Reina de la música urbana', calidad: '☆☆☆☆' },
    { nombre: 'Shakira', categoria: 'Música', descripcion: 'Cantante colombiana', calidad: '☆☆☆☆' },
    { nombre: 'Bad Bunny', categoria: 'Música', descripcion: 'Rey del reggaetón', calidad: '☆☆☆☆' },
    { nombre: 'Drake', categoria: 'Música', descripcion: 'Rapero canadiense', calidad: '☆☆☆☆' },
    { nombre: 'Eminem', categoria: 'Música', descripcion: 'El Rey del Rap', calidad: '☆☆☆☆' },
    { nombre: 'Rihanna', categoria: 'Música', descripcion: 'Cantante de Barbados', calidad: '☆☆☆☆' },
    { nombre: 'Adele', categoria: 'Música', descripcion: 'Cantante británica', calidad: '☆☆☆☆' },
    { nombre: 'Ed Sheeran', categoria: 'Música', descripcion: 'Cantautor inglés', calidad: '☆☆☆' },
    { nombre: 'Lady Gaga', categoria: 'Música', descripcion: 'Cantante y actriz', calidad: '☆☆☆☆' },
    { nombre: 'Justin Bieber', categoria: 'Música', descripcion: 'Cantante canadiense', calidad: '☆☆☆☆' },
    { nombre: 'The Weeknd', categoria: 'Música', descripcion: 'Cantante canadiense R&B', calidad: '☆☆☆' },
    { nombre: 'Billie Eilish', categoria: 'Música', descripcion: 'Cantante pop alternativa', calidad: '☆☆☆' },
    { nombre: 'J Balvin', categoria: 'Música', descripcion: 'Cantante colombiano', calidad: '☆☆☆' },
    { nombre: 'Maluma', categoria: 'Música', descripcion: 'Cantante colombiano', calidad: '☆☆☆' },
    { nombre: 'Leonardo DiCaprio', categoria: 'Cine', descripcion: 'Actor de Hollywood', calidad: '☆☆☆☆☆' },
    { nombre: 'Meryl Streep', categoria: 'Cine', descripcion: 'La mejor actriz del mundo', calidad: '☆☆☆☆' },
    { nombre: 'Brad Pitt', categoria: 'Cine', descripcion: 'Actor de Hollywood', calidad: '☆☆☆☆' },
    { nombre: 'Angelina Jolie', categoria: 'Cine', descripcion: 'Actriz y directora', calidad: '☆☆☆☆' },
    { nombre: 'Tom Hanks', categoria: 'Cine', descripcion: 'Ícono del cine americano', calidad: '☆☆☆☆' },
    { nombre: 'Scarlett Johansson', categoria: 'Cine', descripcion: 'Actriz de Marvel', calidad: '☆☆☆☆' },
    { nombre: 'Robert Downey Jr', categoria: 'Cine', descripcion: 'Iron Man', calidad: '☆☆☆☆' },
    { nombre: 'Keanu Reeves', categoria: 'Cine', descripcion: 'Actor y celebridad de internet', calidad: '☆☆☆☆' },
    { nombre: 'Will Smith', categoria: 'Cine', descripcion: 'Actor y rapero', calidad: '☆☆☆☆' },
    { nombre: 'Dwayne Johnson', categoria: 'Cine', descripcion: 'The Rock', calidad: '☆☆☆☆' },
    { nombre: 'Johnny Depp', categoria: 'Cine', descripcion: 'Actor ecléctico', calidad: '☆☆☆☆' },
    { nombre: 'Jennifer Lawrence', categoria: 'Cine', descripcion: 'Actriz ganadora del Oscar', calidad: '☆☆☆' },
    { nombre: 'Morgan Freeman', categoria: 'Cine', descripcion: 'Legendario actor americano', calidad: '☆☆☆☆' },
    { nombre: 'Denzel Washington', categoria: 'Cine', descripcion: 'Actor galardonado', calidad: '☆☆☆☆' },
    { nombre: 'Chris Evans', categoria: 'Cine', descripcion: 'Capitán América', calidad: '☆☆☆' },
    { nombre: 'Zendaya', categoria: 'Cine', descripcion: 'Actriz y cantante', calidad: '☆☆☆' },
    { nombre: 'Michael Jordan', categoria: 'Deporte', descripcion: 'El mejor basquetbolista', calidad: '☆☆☆☆☆' },
    { nombre: 'LeBron James', categoria: 'Deporte', descripcion: 'Rey del básquetbol moderno', calidad: '☆☆☆☆☆' },
    { nombre: 'Muhammad Ali', categoria: 'Deporte', descripcion: 'Leyenda del boxeo', calidad: '☆☆☆☆☆' },
    { nombre: 'Serena Williams', categoria: 'Deporte', descripcion: 'Leyenda del tenis', calidad: '☆☆☆☆' },
    { nombre: 'Tiger Woods', categoria: 'Deporte', descripcion: 'Leyenda del golf', calidad: '☆☆☆☆' },
    { nombre: 'Usain Bolt', categoria: 'Deporte', descripcion: 'El hombre más rápido', calidad: '☆☆☆☆' },
    { nombre: 'Roger Federer', categoria: 'Deporte', descripcion: 'Maestro del tenis', calidad: '☆☆☆☆' },
    { nombre: 'Rafael Nadal', categoria: 'Deporte', descripcion: 'Rey de la arcilla', calidad: '☆☆☆☆' },
    { nombre: 'Kobe Bryant', categoria: 'Deporte', descripcion: 'Mamba negra', calidad: '☆☆☆☆☆' },
    { nombre: 'Elon Musk', categoria: 'Tecnología', descripcion: 'CEO de Tesla y SpaceX', calidad: '☆☆☆☆☆' },
    { nombre: 'Steve Jobs', categoria: 'Tecnología', descripcion: 'Cofundador de Apple', calidad: '☆☆☆☆☆' },
    { nombre: 'Bill Gates', categoria: 'Tecnología', descripcion: 'Cofundador de Microsoft', calidad: '☆☆☆☆☆' },
    { nombre: 'Mark Zuckerberg', categoria: 'Tecnología', descripcion: 'Creador de Facebook', calidad: '☆☆☆☆' },
    { nombre: 'Nelson Mandela', categoria: 'Historia', descripcion: 'Ícono de la paz', calidad: '☆☆☆☆☆' },
    { nombre: 'Albert Einstein', categoria: 'Ciencia', descripcion: 'Físico genial', calidad: '☆☆☆☆☆' },
    { nombre: 'Stephen Hawking', categoria: 'Ciencia', descripcion: 'Cosmólogo brillante', calidad: '☆☆☆☆' },
    { nombre: 'Kim Kardashian', categoria: 'Entretenimiento', descripcion: 'Empresaria e influencer', calidad: '☆☆☆' },
    { nombre: 'Kylie Jenner', categoria: 'Entretenimiento', descripcion: 'Influencer y empresaria', calidad: '☆☆☆' },
    { nombre: 'MrBeast', categoria: 'Entretenimiento', descripcion: 'El mayor youtuber del mundo', calidad: '☆☆☆☆' },
    { nombre: 'PewDiePie', categoria: 'Entretenimiento', descripcion: 'Ícono de YouTube', calidad: '☆☆☆' },
];

const LISTA_FAMOSOS = FAMOSOS_BASE.map(f => ({
    ...f,
    nombreFormateado: f.nombre,
    nombre: f.nombre.replace(/\s/g, '').toLowerCase()
}));

function formatoNombre(nombreSimple) {
    const data = LISTA_FAMOSOS.find(f => f.nombre === nombreSimple);
    if (!data) return nombreSimple.toUpperCase();
    return data.nombreFormateado.replace(/\s/g, '_');
}

function obtenerPrecioVenta(calidadString) {
    const estrellas = calidadString.length;
    return estrellas * PRECIO_BASE_POR_ESTRELLA;
}

function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.famosos) db.data.famosos = {};
    if (!db.data.intercambiosFamosos) db.data.intercambiosFamosos = {};
}

function guardarCambios(targetNumber) {
    if (db && db.data && db.data.famosos) {
        if (targetNumber && db.data.famosos[targetNumber]) {
            db.setFamosos(targetNumber, db.data.famosos[targetNumber]);
        } else {
            for (const [key, val] of Object.entries(db.data.famosos)) {
                db.setFamosos(key, val);
            }
        }
    }
    if (db && typeof db.save === 'function') db.save();
}

function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

function obtenerFamosoAleatorio() {
    return LISTA_FAMOSOS[Math.floor(Math.random() * LISTA_FAMOSOS.length)];
}

function buscarFamosoPorNombre(entrada) {
    const limpio = entrada.replace(/\s/g, '').replace(/_/g, '').toLowerCase();
    return LISTA_FAMOSOS.find(f => f.nombre === limpio);
}

let handler = async (message, { text, command, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = db.cleanNumber(senderJid) || senderJid?.split('@')[0];

        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const famososData = db.data.famosos;
        const intercambiosFamosos = db.data.intercambiosFamosos;

        if (!famososData[senderNumber]) {
            famososData[senderNumber] = {
                famosos: [],
                bloqueados: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            db.setFamosos(senderNumber, famososData[senderNumber]);
            guardarCambios();
        }
        if (!famososData[senderNumber].bloqueados) {
            famososData[senderNumber].bloqueados = [];
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        if (command.match(/^famoso[s]?$/i) && !subCommand) {
            return await message.reply(
                '🌟 *COMANDOS DE FAMOSOS* 🌟\n' +
                '━━━━━━━━━━\n\n' +
                '*.famoso reclamar* / *.famoso claim* - _Reclamá un famoso aleatorio (1 por hora)._\n' +
                '*.myfamoso* - _Ver tu colección de famosos._\n' +
                '*.famoso ver [nombre]* - _Ver la imagen de un famoso (solo si lo tenés)._\n' +
                '*.famoso regalar @user [nombre]* - _Regalá un famoso a otro usuario._\n' +
                '*.famoso intercambio @user [mi_famoso] [su_famoso]* - _Proponé un intercambio._\n' +
                '*.famoso intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*.famoso intercambio rechazar @user* - _Rechazar intercambio._\n' +
                '*.famoso vender [nombre] [cantidad]* - _Vende famosos._\n' +
                '*.famoso vender all* - _Vende todos tus famosos (excepto bloqueados)._\n' +
                '*.famoso block [nombre] [número]* - _Bloquea una copia (no se vende con all)._\n' +
                '*.famoso block all* - _Bloquea todos tus famosos._\n' +
                '*.famoso unlock [nombre] [número]* - _Desbloquea una copia._\n' +
                '*.famoso unlock all* - _Desbloquea todos tus famosos._\n'
            );
        }

        // SUBCOMANDO: block / bloquear
        if (subCommand === 'block' || subCommand === 'bloquear') {
            const objetivo = args[1]?.toLowerCase();
            const inventario = famososData[senderNumber].famosos;
            const bloqueados = famososData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso block [famoso] [número]_ o _.famoso block all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                const aBloqear = [];
                const conteo = {};
                for (const n of inventario) {
                    conteo[n] = (conteo[n] || 0) + 1;
                    const key = n + '_' + conteo[n];
                    if (!bloqueados.includes(key)) aBloqear.push(key);
                }
                famososData[senderNumber].bloqueados = [...new Set([...bloqueados, ...aBloqear])];
                guardarCambios();
                return await message.reply(`🔒 *Todos tus famosos han sido bloqueados.* No se venderán con \`.famoso vender all\`.`);
            }

            const famoso = buscarFamosoPorNombre(objetivo);
            if (!famoso) return await message.reply('❌ *Famoso no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `.famoso block MichaelJackson 1`');

            const copias = inventario.filter(n => n === famoso.nombre).length;
            if (numero > copias) return await message.reply(`❌ Solo tenés *${copias}x ${formatoNombre(famoso.nombre)}*.`);

            const key = famoso.nombre + '_' + numero;
            if (bloqueados.includes(key)) return await message.reply(`🔒 La copia #${numero} de *${formatoNombre(famoso.nombre)}* ya está bloqueada.`);

            bloqueados.push(key);
            guardarCambios();
            return await message.reply(`🔒 *${formatoNombre(famoso.nombre)} #${numero}* bloqueado. No se venderá con \`.famoso vender all\`.`);
        }

        // SUBCOMANDO: unlock / desbloquear
        if (subCommand === 'unlock' || subCommand === 'desbloquear') {
            const objetivo = args[1]?.toLowerCase();
            const bloqueados = famososData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso unlock [famoso] [número]_ o _.famoso unlock all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                famososData[senderNumber].bloqueados = [];
                guardarCambios();
                return await message.reply('🔓 *Todos tus famosos han sido desbloqueados.*');
            }

            const famoso = buscarFamosoPorNombre(objetivo);
            if (!famoso) return await message.reply('❌ *Famoso no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `.famoso unlock MichaelJackson 1`');

            const key = famoso.nombre + '_' + numero;
            const idx = bloqueados.indexOf(key);
            if (idx === -1) return await message.reply(`🔓 La copia #${numero} de *${formatoNombre(famoso.nombre)}* no está bloqueada.`);

            bloqueados.splice(idx, 1);
            guardarCambios();
            return await message.reply(`🔓 *${formatoNombre(famoso.nombre)} #${numero}* desbloqueado.`);
        }

        if (subCommand === 'vender' || subCommand === 'sell') {
            const comandoVender = args[1]?.toLowerCase();
            let totalMonedasGanadas = 0;
            let famososVendidos = 0;
            const inventarioUsuario = famososData[senderNumber].famosos;
            const bloqueados = famososData[senderNumber].bloqueados || [];

            if (comandoVender === 'all' || comandoVender === 'todo' || comandoVender === 'todos') {
                if (inventarioUsuario.length === 0) {
                    return await message.reply('❌ *Tu colección está vacía.*');
                }

                const copiasBloqueadas = {};
                for (const key of bloqueados) {
                    const partes = key.split('_');
                    const num = parseInt(partes[partes.length - 1]);
                    const nombre = partes.slice(0, partes.length - 1).join('_');
                    if (!isNaN(num)) {
                        copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                    }
                }

                const quedan = [];
                const conteoTotal = {};
                for (const n of inventarioUsuario) {
                    conteoTotal[n] = (conteoTotal[n] || 0) + 1;
                }

                for (const nombreSimple in conteoTotal) {
                    const totalCopias = conteoTotal[nombreSimple];
                    const bloqCopias = copiasBloqueadas[nombreSimple] || 0;
                    const vendibles = totalCopias - bloqCopias;
                    const data = buscarFamosoPorNombre(nombreSimple);

                    if (data && vendibles > 0) {
                        const precioPorUnidad = obtenerPrecioVenta(data.calidad);
                        totalMonedasGanadas += precioPorUnidad * vendibles;
                        famososVendidos += vendibles;
                    }

                    const aGuardar = data ? bloqCopias : totalCopias;
                    for (let i = 0; i < aGuardar; i++) quedan.push(nombreSimple);
                }

                if (famososVendidos === 0) {
                    return await message.reply('❌ *No tenés famosos vendibles.* (Todos están bloqueados o vacíos)');
                }

                famososData[senderNumber].famosos = quedan;

            } else {
                const nombreEntrada = args[1];
                const cantidadAVender = parseInt(args[2] || 1);

                if (!nombreEntrada || isNaN(cantidadAVender) || cantidadAVender < 1) {
                    return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso vender [Nombre] [cantidad]_ o _.famoso vender all_');
                }

                const famoso = buscarFamosoPorNombre(nombreEntrada);

                if (!famoso) {
                    return await message.reply('❌ *Famoso no encontrado.*');
                }

                const nombreSimple = famoso.nombre;
                const conteoEnInventario = inventarioUsuario.filter(n => n === nombreSimple).length;

                if (conteoEnInventario < cantidadAVender) {
                    return await message.reply(`❌ Solo tenés *${conteoEnInventario}x ${formatoNombre(nombreSimple)}*`);
                }

                const precioPorUnidad = obtenerPrecioVenta(famoso.calidad);
                totalMonedasGanadas = precioPorUnidad * cantidadAVender;
                famososVendidos = cantidadAVender;

                let eliminados = 0;
                famososData[senderNumber].famosos = inventarioUsuario.filter(n => {
                    if (n === nombreSimple && eliminados < cantidadAVender) {
                        eliminados++;
                        return false;
                    }
                    return true;
                });
            }

            if (famososVendidos > 0) {
                await añadirMonedas(senderJid, groupJid, totalMonedasGanadas);
                guardarCambios();

                userDb = await global.db.getUser(senderJid, groupJid);
                const saldoFinal = obtenerMonedas(userDb).toLocaleString();

                const mensaje =
                    `💰 *¡Venta Exitosa!* 💰\n` +
                    '━━━━━━━━━━\n\n' +
                    `Has vendido *${famososVendidos} famosos* por *${totalMonedasGanadas.toLocaleString()} monedas*.\n` +
                    `Tu saldo total: *${saldoFinal} monedas*.\n\n` +
                    '_¡Sigue coleccionando!_ 🌟';

                return await message.reply(mensaje, { mentions: [senderJid] });
            }

            return await message.reply('❌ *Error al procesar la venta.*');
        }

        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const ultimaVez = famososData[senderNumber].ultimoClaim || 0;
            const isPremiumUser = premium.isPremium(senderJid);
            const cooldown = isPremiumUser ? 30 * 60 * 1000 : 60 * 60 * 1000;
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Podés reclamar otro famoso en *${minutos}m ${segundos}s*`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const famosoReclamado = obtenerFamosoAleatorio();
            famososData[senderNumber].famosos.push(famosoReclamado.nombre);
            famososData[senderNumber].ultimoClaim = ahora;
            db.setFamosos(senderNumber, famososData[senderNumber]);
            guardarCambios();

            await message.reply('🔍 *Buscando tu nuevo famoso...*');
            const imagenUrl = await buscarImagenFamoso(famosoReclamado.nombreFormateado, famosoReclamado.categoria);

            const caption =
                `🎉 *¡Has reclamado un famoso!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Famoso:* ${formatoNombre(famosoReclamado.nombre)}\n` +
                `*Categoría:* ${famosoReclamado.categoria}\n` +
                `*Descripción:* ${famosoReclamado.descripcion}\n` +
                `*Calidad:* ${famosoReclamado.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(famosoReclamado.calidad).toLocaleString()} monedas\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclamá de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }
            return;
        }

        if (subCommand === 'ver') {
            const nombreEntrada = args.slice(1).join('');
            if (!nombreEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso ver [NombreFamoso]_');
            }

            const famoso = buscarFamosoPorNombre(nombreEntrada);
            if (!famoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const tieneFamoso = famososData[senderNumber].famosos.some(n => n === famoso.nombre);
            if (!tieneFamoso) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(famoso.nombre)}* en tu colección.`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            await message.reply('🔍 *Buscando imagen del famoso...*');
            const imagenUrl = await buscarImagenFamoso(famoso.nombreFormateado, famoso.categoria);

            const caption =
                `🌟 *FAMOSO EN COLECCIÓN* 🌟\n` +
                `━━━━━━━━━━\n\n` +
                `*Famoso:* ${formatoNombre(famoso.nombre)}\n` +
                `*Categoría:* ${famoso.categoria}\n` +
                `*Descripción:* ${famoso.descripcion}\n` +
                `*Calidad:* ${famoso.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(famoso.calidad).toLocaleString()} monedas\n\n` +
                `_Este famoso es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }
            return;
        }

        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombreEntrada = args.slice(2).join('');

            if (!mentionedJids || mentionedJids.length === 0 || !nombreEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso regalar @usuario [NombreFamoso]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const famoso = buscarFamosoPorNombre(nombreEntrada);

            if (!famoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const indexEnInventario = famososData[senderNumber].famosos.findIndex(n => n === famoso.nombre);
            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(famoso.nombre)}* para regalar.`);
            }

            if (!famososData[receptorNumber]) {
                famososData[receptorNumber] = { famosos: [], ultimoClaim: 0, jid: receptorJid };
            }

            famososData[senderNumber].famosos.splice(indexEnInventario, 1);
            famososData[receptorNumber].famosos.push(famoso.nombre);
            guardarCambios();

            const mensaje =
                `🎁 *¡REGALO DE FAMOSO!* 🎁\n` +
                `━━━━━━━━━━\n\n` +
                `@${senderNumber} le regaló a *${formatoNombre(famoso.nombre)}* (${famoso.categoria}) a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miEntrada = args[2];
            const suEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miEntrada || !suEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso intercambio @user [mi_famoso] [su_famoso]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];

            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No podés intercambiar con vos mismo.*');
            }

            const miFamoso = buscarFamosoPorNombre(miEntrada);
            const suFamoso = buscarFamosoPorNombre(suEntrada);

            if (!miFamoso || !suFamoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const indexMio = famososData[senderNumber].famosos.findIndex(n => n === miFamoso.nombre);
            if (indexMio === -1) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(miFamoso.nombre)}* para ofrecer.`);
            }

            if (!famososData[receptorNumber] || !famososData[receptorNumber].famosos.includes(suFamoso.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suFamoso.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosFamosos[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorFamoso: miFamoso.nombre,
                receptorFamoso: suFamoso.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            setTimeout(async () => {
                if (intercambiosFamosos[tradeKey]) {
                    delete intercambiosFamosos[tradeKey];
                    guardarCambios();
                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: `⏳ *Intercambio Cancelado*\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} expiró.`,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                `━━━━━━━━━━\n\n` +
                `*@${senderNumber}* ofrece: *${formatoNombre(miFamoso.nombre)}* (${miFamoso.categoria})\n` +
                `_por el famoso de_ *@${receptorNumber}:* *${formatoNombre(suFamoso.nombre)}* (${suFamoso.categoria})\n\n` +
                `*Para aceptar:*\n.famoso intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n.famoso intercambio rechazar @${senderNumber}\n\n` +
                `_Tenés 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: .famoso intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;
            const propuesta = intercambiosFamosos[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosFamosos[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje =
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* rechazó la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será para otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            const mioSimple = propuesta.receptorFamoso;
            const suyoSimple = propuesta.emisorFamoso;

            const indexMio = famososData[senderNumber].famosos.findIndex(n => n === mioSimple);
            const indexSuyo = famososData[emisorNumber]?.famosos.findIndex(n => n === suyoSimple);

            if (indexMio === -1) {
                return await message.reply(`❌ *ERROR: Ya no tenés a ${formatoNombre(mioSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuyo === undefined || indexSuyo === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suyoSimple)}*`, { mentions: [emisorJid] });
            }

            famososData[senderNumber].famosos.splice(indexMio, 1);
            famososData[emisorNumber].famosos.splice(indexSuyo, 1);
            famososData[senderNumber].famosos.push(suyoSimple);
            famososData[emisorNumber].famosos.push(mioSimple);
            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                `━━━━━━━━━━\n\n` +
                `*@${senderNumber}* recibe: *${formatoNombre(suyoSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(mioSimple)}*\n\n` +
                '_¡Nuevos famosos para ambos!_ 🌟';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        if (command.match(/^myfamoso[s]?$/i)) {
            const inventario = famososData[senderNumber]?.famosos || [];
            const bloqueados = famososData[senderNumber]?.bloqueados || [];

            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(
                    `🌟 *COLECCIÓN DE* @${senderNumber} 🌟\n\n` +
                    `_No tenés famosos. Usá .famoso reclamar para obtener uno._\n\n` +
                    `*Monedas Totales:* ${monedasActuales} 💰`,
                    { mentions: [senderJid] }
                );
            }

            const conteo = inventario.reduce((acc, nombre) => {
                acc[nombre] = (acc[nombre] || 0) + 1;
                return acc;
            }, {});

            const copiasBloqueadas = {};
            for (const key of bloqueados) {
                const partes = key.split('_');
                const num = parseInt(partes[partes.length - 1]);
                const nombre = partes.slice(0, partes.length - 1).join('_');
                if (!isNaN(num)) {
                    copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                }
            }

            let mensaje =
                `🌟 *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Famosos)_ 🌟\n` +
                `*Monedas Totales:* ${monedasActuales} 💰\n` +
                `━━━━━━━━━━\n`;

            Object.keys(conteo).sort().forEach(nombreSimple => {
                const data = buscarFamosoPorNombre(nombreSimple);
                const count = conteo[nombreSimple];
                const categoria = data ? data.categoria : '???';
                const descripcion = data ? data.descripcion : '???';
                const calidad = data ? data.calidad : '???';
                const precio = data ? obtenerPrecioVenta(data.calidad).toLocaleString() : '???';
                const bloq = copiasBloqueadas[nombreSimple] || 0;
                const bloqTexto = bloq > 0 ? ` 🔒x${bloq}` : '';

                mensaje +=
                    `\n*${formatoNombre(nombreSimple)}* x${count}${bloqTexto}\n` +
                    `└ ${categoria} • ${descripcion} • ${calidad}\n` +
                    `└ Venta: ${precio} c/u`;
            });

            if (bloqueados.length > 0) {
                mensaje += `\n\n🔒 *Bloqueados:* ${bloqueados.length} copia(s) protegida(s) del \`vender all\``;
            }

            mensaje += '\n\n_Usá .famoso ver [nombre] para ver su imagen._';

            return await message.reply(mensaje, { mentions: [senderJid] });
        }

        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usá .famoso para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de famosos:', error.code || error.message, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['famoso', 'famoso reclamar', 'famoso claim', 'famoso ver', 'famoso regalar', 'famoso intercambio', 'famoso vender', 'famoso vender all', 'famoso sell', 'famoso sell all', 'famoso block', 'famoso unlock', 'famoso bloquear', 'famoso desbloquear', 'myfamoso'];
handler.tags = ['juegos'];
handler.command = /^(famoso|famosos|famous|myfamoso|myfamosos)$/i;

module.exports = handler;
module.exports.FAMOSOS_BASE = FAMOSOS_BASE;
module.exports.buscarImagenFamoso = buscarImagenFamoso;
handler.group = false;