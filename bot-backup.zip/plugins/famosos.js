const axios = require('axios');
const db = require('../database.js');

// 🧠 Cache simple para imágenes de Pinterest
const imageCache = new Map();

/**
 * 🔍 Buscar imagen de famoso en Pinterest
 */
async function buscarImagenFamoso(nombreFamoso, categoria) {
    const query = `${nombreFamoso} ${categoria} celebrity`;

    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://www.robleuy.site/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 8000 });

        if (!data?.ok || !data?.images?.length) return null;

        const random = data.images[Math.floor(Math.random() * data.images.length)];
        const imageUrl = random?.large || random?.small;
        if (!imageUrl) return null;

        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`Error buscando imagen para ${nombreFamoso}:`, error.message);
        return null;
    }
}

// --- DATOS DE FAMOSOS ---
const FAMOSOS_BASE = [
    // MÚSICA
    { nombre: 'Michael Jackson', categoria: 'Música', descripcion: 'Rey del Pop', imagen: null },
    { nombre: 'Madonna', categoria: 'Música', descripcion: 'Reina del Pop', imagen: null },
    { nombre: 'Freddie Mercury', categoria: 'Música', descripcion: 'Vocalista de Queen', imagen: null },
    { nombre: 'Elvis Presley', categoria: 'Música', descripcion: 'El Rey del Rock', imagen: null },
    { nombre: 'David Bowie', categoria: 'Música', descripcion: 'El Camaleón del Rock', imagen: null },
    { nombre: 'Taylor Swift', categoria: 'Música', descripcion: 'Cantautora pop country', imagen: null },
    { nombre: 'Beyoncé', categoria: 'Música', descripcion: 'Reina de la música urbana', imagen: null },
    { nombre: 'Shakira', categoria: 'Música', descripcion: 'Cantante colombiana', imagen: null },
    { nombre: 'Bad Bunny', categoria: 'Música', descripcion: 'Rey del reggaetón', imagen: null },
    { nombre: 'Drake', categoria: 'Música', descripcion: 'Rapero canadiense', imagen: null },
    { nombre: 'Eminem', categoria: 'Música', descripcion: 'El Rey del Rap', imagen: null },
    { nombre: 'Rihanna', categoria: 'Música', descripcion: 'Cantante de Barbados', imagen: null },
    { nombre: 'Adele', categoria: 'Música', descripcion: 'Cantante británica', imagen: null },
    { nombre: 'Ed Sheeran', categoria: 'Música', descripcion: 'Cantautor inglés', imagen: null },
    { nombre: 'Lady Gaga', categoria: 'Música', descripcion: 'Cantante y actriz', imagen: null },
    { nombre: 'Justin Bieber', categoria: 'Música', descripcion: 'Cantante canadiense', imagen: null },
    { nombre: 'The Weeknd', categoria: 'Música', descripcion: 'Cantante canadiense R&B', imagen: null },
    { nombre: 'Billie Eilish', categoria: 'Música', descripcion: 'Cantante pop alternativa', imagen: null },
    { nombre: 'J Balvin', categoria: 'Música', descripcion: 'Cantante colombiano', imagen: null },
    { nombre: 'Maluma', categoria: 'Música', descripcion: 'Cantante colombiano', imagen: null },
    // CINE Y TV
    { nombre: 'Leonardo DiCaprio', categoria: 'Cine', descripcion: 'Actor de Hollywood', imagen: null },
    { nombre: 'Meryl Streep', categoria: 'Cine', descripcion: 'La mejor actriz del mundo', imagen: null },
    { nombre: 'Brad Pitt', categoria: 'Cine', descripcion: 'Actor de Hollywood', imagen: null },
    { nombre: 'Angelina Jolie', categoria: 'Cine', descripcion: 'Actriz y directora', imagen: null },
    { nombre: 'Tom Hanks', categoria: 'Cine', descripcion: 'Ícono del cine americano', imagen: null },
    { nombre: 'Scarlett Johansson', categoria: 'Cine', descripcion: 'Actriz de Marvel', imagen: null },
    { nombre: 'Robert Downey Jr', categoria: 'Cine', descripcion: 'Iron Man', imagen: null },
    { nombre: 'Keanu Reeves', categoria: 'Cine', descripcion: 'Actor y celebridad de internet', imagen: null },
    { nombre: 'Will Smith', categoria: 'Cine', descripcion: 'Actor y rapero', imagen: null },
    { nombre: 'Dwayne Johnson', categoria: 'Cine', descripcion: 'The Rock', imagen: null },
    { nombre: 'Johnny Depp', categoria: 'Cine', descripcion: 'Actor ecléctico', imagen: null },
    { nombre: 'Jennifer Lawrence', categoria: 'Cine', descripcion: 'Actriz ganadora del Oscar', imagen: null },
    { nombre: 'Morgan Freeman', categoria: 'Cine', descripcion: 'Legendario actor americano', imagen: null },
    { nombre: 'Denzel Washington', categoria: 'Cine', descripcion: 'Actor galardonado', imagen: null },
    { nombre: 'Chris Evans', categoria: 'Cine', descripcion: 'Capitán América', imagen: null },
    { nombre: 'Zendaya', categoria: 'Cine', descripcion: 'Actriz y cantante', imagen: null },
    // DEPORTE (no fútbol)
    { nombre: 'Michael Jordan', categoria: 'Deporte', descripcion: 'El mejor basquetbolista', imagen: null },
    { nombre: 'LeBron James', categoria: 'Deporte', descripcion: 'Rey del básquetbol moderno', imagen: null },
    { nombre: 'Muhammad Ali', categoria: 'Deporte', descripcion: 'Leyenda del boxeo', imagen: null },
    { nombre: 'Serena Williams', categoria: 'Deporte', descripcion: 'Leyenda del tenis', imagen: null },
    { nombre: 'Tiger Woods', categoria: 'Deporte', descripcion: 'Leyenda del golf', imagen: null },
    { nombre: 'Usain Bolt', categoria: 'Deporte', descripcion: 'El hombre más rápido', imagen: null },
    { nombre: 'Roger Federer', categoria: 'Deporte', descripcion: 'Maestro del tenis', imagen: null },
    { nombre: 'Rafael Nadal', categoria: 'Deporte', descripcion: 'Rey de la arcilla', imagen: null },
    { nombre: 'Kobe Bryant', categoria: 'Deporte', descripcion: 'Mamba negra', imagen: null },
    // TECNOLOGÍA Y NEGOCIOS
    { nombre: 'Elon Musk', categoria: 'Tecnología', descripcion: 'CEO de Tesla y SpaceX', imagen: null },
    { nombre: 'Steve Jobs', categoria: 'Tecnología', descripcion: 'Cofundador de Apple', imagen: null },
    { nombre: 'Bill Gates', categoria: 'Tecnología', descripcion: 'Cofundador de Microsoft', imagen: null },
    { nombre: 'Mark Zuckerberg', categoria: 'Tecnología', descripcion: 'Creador de Facebook', imagen: null },
    // POLÍTICA E HISTORIA
    { nombre: 'Nelson Mandela', categoria: 'Historia', descripcion: 'Ícono de la paz', imagen: null },
    { nombre: 'Albert Einstein', categoria: 'Ciencia', descripcion: 'Físico genial', imagen: null },
    { nombre: 'Stephen Hawking', categoria: 'Ciencia', descripcion: 'Cosmólogo brillante', imagen: null },
    // INFLUENCERS Y CULTURA POP
    { nombre: 'Kim Kardashian', categoria: 'Entretenimiento', descripcion: 'Empresaria e influencer', imagen: null },
    { nombre: 'Kylie Jenner', categoria: 'Entretenimiento', descripcion: 'Influencer y empresaria', imagen: null },
    { nombre: 'MrBeast', categoria: 'Entretenimiento', descripcion: 'El mayor youtuber del mundo', imagen: null },
    { nombre: 'PewDiePie', categoria: 'Entretenimiento', descripcion: 'Ícono de YouTube', imagen: null },
];

const LISTA_FAMOSOS = FAMOSOS_BASE.map(f => ({
    ...f,
    nombreFormateado: f.nombre,
    nombre: f.nombre.replace(/\s/g, '').toLowerCase()
}));

/**
 * Convierte el nombre simple al formato legible
 */
function formatoNombre(nombreSimple) {
    const data = LISTA_FAMOSOS.find(f => f.nombre === nombreSimple);
    if (!data) return nombreSimple.toUpperCase();
    return data.nombreFormateado.replace(/\s/g, '_');
}

// --- Helpers de DB ---
function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.famosos) db.data.famosos = {};
    if (!db.data.intercambiosFamosos) db.data.intercambiosFamosos = {};
}

function guardarCambios() {
    if (db && typeof db.save === 'function') db.save();
}

// --- FUNCIONES DE MONEDAS ---
function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

// --- Famoso aleatorio (todos tienen igual probabilidad, sin estrellas) ---
function obtenerFamosoAleatorio() {
    return LISTA_FAMOSOS[Math.floor(Math.random() * LISTA_FAMOSOS.length)];
}

function buscarFamosoPorNombre(entrada) {
    const limpio = entrada.replace(/\s/g, '').replace(/_/g, '').toLowerCase();
    return LISTA_FAMOSOS.find(f => f.nombre === limpio);
}

// --- Manejador Principal ---
let handler = async (message, { text, command, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = senderJid?.split('@')[0];

        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const famososData = db.data.famosos;
        const intercambiosFamosos = db.data.intercambiosFamosos;

        if (!famososData[senderNumber]) {
            famososData[senderNumber] = {
                famosos: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            guardarCambios();
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        // ══════════════════════════════════════
        // .famoso (sin subcomando) → lista de comandos
        // ══════════════════════════════════════
        if (command.match(/^famoso[s]?$/i) && !subCommand) {
            return await message.reply(
                '🌟 *COMANDOS DE FAMOSOS* 🌟\n' +
                '━━━━━━━━━━\n\n' +
                '*.famoso reclamar* / *.famoso claim* - _Reclamá un famoso aleatorio (1 por hora)._\n' +
                '*.myfamoso* - _Ver tu colección de famosos._\n' +
                '*.famoso ver [nombre]* - _Ver la imagen de un famoso (solo si lo tenés)._\n' +
                '*.famoso regalar @user [nombre]* - _Regalá un famoso a otro usuario._\n' +
                '*.famoso intercambio @user [mi_famoso] [su_famoso]* - _Proponé un intercambio._\n' +
                '*.famoso intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*.famoso intercambio rechazar @user* - _Rechazar intercambio._\n'
            );
        }

        // ══════════════════════════════════════
        // SUBCOMANDO: reclamar / claim
        // ══════════════════════════════════════
        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const ultimaVez = famososData[senderNumber].ultimoClaim || 0;
            const cooldown = 60 * 60 * 1000; // 1 hora
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Podés reclamar otro famoso en *${minutos}m ${segundos}s*`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const famosoReclamado = obtenerFamosoAleatorio();
            famososData[senderNumber].famosos.push(famosoReclamado.nombre);
            famososData[senderNumber].ultimoClaim = ahora;
            guardarCambios();

            await message.reply('🔍 *Buscando tu nuevo famoso...*');
            const imagenUrl = await buscarImagenFamoso(famosoReclamado.nombreFormateado, famosoReclamado.categoria);

            const caption =
                `🎉 *¡Has reclamado un famoso!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Famoso:* ${formatoNombre(famosoReclamado.nombre)}\n` +
                `*Categoría:* ${famosoReclamado.categoria}\n` +
                `*Descripción:* ${famosoReclamado.descripcion}\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclamá de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }
            return;
        }

        // ══════════════════════════════════════
        // SUBCOMANDO: ver (desde .famoso ver [nombre])
        // ══════════════════════════════════════
        if (subCommand === 'ver') {
            const nombreEntrada = args.slice(1).join('');
            if (!nombreEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso ver [NombreFamoso]_');
            }

            const famoso = buscarFamosoPorNombre(nombreEntrada);
            if (!famoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const tieneFamoso = famososData[senderNumber].famosos.some(n => n === famoso.nombre);
            if (!tieneFamoso) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(famoso.nombre)}* en tu colección.`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            await message.reply('🔍 *Buscando imagen del famoso...*');
            const imagenUrl = await buscarImagenFamoso(famoso.nombreFormateado, famoso.categoria);

            const caption =
                `🌟 *FAMOSO EN COLECCIÓN* 🌟\n` +
                `━━━━━━━━━━\n\n` +
                `*Famoso:* ${formatoNombre(famoso.nombre)}\n` +
                `*Categoría:* ${famoso.categoria}\n` +
                `*Descripción:* ${famoso.descripcion}\n\n` +
                `_Este famoso es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }
            return;
        }

        // ══════════════════════════════════════
        // SUBCOMANDO: regalar
        // ══════════════════════════════════════
        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombreEntrada = args.slice(2).join('');

            if (!mentionedJids || mentionedJids.length === 0 || !nombreEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso regalar @usuario [NombreFamoso]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const famoso = buscarFamosoPorNombre(nombreEntrada);

            if (!famoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const indexEnInventario = famososData[senderNumber].famosos.findIndex(n => n === famoso.nombre);
            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(famoso.nombre)}* para regalar.`);
            }

            if (!famososData[receptorNumber]) {
                famososData[receptorNumber] = { famosos: [], ultimoClaim: 0, jid: receptorJid };
            }

            famososData[senderNumber].famosos.splice(indexEnInventario, 1);
            famososData[receptorNumber].famosos.push(famoso.nombre);
            guardarCambios();

            const mensaje =
                `🎁 *¡REGALO DE FAMOSO!* 🎁\n` +
                `━━━━━━━━━━\n\n` +
                `@${senderNumber} le regaló a *${formatoNombre(famoso.nombre)}* (${famoso.categoria}) a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // ══════════════════════════════════════
        // SUBCOMANDO: intercambio (proponer)
        // ══════════════════════════════════════
        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miEntrada = args[2];
            const suEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miEntrada || !suEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: .famoso intercambio @user [mi_famoso] [su_famoso]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];

            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No podés intercambiar con vos mismo.*');
            }

            const miFamoso = buscarFamosoPorNombre(miEntrada);
            const suFamoso = buscarFamosoPorNombre(suEntrada);

            if (!miFamoso || !suFamoso) {
                return await message.reply('❌ *Famoso no reconocido.*');
            }

            const indexMio = famososData[senderNumber].famosos.findIndex(n => n === miFamoso.nombre);
            if (indexMio === -1) {
                return await message.reply(`❌ *No tenés a ${formatoNombre(miFamoso.nombre)}* para ofrecer.`);
            }

            if (!famososData[receptorNumber] || !famososData[receptorNumber].famosos.includes(suFamoso.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suFamoso.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosFamosos[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorFamoso: miFamoso.nombre,
                receptorFamoso: suFamoso.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            // Expiración en 40 segundos
            setTimeout(async () => {
                if (intercambiosFamosos[tradeKey]) {
                    delete intercambiosFamosos[tradeKey];
                    guardarCambios();
                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: `⏳ *Intercambio Cancelado*\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} expiró.`,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                `━━━━━━━━━━\n\n` +
                `*@${senderNumber}* ofrece: *${formatoNombre(miFamoso.nombre)}* (${miFamoso.categoria})\n` +
                `_por el famoso de_ *@${receptorNumber}:* *${formatoNombre(suFamoso.nombre)}* (${suFamoso.categoria})\n\n` +
                `*Para aceptar:*\n.famoso intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n.famoso intercambio rechazar @${senderNumber}\n\n` +
                `_Tenés 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // ══════════════════════════════════════
        // SUBCOMANDO: intercambio aceptar / rechazar
        // ══════════════════════════════════════
        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: .famoso intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;
            const propuesta = intercambiosFamosos[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosFamosos[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje =
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* rechazó la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será para otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            // Aceptar: verificar que ambos aún tienen sus famosos
            const mioSimple = propuesta.receptorFamoso;
            const suyoSimple = propuesta.emisorFamoso;

            const indexMio = famososData[senderNumber].famosos.findIndex(n => n === mioSimple);
            const indexSuyo = famososData[emisorNumber]?.famosos.findIndex(n => n === suyoSimple);

            if (indexMio === -1) {
                return await message.reply(`❌ *ERROR: Ya no tenés a ${formatoNombre(mioSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuyo === undefined || indexSuyo === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suyoSimple)}*`, { mentions: [emisorJid] });
            }

            // Realizar el intercambio
            famososData[senderNumber].famosos.splice(indexMio, 1);
            famososData[emisorNumber].famosos.splice(indexSuyo, 1);
            famososData[senderNumber].famosos.push(suyoSimple);
            famososData[emisorNumber].famosos.push(mioSimple);
            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                `━━━━━━━━━━\n\n` +
                `*@${senderNumber}* recibe: *${formatoNombre(suyoSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(mioSimple)}*\n\n` +
                '_¡Nuevos famosos para ambos!_ 🌟';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        // ══════════════════════════════════════
        // COMANDO: .myfamoso → ver colección
        // ══════════════════════════════════════
        if (command.match(/^myfamoso[s]?$/i)) {
            const inventario = famososData[senderNumber]?.famosos || [];

            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(
                    `🌟 *COLECCIÓN DE* @${senderNumber} 🌟\n\n` +
                    `_No tenés famosos. Usá .famoso reclamar para obtener uno._\n\n` +
                    `*Monedas Totales:* ${monedasActuales} 💰`,
                    { mentions: [senderJid] }
                );
            }

            const conteo = inventario.reduce((acc, nombre) => {
                acc[nombre] = (acc[nombre] || 0) + 1;
                return acc;
            }, {});

            let mensaje =
                `🌟 *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Famosos)_ 🌟\n` +
                `*Monedas Totales:* ${monedasActuales} 💰\n` +
                `━━━━━━━━━━\n`;

            Object.keys(conteo).sort().forEach(nombreSimple => {
                const data = buscarFamosoPorNombre(nombreSimple);
                const count = conteo[nombreSimple];
                const categoria = data ? data.categoria : '???';
                const descripcion = data ? data.descripcion : '???';

                mensaje +=
                    `\n*${formatoNombre(nombreSimple)}* x${count}\n` +
                    `└ ${categoria} • ${descripcion}`;
            });

            mensaje += '\n\n_Usá .famoso ver [nombre] para ver su imagen._';

            return await message.reply(mensaje, { mentions: [senderJid] });
        }

        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usá .famoso para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de famosos:', error.code || error.message, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['famoso', 'famoso reclamar', 'famoso claim', 'famoso ver', 'famoso regalar', 'famoso intercambio', 'myfamoso'];
handler.tags = ['juegos'];
handler.command = /^(famoso|famosos|famous|myfamoso|myfamosos)$/i;

module.exports = handler;
handler.group = false;
