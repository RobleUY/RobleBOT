const normalizeNumber = (jidPart) => (jidPart || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!global.db?.data?.users) 
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const currentUserNumber = normalizeNumber(message.sender || message.author);

        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];

        const isGlobal = args[1] && /^(g|global)$/i.test(args[1]);

        if (!isGlobal && !message.isGroup) 
            return await message.reply('❌ Este comando solo puede usarse en grupos.\n💡 Usa *' + usedPrefix + cmd + ' global* para ver el top global.');

        const usersWithCmds = [];

        if (isGlobal) {
            // Usar getUniqueUsers() para obtener usuarios sin duplicados
            const uniqueUsers = global.db.getUniqueUsers();

            for (const [userNumber, userData] of uniqueUsers.entries()) {
                if (!userData) continue;
                
                const totalCmds = userData.ComandosEjecutados || 0;
                if (totalCmds <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? '👤 Sin Apodo'
                    : apodoRaw;

                usersWithCmds.push({ jid: userNumber + '@s.whatsapp.net', number: userNumber, totalCmds, apodo });
            }
        } else {
            const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);
            const seenNumbers = new Set();

            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                
                // Evitar duplicados por número
                if (seenNumbers.has(userNumber)) continue;
                seenNumbers.add(userNumber);
                
                const userData = global.db.getUser(userNumber);
                if (!userData) continue;

                const totalCmds = userData.ComandosEjecutados || 0;
                if (totalCmds <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? '👤 Sin Apodo'
                    : apodoRaw;

                usersWithCmds.push({ jid: participant, number: userNumber, totalCmds, apodo });
            }
        }

        if (usersWithCmds.length === 0)
            return await message.reply('📊 No hay usuarios con comandos ejecutados en el ranking todavía.');

        // Ordenar de mayor a menor
        usersWithCmds.sort((a, b) => b.totalCmds - a.totalCmds);

        // ===== CALCULAR POSICIÓN GLOBAL SIEMPRE =====
        const allUsersGlobal = [];
        {
            const uniqueUsers = global.db.getUniqueUsers();
            for (const [userNumber, userData] of uniqueUsers.entries()) {
                if (!userData) continue;
                const totalCmds = userData.ComandosEjecutados || 0;
                if (totalCmds <= 0) continue;
                allUsersGlobal.push({ number: userNumber, totalCmds });
            }
        }
        allUsersGlobal.sort((a, b) => b.totalCmds - a.totalCmds);
        const globalPos = allUsersGlobal.findIndex(u => u.number === currentUserNumber) + 1;
        const globalTotal = allUsersGlobal.length;
        const itemsPerPage = 10;
        const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;
        // =============================================

        // Posición del usuario en la lista actual
        const userIndex = usersWithCmds.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // Paginación
        const totalPages = Math.max(1, Math.ceil(usersWithCmds.length / itemsPerPage));
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        const pageArg = isGlobal ? args[2] : args[1];
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = usersWithCmds.slice(start, end);

        // ===== CONSTRUIR MENSAJE =====
        let rankingText = isGlobal
            ? `*🌍 TOP COMANDOS GLOBAL 🎮*\n\n`
            : `*🏆 TOP COMANDOS DEL GRUPO 🎮*\n\n`;

        if (!isGlobal) {
            rankingText += `👥 *En este grupo:* ${usersWithCmds.length} jugadores en el top\n`;
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = usersWithCmds[userIndex];
                rankingText += `📍 *Tu pos. en el grupo:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *${usedPrefix}${cmd} ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. en el grupo:* No estás en el ranking\n`;
            }

            if (globalPos > 0) {
                rankingText += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                rankingText += `   ↳ Usa *${usedPrefix}${cmd} global ${globalUserPage}* para verlo\n`;
            } else {
                rankingText += `🌐 *Tu pos. global:* No estás en el ranking\n`;
            }

        } else {
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = usersWithCmds[userIndex];
                rankingText += `📍 *Tu pos. global:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *${usedPrefix}${cmd} global ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. global:* No estás en el ranking\n`;
            }
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            const modeArg = isGlobal ? ' global' : '';

            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *${usedPrefix}${cmd}${modeArg} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *${usedPrefix}${cmd}${modeArg} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        // ===== LISTA DE USUARIOS =====
        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;

            let medal;
            if (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else medal = `${pos}.`;

            rankingText += `${medal} *${u.apodo}*\n🎮 ${u.totalCmds.toLocaleString()} comandos\n\n`;
        });

        if (!isGlobal) {
            rankingText += `💡 _Usa *${usedPrefix}${cmd} global* para el top mundial_`;
        }

        await message.reply(rankingText);

    } catch (error) {
        console.error('[ERROR EN TOPCOMANDOS]:', error);
        await message.reply('⚠️ Error al obtener el top de comandos.');
    }
};

handler.help = ['topc', 'topcomandos', 'topcommands', 'topcomando', 'topcommand'];
handler.tags = ['info'];
handler.command = /^(topc|topcomandos|topcommands|topcomando|topcommand)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;
