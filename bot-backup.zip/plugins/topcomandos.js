const db = require('../database.js'); // Ajusta según tu estructura

// Normalizar números
const normalizeNumber = (jidPart) =>
    jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!global.db?.data?.users)
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);
        const user = global.db.getUser(senderNumber);

        // Verificación de apodo
        if (
            !user ||
            !user.apodo ||
            user.apodo.trim() === '' ||
            user.apodo.trim().toLowerCase() === 'sin apodo'
        ) {
            return await message.reply(
                `🚫 No puedes usar este comando sin tener un apodo.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`
            );
        }

        const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];

        // Procesar prefijo y argumentos
        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];

        // Detectar modo GLOBAL:
        // args[1] = g | global
        const isGlobal = args[1] && /^(g|global)$/i.test(args[1]);

        // Si NO es global → tiene que ser grupo
        if (!isGlobal && !message.isGroup)
            return await message.reply(
                '❌ Este comando solo puede usarse en grupos.\n💡 Usa *' + 
                usedPrefix + cmd + ' g* para ver el top global.'
            );

        const usersRank = [];
        const currentUserNumber = normalizeNumber(message.sender);

        let participants = [];

        if (isGlobal) {
            // 🌍 Modo GLOBAL
            const allUsers = global.db.data.users;

            for (const [jid, data] of Object.entries(allUsers)) {
                if (!data) continue;

                const totalCmds = data.ComandosEjecutados || 0;
                if (totalCmds <= 0) continue;

                const apodo = (data.apodo || '').trim();
                if (!apodo || apodo.toLowerCase() === 'sin apodo') continue;

                usersRank.push({
                    jid,
                    number: normalizeNumber(jid),
                    totalCmds,
                    apodo,
                    clan: data.clan ? data.clan.toUpperCase() : null
                });
            }

        } else {
            // 👥 Modo GRUPO solamente
            participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);

            for (const participant of participants) {
                const n = normalizeNumber(participant);
                const u = global.db.getUser(n);
                if (!u) continue;

                const totalCmds = u.ComandosEjecutados || 0;
                if (totalCmds <= 0) continue;

                const apodo = (u.apodo || '').trim();
                if (!apodo || apodo.toLowerCase() === 'sin apodo') continue;

                usersRank.push({
                    jid: participant,
                    number: n,
                    totalCmds,
                    apodo,
                    clan: u.clan ? u.clan.toUpperCase() : null
                });
            }
        }

        // Verificar que hayan usuarios
        if (usersRank.length === 0)
            return await message.reply('📊 No hay usuarios con comandos ejecutados.');

        // Ordenar
        usersRank.sort((a, b) => b.totalCmds - a.totalCmds);

        // Posición del usuario
        const userIndex = usersRank.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // ---------- Paginación ----------
        const itemsPerPage = 10;

        const totalPages = Math.max(1, Math.ceil(usersRank.length / itemsPerPage));

        // Página solicitada
        // GLOBAL: args[2]
        // GRUPO: args[1]
        let page = 1;
        let pageArg = isGlobal ? args[2] : args[1];

        if (pageArg && !isNaN(pageArg))
            page = Math.max(1, parseInt(pageArg));

        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = usersRank.slice(start, end);

        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 1;

        // ---------- Construcción del mensaje ----------
        let txt = isGlobal
            ? `*🌍 TOP COMANDOS GLOBAL 📚*\n`
            : `*🏆 TOP COMANDOS DEL GRUPO 📚*\n`;

        if (userPosition > 0)
            txt += `_Tu posición:_ *#${userPosition}* (Página ${userPage})\n`;

        txt += `_Mostrando página_ *${page}* _de_ *${totalPages}*\n\n`;

        // Navegación
        if (totalPages > 1) {
            const prevPage = page > 1 ? page - 1 : null;
            const nextPage = page < totalPages ? page + 1 : null;
            const modeArg = isGlobal ? ' g' : '';

            if (prevPage) txt += `⬅️ *${usedPrefix}${cmd}${modeArg} ${prevPage}*\n`;
            if (nextPage) txt += `➡️ *${usedPrefix}${cmd}${modeArg} ${nextPage}*\n`;
            if (userPage !== page) txt += `📍 *${usedPrefix}${cmd}${modeArg} ${userPage}*\n`;

            txt += `\n`;
        }

        // Lista
        pageUsers.forEach((u, i) => {
            const globalIndex = start + i + 1;
            const medal = medals[i] || `${globalIndex}️⃣`;

            const name = u.clan ? `[${u.clan}] ${u.apodo}` : u.apodo;

            txt += `${medal} *${name}*\n📌 ${u.totalCmds.toLocaleString()} comandos\n\n`;
        });

        if (!isGlobal)
            txt += `💡 Usa *${usedPrefix}${cmd} g* para ver el top global`;

        await message.reply(txt);

    } catch (error) {
        console.error('[ERROR EN TOPCOMANDOS]:', error);
        await message.reply('⚠️ Error al obtener el top de comandos.');
    }
};

handler.help = ['topcomandos', 'topc', 'ctop', 'comandostop'];
handler.tags = ['tools'];
handler.command = /^(topcomandos|topc|ctop|comandostop)$/i;
handler.group = true;
handler.apodo = true;

module.exports = handler;
