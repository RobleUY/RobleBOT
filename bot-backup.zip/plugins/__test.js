'use strict';
/**
 * Plugin de prueba .mytest
 * Envía la respuesta como mensaje reenviado/enriquecido.
 */

const WHATSAPP_CHANNEL_LINK = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';

const mytestHandler = {
    command: /^mytest$/i,
    help: 'Comando de prueba. Ejemplo: .mytest 1, .mytest 2, .mytest canal',
    tags: ['test', 'utilidades'],
    handler: async (message) => {
        const sock = message._sock || global.conn;
        const body = (message.body || '').trim();
        const args = body.split(/\s+/).slice(1);
        const option = args.join(' ').trim().toLowerCase();

        let text;

        if (!option) {
            text = `📌 Usar: .mytest 1 o .mytest 2\n\nCanal de WhatsApp:\n${WHATSAPP_CHANNEL_LINK}`;
        } else if (option === '1') {
            text = `✅ Has usado .mytest 1\n\nCanal de WhatsApp:\n${WHATSAPP_CHANNEL_LINK}\n\nUsa .mytest 2 para otra prueba.`;
        } else if (option === '2') {
            text = `✅ Has usado .mytest 2\n\nCanal de WhatsApp:\n${WHATSAPP_CHANNEL_LINK}\n\nTambién podés usar .mytest canal o .mytest <texto>.`;
        } else if (option === 'canal' || option === 'channel') {
            text = `🌐 Canal de WhatsApp:\n${WHATSAPP_CHANNEL_LINK}\n\nEste comando solo muestra el enlace del canal.`;
        } else {
            text = `🔧 Opción registrada: ${option}\n\nCanal de WhatsApp:\n${WHATSAPP_CHANNEL_LINK}\n\nEjemplos válidos:\n.mytest 1\n.mytest 2\n.mytest canal`;
        }

        const fkontak = {
            key: {
                participants: '0@s.whatsapp.net',
                remoteJid: 'status@broadcast',
                fromMe: false,
                id: '1234567890'
            },
            message: {
                contactMessage: {
                    displayName: 'Canal WhatsApp',
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;Canal WhatsApp;;;\nFN:Canal WhatsApp\nitem1.TEL;waid=0000000000:0000000000\nitem1.X-ABLabel:Canal\nEND:VCARD`
                }
            }
        };

        const ctxInfo = {
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: true,
                title: 'Canal de WhatsApp',
                body: 'Únete a este canal oficial',
                sourceUrl: WHATSAPP_CHANNEL_LINK,
                thumbnail: null
            }
        };

        // Preferir fakeReply si existe (da mejor efecto de 'reenviado')
        try {
            if (typeof sock.fakeReply === 'function') {
                await sock.fakeReply(
                    message.from,
                    text,
                    '0@s.whatsapp.net',            // jidFakeSender
                    'Canal WhatsApp',              // textFakeQuote shown in quoted message
                    message.from,                  // quoted chat
                    { contextInfo: ctxInfo }
                );
                return;
            }
        } catch (e) {
            // si falla fakeReply, caemos al fallback
            console.error('[__test] fakeReply falló:', e.message);
        }

        // Fallback: enviar como mensaje con quoted contact y contextInfo
        await sock.sendMessage(message.from, {
            text,
            contextInfo: ctxInfo
        }, { quoted: fkontak });
    }
};

module.exports = mytestHandler;
