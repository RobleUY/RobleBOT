const command = 'testa';
const help = 'Mensaje de prueba enriquecido';
const tags = ['test'];

async function handler(message, { conn }) {
    const sock = global.conn;
    if (!sock) return;

    await sock.sendMessage(
        message.from,
        {
            text: 'HOLA',
            contextInfo: {
                externalAdReply: {
                    title: 'Si lees esto rafa es gay',
                    body: 'XDDD',
                    thumbnailUrl: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
                    sourceUrl: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: false
                }
            }
        },
        { quoted: message._baileyMessage }
    );
}

module.exports = { command, help, tags, handler };
