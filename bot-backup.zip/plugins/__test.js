/**
 * Comando: joinzz
 * Descripción: El bot se une a un grupo mediante link de invitación,
 *              pero solo si el comando se ejecuta desde el grupo oficial.
 */

const handler = async (message, { conn, text }) => {
    try {
        // 🔹 ID del grupo oficial autorizado
        const AUTHORIZED_GROUP = "120363203689229697@g.us"; // <-- tu grupo oficial
        // 🔹 Link público del grupo oficial
        const AUTH_LINK = "https://chat.whatsapp.com/ABCDEFG123456789XYZ"; // <-- reemplaza con tu link real

        const currentChat = message.chat || message.key.remoteJid;
        console.log(`[DEBUG] Grupo actual: ${currentChat}`);
        console.log(`[DEBUG] isGroup: ${message.isGroup}`);

        // --- 1️⃣ Verificar si el comando se usa en un grupo ---
        if (!message.isGroup) {
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        // --- 2️⃣ Verificar si es el grupo autorizado ---
        if (currentChat !== AUTHORIZED_GROUP) {
            console.log("[ACCESS DENIED] Comando usado fuera del grupo oficial.");
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        // --- 3️⃣ Validar el link de invitación ---
        if (!text) {
            return await message.reply(
                "⚠️ Debes proporcionar un *link de invitación* del grupo.\n\n" +
                "Ejemplo:\n.joinzz https://chat.whatsapp.com/ABC123xyz"
            );
        }

        let inviteCode = null;
        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        if (!inviteCode) {
            const codeMatch = text.match(/^([0-9A-Za-z]{20,24})$/);
            if (codeMatch) inviteCode = codeMatch[1];
        }

        if (!inviteCode) {
            return await message.reply("⚠️ Link de invitación *no válido*.");
        }

        console.log(`[INFO] Intentando unirse al grupo con código: ${inviteCode}`);
        await message.reply("⏳ Intentando unirme al grupo...");

        // --- 4️⃣ Intentar unirse al grupo ---
        try {
            const joinResult = await conn.groupAcceptInvite(inviteCode);
            console.log(`[SUCCESS] Bot unido al grupo: ${joinResult}`);

            await message.reply("✅ *¡Me uní al grupo exitosamente!* 🎉");

            // Mensaje de bienvenida en el nuevo grupo
            const welcome = `
┏━〔 🌟 *ROBLEBOT* 🌟 〕━┓
┃ ¡Hola! Fui invitado por un miembro del grupo oficial.
┃
┃ ✨ Escribe */menu* para ver los comandos disponibles.
┃ 👑 *Creador:* RobleUY
┃ 📱 Instagram: @robleuy
┗━━━━━━━━━━━━━━━━━━━━━━━┛
`;
            await conn.sendMessage(joinResult, { text: welcome });
        } catch (joinError) {
            console.error("[ERROR] Al unirse al grupo:", joinError);
            await message.reply(
                "❌ No pude unirme al grupo.\nVerifica que el link sea válido o que el grupo no esté lleno."
            );
        }
    } catch (err) {
        console.error("[ERROR] General en joinzz:", err);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

// --- Configuración del Handler ---
handler.help = ["joinzz [link]"];
handler.tags = ["owner"];
handler.command = /^joinzz$/i;


module.exports = handler;
