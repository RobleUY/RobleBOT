const fs = require('fs');
const path = require('path');
const { Sticker } = require('wa-sticker-formatter');

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const stickerPath = path.join(__dirname, 'cumsito.webp');
        if (!fs.existsSync(stickerPath)) {
            return await message.reply('❌ No se encontró el archivo `cumsito.webp`.');
        }

        const imageBuffer = fs.readFileSync(stickerPath);

        const sticker = new Sticker(imageBuffer, {
            pack: 'RobleBOT',
            author: '\nRobleBOT\nInstagram: @robleuy',
            type: 'default',
            quality: 100
        });

        const finalBuffer = await sticker.toBuffer();

        await sock.sendMessage(
            message.from,
            { sticker: finalBuffer },
            { quoted: message._baileyMessage }
        );
    } catch (e) {
        console.error('[CUMSITO]', e);
        await message.reply(`❌ Error: ${e.message}`);
    }
};

handler.help = ['cumsito'];
handler.tags = ['fun'];
handler.command = /^cumsito$/i;
module.exports = handler;