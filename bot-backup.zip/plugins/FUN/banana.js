async function handler(message) {
    try {
        const senderJid = message.key.participant || message.key.remoteJid;

        // Generar tamaño aleatorio entre 0 y 100
        const size = Math.floor(Math.random() * 101);

        // Enviar mensaje con mención clickeable y solo el tamaño
        await message.reply(
            `Tu 🍌 te mide: ${size}cm`,
            { mentions: [senderJid] }
        );

    } catch (error) {
        console.error('Error en comando banana:', error);
        return await message.reply('❌ Ocurrió un error al medir tu banana.');
    }
}

handler.command = /^(banana)$/i;
handler.help = ['banana - Mide tu 🍌'];
handler.tags = ['diversion', 'banana'];

module.exports = handler;

