let handler = async (message, { text }) => {
    try {
        // 1. Identificar al remitente (tú)
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        // 2. Identificar si mencionaste a alguien
        const mentionedJids = message?.mentions;
        let targetJid = (mentionedJids && mentionedJids.length > 0) ? mentionedJids[0] : senderJid;

        // Extraer el número para el texto
        const targetNumber = targetJid.split('@')[0];

        // 3. Generar el tamaño aleatorio (0 a 100 cm)
        const size = Math.floor(Math.random() * 101);

        // 4. Determinar el mensaje (si es para ti o para otro)
        let responseText = "";
        if (targetJid === senderJid) {
            responseText = `🍌 *@${targetNumber}*, tu banana mide: *${size}cm*`;
        } else {
            responseText = `🍌 La banana de *@${targetNumber}* mide: *${size}cm*`;
        }

        // 5. Enviar respuesta con menciones activas
        await message.reply(responseText, { 
            mentions: [targetJid] 
        });

    } catch (error) {
        console.error('Error en comando banana:', error);
        await message.reply('❌ Ocurrió un error al medir la banana.');
    }
};

handler.help = ['banana'];
handler.tags = ['diversion'];
handler.command = /^(banana)$/i;

module.exports = handler;