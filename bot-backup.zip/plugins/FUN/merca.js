let handler = async (message, { text }) => {
    // Definir un array con los posibles mensajes
    const messages = ["AGUANTE LA MERCAAAAAA 👃", "MERCA? DONDE? DONDE??? 👃", "ESTOY RE DURO HIJOS DE PUTA 👃", "QUE RICA QUE ES LA MERCAAAAAAA 👃", "AMO INHALAR MERCA 👃"];
    
    // Seleccionar un mensaje aleatorio del array
    let randomMessage = messages[Math.floor(Math.random() * messages.length)];
    
    // Enviar el mensaje aleatorio
    return message.reply(randomMessage);
};

handler.help = ['merca'];
handler.tags = ['merca'];
handler.command = /^(merca)$/i;

if (!global.plugins) global.plugins = new Map();
global.plugins.set('merca', handler);

module.exports = handler;
