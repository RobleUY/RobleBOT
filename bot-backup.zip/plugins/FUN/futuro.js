

async function handler(message) {
    try {
        // Generar porcentaje aleatorio entre 0 y 100
        const probability = Math.floor(Math.random() * 101);

        // Determinar el mensaje basado en la probabilidad
        let prediction = '';
        if (probability < 20) {
            prediction = '🔮 Tu futuro es más oscuro que el café sin azúcar...';
        } else if (probability < 40) {
            prediction = '🔮 Veo dinero en tu futuro... ¡Ah no, perdón! Era una mancha en mi bola de cristal...';
        } else if (probability < 60) {
            prediction = '🔮 Las estrellas dicen que serás millonario... en seguidores de Instagram...';
        } else if (probability < 80) {
            prediction = '🔮 Tu futuro es tan brillante que necesito gafas de sol para verlo...';
        } else if (probability < 95) {
            prediction = '🔮 Veo un viaje en tu futuro... del sofá a la nevera...';
        } else {
            prediction = '🔮 ¡INCREÍBLE! Serás tan exitoso que hasta tus haters te pedirán autógrafos...';
        }

        // Enviar respuesta
        await message.reply(`🤖 *RobleBOT - Predicción*\n\n${prediction}\n\n*Probabilidad de que se cumpla:* ${probability}%`);
    } catch (error) {
        console.error('Error en futuro:', error);
        return await message.reply('❌ Ocurrió un error al leer tu futuro.');
    }
}

handler.command = /^(futuro)$/i;
handler.help = ['ver futuro'];
handler.tags = ['diversion', 'banana'];

module.exports = handler;

