const fs = require('fs');
const path = require('path');

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;

    try {
        const audioPath = path.join(__dirname, 'ahhhhh.mp3');

        if (!fs.existsSync(audioPath)) {
            return await message.reply('❌ No se encontró el archivo `ahhhhh.mp3`.');
        }

        await sock.sendMessage(
            message.from,
            {
                audio: fs.readFileSync(audioPath),
                mimetype: 'audio/mpeg',
                fileName: 'ahhhhh.mp3',
                ptt: false
            },
            { quoted: message._baileyMessage }
        );
    } catch (e) {
        console.error('[FAH]', e);
        await message.reply(`❌ Error: ${e.message}`);
    }
};

handler.help = ['fah'];
handler.tags = ['fun'];
handler.command = /^ah/i;

module.exports = handler;