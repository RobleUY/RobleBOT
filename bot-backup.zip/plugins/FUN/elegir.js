const handler = async (m, { conn, text }) => {
  try {
    // Verificar que haya texto con " o "
    if (!text || !text.includes(' o ')) {
      return m.reply('❗ Usa el comando así:\n\n.elegir opción1 o opción2\n\nEjemplo:\n.elegir perro o gato');
    }

    // Separar las opciones por " o "
    let opciones = text.split(/\s+o\s+/i).map(o => o.trim()).filter(o => o.length > 0);

    // Validar que haya exactamente 2 opciones
    if (opciones.length !== 2) {
      return m.reply('⚠️ Debes escribir exactamente *2 opciones* separadas por "o".\n\nEjemplo:\n.elegir café o té');
    }

    // Construir mensaje de la encuesta
    const mensaje = `🤔 *ELIGE UNA OPCIÓN*\n`;

    // Enviar encuesta interactiva con las 2 opciones
    await conn.sendMessage(m.from, {
      poll: {
        name: mensaje,
        values: opciones,
        selectableCount: 1
      }
    }, { quoted: m._baileyMessage });

  } catch (e) {
    console.error('Error en comando elegir:', e);
    await m.reply('❌ Ocurrió un error al crear la encuesta.');
  }
};

handler.help = ['elegir'];
handler.tags = ['juegos', 'diversión'];
handler.command = /^(elegir)$/i;

module.exports = handler;

