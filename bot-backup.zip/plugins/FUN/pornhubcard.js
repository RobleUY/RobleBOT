const axios = require('axios');

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let targetJid;
        let targetName;

        // Verificar si se usó "me" o "yo"
        const firstArg = args[0]?.toLowerCase();
        
        if (firstArg === 'me' || firstArg === 'yo') {
            // Usar el remitente del mensaje
            targetJid = message.sender;
            targetName = message.pushName || 'Usuario';
        } else if (message.mentions && message.mentions.length > 0) {
            // Usar el usuario mencionado
            targetJid = message.mentions[0];
            // Intentar obtener el nombre del mencionado
            try {
                const metadata = await conn.groupMetadata(message.from);
                const participant = metadata.participants.find(p => p.id === targetJid);
                targetName = participant?.notify || participant?.name || 'Usuario';
            } catch {
                targetName = 'Usuario';
            }
        } else {
            return await message.reply('⚠️ Debes mencionar a un usuario o usar:\n• `.phcard me`\n• `.phcard @usuario`');
        }

        const username = message.pushName || 'Busco Sexo';

        // Lista de frases aleatorias
        const frases = [
            'Me pajeo mientras lo veo',
            'Busco alguien hot',
            'Ojala a mi me cojan asi',
            'Pornhub la mejor pagina',
            'Hoy me masturbe 12 veces',
            'Alguien quiere cojerme?',
            'Yo se dar sexo oral',
            'Que pija mas grande'
        ];

        // Elegir frase al azar
        const textoRandom = frases[Math.floor(Math.random() * frases.length)];

        // Intentar obtener el avatar del usuario objetivo
        let avatarUrl;
        try {
            avatarUrl = await conn.profilePictureUrl(targetJid, 'image');
        } catch {
            avatarUrl = 'https://i.imgur.com/8Km9tLL.png'; // Imagen por defecto
        }

        // Codificar los valores para la URL
        const encodedImage = encodeURIComponent(avatarUrl);
        const encodedUsername = encodeURIComponent(username);
        const encodedText = encodeURIComponent(textoRandom);

        // Generar la URL final
        const apiUrl = `https://api.delirius.store/canvas/phub?image=${encodedImage}&username=${encodedUsername}&text=${encodedText}`;

        // Descargar la imagen generada
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);

        // Enviar la imagen
        await sock.sendMessage(
            message.from,
            {
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] phcard:', error);
        await message.reply('❌ Error al generar phcard.');
    }
};

handler.help = ['phcard me', 'phcard @usuario'];
handler.tags = ['diversion'];
handler.command = /^(phcard)$/i;

module.exports = handler;
