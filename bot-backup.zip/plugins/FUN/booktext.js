const axios = require('axios');

let handler = async (message, { conn, args }) => {
    try {
        // Si el usuario no escribe texto, usar el ejemplo por defecto
        const text = args.length > 0 ? args.join(' ') : 'Hola a todos';
        const footer = 'RobleBOT';

        // Codificar los parámetros para la URL
        const encodedText = encodeURIComponent(text);
        const encodedFooter = encodeURIComponent(footer);

        // Construir la URL de la API
        const apiUrl = `https://delirius-apiofc.vercel.app/canvas/book?text=${encodedText}&footer=${encodedFooter}`;

        // Descargar la imagen desde la API
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);

        // Enviar solo la imagen, sin texto adicional
        await conn.sendMessage(
            message.from,
            { 
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] booktext:', error.message);
        await message.reply('❌ Error al generar el libro.');
    }
};

handler.help = ['booktext <texto>'];
handler.tags = ['diversion'];
handler.command = /^(booktext)$/i;

module.exports = handler;
