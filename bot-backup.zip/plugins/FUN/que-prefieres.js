const fs = require('fs');
const path = require('path');

// carga de preguntas desde el json
const preguntasPath = path.join(__dirname, 'prefieres.json');
let preguntas = JSON.parse(fs.readFileSync(preguntasPath, 'utf-8'));

let handler = async (m, {conn, text}) => {
  try {
    let opciones = [];

    if (text && text.includes(' o ')) {
      //separar por o
      opciones = text.split(/\s+o\s+/i).map(o => o.trim()).filter(o => o);
      if (opciones.length < 2) opciones = ['Sí', 'No']; // fallback si escribió mal
    } else {
      // sino usar el json
      const pregunta = preguntas[Math.floor(Math.random() * preguntas.length)];
      opciones = [`${pregunta.opcion1}`, `${pregunta.opcion2}`];
    }

    // Limitar máximo 10 opciones (WhatsApp limita las encuestas)
    opciones = opciones.slice(0, 10);

    // Crear mensaje de la encuesta
    const mensaje = `🤔 *¿QUÉ PREFIERES?*\n\n💭 Elige tu opción:`;

    // Enviar encuesta interactiva
    await conn.sendMessage(m.from, {
      poll: {
        name: mensaje,
        values: opciones,
        selectableCount: 1
      }
    }, {quoted: m._baileyMessage});

  } catch (e) {
    console.error('Error en comando prefieres:', e);
    await m.reply('❌ Ocurrió un error al mostrar la pregunta.');
  }
};

handler.help = ['prefieres'];
handler.tags = ['juegos', 'diversión'];
handler.command = /^(prefieres|kprefieres|qprefieres|queprefieres)$/i;

module.exports = handler;

