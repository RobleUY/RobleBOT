const axios = require('axios');

let handler = async (message, { conn }) => {
    try {
        if (!message.mentions || message.mentions.length === 0)
            return await message.reply('⚠️ Debes mencionar a un usuario. Ejemplo: /slap @usuario');

        const targetJid = message.mentions[0];
        const authorJid = message.sender;

        let authorAvatar, targetAvatar;

        try {
            authorAvatar = await conn.profilePictureUrl(authorJid, 'image');
        } catch {
            authorAvatar = 'https://i.imgur.com/8Km9tLL.png';
        }

        try {
            targetAvatar = await conn.profilePictureUrl(targetJid, 'image');
        } catch {
            targetAvatar = 'https://i.imgur.com/8Km9tLL.png';
        }

        const encodedAuthor = encodeURIComponent(authorAvatar);
        const encodedTarget = encodeURIComponent(targetAvatar);

        const apiUrl = `https://delirius-apiofc.vercel.app/canvas/slap?url1=${encodedAuthor}&url2=${encodedTarget}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);

        await conn.sendMessage(
            message.from,
            {
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] slap:', error);
        await message.reply('❌ Error al generar slap.');
    }
};

handler.help = ['slap @usuario'];
handler.tags = ['diversion'];
handler.command = /^(slap)$/i;

module.exports = handler;
