let handler = async (message, { text }) => {
    try {
        console.log(`[DEBUG] Comando siono recibido con texto: ${text}`);
        
        if (!text) {
            console.log(`[DEBUG] No se proporcionó texto para la pregunta`);
            return await message.reply(
                '*❌ Debes proporcionar un texto después de ".siono*"\n*Ejemplo: .siono ¿Hoy es Lunes?*'
            );
        }

        // Lista ampliada de respuestas aleatorias
        const opciones = [
            "Sí. ✅",
            "No. ❌",
            "Tal vez… 🤔",
            "Definitivamente sí! 😎",
            "Ni lo sueñes! 😅",
            "No puedo decirlo ahora… ⏳",
            "Probablemente sí 🤷‍♂️",
            "Probablemente no 🤷‍♀️",
            "Absolutamente! 💪",
            "Para nada… 😬"
        ];

        const respuesta = opciones[Math.floor(Math.random() * opciones.length)];
        
        console.log(`[DEBUG] Respuesta seleccionada: ${respuesta}`);

        await message.reply(respuesta);
    } catch (error) {
        console.error('[ERROR] Error en siono:', error);
        throw error;
    }
};

handler.help = ["siono"];
handler.tags = ["games"];
handler.command = "siono";

module.exports = handler;
