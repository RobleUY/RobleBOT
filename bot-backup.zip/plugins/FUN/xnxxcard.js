const axios = require('axios');

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let targetJid;

        // Verificar si se usó "me" o "yo"
        const firstArg = args[0]?.toLowerCase();
        
        if (firstArg === 'me' || firstArg === 'yo') {
            // Usar el remitente del mensaje
            targetJid = message.sender;
        } else if (message.mentions && message.mentions.length > 0) {
            // Usar el usuario mencionado
            targetJid = message.mentions[0];
        } else {
            return await message.reply('⚠️ Debes mencionar a un usuario o usar:\n• `.xnxxcard me`\n• `.xnxxcard @usuario`');
        }

        // Lista de frases aleatorias
        const frases = [
            'Es garchada por el leviatan',
            'Hoy me cojen 3 negros',
            'Debut de pendeja trola',
            'Se la cojen en dubai',
            'Le rompen el culo en 4',
            'Es garchada x el bot',
            'Recibe bukake',
            'Se ahoga en semen de mono'
        ];

        // Elegir frase al azar
        const textoRandom = frases[Math.floor(Math.random() * frases.length)];

        // Intentar obtener el avatar del usuario objetivo
        let avatarUrl;
        try {
            avatarUrl = await conn.profilePictureUrl(targetJid, 'image');
        } catch {
            avatarUrl = 'https://i.imgur.com/8Km9tLL.png'; // Imagen por defecto
        }

        // Codificar los valores para la URL
        const encodedImage = encodeURIComponent(avatarUrl);
        const encodedTitle = encodeURIComponent(textoRandom);

        // Generar la URL final
        const apiUrl = `https://api.delirius.store/canvas/xnxxcard?image=${encodedImage}&title=${encodedTitle}`;

        // Descargar la imagen generada
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data);

        // Enviar la imagen
        await sock.sendMessage(
            message.from,
            {
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] xnxxcard:', error);
        await message.reply('❌ Error al generar xnxxcard.');
    }
};

handler.help = ['xnxxcard me', 'xnxxcard @usuario'];
handler.tags = ['diversion'];
handler.command = /^(xnxxcard)$/i;

module.exports = handler;
