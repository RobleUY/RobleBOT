

async function handler(message) {
    try {
        // Generar tamaño aleatorio entre 0 y 100
        const size = Math.floor(Math.random() * 101);

        // Enviar respuesta
        await message.reply(`*🌈 Tu porcentaje de gay es de:* ${size}%`);
    } catch (error) {
        console.error('Error en gay:', error);
        return await message.reply('❌ Ocurrió un error al medir tu homosexualidad.');
    }
}

handler.command = /^(gay)$/i;
handler.help = ['calcular gay'];
handler.tags = ['diversion', 'banana'];

module.exports = handler;

