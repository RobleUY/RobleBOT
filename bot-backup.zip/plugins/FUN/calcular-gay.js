

async function handler(message) {
    try {
        // Generar tamaño aleatorio entre 0 y 100
        const size = Math.floor(Math.random() * 101);

        // Determinar el mensaje basado en el tamaño
        let niveldegay = '';
        if (size < 10) {
            niveldegay = '🌈 Aun estas a salvo...';
        } else if (size < 30) {
            niveldegay = '🌈 Ya empiezas a ser rarit@...';
        } else if (size < 60) {
            niveldegay = '🌈 Definitivamente tienes la enfermedad...';
        } else if (size < 90) {
            niveldegay = '🌈 Eres tan gay que hasta puedes contagiar, ALEJATE!!...';
        } else {
            niveldegay = '🌈 No tienes cura, tu homosexualidad ya es demasiado extensa.';
        }

        // Enviar respuesta
        await message.reply(`🤖 *RobleBOT - Gay*\n\n${niveldegay}\n\n*Tu porcentaje de gay es de:* ${size}%`);
    } catch (error) {
        console.error('Error en gay:', error);
        return await message.reply('❌ Ocurrió un error al medir tu homosexualidad.');
    }
}

handler.command = /^(gay)$/i;
handler.help = ['calcular gay'];
handler.tags = ['diversion', 'banana'];

module.exports = handler;

