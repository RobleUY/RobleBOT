let handler = async (message, { text }) => {
    // Definir un array con los posibles mensajes
    const messages = ["Sale ese fasito? ☘", "Un buen porro no estaria mal ☘", "Alguien me regala un porrito? ☘", "Es hora de fumar weeeeeed ☘", "La marihuana hace bien, fumen chicos, fumen ☘"];
    
    // Seleccionar un mensaje aleatorio del array
    let randomMessage = messages[Math.floor(Math.random() * messages.length)];
    
    // Enviar el mensaje aleatorio
    return message.reply(randomMessage);
};

handler.help = ['merca'];
handler.tags = ['merca'];
handler.command = /^(weed)$/i;

if (!global.plugins) global.plugins = new Map();
global.plugins.set('weed', handler);

module.exports = handler;
