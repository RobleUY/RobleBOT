let handler = async (message, { conn }) => {
    try {
        // Obtener el JID completo
        let botJid = conn.user?.id || conn.user?.jid;

        if (!botJid) {
            return await message.reply("❌ No pude obtener mi número.");
        }

        // Eliminar todo después de ":" (como :1, :2, etc)
        botJid = botJid.split(":")[0];

        // Normalizar solo números
        const botNumber = botJid.replace(/[^0-9]/g, '');

        await message.reply(`🤖 *Mi número es:*\nwa.me/${botNumber}`);

    } catch (err) {
        console.error("[ERROR OBTENER NÚMERO BOT]:", err);
        await message.reply("⚠️ Error al obtener el número del bot.");
    }
};

handler.help = ['botnumber', 'numerobot'];
handler.tags = ['info'];
handler.command = /^botnumber|numerobot|numdelbot|botnum$/i;

module.exports = handler;
