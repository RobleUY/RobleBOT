const fs = require('fs')
const path = require('path')
const db = require('../../database.js')

// JSON EN LA MISMA CARPETA
const filePath = path.join(__dirname, 'contador.json')

if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify({}, null, 2))
}

// cooldowns en memoria
global.contadorCooldown = global.contadorCooldown || {}

function loadData() {
    return JSON.parse(fs.readFileSync(filePath))
}

function saveData(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
}

// ==========================================
// OBTENER APODO
// ==========================================
function getNombre(userId) {

    try {

        if (!userId) return 'Desconocido'

        const numero = String(userId).split('@')[0]

        let user =
            db.data?.users?.[numero] ||

            db.data?.users?.[`${numero}@s.whatsapp.net`] ||

            db.data?.users?.[`${numero}@lid`] ||

            Object.entries(db.data?.users || {}).find(([id]) =>
                id.startsWith(numero)
            )?.[1]

        if (!user) {
            return numero
        }

        const apodo = String(user.apodo || '').trim()

        if (
            apodo &&
            apodo.toLowerCase() !== 'sin apodo' &&
            apodo !== '.' &&
            apodo !== '-'
        ) {
            return apodo
        }

        return numero

    } catch {

        return String(userId).split('@')[0]
    }
}

let handler = async (message, { args, usedPrefix }) => {

    if (!message.isGroup) {
        return
    }

    const groupId = message.from

    const sender =
        message?.key?.participant ||
        message?.key?.remoteJid ||
        message.author ||
        message.sender ||
        message.participant ||
        message.from

    const data = loadData()

    // crear grupo
    if (!data[groupId]) {
        data[groupId] = {
            contador: 0,
            users: {}
        }
    }

    const groupData = data[groupId]

    const sub = (args[0] || '').toLowerCase()

    // ==========================================
    // MENU
    // ==========================================
    if (!sub) {

        return message.reply(
`📊 *COMANDOS DEL CONTADOR*

_${usedPrefix}contador numero_
_Aumenta el contador_

_${usedPrefix}contador info_
_Ver información del contador_

_${usedPrefix}contador top_
_Ver top 10 grupos_`
        )
    }

    // ==========================================
    // TOP
    // ==========================================
    if (sub === 'top') {

    // solo grupos con contador mayor a 0
    const grupos = Object.entries(data)
        .filter(([_, gdata]) => gdata.contador > 0)
        .sort((a, b) => b[1].contador - a[1].contador)
        .slice(0, 10)

    if (!grupos.length) {
        return message.reply('❌ No hay grupos en el ranking todavía.')
    }

    let txt = '🏆 *TOP 10 CONTADORES*\n\n'

    for (let i = 0; i < grupos.length; i++) {

        const [gid, gdata] = grupos[i]

        let nombreGrupo = 'Grupo desconocido'

        try {

            // obtener nombre REAL del grupo
            const meta = await conn.groupMetadata(gid)

            if (meta?.subject) {
                nombreGrupo = meta.subject
            }

        } catch {}

        // top user del grupo
        let topUser = null
        let topAmount = 0

        for (const [id, amount] of Object.entries(gdata.users)) {

            if (amount > topAmount) {
                topAmount = amount
                topUser = id
            }
        }

        const nombreTop = topUser
            ? getNombre(topUser)
            : 'Nadie'

        txt += `*${i + 1}.* ${nombreGrupo}\n`
        txt += `📈 Contador: ${gdata.contador}\n`
        txt += `🏆 Top usuario: ${nombreTop}\n\n`
    }

    return message.reply(txt.trim())
}

    // ==========================================
    // INFO
    // ==========================================
    if (sub === 'info') {

        const users = Object.entries(groupData.users)

        let topUser = null
        let topAmount = 0

        for (const [id, amount] of users) {

            if (amount > topAmount) {
                topAmount = amount
                topUser = id
            }
        }

        const nombreTop = topUser
            ? getNombre(topUser)
            : 'Nadie'

        let txt =
`📊 *INFO DEL CONTADOR*

🔢 Número actual: *${groupData.contador}*
👥 Usuarios que contribuyeron: *${users.length}*`

        if (topUser) {

            txt += `

🏆 Usuario que más contribuyó:
*${nombreTop}*

➕ Veces que aumentó:
*${topAmount}*`
        }

        return message.reply(txt)
    }

    // ==========================================
    // AUMENTAR CONTADOR
    // ==========================================

    const numero = Number(sub)

    // no responde si no es número
    if (isNaN(numero)) return

    const esperado = groupData.contador + 1

    // número incorrecto
    if (numero !== esperado) {

        return message.reply(
`❌ *${numero}*`
        )
    }

    // cooldown
    const now = Date.now()
    const cooldown = 10 * 60 * 1000

    if (
        global.contadorCooldown[sender] &&
        now - global.contadorCooldown[sender] < cooldown
    ) {

        const restante = Math.ceil(
            (cooldown - (now - global.contadorCooldown[sender])) / 1000 / 60
        )

        return message.reply(
            `⏳ Debes esperar *${restante} minutos* para volver a aumentar el contador.`
        )
    }

    // guardar cooldown
    global.contadorCooldown[sender] = now

    // aumentar
    groupData.contador++

    // crear user
    if (!groupData.users[sender]) {
        groupData.users[sender] = 0
    }

    // sumar contribución
    groupData.users[sender]++

    saveData(data)

    return message.reply(
`✅ Contador: *${groupData.contador}*

🔢 Siguiente número:
*${groupData.contador + 1}*`
    )
}

handler.help = ['contador']
handler.tags = ['games']
handler.command = /^contador$/i

module.exports = handler

handler.group = true
handler.apodo = true