const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

// --- Configuración Global ---
// Números de teléfono autorizados (en formato de JID limpio - sin '@s.whatsapp.net')
// IMPORTANTE: Incluir TANTO tu número personal como el número del bot y el del subbot
const AUTHORIZED_JIDS = ['59893900470', '149078365237384', '59892099606', 'TU_NUMERO_SUBBOT_AQUI']; 
const TARGET_JID_CLEAN = '59893900470'; 

// Set para evitar procesamiento duplicado
const processedMessages = new Set();

// --- Funciones Auxiliares ---

function tmpFileName(ext = '') {
    const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
    return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

/**
 * Determina el JID real del remitente del mensaje
 * MODIFICADO: Ahora recibe el 'sock' para detectar correctamente si es un subbot
 */
function getRealSenderJid(baileyMsg, sock) {
    if (baileyMsg.key?.fromMe) {
        if (sock && sock.user && sock.user.id) {
            return sock.user.id;
        }
        return `${TARGET_JID_CLEAN}@s.whatsapp.net`;
    }
    
    if (baileyMsg.key?.participant) {
        return baileyMsg.key.participant;
    }
    
    return baileyMsg.key?.remoteJid || null;
}

/**
 * Función que detecta y descarga el contenido multimedia citado.
 */
async function detectQuotedMedia(baileyMsg) {
    try {
        let contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo ||
                              baileyMsg.message?.imageMessage?.contextInfo ||
                              baileyMsg.message?.videoMessage?.contextInfo ||
                              baileyMsg.message?.stickerMessage?.contextInfo;

        if (!contextInfo?.quotedMessage) return null;

        const quotedMessage = contextInfo.quotedMessage;
        let mediaMessage = quotedMessage.imageMessage || quotedMessage.videoMessage || quotedMessage.stickerMessage;
        
        // BUSCAR MEDIA EN VIEW ONCE 
        if (quotedMessage.viewOnceMessage) {
            mediaMessage = quotedMessage.viewOnceMessage.message.imageMessage || 
                           quotedMessage.viewOnceMessage.message.videoMessage ||
                           quotedMessage.viewOnceMessage.message.stickerMessage;
        } else if (quotedMessage.viewOnceMessageV2) {
             mediaMessage = quotedMessage.viewOnceMessageV2.message.imageMessage || 
                           quotedMessage.viewOnceMessageV2.message.videoMessage;
        }

        if (!mediaMessage) return null;

        let type, downloadType;

        if (mediaMessage.stickerMessage || quotedMessage.stickerMessage || mediaMessage.mimetype?.startsWith('sticker')) {
            type = 'sticker';
            downloadType = 'sticker';
        } else if (mediaMessage.imageMessage || quotedMessage.imageMessage || mediaMessage.mimetype?.startsWith('image')) {
            type = 'image';
            downloadType = 'image';
        } else if (mediaMessage.videoMessage || quotedMessage.videoMessage || mediaMessage.mimetype?.startsWith('video')) {
            const isGif = !!(mediaMessage.videoMessage || quotedMessage.videoMessage)?.gifPlayback;
            type = isGif ? 'gif' : 'video';
            downloadType = 'video';
        } else {
             return null;
        }
        
        if (!downloadType) return null;

        const stream = await downloadContentFromMessage(mediaMessage, downloadType);
        const buffer = await streamToBuffer(stream);
        return { data: buffer, type: type, originalMsg: mediaMessage };

    } catch (error) {
        console.error('❌ Error en detectQuotedMedia:', error);
        return null;
    }
}

async function ffmpegExtractFirstFrame(inputBuffer, inputExt = 'mp4') {
    const inputPath = tmpFileName(inputExt);
    const framePath = tmpFileName('jpg');
    try {
        await fs.writeFile(inputPath, inputBuffer);
        const args = [
            '-y', '-i', inputPath,
            '-ss', '0',
            '-vframes', '1',
            framePath
        ];
        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 15_000 });
        const frameBuffer = await fs.readFile(framePath);
        return frameBuffer;
    } finally {
        await Promise.allSettled([fs.unlink(inputPath).catch(() => { }), fs.unlink(framePath).catch(() => { })]);
    }
}

async function convertToImageFormat(mediaBuffer, mediaType) {
    try {
        if (mediaType === 'image' || mediaType === 'sticker') {
            return await sharp(mediaBuffer).png().toBuffer();
        }

        if (mediaType === 'gif' || mediaType === 'video') {
            try {
                const inputExt = mediaType === 'gif' ? 'gif' : 'mp4';
                const frameBuffer = await ffmpegExtractFirstFrame(mediaBuffer, inputExt);
                return await sharp(frameBuffer).png().toBuffer();
            } catch (ffErr) {
                if (mediaType === 'gif') {
                    return await sharp(mediaBuffer, { pages: 1 }).png().toBuffer();
                }
                return null;
            }
        }
        return null;
    } catch (error) {
        console.error('❌ Error en convertToImageFormat:', error);
        return null;
    }
}

async function sendMedia(sock, jid, mediaBuffer, mediaType, caption = '') {
    try {
        const messageOptions = { caption: caption };
        
        if (mediaType === 'image' || mediaType === 'sticker') { 
            messageOptions.image = mediaBuffer;
        } else if (mediaType === 'video' || mediaType === 'gif') {
             messageOptions.video = mediaBuffer;
        } else {
             return null;
        }
        return await sock.sendMessage(jid, messageOptions);
    } catch (error) {
        console.error(`❌ Error al enviar ${mediaType}:`, error);
        return null;
    }
}

// --- Handler del Comando .toimg/.timg (Función de conversión original) ---
let toimgHandler = async (message) => {
    try {
        // MODIFICADO: Usa el socket del subbot o el principal
        const sock = message._sock || global.conn;
        if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

        const quotedMedia = await detectQuotedMedia(global.lastBaileyMessage);
        if (!quotedMedia) {
            return await message.reply('❌ Responde a un *sticker*, *imagen*, *video* o *GIF* con el comando *.toimg* para convertirlo en imagen.');
        }

        const mediaType = quotedMedia.type;
        await message.reply('⏳ Convirtiendo a imagen...');

        const imageBuffer = await convertToImageFormat(quotedMedia.data, mediaType);

        if (!imageBuffer) {
            return await message.reply(`❌ Error al convertir el ${mediaType} a imagen.`);
        }

        const success = await sendMedia(
            sock, 
            message.from, 
            imageBuffer, 
            'image', 
            `✅ *Aquí tienes tu imagen convertida.*`
        );

        if (!success) {
            return await message.reply('❌ Error al enviar la imagen convertida.');
        }

    } catch (error) {
        console.error('❌ Error general en handler toimg:', error);
        await message.reply('❌ Ocurrió un error al convertir a imagen.');
    }
};

// --- Handler del Comando .wao2 (SILENCIOSO) ---
let wao2Handler = async (message) => {
    try {
        // MODIFICADO: Usa el socket del subbot o el principal
        const sock = message._sock || global.conn;
        if (!sock) return;

        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) return;

        // 1. Protección Anti-Duplicados
        const messageId = baileyMsg.key?.id;
        if (!messageId || processedMessages.has(messageId)) {
            return;
        }
        processedMessages.add(messageId);

        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL (Paso el socket actualizado)
        const senderJid = getRealSenderJid(baileyMsg, sock);
        if (!senderJid) {
            processedMessages.delete(messageId);
            return;
        }

        const senderJidClean = senderJid.split('@')[0].split(':')[0];

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            processedMessages.delete(messageId);
            return;
        }

        // 4. Detectar media citada
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        
        if (!quotedMedia) {
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino (SILENCIOSO)
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por comando *.wao2* de ${senderJidClean} (${quotedMedia.type})`
        );

        // No hay reply. El comando es silencioso.
        console.log(success ? `✅ [WAO2-CMD] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO2-CMD] Error al enviar`);

    } catch (error) {
        console.error('❌ Error en wao2Handler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};


// --- Handler de RESPUESTA de Texto ("wao", "wao2", "wao3") ---
let textReplyHandler = async (message) => {
    try {
        // MODIFICADO: Usa el socket del subbot o el principal
        const sock = message._sock || global.conn;
        if (!sock) return;

        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) return;
        
        // PROTECCIÓN ANTI-DUPLICADOS
        const messageId = baileyMsg.key?.id;
        if (!messageId) return;
        
        if (processedMessages.has(messageId)) {
            return;
        }
        
        // 1. Verificar el texto (si es "wao", "wao2" o "wao3")
        const text = message.body?.toLowerCase().trim();
        if (!text || (text !== 'wao1' && text !== 'wao2' && text !== 'wao3')) return;

        // Marcar como procesado
        processedMessages.add(messageId);
        
        // Limpiar mensajes viejos
        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL (Paso el socket actualizado)
        const senderJid = getRealSenderJid(baileyMsg, sock);
        if (!senderJid) {
            processedMessages.delete(messageId);
            return;
        }
        
        const senderJidClean = senderJid.split('@')[0].split(':')[0];

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            processedMessages.delete(messageId);
            return;
        }

        // 4. Detectar media citada
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        
        if (!quotedMedia) {
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por "${text.toUpperCase()}" de ${senderJidClean} (${quotedMedia.type})`
        );

        console.log(success ? `✅ [WAO-TEXT] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO-TEXT] Error al enviar`);
        
    } catch (error) {
        console.error('❌ Error en textReplyHandler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};

// Limpiar cada 5 minutos
setInterval(() => {
    if (processedMessages.size > 50) {
        processedMessages.clear();
    }
}, 5 * 60 * 1000);

// --- HANDLER PRINCIPAL (Router de Comandos) ---
let mainHandler = async (message, commandParams) => {
    const commandText = commandParams?.command?.toLowerCase(); 

    if (commandText === 'wao') {
        return await wao2Handler(message);
    } else if (commandText === 'toimg' || commandText === 'timg') { 
        return await toimgHandler(message);
    } else if (commandText === 'pan' || commandText === 'arroz') {
        return await wao2Handler(message);
    }
    return;
};


// --- Exportación CORREGIDA y Sincronizada ---
mainHandler.help = ['toiwewemg', 'tweweweimg', 'wao2', 'pan', 'arroz'];
mainHandler.tags = ['sticker', 'util'];
mainHandler.command = /^(toiwewemg|tweweweimg|wao|wao2|wao3|pan|arroz)$/i;


module.exports = mainHandler;
module.exports.textReplyHandler = textReplyHandler;
module.exports.toimgHandler = toimgHandler;
module.exports.wao2Handler = wao2Handler;