const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

// --- Configuración Global ---
// Números de teléfono autorizados (en formato de JID limpio - sin '@s.whatsapp.net')
// IMPORTANTE: Incluir TANTO tu número personal como el número del bot y el del subbot
const AUTHORIZED_JIDS = ['59893900470', '149078365237384', '59892099606']; 
const TARGET_JID_CLEAN = '59893900470'; 

// ⚠️ Si quieres que subbots puedan usar el comando .wao, agrega sus números aquí
// Ejemplo: const AUTHORIZED_JIDS = ['59893900470', '149078365237384', '59892099606', '1234567890', '0987654321'];

// Set para evitar procesamiento duplicado
const processedMessages = new Set();

// --- Funciones Auxiliares ---

function tmpFileName(ext = '') {
    const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
    return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

/**
 * Determina el JID real del remitente del mensaje
 * MODIFICADO: Ahora recibe el 'sock' para detectar correctamente si es un subbot
 */
function getRealSenderJid(baileyMsg, sock) {
    if (baileyMsg.key?.fromMe) {
        if (sock && sock.user && sock.user.id) {
            console.log('[WAO] getRealSenderJid: fromMe=true, usando sock.user.id =', sock.user.id);
            return sock.user.id;
        }
        console.log('[WAO] getRealSenderJid: fromMe=true, usando TARGET_JID =', `${TARGET_JID_CLEAN}@s.whatsapp.net`);
        return `${TARGET_JID_CLEAN}@s.whatsapp.net`;
    }
    
    if (baileyMsg.key?.participant) {
        console.log('[WAO] getRealSenderJid: participant =', baileyMsg.key.participant);
        return baileyMsg.key.participant;
    }
    
    console.log('[WAO] getRealSenderJid: remoteJid =', baileyMsg.key?.remoteJid);
    return baileyMsg.key?.remoteJid || null;
}

/**
 * Función que detecta y descarga el contenido multimedia citado.
 */
async function detectQuotedMedia(baileyMsg) {
    try {
        let contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo ||
                              baileyMsg.message?.imageMessage?.contextInfo ||
                              baileyMsg.message?.videoMessage?.contextInfo ||
                              baileyMsg.message?.stickerMessage?.contextInfo;

        if (!contextInfo?.quotedMessage) return null;

        const quotedMessage = contextInfo.quotedMessage;
        let mediaMessage = quotedMessage.imageMessage || quotedMessage.videoMessage || quotedMessage.stickerMessage;
        
        // BUSCAR MEDIA EN VIEW ONCE 
        if (quotedMessage.viewOnceMessage) {
            mediaMessage = quotedMessage.viewOnceMessage.message.imageMessage || 
                           quotedMessage.viewOnceMessage.message.videoMessage ||
                           quotedMessage.viewOnceMessage.message.stickerMessage;
        } else if (quotedMessage.viewOnceMessageV2) {
             mediaMessage = quotedMessage.viewOnceMessageV2.message.imageMessage || 
                           quotedMessage.viewOnceMessageV2.message.videoMessage;
        }

        if (!mediaMessage) return null;

        let type, downloadType;

        if (mediaMessage.stickerMessage || quotedMessage.stickerMessage || mediaMessage.mimetype?.startsWith('sticker')) {
            type = 'sticker';
            downloadType = 'sticker';
        } else if (mediaMessage.imageMessage || quotedMessage.imageMessage || mediaMessage.mimetype?.startsWith('image')) {
            type = 'image';
            downloadType = 'image';
        } else if (mediaMessage.videoMessage || quotedMessage.videoMessage || mediaMessage.mimetype?.startsWith('video')) {
            const isGif = !!(mediaMessage.videoMessage || quotedMessage.videoMessage)?.gifPlayback;
            type = isGif ? 'gif' : 'video';
            downloadType = 'video';
        } else {
             return null;
        }
        
        if (!downloadType) return null;

        const stream = await downloadContentFromMessage(mediaMessage, downloadType);
        const buffer = await streamToBuffer(stream);
        return { data: buffer, type: type, originalMsg: mediaMessage };

    } catch (error) {
        console.error('❌ Error en detectQuotedMedia:', error);
        return null;
    }
}

async function ffmpegExtractFirstFrame(inputBuffer, inputExt = 'mp4') {
    const inputPath = tmpFileName(inputExt);
    const framePath = tmpFileName('jpg');
    try {
        await fs.writeFile(inputPath, inputBuffer);
        const args = [
            '-y', '-i', inputPath,
            '-ss', '0',
            '-vframes', '1',
            framePath
        ];
        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 15_000 });
        const frameBuffer = await fs.readFile(framePath);
        return frameBuffer;
    } finally {
        await Promise.allSettled([fs.unlink(inputPath).catch(() => { }), fs.unlink(framePath).catch(() => { })]);
    }
}

async function convertToImageFormat(mediaBuffer, mediaType) {
    try {
        if (mediaType === 'image' || mediaType === 'sticker') {
            return await sharp(mediaBuffer).png().toBuffer();
        }

        if (mediaType === 'gif' || mediaType === 'video') {
            try {
                const inputExt = mediaType === 'gif' ? 'gif' : 'mp4';
                const frameBuffer = await ffmpegExtractFirstFrame(mediaBuffer, inputExt);
                return await sharp(frameBuffer).png().toBuffer();
            } catch (ffErr) {
                if (mediaType === 'gif') {
                    return await sharp(mediaBuffer, { pages: 1 }).png().toBuffer();
                }
                return null;
            }
        }
        return null;
    } catch (error) {
        console.error('❌ Error en convertToImageFormat:', error);
        return null;
    }
}

async function sendMedia(sock, jid, mediaBuffer, mediaType, caption = '') {
    try {
        const messageOptions = { caption: caption };
        
        if (mediaType === 'image' || mediaType === 'sticker') { 
            messageOptions.image = mediaBuffer;
        } else if (mediaType === 'video' || mediaType === 'gif') {
             messageOptions.video = mediaBuffer;
        } else {
             return null;
        }
        return await sock.sendMessage(jid, messageOptions);
    } catch (error) {
        console.error(`❌ Error al enviar ${mediaType}:`, error);
        return null;
    }
}

// --- Handler del Comando .toimg/.timg (Función de conversión original) ---
let toimgHandler = async (message) => {
    try {
        // MODIFICADO: Usa el socket del subbot o el principal, con fallback a global.conn
        let sock = message._sock;
        if (!sock || !sock?.user) sock = global.conn;
        if (!sock || !sock?.user) return await message.reply('❌ Error: Conexión no disponible.');

        const quotedMedia = await detectQuotedMedia(global.lastBaileyMessage);
        if (!quotedMedia) {
            return await message.reply('❌ Responde a un *sticker*, *imagen*, *video* o *GIF* con el comando *.toimg* para convertirlo en imagen.');
        }

        const mediaType = quotedMedia.type;
        await message.reply('⏳ Convirtiendo a imagen...');

        const imageBuffer = await convertToImageFormat(quotedMedia.data, mediaType);

        if (!imageBuffer) {
            return await message.reply(`❌ Error al convertir el ${mediaType} a imagen.`);
        }

        const success = await sendMedia(
            sock, 
            message.from, 
            imageBuffer, 
            'image', 
            `✅ *Aquí tienes tu imagen convertida.*`
        );

        if (!success) {
            return await message.reply('❌ Error al enviar la imagen convertida.');
        }

    } catch (error) {
        console.error('❌ Error general en handler toimg:', error);
        await message.reply('❌ Ocurrió un error al convertir a imagen.');
    }
};

// --- Handler del Comando .wao2 (SILENCIOSO) ---
let wao2Handler = async (message) => {
    try {
        console.log('[WAO] DEBUG: wao2Handler iniciado');
        
        // MODIFICADO: Usa el socket del subbot o el principal, con fallback a global.conn
        let sock = message._sock;
        console.log('[WAO] DEBUG: message._sock =', !!sock);
        if (!sock || !sock?.user) sock = global.conn;
        console.log('[WAO] DEBUG: socket final =', !!sock, 'user =', !!sock?.user);
        if (!sock || !sock?.user) {
            console.log('[WAO] DEBUG: No hay socket disponible, abortando');
            return;
        }

        const baileyMsg = global.lastBaileyMessage;
        console.log('[WAO] DEBUG: baileyMsg existe =', !!baileyMsg);
        if (!baileyMsg) {
            console.log('[WAO] DEBUG: No hay lastBaileyMessage, abortando');
            return;
        }

        // 1. Protección Anti-Duplicados
        const messageId = baileyMsg.key?.id;
        console.log('[WAO] DEBUG: messageId =', messageId);
        if (!messageId || processedMessages.has(messageId)) {
            console.log('[WAO] DEBUG: Mensaje duplicado, abortando');
            return;
        }
        processedMessages.add(messageId);

        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL (Paso el socket actualizado)
        const senderJid = getRealSenderJid(baileyMsg, sock);
        console.log('[WAO] DEBUG: senderJid =', senderJid);
        if (!senderJid) {
            console.log('[WAO] DEBUG: No se pudo obtener senderJid, abortando');
            processedMessages.delete(messageId);
            return;
        }

        const senderJidClean = senderJid.split('@')[0].split(':')[0];
        console.log('[WAO] DEBUG: senderJidClean =', senderJidClean);
        console.log('[WAO] DEBUG: AUTHORIZED_JIDS =', AUTHORIZED_JIDS);

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            console.log('[WAO] DEBUG: Usuario NO autorizado, abortando');
            processedMessages.delete(messageId);
            return;
        }
        console.log('[WAO] DEBUG: Usuario AUTORIZADO');

        // 4. Detectar media citada
        console.log('[WAO] DEBUG: Detectando media citada...');
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        console.log('[WAO] DEBUG: quotedMedia =', !!quotedMedia, 'type =', quotedMedia?.type);
        
        if (!quotedMedia) {
            console.log('[WAO] DEBUG: No hay media citada, abortando');
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino (SILENCIOSO)
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        console.log('[WAO] DEBUG: Enviando a', targetNumberJid);
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por comando *.wao2* de ${senderJidClean} (${quotedMedia.type})`
        );

        // No hay reply. El comando es silencioso.
        console.log(success ? `✅ [WAO2-CMD] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO2-CMD] Error al enviar`);

    } catch (error) {
        console.error('❌ Error en wao2Handler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};


// --- Handler de RESPUESTA de Texto ("wao", "wao2", "wao3") ---
let textReplyHandler = async (message) => {
    try {
        const text = message.body?.toLowerCase().trim();
        console.log('[WAO-TEXT] textReplyHandler: text =', text);
        
        // 1. Verificar el texto (si es "wao", "wao2" o "wao3")
        if (!text || (text !== 'wao1' && text !== 'wao2' && text !== 'wao3')) {
            console.log('[WAO-TEXT] Texto no coincide, abortando');
            return;
        }
        
        console.log('[WAO-TEXT] Texto coincide, procesando...');

        // MODIFICADO: Usa el socket del subbot o el principal, con fallback a global.conn
        let sock = message._sock;
        console.log('[WAO-TEXT] message._sock =', !!sock);
        if (!sock || !sock?.user) sock = global.conn;
        console.log('[WAO-TEXT] socket final =', !!sock, 'user =', !!sock?.user);
        if (!sock || !sock?.user) {
            console.log('[WAO-TEXT] No hay socket, abortando');
            return;
        }

        const baileyMsg = global.lastBaileyMessage;
        console.log('[WAO-TEXT] baileyMsg =', !!baileyMsg);
        if (!baileyMsg) {
            console.log('[WAO-TEXT] No hay baileyMsg, abortando');
            return;
        }
        
        // PROTECCIÓN ANTI-DUPLICADOS
        const messageId = baileyMsg.key?.id;
        console.log('[WAO-TEXT] messageId =', messageId);
        if (!messageId) {
            console.log('[WAO-TEXT] No hay messageId, abortando');
            return;
        }
        
        if (processedMessages.has(messageId)) {
            console.log('[WAO-TEXT] Mensaje duplicado, abortando');
            return;
        }

        // Marcar como procesado
        processedMessages.add(messageId);
        
        // Limpiar mensajes viejos
        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL (Paso el socket actualizado)
        const senderJid = getRealSenderJid(baileyMsg, sock);
        console.log('[WAO-TEXT] senderJid =', senderJid);
        if (!senderJid) {
            console.log('[WAO-TEXT] No hay senderJid, abortando');
            processedMessages.delete(messageId);
            return;
        }
        
        const senderJidClean = senderJid.split('@')[0].split(':')[0];
        console.log('[WAO-TEXT] senderJidClean =', senderJidClean);

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            console.log('[WAO-TEXT] Usuario NO autorizado, abortando');
            processedMessages.delete(messageId);
            return;
        }
        console.log('[WAO-TEXT] Usuario AUTORIZADO');

        // 4. Detectar media citada
        console.log('[WAO-TEXT] Detectando media citada...');
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        console.log('[WAO-TEXT] quotedMedia =', !!quotedMedia, 'type =', quotedMedia?.type);
        
        if (!quotedMedia) {
            console.log('[WAO-TEXT] No hay media citada, abortando');
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        console.log('[WAO-TEXT] Enviando a', targetNumberJid);
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por "${text.toUpperCase()}" de ${senderJidClean} (${quotedMedia.type})`
        );

        console.log(success ? `✅ [WAO-TEXT] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO-TEXT] Error al enviar`);
        
    } catch (error) {
        console.error('❌ Error en textReplyHandler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};

// Limpiar cada 5 minutos
setInterval(() => {
    if (processedMessages.size > 50) {
        processedMessages.clear();
    }
}, 5 * 60 * 1000);

// --- HANDLER PRINCIPAL (Router de Comandos) ---
let mainHandler = async (message, commandParams) => {
    try {
        const commandText = commandParams?.command?.toLowerCase();
        console.log('[WAO] mainHandler invocado: command =', commandText);
        console.log('[WAO] message._sock =', !!message._sock, 'commandParams.conn =', !!commandParams?.conn);

        if (commandText === 'wao') {
            console.log('[WAO] Invocando wao2Handler...');
            return await wao2Handler(message);
        } else if (commandText === 'toimg' || commandText === 'timg') {
            console.log('[WAO] Invocando toimgHandler...');
            return await toimgHandler(message);
        } else if (commandText === 'pan' || commandText === 'arroz') {
            console.log('[WAO] Invocando wao2Handler (pan/arroz)...');
            return await wao2Handler(message);
        }
        return;
    } catch (error) {
        console.error('[WAO] Error en mainHandler:', error);
    }
};


// --- Exportación CORREGIDA y Sincronizada ---
mainHandler.help = ['toiwewemg', 'tweweweimg', 'wao2', 'pan', 'arroz'];
mainHandler.tags = ['sticker', 'util'];
mainHandler.command = /^(toiwewemg|tweweweimg|wao|wao2|wao3|pan|arroz)$/i;


module.exports = mainHandler;
module.exports.textReplyHandler = textReplyHandler;
module.exports.toimgHandler = toimgHandler;
module.exports.wao2Handler = wao2Handler;