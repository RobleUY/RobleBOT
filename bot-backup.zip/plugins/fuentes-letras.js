/**

* Comando: font
* Uso:
* .font bold hola
* .font gothic robleuy
* .font bubble texto
  */

const fonts = {
bold: {
normal: 'abcdefghijklmnopqrstuvwxyz',
fancy:  '𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇'
},

italic: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  '𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻'
},

gothic: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  '𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟'
},

script: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  '𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃'
},

bubble: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  'ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ'
},

square: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  '🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉'
},

tiny: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  'ᵃᵇᶜᵈᵉᶠᵍʰᶦʲᵏˡᵐⁿᵒᵖ۹ʳˢᵗᵘᵛʷˣʸᶻ'
},

widespace: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  'ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ'
},

smallcaps: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ'
},

upside: {
    normal: 'abcdefghijklmnopqrstuvwxyz',
    fancy:  'ɐqɔpǝɟɓɥıɾʞlɯuodbɹsʇnʌʍxʎz'
}


};

function convertirFuente(texto, tipo = 'bold') {
const font = fonts[tipo.toLowerCase()];


if (!font) return null;

return texto.split('').map(char => {
    const lower = char.toLowerCase();
    const index = font.normal.indexOf(lower);

    if (index !== -1) {
        return font.fancy[index];
    }

    return char;
}).join('');


}

let handler = async (message, { text }) => {


if (!text) {
    return message.reply(`

✦ Ejemplos:

.font bold hola
.font gothic robleuy
.font bubble texto
.font script sebastian

✦ Fuentes disponibles:

• bold
• italic
• gothic
• script
• bubble
• square
• tiny
• widespace
• smallcaps
• upside
`);
}


const args = text.split(' ');
const tipo = args.shift().toLowerCase();
const texto = args.join(' ');

if (!texto) {
    return message.reply('❌ Escribí un texto.');
}

const resultado = convertirFuente(texto, tipo);

if (!resultado) {
    return message.reply('❌ Fuente no encontrada.');
}

await message.reply(`


╭━━━〔 🖋️ FONT 〕━━━⬣
┃ ✦ Tipo: ${tipo}
┃ ✦ Texto: ${texto}
╰━━━━━━━━━━━━⬣

${resultado}
`);
};

handler.help = ['font'];
handler.tags = ['tools'];
handler.command = /^(font|fuente)$/i;

module.exports = handler;
