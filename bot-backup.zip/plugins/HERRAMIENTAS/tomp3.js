/**
 * Comando: tomp3
 * Descripción: Convierte stickers, videos o notas de voz en audio MP3
 * Uso: Responde a un sticker de audio, video o nota de voz con .tomp3
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

/**
 * Genera un nombre de archivo temporal único en el directorio temporal del sistema.
 * @param {string} [ext=''] - Extensión del archivo.
 * @returns {string} Ruta completa del archivo temporal.
 */
function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte un stream a un Buffer.
 * @param {ReadableStream} stream - El stream a convertir.
 * @returns {Promise<Buffer>} El buffer resultante.
 */
async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * Detecta y descarga el contenido multimedia del mensaje citado.
 * @returns {Promise<{data: Buffer, mimetype: string, type: 'audio'|'video'}|null>} Los datos del media citado.
 */
async function detectQuotedMedia() {
  try {
    // Asumiendo que 'global.lastBaileyMessage' contiene el mensaje reciente de @whiskeysockets/baileys.
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    let contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo
                      || baileyMsg.message?.audioMessage?.contextInfo
                      || baileyMsg.message?.videoMessage?.contextInfo;

    // Si el mensaje actual es una respuesta (tiene contextInfo)
    if (!contextInfo?.quotedMessage) return null;

    const quotedMessage = contextInfo.quotedMessage;

    // audioMessage (nota de voz o audio)
    if (quotedMessage.audioMessage) {
      const stream = await downloadContentFromMessage(quotedMessage.audioMessage, 'audio');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: quotedMessage.audioMessage.mimetype || 'audio/ogg',
        type: 'audio'
      };
    }

    // videoMessage
    if (quotedMessage.videoMessage) {
      const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4',
        type: 'video'
      };
    }
    
    // Si fuera un sticker animado, necesitaría manejo de 'stickerMessage' y quizás descarga.
    // console.log('❌ Tipo de mensaje citado no soportado para audio');
    return null;
  } catch (error) {
    console.error('❌ Error detectando media:', error);
    return null;
  }
}

/**
 * Convierte cualquier media a MP3 usando ffmpeg.
 * @param {Buffer} mediaBuffer - Buffer del media de entrada.
 * @param {'audio'|'video'} mediaType - Tipo de media.
 * @returns {Promise<Buffer|null>} Buffer del MP3 resultante, o null en caso de error.
 */
async function convertToMP3(mediaBuffer, mediaType) {
  const inputExt = mediaType === 'video' ? 'mp4' : 'ogg';
  const inputPath = tmpFileName(inputExt);
  const outputPath = tmpFileName('mp3');

  try {
    await fs.writeFile(inputPath, mediaBuffer);
    
    // Comando ffmpeg:
    // -y: Sobrescribir salida
    // -i: Archivo de entrada
    // -vn: Eliminar video stream (solo audio)
    // -ar 44100: Frecuencia de muestreo 44.1 kHz
    // -ac 2: Canales estéreo
    // -b:a 192k: Bitrate de audio 192 kbps
    await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-vn', '-ar', '44100', '-ac', '2', '-b:a', '192k', outputPath], { windowsHide: true, timeout: 30000 });
    
    const mp3Buffer = await fs.readFile(outputPath);
    return mp3Buffer;
  } catch (err) {
    console.error('❌ Error en FFmpeg:', err);
    return null;
  } finally {
    // Limpieza de archivos temporales
    // Usamos Promise.allSettled para ignorar errores si un archivo ya fue borrado
    Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * Envía el buffer de audio como un mensaje de audio.
 * @param {object} sock - Objeto de conexión de @whiskeysockets/baileys.
 * @param {object} message - El objeto del mensaje original (para la respuesta).
 * @param {Buffer} audioBuffer - El buffer del audio MP3.
 * @param {string} [caption=''] - El texto de la respuesta.
 * @returns {Promise<boolean>} True si el envío fue exitoso.
 */
async function sendAudio(sock, message, audioBuffer, caption = '') {
  try {
    await sock.sendMessage(message.from, {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      fileName: 'audio.mp3',
      caption: caption,
      quoted: message // <--- ESTO GARANTIZA QUE EL AUDIO RESPONDA AL COMANDO
    });
    return true;
  } catch (error) {
    console.error('❌ Error enviando audio:', error);
    return false;
  }
}

// Handler principal
let handler = async (message, { text, args }) => {
  try {
    const sock = global.conn; // Asumiendo que la conexión está en global.conn
    if (!sock) return await message.reply('❌ Conexión no disponible.');

    const quotedMedia = await detectQuotedMedia();
    if (!quotedMedia) return await message.reply('❌ Responde a un *audio*, *video* o *nota de voz* con el comando *.tomp3* para convertirlo a MP3.');

    // Mensaje de progreso. Usa .reply(), que debería responder al mensaje del comando.
    await message.reply('⏳ Convirtiendo a MP3...');

    const mp3Buffer = await convertToMP3(quotedMedia.data, quotedMedia.type);
    if (!mp3Buffer) return await message.reply('❌ Error al convertir a MP3. Asegúrate de tener *FFmpeg* instalado.');

    // Envía el audio. La función `sendAudio` asegura que sea una respuesta al `message` del comando.
    const success = await sendAudio(sock, message, mp3Buffer, '✅ Aquí tienes tu audio en MP3.');
    if (!success) return await message.reply('❌ Error al enviar el audio convertido.');

  } catch (error) {
    console.error('❌ Error general en handler tomp3:', error);
    await message.reply('❌ Ocurrió un error al convertir a MP3.');
  }
};

// --- Configuración del Handler ---
handler.help = ['tomp3'];
handler.tags = ['sticker', 'audio', 'video'];
handler.command = /^(tomp3)$/i; // Permite .tomp3, /tomp3, etc.

module.exports = handler;