/**
 * Comando: .fecha / .hora
 * Flujo:
 *  1) Se pide la lista completa de países+timezones a /timezones (para
 *     mapear "Uruguay" -> "America/Montevideo")
 *  2) Se busca el país (o timezone) que escribió el usuario en esa lista
 *  3) La fecha/hora YA NO se pide a la API (llegaba desactualizada) — se
 *     calcula en el momento con moment-timezone, usando el tz encontrado.
 */

const moment = require('moment-timezone');

const TIMEZONES_URL = 'https://robleuy.vercel.app/robleapi/tools/datetime/timezones';

// Caché en memoria de la lista de timezones (se refresca cada 1h)
let timezonesCache = null;
let timezonesCacheAt = 0;
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hora

moment.locale('es');

/**
 * Obtiene fetch: usa el global si existe (Node 18+), si no cae a node-fetch.
 */
async function getFetch() {
  if (global.fetch) return global.fetch;
  const mod = await import('node-fetch');
  return mod.default;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * GET con reintentos, usando fetch nativo con timeout manual vía AbortController.
 */
async function fetchJsonWithRetry(url, { retries = 2, timeoutMs = 10000 } = {}) {
  const fetchFn = await getFetch();
  let lastError = null;

  for (let attempt = 1; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const res = await fetchFn(url, { signal: controller.signal });
      clearTimeout(timer);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      return await res.json();
    } catch (error) {
      clearTimeout(timer);
      lastError = error;
      const isLastAttempt = attempt === retries;

      console.warn(
        `⚠️ [fecha/hora] Intento ${attempt}/${retries} falló → ${url} → ${error.code || error.message}`
      );

      if (isLastAttempt) break;
      await sleep(700 * attempt);
    }
  }

  throw lastError;
}

/**
 * Quita tildes y pasa a minúsculas para comparar sin problemas de acentos
 */
function normalize(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

/**
 * Trae la lista completa de países+timezones (con caché)
 */
async function getTimezones() {
  const now = Date.now();
  if (timezonesCache && (now - timezonesCacheAt) < CACHE_TTL_MS) {
    return timezonesCache;
  }

  const data = await fetchJsonWithRetry(TIMEZONES_URL);

  if (!data || !data.ok || !Array.isArray(data.timezones)) {
    throw new Error('Respuesta inválida de la API de timezones.');
  }

  timezonesCache = data.timezones;
  timezonesCacheAt = now;
  return timezonesCache;
}

/**
 * Busca en la lista de timezones el país (o tz) que escribió el usuario.
 */
function findTimezone(query, timezones) {
  const q = normalize(query).replace(/_/g, ' ');

  let match = timezones.find(t => normalize(t.pais) === q);
  if (match) return match;

  match = timezones.find(t => normalize(t.tz).replace(/_/g, ' ') === q);
  if (match) return match;

  match = timezones.find(t => normalize(t.pais).includes(q));
  if (match) return match;

  match = timezones.find(t => normalize(t.tz).replace(/_/g, ' ').includes(q));
  if (match) return match;

  return null;
}

function buildTimezonesList(timezones) {
  const lines = timezones.map((t, i) => `${i + 1}. *${t.pais}* — ${t.tz}`);
  return (
    `🌍 *Zonas horarias disponibles* (${timezones.length})\n\n` +
    lines.join('\n') +
    `\n\n💡 Usá: *.fecha <país>* o *.hora <país>* (ej: *.fecha uruguay*)`
  );
}

/**
 * Capitaliza la primera letra (moment en español devuelve el día en minúscula)
 */
function capitalizar(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Calcula la fecha/hora ACTUAL para el tz encontrado usando moment-timezone.
 * No depende de ninguna API externa para esto: usa el reloj del servidor,
 * así que siempre está al día.
 */
function formatResult(tzEntry) {
  if (!moment.tz.zone(tzEntry.tz)) {
    throw new Error(`moment-timezone no reconoce la zona: ${tzEntry.tz}`);
  }

  const ahora = moment.tz(tzEntry.tz).locale('es');
  const fechaFormato = capitalizar(ahora.format('dddd, D [de] MMMM [de] YYYY'));
  const horaFormato = ahora.format('HH:mm');

  return (
    `📅 *Información de fecha y hora*\n\n` +
    `🌍 País: ${tzEntry.pais}\n` +
    `🕐 Zona horaria: ${tzEntry.tz}\n` +
    `📆 Fecha: ${fechaFormato}\n` +
    `⏰ Hora: ${horaFormato}`
  );
}

let handler = async (message, { text, command }) => {
  try {
    const query = (text || '').trim();

    // .fecha list / .fecha lista / .hora list / .hora lista
    if (/^(list|lista)$/i.test(query)) {
      await message.reply('🔍 *Cargando zonas horarias...* ⏳');
      const timezones = await getTimezones();
      return await message.reply(buildTimezonesList(timezones));
    }

    if (!query) {
      return await message.reply(
        `🕐 *Fecha y hora por país*\n\n` +
        `📌 *Uso:*\n` +
        `• .${command} uruguay\n` +
        `• .${command} America/Montevideo\n` +
        `• .${command} list  _(ver todos los países disponibles)_\n`
      );
    }

    await message.reply('🔍 *Buscando...* ⏳');

    // Paso 1: traer la lista completa de timezones (solo para el mapeo país -> tz)
    const timezones = await getTimezones();

    // Paso 2: buscar el país (o tz) que pidió el usuario en esa lista
    const tzEntry = findTimezone(query, timezones);

    if (!tzEntry) {
      return await message.reply(
        `❌ No encontré ningún país o zona horaria que coincida con *"${query}"*.\n` +
        `💡 Probá con *.${command} list* para ver las opciones disponibles.`
      );
    }

    // Paso 3: calcular fecha/hora actual localmente con moment-timezone
    return await message.reply(formatResult(tzEntry));

  } catch (error) {
    console.error('❌ [fecha/hora] Error final:', error.code || error.message);

    const isNetworkError = ['ECONNRESET', 'ETIMEDOUT', 'ECONNABORTED', 'ENOTFOUND', 'ECONNREFUSED', 'AbortError'].includes(error.code || error.name);
    const msg = isNetworkError
      ? '❌ ERRROR No se pudo conectar con el servidor de datos. Intenta más tarde.'
      : '❌ ERRROR Ocurrió un error al consultar la fecha/hora. Intenta nuevamente.';

    await message.reply(msg);
  }
};

handler.help = ['fecha <país>', 'hora <país>', 'fecha list', 'hora list'];
handler.tags = ['tools'];
handler.command = /^(fecha|hora)$/i;

module.exports = handler;
