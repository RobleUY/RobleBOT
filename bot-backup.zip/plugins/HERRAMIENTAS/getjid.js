/**
 * Comando: getjid
 * Descripción: Muestra el JID del chat actual o el JID correspondiente a un enlace de grupo.
 * Uso:
 *   .getjid               → muestra el ID del chat o grupo actual
 *   .getjid <enlace>      → muestra el ID del grupo correspondiente al enlace
 */

let handler = async (message, { text, conn }) => {
    try {
        // Si se pasó un enlace como argumento
        if (text && text.trim().length > 0) {
            const inviteCode = text.trim()
                .replace('https://chat.whatsapp.com/', '')
                .replace('chat.whatsapp.com/', '')
                .split(' ')[0];

            if (!inviteCode || inviteCode.length < 5)
                return await message.reply('⚠️ Enlace inválido. Usa un enlace válido de grupo de WhatsApp.');

            try {
                const groupInfo = await conn.groupGetInviteInfo(inviteCode);
                if (!groupInfo) throw new Error('no-info');

                let response = `*🆔 ID del Grupo (desde enlace):*\n\n\`${groupInfo.id}\`\n\n`;
                response += `📛 *Nombre del grupo:* ${groupInfo.subject || 'Desconocido'}\n`;
                response += `👥 *Miembros:* ${groupInfo.size || 'N/A'}\n`;
                response += `🧩 *Creado por:* ${groupInfo.owner ? '@' + groupInfo.owner.split('@')[0] : 'Desconocido'}`;

                // Enviar mensaje con o sin menciones, según corresponda
                if (groupInfo.owner) {
                    await message.reply(response, { mentions: [groupInfo.owner] });
                } else {
                    await message.reply(response);
                }

                return;

            } catch (err) {
                console.error('[ERROR] Error al obtener info del enlace:', err.message);
                return await message.reply('❌ No se pudo obtener información del enlace. Verifica que el enlace sea válido o que el grupo exista.');
            }
        }

        // Si no se pasó enlace → mostrar el JID del chat actual
        const jid = message.from;
        let response = `*🆔 ID del Chat/Grupo (JID actual):*\n\n\`${jid}\`\n`;

        if (message.isGroup) {
            const meta = await conn.groupMetadata(jid);
            response += `\n📛 *Nombre:* ${meta.subject}\n👥 *Participantes:* ${meta.participants.length}`;
        } else {
            response += `\n💬 *Chat individual*`;
        }

        await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando getjid:', error.message);
        await message.reply('❌ Ocurrió un error al intentar obtener el ID.');
    }
};

handler.help = ['getjid [enlace]'];
handler.tags = ['info'];
handler.command = /^(getjid)$/i;
handler.owner = true;

module.exports = handler;
