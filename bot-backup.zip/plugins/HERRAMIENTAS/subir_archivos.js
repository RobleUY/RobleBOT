const axios = require('axios');
const FormData = require('form-data');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ==========================================
// CONFIG
// ==========================================

const IMGBB_KEYS = [
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c'
];

// ==========================================
// HELPERS
// ==========================================

/** Sube un buffer de imagen a ImgBB probando varias keys de respaldo */
async function subirImgBB(buffer) {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename: 'upload.jpg' });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: { ...form.getHeaders() }, timeout: 20000 }
            );
            const data = res.data?.data;
            if (data?.url) {
                return {
                    url: data.url,                       // link directo (imagen)
                    displayUrl: data.display_url || data.url,
                    deleteUrl: data.delete_url || null,
                    size: data.size || null,
                    width: data.width || null,
                    height: data.height || null,
                    extension: data.image?.extension || null
                };
            }
        } catch (e) {
            console.warn(`[SUBIR] ImgBB key ...${key.slice(-6)} falló:`, e.message);
        }
    }
    throw new Error('Todas las keys de ImgBB fallaron al subir la imagen.');
}

/** Verifica que una imagen (por URL) sea segura usando la API de Delirius (NSFW + Porn) */
async function verificarImagenSegura(imageUrl) {
    const nsfwUrl = `https://api.delirius.online/tools/checknsfw?image=${encodeURIComponent(imageUrl)}`;
    const pornUrl = `https://api.delirius.online/tools/checkporn?image=${encodeURIComponent(imageUrl)}`;

    const [nsfwRes, pornRes] = await Promise.all([
        axios.get(nsfwUrl, { timeout: 20000 }).catch(err => ({
            data: { status: false, data: {}, error: err.message }
        })),
        axios.get(pornUrl, { timeout: 20000 }).catch(err => ({
            data: { status: false, data: {}, error: err.message }
        }))
    ]);

    const nsfwData = nsfwRes?.data?.data || {};
    const pornData = pornRes?.data?.data || {};

    const isTruthy = (value) => {
        if (typeof value === 'boolean') return value;
        if (typeof value === 'number') return value !== 0;
        if (typeof value === 'string') {
            const v = value.trim().toLowerCase();
            if (v === 'true' || v === 'yes' || v === '1' || v === 'y') return true;
            if (v === 'false' || v === 'no' || v === '0' || v === 'n') return false;
        }
        return null;
    };

    const nsfwStatus = nsfwRes?.data?.status === true;
    const pornStatus = pornRes?.data?.status === true;
    const nsfwFlag = !!(
        nsfwStatus && (
            isTruthy(nsfwData.NSFW) === true ||
            isTruthy(nsfwData.safe) === false ||
            String(nsfwData.NSFW ?? '').trim().toLowerCase() === 'true' ||
            String(nsfwData.safe ?? '').trim().toLowerCase() === 'false'
        )
    );
    const pornRaw = String(pornData.isPorn ?? '').trim();
    const pornFlag = pornRaw.toLowerCase() === 'porn';

    if (!nsfwStatus && !pornStatus) {
        console.warn('[SUBIR] Delirius no respondió bien, se omite la validación por seguridad y se acepta la imagen.');
        return { nsfwData, pornData, skipped: true };
    }

    if (nsfwFlag || pornFlag) {
        const reasons = [];
        if (nsfwFlag) reasons.push('NSFW: detectado');
        if (pornFlag) reasons.push(`Porn: ${pornRaw || 'detectado'}`);
        throw new Error(`La imagen no cumple con los requisitos de seguridad: ${reasons.join(' | ')}`);
    }

    return { nsfwData, pornData, skipped: false };
}

/** Convierte un stream de Baileys a Buffer */
async function streamToBuffer(stream) {
    let buf = Buffer.alloc(0);
    for await (const chunk of stream) {
        buf = Buffer.concat([buf, chunk]);
    }
    return buf;
}

/**
 * Resuelve la imagen a subir desde:
 *  1. URL directa en el texto
 *  2. Imagen adjunta en el mensaje actual (enviada junto con .subir)
 *  3. Imagen citada (respondiendo a una foto con .subir)
 */
async function resolverImagenDesdeMensaje(message, rawUrl) {
    // ── Caso 1: URL en el texto ──────────────────────────────────────────────
    const inputUrl = (rawUrl || '').trim();
    if (inputUrl) {
        if (!/^https?:\/\//i.test(inputUrl)) {
            throw new Error('La URL de la imagen debe empezar con http:// o https://');
        }
        try {
            const { data } = await axios.get(inputUrl, { responseType: 'arraybuffer', timeout: 20000 });
            return { buffer: Buffer.from(data), sourceUrl: inputUrl };
        } catch (error) {
            throw new Error(`No se pudo descargar la imagen desde la URL: ${error.message}`);
        }
    }

    // ── Caso 2 y 3: imagen en el mensaje actual o citado ─────────────────────
    const baileyMsg = message?._baileyMessage || global.lastBaileyMessage || message;
    if (!baileyMsg) {
        throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
    }

    function unwrap(msg) {
        if (!msg) return null;
        return (
            msg.viewOnceMessage?.message ||
            msg.viewOnceMessageV2?.message ||
            msg.viewOnceMessageV2Extension?.message ||
            msg.ephemeralMessage?.message ||
            msg.documentWithCaptionMessage?.message ||
            msg.buttonReplyMessage?.message ||
            msg.buttonsResponseMessage?.message ||
            msg.templateButtonReplyMessage?.message ||
            msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
            msg
        );
    }

    async function downloadImgMsg(imgMsgObj) {
        try {
            const stream = await downloadContentFromMessage(imgMsgObj, 'image');
            return await streamToBuffer(stream);
        } catch (e) {
            console.error('[SUBIR] Error descargando imagen:', e.message);
            return null;
        }
    }

    const rawMsg = baileyMsg.message || baileyMsg;
    const inner = unwrap(rawMsg);

    if (inner?.imageMessage) {
        console.log('[SUBIR] Imagen detectada en el mensaje actual');
        const buf = await downloadImgMsg(inner.imageMessage);
        if (buf) return { buffer: buf, sourceUrl: null };
    }

    const contextInfo =
        inner?.extendedTextMessage?.contextInfo ||
        inner?.imageMessage?.contextInfo ||
        inner?.videoMessage?.contextInfo ||
        inner?.audioMessage?.contextInfo ||
        inner?.stickerMessage?.contextInfo ||
        rawMsg?.extendedTextMessage?.contextInfo ||
        rawMsg?.imageMessage?.contextInfo ||
        rawMsg?.videoMessage?.contextInfo ||
        rawMsg?.stickerMessage?.contextInfo ||
        null;

    const quoted = contextInfo?.quotedMessage;
    if (quoted) {
        const quotedInner = unwrap(quoted) || quoted;
        if (quotedInner?.imageMessage) {
            console.log('[SUBIR] Imagen detectada en el mensaje citado');
            const buf = await downloadImgMsg(quotedInner.imageMessage);
            if (buf) return { buffer: buf, sourceUrl: null };
        }
    }

    throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
}

/** Formatea bytes en KB/MB legibles */
function formatBytes(bytes) {
    if (!bytes) return 'Desconocido';
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { text }) => {
    try {
        const rawUrl = (text || '').trim();

        try {
            const { buffer, sourceUrl } = await resolverImagenDesdeMensaje(message, rawUrl);
            if (!buffer || buffer.length < 1000) {
                throw new Error('La imagen es demasiado pequeña o no se pudo leer correctamente.');
            }

            await message.reply('📷 Obteniendo la imagen...');
            const uploaded = await subirImgBB(buffer);

            await message.reply('🔎 Verificando que la imagen sea segura...');
            await verificarImagenSegura(uploaded.url);

            let infoMsg =
                `✅ *¡Imagen subida con éxito!*\n\n` +
                `🔗 *Link directo:* ${uploaded.url}\n` +
                `🖼️ *Vista previa:* ${uploaded.displayUrl}\n`;

            if (uploaded.extension) infoMsg += `📄 *Formato:* ${uploaded.extension.toUpperCase()}\n`;
            if (uploaded.width && uploaded.height) infoMsg += `📐 *Dimensiones:* ${uploaded.width}x${uploaded.height}px\n`;
            if (uploaded.size) infoMsg += `💾 *Tamaño:* ${formatBytes(uploaded.size)}\n`;
            if (sourceUrl) infoMsg += `\n_Imagen original obtenida desde:_ ${sourceUrl}`;

            return await message.reply(infoMsg.trim());
        } catch (error) {
            console.error('[SUBIR ERROR]', error.message);
            return await message.reply(
                `❌ *Error al subir la imagen:*\n\n${error.message}`
            );
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando subir:', error, '\x1b[0m');
        return await message.reply('❌ *Error inesperado al procesar la imagen.*');
    }
};

handler.help = [
    'subir [url]',
    'upload [url]'
];
handler.tags = ['herramientas'];
handler.command = /^(subir|upload)$/i;

module.exports = handler;