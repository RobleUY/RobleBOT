/**
 * Comando: subir / upload
 * Descripción: Sube cualquier archivo (imagen, video, audio, gif, sticker, documento)
 *              a uguu.se y devuelve un enlace de descarga directo.
 * Uso: Envía el archivo con .subir como caption, o respondé a un archivo con .subir
 * Límite: 100MB | Los archivos duran 48 horas
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data');

const UGUU_API = 'https://uguu.se/upload';

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

/**
 * Detecta si el mensaje ACTUAL tiene media (imagen, video, gif, audio, sticker, documento).
 * Igual que detectCurrentMedia() de sticker.js pero con más tipos.
 */
async function detectCurrentMedia() {
    try {
        console.log('🔍 [subir] Buscando media en mensaje actual...');
        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) return null;

        const msg = baileyMsg.message;
        const inner =
            msg?.viewOnceMessage?.message ||
            msg?.viewOnceMessageV2?.message ||
            msg?.ephemeralMessage?.message ||
            msg?.documentWithCaptionMessage?.message ||
            msg;

        // Imagen
        if (inner?.imageMessage) {
            console.log('🖼️ [subir] Imagen detectada en mensaje actual');
            const stream = await downloadContentFromMessage(inner.imageMessage, 'image');
            const buffer = await streamToBuffer(stream);
            const mime = inner.imageMessage.mimetype || 'image/jpeg';
            const ext = mime.split('/')[1]?.split(';')[0] || 'jpg';
            return { data: buffer, mimeType: mime, fileName: `imagen_${Date.now()}.${ext}` };
        }

        // Video / GIF
        if (inner?.videoMessage) {
            const isGif = !!inner.videoMessage.gifPlayback;
            console.log(`${isGif ? '🎭 GIF' : '🎥 Video'} detectado en mensaje actual`);
            const stream = await downloadContentFromMessage(inner.videoMessage, 'video');
            const buffer = await streamToBuffer(stream);
            const mime = inner.videoMessage.mimetype || 'video/mp4';
            return { data: buffer, mimeType: mime, fileName: `${isGif ? 'gif' : 'video'}_${Date.now()}.mp4` };
        }

        // Audio / Nota de voz
        if (inner?.audioMessage) {
            const isPtt = !!inner.audioMessage.ptt;
            console.log(`🎵 ${isPtt ? 'Nota de voz' : 'Audio'} detectado en mensaje actual`);
            const stream = await downloadContentFromMessage(inner.audioMessage, 'audio');
            const buffer = await streamToBuffer(stream);
            const mime = inner.audioMessage.mimetype || 'audio/ogg; codecs=opus';
            return { data: buffer, mimeType: 'audio/ogg', fileName: `${isPtt ? 'voz' : 'audio'}_${Date.now()}.ogg` };
        }

        // Sticker
        if (inner?.stickerMessage) {
            console.log('🎟️ [subir] Sticker detectado en mensaje actual');
            const stream = await downloadContentFromMessage(inner.stickerMessage, 'sticker');
            const buffer = await streamToBuffer(stream);
            return { data: buffer, mimeType: 'image/webp', fileName: `sticker_${Date.now()}.webp` };
        }

        // Documento
        if (inner?.documentMessage) {
            console.log('📄 [subir] Documento detectado en mensaje actual');
            const stream = await downloadContentFromMessage(inner.documentMessage, 'document');
            const buffer = await streamToBuffer(stream);
            const mime = inner.documentMessage.mimetype || 'application/octet-stream';
            const name = inner.documentMessage.fileName || `documento_${Date.now()}`;
            return { data: buffer, mimeType: mime, fileName: name };
        }

        console.log('❌ [subir] No hay media en el mensaje actual');
        return null;
    } catch (error) {
        console.error('❌ [subir] Error en detectCurrentMedia:', error);
        return null;
    }
}

/**
 * Detecta si hay media en un mensaje CITADO (respondiendo a otro mensaje).
 * Igual que detectQuotedMedia() de sticker.js pero con más tipos.
 */
async function detectQuotedMedia() {
    try {
        console.log('🔍 [subir] Buscando media en mensaje citado...');
        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) {
            console.log('❌ [subir] No hay global.lastBaileyMessage');
            return null;
        }

        // Copiar exactamente igual a sticker.js: buscar contextInfo en cada tipo
        let contextInfo = null;
        if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
            contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
        } else if (baileyMsg.message?.imageMessage?.contextInfo) {
            contextInfo = baileyMsg.message.imageMessage.contextInfo;
        } else if (baileyMsg.message?.videoMessage?.contextInfo) {
            contextInfo = baileyMsg.message.videoMessage.contextInfo;
        } else if (baileyMsg.message?.audioMessage?.contextInfo) {
            contextInfo = baileyMsg.message.audioMessage.contextInfo;
        } else if (baileyMsg.message?.documentMessage?.contextInfo) {
            contextInfo = baileyMsg.message.documentMessage.contextInfo;
        } else if (baileyMsg.message?.stickerMessage?.contextInfo) {
            contextInfo = baileyMsg.message.stickerMessage.contextInfo;
        }

        if (!contextInfo?.quotedMessage) {
            console.log('❌ [subir] No hay mensaje citado');
            return null;
        }

        const q = contextInfo.quotedMessage;

        // Sticker
        if (q.stickerMessage) {
            console.log('🎟️ [subir] Sticker citado detectado');
            const stream = await downloadContentFromMessage(q.stickerMessage, 'sticker');
            const buffer = await streamToBuffer(stream);
            return { data: buffer, mimeType: 'image/webp', fileName: `sticker_${Date.now()}.webp` };
        }

        // Imagen
        if (q.imageMessage) {
            console.log('🖼️ [subir] Imagen citada detectada');
            const stream = await downloadContentFromMessage(q.imageMessage, 'image');
            const buffer = await streamToBuffer(stream);
            const mime = q.imageMessage.mimetype || 'image/jpeg';
            const ext = mime.split('/')[1]?.split(';')[0] || 'jpg';
            return { data: buffer, mimeType: mime, fileName: `imagen_${Date.now()}.${ext}` };
        }

        // Video / GIF
        if (q.videoMessage) {
            const isGif = !!q.videoMessage.gifPlayback;
            console.log(`${isGif ? '🎭 GIF' : '🎥 Video'} citado detectado`);
            const stream = await downloadContentFromMessage(q.videoMessage, 'video');
            const buffer = await streamToBuffer(stream);
            const mime = q.videoMessage.mimetype || 'video/mp4';
            return { data: buffer, mimeType: mime, fileName: `${isGif ? 'gif' : 'video'}_${Date.now()}.mp4` };
        }

        // Audio / Nota de voz
        if (q.audioMessage) {
            const isPtt = !!q.audioMessage.ptt;
            console.log(`🎵 ${isPtt ? 'Nota de voz' : 'Audio'} citado detectado`);
            const stream = await downloadContentFromMessage(q.audioMessage, 'audio');
            const buffer = await streamToBuffer(stream);
            return { data: buffer, mimeType: 'audio/ogg', fileName: `${isPtt ? 'voz' : 'audio'}_${Date.now()}.ogg` };
        }

        // Documento
        if (q.documentMessage) {
            console.log('📄 [subir] Documento citado detectado');
            const stream = await downloadContentFromMessage(q.documentMessage, 'document');
            const buffer = await streamToBuffer(stream);
            const mime = q.documentMessage.mimetype || 'application/octet-stream';
            const name = q.documentMessage.fileName || `documento_${Date.now()}`;
            return { data: buffer, mimeType: mime, fileName: name };
        }

        console.log('❌ [subir] Tipo de mensaje citado no soportado');
        return null;
    } catch (error) {
        console.error('❌ [subir] Error en detectQuotedMedia:', error);
        return null;
    }
}

/**
 * Sube buffer a uguu.se y retorna URL directa
 */
async function subirAUguu(buffer, fileName, mimeType) {
    const form = new FormData();
    form.append('files[]', buffer, {
        filename: fileName,
        contentType: mimeType,
    });

    const response = await axios.post(UGUU_API, form, {
        headers: { ...form.getHeaders() },
        timeout: 60_000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
    });

    const data = response.data;
    if (data?.success && data?.files?.[0]?.url) {
        return data.files[0].url;
    }

    throw new Error('Respuesta inesperada de uguu.se: ' + JSON.stringify(data));
}

// --- Handler Principal ---
let handler = async (message, { conn }) => {
    try {
        // Igual que sticker.js: usar conn || message._sock || global.conn
        const sock = conn || message._sock || global.conn;
        if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

        // 1. Buscar media en el mensaje actual
        let media = await detectCurrentMedia();

        // 2. Si no hay, buscar en el mensaje citado
        if (!media) {
            console.log('📁 [subir] Buscando media citada...');
            media = await detectQuotedMedia();
        }

        if (!media) {
            return await message.reply(
                '❌ Adjuntá o respondé a una *imagen, video, audio, sticker o documento* con *.subir* para obtener el enlace de descarga.'
            );
        }

        // Verificar límite 100MB
        const sizeMB = (media.data.length / 1048576).toFixed(2);
        if (parseFloat(sizeMB) > 100) {
            return await message.reply(`❌ El archivo pesa *${sizeMB}MB* y supera el límite de 100MB de uguu.se.`);
        }

        await message.reply(`⏳ Subiendo *${media.fileName}* (${sizeMB} MB) a uguu.se...`);

        let url;
        try {
            url = await subirAUguu(media.data, media.fileName, media.mimeType);
        } catch (err) {
            console.error('❌ [subir] Error al subir a uguu.se:', err.message);
            return await message.reply('❌ Error al subir el archivo. Intentá de nuevo.');
        }

        await message.reply(`🔗 ${url}\n📦 ${sizeMB} MB`);

    } catch (error) {
        console.error('❌ [subir] Error general:', error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud.');
    }
};

handler.help = ['subir', 'upload'];
handler.tags = ['util', 'archivos', 'upload'];
handler.command = /^(subir|upload)$/i;

module.exports = handler;