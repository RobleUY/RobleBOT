const axios = require('axios');
const FormData = require('form-data');
const crypto = require('crypto');
require('dotenv').config();
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ==========================================
// CONFIG & KEYS
// ==========================================

const IMGBB_KEYS = [
    process.env.IMGBB_API_KEY,
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c',
    'Z4ce3fe016a9c978bf9c8cba581c22bd3'
].filter(Boolean);

// ==========================================
// UPLOAD PROVIDERS
// ==========================================

async function uploadCloudinary(buffer, filename = 'upload.jpg') {
    const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;

    if (!cloudName || !apiKey || !apiSecret) {
        throw new Error('Cloudinary credentials not configured in .env');
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const stringToSign = `timestamp=${timestamp}${apiSecret}`;
    const signature = crypto.createHash('sha1').update(stringToSign).digest('hex');

    const form = new FormData();
    form.append('file', buffer, { filename });
    form.append('api_key', apiKey);
    form.append('timestamp', timestamp);
    form.append('signature', signature);

    const res = await axios.post(
        `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
        form,
        { headers: form.getHeaders(), timeout: 15000 }
    );

    const data = res.data;
    if (data?.secure_url || data?.url) {
        const url = data.secure_url || data.url;
        return {
            url,
            displayUrl: url,
            service: 'Cloudinary',
            size: data.bytes || buffer.length,
            width: data.width || null,
            height: data.height || null,
            extension: data.format || null
        };
    }
    throw new Error('Cloudinary failed');
}

async function uploadImgBB(buffer, filename = 'upload.jpg') {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: form.getHeaders(), timeout: 15000 }
            );
            const data = res.data?.data;
            if (data?.url) {
                return {
                    url: data.url,
                    displayUrl: data.display_url || data.url,
                    service: 'ImgBB',
                    size: data.size || buffer.length,
                    width: data.width || null,
                    height: data.height || null,
                    extension: data.image?.extension || null
                };
            }
        } catch (e) {
            // Sigue con la siguiente key
        }
    }
    throw new Error('All ImgBB keys failed');
}

async function uploadTelegraph(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://telegra.ph/upload', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (res.data?.[0]?.src) {
        const url = 'https://telegra.ph' + res.data[0].src;
        return { url, displayUrl: url, service: 'Telegraph', size: buffer.length };
    }
    throw new Error('Telegraph failed');
}

async function uploadCatbox(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (typeof res.data === 'string' && res.data.startsWith('http')) {
        const url = res.data.trim();
        return { url, displayUrl: url, service: 'Catbox', size: buffer.length };
    }
    throw new Error('Catbox failed');
}

async function uploadQuax(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (res.data?.success && res.data?.files?.[0]?.url) {
        const url = res.data.files[0].url;
        return { url, displayUrl: url, service: 'Qu.ax', size: res.data.files[0].size || buffer.length };
    }
    throw new Error('Qu.ax failed');
}

/** Carrera de velocidad: Sube a todos y devuelve el más rápido */
async function uploadImageFastest(buffer, filename = 'upload.jpg') {
    const providers = [];

    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
        providers.push(uploadCloudinary(buffer, filename).catch(e => { throw e; }));
    }

    providers.push(uploadImgBB(buffer, filename).catch(e => { throw e; }));
    providers.push(uploadTelegraph(buffer, filename).catch(e => { throw e; }));
    providers.push(uploadCatbox(buffer, filename).catch(e => { throw e; }));
    providers.push(uploadQuax(buffer, filename).catch(e => { throw e; }));

    try {
        // Devuelve el primero que tenga éxito
        return await Promise.any(providers);
    } catch (error) {
        throw new Error('Todos los servicios de subida fallaron al procesar la imagen.');
    }
}

// ==========================================
// HELPERS & SEGURIDAD
// ==========================================

/** Verifica que una imagen (por URL) sea segura usando la API de Delirius (NSFW + Porn) */
async function verificarImagenSegura(imageUrl) {
    // 1. Intentar API principal de Roble Games
    const primaryUrl = `http://roblegames.servegame.net:24667/nsfw?url=${encodeURIComponent(imageUrl)}`;
    try {
        const { data } = await axios.get(primaryUrl, { timeout: 15000 });
        if (data && data.ok) {
            const isUnsafe = data.safe === false || data.porn === true || data.gore === true || data.violence === true || data.self_harm === true || (data.scores && Number(data.scores.nsfw) > 0.5);
            if (isUnsafe) {
                const reasons = [];
                if (data.porn) reasons.push('Porno / Contenido explícito');
                if (data.gore) reasons.push('Gore');
                if (data.violence) reasons.push('Violencia');
                if (data.self_harm) reasons.push('Autolesión');
                if (!reasons.length && data.scores?.nsfw > 0.5) reasons.push(`NSFW (${(data.scores.nsfw * 100).toFixed(1)}%)`);
                
                throw new Error(`La imagen no cumple con los requisitos de seguridad: ${reasons.join(' | ')}`);
            }
            return { safe: true, data };
        }
    } catch (err) {
        if (err.message && err.message.startsWith('La imagen no cumple')) {
            throw err;
        }
        console.warn('[SUBIR ARCHIVOS NSFW] API principal falló o dio timeout, intentando backup (Delirius)...', err.message);
    }

    // 2. Backup: Delirius API
    try {
        const nsfwUrl = `https://api.delirius.online/tools/checknsfw?image=${encodeURIComponent(imageUrl)}`;
        const pornUrl = `https://api.delirius.online/tools/checkporn?image=${encodeURIComponent(imageUrl)}`;

        const [nsfwRes, pornRes] = await Promise.all([
            axios.get(nsfwUrl, { timeout: 15000 }).catch(() => ({ data: {} })),
            axios.get(pornUrl, { timeout: 15000 }).catch(() => ({ data: {} }))
        ]);

        const nsfwData = nsfwRes?.data?.data || {};
        const pornData = pornRes?.data?.data || {};

        const nsfwFlag = nsfwRes?.data?.status === true && (nsfwData.NSFW === true || nsfwData.safe === false);
        const pornFlag = pornRes?.data?.status === true && String(pornData.isPorn || '').toLowerCase() === 'porn';

        if (nsfwFlag || pornFlag) {
            throw new Error('La imagen no cumple con los requisitos de seguridad: Contenido NSFW / Porno detectado');
        }
    } catch (err) {
        if (err.message && err.message.startsWith('La imagen no cumple')) {
            throw err;
        }
        console.warn('[SUBIR ARCHIVOS NSFW] Backup Delirius también falló, continuando con precaución:', err.message);
    }

    return { safe: true };
}

/** Convierte un stream de Baileys a Buffer */
async function streamToBuffer(stream) {
    let buf = Buffer.alloc(0);
    for await (const chunk of stream) {
        buf = Buffer.concat([buf, chunk]);
    }
    return buf;
}

/**
 * Resuelve la imagen a subir desde:
 *  1. URL directa en el texto
 *  2. Imagen adjunta en el mensaje actual (enviada junto con .subir)
 *  3. Imagen citada (respondiendo a una foto con .subir)
 */
async function resolverImagenDesdeMensaje(message, rawUrl) {
    const inputUrl = (rawUrl || '').trim();
    if (inputUrl) {
        if (!/^https?:\/\//i.test(inputUrl)) {
            throw new Error('La URL de la imagen debe empezar con http:// o https://');
        }
        try {
            const { data } = await axios.get(inputUrl, { responseType: 'arraybuffer', timeout: 20000 });
            return { buffer: Buffer.from(data), sourceUrl: inputUrl };
        } catch (error) {
            throw new Error(`No se pudo descargar la imagen desde la URL: ${error.message}`);
        }
    }

    const baileyMsg = message?._baileyMessage || global.lastBaileyMessage || message;
    if (!baileyMsg) {
        throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
    }

    function unwrap(msg) {
        if (!msg) return null;
        return (
            msg.viewOnceMessage?.message ||
            msg.viewOnceMessageV2?.message ||
            msg.viewOnceMessageV2Extension?.message ||
            msg.ephemeralMessage?.message ||
            msg.documentWithCaptionMessage?.message ||
            msg.buttonReplyMessage?.message ||
            msg.buttonsResponseMessage?.message ||
            msg.templateButtonReplyMessage?.message ||
            msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
            msg
        );
    }

    async function downloadImgMsg(imgMsgObj) {
        try {
            const stream = await downloadContentFromMessage(imgMsgObj, 'image');
            return await streamToBuffer(stream);
        } catch (e) {
            console.error('[SUBIR] Error descargando imagen:', e.message);
            return null;
        }
    }

    const rawMsg = baileyMsg.message || baileyMsg;
    const inner = unwrap(rawMsg);

    if (inner?.imageMessage) {
        const buf = await downloadImgMsg(inner.imageMessage);
        if (buf) return { buffer: buf, sourceUrl: null };
    }

    const contextInfo =
        inner?.extendedTextMessage?.contextInfo ||
        inner?.imageMessage?.contextInfo ||
        inner?.videoMessage?.contextInfo ||
        inner?.audioMessage?.contextInfo ||
        inner?.stickerMessage?.contextInfo ||
        rawMsg?.extendedTextMessage?.contextInfo ||
        rawMsg?.imageMessage?.contextInfo ||
        rawMsg?.videoMessage?.contextInfo ||
        rawMsg?.stickerMessage?.contextInfo ||
        null;

    const quoted = contextInfo?.quotedMessage;
    if (quoted) {
        const quotedInner = unwrap(quoted) || quoted;
        if (quotedInner?.imageMessage) {
            const buf = await downloadImgMsg(quotedInner.imageMessage);
            if (buf) return { buffer: buf, sourceUrl: null };
        }
    }

    throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
}

function formatBytes(bytes) {
    if (!bytes) return 'Desconocido';
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { text }) => {
    try {
        const rawUrl = (text || '').trim();

        try {
            const { buffer, sourceUrl } = await resolverImagenDesdeMensaje(message, rawUrl);
            if (!buffer || buffer.length < 1000) {
                throw new Error('La imagen es demasiado pequeña o no se pudo leer correctamente.');
            }

            await message.reply('📷 Obteniendo y subiendo la imagen a la máxima velocidad...');
            const uploaded = await uploadImageFastest(buffer);

            await message.reply('🔎 Verificando que la imagen sea segura...');
            await verificarImagenSegura(uploaded.url);

            let infoMsg =
                `✅ *¡Imagen subida con éxito!*\n\n` +
                `🚀 *Servidor:* ${uploaded.service}\n` +
                `🔗 *Link directo:* ${uploaded.url}\n`;

            if (uploaded.extension) infoMsg += `📄 *Formato:* ${uploaded.extension.toUpperCase()}\n`;
            if (uploaded.width && uploaded.height) infoMsg += `📐 *Dimensiones:* ${uploaded.width}x${uploaded.height}px\n`;
            if (uploaded.size) infoMsg += `💾 *Tamaño:* ${formatBytes(uploaded.size)}\n`;
            if (sourceUrl) infoMsg += `\n_Imagen original obtenida desde:_ ${sourceUrl}`;

            return await message.reply(infoMsg.trim());
        } catch (error) {
            console.error('[SUBIR ERROR]', error.message);
            return await message.reply(`❌ *Error al procesar la imagen:*\n\n${error.message}`);
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando subir:', error, '\x1b[0m');
        return await message.reply('❌ *Error inesperado al procesar la petición.*');
    }
};

handler.help = ['subir [url]', 'upload [url]'];
handler.tags = ['herramientas'];
handler.command = /^(subir|upload)$/i;

module.exports = handler;