const axios = require('axios')
const { Sticker } = require('wa-sticker-formatter')

let handler = async (message, { conn, text, usedPrefix, command }) => {
    try {
        if (!text?.trim()) return message.reply(`⚠️ Uso: ${usedPrefix + command} 😂`)

        const res = await axios.get('https://www.robleuy.site/robleapi/imagen/emojigif', {
            params: { emoji: text.trim() },
            responseType: 'arraybuffer',
            timeout: 15000
        })

        const buffer = Buffer.from(res.data)

        const sticker = new Sticker(buffer, {
            pack: '🤖 RobleBOT',
            author: 'RobleBOT\n📷 Instagram: @robleuy',
            type: 'full',
            quality: 100
        })

        const stickerBuffer = await sticker.toBuffer()
        await conn.sendMessage(message.from, { sticker: stickerBuffer }, { quoted: message._baileyMessage })

    } catch (err) {
        console.error('[EMOJIGIF]', err.message)
        await message.reply('❌ No se pudo obtener el GIF.')
    }
}

handler.help = ['emojigif <emoji>']
handler.tags = ['herramientas']
handler.command = /^(emojigif|emojitogif)$/i

module.exports = handler
