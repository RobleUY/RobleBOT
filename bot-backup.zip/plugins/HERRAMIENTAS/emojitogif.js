// emojitogif.js
const axios = require('axios');
const { Sticker, StickerTypes } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];

    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

async function fetchEmojiToGif(emoji) {
  try {
    const apiUrl = `https://www.sankavollerei.web.id/tools/emojitogif?apikey=planaai&emoji=${encodeURIComponent(emoji)}`;

    console.log('🔗 Consultando API EmojiToGif:', apiUrl);

    // La API devuelve el gif directamente
    const response = await axios.get(apiUrl, {
      timeout: 15000,
      responseType: 'arraybuffer'
    });

    if (response.status === 200 && response.data) {
      const buffer = Buffer.from(response.data);
      console.log(`✅ Gif obtenido: ${buffer.length} bytes`);

      // Verificar que sea un GIF válido (firma "GIF87a" o "GIF89a")
      if (buffer.length > 0 && buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) {
        return buffer;
      } else {
        console.error('❌ El buffer no es un GIF válido');
        return null;
      }
    }

    return null;
  } catch (error) {
    console.error('❌ Error al obtener EmojiToGif:', error.message);
    if (error.response) {
      console.error('📄 Estado de respuesta:', error.response.status);
    }
    return null;
  }
}

function extractEmojis(text) {
  // Regex para detectar emojis (incluyendo emojis compuestos)
  const emojiRegex = /(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/gu;
  const emojis = text.match(emojiRegex);
  return emojis || [];
}

async function sendEmojiGifSticker(sock, jid, gifBuffer, emoji, quotedMsg) {
  try {
    console.log('📤 Convirtiendo EmojiToGif a sticker animado...');

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const sticker = new Sticker(gifBuffer, {
      pack: 'RobleBOT',
      author: authorText,
      type: StickerTypes.FULL, // animado, ocupa el cuadro completo
      quality: 70,
      animated: true
    });

    const stickerBuffer = await sticker.toBuffer();

    await sock.sendMessage(jid, { sticker: stickerBuffer }, quotedMsg ? { quoted: quotedMsg } : {});
    console.log('✅ Sticker EmojiToGif enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker EmojiToGif:', error);
    return false;
  }
}

let handler = async (message, { text, args, conn }) => {
  try {
    console.log('🎨 Iniciando comando emojitogif...');

    const sock = conn || message._sock || global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // Verificar que se proporcionó texto
    if (!text || text.trim().length === 0) {
      return await message.reply(
        '❌ *Debes proporcionar 1 emoji para convertir a gif.*\n\n' +
        '📝 *Uso:*\n' +
        '• `/emojitogif 💀`\n' +
        '• `/emojitogif 🔥`\n' +
        '• `/emojitogif 😂`\n\n' +
        '💡 *Tip:* Algunos emojis pueden no funcionar.'
      );
    }

    // Extraer emojis del texto
    const emojis = extractEmojis(text);

    if (emojis.length < 1) {
      return await message.reply(
        '❌ *Necesito al menos 1 emoji para convertir.*\n\n' +
        '📝 *Ejemplo correcto:*\n' +
        '• `.emojitogif 💀`\n\n' +
        `🔍 *Encontré:* ${emojis.length} emoji(s)`
      );
    }

    const emoji = emojis[0];

    console.log(`🎭 Convirtiendo a gif: ${emoji}`);

    // Enviar mensaje de espera
    await message.reply(`⏳ Creando sticker animado de ${emoji}...`);

    // Obtener el gif del emoji
    const gifBuffer = await fetchEmojiToGif(emoji);

    if (!gifBuffer || gifBuffer.length === 0) {
      return await message.reply(
        `❌ *No se pudo crear el gif de ${emoji}*\n\n` +
        '💡 *Posibles razones:*\n' +
        '• El emoji no está en la base de datos\n' +
        '• Error de conexión con la API\n' +
        '• Emoji no disponible\n\n' +
        '🔄 *Intenta con otros emojis populares como:*\n' +
        '😍, 😎, 🔥, 💀, 😂, 🥺, ❤️, 🎉'
      );
    }

    console.log(`📊 Tamaño del buffer: ${gifBuffer.length} bytes`);

    // Enviar como sticker animado
    const success = await sendEmojiGifSticker(sock, message.from, gifBuffer, emoji, message._baileyMessage);

    if (!success) {
      return await message.reply(
        '❌ *Error al crear el sticker EmojiToGif.*\n\n' +
        '🔄 Por favor intenta nuevamente.'
      );
    }

  } catch (error) {
    console.error('❌ Error general en handler emojitogif:', error);
    await message.reply(
      '❌ *Ocurrió un error al crear el EmojiToGif.*\n\n' +
      `📋 *Error:* ${error.message}\n\n` +
      '🔄 Por favor intenta nuevamente con otro emoji.'
    );
  }
};

handler.help = ['emojitogif'];
handler.tags = ['stickers', 'fun'];
handler.command = /^(emojitogif)$/i;

module.exports = handler;