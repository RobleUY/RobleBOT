/**
 * Comando: .clima
 * Descripción: Muestra el clima actual de una ciudad (sin usar API key)
 * Uso: .clima <ciudad>
 */

let handler = async (message, { text }) => {
  try {
    if (!text || typeof text !== 'string') {
      return await message.reply(
        '🌍 *Debes escribir una ciudad.*\n\nEjemplo: `.clima montevideo` o mejor aún `.clima montevideo uruguay` para mayor precisión.'
      );
    }

    await message.reply('☁️ Consultando el clima, espera un momento...');

    const city = encodeURIComponent(text.trim());
    const url = `https://wttr.in/${city}?format=j1&lang=es`; // Idioma español

    const fetchFn = global.fetch || (await import('node-fetch')).default;
    const res = await fetchFn(url);
    if (!res.ok) throw new Error(`No se pudo obtener el clima para ${text}`);
    const data = await res.json();

    const area = data?.nearest_area?.[0]?.areaName?.[0]?.value || text;
    const country = data?.nearest_area?.[0]?.country?.[0]?.value || '';
    const current = data?.current_condition?.[0];
    if (!current) throw new Error('Datos climáticos no disponibles.');

    const temp = current.temp_C;
    const feels = current.FeelsLikeC;
    const humidity = current.humidity;
    const wind = current.windspeedKmph;

    // Emoji según temperatura
    let emoji = '🌤️';
    if (parseInt(temp) >= 30) emoji = '🔥';
    else if (parseInt(temp) <= 10) emoji = '❄️';

    const msg =
      `${emoji} *Clima en ${area}${country ? ', ' + country : ''}*\n\n` +
      `🌡️ *Temperatura:* ${temp}°C (Sensación: ${feels}°C)\n` +
      `💧 *Humedad:* ${humidity}%\n` +
      `💨 *Viento:* ${wind} km/h\n\n` +
      '⚠️ Se recomienda escribir ciudad y país para mayor precisión.\n' +
      'ℹ️ Los datos pueden no ser 100% exactos.';

    await message.reply(msg);

  } catch (e) {
    console.error('Error en comando clima:', e);
    await message.reply(
      '❌ No se pudo obtener el clima. Verifica el nombre de la ciudad e inténtalo nuevamente.\n' +
      '⚠️ Se recomienda escribir ciudad y país para mayor precisión.'
    );
  }
};

handler.help = ['clima <ciudad>'];
handler.tags = ['herramientas', 'utilidad'];
handler.command = /^(clima)$/i;

module.exports = handler;
