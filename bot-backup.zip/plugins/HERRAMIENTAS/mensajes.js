const { getDb } = require('../../chatLogger')

function cleanNum(str) {
    return str.split('@')[0].split(':')[0].replace(/\D/g, '')
}

function getUserInfo(message, args) {
    const mentioned = message.mentions?.[0]
    if (mentioned) {
        const numero = mentioned.split('@')[0].replace(/\D/g, '')
        return { numero, jid: mentioned, esPropioUsuario: false }
    }
    const senderJid = message.sender
    const numero = senderJid.split('@')[0].replace(/\D/g, '')
    return { numero, jid: senderJid, esPropioUsuario: true }
}

function contarMensajes(numero, groupId) {
    try {
        const db = getDb()
        
        let query, params
        if (groupId) {
            query = `
                SELECT COUNT(*) as total
                FROM messages 
                WHERE user_number = ? AND group_jid = ?
            `
            params = [numero, groupId]
        } else {
            query = `
                SELECT COUNT(*) as total
                FROM messages 
                WHERE user_number = ?
            `
            params = [numero]
        }
        
        const result = db.prepare(query).get(...params)
        
        if (!result || result.total === 0) {
            return null
        }
        
        return { total: result.total || 0 }
    } catch (e) {
        console.error('[contarMensajes] Error:', e.message)
        return null
    }
}

const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟']

let handler = async (message, { args, conn }) => {
    try {
        const body = message.body || ''
        const usedPrefix = body.charAt(0) || '.'
        const cmdArgs = body.trim().slice(1).split(/\s+/)
        const cmd = cmdArgs[0]

        // — TOP —
        const isTop = /^(mensajestop|smstop|msgstop|topmsgs|topsms|topmensajes)$/i.test(cmd)

        if (isTop) {
            if (!message.isGroup)
                return message.reply('❌ Este comando solo puede usarse en grupos.')

            const senderNumero = message.sender.split('@')[0].replace(/\D/g, '')
            const db = getDb()

            // Obtener participantes del grupo para tener los JIDs reales
            let participants = []
            try {
                const meta = await conn.groupMetadata(message.from)
                participants = meta.participants || []
            } catch {
                return message.reply('❌ No pude obtener los miembros del grupo.')
            }

            // Crear mapa de número -> JID
            const numToJid = {}
            for (const p of participants) {
                const num = cleanNum(p.id)
                numToJid[num] = p.id
            }

            // Obtener ranking directamente de la DB
            const ranking = db.prepare(`
                SELECT user_number, COUNT(*) as total
                FROM messages
                WHERE group_jid = ?
                GROUP BY user_number
                ORDER BY total DESC
            `).all(message.from)

            if (ranking.length === 0)
                return message.reply('📊 Nadie en el grupo tiene mensajes registrados todavía.')

            // Convertir user_number a JID usando el mapa
            const rankingConJid = ranking.map(r => {
                const cleanNumber = cleanNum(r.user_number)
                const jid = numToJid[cleanNumber] || `${cleanNumber}@s.whatsapp.net`
                return {
                    jid: jid,
                    numero: cleanNumber,
                    total: r.total
                }
            }).filter(r => numToJid[r.numero]) // Solo usuarios que siguen en el grupo

            const itemsPerPage = 10
            const totalPages = Math.max(1, Math.ceil(rankingConJid.length / itemsPerPage))

            let page = 1
            const pageArg = cmdArgs[1]
            if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg))
            if (page > totalPages) page = totalPages

            const userIndex = rankingConJid.findIndex(u => u.numero === senderNumero)
            const userPosition = userIndex + 1
            const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0

            const start = (page - 1) * itemsPerPage
            const pageUsers = rankingConJid.slice(start, start + itemsPerPage)

            let txt = `*💬 TOP MENSAJES DEL GRUPO*\n`
            txt += userPosition > 0
                ? `_Tu posición:_ *#${userPosition}* (Página ${userPage})\n`
                : `_No estás en el ranking aún_\n`
            txt += `_Página_ *${page}* _de_ *${totalPages}*\n`

            if (totalPages > 1) {
                txt += `\n`
                if (page > 1) txt += `⬅️ *${usedPrefix}${cmd} ${page - 1}* página anterior\n`
                if (page < totalPages) txt += `➡️ *${usedPrefix}${cmd} ${page + 1}* siguiente página\n`
                if (userPage > 0 && userPage !== page) txt += `📍 *${usedPrefix}${cmd} ${userPage}* ir a tu página\n`
            }

            txt += `\n`
            pageUsers.forEach((u, i) => {
                const pos = start + i + 1
                const medal = medals[i] || `${pos}.`
                txt += `${medal} *@${u.numero}*\n💬 ${u.total.toLocaleString()} mensajes\n\n`
            })

            const mentions = pageUsers.map(u => u.jid)
            
            return await conn.sendMessage(message.from, { text: txt.trim(), mentions }, {
                quoted: message.baileyMessage || message._baileyMessage
            })
        }

        // — STATS INDIVIDUALES —
        const { numero, jid, esPropioUsuario } = getUserInfo(message, args)
        const stats = contarMensajes(numero, message.isGroup ? message.from : null)

        if (!stats) {
            const msg = esPropioUsuario
                ? '❌ No tengo mensajes tuyos guardados aún.'
                : `❌ No tengo mensajes guardados de @${jid.split('@')[0]}.`
            return message.reply(msg, { mentions: esPropioUsuario ? [] : [jid] })
        }

        let texto = ''
        const mentions = [jid] // Siempre incluimos el JID en las menciones para que el tag funcione correctamente
        
        if (esPropioUsuario) {
            texto = `💬 *@${numero}* _Has enviado_ *${stats.total.toLocaleString()}* _mensajes en este grupo._`
        } else {
            texto = `💬 *@${numero}* _Ha enviado_ *${stats.total.toLocaleString()}* _mensajes en este grupo._`
        }
        
        return await conn.sendMessage(message.from, { text: texto, mentions }, {
            quoted: message.baileyMessage || message._baileyMessage
        })

    } catch (err) {
        console.error('[MENSAJES ERROR]', err?.message || err)
        return message.reply('❌ Error al obtener los mensajes.')
    }
}

handler.help = ['msgs [@usuario]', 'mensajes [@usuario]', 'mensajestop', 'topmensajes', 'smstop']
handler.tags = ['herramientas']
handler.command = /^(msgs|mensajes|mensajestop|topmensajes|smstop|msgstop|topmsgs|topsms)$/i

module.exports = handler