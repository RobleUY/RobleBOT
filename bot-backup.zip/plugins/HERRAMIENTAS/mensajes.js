const fs = require('fs')
const path = require('path')

const CHAT_USUARIOS_DIR = path.join(__dirname, '../../CHATS-USUARIOS')

function getUserInfo(message, args) {
    const mentioned = message.mentions?.[0]
    if (mentioned) {
        const numero = mentioned.split('@')[0].replace(/\D/g, '')
        return { numero, jid: mentioned, esPropioUsuario: false }
    }
    const senderJid = message.sender
    const numero = senderJid.split('@')[0].replace(/\D/g, '')
    return { numero, jid: senderJid, esPropioUsuario: true }
}

function contarMensajes(numero, groupId) {
    const file = groupId
        ? path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
        : path.join(CHAT_USUARIOS_DIR, `${numero}.txt`)
    if (!fs.existsSync(file)) return null

    const contenido = fs.readFileSync(file, 'utf-8').trim()
    if (!contenido) return { total: 0, bytes: 0 }

    const lineas = contenido.split('\n').filter(Boolean)
    const bytes = Buffer.byteLength(contenido, 'utf-8')

    return { total: lineas.length, bytes }
}

function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟']

let handler = async (message, { args, conn }) => {
    try {
        const body = message.body || ''
        const usedPrefix = body.charAt(0) || '.'
        const cmdArgs = body.trim().slice(1).split(/\s+/)
        const cmd = cmdArgs[0]

        // — TOP —
        const isTop = /^(mensajestop|smstop|msgstop|topmsgs|topsms|topmensajes)$/i.test(cmd)

        if (isTop) {
            if (!message.isGroup)
                return message.reply('❌ Este comando solo puede usarse en grupos.')

            const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id)
            const senderNumero = message.sender.split('@')[0].replace(/\D/g, '')

            // Recopilar datos de cada participante
            const ranking = []
            for (const jid of participants) {
                const numero = jid.split('@')[0].replace(/\D/g, '')
                const stats = contarMensajes(numero, message.from)
                if (!stats || stats.total === 0) continue
                ranking.push({ jid, numero, total: stats.total })
            }

            if (ranking.length === 0)
                return message.reply('📊 Nadie en el grupo tiene mensajes registrados todavía.')

            ranking.sort((a, b) => b.total - a.total)

            const itemsPerPage = 10
            const totalPages = Math.max(1, Math.ceil(ranking.length / itemsPerPage))

            let page = 1
            const pageArg = cmdArgs[1]
            if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg))
            if (page > totalPages) page = totalPages

            const userIndex = ranking.findIndex(u => u.numero === senderNumero)
            const userPosition = userIndex + 1
            const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0

            const start = (page - 1) * itemsPerPage
            const pageUsers = ranking.slice(start, start + itemsPerPage)

            let txt = `*💬 TOP MENSAJES DEL GRUPO*\n`
            txt += userPosition > 0
                ? `_Tu posición:_ *#${userPosition}* (Página ${userPage})\n`
                : `_No estás en el ranking aún_\n`
            txt += `_Página_ *${page}* _de_ *${totalPages}*\n`

            if (totalPages > 1) {
                txt += `\n`
                if (page > 1) txt += `⬅️ *${usedPrefix}${cmd} ${page - 1}* página anterior\n`
                if (page < totalPages) txt += `➡️ *${usedPrefix}${cmd} ${page + 1}* siguiente página\n`
                if (userPage > 0 && userPage !== page) txt += `📍 *${usedPrefix}${cmd} ${userPage}* ir a tu página\n`
            }

            txt += `\n`
            pageUsers.forEach((u, i) => {
                const pos = start + i + 1
                const medal = medals[i] || `${pos}.`
                txt += `${medal} @${u.numero}\n💬 ${u.total.toLocaleString()} mensajes\n\n`
            })

            const mentions = pageUsers.map(u => u.jid)
            return message.reply(txt.trim(), { mentions })
        }

        // — STATS INDIVIDUALES —
        const { numero, jid, esPropioUsuario } = getUserInfo(message, args)
        const stats = contarMensajes(numero, message.isGroup ? message.from : null)

        if (!stats) {
            const msg = esPropioUsuario
                ? '❌ No tengo mensajes tuyos guardados aún.'
                : `❌ No tengo mensajes guardados de @${jid.split('@')[0]}.`
            return message.reply(msg, { mentions: esPropioUsuario ? [] : [jid] })
        }

        const header = esPropioUsuario
            ? `📊 *Tus mensajes registrados*`
            : `📊 *Mensajes de @${jid.split('@')[0]}*`

        const texto = `${header}\n${'─'.repeat(28)}\n💬 Mensajes: *${stats.total.toLocaleString()}*\n📁 Tamaño del historial: *${formatBytes(stats.bytes)}*`

        return message.reply(texto, { mentions: esPropioUsuario ? [] : [jid] })

    } catch (err) {
        console.error('[MENSAJES ERROR]', err?.message || err)
        return message.reply('❌ Error al obtener los mensajes.')
    }
}

handler.help = ['msgs [@usuario]', 'mensajestop', 'smstop']
handler.tags = ['herramientas']
handler.command = /^(msgs|mensajestop|smstop|msgstop|topmsgs|topsms|topmensajes)$/i

module.exports = handler
