const db = require('../../database.js');

let handler = async (message) => {
    const senderJid = message.author || message.sender || message.from;
    const senderNumber = senderJid?.split('@')[0]?.split(':')[0];

    const userData = db.getUser(senderNumber);
    userData.noDecor = !userData.noDecor;
    db.setUser(senderNumber, userData);

    const estado = userData.noDecor;
    await message.reply(
        estado
            ? `✅ Mensajes en modo simple activado.\n\nA partir de ahora el bot te responderá sin decorativos.\n\n_Usa .nodecor de nuevo para volver al modo normal._`
            : `🎨 Mensajes decorativos reactivados.\n\nA partir de ahora el bot te responderá con el formato normal.\n\n_Usa .nodecor de nuevo para desactivarlos._`
    );
};

handler.help = ['nodecor'];
handler.tags = ['herramientas'];
handler.command = /^nodecor$/i;
module.exports = handler;
