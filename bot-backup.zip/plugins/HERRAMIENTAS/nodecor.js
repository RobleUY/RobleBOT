const db = require('../../database.js');

let handler = async (message, { command }) => {
    const senderJid = message.author || message.sender || message.from;
    const senderNumber = senderJid?.split('@')[0]?.split(':')[0];

    const userData = db.getUser(senderNumber);
    const cmd = command.toLowerCase();

    let newValue;
    if (cmd === 'nodecor') {
        newValue = true;
    } else if (cmd === 'sidecor') {
        newValue = false;
    } else {
        // decor → alternar
        newValue = !userData.noDecor;
    }

    // Si ya está en ese estado, avisar
    if (userData.noDecor === newValue) {
        await message.reply(
            newValue
                ? '⚠️ Los mensajes decorativos ya están desactivados.\n_Usa .sidecor para reactivarlos._'
                : '⚠️ Los mensajes decorativos ya están activados.\n_Usa .nodecor para desactivarlos._'
        );
        return;
    }

    userData.noDecor = newValue;
    db.setUser(senderNumber, userData);

    await message.reply(
        newValue
            ? '✅ Mensajes en modo simple activado. El bot te responderá sin decorativos.\n_Usa .sidecor para volver al modo normal._'
            : '🎨 Mensajes decorativos reactivados.\n_Usa .nodecor para desactivarlos._'
    );
};

handler.help = ['nodecor', 'sidecor', 'decor'];
handler.tags = ['herramientas'];
handler.command = /^(nodecor|sidecor|decor)$/i;
module.exports = handler;
