/**
 * Comando: timg / toimg
 * Descripción: Convierte stickers, videos y GIFs en imágenes estáticas.
 * Uso: Responde a un sticker, imagen, video o GIF con .toimg o .timg
 *
 * Comando: wao2
 * Descripción: Reenvía la media citada al chat privado del TARGET_JID_CLEAN (SILENCIOSO).
 * Uso: Responde a una imagen con .wao2
 *
 * Funcionalidad Adicional (Respuesta "wao"): 
 * Responde a CUALQUIER imagen (incluyendo View Once) con la palabra "wao", "wao2" o "wao3" 
 * para que el bot la reenvíe a tu chat privado.
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

// --- Configuración Global ---
// Números de teléfono autorizados (en formato de JID limpio - sin '@s.whatsapp.net')
// IMPORTANTE: Incluir TANTO tu número personal como el número del bot
const AUTHORIZED_JIDS = ['59893900470', '149078365237384', '59892099606']; 
const TARGET_JID_CLEAN = '59893900470'; 

// Set para evitar procesamiento duplicado
const processedMessages = new Set();

// --- Funciones Auxiliares ---

function tmpFileName(ext = '') {
    const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
    return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

/**
 * Determina el JID real del remitente del mensaje
 */
function getRealSenderJid(baileyMsg, sock) {
    if (baileyMsg.key?.fromMe) {
        if (sock && sock.user && sock.user.id) {
            return sock.user.id;
        }
        return `${TARGET_JID_CLEAN}@s.whatsapp.net`;
    }
    
    if (baileyMsg.key?.participant) {
        return baileyMsg.key.participant;
    }
    
    return baileyMsg.key?.remoteJid || null;
}

/**
 * Función que detecta y descarga el contenido multimedia citado.
 */
async function detectQuotedMedia(baileyMsg) {
    try {
        let contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo ||
                              baileyMsg.message?.imageMessage?.contextInfo ||
                              baileyMsg.message?.videoMessage?.contextInfo ||
                              baileyMsg.message?.stickerMessage?.contextInfo;

        if (!contextInfo?.quotedMessage) return null;

        const quotedMessage = contextInfo.quotedMessage;
        let mediaMessage = quotedMessage.imageMessage || quotedMessage.videoMessage || quotedMessage.stickerMessage;
        
        // BUSCAR MEDIA EN VIEW ONCE 
        if (quotedMessage.viewOnceMessage) {
            mediaMessage = quotedMessage.viewOnceMessage.message.imageMessage || 
                           quotedMessage.viewOnceMessage.message.videoMessage ||
                           quotedMessage.viewOnceMessage.message.stickerMessage;
        } else if (quotedMessage.viewOnceMessageV2) {
             mediaMessage = quotedMessage.viewOnceMessageV2.message.imageMessage || 
                           quotedMessage.viewOnceMessageV2.message.videoMessage;
        }

        if (!mediaMessage) return null;

        let type, downloadType;

        if (mediaMessage.stickerMessage || quotedMessage.stickerMessage || mediaMessage.mimetype?.startsWith('sticker')) {
            type = 'sticker';
            downloadType = 'sticker';
        } else if (mediaMessage.imageMessage || quotedMessage.imageMessage || mediaMessage.mimetype?.startsWith('image')) {
            type = 'image';
            downloadType = 'image';
        } else if (mediaMessage.videoMessage || quotedMessage.videoMessage || mediaMessage.mimetype?.startsWith('video')) {
            const isGif = !!(mediaMessage.videoMessage || quotedMessage.videoMessage)?.gifPlayback;
            type = isGif ? 'gif' : 'video';
            downloadType = 'video';
        } else {
             return null;
        }
        
        if (!downloadType) return null;

        const stream = await downloadContentFromMessage(mediaMessage, downloadType);
        const buffer = await streamToBuffer(stream);
        return { data: buffer, type: type, originalMsg: mediaMessage };

    } catch (error) {
        console.error('❌ Error en detectQuotedMedia:', error);
        return null;
    }
}

async function ffmpegExtractFirstFrame(inputBuffer, inputExt = 'mp4') {
    const inputPath = tmpFileName(inputExt);
    const framePath = tmpFileName('jpg');
    try {
        await fs.writeFile(inputPath, inputBuffer);
        const args = [
            '-y', '-i', inputPath,
            '-ss', '0',
            '-vframes', '1',
            framePath
        ];
        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 15_000 });
        const frameBuffer = await fs.readFile(framePath);
        return frameBuffer;
    } finally {
        await Promise.allSettled([fs.unlink(inputPath).catch(() => { }), fs.unlink(framePath).catch(() => { })]);
    }
}

async function convertToImageFormat(mediaBuffer, mediaType) {
    try {
        if (mediaType === 'sticker') {
            // Los stickers WebP tienen canvas cuadrado con la imagen centrada y el resto
            // transparente. Recortamos el espacio vacío con .trim() antes de aplanar,
            // así el resultado queda ajustado al contenido sin bordes de ningún color.
            return await sharp(mediaBuffer)
                .trim()                                              // recortar pixels transparentes/de borde
                .flatten({ background: { r: 255, g: 255, b: 255 } }) // aplanar alpha restante
                .png()
                .toBuffer();
        }

        if (mediaType === 'image') {
            // Las imágenes normales no necesitan trim, solo aplanar el alpha si lo tienen
            return await sharp(mediaBuffer)
                .flatten({ background: { r: 255, g: 255, b: 255 } })
                .png()
                .toBuffer();
        }

        if (mediaType === 'gif' || mediaType === 'video') {
            try {
                const inputExt = mediaType === 'gif' ? 'gif' : 'mp4';
                const frameBuffer = await ffmpegExtractFirstFrame(mediaBuffer, inputExt);
                return await sharp(frameBuffer).png().toBuffer();
            } catch (ffErr) {
                if (mediaType === 'gif') {
                    return await sharp(mediaBuffer, { pages: 1 }).png().toBuffer();
                }
                return null;
            }
        }
        return null;
    } catch (error) {
        console.error('❌ Error en convertToImageFormat:', error);
        return null;
    }
}

/**
 * Convierte cualquier media (sticker, imagen, gif, video) a MP4.
 * - sticker/gif → mp4 via ffmpeg
 * - imagen → mp4 (imagen estática de 3 segundos) via ffmpeg
 * - video → devuelve el buffer tal cual (ya es mp4)
 */
async function convertToVideoFormat(mediaBuffer, mediaType) {
    const inputExt = mediaType === 'sticker' ? 'webp'
                   : mediaType === 'image'   ? 'png'
                   : mediaType === 'gif'     ? 'gif'
                   : 'mp4';

    // Si ya es video, devolver directo
    if (mediaType === 'video') return mediaBuffer;

    const inputPath = tmpFileName(inputExt);
    const outputPath = tmpFileName('mp4');
    try {
        // Para sticker webp animado o imagen estática, primero convertir a png con sharp
        let writeBuf = mediaBuffer;
        let realInputPath = inputPath;

        if (mediaType === 'sticker' || mediaType === 'image') {
            // Convertir a png para que ffmpeg lo lea bien
            writeBuf = await sharp(mediaBuffer).png().toBuffer();
            realInputPath = tmpFileName('png');
            await fs.writeFile(realInputPath, writeBuf);
        } else {
            await fs.writeFile(inputPath, mediaBuffer);
            realInputPath = inputPath;
        }

        let args;
        if (mediaType === 'image') {
            // Imagen estática → video de 3 segundos
            args = [
                '-y', '-loop', '1', '-i', realInputPath,
                '-c:v', 'libx264', '-t', '3',
                '-pix_fmt', 'yuv420p',
                '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
                outputPath
            ];
        } else {
            // gif / sticker animado → mp4
            args = [
                '-y', '-i', realInputPath,
                '-c:v', 'libx264',
                '-pix_fmt', 'yuv420p',
                '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
                '-movflags', '+faststart',
                outputPath
            ];
        }

        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 30_000 });
        return await fs.readFile(outputPath);
    } finally {
        await Promise.allSettled([
            fs.unlink(inputPath).catch(() => {}),
            fs.unlink(outputPath).catch(() => {}),
        ]);
    }
}

/**
 * Convierte cualquier media (sticker, imagen, video, gif) a GIF animado.
 * - sticker/gif → gif via ffmpeg
 * - imagen → gif estático via sharp
 * - video → gif via ffmpeg (primeros 10 segundos, 15fps, 480px ancho)
 */
async function convertToGifFormat(mediaBuffer, mediaType) {
    // Imagen estática → gif con sharp (sin ffmpeg)
    if (mediaType === 'image') {
        return await sharp(mediaBuffer).gif().toBuffer();
    }

    const inputExt = mediaType === 'sticker' ? 'webp'
                   : mediaType === 'gif'     ? 'gif'
                   : 'mp4';

    // Si ya es gif, devolver directo
    if (mediaType === 'gif') return mediaBuffer;

    const inputPath = tmpFileName(inputExt);
    const outputPath = tmpFileName('gif');
    try {
        let writeBuf = mediaBuffer;
        let realInputPath = inputPath;

        if (mediaType === 'sticker') {
            // Convertir webp a png primero para mejor compatibilidad
            writeBuf = await sharp(mediaBuffer).png().toBuffer();
            realInputPath = tmpFileName('png');
            await fs.writeFile(realInputPath, writeBuf);
        } else {
            await fs.writeFile(inputPath, mediaBuffer);
            realInputPath = inputPath;
        }

        const args = [
            '-y', '-i', realInputPath,
            '-t', '10',                          // máximo 10 segundos
            '-vf', 'fps=15,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse',
            outputPath
        ];

        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 60_000 });
        return await fs.readFile(outputPath);
    } finally {
        await Promise.allSettled([
            fs.unlink(inputPath).catch(() => {}),
            fs.unlink(outputPath).catch(() => {}),
        ]);
    }
}

async function sendMedia(sock, jid, mediaBuffer, mediaType, caption = '') {
    try {
        const messageOptions = { caption: caption };
        
        if (mediaType === 'image' || mediaType === 'sticker') { 
            messageOptions.image = mediaBuffer;
        } else if (mediaType === 'video' || mediaType === 'gif') {
             messageOptions.video = mediaBuffer;
        } else {
             return null;
        }
        return await sock.sendMessage(jid, messageOptions);
    } catch (error) {
        console.error(`❌ Error al enviar ${mediaType}:`, error);
        return null;
    }
}

// --- Handler del Comando .toimg/.timg ---
let toimgHandler = async (message) => {
    try {
        const sock = message._sock || global.conn;
        if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

        const quotedMedia = await detectQuotedMedia(global.lastBaileyMessage);
        if (!quotedMedia) {
            return await message.reply('❌ Responde a un *sticker*, *imagen*, *video* o *GIF* con el comando *.toimg* para convertirlo en imagen.');
        }

        const mediaType = quotedMedia.type;
        await message.reply('⏳ Convirtiendo a imagen...');

        const imageBuffer = await convertToImageFormat(quotedMedia.data, mediaType);

        if (!imageBuffer) {
            return await message.reply(`❌ Error al convertir el ${mediaType} a imagen.`);
        }

        const success = await sendMedia(
            sock, 
            message.from, 
            imageBuffer, 
            'image', 
            `✅ *Aquí tienes tu imagen convertida.*`
        );

        if (!success) {
            return await message.reply('❌ Error al enviar la imagen convertida.');
        }

    } catch (error) {
        console.error('❌ Error general en handler toimg:', error);
        await message.reply('❌ Ocurrió un error al convertir a imagen.');
    }
};

// --- Handler del Comando .tovideo ---
let tovideoHandler = async (message) => {
    try {
        const sock = message._sock || global.conn;
        if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

        const quotedMedia = await detectQuotedMedia(global.lastBaileyMessage);
        if (!quotedMedia) {
            return await message.reply('❌ Responde a un *sticker*, *imagen*, *GIF* o *video* con *.tovideo* para convertirlo en video.');
        }

        const mediaType = quotedMedia.type;
        await message.reply('⏳ Convirtiendo a video...');

        let videoBuffer;
        try {
            videoBuffer = await convertToVideoFormat(quotedMedia.data, mediaType);
        } catch (err) {
            console.error('❌ Error en convertToVideoFormat:', err);
            return await message.reply(`❌ Error al convertir el ${mediaType} a video. Asegúrate de que ffmpeg esté instalado.`);
        }

        if (!videoBuffer) {
            return await message.reply(`❌ No se pudo convertir el ${mediaType} a video.`);
        }

        const success = await sock.sendMessage(message.from, {
            video: videoBuffer,
            caption: '✅ *Aquí tienes tu video convertido.*'
        });

        if (!success) {
            return await message.reply('❌ Error al enviar el video convertido.');
        }

    } catch (error) {
        console.error('❌ Error general en handler tovideo:', error);
        await message.reply('❌ Ocurrió un error al convertir a video.');
    }
};

// --- Handler del Comando .togif ---
let togifHandler = async (message) => {
    try {
        const sock = message._sock || global.conn;
        if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

        const quotedMedia = await detectQuotedMedia(global.lastBaileyMessage);
        if (!quotedMedia) {
            return await message.reply('❌ Responde a un *sticker*, *imagen*, *video* o *GIF* con *.togif* para convertirlo en GIF.');
        }

        const mediaType = quotedMedia.type;
        await message.reply('⏳ Convirtiendo a GIF... (puede tardar unos segundos)');

        let gifBuffer;
        try {
            gifBuffer = await convertToGifFormat(quotedMedia.data, mediaType);
        } catch (err) {
            console.error('❌ Error en convertToGifFormat:', err);
            return await message.reply(`❌ Error al convertir el ${mediaType} a GIF. Asegúrate de que ffmpeg esté instalado.`);
        }

        if (!gifBuffer) {
            return await message.reply(`❌ No se pudo convertir el ${mediaType} a GIF.`);
        }

        // Enviar como video con gifPlayback para que se vea como GIF en WhatsApp
        const success = await sock.sendMessage(message.from, {
            video: gifBuffer,
            gifPlayback: true,
            caption: '✅ *Aquí tienes tu GIF convertido.*'
        });

        if (!success) {
            return await message.reply('❌ Error al enviar el GIF convertido.');
        }

    } catch (error) {
        console.error('❌ Error general en handler togif:', error);
        await message.reply('❌ Ocurrió un error al convertir a GIF.');
    }
};

// --- Handler del Comando .wao2 (SILENCIOSO) ---
let wao2Handler = async (message) => {
    try {
        const sock = message._sock || global.conn;
        if (!sock) return;

        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) return;

        // 1. Protección Anti-Duplicados
        const messageId = baileyMsg.key?.id;
        if (!messageId || processedMessages.has(messageId)) {
            return;
        }
        processedMessages.add(messageId);

        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL
        const senderJid = getRealSenderJid(baileyMsg, sock);
        if (!senderJid) {
            processedMessages.delete(messageId);
            return;
        }

        const senderJidClean = senderJid.split('@')[0].split(':')[0];

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            processedMessages.delete(messageId);
            return;
        }

        // 4. Detectar media citada
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        
        if (!quotedMedia) {
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino (SILENCIOSO)
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por comando *.wao2* de ${senderJidClean} (${quotedMedia.type})`
        );

        // No hay reply. El comando es silencioso.
        console.log(success ? `✅ [WAO2-CMD] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO2-CMD] Error al enviar`);

    } catch (error) {
        console.error('❌ Error en wao2Handler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};


// --- Handler de RESPUESTA de Texto ("wao", "wao2", "wao3") ---
let textReplyHandler = async (message) => {
    try {
        const sock = message._sock || global.conn;
        if (!sock) return;

        const baileyMsg = global.lastBaileyMessage;
        if (!baileyMsg) return;
        
        // PROTECCIÓN ANTI-DUPLICADOS
        const messageId = baileyMsg.key?.id;
        if (!messageId) return;
        
        if (processedMessages.has(messageId)) {
            return;
        }
        
        // 1. Verificar el texto (si es "wao", "wao2" o "wao3")
        const text = message.body?.toLowerCase().trim();
        if (!text || (text !== 'wao1' && text !== 'wao2' && text !== 'wao3')) return;

        // Marcar como procesado
        processedMessages.add(messageId);
        
        // Limpiar mensajes viejos
        if (processedMessages.size > 100) {
            const firstItem = processedMessages.values().next().value;
            processedMessages.delete(firstItem);
        }

        // 2. Determinar el JID del remitente REAL
        const senderJid = getRealSenderJid(baileyMsg, sock);
        if (!senderJid) {
            processedMessages.delete(messageId);
            return;
        }
        
        const senderJidClean = senderJid.split('@')[0].split(':')[0];

        // 3. Verificar autorización
        if (!AUTHORIZED_JIDS.includes(senderJidClean)) {
            processedMessages.delete(messageId);
            return;
        }

        // 4. Detectar media citada
        const quotedMedia = await detectQuotedMedia(baileyMsg);
        
        if (!quotedMedia) {
            processedMessages.delete(messageId);
            return;
        }

        // 5. Enviar al destino
        const targetNumberJid = `${TARGET_JID_CLEAN}@s.whatsapp.net`;
        
        const success = await sendMedia(
            sock,
            targetNumberJid,
            quotedMedia.data,
            quotedMedia.type,
            `✅ Reenviado por "${text.toUpperCase()}" de ${senderJidClean} (${quotedMedia.type})`
        );

        console.log(success ? `✅ [WAO-TEXT] Enviado exitosamente a ${TARGET_JID_CLEAN}` : `❌ [WAO-TEXT] Error al enviar`);
        
    } catch (error) {
        console.error('❌ Error en textReplyHandler:', error);
        const messageId = global.lastBaileyMessage?.key?.id;
        if (messageId) processedMessages.delete(messageId);
    }
};

// Limpiar cada 5 minutos
setInterval(() => {
    if (processedMessages.size > 50) {
        processedMessages.clear();
    }
}, 5 * 60 * 1000);

// --- HANDLER PRINCIPAL (Router de Comandos) ---
let mainHandler = async (message, commandParams) => {
    const commandText = commandParams?.command?.toLowerCase(); 

    if (commandText === 'wao') {
        return await wao2Handler(message);
    } else if (commandText === 'toimg' || commandText === 'timg') { 
        return await toimgHandler(message);
    } else if (commandText === 'ztovideo' || commandText === 'ztvideo') {
        return await tovideoHandler(message);
    } else if (commandText === 'ztogif' || commandText === 'ztgif') {
        return await togifHandler(message);
    }
    return;
};


// --- Exportación CORREGIDA y Sincronizada ---
// 💡 CORRECCIÓN: El regex ahora usa los nombres de comandos correctos (toimg, timg).

mainHandler.help = ['toimg', 'timg', 'ztovideo', 'ztvideo', 'ztogif', 'ztgif', 'wao2'];
mainHandler.tags = ['sticker', 'util'];
mainHandler.command = /^(toimg|timg|ztovideo|ztvideo|ztogif|ztgif|waoo)$/i; 

module.exports = mainHandler;
module.exports.textReplyHandler = textReplyHandler;
module.exports.toimgHandler = toimgHandler;
module.exports.tovideoHandler = tovideoHandler;
module.exports.togifHandler = togifHandler;
module.exports.wao2Handler = wao2Handler;