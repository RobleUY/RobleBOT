const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const { execFile } = require('child_process');
const { promisify } = require('util');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const execFileAsync = promisify(execFile);

function tmpFile(ext) {
    return path.join(os.tmpdir(), `${crypto.randomBytes(10).toString('hex')}.${ext}`);
}

let handler = async (message, { command }) => {
    try {
        const sock = global.conn;
        const m = message._baileyMessage;
        
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted || !quoted.stickerMessage) {
            return await message.reply('❌ Responde a un *Sticker* para convertirlo.');
        }

        const sticker = quoted.stickerMessage;
        const isAnimated = !!sticker.isAnimated;

        await message.reply('⏳ Procesando conversión...');
        const stream = await downloadContentFromMessage(sticker, 'sticker');
        let buffer = Buffer.alloc(0);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (command === 'toimg') {
            if (isAnimated) return await message.reply('❌ Sticker animado detectado. Usa */togif* o */tovideo*.');
            const pngBuffer = await sharp(buffer).png().toBuffer();
            return await sock.sendMessage(message.from, { image: pngBuffer, caption: '✅ Hecho.' }, { quoted: m });
        }

        if (command === 'tovideo' || command === 'togif') {
            if (!isAnimated) return await message.reply('❌ Este sticker no es animado.');

            const inputPath = tmpFile('webp');
            const outputPath = tmpFile(command === 'togif' ? 'gif' : 'mp4');

            await fs.writeFile(inputPath, buffer);

            // Argumentos mejorados para mayor compatibilidad con WebP animado
            let ffmpegArgs = [
                '-vcodec', 'libwebp', // Forzamos decodificador de entrada
                '-i', inputPath,
            ];

            if (command === 'togif') {
                ffmpegArgs.push('-vf', 'fps=15,scale=512:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse', '-loop', '0', outputPath);
            } else {
                ffmpegArgs.push('-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-preset', 'fast', outputPath);
            }

            try {
                await execFileAsync('ffmpeg', ffmpegArgs);
                const resultBuffer = await fs.readFile(outputPath);

                if (command === 'togif') {
                    await sock.sendMessage(message.from, { video: resultBuffer, gifPlayback: true, caption: '✅ GIF creado.' }, { quoted: m });
                } else {
                    await sock.sendMessage(message.from, { video: resultBuffer, caption: '✅ Video creado.' }, { quoted: m });
                }
            } catch (ffError) {
                console.error('FFMPEG Error:', ffError);
                await message.reply('❌ Tu servidor no soporta la decodificación de stickers animados. Intenta actualizar libwebp-dev.');
            } finally {
                await fs.unlink(inputPath).catch(() => {});
                await fs.unlink(outputPath).catch(() => {});
            }
        }

    } catch (error) {
        console.error('General Error:', error);
        await message.reply('❌ Error inesperado.');
    }
};

handler.help = ['toimg', 'togif', 'tovideo'];
handler.tags = ['convertir'];
handler.command = /^(toimg|togif|tovideo)$/i;

module.exports = handler;