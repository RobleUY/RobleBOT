let handler = async (message, { conn, text, command }) => {
    try {
        console.log('\n=================== DEBUG INFO ===================');
        console.log('Comando recibido:', command);
        console.log('Mensaje de:', message.sender);
        console.log('Texto:', text);
        console.log('Es grupo?:', message.isGroup);
        console.log('Menciones:', message.mentions);
        console.log('key:', message.key);
        console.log('=================================================\n');

        const jidToNumber = (jid) => {
            if (!jid) return null;
            return jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        };

        // Resuelve LID → PN real usando todos los métodos disponibles
        const resolveLid = async (lid, groupId) => {
            if (!lid) return null;

            // Si ya es un número real, no hace falta resolver
            if (lid.includes('s.whatsapp.net')) return lid;

            // MÉTODO 1: signalRepository de Baileys v7
            try {
                if (conn.signalRepository?.lidMapping) {
                    const pn = await conn.signalRepository.lidMapping.getPNForLID(lid);
                    if (pn) {
                        console.log('[LID resolved via signalRepository]:', pn);
                        return pn;
                    }
                }
            } catch (e) {
                console.log('[signalRepository error]:', e.message);
            }

            // MÉTODO 2: groupMetadata → participant.phoneNumber (Baileys v7)
            if (groupId) {
                try {
                    const groupMeta = await conn.groupMetadata(groupId);
                    const participant = groupMeta.participants.find(p =>
                        p.id === lid ||
                        p.lid === lid ||
                        p.id?.startsWith(lid.split('@')[0]) ||
                        p.lid?.startsWith(lid.split('@')[0])
                    );
                    if (participant) {
                        console.log('[participant found]:', JSON.stringify(participant));
                        if (participant.phoneNumber) return participant.phoneNumber;
                        if (participant.id?.includes('s.whatsapp.net')) return participant.id;
                        if (participant.jid?.includes('s.whatsapp.net')) return participant.jid;
                    }
                } catch (e) {
                    console.log('[groupMetadata error]:', e.message);
                }
            }

            // Fallback: devolver el LID tal cual (al menos es funcional para enviar mensajes)
            return lid;
        };

        const jidToNumber2 = async (jid, groupId) => {
            const resolved = await resolveLid(jid, groupId);
            return jidToNumber(resolved);
        };

        let targetJid;
        let targetName = message.pushName || 'Usuario';
        let realNumber = null;

        // =========================================================
        // COMANDO: jidtonum
        // =========================================================
        if (/^jidtonum$/i.test(command)) {
            if (!text) {
                await message.reply('❗ Usa el comando así:\n\n*Ejemplo:* `.jidtonum 5215512345678@s.whatsapp.net`');
                return;
            }
            targetJid = text.trim();
            const resolved = await resolveLid(targetJid, message.from);
            realNumber = jidToNumber(resolved);
            await message.reply(`🔢 *CONVERSIÓN JID → NÚMERO*\n\n📄 JID: ${targetJid}\n✅ Resuelto: ${resolved}\n📞 Número: \`+${realNumber}\``);
            return;
        }

        // =========================================================
        // COMANDO: jid
        // =========================================================
        if (/^jid$/i.test(command)) {
            if (message.mentions?.length > 0) {
                const mentionedLid = message.mentions[0];
                targetName = 'Usuario mencionado';
                targetJid = await resolveLid(mentionedLid, message.from);
            } else {
                // Para el sender: participantAlt ya tiene el PN real en Baileys v7
                targetJid = message.key?.participantAlt ||
                    (message.isGroup ? message.key.participant : message.sender);
                targetName = message.pushName || 'Tú';
            }
            await message.reply(`🪪 *JID DEL USUARIO*\n\n👤 ${targetName}\n📄 \`${targetJid}\``);
            return;
        }

        // =========================================================
        // COMANDO: celular
        // =========================================================
        if (/^celular$/i.test(command)) {
            if (message.mentions?.length > 0) {
                const mentionedLid = message.mentions[0];
                targetName = 'Usuario mencionado';
                targetJid = await resolveLid(mentionedLid, message.from);
                realNumber = jidToNumber(targetJid);
            } else {
                targetJid = message.key?.participantAlt ||
                    (message.isGroup ? message.key.participant : message.sender);
                targetName = message.pushName || 'Tú';
                realNumber = jidToNumber(targetJid);
            }
            if (!realNumber) realNumber = jidToNumber(targetJid);
            await message.reply(`📱 *NÚMERO REAL*\n\n👤 ${targetName}\n📞 \`+${realNumber}\``);
            return;
        }

        // =========================================================
        // COMANDO: numtd
        // =========================================================
        if (/^numtd$/i.test(command)) {
            targetJid = message.key?.participantAlt ||
                (message.isGroup ? message.key.participant : message.sender);
            targetName = message.pushName || 'Tú';
            realNumber = jidToNumber(targetJid);
            await message.reply(`🧾 *TUS DATOS DE WHATSAPP*\n\n👤 ${targetName}\n📄 JID: \`${targetJid}\`\n📞 Número: \`+${realNumber}\``);
            return;
        }

    } catch (err) {
        console.error('[ERROR GENERAL]:', err);
        await message.reply(`❌ Error interno: ${err.message}`);
    }
};

handler.help = ['celular', 'jid', 'jidtonum', 'numtd'];
handler.tags = ['info'];
handler.command = /^(celular|jid|jidtonum|numtd)$/i;

module.exports = handler;