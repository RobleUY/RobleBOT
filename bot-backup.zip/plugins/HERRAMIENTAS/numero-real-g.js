let handler = async (message, { conn, text, command }) => {
    try {
        console.log('\n=================== DEBUG INFO ===================');
        console.log('Comando recibido:', command);
        console.log('Mensaje de:', message.sender);
        console.log('Texto:', text);
        console.log('Es grupo?:', message.isGroup);
        console.log('Menciones:', message.mentions);
        console.log('key:', message.key);
        console.log('=================================================\n');

        // Convierte un JID en número
        const jidToNumber = (jid) => {
            if (!jid) return null;
            return jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        };

        // Busca un número real de un JID dentro de un grupo
        const findNumberInGroup = async (jid, groupId) => {
            if (!groupId || !jid) return null;
            try {
                const groupMeta = await conn.groupMetadata(groupId);
                const participant = groupMeta.participants.find(p => p.id.startsWith(jid.split('@')[0]));
                return participant ? jidToNumber(participant.jid) : null;
            } catch (e) {
                console.log('[ERROR findNumberInGroup]:', e);
                return null;
            }
        };

        let targetJid;
        let targetName = message.pushName || 'Usuario';
        let realNumber = null;

        // =========================================================
        // COMANDO: jidtonum → Convierte JID a número real
        // =========================================================
        if (/^jidtonum$/i.test(command)) {
            if (!text) {
                await message.reply('❗ Usa el comando así:\n\n*Ejemplo:* `.jidtonum 5215512345678@s.whatsapp.net`');
                return;
            }

            targetJid = text.trim();
            realNumber = await findNumberInGroup(targetJid, message.from);

            if (!realNumber) {
                // Fallback: limpiar el JID manualmente
                realNumber = jidToNumber(targetJid);
            }

            await message.reply(`🔢 *CONVERSIÓN JID → NÚMERO*\n\n📄 JID: ${targetJid}\n📞 Número: \`+${realNumber}\``);
            return;
        }

        // =========================================================
        // COMANDO: jid → Muestra el JID real del usuario o mención
        // =========================================================
        if (/^jid$/i.test(command)) {
            if (message.mentions?.length > 0) {
                targetJid = message.mentions[0];
                targetName = 'Usuario mencionado';
            } else {
                targetJid = message.isGroup ? message.key.participant : message.sender;
                targetName = message.pushName || 'Tú';
            }

            await message.reply(`🪪 *JID DEL USUARIO*\n\n👤 ${targetName}\n📄 \`${targetJid}\``);
            return;
        }

        // =========================================================
        // COMANDO: celular → Saca el número real
        // =========================================================
        if (/^celular$/i.test(command)) {
            const isMention = message.mentions?.length > 0;

            if (isMention) {
                targetJid = message.mentions[0];
                targetName = 'Usuario mencionado';
            } else {
                targetJid = message.isGroup ? message.key.participant : message.sender;
                targetName = message.pushName || 'Tú';
            }

            if (message.isGroup) {
                realNumber = await findNumberInGroup(targetJid, message.from);
            }

            if (!realNumber) {
                realNumber = jidToNumber(targetJid);
            }

            await message.reply(`📱 *NÚMERO REAL*\n\n👤 ${targetName}\n📞 \`+${realNumber}\``);
            return;
        }

        // =========================================================
        // COMANDO: numtd → Muestra tu JID y tu número real
        // =========================================================
        if (/^numtd$/i.test(command)) {
            targetJid = message.isGroup ? message.key.participant : message.sender;
            targetName = message.pushName || 'Tú';

            if (message.isGroup) {
                realNumber = await findNumberInGroup(targetJid, message.from);
            }

            if (!realNumber) {
                realNumber = jidToNumber(targetJid);
            }

            await message.reply(`🧾 *TUS DATOS DE WHATSAPP*\n\n👤 ${targetName}\n📄 JID: \`${targetJid}\`\n📞 Número: \`+${realNumber}\``);
            return;
        }

    } catch (err) {
        console.error('[ERROR GENERAL]:', err);
        await message.reply(`❌ Error interno: ${err.message}`);
    }
};

handler.help = ['celular', 'jid', 'jidtonum', 'numtd'];
handler.tags = ['info'];
handler.command = /^(celular|jid|jidtonum|numtd)$/i;

module.exports = handler;
