const { parsePhoneNumberFromString } = require('libphonenumber-js')

// Mapa de nombres de países a códigos ISO (puedes añadir los que quieras)
const countryMap = {
    'uruguay': 'UY',
    'peru': 'PE',
    'mexico': 'MX',
    'argentina': 'AR',
    'españa': 'ES',
    'colombia': 'CO',
    'chile': 'CL',
    'venezuela': 'VE',
    'bolivia': 'BO'
}

let handler = async (message, { text }) => {
    try {
        if (!text) return message.reply('❌ Uso: `.numwa <país> <número>`\nEj: `.numwa uruguay 093900470`')

        const args = text.trim().split(/\s+/)
        if (args.length < 2) return message.reply('❌ Falta el país o el número.')

        const paisInput = args[0].toLowerCase()
        const numeroRaw = args.slice(1).join('') // Unimos el resto por si tiene espacios
        
        const isoCode = countryMap[paisInput]

        if (!isoCode) {
            return message.reply(`❌ El país "${paisInput}" no está soportado o está mal escrito. Usa: uruguay, peru, mexico, etc.`)
        }

        // La magia de la librería: analiza el número según el país (ISO Code)
        const phoneNumber = parsePhoneNumberFromString(numeroRaw, isoCode)

        // 1. Verificamos si el número es válido
        if (!phoneNumber || !phoneNumber.isValid()) {
            
            // Ayuda extra: si es Uruguay y puso 9 números pero le falta el 0, o le sobra.
            return message.reply(`⚠️ *Número Inválido para ${paisInput.toUpperCase()}*\n\nEl formato no coincide con el estándar del país. Revisa si sobran o faltan dígitos.`)
        }

        // 2. Extraemos el formato internacional puro para WhatsApp (E.164)
        const numeroFinal = phoneNumber.format('E164').replace('+', '')

        let response = `✅ *Validación Profesional*\n\n`
        response += `🌍 *País:* ${phoneNumber.country}\n`
        response += `📱 *Formato Local:* ${phoneNumber.formatNational()}\n`
        response += `🔢 *Internacional:* +${numeroFinal}\n\n`
        response += `🔗 *Link:* https://wa.me/${numeroFinal}`

        return message.reply(response)

    } catch (err) {
        console.error(err)
        return message.reply('❌ Error al procesar el número.')
    }
}

handler.help = ['numwa <país> <número>']
handler.tags = ['herramientas']
handler.command = /^numwa$/i

module.exports = handler