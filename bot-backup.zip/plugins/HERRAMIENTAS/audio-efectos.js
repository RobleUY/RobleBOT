/**
 * Comando: efecto
 * Descripción: Aplica efectos de audio a mensajes de voz o audio
 * Uso: Responde a un audio con .efecto [nombre_efecto]
 * Efectos disponibles: robot, ardilla, grave, reverb, eco, nightcore, lento, rapido, demonio, alien
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

async function detectQuotedAudio() {
  try {
    console.log('🔍 Buscando audio citado...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      console.log('❌ No hay mensaje de @whiskeysockets/baileys guardado');
      return null;
    }

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.audioMessage?.contextInfo) {
      contextInfo = baileyMsg.message.audioMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) {
      console.log('❌ No hay mensaje citado');
      return null;
    }

    const quotedMessage = contextInfo.quotedMessage;

    // audioMessage (mensajes de voz o audio)
    if (quotedMessage.audioMessage) {
      console.log('🎵 Audio citado detectado, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.audioMessage, 'audio');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.audioMessage.mimetype || 'audio/ogg; codecs=opus',
          type: 'audio',
          ptt: quotedMessage.audioMessage.ptt || false
        };
      } catch (err) {
        console.error('❌ Error descargando audio citado:', err);
        return null;
      }
    }

    console.log('❌ El mensaje citado no es un audio');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectQuotedAudio:', error);
    return null;
  }
}

// Definición de efectos de audio con sus filtros FFmpeg
const audioEffects = {
  robot: {
    name: '🤖 Robot',
    filters: 'afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75'
  },
  ardilla: {
    name: '🐿️ Ardilla',
    filters: 'asetrate=44100*1.5,aresample=44100,atempo=1.0'
  },
  grave: {
    name: '🔉 Grave/Profundo',
    filters: 'asetrate=44100*0.7,aresample=44100,atempo=1.0'
  },
  reverb: {
    name: '🎭 Reverb',
    filters: 'aecho=0.8:0.88:60:0.4'
  },
  eco: {
    name: '📢 Eco',
    filters: 'aecho=0.8:0.9:1000:0.3'
  },
  nightcore: {
    name: '🌙 Nightcore',
    filters: 'asetrate=44100*1.25,aresample=44100'
  },
  lento: {
    name: '🐌 Lento',
    filters: 'atempo=0.7'
  },
  rapido: {
    name: '⚡ Rápido',
    filters: 'atempo=1.5'
  },
  demonio: {
    name: '😈 Demonio',
    filters: 'asetrate=44100*0.5,aresample=44100,atempo=1.0'
  },
  alien: {
    name: '👽 Alien',
    filters: 'asetrate=44100*1.8,aresample=44100,atempo=1.0,vibrato=f=10:d=0.8'
  },
  chipmunk: {
    name: '🐹 Chipmunk',
    filters: 'asetrate=44100*2,aresample=44100'
  },
  distorsion: {
    name: '🎸 Distorsión',
    filters: 'asetrate=44100,aresample=44100,aphaser=in_gain=0.4'
  },
  bajo: {
    name: '🎺 Bajo Aumentado',
    filters: 'bass=g=10'
  },
  agudo: {
    name: '🎻 Agudos Aumentados',
    filters: 'treble=g=10'
  }
};

async function applyAudioEffect(audioBuffer, effectName) {
  const inputPath = tmpFileName('ogg');
  const outputPath = tmpFileName('opus');

  try {
    console.log(`🎛️ Aplicando efecto: ${effectName}...`);
    
    // Guardar audio de entrada
    await fs.writeFile(inputPath, audioBuffer);

    const effect = audioEffects[effectName];
    
    if (!effect) {
      throw new Error(`Efecto "${effectName}" no encontrado`);
    }

    // Construir comando FFmpeg con formato Opus compatible con WhatsApp
    const args = [
      '-y',
      '-i', inputPath,
      '-af', effect.filters,
      '-ar', '48000',        // WhatsApp usa 48kHz para Opus
      '-ac', '1',            // Mono (WhatsApp prefiere mono)
      '-c:a', 'libopus',     // Codec Opus
      '-b:a', '64k',         // Bitrate para WhatsApp
      '-vbr', 'on',          // Variable bitrate
      '-compression_level', '10',
      '-f', 'opus',          // Formato Opus
      outputPath
    ];

    console.log('🔧 Ejecutando FFmpeg con filtros:', effect.filters);

    await execFileAsync('ffmpeg', args, { 
      windowsHide: true, 
      timeout: 60_000 // 60 segundos máximo
    });

    const outputBuffer = await fs.readFile(outputPath);
    console.log('✅ Efecto aplicado correctamente, tamaño:', outputBuffer.length);
    
    return outputBuffer;
  } catch (error) {
    console.error('❌ Error aplicando efecto:', error);
    throw error;
  } finally {
    // Limpiar archivos temporales
    Promise.allSettled([
      fs.unlink(inputPath).catch(() => {}),
      fs.unlink(outputPath).catch(() => {})
    ]);
  }
}

async function sendAudio(sock, jid, audioBuffer, isPTT = false) {
  try {
    console.log('📤 Enviando audio...');
    
    const message = {
      audio: audioBuffer,
      mimetype: 'audio/ogg; codecs=opus',  // Formato correcto para WhatsApp
      ptt: isPTT // Si era nota de voz, mantenerlo como nota de voz
    };

    await sock.sendMessage(jid, message);
    console.log('✅ Audio enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar audio:', error);
    return false;
  }
}

function getEffectsList() {
  let list = '*🎛️ EFECTOS DE AUDIO DISPONIBLES*\n\n';
  for (const [key, value] of Object.entries(audioEffects)) {
    list += `• *.efecto ${key}* - ${value.name}\n`;
  }
  list += '\n💡 *Uso:* Responde a un audio con *.efecto [nombre]*\n';
  list += '📝 *Ejemplo:* .efecto robot';
  return list;
}

// Handler principal
let handler = async (message, { text, args }) => {
  try {
    console.log('🚀 Iniciando comando efecto...');
    const sock = global.conn;
    
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // Si no hay argumentos, mostrar lista de efectos
    if (!args || args.length === 0) {
      return await message.reply(getEffectsList());
    }

    const effectName = args[0].toLowerCase();

    // Verificar si el efecto existe
    if (!audioEffects[effectName]) {
      return await message.reply(
        `❌ Efecto *"${effectName}"* no encontrado.\n\n` +
        `Usa *.efecto* sin argumentos para ver la lista de efectos disponibles.`
      );
    }

    // Buscar audio citado
    console.log('📁 Buscando audio citado...');
    const quotedAudio = await detectQuotedAudio();

    if (!quotedAudio) {
      return await message.reply(
        '❌ Debes *responder a un audio o nota de voz* para aplicar el efecto.\n\n' +
        `💡 *Ejemplo:* Responde a un audio con *.efecto ${effectName}*`
      );
    }

    console.log('✅ Audio encontrado, procesando...');
    
    // Mensaje de espera
    const effect = audioEffects[effectName];
    await message.reply(`⏳ Aplicando efecto *${effect.name}*...\n\n_Esto puede tardar unos segundos..._`);

    // Aplicar efecto
    const processedAudio = await applyAudioEffect(quotedAudio.data, effectName);

    if (!processedAudio) {
      return await message.reply('❌ Error al procesar el audio con el efecto.');
    }

    // Enviar audio procesado (mantener si era PTT o no)
    const success = await sendAudio(sock, message.from, processedAudio, quotedAudio.ptt);

    if (!success) {
      return await message.reply('❌ Error al enviar el audio procesado.');
    }

    console.log('🎉 Efecto aplicado y enviado exitosamente');

  } catch (error) {
    console.error('❌ Error general en handler efecto:', error);
    console.error('❌ Stack:', error.stack);
    
    let errorMsg = '❌ Ocurrió un error al aplicar el efecto de audio.';
    
    if (error.message && error.message.includes('ffmpeg')) {
      errorMsg += '\n\n⚠️ Asegúrate de tener *FFmpeg* instalado en tu sistema.';
    }
    
    if (error.message && (error.message.includes('ENOENT') || error.message.includes('spawn'))) {
      errorMsg += '\n\n⚠️ FFmpeg no está instalado o no se encuentra en el PATH.\nInstala FFmpeg con: `apt install ffmpeg`';
    }
    
    await message.reply(errorMsg);
  }
};

// --- Configuración del Handler ---
handler.help = ['efecto'];
handler.tags = ['audio'];
handler.command = /^(efecto|effect|fx)$/i;

module.exports = handler;