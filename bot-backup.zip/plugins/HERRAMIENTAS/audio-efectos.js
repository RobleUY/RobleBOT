/**
 * Comando: efecto
 * Descripción: Aplica efectos de audio a mensajes de voz o audio de forma optimizada
 * Uso: Responde a un audio con .efecto [nombre_efecto]
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs').promises;
const { createWriteStream } = require('fs');
const { pipeline } = require('stream/promises');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

// --- CONTROL DE SATURACIÓN ---
// Límite de cuántos audios se pueden procesar al mismo tiempo para no congelar el bot
const MAX_CONCURRENT = 3; 
let activeProcesses = 0;

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

// OPTIMIZACIÓN: Descarga el stream directamente a un archivo temporal para no saturar la RAM
async function downloadAudioToFile(outputPath) {
  try {
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    let contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo || 
                      baileyMsg.message?.audioMessage?.contextInfo;

    if (!contextInfo?.quotedMessage?.audioMessage) return null;

    const audioMessage = contextInfo.quotedMessage.audioMessage;
    
    // Iniciar descarga del stream
    const stream = await downloadContentFromMessage(audioMessage, 'audio');
    
    // Escribir directamente al disco duro de forma eficiente
    await pipeline(stream, createWriteStream(outputPath));

    return {
      mimetype: audioMessage.mimetype || 'audio/ogg; codecs=opus',
      type: 'audio',
      ptt: audioMessage.ptt || false
    };
  } catch (error) {
    console.error('❌ Error descargando audio al archivo:', error);
    return null;
  }
}

// Definición de efectos de audio
const audioEffects = {
  robot: { name: '🤖 Robot', filters: 'afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75' },
  ardilla: { name: '🐿️ Ardilla', filters: 'asetrate=44100*1.5,aresample=44100,atempo=1.0' },
  grave: { name: '🔉 Grave', filters: 'asetrate=44100*0.7,aresample=44100,atempo=1.0' },
  reverb: { name: '🎭 Reverb', filters: 'aecho=0.8:0.88:60:0.4' },
  eco: { name: '📢 Eco', filters: 'aecho=0.8:0.9:1000:0.3' },
  nightcore: { name: '🌙 Nightcore', filters: 'asetrate=44100*1.25,aresample=44100' },
  lento: { name: '🐌 Lento', filters: 'atempo=0.7' },
  rapido: { name: '⚡ Rápido', filters: 'atempo=1.5' },
  demonio: { name: '😈 Demonio', filters: 'asetrate=44100*0.5,aresample=44100,atempo=1.0' },
  alien: { name: '👽 Alien', filters: 'asetrate=44100*1.8,aresample=44100,atempo=1.0,vibrato=f=10:d=0.8' },
  chipmunk: { name: '🐹 Chipmunk', filters: 'asetrate=44100*2,aresample=44100' },
  distorsion: { name: '🎸 Distorsión', filters: 'asetrate=44100,aresample=44100,aphaser=in_gain=0.4' },
  bajo: { name: '🎺 Bajo', filters: 'bass=g=10' },
  agudo: { name: '🎻 Agudos', filters: 'treble=g=10' }
};

async function applyAudioEffect(inputPath, effectName) {
  const outputPath = tmpFileName('opus');

  try {
    const effect = audioEffects[effectName];
    
    // OPTIMIZACIÓN: Se agregó -threads 1 para evitar que FFmpeg consuma todo el procesador
    const args = [
      '-y',
      '-threads', '1',       
      '-i', inputPath,
      '-af', effect.filters,
      '-ar', '48000',        
      '-ac', '1',            
      '-c:a', 'libopus',     
      '-b:a', '64k',         
      '-vbr', 'on',          
      '-compression_level', '10',
      '-f', 'opus',          
      outputPath
    ];

    // Timeout ajustado a 45 segundos para matar procesos rebeldes
    await execFileAsync('ffmpeg', args, { 
      windowsHide: true, 
      timeout: 45_000 
    });

    const outputBuffer = await fs.readFile(outputPath);
    return outputBuffer;
  } finally {
    // Asegurar limpieza del archivo de salida
    await fs.unlink(outputPath).catch(() => {});
  }
}

function getEffectsList() {
  let list = '*🎛️ EFECTOS DE AUDIO DISPONIBLES*\n\n';
  for (const [key, value] of Object.entries(audioEffects)) {
    list += `• *.efecto ${key}* - ${value.name}\n`;
  }
  list += '\n💡 *Uso:* Responde a un audio con *.efecto [nombre]*\n';
  list += '📝 *Ejemplo:* .efecto robot';
  return list;
}

// Handler principal
let handler = async (message, { text, args }) => {
  const sock = global.conn;
  let inputPath = null;

  try {
    if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

    if (!args || args.length === 0) {
      return await message.reply(getEffectsList());
    }

    const effectName = args[0].toLowerCase();
    if (!audioEffects[effectName]) {
      return await message.reply(`❌ Efecto *"${effectName}"* no encontrado.\nUsa *.efecto* para ver la lista.`);
    }

    // CONTROL DE CONCURRENCIA: Rechaza amablemente si el bot está procesando muchos audios
    if (activeProcesses >= MAX_CONCURRENT) {
      return await message.reply('⏳ *Servidor ocupado.* Estoy procesando otros audios en este momento. Por favor, intenta de nuevo en unos segundos.');
    }

    // Reservar un "espacio" en el procesador
    activeProcesses++;

    inputPath = tmpFileName('ogg');
    
    // Descarga optimizada
    const audioInfo = await downloadAudioToFile(inputPath);

    if (!audioInfo) {
      activeProcesses--; // Liberar espacio si falla temprano
      return await message.reply('❌ Debes *responder a un audio o nota de voz* para aplicar el efecto.');
    }
    
    await message.reply(`⏳ Aplicando efecto *${audioEffects[effectName].name}*...\n\n_Optimizando y procesando..._`);

    // Procesar audio
    const processedAudio = await applyAudioEffect(inputPath, effectName);

    // Enviar resultado
    await sock.sendMessage(message.from, {
      audio: processedAudio,
      mimetype: 'audio/ogg; codecs=opus',  
      ptt: audioInfo.ptt 
    });

  } catch (error) {
    console.error('❌ Error general en handler efecto:', error);
    let errorMsg = '❌ Ocurrió un error al procesar el audio.';
    if (error.message && error.message.includes('ffmpeg')) {
      errorMsg += '\n\n⚠️ Verifica que el audio no sea demasiado largo o pesado.';
    }
    await message.reply(errorMsg);
  } finally {
    // 🧹 LIMPIEZA GARANTIZADA: Disminuir procesos y borrar archivo original
    if (inputPath) await fs.unlink(inputPath).catch(() => {});
    if (activeProcesses > 0) activeProcesses--; 
  }
};

handler.help = ['efecto'];
handler.tags = ['audio'];
handler.command = /^(efecto|effect|fx)$/i;

module.exports = handler;