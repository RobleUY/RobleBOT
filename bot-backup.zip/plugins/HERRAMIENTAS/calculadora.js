/**
 * Calculadora - Plugin para RobleBOT
 * Permite realizar cálculos matemáticos básicos y avanzados
 */

const math = require('mathjs'); // Evaluación segura de expresiones

// Función principal para manejar los cálculos
async function handler(message, { text }) {
    if (!text) {
        return await message.reply(
            '❌ Por favor proporciona una expresión matemática.\n\n' +
            '📝 *Ejemplos:*\n' +
            '• .calc 2+2\n' +
            '• .calc 5*3-2\n' +
            '• .calc sin(45 deg)\n' +
            '• .calc 2^8\n' +
            '• .calc 10%3'
        );
    }

    try {
        const result = math.evaluate(text);
        let formattedResult;

        if (typeof result === 'number') {
            if (Math.abs(result) > 1e10 || (Math.abs(result) < 1e-10 && result !== 0)) {
                formattedResult = result.toExponential(6);
            } else {
                formattedResult = Number(result.toFixed(8)).toString();
            }
        } else {
            formattedResult = result.toString();
        }

        await message.reply(`🧮 *Resultado:*\n${text} = ${formattedResult}`);
    } catch (error) {
        await message.reply(
            `❌ Error: ${error.message || 'Expresión inválida'}\n\nAsegúrate de usar una expresión matemática válida.`
        );
    }
}

// Asignamos propiedades compatibles con tu handler.js
handler.command = /^(calc|calculadora|math)$/i;
handler.help = ['calc [expresión] - Calculadora matemática'];
handler.tags = ['utilidades', 'matemáticas'];

// Exportamos la función principal directamente
module.exports = handler;
