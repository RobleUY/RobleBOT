const axios = require('axios');

/**
 * 🔑 API Keys de Klipy (en orden de prioridad).
 * Si la primera falla o no devuelve resultados, se prueba con la siguiente.
 * Conseguí más keys en: https://partner.klipy.com/api-keys
 */
const KLIPY_API_KEYS = [
  'VbYdj6L0B30rUXIisnilRoBbapmOEZKaQMT6ONFBsZ9QXUlA7Yph0FaEFyvIIh79',
  'b4wVNTCmDSmSBWPIhvB512E0dhYZjTIuTPdzNVnqpqoc4Agyk8XrhzzE3zgp4gYD',
  'BTeDDOybI5M2aJ2YVbGm1K0IFj50Z2zyquUEa4KRLD5GHthel3CSXEI3HDrYVcf8',
];

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de búsqueda en Klipy (endpoint de GIFs) para una API key específica
 */
function buildKlipyGifSearchUrl(apiKey, query, customerId) {
  const baseUrl = `https://api.klipy.com/api/v1/${apiKey}/gifs/search`;
  const params = new URLSearchParams({
    q: query,
    customer_id: customerId || 'roblebot-default',
    per_page: '24',
    page: '1'
  });
  return `${baseUrl}?${params.toString()}`;
}

/**
 * Busca recursivamente dentro de un objeto una URL de medio utilizable
 * (mp4, webp o gif). Klipy anida los formatos dentro de "file", pero la
 * estructura exacta puede variar según el tipo de contenido, así que
 * revisamos de forma defensiva.
 */
function extractMediaUrl(item) {
  if (!item || typeof item !== 'object') return null;

  // Rutas más comunes en la respuesta de Klipy
  const candidatePaths = [
    item?.file?.md?.mp4?.url,
    item?.file?.md?.gif?.url,
    item?.file?.md?.webp?.url,
    item?.file?.hd?.mp4?.url,
    item?.file?.hd?.gif?.url,
    item?.file?.sm?.mp4?.url,
    item?.file?.sm?.gif?.url,
    item?.file?.url,
    item?.file?.mp4,
    item?.file?.gif,
    item?.url,
    item?.mp4,
    item?.gif
  ];

  for (const candidate of candidatePaths) {
    if (typeof candidate === 'string' && candidate.startsWith('http')) {
      return candidate;
    }
  }

  // Fallback: recorrer todo el objeto buscando cualquier string que
  // parezca una URL de mp4/gif/webp
  const stack = [item];
  const seen = new Set();
  while (stack.length) {
    const current = stack.pop();
    if (!current || typeof current !== 'object' || seen.has(current)) continue;
    seen.add(current);

    for (const value of Object.values(current)) {
      if (typeof value === 'string' && value.startsWith('http') &&
          /\.(mp4|gif|webp)(\?|$)/i.test(value)) {
        return value;
      } else if (value && typeof value === 'object') {
        stack.push(value);
      }
    }
  }

  return null;
}

/**
 * Busca gifs en Klipy probando cada API key disponible hasta
 * conseguir un resultado válido. Devuelve un resultado aleatorio.
 */
async function searchKlipyGifs(query, customerId) {
  for (const apiKey of KLIPY_API_KEYS) {
    try {
      const searchUrl = buildKlipyGifSearchUrl(apiKey, query, customerId);

      const response = await axios.get(searchUrl, {
        timeout: 15000
      });

      // Validar estructura básica de la respuesta de Klipy
      // Formato esperado: { result: true, data: { data: [...] } }
      const items = response?.data?.data?.data;

      if (!response.data || !response.data.result || !Array.isArray(items) || items.length === 0) {
        console.warn(`⚠️ API key de Klipy sin resultados, probando siguiente...`);
        continue;
      }

      // Filtrar solo los ítems de los que podamos extraer una URL de medio
      const validResults = items
        .map(item => ({ item, mediaUrl: extractMediaUrl(item) }))
        .filter(entry => entry.mediaUrl);

      if (validResults.length === 0) {
        console.warn(`⚠️ API key de Klipy no devolvió URLs utilizables, probando siguiente...`);
        continue;
      }

      // Seleccionar uno aleatorio de la lista final
      const randomIndex = Math.floor(Math.random() * validResults.length);
      const selected = validResults[randomIndex];

      return {
        ...selected.item,
        mp4: selected.mediaUrl
      };

    } catch (error) {
      console.error(`❌ Error de conexión con la API de Klipy (key probada): ${error.message}`);
      // Continúa con la siguiente key del array
      continue;
    }
  }

  // Si ninguna key funcionó
  return null;
}

/**
 * Descarga el video o gif desde Klipy
 */
async function downloadKlipyMedia(mediaUrl) {
  try {
    const response = await axios.get(mediaUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    return Buffer.from(response.data);
  } catch (error) {
    console.error('❌ Error al descargar el archivo multimedia:', error.message);
    return null;
  }
}

/**
 * Envía el gif (como video con gifPlayback para que WhatsApp lo reproduzca en loop)
 */
async function sendKlipyGif(sock, jid, mediaBuffer, options = {}) {
  try {
    if (!mediaBuffer || !(mediaBuffer instanceof Buffer)) {
      throw new Error('Buffer multimedia no válido.');
    }

    await sock.sendMessage(jid, {
      video: mediaBuffer,
      gifPlayback: true,
      caption: options.caption || ''
    }, options.quoted ? { quoted: options.quoted } : {});

    return true;
  } catch (error) {
    console.error('❌ Error al enviar el gif:', error.message);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `🔍 *Buscar GIFs en Klipy*\n\n` +
        `📌 *Uso:*\n` +
        `• /gif gatos graciosos\n` +
        `✨ *Busca y envía videos/gifs de Klipy directamente*\n`
      );
    }

    // Mensaje 1: Avisar que empezó la búsqueda
    await message.reply('🔍 *Buscando gif...* ⏳');

    // customer_id único, requerido por Klipy para identificar al usuario
    const botNumber = getBotNumber(sock);
    const customerId = message.sender
      ? message.sender.replace(/[^0-9]/g, '')
      : (botNumber || 'roblebot-default');

    // Buscar en la API (probando todas las keys disponibles)
    const gifResult = await searchKlipyGifs(text, customerId);
    if (!gifResult) {
      return await message.reply(
        '❌ No se encontraron resultados.\n' +
        '💡 Intenta de nuevo o prueba con términos en inglés (ej: *funny cat*, *meme*).'
      );
    }

    // Descargar el archivo
    const mediaBuffer = await downloadKlipyMedia(gifResult.mp4);
    if (!mediaBuffer) {
      return await message.reply(
        '❌ No se pudo descargar el archivo de Klipy.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    // Enviar como Mensaje 2 (GIF)
    const success = await sendKlipyGif(sock, message.from, mediaBuffer, {
      quoted: message._baileyMessage
    });

    if (!success) {
      await message.reply('⚠️ No se pudo enviar el gif.');
    }

  } catch (error) {
    await message.reply('❌ Error inesperado al buscar el gif.');
  }
};

handler.help = ['gif <búsqueda>', 'gifs <búsqueda>', 'sgif <búsqueda>', 'gifsearch <búsqueda>'];
handler.tags = ['sticker'];
handler.command = /^(gif|gifs|sgif|gifsearch)$/i;

module.exports = handler;