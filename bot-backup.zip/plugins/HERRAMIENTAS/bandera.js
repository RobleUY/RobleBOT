const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CACHE_FILE = path.join(__dirname, 'data', 'info-banderas.json');

const LABELS = {
    sovereignState:  'Estado soberano',
    countryCodes:    'Códigos de país',
    officialName:    'Nombre oficial',
    capitalCity:     'Capital',
    continent:       'Continente',
    memberOf:        'Miembro de',
    population:      'Población',
    area:            'Área',
    highestPoint:    'Punto más alto',
    lowestPoint:     'Punto más bajo',
    gdpPerCapita:    'PIB per cápita',
    currency:        'Moneda',
    callingCode:     'Código de llamada',
    internetTld:     'TLD de internet',
};

const CAMPOS_ORDEN = [
    'officialName', 'capitalCity', 'continent', 'countryCodes',
    'sovereignState', 'population', 'area', 'highestPoint', 'lowestPoint',
    'gdpPerCapita', 'currency', 'callingCode', 'internetTld', 'memberOf'
];

// ── Caché en disco ──────────────────────────────────────────
function loadCache() {
    try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); }
    catch { return {}; }
}

function saveCache(data) {
    try { fs.writeFileSync(CACHE_FILE, JSON.stringify(data, null, 2), 'utf8'); }
    catch (e) { console.error('[bandera] Error guardando caché:', e.message); }
}

// ── Traducción via Delirius ─────────────────────────────────
async function traducir(texto, idioma = 'es') {
    if (!texto || !texto.trim()) return texto;
    try {
        const res = await axios.get(
            `https://api.delirius.online/tools/translate?text=${encodeURIComponent(texto)}&language=${idioma}`,
            { timeout: 10000 }
        );
        return res.data?.data || texto;
    } catch {
        return texto;
    }
}

// ── Construir mensaje desde entrada de caché ────────────────
function construirMensaje(entrada) {
    let info = '';
    for (const key of CAMPOS_ORDEN) {
        if (entrada.campos[key]) {
            info += `• *${LABELS[key]}:* ${entrada.campos[key]}\n`;
        }
    }
    return (
        `🏳️ *${entrada.campos.officialName || entrada.queryOriginal}*\n\n${info}` +
        (entrada.descripcion ? `\n📖 *Descripción:*\n${entrada.descripcion}` : '')
    );
}

// ── Enviar respuesta (imagen + texto) ──────────────────────
async function enviarRespuesta(sock, message, entrada) {
    const mensaje = construirMensaje(entrada);
    if (entrada.imageUrl) {
        try {
            const imgRes = await axios.get(entrada.imageUrl, { responseType: 'arraybuffer', timeout: 10000 });
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgRes.data),
                caption: mensaje
            }, { quoted: message._baileyMessage });
        } catch { /* si falla la imagen, cae al texto */ }
    }
    await message.reply(mensaje);
}

// ── Handler ─────────────────────────────────────────────────
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text || !text.trim()) {
            return await message.reply('🌍 *Uso correcto:*\n.bandera <país>\n\nEjemplo: .bandera uruguay');
        }

        const queryOriginal = text.trim().toLowerCase();
        const cache = loadCache();

        // ✅ Hit de caché — buscar por clave original (español) o por clave en inglés
        // El JSON guarda cada entrada con DOS claves: la original y la traducida al inglés
        if (cache[queryOriginal]) {
            return await enviarRespuesta(sock, message, cache[queryOriginal]);
        }

        // 🌐 No está en caché — primero traducir el nombre al inglés para la API
        await message.reply('🔍 Buscando información...');

        const queryEN = (await traducir(text.trim(), 'en')).trim().toLowerCase();

        // Si ya existe con clave en inglés (otro usuario lo pidió en inglés antes)
        if (cache[queryEN]) {
            // Guardar también con clave original para futuros hits
            cache[queryOriginal] = cache[queryEN];
            saveCache(cache);
            return await enviarRespuesta(sock, message, cache[queryEN]);
        }

        // Consultar la API con el nombre en inglés
        const res = await axios.get(
            `https://api.delirius.online/tools/flaginfo?query=${encodeURIComponent(queryEN)}`,
            { timeout: 12000 }
        );

        if (!res.data?.status || !res.data?.data) {
            return await message.reply('❌ No se encontró información para ese país. Verificá el nombre e intentá de nuevo.');
        }

        const d = res.data.data;

        // Traducir todos los campos + descripción al español en paralelo
        const aTraducir = CAMPOS_ORDEN.filter(k => d[k]).map(k => ({ key: k, original: d[k] }));

        const [valoresTraducidos, descripcionTraducida] = await Promise.all([
            Promise.all(aTraducir.map(item => traducir(item.original, 'es'))),
            d.description ? traducir(d.description, 'es') : Promise.resolve(null)
        ]);

        const camposTraducidos = {};
        for (let i = 0; i < aTraducir.length; i++) {
            camposTraducidos[aTraducir[i].key] = valoresTraducidos[i];
        }

        const entrada = {
            queryOriginal,
            imageUrl: d.image || null,
            campos: camposTraducidos,
            descripcion: descripcionTraducida || null,
            cachedAt: new Date().toISOString()
        };

        // Guardar con ambas claves: la original (español) y la traducida (inglés)
        cache[queryOriginal] = entrada;
        if (queryEN !== queryOriginal) cache[queryEN] = entrada;
        saveCache(cache);

        await enviarRespuesta(sock, message, entrada);

    } catch (error) {
        console.error('[bandera] Error:', error.message);
        await message.reply('❌ No se pudo obtener la información. Verificá el nombre del país e intentá de nuevo.');
    }
};

handler.help = ['bandera <país>', 'flag <país>'];
handler.tags = ['herramientas', 'info'];
handler.command = /^(bandera|flag)$/i;

module.exports = handler;
