// story.js
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

/**
 * Convierte stream a buffer
 */
async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * Obtiene la lista de contactos/JIDs para el statusJidList
 * Baileys REQUIERE esta lista para que el estado sea visible
 */
async function getStatusJidList(sock) {
  try {
    // Método 1: obtener desde el store de contactos si existe
    if (sock.store?.contacts) {
      const contacts = Object.keys(sock.store.contacts).filter(jid =>
        jid.endsWith('@s.whatsapp.net')
      );
      if (contacts.length > 0) {
        console.log(`📋 Contactos del store: ${contacts.length}`);
        return contacts;
      }
    }

    // Método 2: obtener desde el store global si existe
    if (global.store?.contacts) {
      const contacts = Object.keys(global.store.contacts).filter(jid =>
        jid.endsWith('@s.whatsapp.net')
      );
      if (contacts.length > 0) {
        console.log(`📋 Contactos del store global: ${contacts.length}`);
        return contacts;
      }
    }

    // Método 3: extraer participantes de todos los grupos
    if (typeof sock.groupFetchAllParticipating === 'function') {
      try {
        const groups = await sock.groupFetchAllParticipating();
        const jids = new Set();
        for (const group of Object.values(groups)) {
          for (const participant of (group.participants || [])) {
            const jid = participant.id || participant;
            if (jid && jid.endsWith('@s.whatsapp.net')) {
              jids.add(jid);
            }
          }
        }
        if (jids.size > 0) {
          console.log(`📋 JIDs de grupos: ${jids.size}`);
          return Array.from(jids);
        }
      } catch (e) {
        console.warn('⚠️ No se pudo obtener grupos:', e.message);
      }
    }

    // Fallback: lista vacía (el estado igual se sube para el propio bot)
    console.warn('⚠️ No se encontraron contactos, usando lista vacía');
    return [];
  } catch (error) {
    console.error('❌ Error obteniendo statusJidList:', error);
    return [];
  }
}

/**
 * Detecta media en el mensaje actual
 */
async function detectCurrentMedia() {
  try {
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    if (baileyMsg.message?.imageMessage) {
      const stream = await downloadContentFromMessage(baileyMsg.message.imageMessage, 'image');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: baileyMsg.message.imageMessage.mimetype || 'image/jpeg',
        type: 'image',
        caption: baileyMsg.message.imageMessage.caption || ''
      };
    }

    if (baileyMsg.message?.videoMessage) {
      const isGif = !!baileyMsg.message.videoMessage.gifPlayback;
      const stream = await downloadContentFromMessage(baileyMsg.message.videoMessage, 'video');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: baileyMsg.message.videoMessage.mimetype || 'video/mp4',
        type: isGif ? 'gif' : 'video',
        caption: baileyMsg.message.videoMessage.caption || ''
      };
    }

    return null;
  } catch (error) {
    console.error('❌ Error en detectCurrentMedia (story):', error);
    return null;
  }
}

/**
 * Detecta media citada (respondiendo a un mensaje anterior)
 */
async function detectQuotedMedia() {
  try {
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.imageMessage?.contextInfo) {
      contextInfo = baileyMsg.message.imageMessage.contextInfo;
    } else if (baileyMsg.message?.videoMessage?.contextInfo) {
      contextInfo = baileyMsg.message.videoMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) return null;

    const quotedMessage = contextInfo.quotedMessage;

    if (quotedMessage.imageMessage) {
      const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg',
        type: 'image',
        caption: quotedMessage.imageMessage.caption || ''
      };
    }

    if (quotedMessage.videoMessage) {
      const isGif = !!quotedMessage.videoMessage.gifPlayback;
      const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
      const buffer = await streamToBuffer(stream);
      return {
        data: buffer,
        mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4',
        type: isGif ? 'gif' : 'video',
        caption: quotedMessage.videoMessage.caption || ''
      };
    }

    return null;
  } catch (error) {
    console.error('❌ Error en detectQuotedMedia (story):', error);
    return null;
  }
}

/**
 * Sube imagen o video al estado
 * CLAVE: statusJidList y broadcast van en el TERCER argumento (opciones), NO en el contenido
 */
async function sendMediaStory(sock, mediaBuffer, mediaType, caption, statusJidList) {
  try {
    // Segundo argumento: solo el contenido del mensaje
    const content = mediaType === 'image'
      ? { image: mediaBuffer, caption }
      : { video: mediaBuffer, caption, gifPlayback: mediaType === 'gif' };

    // Tercer argumento: opciones de broadcast (separado del contenido)
    const options = {
      backgroundColor: '#000000',
      font: 0,
      statusJidList,
      broadcast: true
    };

    await sock.sendMessage('status@broadcast', content, options);
    return true;
  } catch (error) {
    console.error('❌ Error enviando story multimedia:', error);
    throw error;
  }
}

/**
 * Sube texto al estado
 * CLAVE: statusJidList y broadcast van en el TERCER argumento (opciones), NO en el contenido
 */
async function sendTextStory(sock, text, statusJidList) {
  try {
    const bgColors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4',
      '#FFEAA7', '#DDA0DD', '#F0A500', '#6C5CE7',
      '#00B894', '#E17055'
    ];
    const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];

    // Segundo argumento: solo el texto
    const content = { text };

    // Tercer argumento: opciones separadas del contenido
    const options = {
      backgroundColor: bgColor,
      font: 3,
      statusJidList,
      broadcast: true
    };

    await sock.sendMessage('status@broadcast', content, options);
    return { success: true, color: bgColor };
  } catch (error) {
    console.error('❌ Error enviando story de texto:', error);
    throw error;
  }
}

// ─── Handler principal ───────────────────────────────────────────────────────

let handler = async (message, { text, args, conn }) => {
  try {
    const sock = global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    console.log('📖 Iniciando comando .story...');

    const userText = text ? text.trim() : '';

    // Detectar media adjunta o citada
    let media = await detectCurrentMedia();
    if (!media) {
      media = await detectQuotedMedia();
    }

    // Sin media ni texto → mostrar ayuda
    if (!media && !userText) {
      return await message.reply(
        `📖 *COMANDO STORY*\n\n` +
        `Sube contenido al estado del bot principal.\n\n` +
        `📋 *Uso:*\n` +
        `• *.story <texto>* — Sube un estado de texto\n` +
        `  Ejemplo: \`.story Hola a todos!\`\n\n` +
        `• *Responde a una imagen/video/GIF* con *.story* — Sube ese medio como estado\n\n` +
        `• *Adjunta una imagen/video* con *.story* o *.story <caption>* como caption\n\n` +
        `⚠️ Solo el owner puede usar este comando.`
      );
    }

    // Obtener lista de contactos (necesario para que WA muestre el estado)
    console.log('📋 Obteniendo lista de contactos para statusJidList...');
    const statusJidList = await getStatusJidList(sock);
    console.log(`✅ statusJidList con ${statusJidList.length} contactos`);

    // ── Caso: Media encontrada ──────────────────────────────────────────────
    if (media) {
      console.log(`✅ Media detectada: ${media.type} — subiendo al estado...`);
      const caption = userText || media.caption || '';

      try {
        await sendMediaStory(sock, media.data, media.type, caption, statusJidList);
        await message.reply(
          `✅ *Story publicado correctamente*\n\n` +
          `📁 Tipo: ${media.type.toUpperCase()}\n` +
          (caption ? `💬 Caption: ${caption}\n` : '') +
          `👥 Enviado a: ${statusJidList.length} contactos\n\n` +
          `🟢 El estado ya está visible en el bot principal.`
        );
      } catch (err) {
        console.error('❌ Error al subir story multimedia:', err);
        await message.reply(`❌ No se pudo publicar el story. Error: ${err.message || 'desconocido'}`);
      }

      return;
    }

    // ── Caso: Solo texto ────────────────────────────────────────────────────
    if (userText.length > 700) {
      return await message.reply('⚠️ El texto es muy largo. Máximo 700 caracteres para un story de texto.');
    }

    console.log(`📝 Story de texto: "${userText}"`);

    try {
      const result = await sendTextStory(sock, userText, statusJidList);
      await message.reply(
        `✅ *Story de texto publicado*\n\n` +
        `💬 Texto: "${userText}"\n` +
        `🎨 Color: ${result.color}\n` +
        `👥 Enviado a: ${statusJidList.length} contactos\n\n` +
        `🟢 El estado ya está visible en el bot principal.`
      );
    } catch (err) {
      console.error('❌ Error al subir story de texto:', err);
      await message.reply(`❌ No se pudo publicar el story de texto. Error: ${err.message || 'desconocido'}`);
    }

  } catch (error) {
    console.error('❌ Error general en handler story:', error);
    await message.reply('❌ Ocurrió un error al publicar el story.');
  }
};

handler.help = ['story'];
handler.tags = ['owner'];
handler.command = /^story$/i;
handler.owner = true;

module.exports = handler;