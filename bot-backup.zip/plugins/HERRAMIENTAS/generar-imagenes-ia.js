const axios = require('axios');

const SANKA_API_KEYS = ['planaai'];
const imageCache = new Map();

async function generarImagenAI(prompt, keyIndex = 0, ratio = '1:1') {
    const cacheKey = `${prompt}|${ratio}`;
    if (imageCache.has(cacheKey)) return imageCache.get(cacheKey);

    if (keyIndex >= SANKA_API_KEYS.length) return null;

    const apiKey = SANKA_API_KEYS[keyIndex];
    const url = `https://www.sankavollerei.com/ai/ai4chat?apikey=${apiKey}&prompt=${encodeURIComponent(prompt)}&ratio=${encodeURIComponent(ratio)}`;

    try {
        // Esta API devuelve la imagen directamente como binario
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data, 'binary');

        imageCache.set(cacheKey, imageBuffer);
        return imageBuffer;

    } catch (error) {
        console.warn(`Error con la clave actual (${apiKey}), intentando siguiente si existe...`);
        return keyIndex + 1 < SANKA_API_KEYS.length
            ? generarImagenAI(prompt, keyIndex + 1, ratio)
            : null;
    }
}

// Comando principal
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return await message.reply('❌ Proporciona un prompt. Ejemplo: .aiimagen un árbol con cara triste');

        let [prompt, ratio] = text.split('|').map(s => s.trim());
        ratio = ratio || '1:1'; // Ratio por defecto

        const imageBuffer = await generarImagenAI(prompt, 0, ratio);
        if (!imageBuffer) return await message.reply('❌ No se pudo generar la imagen. Intenta más tarde.');

        await sock.sendMessage(message.from, {
            image: imageBuffer,
            caption: `🤖 *RobleBOT AI*\n\n📝 *Prompt:*\n${prompt}\n🎨 *Ratio:* ${ratio}`
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en el comando AIImagen:', error);
        await message.reply('❌ Ocurrió un error al generar la imagen.');
    }
};

handler.help = ['aiimagen <prompt> | <ratio>'];
handler.tags = ['imagenes', 'ai'];
handler.command = /^(aiimagen|imagenia|iaimagen|imageai)$/i;

module.exports = handler;

