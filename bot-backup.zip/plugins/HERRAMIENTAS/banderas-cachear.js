const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CACHE_FILE = path.join(__dirname, 'data', 'info-banderas.json');

// Debe coincidir exactamente con los campos usados en .bandera
const CAMPOS_ORDEN = [
    'officialName', 'capitalCity', 'continent', 'countryCodes',
    'sovereignState', 'population', 'area', 'highestPoint', 'lowestPoint',
    'gdpPerCapita', 'currency', 'callingCode', 'internetTld', 'memberOf'
];

// Lista por defecto de países en inglés (nombres que la API de Delirius suele aceptar).
// Nota: usar "England" en vez de "United Kingdom" / "Inglaterra", como pediste.

// Todos los países hispanohablantes (oficial o mayoritario)
const PAISES_HISPANOS = [
    'Argentina', 'Bolivia', 'Chile', 'Colombia', 'Costa Rica', 'Cuba',
    'Dominican Republic', 'Ecuador', 'El Salvador', 'Equatorial Guinea',
    'Guatemala', 'Honduras', 'Mexico', 'Nicaragua', 'Panama', 'Paraguay',
    'Peru', 'Puerto Rico', 'Spain', 'Uruguay', 'Venezuela'
];

// Países "famosos" / muy consultados
const PAISES_FAMOSOS = [
    'United States', 'England', 'France', 'Germany', 'Italy', 'Portugal',
    'Russia', 'China', 'Japan', 'South Korea', 'North Korea', 'India',
    'Brazil', 'Canada', 'Australia'
];

const PAISES_DEFAULT = [...PAISES_HISPANOS, ...PAISES_FAMOSOS];

// ── Cache en disco ──────────────────────────────────────────
function loadCache() {
    try {
        return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
    } catch {
        return {};
    }
}

function saveCache(cache) {
    try {
        const dir = path.dirname(CACHE_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8');
    } catch (e) {
        console.error('[banderasall] Error guardando caché:', e.message);
    }
}

// ── Traducción via Delirius ─────────────────────────────────
async function traducir(texto) {
    if (!texto || !texto.trim()) return texto;
    try {
        const res = await axios.get(
            `https://api.delirius.online/tools/translate?text=${encodeURIComponent(texto)}&language=es`,
            { timeout: 10000 }
        );
        return res.data?.data || texto;
    } catch {
        return texto;
    }
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ── Consultar y guardar un país en el caché ─────────────────
async function procesarPais(pais, cache) {
    const query = pais.trim().toLowerCase();

    // Ya guardado, no tocamos nada
    if (cache[query]) {
        return { pais, status: 'skip' };
    }

    try {
        const res = await axios.get(
            `https://api.delirius.online/tools/flaginfo?query=${encodeURIComponent(query)}`,
            { timeout: 12000 }
        );

        if (!res.data?.status || !res.data?.data) {
            return { pais, status: 'notfound' };
        }

        const d = res.data.data;

        const aTraducir = CAMPOS_ORDEN.filter(k => d[k]).map(k => ({ key: k, original: d[k] }));

        const [valoresTraducidos, descripcionTraducida] = await Promise.all([
            Promise.all(aTraducir.map(item => traducir(item.original))),
            d.description ? traducir(d.description) : Promise.resolve(null)
        ]);

        const camposTraducidos = {};
        for (let i = 0; i < aTraducir.length; i++) {
            camposTraducidos[aTraducir[i].key] = valoresTraducidos[i];
        }

        cache[query] = {
            query,
            imageUrl: d.image || null,
            campos: camposTraducidos,
            descripcion: descripcionTraducida || null,
            cachedAt: new Date().toISOString()
        };

        return { pais, status: 'ok' };
    } catch (e) {
        return { pais, status: 'error', error: e.message };
    }
}

// ── Handler ─────────────────────────────────────────────────
let handler = async (message, { text }) => {
    try {
        // Permite pasar una lista custom separada por comas, o usa la lista default
        const listaPaises = text && text.trim()
            ? text.split(',').map(p => p.trim()).filter(Boolean)
            : PAISES_DEFAULT;

        const cache = loadCache();

        const yaEnCache = listaPaises.filter(p => cache[p.trim().toLowerCase()]).length;
        const porProcesar = listaPaises.length - yaEnCache;

        await message.reply(
            `🌍 *Precarga de banderas iniciada*\n\n` +
            `• Total en la lista: ${listaPaises.length}\n` +
            `• Ya en caché (se omiten): ${yaEnCache}\n` +
            `• A consultar: ${porProcesar}\n\n` +
            `_Esto puede tardar unos minutos, se procesan de a uno para no saturar la API..._`
        );

        const resultados = { ok: 0, skip: 0, notfound: 0, error: 0 };
        const fallidos = [];
        let procesados = 0;

        for (const pais of listaPaises) {
            const r = await procesarPais(pais, cache);
            resultados[r.status] = (resultados[r.status] || 0) + 1;
            if (r.status === 'notfound' || r.status === 'error') fallidos.push(r.pais);

            // Guardamos progresivamente por si algo falla a mitad de camino
            if (r.status === 'ok') saveCache(cache);

            procesados++;

            // Reporte de progreso cada 15 países procesados (no omitidos)
            if (r.status !== 'skip' && procesados % 15 === 0) {
                await message.reply(`⏳ Progreso: ${procesados}/${listaPaises.length} países revisados...`);
            }

            // Pequeña pausa solo cuando de verdad se consultó la API, para no saturarla
            if (r.status === 'ok' || r.status === 'notfound') {
                await delay(1500);
            }
        }

        saveCache(cache);

        let resumen =
            `✅ *Precarga finalizada*\n\n` +
            `• Guardados nuevos: ${resultados.ok || 0}\n` +
            `• Ya existían (omitidos): ${resultados.skip || 0}\n` +
            `• No encontrados: ${resultados.notfound || 0}\n` +
            `• Errores: ${resultados.error || 0}`;

        if (fallidos.length) {
            resumen += `\n\n⚠️ *Fallaron:* ${fallidos.join(', ')}`;
        }

        await message.reply(resumen);

    } catch (error) {
        console.error('[banderasall] Error:', error.message);
        await message.reply('❌ Ocurrió un error ejecutando la precarga de banderas.');
    }
};

handler.help = ['banderasall', 'banderasall <pais1, pais2, ...>'];
handler.tags = ['owner'];
handler.command = /^(banderasall|bandersall)$/i;
handler.owner = true;

module.exports = handler;