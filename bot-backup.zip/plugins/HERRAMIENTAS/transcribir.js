/**
 * Comando: vat
 * Descripción: Transcribe audios, videos o archivos de texto plano (mp3, wav, mp4, txt, etc.) usando la API de Gemini.
 * Uso: responde a un audio, video o archivo con .vat
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const execFileAsync = promisify(execFile);

/* --------------------------- CLAVES API GEMINI --------------------------- */
const apiKeys = [
  { key: "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE" },
  { key: "AIzaSyAqad2qjoPDpNWFQg20_3tMpt8CL_Pqw_A" },
  { key: "AIzaSyBkHDP5FNjQKuhR-aCbmVkj9Mc7_tHuK3A" },
  { key: "AIzaSyAfeiA7ww0eiY-8ukElr7iAahue7BMwaw0" }
];
function getRandomApiKey() {
  return apiKeys[Math.floor(Math.random() * apiKeys.length)].key;
}

/* --------------------------- FUNCIONES AUXILIARES --------------------------- */
function tmpFileName(ext = '') {
  return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : ''));
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
  return buffer;
}

async function detectQuotedFile() {
  const msg = global.lastBaileyMessage;
  if (!msg) return null;

  const context = msg.message?.extendedTextMessage?.contextInfo;
  if (!context?.quotedMessage) return null;

  const q = context.quotedMessage;
  let file = null;

  if (q.audioMessage) {
    const stream = await downloadContentFromMessage(q.audioMessage, 'audio');
    file = { data: await streamToBuffer(stream), mimetype: q.audioMessage.mimetype, type: 'audio' };
  } else if (q.videoMessage) {
    const stream = await downloadContentFromMessage(q.videoMessage, 'video');
    file = { data: await streamToBuffer(stream), mimetype: q.videoMessage.mimetype, type: 'video' };
  } else if (q.documentMessage) {
    const stream = await downloadContentFromMessage(q.documentMessage, 'document');
    file = {
      data: await streamToBuffer(stream),
      mimetype: q.documentMessage.mimetype,
      fileName: q.documentMessage.fileName,
      type: 'document'
    };
  }

  return file;
}

async function convertToWav(inputPath) {
  const output = tmpFileName('wav');
  await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-ar', '16000', '-ac', '1', output]);
  return output;
}

async function transcribeWithGemini(base64Audio) {
  const GEMINI_API_KEY = getRandomApiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;
  const prompt = "Transcribe en texto el siguiente audio o video, en español, sin inventar nada:";

  const res = await axios.post(url, {
    contents: [
      {
        parts: [
          { text: prompt },
          { inline_data: { mime_type: "audio/wav", data: base64Audio } }
        ]
      }
    ]
  }, { headers: { "Content-Type": "application/json" } });

  return res.data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message) => {
  try {
    const quoted = await detectQuotedFile();

    if (!quoted) {
      return message.reply(
        '*🎙️ TRANSCRIPCIÓN / LECTURA DE ARCHIVOS*\n\n' +
        'Responde a un archivo con:\n' +
        '• *.vat*\n\n' +
        'Funciona con:\n' +
        '🎧 Audios y notas de voz\n🎬 Videos (mp4, mov)\n📄 Archivos de texto (.txt, .json, .csv)\n\n' +
        'Ejemplo: responde a un audio o archivo con /leer'
      );
    }

    const loading = await message.reply('⏳ Procesando archivo...');

    const ext = quoted.fileName ? path.extname(quoted.fileName).toLowerCase().replace('.', '') : '';
    const tempFile = tmpFileName(ext || 'dat');
    await fs.writeFile(tempFile, quoted.data);

    let resultText = null;

    if (quoted.type === 'audio' || quoted.type === 'video') {
      const wav = await convertToWav(tempFile);
      const base64 = (await fs.readFile(wav)).toString('base64');
      resultText = await transcribeWithGemini(base64);
      await fs.unlink(wav).catch(() => {});
    } else if (quoted.type === 'document') {
      if (quoted.mimetype.startsWith('text/') || ['txt', 'json', 'csv', 'log'].includes(ext)) {
        resultText = await fs.readFile(tempFile, 'utf8');
      } else {
        return message.reply('❌ Solo se pueden leer archivos de texto plano (.txt, .json, .csv, etc.).');
      }
    }

    await fs.unlink(tempFile).catch(() => {});
    if (!resultText) return message.reply('❌ No se pudo obtener texto del archivo.');

    await message.reply(`📜 *Texto obtenido:*\n\n${resultText.trim()}`);
  } catch (err) {
    console.error('❌ Error en comando VAT:', err);
    await message.reply('❌ Ocurrió un error al procesar el archivo.');
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['vat'];
handler.tags = ['media', 'audio', 'document'];
handler.command = /^(vat|transcribir|leer|aat)$/i;

module.exports = handler;
