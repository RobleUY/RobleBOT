/**
 * Comando: removebg
 * Descripción: Remueve el fondo de una imagen usando API
 * Uso: Responde a una imagen con .removebg o adjúntala con el comando en el caption
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data'); // Asegúrate de que form-data esté instalado (`npm install form-data`)

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * 🆕 Detecta si el mensaje actual tiene una imagen adjunta (en el caption)
 * @returns {object|null}
 */
async function detectCurrentMedia() {
  try {
    console.log('🔍 Buscando imagen en el mensaje actual...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      return null;
    }

    // imageMessage
    if (baileyMsg.message?.imageMessage) {
      console.log('🖼️ Imagen detectada en el mensaje actual, descargando...');
      try {
        // Asegúrate de usar 'image' como tipo de descarga
        const stream = await downloadContentFromMessage(baileyMsg.message.imageMessage, 'image'); 
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: baileyMsg.message.imageMessage.mimetype || 'image/jpeg',
          type: 'image'
        };
      } catch (err) {
        console.error('❌ Error descargando imagen actual:', err);
        return null;
      }
    }

    return null;
  } catch (error) {
    console.error('❌ Error general en detectCurrentMedia:', error);
    return null;
  }
}

/**
 * Detecta medios citados (respondiendo a un mensaje anterior).
 * (Lógica existente para buscar imagen citada)
 * @returns {object|null}
 */
async function detectQuotedMedia() {
  try {
    console.log('🔍 Buscando imagen citada...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      return null;
    }

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.imageMessage?.contextInfo) {
      contextInfo = baileyMsg.message.imageMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) {
      return null;
    }

    const quotedMessage = contextInfo.quotedMessage;

    // imageMessage
    if (quotedMessage.imageMessage) {
      console.log('🖼️ Imagen citada detectada, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg',
          type: 'image'
        };
      } catch (err) {
        console.error('❌ Error descargando imagen citada:', err);
        return null;
      }
    }

    console.log('❌ Solo se soportan imágenes');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectQuotedMedia:', error);
    return null;
  }
}

async function uploadImageToHost(imageBuffer) {
  try {
    console.log('📤 Subiendo imagen a hosting temporal...');
    
    // Opción 1: Intentar con telegraph (más confiable)
    try {
      const form = new FormData();
      
      form.append('file', imageBuffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
      });

      const response = await axios.post('https://telegra.ph/upload', form, {
        headers: {
          ...form.getHeaders()
        },
        timeout: 30000
      });

      if (response.data && response.data[0] && response.data[0].src) {
        const imageUrl = 'https://telegra.ph' + response.data[0].src;
        console.log('✅ Imagen subida a Telegraph:', imageUrl);
        return imageUrl;
      }
    } catch (telegraphError) {
      console.log('⚠️ Telegraph falló, intentando con catbox...');
    }

    // Opción 2: Catbox como fallback
    const form = new FormData();
    
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', imageBuffer, {
      filename: 'image.jpg',
      contentType: 'image/jpeg'
    });

    const response = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders(),
      timeout: 30000
    });

    if (response.data && typeof response.data === 'string' && response.data.startsWith('http')) {
      console.log('✅ Imagen subida a Catbox:', response.data);
      return response.data;
    }

    console.error('❌ Error al subir imagen a ambos servicios');
    return null;
  } catch (error) {
    console.error('❌ Error en uploadImageToHost:', error.message);
    return null;
  }
}

async function removeBackground(imageUrl) {
  try {
    console.log('🌐 Llamando a la API para remover fondo...');
    
    const apiUrl = `https://www.sankavollerei.com/imagecreator/removebg?apikey=planaai&url=${encodeURIComponent(imageUrl)}`;
    
    // Paso 1: Obtener la URL de la imagen procesada desde la API
    const response = await axios.get(apiUrl, {
      timeout: 60000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (response.status === 200 && response.data) {
      let resultData = response.data;
      
      if (typeof resultData === 'string') {
        resultData = JSON.parse(resultData);
      }
      
      if (!resultData.status || !resultData.result) {
        console.error('❌ La API no devolvió una URL válida');
        return null;
      }
      
      const processedImageUrl = resultData.result;
      console.log('🔗 URL de imagen procesada:', processedImageUrl);
      
      // Paso 2: Descargar la imagen sin fondo desde la URL devuelta
      console.log('📥 Descargando imagen sin fondo...');
      const imageResponse = await axios.get(processedImageUrl, {
        responseType: 'arraybuffer',
        timeout: 60000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      if (imageResponse.status === 200 && imageResponse.data) {
        const imageBuffer = Buffer.from(imageResponse.data);
        if (imageBuffer.length < 1000) {
          console.error('❌ La imagen es demasiado pequeña (posible error)');
          return null;
        }
        
        return imageBuffer;
      }
      
      console.error('❌ Error al descargar la imagen procesada');
      return null;
    } else {
      console.error('❌ Error en respuesta de API:', response.status);
      return null;
    }
  } catch (error) {
    console.error('❌ Error en removeBackground:', error.message);
    if (error.response) {
      console.error('📄 Response status:', error.response.status);
    }
    return null;
  }
}

async function sendImage(sock, jid, imageBuffer, caption = '') {
  try {
    console.log('📤 Enviando imagen sin fondo...');
    
    await sock.sendMessage(jid, {
      image: imageBuffer,
      caption: caption,
      mimetype: 'image/png'
    });
    
    console.log('✅ Imagen enviada correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar imagen:', error);
    return false;
  }
}

// Handler principal
let handler = async (message, { text, args }) => {
  try {
    console.log('🚀 Iniciando comando removebg...');
    const sock = global.conn;
    
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // 1. 🆕 Buscar imagen en el *mensaje actual* (caption/adjunto)
    let quotedMedia = await detectCurrentMedia();

    // 2. Si no la encuentra, buscar imagen *citada* (respondiendo)
    if (!quotedMedia) {
        console.log('📁 Buscando imagen citada...');
        quotedMedia = await detectQuotedMedia();
    }

    if (!quotedMedia) {
      return await message.reply(
        '❌ *Adjunta o Responde a una imagen* con el comando */removebg* para remover su fondo.'
      );
    }

    if (quotedMedia.type !== 'image') {
      return await message.reply('❌ Este comando solo funciona con *imágenes*.');
    }

    console.log('✅ Imagen encontrada, procesando...');
    await message.reply('⏳ Removiendo el fondo de la imagen...');

    // Paso 1: Subir imagen a un hosting temporal para obtener URL pública
    const imageUrl = await uploadImageToHost(quotedMedia.data);
    
    if (!imageUrl) {
      return await message.reply('❌ Error al subir la imagen. Intenta nuevamente.');
    }

    // Paso 2: Remover fondo usando la API
    const imageWithoutBg = await removeBackground(imageUrl);

    if (!imageWithoutBg) {
      return await message.reply('❌ Error al remover el fondo de la imagen.\n\n⚠️ La API puede estar temporalmente no disponible o la imagen no es válida.');
    }

    // Paso 3: Enviar la imagen sin fondo al usuario
    const success = await sendImage(
      sock, 
      message.from, 
      imageWithoutBg, 
      `✅ *Fondo removido exitosamente*`
    );

    if (!success) {
      return await message.reply('❌ Error al enviar la imagen procesada.');
    }

  } catch (error) {
    console.error('❌ Error general en handler removebg:', error);
    await message.reply('❌ Ocurrió un error al remover el fondo de la imagen.');
  }
};

// --- Configuración del Handler ---
handler.help = ['removebg', 'nobg'];
handler.tags = ['tools'];
handler.command = /^(removebg|nobg|rmbg)$/i;

module.exports = handler;