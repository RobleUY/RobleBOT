const { parsePhoneNumberFromString, getCountries } = require('libphonenumber-js')

const allCountries = getCountries()

// Mapa completo: nombre en español y/o inglés -> código ISO
const countryAlpha = {
    // A
    "afganistán": "AF", "afghanistan": "AF",
    "albania": "AL",
    "alemania": "DE", "germany": "DE",
    "andorra": "AD",
    "angola": "AO",
    "anguila": "AI", "anguilla": "AI",
    "antigua y barbuda": "AG", "antigua and barbuda": "AG", "antigua": "AG",
    "arabia saudita": "SA", "arabia saudi": "SA", "saudi arabia": "SA",
    "argelia": "DZ", "algeria": "DZ",
    "argentina": "AR",
    "armenia": "AM",
    "aruba": "AW",
    "australia": "AU",
    "austria": "AT",
    "azerbaiyán": "AZ", "azerbaijan": "AZ",
    "ascensión": "AC", "ascension": "AC",
    "samoa americana": "AS", "american samoa": "AS",
    "islas åland": "AX", "aland islands": "AX",

    // B
    "bahamas": "BS",
    "bahrein": "BH", "bahrain": "BH",
    "bangladesh": "BD",
    "barbados": "BB",
    "bélgica": "BE", "belgica": "BE", "belgium": "BE",
    "belice": "BZ", "belize": "BZ",
    "benin": "BJ", "benín": "BJ",
    "bermudas": "BM", "bermuda": "BM",
    "bielorrusia": "BY", "belarus": "BY",
    "bolivia": "BO",
    "bosnia y herzegovina": "BA", "bosnia": "BA", "bosnia and herzegovina": "BA",
    "botsuana": "BW", "botswana": "BW",
    "brasil": "BR", "brazil": "BR",
    "brunéi": "BN", "brunei": "BN",
    "bulgaria": "BG",
    "burkina faso": "BF",
    "burundi": "BI",
    "bonaire": "BQ",
    "bhutan": "BT", "bután": "BT",
    "islas vírgenes británicas": "VG", "british virgin islands": "VG",

    // C
    "cabo verde": "CV", "cape verde": "CV",
    "camboya": "KH", "cambodia": "KH",
    "camerún": "CM", "cameroon": "CM",
    "canadá": "CA", "canada": "CA",
    "catar": "QA", "qatar": "QA",
    "chad": "TD",
    "chile": "CL",
    "china": "CN",
    "chipre": "CY", "cyprus": "CY",
    "colombia": "CO",
    "comoras": "KM", "comoros": "KM",
    "congo": "CG",
    "república democrática del congo": "CD", "democratic republic of the congo": "CD", "rd congo": "CD",
    "corea del norte": "KP", "north korea": "KP",
    "corea del sur": "KR", "south korea": "KR", "korea": "KR",
    "costa rica": "CR",
    "costa de marfil": "CI", "ivory coast": "CI", "côte d'ivoire": "CI",
    "croacia": "HR", "croatia": "HR",
    "cuba": "CU",
    "curazao": "CW", "curaçao": "CW", "curacao": "CW",
    "islas cocos": "CC", "cocos islands": "CC",
    "islas cook": "CK", "cook islands": "CK",
    "islas christmas": "CX", "christmas island": "CX",
    "república centroafricana": "CF", "central african republic": "CF",

    // D
    "dinamarca": "DK", "denmark": "DK",
    "dominica": "DM",
    "república dominicana": "DO", "dominican republic": "DO",
    "djibouti": "DJ", "yibuti": "DJ",

    // E
    "ecuador": "EC",
    "egipto": "EG", "egypt": "EG",
    "el salvador": "SV",
    "emiratos árabes unidos": "AE", "emiratos arabes unidos": "AE", "united arab emirates": "AE", "uae": "AE",
    "eritrea": "ER",
    "eslovaquia": "SK", "slovakia": "SK",
    "eslovenia": "SI", "slovenia": "SI",
    "españa": "ES", "espana": "ES", "spain": "ES",
    "estados unidos": "US", "united states": "US", "usa": "US", "eeuu": "US",
    "estonia": "EE",
    "etiopía": "ET", "etiopia": "ET", "ethiopia": "ET",
    "sahara occidental": "EH", "western sahara": "EH",

    // F
    "filipinas": "PH", "philippines": "PH",
    "finlandia": "FI", "finland": "FI",
    "fiyi": "FJ", "fiji": "FJ",
    "francia": "FR", "france": "FR",
    "islas malvinas": "FK", "falkland islands": "FK",
    "islas feroe": "FO", "faroe islands": "FO",
    "micronesia": "FM",
    "guayana francesa": "GF", "french guiana": "GF",
    "polinesia francesa": "PF", "french polynesia": "PF",

    // G
    "gabón": "GA", "gabon": "GA",
    "gambia": "GM",
    "georgia": "GE",
    "ghana": "GH",
    "gibraltar": "GI",
    "granada": "GD", "grenada": "GD",
    "grecia": "GR", "greece": "GR",
    "groenlandia": "GL", "greenland": "GL",
    "guadalupe": "GP", "guadeloupe": "GP",
    "guam": "GU",
    "guatemala": "GT",
    "guernsey": "GG",
    "guinea": "GN",
    "guinea ecuatorial": "GQ", "equatorial guinea": "GQ",
    "guinea-bisáu": "GW", "guinea-bissau": "GW",
    "guyana": "GY",
    "reino unido": "GB", "united kingdom": "GB", "uk": "GB",

    // H
    "haití": "HT", "haiti": "HT",
    "honduras": "HN",
    "hong kong": "HK",
    "hungría": "HU", "hungria": "HU", "hungary": "HU",

    // I
    "india": "IN",
    "indonesia": "ID",
    "irak": "IQ", "iraq": "IQ",
    "irán": "IR", "iran": "IR",
    "irlanda": "IE", "ireland": "IE",
    "isla de man": "IM", "isle of man": "IM",
    "islas caimán": "KY", "cayman islands": "KY",
    "islas marianas del norte": "MP", "northern mariana islands": "MP",
    "islas marshall": "MH", "marshall islands": "MH",
    "islas salomón": "SB", "solomon islands": "SB",
    "islas turcas y caicos": "TC", "turks and caicos": "TC",
    "islas vírgenes": "VI", "us virgin islands": "VI",
    "israel": "IL",
    "italia": "IT", "italy": "IT",
    "islandia": "IS", "iceland": "IS",
    "territorio británico del océano índico": "IO", "british indian ocean territory": "IO",

    // J
    "jamaica": "JM",
    "japón": "JP", "japon": "JP", "japan": "JP",
    "jersey": "JE",
    "jordania": "JO", "jordan": "JO",

    // K
    "kazajistán": "KZ", "kazakhstan": "KZ",
    "kenia": "KE", "kenya": "KE",
    "kirguistán": "KG", "kyrgyzstan": "KG",
    "kiribati": "KI",
    "kosovo": "XK",
    "kuwait": "KW",

    // L
    "laos": "LA",
    "lesoto": "LS", "lesotho": "LS",
    "letonia": "LV", "latvia": "LV",
    "líbano": "LB", "libano": "LB", "lebanon": "LB",
    "liberia": "LR",
    "libia": "LY", "libya": "LY",
    "liechtenstein": "LI",
    "lituania": "LT", "lithuania": "LT",
    "luxemburgo": "LU", "luxembourg": "LU",
    "santa lucía": "LC", "santa lucia": "LC", "saint lucia": "LC",

    // M
    "macao": "MO", "macau": "MO",
    "madagascar": "MG",
    "malasia": "MY", "malaysia": "MY",
    "malaui": "MW", "malawi": "MW",
    "maldivas": "MV", "maldives": "MV",
    "malí": "ML", "mali": "ML",
    "malta": "MT",
    "marruecos": "MA", "morocco": "MA",
    "martinica": "MQ", "martinique": "MQ",
    "mauricio": "MU", "mauritius": "MU",
    "mauritania": "MR",
    "mayotte": "YT",
    "méxico": "MX", "mexico": "MX",
    "moldavia": "MD", "moldova": "MD",
    "mónaco": "MC", "monaco": "MC",
    "mongolia": "MN",
    "montenegro": "ME",
    "montserrat": "MS",
    "mozambique": "MZ",
    "myanmar": "MM", "birmania": "MM", "burma": "MM",
    "macedonia del norte": "MK", "north macedonia": "MK",
    "islas marianas": "MP",

    // N
    "namibia": "NA",
    "nauru": "NR",
    "nepal": "NP",
    "nicaragua": "NI",
    "níger": "NE", "niger": "NE",
    "nigeria": "NG",
    "niue": "NU",
    "noruega": "NO", "norway": "NO",
    "nueva caledonia": "NC", "new caledonia": "NC",
    "nueva zelanda": "NZ", "new zealand": "NZ",
    "países bajos": "NL", "paises bajos": "NL", "netherlands": "NL", "holanda": "NL", "holland": "NL",
    "isla norfolk": "NF", "norfolk island": "NF",

    // O
    "omán": "OM", "oman": "OM",

    // P
    "pakistán": "PK", "pakistan": "PK",
    "palaos": "PW", "palau": "PW",
    "palestina": "PS", "palestine": "PS",
    "panamá": "PA", "panama": "PA",
    "papúa nueva guinea": "PG", "papua new guinea": "PG",
    "paraguay": "PY",
    "perú": "PE", "peru": "PE",
    "polonia": "PL", "poland": "PL",
    "portugal": "PT",
    "puerto rico": "PR",
    "islas pitcairn": "PN",

    // R
    "república checa": "CZ", "czech republic": "CZ", "czechia": "CZ",
    "reunión": "RE", "reunion": "RE",
    "ruanda": "RW", "rwanda": "RW",
    "rumania": "RO", "romania": "RO",
    "rusia": "RU", "russia": "RU",

    // S
    "samoa": "WS",
    "san bartolomé": "BL", "saint barthélemy": "BL", "saint barthelemy": "BL",
    "san cristóbal y nieves": "KN", "saint kitts and nevis": "KN",
    "san marino": "SM",
    "san martín": "MF", "saint martin": "MF",
    "san pedro y miquelón": "PM", "saint pierre and miquelon": "PM",
    "san vicente y las granadinas": "VC", "saint vincent and the grenadines": "VC",
    "santa elena": "SH", "saint helena": "SH",
    "santo tomé y príncipe": "ST", "sao tome and principe": "ST",
    "senegal": "SN",
    "serbia": "RS",
    "seychelles": "SC",
    "sierra leona": "SL", "sierra leone": "SL",
    "singapur": "SG", "singapore": "SG",
    "sint maarten": "SX",
    "siria": "SY", "syria": "SY",
    "somalia": "SO",
    "sri lanka": "LK",
    "suazilandia": "SZ", "eswatini": "SZ", "swaziland": "SZ",
    "sudáfrica": "ZA", "sudafrica": "ZA", "south africa": "ZA",
    "sudán": "SD", "sudan": "SD",
    "sudán del sur": "SS", "south sudan": "SS",
    "suecia": "SE", "sweden": "SE",
    "suiza": "CH", "switzerland": "CH",
    "surinam": "SR", "suriname": "SR",
    "svalbard y jan mayen": "SJ",
    "islas svalbard": "SJ",

    // T
    "tailandia": "TH", "thailand": "TH",
    "taiwán": "TW", "taiwan": "TW",
    "tanzania": "TZ",
    "tayikistán": "TJ", "tajikistan": "TJ",
    "timor oriental": "TL", "east timor": "TL", "timor-leste": "TL",
    "togo": "TG",
    "tokelau": "TK",
    "tonga": "TO",
    "trinidad y tobago": "TT", "trinidad and tobago": "TT",
    "tristán de acuña": "TA", "tristan da cunha": "TA",
    "túnez": "TN", "tunez": "TN", "tunisia": "TN",
    "turkmenistán": "TM", "turkmenistan": "TM",
    "turquía": "TR", "turkey": "TR",
    "tuvalu": "TV",
    "islas turcas": "TC",

    // U
    "ucrania": "UA", "ukraine": "UA",
    "uganda": "UG",
    "uruguay": "UY",
    "uzbekistán": "UZ", "uzbekistan": "UZ",

    // V
    "vanuatu": "VU",
    "vaticano": "VA", "vatican": "VA", "holy see": "VA",
    "venezuela": "VE",
    "vietnam": "VN",
    "wallis y futuna": "WF", "wallis and futuna": "WF",

    // Y
    "yemen": "YE",

    // Z
    "zambia": "ZM",
    "zimbabue": "ZW", "zimbabwe": "ZW",
}

let handler = async (message, { text, command }) => {
    if (command === 'numwalist') {
        return message.reply(`🌎 *Códigos de País Soportados (ISO):*\n\n` +
            allCountries.join(', ') +
            `\n\n💡 *Ejemplos:*\n.numwa UY 093900470\n.numwa uruguay 093900470\n.numwa argentina 01123456789\n.numwa españa 612345678`)
    }

    try {
        if (!text) return message.reply(
            '❌ *Uso:* `.numwa <país o código> <número>`\n\n' +
            '*Ejemplos:*\n' +
            '`.numwa UY 093900470`\n' +
            '`.numwa uruguay 093900470`\n' +
            '`.numwa argentina 01123456789`\n' +
            '`.numwa españa 612345678`'
        )

        const args = text.trim().split(/\s+/)

        // Soporte para nombres de país con varias palabras (ej: "costa rica", "estados unidos")
        // Probamos desde el argumento más largo hacia el más corto
        let isoCode = null
        let numeroRaw = null

        for (let i = args.length - 1; i >= 1; i--) {
            const possibleCountry = args.slice(0, i).join(' ').toLowerCase()
            const possibleNumber = args.slice(i).join('')

            // ¿Es un nombre conocido?
            if (countryAlpha[possibleCountry]) {
                isoCode = countryAlpha[possibleCountry]
                numeroRaw = possibleNumber
                break
            }

            // ¿Es un código ISO directo? (ej: UY, AR, US)
            const upperCode = possibleCountry.toUpperCase()
            if (i === 1 && allCountries.includes(upperCode)) {
                isoCode = upperCode
                numeroRaw = possibleNumber
                break
            }
        }

        if (!isoCode) {
            // Fallback: primer argumento como código ISO
            const upperCode = args[0].toUpperCase()
            if (allCountries.includes(upperCode)) {
                isoCode = upperCode
                numeroRaw = args.slice(1).join('')
            } else {
                return message.reply(
                    `❌ El país o código *"${args[0]}"* no es válido.\n\n` +
                    `Podés usar el nombre del país en español o inglés, o el código ISO.\n` +
                    `Usá \`.numwalist\` para ver todos los códigos soportados.`
                )
            }
        }

        const phoneNumber = parsePhoneNumberFromString(numeroRaw, isoCode)

        if (!phoneNumber || !phoneNumber.isValid()) {
            return message.reply(
                `⚠️ *Número Inválido para ${isoCode}*\n\n` +
                `Verificá que el número sea correcto para ese país.`
            )
        }

        const numeroFinal = phoneNumber.format('E.164').replace('+', '')

        let response = `✅ *Validación Exitosa*\n\n`
        response += `🌍 *País:* ${isoCode}\n`
        response += `🔢 *WA:* ${numeroFinal}\n\n`

        return message.reply(response)

    } catch (err) {
        return message.reply('❌ Error al procesar el número.')
    }
}

handler.help = ['numwa', 'numwalist']
handler.tags = ['herramientas']
handler.command = /^(numwa|numwalist)$/i

module.exports = handler