// hd.js
const sharp = require('sharp');

let handler = async (message, { conn }) => {
  try {
    const sock = conn || message._sock || global.conn;

    const quoted = message.quoted ? message.quoted : message;
    const mime = (quoted.msg || quoted).mimetype || '';

    if (!/image/.test(mime)) {
      return await message.reply('❌ Enviá o respondé a una imagen para mejorar su calidad.');
    }

    await message.reply('✨ Aumentando la calidad...');

    const imgBuffer = await quoted.download();

    // Obtener dimensiones originales
    const metadata = await sharp(imgBuffer).metadata();
    const newWidth  = metadata.width  * 2;
    const newHeight = metadata.height * 2;

    // Upscale x2 + sharpening
    const resultBuffer = await sharp(imgBuffer)
      .resize(newWidth, newHeight, {
        kernel: sharp.kernel.lanczos3,   // mejor algoritmo de escalado
        fastShrinkOnLoad: false
      })
      .sharpen({
        sigma: 1.2,    // radio del sharpening
        m1: 1.5,       // intensidad en bordes suaves
        m2: 0.7,       // intensidad en bordes fuertes
        x1: 2,
        y2: 10,
        y3: 20
      })
      .jpeg({ quality: 95, mozjpeg: true })
      .toBuffer();

    const sendOptions = message._baileyMessage ? { quoted: message._baileyMessage } : {};
    await sock.sendMessage(message.from, { image: resultBuffer, caption: '✅' }, sendOptions);

  } catch (error) {
    console.error('[HD ERROR]', error.message);
    await message.reply('❌ Ocurrió un error, intentá de nuevo.');
  }
};

handler.help = ['hd', 'upscale'];
handler.tags = ['tools'];
handler.command = /^(hd|upscale|upsc|mejorar)$/i;

module.exports = handler;