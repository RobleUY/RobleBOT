const axios = require('axios');
const FormData = require('form-data');
const sharp = require('sharp');

const IMGBB_KEYS = [
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c'
];

// Sube imagen a ImgBB rotando keys si alguna falla
async function subirImgBB(buffer) {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename: 'image.jpg' });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: { ...form.getHeaders() }, timeout: 20000 }
            );
            const url = res.data?.data?.url;
            if (url) return url;
        } catch (e) {
            console.warn(`[HD] ImgBB key ...${key.slice(-6)} falló:`, e.message);
        }
    }
    throw new Error('Todas las keys de ImgBB fallaron');
}

// Upscale con Delirius — devuelve buffer de la imagen mejorada
async function upscaleDelirius(imageUrl) {
    const res = await axios.get(
        `https://api.delirius.online/ia/upscale?image=${encodeURIComponent(imageUrl)}`,
        { responseType: 'arraybuffer', timeout: 60000 }
    );
    const buf = Buffer.from(res.data);
    if (buf.length < 5000) throw new Error('Respuesta demasiado pequeña, posible error');
    return buf;
}

// Fallback local con sharp: x2 + sharpening
async function upscaleLocal(buffer) {
    const metadata = await sharp(buffer).metadata();
    return await sharp(buffer)
        .resize(metadata.width * 2, metadata.height * 2, {
            kernel: sharp.kernel.lanczos3,
            fastShrinkOnLoad: false
        })
        .sharpen({ sigma: 1.2, m1: 1.5, m2: 0.7, x1: 2, y2: 10, y3: 20 })
        .jpeg({ quality: 95, mozjpeg: true })
        .toBuffer();
}

let handler = async (message, { conn }) => {
    try {
        const sock = conn || message._sock || global.conn;

        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';

        if (!/image/.test(mime)) {
            return await message.reply('❌ Enviá o respondé a una imagen para mejorar su calidad.');
        }

        await message.reply('✨ Mejorando calidad...');

        const imgBuffer = await quoted.download();

        let resultBuffer = null;

        // Intentar con Delirius primero
        try {
            console.log('[HD] Subiendo imagen a ImgBB...');
            const imageUrl = await subirImgBB(imgBuffer);
            console.log('[HD] Consultando Delirius upscale...');
            resultBuffer = await upscaleDelirius(imageUrl);
            console.log(`[HD] ✅ Delirius OK — ${(resultBuffer.length / 1024).toFixed(0)} KB`);
        } catch (e) {
            console.warn('[HD] Delirius falló, usando fallback local:', e.message);
            resultBuffer = await upscaleLocal(imgBuffer);
            console.log(`[HD] ✅ Fallback local OK — ${(resultBuffer.length / 1024).toFixed(0)} KB`);
        }

        const sendOptions = message._baileyMessage ? { quoted: message._baileyMessage } : {};
        await sock.sendMessage(message.from, { image: resultBuffer, caption: '✅' }, sendOptions);

    } catch (error) {
        console.error('[HD ERROR]', error.message);
        await message.reply('❌ Ocurrió un error, intentá de nuevo.');
    }
};

handler.help = ['hd', 'upscale'];
handler.tags = ['tools'];
handler.command = /^(hd|upscale|upsc|mejorar)$/i;

module.exports = handler;
