/**
 * Comandos: sugerencia y reporte
 * Descripción: Permite a los usuarios enviar sugerencias o reportes directamente al owner
 * Uso: .sugerencia [texto] / .reporte [texto]
 */
const OWNER_NUMBER = '59893900470@s.whatsapp.net'; // Número del owner
let handler = async (message, { conn, text, command }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // --- 1. Verificar que se haya proporcionado texto ---
        if (!text || text.trim() === '') {
            const ejemploComando = command === 'sugerencia' ? 'sugerencia' : 'reporte';
            return await message.reply(
                `❌ Debes escribir un texto para tu ${command}.\n\n` +
                `*Ejemplo:* .${ejemploComando} Este es mi ${command}`
            );
        }
        // --- 2. Verificar que sea un chat privado ---
        const chat = message.key.remoteJid;
        const isPrivateChat = !chat.includes('-') && !chat.includes('@g.us');
        
        if (!isPrivateChat) {
            return await message.reply(
                `❌ Este comando solo se puede usar en el chat privado del bot.`
            );
        }
        // --- 3. Obtener información del usuario ---
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener tu información de usuario.');
        }
        const senderNumber = senderJid.split('@')[0];
        // --- 3. Determinar el tipo de mensaje (sugerencia o reporte) ---
        const isSugerencia = command === 'sugerencia' || command === 'sugerir' || command === 'suggest';
        const tipoMensaje = isSugerencia ? '💡 SUGERENCIA RECIBIDA' : '⚠️ REPORTE RECIBIDO';
        const emoji = isSugerencia ? '💡' : '⚠️';
        const genero = isSugerencia ? 'enviada' : 'enviado';
        // --- 4. Construir mensaje para el owner ---
        const fechaSolo = new Date().toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const mensajeOwner = 
            `${tipoMensaje}\n\n` +
            `👤 *Usuario:* @${senderNumber}\n` +
            `📱 *Teléfono:* +${senderNumber}\n` +
            `📅 *Fecha:* ${fechaSolo}\n\n` +
            `━━━━━━━━━━━━━━━\n` +
            `📝 *Contenido:*\n${text}\n` +
            `━━━━━━━━━━━━━━━`;
        // --- 5. Enviar mensaje al owner ---
        try {
            await sock.sendMessage(
                OWNER_NUMBER,
                { 
                    text: mensajeOwner,
                    mentions: [senderJid]
                }
            );
            // --- 6. Confirmar al usuario ---
            await message.reply(
                `✅ Tu ${command} ha sido ${genero} correctamente.\n\n` +
                `${emoji} El owner ha recibido tu mensaje y te contactará si es necesario.\n\n` +
                `¡Gracias por tu aporte!`
            );
        } catch (sendError) {
            console.error(`Error al enviar ${command} al owner:`, sendError);
            await message.reply(
                `❌ Hubo un error al enviar tu ${command}.\n\n` +
                `Por favor, intenta nuevamente más tarde o contacta al owner directamente.`
            );
        }
    } catch (error) {
        console.error(`Error en comando ${command}:`, error);
        await message.reply(`❌ Ocurrió un error inesperado al procesar tu ${command}.`);
    }
};
// --- Configuración del Handler ---
handler.help = ['sugerencia [texto]', 'reporte [texto]'];
handler.tags = ['owner', 'contact'];
handler.command = /^(sugerencia|sugerir|suggest|reporte|reportar|report)$/i;
module.exports = handler;
