const axios = require('axios');
const FormData = require('form-data'); // Asegúrate de tener instalado form-data

let handler = async (message, { conn, text }) => {
    try {
        // 1. Verificar si el mensaje respondido (quoted) contiene una imagen, o si el mensaje en sí es una imagen
        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';

        if (!/image/.test(mime)) {
            return await message.reply('⚠️ Por favor, responde a una imagen o envía una imagen usando el comando *.analizar*');
        }

        await message.reply('🔍 Analizando la imagen, por favor espera...');

        // 2. Descargar la imagen del chat de WhatsApp como Buffer
        const imgBuffer = await quoted.download();
        
        // 3. Crear el formulario correcto usando la librería form-data
        const form = new FormData();
        form.append('image', imgBuffer, { filename: 'image.jpg' }); // Enviamos el Buffer directo, es más seguro

        // Subir a ImgBB de forma correcta
        const uploadRes = await axios.post('https://api.imgbb.com/1/upload?key=4ce3fe016a9c978bf9c8cba581c22bd3', form, {
            headers: {
                ...form.getHeaders() // Esto le indica a Axios los límites correctos del formulario
            }
        });

        const imageUrl = uploadRes.data.data.url;

        // 4. Consultar la API Delirius con la URL de la imagen obtenida
        const queryText = text || '¿Qué ves en la imagen sin mucho detalle?';
        const apiUrl = `https://api.delirius.store/ia/visual?image=${encodeURIComponent(imageUrl)}&query=${encodeURIComponent(queryText)}`;
        
        const { data } = await axios.get(apiUrl);

        // 5. Verificar la respuesta de la API y responder al usuario
        if (data && data.status && data.data && data.data.result) {
            await message.reply(data.data.result);
        } else {
            await message.reply('❌ La IA no pudo procesar la imagen correctamente.');
        }

    } catch (error) {
        console.error('[ERROR] Al analizar la imagen:');
        if (error.response) {
            // Si el error viene del servidor (como el 400), esto te dirá exactamente QUÉ no le gustó a ImgBB
            console.error('Data del error:', error.response.data);
        } else {
            console.error(error);
        }
        await message.reply('❌ Ocurrió un error al intentar procesar o analizar la imagen.');
    }
};

handler.help = ['analizar'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(analizar|iavisual|visual)$/i;

module.exports = handler;