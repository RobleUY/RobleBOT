const axios = require('axios');
const FormData = require('form-data');
const crypto = require('crypto');
require('dotenv').config();
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ==========================================
// CONFIG & KEYS
// ==========================================

const IMGBB_KEYS = [
    process.env.IMGBB_API_KEY,
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c',
    'Z4ce3fe016a9c978bf9c8cba581c22bd3'
].filter(Boolean);

// ==========================================
// UPLOAD PROVIDERS
// ==========================================

async function uploadCloudinary(buffer, filename = 'upload.jpg') {
    const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;

    if (!cloudName || !apiKey || !apiSecret) {
        throw new Error('Cloudinary credentials not configured in .env');
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const stringToSign = `timestamp=${timestamp}${apiSecret}`;
    const signature = crypto.createHash('sha1').update(stringToSign).digest('hex');

    const form = new FormData();
    form.append('file', buffer, { filename });
    form.append('api_key', apiKey);
    form.append('timestamp', timestamp);
    form.append('signature', signature);

    const res = await axios.post(
        `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
        form,
        { headers: form.getHeaders(), timeout: 15000 }
    );

    const data = res.data;
    if (data?.secure_url || data?.url) {
        return data.secure_url || data.url;
    }
    throw new Error('Cloudinary failed');
}

async function uploadImgBB(buffer, filename = 'upload.jpg') {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: form.getHeaders(), timeout: 15000 }
            );
            const data = res.data?.data;
            if (data?.url) return data.url;
        } catch (e) {
            // Intenta con la siguiente API Key
        }
    }
    throw new Error('All ImgBB keys failed');
}

async function uploadTelegraph(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://telegra.ph/upload', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (res.data?.[0]?.src) {
        return 'https://telegra.ph' + res.data[0].src;
    }
    throw new Error('Telegraph failed');
}

async function uploadCatbox(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (typeof res.data === 'string' && res.data.startsWith('http')) {
        return res.data.trim();
    }
    throw new Error('Catbox failed');
}

async function uploadQuax(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (res.data?.success && res.data?.files?.[0]?.url) {
        return res.data.files[0].url;
    }
    throw new Error('Qu.ax failed');
}

/** Sube la imagen usando la opción más rápida disponible */
async function uploadImageFastest(buffer, filename = 'upload.jpg') {
    const providers = [];

    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
        providers.push(uploadCloudinary(buffer, filename));
    }

    providers.push(uploadImgBB(buffer, filename));
    providers.push(uploadTelegraph(buffer, filename));
    providers.push(uploadCatbox(buffer, filename));
    providers.push(uploadQuax(buffer, filename));

    try {
        return await Promise.any(providers);
    } catch (error) {
        throw new Error('Todos los servicios de subida fallaron al procesar la imagen.');
    }
}

// ==========================================
// HELPERS
// ==========================================

async function streamToBuffer(stream) {
    let buf = Buffer.alloc(0);
    for await (const chunk of stream) {
        buf = Buffer.concat([buf, chunk]);
    }
    return buf;
}

/**
 * Resuelve la imagen a subir y extrae la consulta/prompt de la entrada
 */
async function resolverImagenYTexto(message, rawText) {
    let promptText = (rawText || '').trim();
    let directUrl = null;

    // Detecta si el texto incluye una URL al inicio
    const urlMatch = promptText.match(/^(https?:\/\/[^\s]+)\s*(.*)/i);
    if (urlMatch) {
        directUrl = urlMatch[1];
        promptText = urlMatch[2].trim();
    }

    if (directUrl) {
        return { imageUrl: directUrl, prompt: promptText || '¿Qué ves en esta imagen?' };
    }

    const baileyMsg = message?._baileyMessage || global.lastBaileyMessage || message;
    if (!baileyMsg) {
        throw new Error('Debes adjuntar una imagen, responder a una imagen o proporcionar una URL válida.');
    }

    function unwrap(msg) {
        if (!msg) return null;
        return (
            msg.viewOnceMessage?.message ||
            msg.viewOnceMessageV2?.message ||
            msg.viewOnceMessageV2Extension?.message ||
            msg.ephemeralMessage?.message ||
            msg.documentWithCaptionMessage?.message ||
            msg.buttonReplyMessage?.message ||
            msg.buttonsResponseMessage?.message ||
            msg.templateButtonReplyMessage?.message ||
            msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
            msg
        );
    }

    async function downloadImgMsg(imgMsgObj) {
        try {
            const stream = await downloadContentFromMessage(imgMsgObj, 'image');
            return await streamToBuffer(stream);
        } catch (e) {
            console.error('[ANALIZAR] Error al descargar la imagen:', e.message);
            return null;
        }
    }

    const rawMsg = baileyMsg.message || baileyMsg;
    const inner = unwrap(rawMsg);

    let buffer = null;

    if (inner?.imageMessage) {
        buffer = await downloadImgMsg(inner.imageMessage);
    }

    if (!buffer) {
        const contextInfo =
            inner?.extendedTextMessage?.contextInfo ||
            inner?.imageMessage?.contextInfo ||
            inner?.videoMessage?.contextInfo ||
            inner?.audioMessage?.contextInfo ||
            inner?.stickerMessage?.contextInfo ||
            rawMsg?.extendedTextMessage?.contextInfo ||
            rawMsg?.imageMessage?.contextInfo ||
            rawMsg?.videoMessage?.contextInfo ||
            rawMsg?.stickerMessage?.contextInfo ||
            null;

        const quoted = contextInfo?.quotedMessage;
        if (quoted) {
            const quotedInner = unwrap(quoted) || quoted;
            if (quotedInner?.imageMessage) {
                buffer = await downloadImgMsg(quotedInner.imageMessage);
            }
        }
    }

    if (!buffer) {
        throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL de imagen válida.');
    }

    if (buffer.length < 1000) {
        throw new Error('La imagen es demasiado pequeña o no se pudo procesar correctamente.');
    }

    const uploadedUrl = await uploadImageFastest(buffer);
    return { imageUrl: uploadedUrl, prompt: promptText || '¿Qué ves en esta imagen?' };
}

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { text }) => {
    try {
        await message.reply('🔍 *Procesando imagen y consultando la IA...*');

        const { imageUrl, prompt } = await resolverImagenYTexto(message, text);

        const apiUrl = `http://darli.hidencloud.com:24667/analizar?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;

        const { data } = await axios.get(apiUrl, { timeout: 30000 });

        if (!data || !data.description) {
            throw new Error('La API de análisis no devolvió una respuesta válida.');
        }

        const respuesta = 
            `👁️ *Análisis de Imagen*\n\n` +
            `❓ *Pregunta:* ${data.prompt || prompt}\n\n` +
            `📝 *Descripción:*\n${data.description}`;

        return await message.reply(respuesta.trim());

    } catch (error) {
        console.error('[ANALIZAR ERROR]', error.message);
        return await message.reply(`❌ *Error al analizar la imagen:*\n\n${error.message}`);
    }
};

handler.help = ['analizar [pregunta]', 'analizar [url] [pregunta]'];
handler.tags = ['herramientas', 'ia'];
handler.command = /^(analizar|analyze)$/i;

module.exports = handler;