const axios = require('axios');
const FormData = require('form-data');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

const IMGBB_KEYS = [
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c'
];

async function subirImgBB(buffer) {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename: 'image.jpg' });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: { ...form.getHeaders() }, timeout: 20000 }
            );
            const url = res.data?.data?.url;
            if (url) return url;
        } catch (e) {
            console.warn(`[IMGBB] key ...${key.slice(-6)} fallo:`, e.message);
        }
    }
    throw new Error('Todas las keys de ImgBB fallaron');
}

function formatToWhatsApp(text) {
    if (!text) return text;
    let out = text;
    out = out.replace(/^#{1,6}\s*(.+)$/gm, '*$1*');
    out = out.replace(/\*\*(.+?)\*\*/g, '*$1*');
    out = out.replace(/__(.+?)__/g, '*$1*');
    out = out.replace(/^[\*\-]\s+/gm, '• ');
    out = out.replace(/```[a-zA-Z]*\n/g, '```');
    out = out.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '$1: $2');
    out = out.replace(/\n{3,}/g, '\n\n');
    return out.trim();
}

// ============================================================
// COMANDO: .analizar / .iavisual / .visual
// ============================================================
let handler = async (message, { conn, text }) => {
    try {
        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/image/.test(mime)) {
            return await message.reply('Por favor, responde a una imagen o envia una imagen usando el comando .analizar');
        }

        await message.reply('Analizando la imagen, por favor espera...');
        console.log('[ANALIZAR] Descargando imagen...');
        const imgBuffer = await quoted.download();
        console.log(`[ANALIZAR] Imagen descargada, tamaño: ${imgBuffer.length} bytes`);

        const queryText = text || 'Que ves en la imagen sin mucho detalle?';
        const promptFinal = `${queryText}\n\nResponde en español, de forma clara y ordenada, en texto plano tipo chat de WhatsApp. No uses encabezados con #, no uses tablas, no uses doble asterisco. Si necesitas resaltar algo usa un solo asterisco alrededor de la palabra. Usa saltos de linea simples entre ideas, sin exagerar el espacio.`;

        // Opcion 1: Gemini
        try {
            console.log('[ANALIZAR] Intentando con Gemini...');
            const geminiRes = await axios.post(
                'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent',
                {
                    contents: [{
                        parts: [
                            { text: promptFinal },
                            { inline_data: { mime_type: mime, data: imgBuffer.toString('base64') } }
                        ]
                    }]
                },
                {
                    headers: { 'Content-Type': 'application/json', 'X-goog-api-key': GEMINI_API_KEY },
                    timeout: 20000
                }
            );
            const resultText = geminiRes?.data?.candidates?.[0]?.content?.parts?.[0]?.text;
            if (resultText) {
                console.log('[ANALIZAR] Gemini OK');
                return await message.reply(formatToWhatsApp(resultText));
            }
            throw new Error('Respuesta de Gemini vacia');
        } catch (geminiError) {
            console.error('[ANALIZAR] Gemini fallo:', geminiError.response?.data || geminiError.message);
        }

        // Opcion 2: ImgBB + Delirius (fallback)
        console.log('[ANALIZAR] Subiendo imagen a ImgBB...');
        const imageUrl = await subirImgBB(imgBuffer);
        console.log('[ANALIZAR] Imagen subida:', imageUrl);

        console.log('[ANALIZAR] Consultando Delirius...');
        const deliriusRes = await axios.get(
            `https://api.delirius.online/ia/visual?image=${encodeURIComponent(imageUrl)}&query=${encodeURIComponent(queryText)}`,
            { timeout: 30000 }
        );
        console.log('[ANALIZAR] Respuesta Delirius:', JSON.stringify(deliriusRes.data).slice(0, 200));

        if (deliriusRes.data?.status && deliriusRes.data?.data?.result) {
            await message.reply(formatToWhatsApp(deliriusRes.data.data.result));
        } else {
            await message.reply('La IA no pudo procesar la imagen correctamente.');
        }

    } catch (error) {
        console.error('[ANALIZAR] Error:', error.response?.data || error.message);
        await message.reply('Ocurrio un error al intentar procesar o analizar la imagen.');
    }
};

handler.help = ['analizar'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(analizar|iavisual|visual)$/i;

module.exports = handler;

// ============================================================
// COMANDO: .edad / .age
// ============================================================
const EXPRESIONES = {
    'none': 'ninguna', 'neutral': 'neutral', 'happy': 'feliz',
    'sad': 'triste', 'angry': 'enojado/a', 'surprised': 'sorprendido/a',
    'fear': 'miedo', 'disgust': 'asco', 'contempt': 'desprecio'
};

const FORMAS_CARA = {
    'oval': 'ovalada', 'round': 'redonda', 'square': 'cuadrada',
    'heart': 'corazon', 'diamond': 'diamante', 'oblong': 'oblonga',
    'triangle': 'triangular'
};

let handlerEdad = async (message, { conn }) => {
    try {
        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';

        if (!/image/.test(mime)) {
            return await message.reply('Responde a una imagen o envia una imagen con el comando .edad para estimar la edad.');
        }

        await message.reply('Analizando el rostro, espera un momento...');

        const imgBuffer = await quoted.download();

        const imageUrl = await subirImgBB(imgBuffer);
        console.log('[EDAD] URL subida:', imageUrl);

        const res = await axios.get(
            `https://api.delirius.online/ia/age?image=${encodeURIComponent(imageUrl)}&language=es`,
            { timeout: 15000 }
        );

        if (!res.data?.status || !res.data?.data) {
            return await message.reply('No se detecto ningun rostro en la imagen. Asegurate de que sea una foto de una persona.');
        }

        const d = res.data.data;
        const edad      = d.age        || '?';
        const genero    = d.gender     || '?';
        const expresion = EXPRESIONES[d.expression?.toLowerCase()] || d.expression || '?';
        const forma     = FORMAS_CARA[d.face_shape?.toLowerCase()] || d.face_shape || '?';

        await message.reply(
            `*Analisis de Rostro*\n\n` +
            `Edad aproximada: ${edad} anos\n` +
            `Genero: ${genero}\n` +
            `Expresion: ${expresion}\n` +
            `Forma de cara: ${forma}`
        );

    } catch (error) {
        console.error('[EDAD] Error:', error.response?.data || error.message);
        await message.reply('Ocurrio un error al analizar la imagen. Intenta de nuevo.');
    }
};

handlerEdad.help = ['edad', 'age'];
handlerEdad.tags = ['ia', 'herramientas'];
handlerEdad.command = /^(edad|age)$/i;

module.exports.edad = handlerEdad;
