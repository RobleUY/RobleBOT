const axios = require('axios');
const FormData = require('form-data');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const IMGBB_API_KEY = process.env.IMGBB_API_KEY;

// 🧹 Convierte markdown estándar (el que usa Gemini) al formato que entiende WhatsApp
function formatToWhatsApp(text) {
    if (!text) return text;

    let out = text;

    // Quitar encabezados tipo ### Título -> lo pasamos a negrita
    out = out.replace(/^#{1,6}\s*(.+)$/gm, '*$1*');

    // Negrita: **texto** o __texto__ -> *texto*
    out = out.replace(/\*\*(.+?)\*\*/g, '*$1*');
    out = out.replace(/__(.+?)__/g, '*$1*');

    // Cursiva markdown con un solo * ya choca con la negrita de WhatsApp,
    // así que la dejamos como _texto_ solo si viene explícita con guion bajo simple
    // (no tocamos los * restantes, ya quedaron como negrita de WhatsApp)

    // Listas: "- item" o "* item" al inicio de línea -> "• item"
    out = out.replace(/^[\*\-]\s+/gm, '• ');

    // Numeradas "1. item" las dejamos tal cual, WhatsApp las muestra bien

    // Bloques de código ```lang ... ``` -> dejamos las comillas triples, WhatsApp las respeta
    // pero quitamos el nombre del lenguaje si viene (```javascript -> ```)
    out = out.replace(/```[a-zA-Z]*\n/g, '```');

    // Enlaces markdown [texto](url) -> "texto: url" (WhatsApp no soporta hyperlinks con texto)
    out = out.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '$1: $2');

    // Quitar líneas en blanco excesivas (más de 2 seguidas)
    out = out.replace(/\n{3,}/g, '\n\n');

    return out.trim();
}

let handler = async (message, { conn, text }) => {
    try {
        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/image/.test(mime)) {
            return await message.reply('⚠️ Por favor, responde a una imagen o envía una imagen usando el comando *.analizar*');
        }

        await message.reply('🔍 Analizando la imagen, por favor espera...');
        console.log('[ANALIZAR] Descargando imagen...');
        const imgBuffer = await quoted.download();
        console.log(`[ANALIZAR] Imagen descargada, tamaño: ${imgBuffer.length} bytes`);

        const queryText = text || '¿Qué ves en la imagen sin mucho detalle?';

        // Instrucción extra para que Gemini responda "limpio" y sin tanto adorno de markdown
        const promptFinal = `${queryText}

Responde en español, de forma clara y ordenada, en texto plano tipo chat de WhatsApp. No uses encabezados con #, no uses tablas, no uses doble asterisco. Si necesitas resaltar algo usa un solo asterisco alrededor de la palabra. Usa saltos de línea simples entre ideas, sin exagerar el espacio.`;

        // ---------- OPCIÓN 1: GEMINI (primaria) ----------
        try {
            console.log('[ANALIZAR] Intentando con Gemini...');
            const base64Image = imgBuffer.toString('base64');

            const geminiRes = await axios.post(
                'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent',
                {
                    contents: [
                        {
                            parts: [
                                { text: promptFinal },
                                {
                                    inline_data: {
                                        mime_type: mime,
                                        data: base64Image
                                    }
                                }
                            ]
                        }
                    ]
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        'X-goog-api-key': GEMINI_API_KEY
                    },
                    timeout: 20000
                }
            );

            const resultText = geminiRes?.data?.candidates?.[0]?.content?.parts?.[0]?.text;

            if (resultText) {
                console.log('[ANALIZAR] ✅ Gemini respondió correctamente');
                return await message.reply(formatToWhatsApp(resultText));
            } else {
                console.log('[ANALIZAR] ⚠️ Gemini respondió pero sin texto útil, se usará fallback');
                throw new Error('Respuesta de Gemini vacía o inválida');
            }
        } catch (geminiError) {
            console.error('[ANALIZAR] ❌ Gemini falló:', geminiError.response?.data || geminiError.message);
            console.log('[ANALIZAR] Pasando a fallback (ImgBB + Delirius)...');
        }

        // ---------- OPCIÓN 2: IMGBB + DELIRIUS (fallback) ----------
        console.log('[ANALIZAR] Subiendo imagen a ImgBB...');
        const form = new FormData();
        form.append('image', imgBuffer, { filename: 'image.jpg' });

        const uploadRes = await axios.post(
            `https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`,
            form,
            { headers: { ...form.getHeaders() } }
        );
        const imageUrl = uploadRes.data.data.url;
        console.log(`[ANALIZAR] Imagen subida: ${imageUrl}`);

        console.log('[ANALIZAR] Consultando API Delirius...');
        const apiUrl = `https://api.delirius.store/ia/visual?image=${encodeURIComponent(imageUrl)}&query=${encodeURIComponent(queryText)}`;
        const { data } = await axios.get(apiUrl);

        if (data && data.status && data.data && data.data.result) {
            console.log('[ANALIZAR] ✅ Delirius respondió correctamente');
            await message.reply(formatToWhatsApp(data.data.result));
        } else {
            console.log('[ANALIZAR] ❌ Delirius no devolvió un resultado válido');
            await message.reply('❌ La IA no pudo procesar la imagen correctamente.');
        }

    } catch (error) {
        console.error('[ERROR] Al analizar la imagen:');
        if (error.response) {
            console.error('Data del error:', error.response.data);
        } else {
            console.error(error);
        }
        await message.reply('❌ Ocurrió un error al intentar procesar o analizar la imagen.');
    }
};

handler.help = ['analizar'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(analizar|iavisual|visual)$/i;

module.exports = handler;