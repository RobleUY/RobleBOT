const axios = require('axios');
const FormData = require('form-data');
const crypto = require('crypto');
const sharp = require('sharp');
require('dotenv').config();
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ==========================================
// CONFIG & KEYS
// ==========================================

const IMGBB_KEYS = [
    process.env.IMGBB_API_KEY,
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c',
    'Z4ce3fe016a9c978bf9c8cba581c22bd3'
].filter(Boolean);

// ==========================================
// UPLOAD PROVIDERS
// ==========================================

async function uploadCloudinary(buffer, filename = 'upload.jpg') {
    const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;

    if (!cloudName || !apiKey || !apiSecret) {
        throw new Error('Cloudinary credentials not configured in .env');
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const stringToSign = `timestamp=${timestamp}${apiSecret}`;
    const signature = crypto.createHash('sha1').update(stringToSign).digest('hex');

    const form = new FormData();
    form.append('file', buffer, { filename });
    form.append('api_key', apiKey);
    form.append('timestamp', timestamp);
    form.append('signature', signature);

    const res = await axios.post(
        `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
        form,
        { headers: form.getHeaders(), timeout: 15000 }
    );

    const data = res.data;
    if (data?.secure_url || data?.url) {
        return data.secure_url || data.url;
    }
    throw new Error('Cloudinary failed');
}

async function uploadImgBB(buffer, filename = 'upload.jpg') {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: form.getHeaders(), timeout: 15000 }
            );
            const data = res.data?.data;
            if (data?.url) return data.url;
        } catch (e) {
            // Intenta con la siguiente API Key
        }
    }
    throw new Error('All ImgBB keys failed');
}

async function uploadCatbox(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (typeof res.data === 'string' && res.data.startsWith('http')) {
        return res.data.trim();
    }
    throw new Error('Catbox failed');
}

async function uploadQuax(buffer, filename = 'image.jpg') {
    const form = new FormData();
    form.append('files[]', buffer, { filename, contentType: 'image/jpeg' });
    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: form.getHeaders(),
        timeout: 15000
    });
    if (res.data?.success && res.data?.files?.[0]?.url) {
        return res.data.files[0].url;
    }
    throw new Error('Qu.ax failed');
}

/** Sube la imagen usando la opción más rápida disponible entre servidores activos con extensión válida */
async function uploadImageFastest(buffer, filename = 'upload.jpg') {
    const providers = [];

    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
        providers.push(uploadCloudinary(buffer, filename));
    }

    providers.push(uploadImgBB(buffer, filename));
    providers.push(uploadCatbox(buffer, filename));

    try {
        const url = await Promise.any(providers);
        if (typeof url === 'string' && url.startsWith('http')) {
            return url;
        }
        throw new Error('URL de imagen inválida.');
    } catch (error) {
        throw new Error('Todos los servicios de subida de imagen fallaron.');
    }
}

// ==========================================
// HELPERS
// ==========================================

async function streamToBuffer(stream) {
    let buf = Buffer.alloc(0);
    for await (const chunk of stream) {
        buf = Buffer.concat([buf, chunk]);
    }
    return buf;
}

/**
 * Desempaqueta capas internas de Baileys (viewOnce, ephemeral, etc.)
 */
function unwrapMessage(msg) {
    if (!msg) return null;
    return (
        msg.viewOnceMessage?.message ||
        msg.viewOnceMessageV2?.message ||
        msg.viewOnceMessageV2Extension?.message ||
        msg.ephemeralMessage?.message ||
        msg.documentWithCaptionMessage?.message ||
        msg.buttonReplyMessage?.message ||
        msg.buttonsResponseMessage?.message ||
        msg.templateButtonReplyMessage?.message ||
        msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
        msg
    );
}

/**
 * Resuelve la imagen a subir y extrae la consulta/prompt de la entrada.
 * Soporta:
 * 1. .analizar <url> [prompt]
 * 2. Responder a una imagen/sticker/video con .analizar [prompt]
 * 3. Enviar una imagen/video con caption .analizar [prompt]
 */
async function resolverImagenYTexto(message, rawText) {
    let promptText = (rawText || '').trim();
    let directUrl = null;

    // Detecta si el texto incluye una URL al inicio
    const urlMatch = promptText.match(/^(https?:\/\/[^\s]+)\s*(.*)/i);
    if (urlMatch) {
        directUrl = urlMatch[1];
        promptText = urlMatch[2].trim();
    }

    if (!promptText) {
        throw new Error('❌ *Debes ingresar una pregunta o indicación para analizar la imagen.*\n\n_Ejemplo: .analizar qué ves en esta foto?_\n_O también: .analizar https://link.com qué ves en la imagen?_');
    }

    if (directUrl) {
        return { imageUrl: directUrl, prompt: promptText };
    }

    // Obtener el objeto de mensaje de Baileys de forma segura (evitando conflictos entre subbots)
    const baileyMsg =
        message._baileysMessage ||
        message._baileyMessage ||
        message.baileysMessage ||
        message.baileyMessage ||
        message.rawMessage ||
        message?._baileyMessage ||
        (global.lastBaileyMessage?.key?.id === message.key?.id ? global.lastBaileyMessage : null) ||
        message;

    async function downloadMediaMsg(msgObj, type) {
        try {
            const stream = await downloadContentFromMessage(msgObj, type);
            return await streamToBuffer(stream);
        } catch (e) {
            console.error(`[ANALIZAR] Error al descargar media (${type}):`, e.message);
            return null;
        }
    }

    const rawMsg = baileyMsg.message || baileyMsg;
    const inner = unwrapMessage(rawMsg);

    let buffer = null;

    // 1. Buscar media en el mensaje actual
    if (inner?.imageMessage) {
        buffer = await downloadMediaMsg(inner.imageMessage, 'image');
    } else if (inner?.stickerMessage) {
        buffer = await downloadMediaMsg(inner.stickerMessage, 'sticker');
    } else if (inner?.videoMessage) {
        buffer = await downloadMediaMsg(inner.videoMessage, 'video');
    }

    // 2. Buscar media en el mensaje citado (quoted)
    if (!buffer) {
        const contextInfo =
            inner?.extendedTextMessage?.contextInfo ||
            inner?.imageMessage?.contextInfo ||
            inner?.videoMessage?.contextInfo ||
            inner?.audioMessage?.contextInfo ||
            inner?.stickerMessage?.contextInfo ||
            inner?.documentMessage?.contextInfo ||
            rawMsg?.extendedTextMessage?.contextInfo ||
            rawMsg?.imageMessage?.contextInfo ||
            rawMsg?.videoMessage?.contextInfo ||
            rawMsg?.stickerMessage?.contextInfo ||
            null;

        const quoted = contextInfo?.quotedMessage;
        if (quoted) {
            const quotedInner = unwrapMessage(quoted) || quoted;
            if (quotedInner?.imageMessage) {
                buffer = await downloadMediaMsg(quotedInner.imageMessage, 'image');
            } else if (quotedInner?.stickerMessage) {
                buffer = await downloadMediaMsg(quotedInner.stickerMessage, 'sticker');
            } else if (quotedInner?.videoMessage) {
                buffer = await downloadMediaMsg(quotedInner.videoMessage, 'video');
            }
        }
    }

    // 3. Fallbacks directos usando los métodos del mensaje wrapper
    if (!buffer && typeof message.download === 'function') {
        try {
            const downloaded = await message.download();
            if (downloaded && downloaded.length > 100) buffer = downloaded;
        } catch (_) {}
    }

    if (!buffer && message.quoted && typeof message.quoted.download === 'function') {
        try {
            const downloaded = await message.quoted.download();
            if (downloaded && downloaded.length > 100) buffer = downloaded;
        } catch (_) {}
    }

    if (!buffer) {
        throw new Error('Debes adjuntar una imagen/sticker, responder a una imagen/sticker o pasar una URL de imagen válida.\n\nEjemplo: *.analizar qué ves en la foto?* (respondiendo a una imagen)');
    }

    if (buffer.length < 100) {
        throw new Error('La imagen es demasiado pequeña o no se pudo procesar correctamente.');
    }

    // Convertir cualquier formato de imagen/sticker (WebP, PNG, etc.) a JPEG limpio con sharp
    try {
        buffer = await sharp(buffer).jpeg({ quality: 90 }).toBuffer();
    } catch (sharpErr) {
        console.warn('[ANALIZAR] Advertencia al procesar con sharp:', sharpErr.message);
    }

    const uploadedUrl = await uploadImageFastest(buffer, 'image.jpg');
    return { imageUrl: uploadedUrl, prompt: promptText };
}

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { text }) => {
    try {
        const { imageUrl, prompt } = await resolverImagenYTexto(message, text);

        await message.reply('🔍 *Procesando imagen y consultando la IA...*');

        const apiUrl = `http://roblegames.servegame.net:24667/analizar?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;

        const { data } = await axios.get(apiUrl, { timeout: 35000 });

        const respuestaText = data?.respuesta || data?.description || data?.text || data?.result;
        if (!data || !respuestaText) {
            throw new Error('La API de análisis no devolvió una respuesta válida.');
        }

        const respuesta = 
            `👁️ *Análisis de Imagen*\n\n` +
            `❓ *Pregunta:* ${data.prompt || prompt}\n\n` +
            `📝 *Descripción:*\n${respuestaText.trim()}`;

        return await message.reply(respuesta.trim());

    } catch (error) {
        const serverErrorMsg = error.response?.data?.error || error.response?.data?.message || error.message;
        console.error('[ANALIZAR ERROR]', serverErrorMsg);
        return await message.reply(`❌ *Error al analizar la imagen:*\n\n${serverErrorMsg}`);
    }
};

handler.help = ['analizar [pregunta]', 'analizar [url] [pregunta]'];
handler.tags = ['herramientas', 'ia'];
handler.command = /^(analizar|analyze)$/i;

module.exports = handler;