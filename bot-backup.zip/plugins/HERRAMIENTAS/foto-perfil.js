const axios = require('axios')

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let targetJid

        const firstArg = args[0]?.toLowerCase()

        if (firstArg === 'me' || firstArg === 'yo') {
            targetJid = message.sender
        } else if (message.mentions?.length > 0) {
            targetJid = message.mentions[0]
        } else if (args[0]) {
            const numero = args.join('').replace(/[^0-9]/g, '')
            if (!numero) return message.reply('⚠️ Número inválido.')
            targetJid = `${numero}@s.whatsapp.net`
        } else {
            return message.reply('⚠️ Uso:\n• `.fotop me`\n• `.fotop @usuario`\n• `.fotop +598912345678`')
        }

        let avatarUrl
        try {
            avatarUrl = await conn.profilePictureUrl(targetJid, 'image')
        } catch {
            return message.reply('❌ No se pudo obtener la foto de perfil.\n_Posible razón: el usuario no tiene foto de perfil o la tiene privada para el bot._')
        }

        const { data } = await axios.get(avatarUrl, { responseType: 'arraybuffer' })

        await sock.sendMessage(message.from, {
            image: Buffer.from(data)
        }, { quoted: message._baileyMessage })

    } catch (err) {
        console.error('[FOTOP]', err.message)
        await message.reply('❌ Error al obtener la foto de perfil.')
    }
}

handler.help = ['fotop @usuario', 'fotop +numero']
handler.tags = ['herramientas']
handler.command = /^fotop$/i

module.exports = handler

