const axios = require('axios')

const normalizeNumberJid = (value) => {
    if (!value) return null
    const raw = String(value).trim()
    if (!raw) return null

    if (raw.includes('@')) {
        return raw
    }

    const digits = raw.replace(/\D/g, '')
    if (!digits) return null
    return `${digits}@s.whatsapp.net`
}

const oneShotTimeout = (promise, timeoutMs) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), timeoutMs)
    promise
        .then((value) => { clearTimeout(timer); resolve(value) })
        .catch((err) => { clearTimeout(timer); reject(err) })
})

let handler = async (message, { conn, args }) => {
    const sockCandidates = [
        conn,
        message._sock,
        global.conn,
        ...(Array.isArray(global.subConns) ? global.subConns : [])
    ].filter(Boolean)

    const activeSock = sockCandidates.find(s => s?.user) || sockCandidates[0]
    if (!activeSock) {
        return message.reply('❌ No hay conexión activa del bot.')
    }

    try {
        let targetJid = null
        const firstArg = args[0]?.trim()

        if (!firstArg) {
            return message.reply('⚠️ Uso:\n• `.fotop me`\n• `.fotop @usuario`\n• `.fotop +598912345678`')
        }

        if (firstArg.toLowerCase() === 'me' || firstArg.toLowerCase() === 'yo') {
            targetJid = message.sender
        } else if (message.mentions?.length > 0) {
            targetJid = normalizeNumberJid(message.mentions[0])
        } else {
            targetJid = normalizeNumberJid(firstArg)
        }

        if (!targetJid) {
            return message.reply('⚠️ Número inválido.')
        }

        await message.reply('⏳ Estoy intentando obtener la foto de perfil... Esto puede tardar unos segundos.')

        let avatarUrl = null
        let lastError = null

        for (const candidateSock of sockCandidates.filter(Boolean)) {
            try {
                const url = await oneShotTimeout(candidateSock.profilePictureUrl(targetJid, 'image'), 10000)
                if (url && /^https?:\/\//i.test(url)) {
                    avatarUrl = url
                    break
                }
            } catch (err) {
                lastError = err
            }
        }

        if (!avatarUrl) {
            if (lastError && /timeout|invalid url|not found|not found/i.test(String(lastError.message || lastError))) {
                console.warn('[FOTOP] No se pudo resolver avatar en ninguna conexión activa:', String(lastError.message || lastError))
            }
            return message.reply('❌ No se pudo obtener la foto de perfil.\n_Posible razón: el usuario no tiene foto de perfil o la tiene privada para el bot._')
        }

        const { data } = await axios.get(avatarUrl, {
            responseType: 'arraybuffer',
            timeout: 15000,
            maxContentLength: 10 * 1024 * 1024,
            validateStatus: s => s >= 200 && s < 400
        })

        await (activeSock || message._sock || global.conn).sendMessage(message.from, {
            image: Buffer.from(data)
        }, { quoted: message._baileyMessage })

    } catch (err) {
        const msg = String(err?.message || err)
        console.error('[FOTOP]', msg)
        await message.reply('❌ Error al obtener la foto de perfil.')
    }
}

handler.help = ['fotop @usuario', 'fotop +numero']
handler.tags = ['herramientas']
handler.command = /^fotop$/i

module.exports = handler

