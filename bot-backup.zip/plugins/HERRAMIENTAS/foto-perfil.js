const axios = require('axios')

const resolveTargetJid = (message, args) => {
    if (message.mentions && message.mentions.length > 0) {
        const mention = message.mentions[0]
        if (mention.includes('@')) return mention
        const digits = mention.replace(/\D/g, '')
        if (digits) return `${digits}@s.whatsapp.net`
    }

    const fullText = (args || []).join(' ').trim()
    if (!fullText) return null

    const lower = fullText.toLowerCase()
    if (lower === 'me' || lower === 'yo' || lower.startsWith('me ') || lower.startsWith('yo ')) {
        return message.sender
    }

    // Extraer todos los dígitos ignorando +, espacios, guiones y paréntesis
    const digits = fullText.replace(/\D/g, '')
    if (digits.length >= 6) {
        return `${digits}@s.whatsapp.net`
    }

    return null
}

const oneShotTimeout = (promise, timeoutMs) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), timeoutMs)
    promise
        .then((value) => { clearTimeout(timer); resolve(value) })
        .catch((err) => { clearTimeout(timer); reject(err) })
})

let handler = async (message, { conn, args }) => {
    // Definir la conexión que está procesando este mensaje (subbot o bot principal)
    const activeSock = message._sock || conn || global.conn
    if (!activeSock || !activeSock.user) {
        return message.reply('❌ No hay conexión activa del bot.')
    }

    const targetJid = resolveTargetJid(message, args)
    if (!targetJid) {
        return message.reply('⚠️ Uso:\n• `.fotop me`\n• `.fotop @usuario`\n• `.fotop 59893900470`\n• `.fotop +598 9390 0470`')
    }

    // Candidatos para reintento rápido si el socket activo no puede resolver la foto
    const candidateSocks = [
        activeSock,
        ...(Array.isArray(global.subConns) ? global.subConns : [])
    ].filter(s => s && s.user)

    const uniqueSocks = Array.from(new Set(candidateSocks)).slice(0, 4)

    try {
        await message.reply('⏳ Obteniendo foto de perfil...')

        let avatarUrl = null

        // 1. Intentar con la conexión actual del mensaje (timeout rápido de 3.5s)
        try {
            avatarUrl = await oneShotTimeout(activeSock.profilePictureUrl(targetJid, 'image'), 3500)
        } catch (_) {}

        // 2. Si falla la conexión actual, probar en paralelo en hasta 3 subbots conectados
        if (!avatarUrl && uniqueSocks.length > 1) {
            const fallbackSocks = uniqueSocks.filter(s => s !== activeSock).slice(0, 3)
            try {
                avatarUrl = await Promise.any(
                    fallbackSocks.map(s => oneShotTimeout(s.profilePictureUrl(targetJid, 'image'), 3500))
                )
            } catch (_) {}
        }

        if (!avatarUrl) {
            return message.reply('❌ No se pudo obtener la foto de perfil.\n_Posible razón: el usuario no tiene foto de perfil o la tiene privada para el bot._')
        }

        const { data } = await axios.get(avatarUrl, {
            responseType: 'arraybuffer',
            timeout: 15000,
            maxContentLength: 10 * 1024 * 1024,
            validateStatus: s => s >= 200 && s < 400
        })

        await activeSock.sendMessage(message.from, {
            image: Buffer.from(data)
        }, { quoted: message._baileyMessage })

    } catch (err) {
        const msg = String(err?.message || err)
        console.error('[FOTOP]', msg)
        await message.reply('❌ Error al obtener la foto de perfil.')
    }
}

handler.help = ['fotop me', 'fotop @usuario', 'fotop 59893900470']
handler.tags = ['herramientas']
handler.command = /^fotop$/i

module.exports = handler
