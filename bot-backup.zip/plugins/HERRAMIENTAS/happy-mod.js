/**
 * Comando: hapk
 * Descripción: Busca APKs modificados en HappyMod
 * Uso: .hapk <nombre del juego/app>
 * Ejemplo: .hapk zombie tsunami
 */

const axios = require('axios');

async function searchHappyMod(query) {
  try {
    console.log('🔍 Buscando en HappyMod:', query);
    
    const apiUrl = `https://www.sankavollerei.com/search/happymod?apikey=planaai&q=${encodeURIComponent(query)}`;
    console.log('🔗 URL de API:', apiUrl);
    
    const response = await axios.get(apiUrl, {
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (response.status === 200 && response.data) {
      console.log('✅ Respuesta recibida de la API');
      
      let resultData = response.data;
      
      // Si es string, parsearlo
      if (typeof resultData === 'string') {
        resultData = JSON.parse(resultData);
      }
      
      console.log('📄 Respuesta API:', JSON.stringify(resultData));
      
      // Validar que la API devolvió status true
      if (!resultData.status) {
        console.error('❌ La API devolvió status false');
        return null;
      }
      
      // Verificar si hay resultados
      if (!resultData.result || resultData.result.length === 0) {
        console.log('⚠️ No se encontraron resultados');
        return { empty: true };
      }
      
      return resultData.result;
    } else {
      console.error('❌ Error en respuesta de API:', response.status);
      return null;
    }
  } catch (error) {
    console.error('❌ Error en searchHappyMod:', error.message);
    if (error.response) {
      console.error('📄 Response status:', error.response.status);
      console.error('📄 Response data:', JSON.stringify(error.response.data).substring(0, 200));
    }
    return null;
  }
}

function formatResults(results, maxResults = 10) {
  if (!results || results.length === 0) {
    return null;
  }
  
  let message = '🎮 *RESULTADOS DE HAPPYMOD* 🎮\n\n';
  
  const limitedResults = results.slice(0, maxResults);
  
  limitedResults.forEach((app, index) => {
    message += `*${index + 1}. ${app.title || app.name || 'Sin nombre'}*\n`;
    
    if (app.rating) {
      message += `⭐ Rating: ${app.rating}\n`;
    }
    
    if (app.version) {
      message += `📦 Versión: ${app.version}\n`;
    }
    
    if (app.size) {
      message += `💾 Tamaño: ${app.size}\n`;
    }
    
    if (app.link || app.url) {
      message += `🔗 Link: ${app.link || app.url}\n`;
    }
    
    message += '\n';
  });
  
  if (results.length > maxResults) {
    message += `_Se encontraron ${results.length} resultados, mostrando los primeros ${maxResults}_`;
  } else {
    message += `_Total: ${results.length} resultado(s)_`;
  }
  
  return message;
}

// Handler principal
let handler = async (message, { text, args }) => {
  try {
    console.log('🚀 Iniciando comando hapk...');
    
    // Validar que se proporcione un texto de búsqueda
    if (!text || text.trim() === '') {
      return await message.reply('❌ *Uso incorrecto*\n\n📝 Debes proporcionar el nombre de la app o juego que deseas buscar.\n\n*Ejemplo:*\n.hapk zombie tsunami\n.hapk minecraft\n.hapk subway surfers');
    }
    
    const query = text.trim();
    console.log('🔎 Búsqueda:', query);
    
    await message.reply('🔍 Buscando en HappyMod...\n_Esto puede tardar unos segundos._');
    
    // Buscar en HappyMod
    const results = await searchHappyMod(query);
    
    if (!results) {
      return await message.reply('❌ Error al buscar en HappyMod.\n\n⚠️ La API puede estar temporalmente no disponible. Intenta nuevamente más tarde.');
    }
    
    // Sin resultados
    if (results.empty) {
      return await message.reply(`❌ No se encontraron resultados para: *${query}*\n\n💡 Intenta con otro nombre o verifica la ortografía.`);
    }
    
    // Formatear y enviar resultados
    const formattedMessage = formatResults(results);
    
    if (!formattedMessage) {
      return await message.reply(`❌ No se pudieron procesar los resultados para: *${query}*`);
    }
    
    await message.reply(formattedMessage);
    
  } catch (error) {
    console.error('❌ Error general en handler hapk:', error);
    console.error('❌ Stack:', error.stack);
    await message.reply('❌ Ocurrió un error al buscar en HappyMod.');
  }
};

// --- Configuración del Handler ---
handler.help = ['hapk'];
handler.tags = ['search', 'tools'];
handler.command = /^(hapk|happymod|apkmod)$/i;

module.exports = handler;