let handler = async (message, { conn, text }) => {
    try {
        if (!text) return await message.reply('❌ Uso: /readmore parte1 | parte2 | parte3 ...');

        // Separar cada bloque por '|'
        let partes = text.split('|').map(p => p.trim()).filter(p => p);

        if (partes.length === 0) return await message.reply('❌ Debes poner al menos un texto');

        // Caracter invisible para "Leer más"
        const more = String.fromCharCode(8206);
        const readMore = more.repeat(4000); // fuerza el "Leer más"

        // Construimos el mensaje con "Leer más" entre cada parte
        let mensajeFinal = partes.join(`\n${readMore}\n`);

        await conn.sendMessage(message.key.remoteJid, { text: mensajeFinal, quoted: message });

    } catch (error) {
        console.error('[CORTO] Error:', error);
        await message.reply('❌ Ocurrió un error al enviar tu mensaje.');
    }
};

handler.help = ['readmore <parte1>|<parte2>|<parte3>'];
handler.tags = ['tools', 'utils'];
handler.command = /^readmore/i;

module.exports = handler;
