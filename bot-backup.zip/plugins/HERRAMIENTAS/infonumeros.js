const axios = require('axios')

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const input = args.join('').trim()

        if (!input) {
            return message.reply('⚠️ Uso: `.infonum +598912345678`')
        }

        // Asegurar que tenga el +
        const numero = input.startsWith('+') ? input : `+${input}`
        const soloDigitos = numero.replace(/\D/g, '')

        // Consultar API
        let info
        try {
            const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/number?q=${encodeURIComponent(numero)}`, { timeout: 10000 })
            if (!data.ok) return message.reply('❌ No se pudo obtener información de ese número.')
            info = data
        } catch {
            return message.reply('❌ Error al consultar la API.')
        }

        const texto = `📱 *Info del Número*\n${'─'.repeat(28)}\n🔢 Número: *${info.number}*\n${info.emoji} País: *${info.country}* (${info.code})\n📶 Tipo: *${info.type}*`

        // Intentar obtener foto de perfil
        const jid = `${soloDigitos}@s.whatsapp.net`
        let avatarUrl = null
        try {
            avatarUrl = await conn.profilePictureUrl(jid, 'image')
        } catch { /* foto privada o no existe */ }

        if (avatarUrl) {
            const { data: imgData } = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 10000 })
            await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: texto
            }, { quoted: message._baileyMessage })
        } else {
            await message.reply(texto + '\n\n_📷 No se pudo obtener la foto de perfil. Posible razón: el usuario no tiene foto o la tiene privada para el bot._')
        }

    } catch (err) {
        console.error('[INFONUM]', err.message)
        await message.reply('❌ Error al procesar el comando.')
    }
}

handler.help = ['infonum +numero']
handler.tags = ['herramientas']
handler.command = /^infonum$/i

module.exports = handler

