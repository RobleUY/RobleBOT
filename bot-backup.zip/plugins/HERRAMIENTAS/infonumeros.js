const { parsePhoneNumberFromString } = require('libphonenumber-js');

let handler = async (message, { conn }) => {
    try {
        const isMention = message.mentions?.length > 0;
        let targetJid;
        let realNumber = null;

        // Obtener número real
        if (isMention) {
            targetJid = message.mentions[0];
            if (message.isGroup) {
                try {
                    const groupMeta = await conn.groupMetadata(message.from);
                    const participant = groupMeta.participants.find(p => p.id === targetJid);
                    if (participant?.jid) {
                        realNumber = participant.jid.split('@')[0];
                    }
                } catch {}
            }
        } else {
            targetJid = message.isGroup ? message.key.participant : message.sender;
            if (message.isGroup) {
                try {
                    const groupMeta = await conn.groupMetadata(message.from);
                    const participant = groupMeta.participants.find(p => p.id === targetJid);
                    if (participant?.jid) {
                        realNumber = participant.jid.split('@')[0];
                    }
                } catch {}
            }
            if (!realNumber) realNumber = targetJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        }

        // Validar número y obtener país
        const phoneNumber = parsePhoneNumberFromString('+' + realNumber);
        if (!phoneNumber || !phoneNumber.isValid()) {
            await message.reply(`❌ El número +${realNumber} no es válido para WhatsApp.`);
            return;
        }

        const countryName = new Intl.DisplayNames(['es'], { type: 'region' }).of(phoneNumber.country);

        // Respuesta final
        await message.reply(`📊 *INFO NÚMERO*\n\n📞 +${realNumber}\n🌐 País: ${countryName || phoneNumber.country}`);

    } catch (err) {
        console.error('[INFONUM] ERROR:', err);
        await message.reply(`❌ Error: ${err.message}`);
    }
};

handler.help = ['infonum @user o número'];
handler.tags = ['info'];
handler.command = /^(infonum)$/i;

module.exports = handler;
