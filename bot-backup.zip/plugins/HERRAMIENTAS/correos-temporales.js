const axios = require('axios')
const fs    = require('fs')
const path  = require('path')

// ── Persistencia en JSON ──────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, 'tempmail_sessions.json')

function loadSessions() {
    try {
        if (fs.existsSync(DB_PATH)) return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
    } catch (_) {}
    return {}
}

function saveSessions(data) {
    try { fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8') } catch (_) {}
}

let sessions = loadSessions()

// ── API Guerrilla Mail ────────────────────────────────────────────────────────
const BASE = 'https://api.guerrillamail.com/ajax.php'
const UA   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

async function newSession() {
    const res = await axios.get(BASE, {
        params:  { f: 'get_email_address', lang: 'en', ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA },
        timeout: 15000
    })
    const d      = res.data
    const cookie = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ')
    return {
        email:     d.email_addr,
        token:     d.sid_token,
        cookie,
        createdAt: Date.now()
    }
}

async function checkInbox(token, cookie) {
    const res = await axios.get(BASE, {
        params:  { f: 'check_email', seq: 0, sid_token: token, ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA, Cookie: cookie },
        timeout: 15000
    })
    return res.data
}

async function fetchMail(mailId, token, cookie) {
    const res = await axios.get(BASE, {
        params:  { f: 'fetch_email', email_id: mailId, sid_token: token, ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA, Cookie: cookie },
        timeout: 15000
    })
    return res.data
}

function stripHtml(html = '') {
    return html
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/\s{3,}/g, '\n')
        .trim()
}

// ── Handler Principal ─────────────────────────────────────────────────────────
let handler = async (message, { args, command }) => {
    const jid = message.sender || message.from
    const sub = (args[0] || '').toLowerCase()
    const sep = '─'.repeat(20)
    const EXPIRATION_TIME = 60 * 60 * 1000 // 60 minutos en ms

    // Verificar si la sesión actual ha expirado
    if (sessions[jid]) {
        const diff = Date.now() - sessions[jid].createdAt
        if (diff > EXPIRATION_TIME) {
            delete sessions[jid]
            saveSessions(sessions)
        }
    }

    // 1. Mostrar ayuda si no hay sub-comando o es "help"
    if (!sub || sub === 'help') {
        return message.reply(
`📧 *MENÚ TEMPORAL MAIL*
${sep}
• *.${command} new* — Crear un correo único
• *.${command} inbox* — Revisar bandeja de entrada
• *.${command} info* — Ver estado del correo actual
• *.${command} delete* — Eliminar sesión actual
${sep}
_Nota: Solo puedes tener 1 correo a la vez. Dura 60 min._`)
    }

    // 2. CREAR CORREO (NEW)
    if (['new', 'nuevo', 'nueva'].includes(sub)) {
        if (sessions[jid]) {
            return message.reply(`⚠️ Ya tienes un correo activo: \`${sessions[jid].email}\`\n\nDebes esperar a que expire o usar *.${command} delete* para crear uno nuevo.`)
        }

        await message.reply('⏳ _Generando tu correo único..._')
        try {
            const sess = await newSession()
            sessions[jid] = sess
            saveSessions(sessions)

            return message.reply(
`📧 *Correo Generado con Éxito*
${sep}
📬 *Email:* \`${sess.email}\`
${sep}
💡 Usa *.${command} inbox* para ver tus mensajes.`)
        } catch (err) {
            return message.reply('❌ Error al conectar con el servidor de correos.')
        }
    }

    // 3. REVISAR BANDEJA (INBOX)
    if (['inbox', 'bandeja', 'check'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No tienes un correo activo. Usa *.tempmail new*')

        const { email, token, cookie } = sessions[jid]
        await message.reply(`🔍 _Consultando mensajes para:_ \`${email}\`...`)

        try {
            const data = await checkInbox(token, cookie)
            const list = (data.list || []).filter(m => m.mail_id && m.mail_id !== '0')

            if (!list.length) return message.reply(`📭 La bandeja de \`${email}\` está vacía.`)

            let txt = `📬 *MENSAJES RECIBIDOS*\n${sep}\n`
            for (let i = 0; i < Math.min(list.length, 5); i++) {
                const m = list[i]
                txt += `📩 *#${i + 1}* | *De:* ${m.mail_from}\n`
                txt += `📋 *Asunto:* ${m.mail_subject}\n`
                txt += `🕒 *Hora:* ${m.mail_date}\n`
                txt += `${sep}\n`
            }
            txt += `_Usa info para ver detalles del tiempo._`
            return message.reply(txt)
        } catch (err) {
            return message.reply('❌ Error al obtener la bandeja.')
        }
    }

    // 4. INFORMACIÓN Y ESTADO (INFO)
    if (['info', 'ver', 'estado'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No tienes un correo activo.')

        const { email, createdAt, token, cookie } = sessions[jid]
        const diff = Date.now() - createdAt
        const restante = Math.max(0, 60 - Math.floor(diff / 60000))
        
        let totalMails = 0
        try {
            const data = await checkInbox(token, cookie)
            totalMails = (data.list || []).length
        } catch (_) {}

        return message.reply(
`📋 *ESTADO DE TU SESIÓN*
${sep}
📬 *Email:* \`${email}\`
📩 *Mensajes:* ${totalMails}
⏳ *Expira en:* ${restante} minutos
${sep}
_Al expirar, podrás crear otro con "new"._`)
    }

    // 5. BORRAR SESIÓN (DELETE)
    if (['delete', 'borrar', 'eliminar'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No hay nada que eliminar.')
        delete sessions[jid]
        saveSessions(sessions)
        return message.reply('🗑️ Sesión eliminada. Ya puedes crear un correo nuevo con *.tempmail new*.')
    }
}

handler.help    = ['tempmail']
handler.tags    = ['herramientas']
handler.command = /^(tempmail|tempemail|emailtemporal|temporalemail|temporalmail|correotem|tempcorreo)$/i

module.exports = handler