const axios = require('axios')
const fs    = require('fs')
const path  = require('path')

// ── Persistencia en JSON ──────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, 'tempmail_sessions.json')

function loadSessions() {
    try {
        if (fs.existsSync(DB_PATH)) return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
    } catch (_) {}
    return {}
}

function saveSessions(data) {
    try { fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8') } catch (_) {}
}

// En memoria (se carga del JSON al iniciar)
let sessions = loadSessions()

// ── API Guerrilla Mail ────────────────────────────────────────────────────────
const BASE = 'https://api.guerrillamail.com/ajax.php'
const UA   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

async function newSession() {
    const res = await axios.get(BASE, {
        params:  { f: 'get_email_address', lang: 'en', ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA },
        timeout: 15000
    })
    const d      = res.data
    const cookie = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ')
    return {
        email:     d.email_addr,
        token:     d.sid_token,
        cookie,
        createdAt: Date.now()
    }
}

async function checkInbox(token, cookie) {
    const res = await axios.get(BASE, {
        params:  { f: 'check_email', seq: 0, sid_token: token, ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA, Cookie: cookie },
        timeout: 15000
    })
    return res.data
}

async function fetchMail(mailId, token, cookie) {
    const res = await axios.get(BASE, {
        params:  { f: 'fetch_email', email_id: mailId, sid_token: token, ip: '0.0.0.0', agent: UA },
        headers: { 'User-Agent': UA, Cookie: cookie },
        timeout: 15000
    })
    return res.data
}

function stripHtml(html = '') {
    return html
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/\s{3,}/g, '\n')
        .trim()
}

// ── Handler ───────────────────────────────────────────────────────────────────
let handler = async (message, { args }) => {
    const jid = message.sender || message.from  // ID único por usuario
    const sub = (args[0] || '').toLowerCase()
    const sep = '─'.repeat(28)

    // ── NEW ──────────────────────────────────────────────────────────
    if (!sub || ['new', 'nuevo', 'nueva'].includes(sub)) {
        await message.reply('⏳ _Generando correo temporal..._')
        try {
            const sess = await newSession()
            sessions[jid] = sess
            saveSessions(sessions)

            return message.reply(
`📧 *Correo Temporal Generado*
${sep}
📬 *Email:* \`${sess.email}\`
${sep}
💡 *Comandos disponibles:*
• *.tempmail inbox* — Ver mensajes recibidos
• *.tempmail ver* — Ver tu correo actual
• *.tempmail new* — Generar otro correo
• *.tempmail delete* — Eliminar tu sesión
${sep}
⚠️ _Expira en ~60 minutos. Cada usuario tiene su propio correo._`)
        } catch (err) {
            console.error('[tempmail:new]', err.message)
            return message.reply('❌ Error al generar el correo. Intenta de nuevo.')
        }
    }

    // ── INBOX ────────────────────────────────────────────────────────
    if (['inbox', 'bandeja', 'mensajes', 'mails', 'check', 'revisar'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No tienes un correo activo.\n\nUsa *.tempmail new* para generar uno.')

        const { email, token, cookie } = sessions[jid]
        await message.reply(`🔍 _Revisando bandeja..._\n📬 *Email:* \`${email}\``)

        try {
            const data = await checkInbox(token, cookie)
            const list = (data.list || []).filter(m => m.mail_id && m.mail_id !== '0')

            if (!list.length) {
                return message.reply(
`📭 *Bandeja vacía*
${sep}
📬 *Email:* \`${email}\`
${sep}
_No hay mensajes aún. Espera y vuelve a revisar._`)
            }

            const recientes = list.slice(0, 5)
            let txt = `📬 *Bandeja de Entrada*\n${sep}\n📧 *Email:* \`${email}\`\n${sep}\n`

            for (let i = 0; i < recientes.length; i++) {
                const m = recientes[i]
                let cuerpo = stripHtml(m.mail_excerpt || '').slice(0, 400)
                try {
                    const full = await fetchMail(m.mail_id, token, cookie)
                    cuerpo = stripHtml(full.mail_body || full.mail_html || m.mail_excerpt || '').slice(0, 400)
                } catch (_) {}

                txt += `📩 *Mensaje ${i + 1}*\n`
                txt += `👤 *De:* ${m.mail_from || 'Desconocido'}\n`
                txt += `📋 *Asunto:* ${m.mail_subject || '(Sin asunto)'}\n`
                txt += `🕒 *Fecha:* ${m.mail_date || 'N/A'}\n`
                txt += `💬 *Contenido:*\n${cuerpo || '(vacío)'}${cuerpo.length >= 400 ? '...' : ''}\n`
                txt += `${sep}\n`
            }

            txt += `_📊 Total de mensajes: ${list.length}_`
            return message.reply(txt)

        } catch (err) {
            console.error('[tempmail:inbox]', err.message)
            return message.reply('❌ Error al revisar la bandeja. Intenta de nuevo.')
        }
    }

    // ── VER ──────────────────────────────────────────────────────────
    if (['ver', 'show', 'email', 'correo', 'cual', 'cuál'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No tienes un correo activo.\n\nUsa *.tempmail new* para generar uno.')

        const { email, createdAt } = sessions[jid]
        const mins = Math.floor((Date.now() - (createdAt || 0)) / 60000)
        const restante = Math.max(0, 60 - mins)

        return message.reply(
`📧 *Tu correo temporal:*
${sep}
📬 \`${email}\`
⏳ *Tiempo restante aprox:* ${restante} min
${sep}
• *.tempmail inbox* — Ver mensajes
• *.tempmail new* — Generar otro`)
    }

    // ── DELETE ───────────────────────────────────────────────────────
    if (['delete', 'borrar', 'eliminar', 'reset'].includes(sub)) {
        if (!sessions[jid]) return message.reply('⚠️ No tienes ninguna sesión activa.')
        delete sessions[jid]
        saveSessions(sessions)
        return message.reply('🗑️ _Tu sesión fue eliminada._\n\nUsa *.tempmail new* para generar uno nuevo.')
    }

    // ── AYUDA ────────────────────────────────────────────────────────
    return message.reply(
`📧 *Correo Temporal — Ayuda*
${sep}
• *.tempmail new* — Generar tu correo
• *.tempmail inbox* — Ver tus mensajes
• *.tempmail ver* — Ver tu correo + tiempo restante
• *.tempmail delete* — Eliminar tu sesión
${sep}
_Alias válidos:_
.tempemail · .emailtemporal · .temporalemail · .temporalmail · .correotem`)
}

handler.help    = ['tempmail [new|inbox|ver|delete]']
handler.tags    = ['herramientas']
handler.command = /^(tempmail|tempemail|emailtemporal|temporalemail|temporalmail|correotem|tempcorreo)$/i

module.exports = handler