/**
 * Comando: tav
 * Descripción: Convierte texto a voz usando RobleAPI con voces personalizadas
 * Uso: .tav <nombre_voz> <texto>
 * Ejemplo: .tav elon musk Hola a todos
 *          .tav elon-musk Hola a todos
 *          .tav elonmusk Hola a todos
 */

const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

/* --------------------------- VOCES (nombres limpios para mostrar) --------------------------- */
const VOICE_DISPLAY_NAMES = [
  "Nahida",
  "Nami",
  "Ana",
  "Optimus Prime",
  "Goku",
  "Elon Musk",
  "Mickey Mouse",
  "Kendrick Lamar",
  "Eminem"
];

/* --------------------------- CÓDIGOS HTTP REINTENTABLES --------------------------- */
const RETRYABLE_STATUS_CODES = new Set([429, 502, 503, 504]);

/* --------------------------- UTILIDADES --------------------------- */
function tmpFileName(ext = '') {
  const name = crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Normaliza: minúsculas, sin tildes, sin guiones/guiones bajos/espacios ni paréntesis
 * Ejemplo: "Elon-Musk" → "elonmusk"  |  "Nahida (Exclusive)" → "nahida"
 */
function normalize(str) {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')  // quita tildes
    .replace(/\(.*?\)/g, '')          // quita paréntesis y contenido
    .replace(/[-_\s]+/g, '')          // quita guiones, guiones bajos y espacios
    .replace(/[^a-z0-9]/g, '')        // quita caracteres especiales
    .trim();
}

/**
 * Busca la voz cuyo nombre normalizado esté al inicio del input.
 * Soporta: "elonmusk", "elon-musk", "elon_musk", "elon musk"
 * Devuelve { displayName, normName, rest } o null.
 */
function detectVoice(input) {
  const normInput = normalize(input);

  const sorted = [...VOICE_DISPLAY_NAMES].sort(
    (a, b) => normalize(b).length - normalize(a).length
  );

  for (const displayName of sorted) {
    const normVoice = normalize(displayName);
    if (normInput.startsWith(normVoice)) {
      let voiceCharsLeft = normVoice.length;
      let i = 0;

      while (i < input.length && voiceCharsLeft > 0) {
        const ch = input[i].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        if (/[a-z0-9]/.test(ch)) voiceCharsLeft--;
        i++;
      }

      while (i < input.length && /[-_\s]/.test(input[i])) i++;

      const rest = input.slice(i).trim();
      if (rest.length > 0) return { displayName, normName: normVoice, rest };
    }
  }
  return null;
}

/**
 * Busca en la lista de voces de la API la que mejor coincide con el nombre detectado.
 */
function matchApiVoice(voices, normName) {
  for (const v of voices) {
    if (normalize(v.voice_name) === normName) return v;
  }
  for (const v of voices) {
    if (normalize(v.voice_name).startsWith(normName)) return v;
  }
  return null;
}

/* --------------------------- FETCH CON RETRY --------------------------- */
/**
 * Hace fetch con reintentos automáticos en caso de errores temporales (429, 502, 503, 504).
 * @param {string} url
 * @param {object} options     - opciones de fetch
 * @param {number} maxRetries  - cantidad máxima de reintentos (default 5)
 * @param {number} baseDelay   - delay base en ms entre reintentos (default 1500)
 * @param {string} label       - etiqueta para logs (default 'fetch')
 */
async function fetchWithRetry(url, options = {}, maxRetries = 5, baseDelay = 1500, label = 'fetch') {
  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await fetch(url, options);

      if (RETRYABLE_STATUS_CODES.has(res.status)) {
        const delay = baseDelay * attempt; // backoff progresivo
        console.warn(`⚠️ [${label}] HTTP ${res.status} en intento ${attempt}/${maxRetries}, reintentando en ${delay}ms...`);
        lastError = new Error(`HTTP_RETRYABLE_${res.status}`);
        if (attempt < maxRetries) await sleep(delay);
        continue;
      }

      if (!res.ok) throw new Error(`HTTP_FATAL_${res.status}`);

      return res;

    } catch (err) {
      // Si es un error fatal (4xx no reintentable), lo propagamos de inmediato
      if (err.message.startsWith('HTTP_FATAL_')) throw err;

      // Error de red u otro error reintentable
      lastError = err;
      const delay = baseDelay * attempt;
      console.warn(`⚠️ [${label}] Error en intento ${attempt}/${maxRetries}: ${err.message}, reintentando en ${delay}ms...`);
      if (attempt < maxRetries) await sleep(delay);
    }
  }

  throw lastError || new Error(`[${label}] no disponible tras ${maxRetries} intentos`);
}

/* --------------------------- LLAMADA A LA API --------------------------- */
async function fetchVoiceUrl(text, normName) {
  const encoded = encodeURIComponent(text);
  const url = `https://robleuy.vercel.app/robleapi/tools/tts?q=${encoded}&lang=es`;

  const res = await fetchWithRetry(url, {}, 5, 1500, 'RobleAPI');
  const json = await res.json();

  if (!json.ok || !Array.isArray(json.voices)) throw new Error('Respuesta inválida de RobleAPI');

  const matched = matchApiVoice(json.voices, normName);
  if (!matched) throw new Error('Voz no encontrada en la respuesta de la API');

  return matched.url;
}

/* --------------------------- DESCARGA DEL AUDIO --------------------------- */
async function downloadAudio(audioUrl) {
  const res = await fetchWithRetry(audioUrl, {}, 5, 1500, 'DescargaAudio');
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

/* --------------------------- CONVERSIÓN A OPUS --------------------------- */
async function convertToOpus(inputBuffer) {
  const tempIn  = tmpFileName('wav');
  const tempOut = tmpFileName('opus');

  try {
    await fs.writeFile(tempIn, inputBuffer);

    const args = [
      '-y',
      '-i', tempIn,
      '-ar', '48000',
      '-ac', '1',
      '-c:a', 'libopus',
      '-b:a', '64k',
      '-vbr', 'on',
      tempOut
    ];

    await execFileAsync('ffmpeg', args, { windowsHide: true });
    return await fs.readFile(tempOut);
  } finally {
    await fs.unlink(tempIn).catch(() => {});
    await fs.unlink(tempOut).catch(() => {});
  }
}

/* --------------------------- ENVIAR AUDIO --------------------------- */
async function sendAudio(sock, jid, audioBuffer, isPTT = true, quoted = null) {
  try {
    const options = {
      audio: audioBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: isPTT
    };
    if (quoted) options.quoted = quoted;

    await sock.sendMessage(jid, options);
    console.log('✅ Audio enviado correctamente');
    return true;
  } catch (err) {
    console.error('❌ Error al enviar audio:', err);
    return false;
  }
}

/* --------------------------- LISTA DE VOCES --------------------------- */
function voiceListText() {
  return VOICE_DISPLAY_NAMES.map((v, i) => `  ${i + 1}. ${v}`).join('\n');
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message, { text }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: conexión no disponible.');

    if (!text || !text.trim()) {
      return await message.reply(
        '*🗣️ TEXTO A VOZ CON VOCES*\n\n' +
        '💡 *Uso:*\n' +
        '• *.tav <nombre_voz> <texto>*\n\n' +
        '🎙️ *Voces disponibles:*\n' +
        voiceListText() + '\n\n' +
        '📌 *Ejemplos:*\n' +
        '• _.tav elonmusk Hola a todos_\n' +
        '• _.tav elon-musk Hola a todos_\n' +
        '• _.tav elon_musk Hola a todos_\n' +
        '• _.tav elon musk Hola a todos_\n' +
        '• _.tav goku Esto es un Kamehameha_'
      );
    }

    const input = text.trim();
    const detected = detectVoice(input);

    if (!detected) {
      return await message.reply(
        '❓ *No reconocí el nombre de la voz.*\n\n' +
        '🎙️ *Voces disponibles:*\n' +
        voiceListText() + '\n\n' +
        '📌 *Ejemplo:* _.tav elonmusk Tu texto aquí_'
      );
    }

    let { displayName, normName, rest: content } = detected;

    if (content.length > 1000) {
      content = content.slice(0, 1000);
      await message.reply('⚠️ Texto recortado a 1000 caracteres.');
    }

    await message.reply(`⏳ Generando audio con la voz de *${displayName}*...`);

    // 1. Llamar a RobleAPI → obtener URL del audio (con retry)
    const audioUrl = await fetchVoiceUrl(content, normName);
    console.log(`🎙️ URL de audio obtenida: ${audioUrl}`);

    // 2. Descargar el WAV desde la URL (con retry)
    const wavBuffer = await downloadAudio(audioUrl);
    console.log(`📦 Audio descargado: ${wavBuffer.length} bytes`);

    // 3. Convertir WAV → OGG Opus para WhatsApp
    const opusBuffer = await convertToOpus(wavBuffer);

    if (!opusBuffer) return await message.reply('❌ Error al procesar el audio.');

    const ok = await sendAudio(sock, message.from, opusBuffer, true, message);
    if (!ok) return await message.reply('❌ Error al enviar el audio.');

  } catch (err) {
    console.error('❌ Error general en comando TAV:', err);

    const msg = err.message || '';

    if (msg.includes('HTTP_RETRYABLE') || msg.includes('no disponible')) {
      return await message.reply('⚠️ El servidor de voces está ocupado, intentá de nuevo en unos segundos.');
    }
    if (msg.includes('HTTP_FATAL_404')) {
      return await message.reply('❌ No se encontró el audio generado (404). Intentá con otro texto.');
    }
    if (msg.includes('HTTP_FATAL_')) {
      return await message.reply('❌ Error del servidor al generar el audio. Intentá más tarde.');
    }

    await message.reply('❌ Ocurrió un error al generar el audio.');
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['tav'];
handler.tags = ['audio'];
handler.command = /^(tav)$/i;
module.exports = handler;