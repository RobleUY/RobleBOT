/**
 * Comando: tav
 * Descripción: Convierte texto a voz natural (voz masculina, un poco más rápida)
 * Uso: .tav <texto>
 */
const gtts = require('node-gtts');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/* --------------------------- FUNCIÓN PRINCIPAL --------------------------- */
async function textToSpeech(text) {
  const tempMp3 = tmpFileName('mp3');
  const tempOpus = tmpFileName('opus');
  
  // gtts('es') por defecto usa la voz masculina
  const tts = gtts('es'); 
  
  try {
    // Generar MP3 con Google TTS
    await new Promise((resolve, reject) => {
      tts.save(tempMp3, text, (err) => (err ? reject(err) : resolve()));
    });
    
    // Convertir MP3 → OGG (opus) y AUMENTAR LA VELOCIDAD (atempo=1.2)
    const args = [
      '-y',
      '-i', tempMp3,
      '-filter:a', 'atempo=1.2', // Aumenta la velocidad un 20%
      '-ar', '48000',           // frecuencia estándar para WhatsApp
      '-ac', '1',               // mono
      '-c:a', 'libopus',
      '-b:a', '64k',
      '-vbr', 'on',
      tempOpus
    ];
    
    await execFileAsync('ffmpeg', args, { windowsHide: true });
    const audioBuffer = await fs.readFile(tempOpus);
    return audioBuffer;
    
  } finally {
    await fs.unlink(tempMp3).catch(() => {});
    await fs.unlink(tempOpus).catch(() => {});
  }
}

/* --------------------------- ENVIAR AUDIO --------------------------- */
async function sendAudio(sock, jid, audioBuffer, isPTT = true, quoted = null) {
  try {
    const options = {
      audio: audioBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: isPTT
    };
    
    // Si hay un mensaje citado, agregarlo
    if (quoted) {
      options.quoted = quoted;
    }
    
    await sock.sendMessage(jid, options);
    console.log('✅ Audio enviado correctamente');
    return true;
  } catch (err) {
    console.error('❌ Error al enviar audio:', err);
    return false;
  }
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message, { text, command }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: conexión no disponible.');
    
    if (!text || !text.trim()) {
      return await message.reply(
        '*🗣️ TEXTO A VOZ*\n\n' +
        '💡 *Uso:*\n' +
        '• *.tav <texto>*\n\n' +
        '⚠️ Máximo 1000 caracteres.'
      );
    }
    
    let content = text.trim();
    if (content.length > 1000) {
      content = content.slice(0, 1000);
      await message.reply('⚠️ Texto recortado a 1000 caracteres.');
    }
    
    // Enviar mensaje de "Generando audio..." SIN el texto
    const loadingMsg = await message.reply('⏳ Generando audio...');
    
    const audioBuffer = await textToSpeech(content);
    if (!audioBuffer) return await message.reply('❌ Error al generar el audio.');
    
    // Enviar el audio como respuesta al comando original
    const ok = await sendAudio(sock, message.from, audioBuffer, true, message);
    if (!ok) return await message.reply('❌ Error al enviar el audio.');
    
  } catch (err) {
    console.error('❌ Error general en comando TTS:', err);
    await message.reply('❌ Ocurrió un error al generar el audio.');
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['tav'];
handler.tags = ['audio'];
handler.command = /^(tav)$/i;

module.exports = handler;