const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await conn.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.ptstalk <usuario>`')

    try {
        const { data } = await axios.get(`https://www.robleuy.site/robleapi/stalk/pinterest?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `📌 *Pinterest*\n${'─'.repeat(28)}\n👤 Usuario: *@${data.username}*\n📛 Nombre: *${data.full_name}*\n📝 Bio: ${data.biography || 'Sin bio'}\n📌 Pins: *${data.pins}*\n👥 Seguidores: *${data.followers}*\n➡️ Siguiendo: *${data.following}*\n🗂️ Tableros: *${data.boards}*\n✅ Verificado: ${data.verified ? 'Sí' : 'No'}\n🔗 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_picture || data.profile_pic || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['ptstalk <usuario>', 'pintereststalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(ptstalk|pintereststalk)$/i

module.exports = handler
