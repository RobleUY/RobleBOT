const axios = require('axios');

let handler = async (message, { conn, args }) => {
    try {
        const channel = args[0];
        if (!channel) {
            return await message.reply('⚠️ Uso correcto: /ytstalk <canal>\n\nEjemplo: `/ytstalk mcrobleuy`');
        }

        const apiUrl = `https://delirius-apiofc.vercel.app/tools/ytstalk?channel=${encodeURIComponent(channel)}`;

        let apiRes;
        try {
            apiRes = await axios.get(apiUrl, { timeout: 15000 });
        } catch {
            return await message.reply('❌ No se pudo conectar con la API. Intenta nuevamente más tarde.');
        }

        const body = apiRes.data;

        // Si la API respondió correctamente pero la cuenta no existe
        if (!body || body.status !== true || !body.data) {
            return await message.reply('❌ No se encontró información de ese canal. Verifica que el nombre sea correcto.');
        }

        const data = body.data;

        // URL corta del canal
        const shortUrl = data.username
            ? `https://www.youtube.com/${data.username}`
            : (data.channel || '-');

        const info = [
            `🎥 *${data.username || 'Canal desconocido'}*`,
            '',
            `🔗 Canal: ${shortUrl}`,
            `👥 Suscriptores: ${data.subscriber_count || '0'}`,
            `🎬 Videos: ${data.video_count || '0'}`,
            '',
            `📝 *Descripción:*`,
            `${data.description && data.description !== '-' ? data.description : 'Sin descripción disponible.'}`,
        ].join('\n');

        // Descargar avatar
        const avatarUrl = data.avatar || null;
        let buffer = null;
        if (avatarUrl) {
            try {
                const picRes = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 15000 });
                buffer = Buffer.from(picRes.data);
            } catch {
                buffer = null;
            }
        }

        if (buffer) {
            await conn.sendMessage(message.from, { image: buffer, caption: info, quoted: message });
        } else {
            await conn.sendMessage(message.from, { text: info, quoted: message });
        }

    } catch (error) {
        console.error('[ytstalk] Ocurrió un error:', error.message || error);
        try { 
            await message.reply('❌ Ocurrió un error al obtener los datos del canal de YouTube.'); 
        } catch {}
    }
};

handler.help = ['ytstalk <canal>', 'yt <canal>'];
handler.tags = ['tools'];
handler.command = /^(ytstalk)$/i;

module.exports = handler;
