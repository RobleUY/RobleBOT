const axios = require('axios')

const YT_API_KEY = process.env.YOUTUBE_API_KEY || '';

// Formatear números grandes: 1200000 → "1.2M", 663000 → "663K"
function formatNum(n) {
    if (!n) return 'Oculto'
    n = parseInt(n)
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace('.0', '') + 'M'
    if (n >= 1_000)     return (n / 1_000).toFixed(1).replace('.0', '') + 'K'
    return n.toString()
}

// Formatear fecha → "15 de abril de 2026"
function formatDate(iso) {
    if (!iso) return 'N/A'
    const d = new Date(iso)
    return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })
}

// Resolver handle (@usuario), URL o ID de canal → channelId
async function resolveChannel(input) {
    // Limpiar input: quitar https://youtube.com/@, espacios, etc.
    input = input.trim().replace(/^https?:\/\/(www\.)?youtube\.com\//i, '')

    // Si ya es un ID de canal (empieza con UC y tiene 24 chars)
    if (/^UC[\w-]{22}$/.test(input)) return input

    // Si es @handle o handle sin @
    const handle = input.startsWith('@') ? input : `@${input}`

    const { data } = await axios.get('https://www.googleapis.com/youtube/v3/channels', {
        params: { part: 'id', forHandle: handle.replace('@', ''), key: YT_API_KEY },
        timeout: 10000
    })
    if (data.items?.length) return data.items[0].id

    // Fallback: buscar por nombre
    const { data: search } = await axios.get('https://www.googleapis.com/youtube/v3/search', {
        params: { part: 'snippet', type: 'channel', q: input, maxResults: 1, key: YT_API_KEY },
        timeout: 10000
    })
    if (search.items?.length) return search.items[0].snippet.channelId

    return null
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const input = args.join(' ').trim()
    if (!input) return message.reply('⚠️ Uso: `.ytstalk <@usuario o nombre>`\n\nEjemplos:\n• `.ytstalk @Blon`\n• `.ytstalk MrBeast`')

    await message.reply('🔍 _Buscando canal de YouTube..._')

    try {
        // 1. Resolver el canal
        const channelId = await resolveChannel(input)
        if (!channelId) return message.reply('❌ No se encontró ningún canal con ese nombre o usuario.')

        // 2. Info del canal
        const { data: chanData } = await axios.get('https://www.googleapis.com/youtube/v3/channels', {
            params: {
                part: 'snippet,statistics,brandingSettings',
                id: channelId,
                key: YT_API_KEY
            },
            timeout: 10000
        })

        if (!chanData.items?.length) return message.reply('❌ Canal no encontrado.')
        const ch  = chanData.items[0]
        const sn  = ch.snippet
        const st  = ch.statistics
        const br  = ch.brandingSettings?.channel || {}

        const nombre      = sn.title || 'N/A'
        const handle      = sn.customUrl ? `@${sn.customUrl.replace('@','')}` : 'N/A'
        const descripcion = (sn.description || 'Sin descripción').split('\n')[0].substring(0, 120)
        const pais        = sn.country || 'No especificado'
        const creacion    = formatDate(sn.publishedAt)
        const subs        = formatNum(st.subscriberCount)
        const videos      = st.videoCount ? parseInt(st.videoCount).toLocaleString('es-ES') : 'N/A'
        const vistas      = formatNum(st.viewCount)
        const subsOcultos = st.hiddenSubscriberCount

        // 3. Avatar
        const avatarUrl = sn.thumbnails?.high?.url || sn.thumbnails?.default?.url || null

        const sep = '─'.repeat(28)
        const txt =
`▶️ *YouTube — Perfil*
${sep}
👤 *Canal:* ${nombre}
🔗 *Handle:* ${handle}
🌎 *País:* ${pais}
📅 *Creado:* ${creacion}
${sep}
👥 *Suscriptores:* ${subsOcultos ? '_Ocultos_' : subs}
🎬 *Videos:* ${videos}
👁️ *Vistas totales:* ${vistas}
${sep}
📝 *Descripción:* ${descripcion}
${sep}
🔗 https://youtube.com/${handle}`

        // Enviar con foto de perfil
        if (avatarUrl) {
            try {
                const { data: imgData } = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 10000 })
                return await sock.sendMessage(message.from, {
                    image: Buffer.from(imgData),
                    caption: txt
                }, { quoted: message._baileyMessage })
            } catch { /* cae al texto */ }
        }
        return message.reply(txt + '\n\n_📷 No se pudo obtener la foto del canal._')

    } catch (err) {
        if (err.response?.status === 403) return message.reply('❌ API key inválida o sin permisos. Verificá tu clave.')
        if (err.response?.status === 429) return message.reply('❌ Límite diario de la API alcanzado. Intentá mañana.')
        console.error('[ytstalk]', err.message)
        return message.reply('❌ Error al buscar el canal. Intentá de nuevo.')
    }
}

handler.help = ['ytstalk <@usuario o nombre>', 'youtubestalk <@usuario o nombre>']
handler.tags = ['herramientas']
handler.command = /^(ytstalk|youtubestalk)$/i

module.exports = handler
