const axios = require('axios');

let handler = async (message, { conn, args }) => {
    // Compatibilidad con la estructura de tu bot (Baileys)
    const sock = conn || message._sock || global.conn;
    const username = args[0];

    if (!username) return message.reply('⚠️ Uso: `.rxstalk <usuario>`\n\nEjemplo: `.rxstalk builderman`');

    await message.reply('🔍 _Buscando perfil de Roblox..._');

    try {
        // 1. La API de Roblox necesita el ID, así que primero convertimos el Username a ID
        const { data: idData } = await axios.post('https://users.roblox.com/v1/usernames/users', {
            usernames: [username],
            excludeBannedUsers: false
        });

        // Si el array de datos viene vacío, el usuario no existe
        if (!idData.data || idData.data.length === 0) {
            return message.reply('❌ No se encontró ningún usuario con ese nombre en Roblox.');
        }

        const userId = idData.data[0].id;
        const actualUsername = idData.data[0].name;
        const displayName = idData.data[0].displayName;

        // 2. Con el ID obtenido, buscamos la información detallada del perfil
        const { data: userInfo } = await axios.get(`https://users.roblox.com/v1/users/${userId}`);
        
        // 3. Y con el mismo ID, obtenemos la imagen del avatar en alta resolución (720x720)
        const { data: avatarData } = await axios.get(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=720x720&format=Png&isCircular=false`);
        const avatarUrl = avatarData.data[0]?.imageUrl;

        // Formateamos la fecha de creación al español
        const createdDate = new Date(userInfo.created).toLocaleDateString('es-ES', {
            year: 'numeric', month: 'long', day: 'numeric'
        });
        
        const bio = userInfo.description || 'Sin descripción';
        const isBanned = userInfo.isBanned ? 'Sí 🚫' : 'No ✅';

        // Estructura del mensaje final
        const sep = '─'.repeat(25);
        const txt = `
🟦 *Roblox — Perfil*
${sep}
👤 *Usuario:* ${actualUsername}
🏷️ *Display Name:* ${displayName}
🆔 *ID:* ${userId}
${sep}
📅 *Cuenta creada:* ${createdDate}
🔨 *Baneado:* ${isBanned}
${sep}
✍️ *Bio:*
${bio}`.trim();

        // Si tenemos URL de avatar, la enviamos con el texto
        if (avatarUrl) {
            try {
                const { data: imgData } = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
                return await sock.sendMessage(message.from, {
                    image: Buffer.from(imgData),
                    caption: txt
                }, { quoted: message._baileyMessage });
            } catch (err) { 
                /* Si falla la descarga de la imagen, pasa al texto simple */ 
            }
        }
        
        // Si no hay imagen o falló la descarga, enviamos solo texto
        return message.reply(txt + '\n\n_📷 No se pudo cargar el avatar._');

    } catch (err) {
        console.error('[rxstalk]', err.message);
        return message.reply('❌ Ocurrió un error al consultar los servidores de Roblox. Intenta de nuevo más tarde.');
    }
}

// Configuración de comandos del bot
handler.help = ['rxstalk <usuario>', 'robloxstalk <usuario>'];
handler.tags = ['herramientas'];
handler.command = /^(rxstalk|robloxstalk)$/i;

module.exports = handler;