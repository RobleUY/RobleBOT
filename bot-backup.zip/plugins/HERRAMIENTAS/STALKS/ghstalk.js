const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.ghstalk <usuario>`')

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/github?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `🐙 *GitHub*\n${'─'.repeat(28)}\n👤 Usuario: *${data.username}*\n🏷️ Tipo: *${data.type}*\n📝 Bio: ${data.bio || 'Sin bio'}\n📦 Repos públicos: *${data.public_repos ?? data.public_repo ?? 0}*\n👥 Seguidores: *${data.followers}*\n➡️ Siguiendo: *${data.following}*${data.location ? `\n📍 Ubicación: ${data.location}` : ''}${data.blog ? `\n🌐 Web: ${data.blog}` : ''}\n🔗 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_pic || data.profile_picture || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['ghstalk <usuario>', 'githubstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(ghstalk|githubstalk)$/i

module.exports = handler

