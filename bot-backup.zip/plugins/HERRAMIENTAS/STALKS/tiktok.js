const axios = require('axios');

let handler = async (message, { conn, args }) => {
    try {
        const username = args[0];
        if (!username) {
            return await message.reply('⚠️ Uso correcto: /ttstalk <usuario>\n\nEjemplo: `/ttstalk robleuy`');
        }

        const apiUrl = `https://delirius-apiofc.vercel.app/tools/tiktokstalk?q=${encodeURIComponent(username)}`;
        const apiRes = await axios.get(apiUrl, { timeout: 15000 });
        const body = apiRes.data;

        if (!body || body.status !== true || !body.result) {
            return await message.reply('❌ No se encontró esa cuenta.');
        }

        const users = body.result.users || {};
        const stats = body.result.stats || {};

        const info = [
            `*${users.nickname || '-'}* (@${users.username || username})`,
            '',
            `🔗 Perfil: ${users.url || ('https://www.tiktok.com/@' + (users.username || username))}`,
            `📝 Bio: ${users.signature || '-'}`,
            `🔒 Privada: ${typeof users.privateAccount !== 'undefined' ? (users.privateAccount ? 'Sí' : 'No') : '-'}`,
            `✅ Verificada: ${typeof users.verified !== 'undefined' ? (users.verified ? 'Sí' : 'No') : '-'}`,
            '',
            `📊 Estadísticas:`,
            `👥 Seguidores: ${stats.followerCount ?? '0'}`,
            `➡️ Siguiendo: ${stats.followingCount ?? '0'}`,
            `❤️ Corazones: ${stats.heartCount ?? '0'}`,
            `🎬 Videos: ${stats.videoCount ?? '0'}`,
            `👤 Amigos: ${stats.friendCount ?? '0'}`,
        ].join('\n');

        // Intentar descargar avatar (avatarLarger > avatarMedium > avatarThumb)
        const avatarUrl = users.avatarLarger || users.avatarMedium || users.avatarThumb || null;
        let buffer = null;
        if (avatarUrl) {
            try {
                const picRes = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 15000 });
                buffer = Buffer.from(picRes.data);
            } catch (e) {
                buffer = null; // si falla la descarga, enviamos solo texto
            }
        }

        if (buffer) {
            await conn.sendMessage(
                message.from,
                { image: buffer, caption: info, quoted: message }
            );
        } else {
            await conn.sendMessage(message.from, { text: info, quoted: message });
        }

    } catch (error) {
        console.error('[ERROR] tt:', error);
        try { await message.reply('❌ Error al obtener información de TikTok.'); } catch {}
    }
};

handler.help = ['tt <usuario>', 'ttstalk <usuario>'];
handler.tags = ['tools'];
handler.command = /^(tt|ttstalk)$/i;

module.exports = handler;
