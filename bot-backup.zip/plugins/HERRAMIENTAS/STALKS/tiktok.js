const axios = require('axios')

let handler = async (message, { conn, args }) => {
    try {
        const username = args[0]
        if (!username)
            return message.reply('⚠️ Uso: /ttstalk <usuario>\nEjemplo: /ttstalk robleuy')

        const res = await axios.get(`https://www.robleuy.site/robleapi/stalk/tiktok?q=${encodeURIComponent(username)}`, { timeout: 15000 })
        const d = res.data

        if (!d?.ok) return message.reply('❌ No se encontró esa cuenta.')

        const info = [
            `*${d.nickname || '-'}* (@${d.username})`,
            `🔗 ${d.url}`,
            '',
            `📝 Bio: ${d.biography || '-'}`,
            `🔒 Privada: ${d.private ? 'Sí' : 'No'}`,
            `✅ Verificada: ${d.verified ? 'Sí' : 'No'}`,
            `👥 Seguidores: ${d.followers || '0'}`,
            `➡️ Siguiendo: ${d.following || '0'}`,
            `❤️ Likes: ${d.likes || '0'}`
        ].join('\n')

        let buffer = null
        try {
            if (d.avatar) {
                const picRes = await axios.get(d.avatar, { responseType: 'arraybuffer', timeout: 15000 })
                buffer = Buffer.from(picRes.data)
            }
        } catch { }

        if (buffer) {
            return await conn.sendMessage(message.from, {
                image: buffer,
                caption: info
            }, { quoted: message._baileyMessage })
        }

        return await message.reply(info + '\n\n_📷 No se pudo obtener la foto de perfil._')

    } catch (err) {
        console.error('[TTSTALK]', err.message)
        await message.reply('❌ Error al obtener info de TikTok.')
    }
}

handler.help = ['ttstalk <usuario>']
handler.tags = ['tools']
handler.command = /^(tt|ttstalk)$/i

module.exports = handler
