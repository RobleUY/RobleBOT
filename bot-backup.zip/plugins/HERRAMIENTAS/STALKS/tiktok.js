const axios = require('axios')
const cheerio = require('cheerio')
const puppeteer = (() => {
    try {
        return require('puppeteer')
    } catch {
        return null
    }
})()

function normalizeCount(value) {
    if (value === null || value === undefined || value === '') return 0
    if (typeof value === 'number') return value
    const cleaned = String(value).trim().replace(/[^\d.]/g, '')
    return Number(cleaned) || 0
}

function normalizeUsername(username) {
    let value = String(username || '').trim()
    if (!value) return ''

    if (/^https?:\/\//i.test(value)) {
        try {
            const { pathname } = new URL(value)
            const parts = pathname.split('/').filter(Boolean)
            if (parts[0] === '@') return parts[1] || ''
            return parts[0] || ''
        } catch {
            return value.replace(/^@/, '').split(/[?#]/)[0]
        }
    }

    return value.replace(/^@/, '').split(/[?#]/)[0].trim()
}

function decodeJsonValue(value) {
    if (value === null || value === undefined) return ''
    return String(value)
        .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
        .replace(/\\n/g, ' ')
        .replace(/\\r/g, ' ')
        .replace(/\\t/g, ' ')
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, '\\')
        .trim()
}

function parseTikTokProfile(html, username) {
    if (!html) return null

    const user = {}
    const patterns = [
        ['uniqueId', /"uniqueId"\s*:\s*"([^"]*)"/i],
        ['username', /"username"\s*:\s*"([^"]*)"/i],
        ['nickname', /"nickname"\s*:\s*"([^"]*)"/i],
        ['displayName', /"displayName"\s*:\s*"([^"]*)"/i],
        ['bioDescription', /"bioDescription"\s*:\s*"([^"]*)"/i],
        ['biography', /"biography"\s*:\s*"([^"]*)"/i],
        ['bio', /"bio"\s*:\s*"([^"]*)"/i],
        ['followerCount', /"followerCount"\s*:\s*(\d+)/i],
        ['followingCount', /"followingCount"\s*:\s*(\d+)/i],
        ['heartCount', /"heartCount"\s*:\s*(\d+)/i],
        ['likes', /"likes"\s*:\s*(\d+)/i],
        ['avatarLarger', /"avatarLarger"\s*:\s*"([^"]*)"/i],
        ['avatarMedium', /"avatarMedium"\s*:\s*"([^"]*)"/i],
        ['avatarThumb', /"avatarThumb"\s*:\s*"([^"]*)"/i],
        ['avatar', /"avatar"\s*:\s*"([^"]*)"/i],
        ['verified', /"verified"\s*:\s*(true|false)/i],
        ['private', /"private"\s*:\s*(true|false)/i]
    ]

    for (const [key, regex] of patterns) {
        const match = html.match(regex)
        if (match) {
            const value = decodeJsonValue(match[1] ?? match[0])
            if (value !== '') {
                user[key] = value === 'true' || value === 'false' ? value === 'true' : value
            }
        }
    }

    if (!Object.keys(user).length) {
        try {
            const $ = cheerio.load(html)
            const title = $('meta[property="og:title"]').attr('content') || ''
            const description = $('meta[name="description"]').attr('content') || ''
            const nickname = title.split('(@')[0]?.trim() || ''
            const bio = description.replace(/\s+/g, ' ').trim() || ''
            if (nickname || bio) {
                user.uniqueId = normalizeUsername(username)
                user.nickname = nickname
                user.bioDescription = bio
                user.followerCount = 0
                user.followingCount = 0
                user.heartCount = 0
                user.verified = false
                user.private = false
                user.avatarLarger = null
            }
        } catch { }
    }

    if (!user.uniqueId && !user.nickname && !user.bioDescription && !user.avatarLarger && !user.avatarMedium && !user.avatarThumb && !user.avatar) {
        return null
    }

    return {
        ok: true,
        username: normalizeUsername(user.uniqueId || user.username || username),
        nickname: user.nickname || user.displayName || user.uniqueId || username || '-',
        biography: user.bioDescription || user.biography || user.bio || '-',
        followers: normalizeCount(user.followerCount || user.followersCount || user.followers),
        following: normalizeCount(user.followingCount || user.following),
        likes: normalizeCount(user.heartCount || user.likes || user.heart),
        verified: Boolean(user.verified),
        private: Boolean(user.private),
        avatar: user.avatarLarger || user.avatarMedium || user.avatarThumb || user.avatar || null,
        url: `https://www.tiktok.com/@${normalizeUsername(user.uniqueId || user.username || username)}`
    }
}

async function sendInfoMessage(message, sock, info, avatarUrl) {
    if (!avatarUrl) {
        return message.reply(info + '\n\n_📷 No se pudo obtener la foto de perfil._')
    }

    try {
        const picRes = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 15000 })
        const buffer = Buffer.from(picRes.data)
        return await sock.sendMessage(message.from, {
            image: buffer,
            caption: info
        }, { quoted: message._baileyMessage })
    } catch {
        return message.reply(info + '\n\n_📷 No se pudo obtener la foto de perfil._')
    }
}

async function fetchTikTokData(username) {
    const cleanUsername = normalizeUsername(username)
    if (!cleanUsername) throw new Error('Sin usuario')

    try {
        const res = await axios.get(`https://www.robleuy.site/robleapi/stalk/tiktok?q=${encodeURIComponent(cleanUsername)}`, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
            }
        })
        const data = res.data
        if (data?.ok) {
            console.log(`[TTSTALK] Fuente: API Roble (${cleanUsername})`)
            return {
                ...data,
                username: cleanUsername,
                url: data.url || `https://www.tiktok.com/@${cleanUsername}`
            }
        }
    } catch (err) {
        console.log(`[TTSTALK] API Roble falló para ${cleanUsername}: ${err.message}`)
    }

    const pageUrl = `https://www.tiktok.com/@${cleanUsername}`

    try {
        const { data: html } = await axios.get(pageUrl, {
            timeout: 20000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept-Language': 'es-ES,es;q=0.9',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        })

        const parsed = parseTikTokProfile(html, cleanUsername)
        if (parsed) {
            console.log(`[TTSTALK] Fuente: scraping TikTok (${cleanUsername})`)
            return parsed
        }
    } catch (err) {
        console.log(`[TTSTALK] Scraping HTTP falló para ${cleanUsername}: ${err.message}`)
    }

    if (puppeteer) {
        let browser = null
        try {
            browser = await puppeteer.launch({
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            })
            const page = await browser.newPage()
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
            await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 30000 })
            await page.waitForTimeout(5000)
            const html = await page.content()
            const parsed = parseTikTokProfile(html, cleanUsername)
            if (parsed) {
                console.log(`[TTSTALK] Fuente: puppeteer TikTok (${cleanUsername})`)
                return parsed
            }
        } catch (err) {
            console.log(`[TTSTALK] Puppeteer falló para ${cleanUsername}: ${err.message}`)
        } finally {
            if (browser) await browser.close()
        }
    }

    throw new Error('No se encontró el perfil')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn
    try {
        const username = args[0]
        if (!username) {
            return message.reply('⚠️ Uso: /ttstalk <usuario>\nEjemplo: /ttstalk robleuy')
        }

        const d = await fetchTikTokData(username)

        if (!d?.ok && !d?.username) {
            return message.reply('❌ No se encontró esa cuenta.')
        }

        const info = [
            `*${d.nickname || '-'}* (@${d.username || normalizeUsername(username)})`,
            `🔗 ${d.url || `https://www.tiktok.com/@${normalizeUsername(username)}`}`,
            '',
            `📝 Bio: ${d.biography || '-'}`,
            `🔒 Privada: ${d.private ? 'Sí' : 'No'}`,
            `✅ Verificada: ${d.verified ? 'Sí' : 'No'}`,
            `👥 Seguidores: ${d.followers || '0'}`,
            `➡️ Siguiendo: ${d.following || '0'}`,
            `❤️ Likes: ${d.likes || '0'}`
        ].join('\n')

        await sendInfoMessage(message, sock, info, d.avatar)

    } catch (err) {
        console.error('[TTSTALK]', err.message)
        await message.reply('❌ Error al obtener info de TikTok. Intenta con el usuario exacto o prueba más tarde.')
    }
}

handler.help = ['ttstalk <usuario>']
handler.tags = ['tools']
handler.command = /^(tt|ttstalk)$/i
handler.parseTikTokProfile = parseTikTokProfile

module.exports = handler

