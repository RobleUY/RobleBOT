const axios = require('axios')

// Regiones soportadas por la API — ordenadas por popularidad para minimizar reintentos
const REGIONS = ['BR', 'IND', 'ID', 'US', 'SG', 'VN', 'TH', 'ME', 'PK', 'TW', 'RU', 'CIS', 'BD']
const API_BASE = 'https://free-ff-api-src-5plp.onrender.com/api/v1'

// Mapa de regiones a nombre legible
const REGION_NAMES = {
    BR: '🇧🇷 Brasil', IND: '🇮🇳 India', ID: '🇮🇩 Indonesia', US: '🇺🇸 América',
    SG: '🇸🇬 Singapur', VN: '🇻🇳 Vietnam', TH: '🇹🇭 Tailandia', ME: '🌍 Medio Oriente',
    PK: '🇵🇰 Pakistán', TW: '🇹🇼 Taiwán', RU: '🇷🇺 Rusia', CIS: '🌐 CIS', BD: '🇧🇩 Bangladesh'
}

// Rango BR
const BR_RANKS = {
    0: 'Sin rango', 1: 'Bronce I', 2: 'Bronce II', 3: 'Bronce III',
    4: 'Plata I', 5: 'Plata II', 6: 'Plata III',
    7: 'Oro I', 8: 'Oro II', 9: 'Oro III', 10: 'Oro IV',
    11: 'Platino I', 12: 'Platino II', 13: 'Platino III', 14: 'Platino IV',
    15: 'Diamante I', 16: 'Diamante II', 17: 'Diamante III',
    18: 'Heroico', 19: 'Grandmaster', 220: 'Heroico'
}
const CS_RANKS = {
    0: 'Sin rango', 1: 'Bronce I', 2: 'Bronce II', 3: 'Bronce III',
    4: 'Plata I', 5: 'Plata II', 6: 'Plata III',
    7: 'Oro I', 8: 'Oro II', 9: 'Oro III', 10: 'Oro IV',
    11: 'Platino I', 12: 'Platino II', 13: 'Platino III', 14: 'Platino IV',
    15: 'Diamante I', 16: 'Diamante II', 17: 'Diamante III',
    18: 'Heroico', 19: 'Grandmaster', 219: 'Heroico'
}

function getRank(map, val) {
    return map[val] || `Rango ${val}`
}

function formatTimestamp(ts) {
    if (!ts) return 'N/A'
    const d = new Date(parseInt(ts) * 1000)
    const months = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic']
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

async function fetchProfile(uid, region) {
    const { data } = await axios.get(`${API_BASE}/account`, {
        params: { region, uid },
        timeout: 12000
    })
    // La API devuelve error en el JSON si no encuentra el perfil
    if (data.error || !data.basicInfo) return null
    return data
}

async function sendWithPhoto(message, conn, photoUrl, txt) {
    const sock = conn || message._sock || global.conn
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* fallback a texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const uid = args[0]
    // Región opcional como segundo argumento: .ffstalk 123456 BR
    const forceRegion = args[1] ? args[1].toUpperCase() : null

    if (!uid) return message.reply('⚠️ Uso: `.ffstalk <ID> [región]`\n\nEjemplo: `.ffstalk 219110511`\nRegiones: BR, IND, ID, US, SG, VN, TH, ME, PK, TW, RU, CIS, BD')
    if (!/^\d+$/.test(uid)) return message.reply('❌ El ID solo debe contener números.')
    if (forceRegion && !REGIONS.includes(forceRegion)) {
        return message.reply(`❌ Región inválida.\nRegiones disponibles: ${REGIONS.join(', ')}`)
    }

    await message.reply('🔍 _Buscando perfil de Free Fire..._')

    try {
        let data = null
        let foundRegion = null

        const searchRegions = forceRegion ? [forceRegion] : REGIONS

        for (const region of searchRegions) {
            try {
                data = await fetchProfile(uid, region)
                if (data) { foundRegion = region; break }
            } catch (e) {
                // Si es timeout o error de red, seguir con la siguiente región
                if (e.response?.status === 404 || e.response?.status === 400) continue
                if (e.code === 'ECONNABORTED') continue
                continue
            }
        }

        if (!data || !data.basicInfo) {
            return message.reply('❌ No se encontró ningún perfil con ese ID.\n\nSi conoces la región, prueba: `.ffstalk ' + uid + ' BR`')
        }

        const b = data.basicInfo
        const clan = data.clanBasicInfo
        const pet  = data.petInfo
        const soc  = data.socialInfo

        const sep = '─'.repeat(28)

        // Crédito
        const credit = data.creditScoreInfo?.creditScore ?? 'N/A'

        // Género
        const generoMap = { Gender_MALE: '♂️ Masculino', Gender_FEMALE: '♀️ Femenino' }
        const genero = generoMap[soc?.gender] || 'N/A'

        // Mascota
        let petTxt = 'Sin mascota'
        if (pet?.id) petTxt = `Lvl ${pet.level || '?'} (ID: ${pet.id})`

        const txt =
`🔥 *Free Fire — Perfil*
${sep}
🆔 *UID:* ${b.accountId}
👤 *Nick:* ${b.nickname || 'N/A'}
🌎 *Región:* ${REGION_NAMES[foundRegion] || foundRegion}
🏷️ *Nivel:* ${b.level || 'N/A'} _(Exp: ${b.exp?.toLocaleString() || 'N/A'})_
❤️ *Likes:* ${b.liked?.toLocaleString() || 'N/A'}
🎮 *Versión:* ${b.releaseVersion || 'N/A'}
${sep}
🏆 *Rango BR:* ${getRank(BR_RANKS, b.rank)} (${b.rankingPoints || 0} pts)
⚔️ *Rango CS:* ${getRank(CS_RANKS, b.csRank)} (${b.csRankingPoints || 0} pts)
${sep}
📅 *Cuenta creada:* ${formatTimestamp(b.createAt)}
🕒 *Último acceso:* ${formatTimestamp(b.lastLoginAt)}
${sep}
👥 *Clan:* ${clan?.clanName || 'Sin clan'}
🆔 *Clan ID:* ${clan?.clanId || 'N/A'}
🔢 *Nivel clan:* ${clan?.clanLevel || 'N/A'}
👤 *Miembros:* ${clan?.memberNum || 'N/A'}/${clan?.capacity || 'N/A'}
${sep}
🐾 *Mascota:* ${petTxt}
⭐ *Crédito:* ${credit}/100
🚻 *Género:* ${genero}
${sep}
🔗 _https://www.freefiremania.com.br/profile/${uid}.html_`

        // Avatar: la API no da URL directa pero el sitio usa un patrón predecible
        // Intentamos con og:image de freefiremania como fallback visual
        let avatarUrl = null
        try {
            const cheerio = require('cheerio')
            const { data: html } = await axios.get(`https://www.freefiremania.com.br/profile/${uid}.html`, {
                timeout: 8000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            })
            const $ = cheerio.load(html)
            avatarUrl = $('meta[property="og:image"]').attr('content') || null
        } catch { /* sin foto */ }

        return await sendWithPhoto(message, conn, avatarUrl, txt)

    } catch (err) {
        console.error('[ffstalk]', err.message)
        return message.reply('❌ Error al obtener el perfil. Intenta de nuevo en unos segundos.')
    }
}

handler.help = ['ffstalk <id> [región]', 'freefirestalk <id> [región]']
handler.tags = ['herramientas']
handler.command = /^(ffstalk|freefirestalk)$/i

module.exports = handler
