const axios = require('axios')
const cheerio = require('cheerio')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await conn.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const id = args[0]
    if (!id) return message.reply('⚠️ Uso: `.ffstalk <ID>`\n\nEjemplo: `.ffstalk 219110511`')
    if (!/^\d+$/.test(id)) return message.reply('❌ El ID solo debe contener números.')

    await message.reply('🔍 _Buscando perfil de Free Fire..._')

    try {
        const url = `https://www.freefiremania.com.br/profile/${id}.html`
        const { data: html } = await axios.get(url, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept-Language': 'es-ES,es;q=0.9',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        })

        const $ = cheerio.load(html)

        if (!$('ul li').length) {
            return message.reply('❌ No se encontró ningún perfil con ese ID.')
        }

        // --- Helper: sacar valor de un <li> por texto del <strong> ---
        const getVal = (label) => {
            let result = 'N/A'
            $('li').each((_, el) => {
                const strong = $(el).find('strong').first().text().trim()
                if (strong.includes(label)) {
                    const clone = $(el).clone()
                    clone.find('ul, strong').remove()
                    result = clone.text().replace(/^[\s:]+/, '').trim().split('\n')[0].trim()
                    if (result) return false
                }
            })
            return result || 'N/A'
        }

        // --- Datos principales ---
        const nick    = getVal('Nick')
        const uid     = getVal('UID') || id
        const levelRaw = getVal('Level')
        const level   = levelRaw.split('(')[0].trim()
        const exp     = (levelRaw.match(/\(([^)]+)\)/) || [])[1] || ''
        const likes   = getVal('Likes').split(' ')[0].trim()
        const region  = getVal('Region')
        const pass    = getVal('Booyah Pass')
        // --- Traducir fechas del portugués al español ---
        const traducirFecha = (str) => {
            if (!str || str === 'N/A') return str
            return str
                .replace(/janeiro/gi,   'enero')
                .replace(/fevereiro/gi, 'febrero')
                .replace(/março/gi,     'marzo')
                .replace(/abril/gi,     'abril')
                .replace(/maio/gi,      'mayo')
                .replace(/junho/gi,     'junio')
                .replace(/julho/gi,     'julio')
                .replace(/agosto/gi,    'agosto')
                .replace(/setembro/gi,  'septiembre')
                .replace(/outubro/gi,   'octubre')
                .replace(/novembro/gi,  'noviembre')
                .replace(/dezembro/gi,  'diciembre')
                .replace(/\bàs\b/gi,    'a las')
                .replace(/\bde\b/gi,    'de')
        }

        const created = traducirFecha(getVal('Account created on'))
        const lastLog = traducirFecha(getVal('Last login on'))

        // --- Guild (bloque completo del <li> de Guild) ---
        let guildName = 'Sin guild', guildId = 'N/A', guildLevel = 'N/A', guildMembers = 'N/A'
        $('li').each((_, el) => {
            const strongText = $(el).find('strong').first().text().trim()
            // El li principal de Guild contiene "Guild" pero no es Guild ID / Level / Members
            if (strongText === '👥 Guild:' || strongText === '👥 Guild') {
                guildName = $(el).find('a').first().text().trim() || 'N/A'
                const block = $(el).text()
                const gidM  = block.match(/Guild ID[:\s]+([0-9]+)/)
                const glvM  = block.match(/Level[:\s]+([0-9]+)/)
                const gmemM = block.match(/Members[:\s]+([0-9]+)/)
                if (gidM)  guildId      = gidM[1]
                if (glvM)  guildLevel   = glvM[1]
                if (gmemM) guildMembers = gmemM[1]
                return false
            }
        })

        // --- Bio (limpiar texto basura del sitio) ---
        let bio = 'Sin bio'
        $('li').each((_, el) => {
            const strong = $(el).find('strong').first().text().trim()
            if (strong.includes('Bio')) {
                const clone = $(el).clone()
                clone.find('strong, button, span, a').remove()
                bio = clone.text()
                    .replace(/Bio copied!?.*/si, '')
                    .replace(/Copy Bio.*$/si, '')
                    .replace(/code/gi, '')
                    .replace(/\s{3,}/g, '\n')
                    .trim() || 'Sin bio'
                return false
            }
        })

        // --- Antigüedad de la cuenta ---
        let accountAge = ''
        $('*').each((_, el) => {
            const t = $(el).text()
            const m = t.match(/(\d+)\s+years?,\s*(\d+)\s+months?\s+and\s+(\d+)\s+days?/)
            if (m) {
                accountAge = `${m[1]} años, ${m[2]} meses y ${m[3]} días`
                return false
            }
        })

        // --- Avatar ---
        let avatarUrl = null
        $('img').each((_, el) => {
            const src = $(el).attr('src') || ''
            if (src.includes('Icon_face') || src.includes('avatar')) {
                avatarUrl = src.startsWith('http') ? src : `https://www.freefiremania.com.br${src}`
                return false
            }
        })

        // --- Texto final todo en español ---
        const sep = '─'.repeat(28)
        const txt =
`🔥 *Free Fire — Perfil*
${sep}
🆔 *UID:* ${uid}
👤 *Nick:* ${nick}
🏷️ *Nivel:* ${level}${exp ? ` _(${exp})_` : ''}
❤️ *Likes:* ${likes}
⭐️ *Booyah Pass:* ${pass}
🌎 *Región:* ${region}
${sep}
📅 *Cuenta creada:* ${created}
🕒 *Último acceso:* ${lastLog}
${accountAge ? `⏳ *Antigüedad:* ${accountAge}\n` : ''}${sep}
👥 *Clan:* ${guildName}
🆔 *Clan ID:* ${guildId}
🔢 *Nivel clan:* ${guildLevel}
👤 *Miembros:* ${guildMembers}
${sep}
✍️ *Bio:* ${bio}`

        return await sendWithPhoto(message, conn, avatarUrl, txt)

    } catch (err) {
        if (err.response?.status === 404) return message.reply('❌ No se encontró ningún perfil con ese ID.')
        console.error('[ffstalk]', err.message)
        return message.reply('❌ Error al obtener el perfil. Verifica el ID e intenta de nuevo.')
    }
}

handler.help = ['ffstalk <id>', 'freefirestalk <id>']
handler.tags = ['herramientas']
handler.command = /^(ffstalk|freefirestalk)$/i

module.exports = handler