const axios = require('axios')
const cheerio = require('cheerio')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    const sock = conn || message._sock || global.conn
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto en caso de error con la imagen */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const id = args[0]
    if (!id) return message.reply('⚠️ Uso: `.ffstalk <ID>`\n\nEjemplo: `.ffstalk 219110511`')
    if (!/^\d+$/.test(id)) return message.reply('❌ El ID solo debe contener números.')

    await message.reply('🔍 _Buscando perfil de Free Fire..._')

    try {
        const url = `https://www.freefiremania.com.br/profile/${id}.html`
        const { data: html } = await axios.get(url, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept-Language': 'es-ES,es;q=0.9',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        })

        const $ = cheerio.load(html)

        // Verificación si existe el contenedor principal del perfil
        if (!$('.perfil-api-card').length) {
            return message.reply('❌ No se encontró ningún perfil con ese ID.')
        }

        // --- Helper: Extraer valor de la cuadrícula (.perfil-api-grid) ---
        const getGridVal = (label) => {
            let result = 'N/A'
            $('.perfil-api-grid div').each((_, el) => {
                const strongText = $(el).find('strong').text().trim()
                if (strongText.toLowerCase().includes(label.toLowerCase())) {
                    result = $(el).find('span').text().trim()
                    return false
                }
            })
            return result || 'N/A'
        }

        // --- Datos principales ---
        const nick     = getGridVal('Nick') !== 'N/A' ? getGridVal('Nick') : ($('.perfil-container .nome').text().trim() || 'N/A')
        const uid      = id
        const level    = $('.perfil-api-level').text().replace(/level/gi, '').trim() || $('.perfil-container .level').text().trim() || 'N/A'
        const exp      = getGridVal('Exp')
        const likes    = getGridVal('Likes')
        const region   = getGridVal('Region')
        const pass     = getGridVal('Booyah Pass')

        // --- Traducir fechas del portugués/inglés al español ---
        const traducirFecha = (str) => {
            if (!str || str === 'N/A') return str
            return str
                .replace(/janeiro|january/gi,    'enero')
                .replace(/fevereiro|february/gi, 'febrero')
                .replace(/março|march/gi,        'marzo')
                .replace(/abril|april/gi,        'abril')
                .replace(/maio|may/gi,          'mayo')
                .replace(/junho|june/gi,         'junio')
                .replace(/julho|july/gi,         'julio')
                .replace(/agosto|august/gi,      'agosto')
                .replace(/setembro|september/gi, 'septiembre')
                .replace(/outubro|october/gi,    'octubre')
                .replace(/novembro|november/gi,  'noviembre')
                .replace(/dezembro|december/gi,  'diciembre')
                .replace(/\bàs\b/gi,             'a las')
                .replace(/\bde\b/gi,             'de')
        }

        const created = traducirFecha(getGridVal('Account created on'))
        const lastLog = traducirFecha(getGridVal('Last login on'))

        // --- Datos del Clan (Guild) ---
        let guildName = 'Sin clan', guildId = 'N/A', guildLevel = 'N/A', guildMembers = 'N/A'
        $('.perfil-api-panel').each((_, el) => {
            const h2Text = $(el).find('h2').text().trim()
            if (h2Text.toLowerCase().includes('guild') || h2Text.toLowerCase().includes('clan')) {
                guildName = $(el).find('a').text().trim() || 'Sin clan'
                const block = $(el).text()
                const gidM  = block.match(/Guild ID[:\s]+([0-9]+)/i)
                const glvM  = block.match(/Level[:\s]+([0-9]+)/i)
                const gmemM = block.match(/Members[:\s]+([0-9]+)/i)
                if (gidM)  guildId      = gidM[1]
                if (glvM)  guildLevel   = glvM[1]
                if (gmemM) guildMembers = gmemM[1]
                return false
            }
        })

        // --- Biografía ---
        const bio = $('#bioContent').attr('data-original-bio') || $('#bioContent').text().trim() || 'Sin bio'

        // --- Antigüedad de la cuenta ---
        let accountAge = ''
        $('.alert-warning p').each((_, el) => {
            const text = $(el).text()
            const match = text.match(/(\d+)\s+years?,\s*(\d+)\s+months?\s+and\s+(\d+)\s+days?/)
            if (match) {
                accountAge = `${match[1]} años, ${match[2]} meses y ${match[3]} días`
                return false
            }
        })

        // --- Avatar / Foto de Perfil ---
        let avatarUrl = $('img.avatar').attr('src') || $('img[src*="Icon_face"]').attr('src') || null
        if (avatarUrl && !avatarUrl.startsWith('http')) {
            avatarUrl = `https://www.freefiremania.com.br${avatarUrl.startsWith('/') ? '' : '/'}${avatarUrl}`
        }

        // --- Formato de respuesta ---
        const sep = '─'.repeat(28)
        const txt =
`🔥 *Free Fire — Perfil*
${sep}
🆔 *UID:* ${uid}
👤 *Nick:* ${nick}
🏷️ *Nivel:* ${level}${exp !== 'N/A' ? ` _(Exp: ${exp})_` : ''}
❤️ *Likes:* ${likes}
⭐️ *Booyah Pass:* ${pass}
🌎 *Región:* ${region}
${sep}
📅 *Cuenta creada:* ${created}
🕒 *Último acceso:* ${lastLog}
${accountAge ? `⏳ *Antigüedad:* ${accountAge}\n` : ''}${sep}
👥 *Clan:* ${guildName}
🆔 *Clan ID:* ${guildId}
🔢 *Nivel clan:* ${guildLevel}
👤 *Miembros:* ${guildMembers}
${sep}
✍️ *Bio:*
${bio}`

        return await sendWithPhoto(message, conn, avatarUrl, txt)

    } catch (err) {
        if (err.response?.status === 404) return message.reply('❌ No se encontró ningún perfil con ese ID.')
        console.error('[ffstalk]', err.message)
        return message.reply('❌ Error al obtener el perfil. Verifica el ID e intenta de nuevo.')
    }
}

handler.help = ['ffstalk <id>', 'freefirestalk <id>']
handler.tags = ['herramientas']
handler.command = /^(ffstalk|freefirestalk)$/i

module.exports = handler