const axios = require('axios')
const cheerio = require('cheerio')
const puppeteer = (() => {
    try {
        return require('puppeteer')
    } catch {
        return null
    }
})()

function normalizeUsername(username) {
    return String(username || '').replace(/^@/, '').trim()
}

function normalizeCount(value) {
    if (value === null || value === undefined || value === '') return 0
    if (typeof value === 'number') return value
    
    let str = String(value).trim().toLowerCase()
    let multiplier = 1
    
    // Detectar si tiene K (miles) o M (millones)
    if (str.includes('k')) multiplier = 1000
    if (str.includes('m')) multiplier = 1000000
    
    // Limpiar dejando solo números y puntos
    const cleaned = str.replace(/[^\d.]/g, '')
    return Math.floor((Number(cleaned) || 0) * multiplier)
}

function parseInstagramProfile(html, username) {
    if (!html) return null

    try {
        const $ = cheerio.load(html)
        const title = $('meta[property="og:title"]').attr('content') || ''
        const description = $('meta[name="description"]').attr('content') || ''
        const image = $('meta[property="og:image"]').attr('content') || ''

        const counts = $('meta[property="og:description"]').attr('content') || ''
        
        // 🚨 BLOQUEO DE SEGURIDAD: 
        // Si no existe la descripción con los contadores, significa que Instagram 
        // nos bloqueó o nos mandó al login. Devolvemos null para que intente con Puppeteer.
        if (!counts || (!counts.toLowerCase().includes('followers') && !counts.toLowerCase().includes('seguidores'))) {
            return null; 
        }

        const fullNameMatch = title.match(/^(.*?)\s*\(@/i)
        const fullName = fullNameMatch ? fullNameMatch[1].trim() : ''
        const cleanedUsername = normalizeUsername(username)

        const profile = {
            ok: true,
            username: cleanedUsername,
            full_name: fullName || cleanedUsername,
            biography: description.replace(/\s+/g, ' ').trim() || '-',
            private: false,
            verified: /verified|verificado/i.test(title) || /verified|verificado/i.test(description),
            posts: 0,
            followers: 0,
            following: 0,
            profile_picture_original: image || null,
            url: `https://www.instagram.com/${cleanedUsername}`
        }

        // Expresiones regulares adaptadas para Inglés y Español, y valores con letras (K/M)
        const followerMatch = counts.match(/([\d,\.km]+)\s*(?:followers|seguidores)/i)
        const followingMatch = counts.match(/([\d,\.km]+)\s*(?:following|seguidos)/i)
        const postsMatch = counts.match(/([\d,\.km]+)\s*(?:posts|publicaciones)/i)

        if (followerMatch) profile.followers = normalizeCount(followerMatch[1].replace(/,/g, ''))
        if (followingMatch) profile.following = normalizeCount(followingMatch[1].replace(/,/g, ''))
        if (postsMatch) profile.posts = normalizeCount(postsMatch[1].replace(/,/g, ''))

        return profile
    } catch {
        return null
    }
}

async function fetchInstagramData(username) {
    const cleanUsername = normalizeUsername(username)
    if (!cleanUsername) throw new Error('Sin usuario')

    try {
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/instagram?q=${encodeURIComponent(cleanUsername)}`, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
            }
        })
        const data = res.data
        if (data?.ok) {
            console.log(`[IGSTALK] Fuente: API Roble (${cleanUsername})`)
            return {
                ...data,
                username: cleanUsername,
                url: data.url || `https://www.instagram.com/${cleanUsername}`
            }
        }
    } catch (err) {
        console.log(`[IGSTALK] API Roble falló para ${cleanUsername}: ${err.message}`)
    }

    const pageUrl = `https://www.instagram.com/${cleanUsername}`

    try {
        const { data: html } = await axios.get(pageUrl, {
            timeout: 20000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept-Language': 'es-ES,es;q=0.9',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        })
        const parsed = parseInstagramProfile(html, cleanUsername)
        if (parsed) {
            console.log(`[IGSTALK] Fuente: scraping Instagram (${cleanUsername})`)
            return parsed
        }
    } catch (err) {
        console.log(`[IGSTALK] Scraping HTTP falló para ${cleanUsername}: ${err.message}`)
    }

    if (puppeteer) {
        let browser = null
        try {
            browser = await puppeteer.launch({
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            })
            const page = await browser.newPage()
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
            await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 30000 })
            await page.waitForTimeout(5000)
            const html = await page.content()
            const parsed = parseInstagramProfile(html, cleanUsername)
            if (parsed) {
                console.log(`[IGSTALK] Fuente: puppeteer Instagram (${cleanUsername})`)
                return parsed
            }
        } catch (err) {
            console.log(`[IGSTALK] Puppeteer falló para ${cleanUsername}: ${err.message}`)
        } finally {
            if (browser) await browser.close()
        }
    }

    throw new Error('No se encontró el perfil')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn
    try {
        const username = args[0]
        if (!username) {
            return message.reply('⚠️ Uso: /igstalk <usuario>\nEjemplo: /igstalk robleuy')
        }

        await message.reply(`🔍 _Buscando perfil de Instagram: @${username}..._`)

        const d = await fetchInstagramData(username)

        if (!d?.ok && !d?.username) {
            return message.reply('❌ No se encontró esa cuenta.')
        }

        const info = [
            `*${d.full_name || d.fullName || '-'}* (@${d.username || normalizeUsername(username)})`,
            `🔗 ${d.url || `https://www.instagram.com/${normalizeUsername(username)}`}`,
            '',
            `📝 Bio: ${d.biography || '-'}`,
            `🔒 Privada: ${d.private ? 'Sí' : 'No'}`,
            `✅ Verificada: ${d.verified ? 'Sí' : 'No'}`,
            `📸 Posts: ${d.posts || '0'}`,
            `👥 Seguidores: ${d.followers || '0'}`,
            `➡️ Siguiendo: ${d.following || '0'}`
        ].join('\n')

        let buffer = null
        try {
            const picUrl = d.profile_picture_original || `https://robleuy.vercel.app${d.profile_picture}`
            const picRes = await axios.get(picUrl, { responseType: 'arraybuffer', timeout: 15000 })
            buffer = Buffer.from(picRes.data)
        } catch { }

        if (buffer) {
            return await sock.sendMessage(message.from, {
                image: buffer,
                caption: info
            }, { quoted: message._baileyMessage })
        }

        return await message.reply(info + '\n\n_📷 No se pudo obtener la foto de perfil._')

    } catch (err) {
        console.error('[IGSTALK]', err.message)
        await message.reply('❌ Error al obtener info de Instagram. Intenta con el usuario exacto o prueba más tarde.')
    }
}

handler.help = ['igstalk <usuario>']
handler.tags = ['tools']
handler.command = /^(ig|igstalk)$/i

module.exports = handler