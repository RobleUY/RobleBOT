const axios = require('axios')

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const username = args[0]
        if (!username)
            return message.reply('⚠️ Uso: /igstalk <usuario>\nEjemplo: /igstalk robleuy')

        const res = await axios.get(`https://www.robleuy.site/robleapi/stalk/instagram?q=${encodeURIComponent(username)}`, { timeout: 15000 })
        const d = res.data

        if (!d?.ok) return message.reply('❌ No se encontró esa cuenta.')

        const info = [
            `*${d.full_name || '-'}* (@${d.username})`,
            `🔗 ${d.url}`,
            '',
            `📝 Bio: ${d.biography || '-'}`,
            `🔒 Privada: ${d.private ? 'Sí' : 'No'}`,
            `✅ Verificada: ${d.verified ? 'Sí' : 'No'}`,
            `📸 Posts: ${d.posts || '0'}`,
            `👥 Seguidores: ${d.followers || '0'}`,
            `➡️ Siguiendo: ${d.following || '0'}`
        ].join('\n')

        // La foto original viene como URL completa en profile_picture_original
        let buffer = null
        try {
            const picUrl = d.profile_picture_original || `https://www.robleuy.site${d.profile_picture}`
            const picRes = await axios.get(picUrl, { responseType: 'arraybuffer', timeout: 15000 })
            buffer = Buffer.from(picRes.data)
        } catch { }

        if (buffer) {
            return await sock.sendMessage(message.from, {
                image: buffer,
                caption: info
            }, { quoted: message._baileyMessage })
        }

        return await message.reply(info + '\n\n_📷 No se pudo obtener la foto de perfil._')

    } catch (err) {
        console.error('[IGSTALK]', err.message)
        await message.reply('❌ Error al obtener info de Instagram.')
    }
}

handler.help = ['igstalk <usuario>']
handler.tags = ['tools']
handler.command = /^(ig|igstalk)$/i

module.exports = handler

