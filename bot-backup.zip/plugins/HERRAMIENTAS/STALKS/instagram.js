const axios = require('axios');

let handler = async (message, { conn, args }) => {
    try {
        const username = args[0];
        if (!username)
            return await message.reply('⚠️ Uso correcto: /igstalk <usuario>\n\nEjemplo: `/igstalk robleuy`');

        const apiUrl = `https://delirius-apiofc.vercel.app/tools/igstalk?username=${encodeURIComponent(username)}`;
        const apiRes = await axios.get(apiUrl, { timeout: 15000 });
        const body = apiRes.data;

        if (!body || body.status !== true || !body.data)
            return await message.reply('❌ No se encontró esa cuenta.');

        const d = body.data;
        const profileUrl = d.url || `https://instagram.com/${d.username || username}`;

        const info = [
            `*${d.full_name || '-'}* (@${d.username || username})`,
            `🔗 ${profileUrl}`,
            '',
            `📝 Bio: ${d.biography || '-'}`,
            `🏷️ Categoría: ${d.category || '-'}`,
            `🔒 Privada: ${d.private ? 'Sí' : 'No'}`,
            `✅ Verificada: ${d.verified ? 'Sí' : 'No'}`,
            `📸 Publicaciones: ${d.posts || '0'}`,
            `👥 Seguidores: ${d.followers || '0'}`,
            `➡️ Siguiendo: ${d.following || '0'}`,
            `🌐 Website: ${d.external_url || '-'}`
        ].join('\n');

        let buffer;
        try {
            const picRes = await axios.get(d.profile_picture, { responseType: 'arraybuffer', timeout: 15000 });
            buffer = Buffer.from(picRes.data);
        } catch {
            buffer = null;
        }

        if (buffer) {
            // Enviar solo TEXTO con el botón clickeable (sin duplicar la imagen)
            await conn.sendMessage(message.from, {
                text: info,
                contextInfo: {
                    externalAdReply: {
                        title: d.full_name || d.username || 'Instagram',
                        body: `@${d.username} • ${d.followers || '0'} seguidores`,
                        thumbnail: buffer,
                        sourceUrl: profileUrl,
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                },
                quoted: message
            });
        } else {
            // Si no hay imagen, enviar solo texto con enlace
            await conn.sendMessage(message.from, {
                text: info,
                quoted: message
            });
        }

    } catch (error) {
        console.error('[ERROR] ig:', error);
        await message.reply('❌ Error al obtener información de Instagram.');
    }
};

handler.help = ['ig <usuario>'];
handler.tags = ['tools'];
handler.command = /^(ig|igstalk)$/i;

module.exports = handler;