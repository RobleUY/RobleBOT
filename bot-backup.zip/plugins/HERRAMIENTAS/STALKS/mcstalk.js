const axios = require('axios')

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.mcstalk <usuario>`')

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/minecraft?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `⛏️ *Minecraft*\n${'─'.repeat(28)}\n👤 Usuario: *${data.username}*\n🆔 UUID: \`${data.id}\`\n🧍 Skin: *${data.skin_model}*\n🔗 NameMC: ${data.namemc_url}`

        // Enviar con avatar (cabeza del personaje)
        if (data.avatar) {
            try {
                const { data: imgData } = await axios.get(data.avatar, { responseType: 'arraybuffer', timeout: 10000 })
                return await sock.sendMessage(message.from, {
                    image: Buffer.from(imgData),
                    caption: txt
                }, { quoted: message._baileyMessage })
            } catch { /* si falla la imagen, mandar solo texto */ }
        }

        return message.reply(txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['mcstalk <usuario>', 'minecraftstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(mcstalk|minecraftstalk)$/i

module.exports = handler

