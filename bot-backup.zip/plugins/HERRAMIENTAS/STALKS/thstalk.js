const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.thstalk <usuario>`')

    await message.reply(`🔍 _Buscando perfil de Threads: @${user}..._`)

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/threads?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const links = data.links?.length ? data.links.join(', ') : 'Ninguno'
        const txt = `🧵 *Threads*\n${'─'.repeat(28)}\n👤 Usuario: *@${data.username}*\n📛 Nombre: *${data.full_name}*\n📝 Bio: ${data.biography || 'Sin bio'}\n👥 Seguidores: *${data.followers}*\n🔗 Links: ${links}\n🌐 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_picture || data.profile_pic || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['thstalk <usuario>', 'threadsstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(thstalk|threadsstalk)$/i

module.exports = handler

