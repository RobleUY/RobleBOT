let handler = async (message, { usedPrefix }) => {
    const prefix = usedPrefix || '.'

    const menu = `
╔═══════════════════
║ 📡 *MENÚ DE STALKS*
╚═══════════════════

*🌐 Redes Sociales*
• ${prefix}igstalk <usuario>
  _Instagram_

• ${prefix}ttstalk <usuario>
  _TikTok_

• ${prefix}ytstalk <canal>
  _YouTube_

• ${prefix}xstalk <usuario>
  _Twitter / X_

• ${prefix}tgstalk <usuario>
  _Telegram_

• ${prefix}thstalk <usuario>
  _Threads_

*💻 Plataformas*
• ${prefix}ghstalk <usuario>
  _GitHub_

• ${prefix}steamstalk <usuario>
  _Steam_

• ${prefix}ffstalk <id>
  _FreeFire_

• ${prefix}mcstalk <usuario>
  _Minecraft_

• ${prefix}ptstalk <usuario>
  _Pinterest_

*📱 Otros*
• ${prefix}infonum <+número>
  _Info de número telefónico_

╚═══════════════════
_Obtén información de perfiles públicos_
`.trim()

    return message.reply(menu)
}

handler.help = ['stalks', 'stalksmenu', 'menustalks']
handler.tags = ['herramientas']
handler.command = /^(stalks|stalksmenu|menustalks)$/i

module.exports = handler
