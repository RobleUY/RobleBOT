const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.steamstalk <usuario>`')

    await message.reply(`🔍 _Buscando perfil de Steam: ${user}..._`)

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/steam?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `🎮 *Steam*\n${'─'.repeat(28)}\n👤 Usuario: *${data.username}*\n📛 Nombre: *${data.full_name}*\n🎮 Juegos: *${data.games}*\n👥 Amigos: *${data.friends}*\n🏅 Badges: *${data.badges}*${data.screenshots ? `\n📸 Screenshots: *${data.screenshots}*` : ''}${data.reviews ? `\n⭐ Reviews: *${data.reviews}*` : ''}\n🔗 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_picture || data.profile_pic || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['steamstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^steamstalk$/i

module.exports = handler

