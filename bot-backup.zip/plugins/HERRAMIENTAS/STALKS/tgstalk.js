const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.tgstalk <usuario>`')

    await message.reply(`🔍 _Buscando perfil de Telegram: @${user}..._`)

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/telegram?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `✈️ *Telegram*\n${'─'.repeat(28)}\n👤 Usuario: *@${data.username}*\n📛 Nombre: *${data.full_name}*\n📝 Bio: ${data.biography || 'Sin bio'}\n✅ Verificado: ${data.verified ? 'Sí' : 'No'}\n⭐ Premium: ${data.premium ? 'Sí' : 'No'}\n🤖 Bot: ${data.bot ? 'Sí' : 'No'}\n🔗 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_picture || data.profile_pic || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['tgstalk <usuario>', 'telegramstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(tgstalk|telegramstalk)$/i

module.exports = handler

