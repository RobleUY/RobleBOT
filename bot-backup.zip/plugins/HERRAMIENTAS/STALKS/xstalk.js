const axios = require('axios')

async function sendWithPhoto(message, conn, photoUrl, txt) {
    if (photoUrl) {
        try {
            const { data: imgData } = await axios.get(photoUrl, { responseType: 'arraybuffer', timeout: 10000 })
            return await sock.sendMessage(message.from, {
                image: Buffer.from(imgData),
                caption: txt
            }, { quoted: message._baileyMessage })
        } catch { /* si falla, cae al texto */ }
    }
    return message.reply(txt + '\n\n_📷 No se pudo obtener la foto de perfil._')
}

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const user = args[0]
    if (!user) return message.reply('⚠️ Uso: `.xstalk <usuario>`')

    try {
        const { data } = await axios.get(`https://robleuy.vercel.app/robleapi/stalk/twitter?q=${encodeURIComponent(user)}`, { timeout: 10000 })
        if (!data.ok) return message.reply('❌ Usuario no encontrado.')

        const txt = `🐦 *Twitter / X*\n${'─'.repeat(28)}\n👤 Usuario: *@${data.username}*\n📛 Nombre: *${data.full_name}*\n📝 Bio: ${data.biography || 'Sin bio'}\n👥 Seguidores: *${data.followers}*\n➡️ Siguiendo: *${data.following}*\n🐦 Tweets: *${data.tweets}*\n✅ Verificado: ${data.verified ? 'Sí' : 'No'}\n🔒 Privado: ${data.private ? 'Sí' : 'No'}\n🔗 ${data.url}`

        return await sendWithPhoto(message, conn, data.profile_picture || data.profile_pic || data.avatar || null, txt)
    } catch {
        return message.reply('❌ Error al consultar la API.')
    }
}

handler.help = ['xstalk <usuario>', 'twitterstalk <usuario>']
handler.tags = ['herramientas']
handler.command = /^(xstalk|twitterstalk)$/i

module.exports = handler

