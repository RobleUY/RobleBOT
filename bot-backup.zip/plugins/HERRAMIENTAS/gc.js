/**
 * Comando para forzar garbage collection
 * Uso: .gc
 * Nota: Requiere ejecutar el bot con --expose-gc
 */

module.exports = {
    command: 'gc',
    help: 'Forzar limpieza de memoria (garbage collection)',
    tags: ['herramientas'],
    owner: true,

    handler: async (message) => {
        try {
            if (!global.gc) {
                return await message.reply(
                    '❌ *Garbage Collection no disponible*\n\n' +
                    'Para habilitar GC, ejecuta el bot con:\n' +
                    '```node --expose-gc index.js```'
                );
            }
            
            const before = process.memoryUsage();
            const beforeMB = Math.round(before.heapUsed / 1024 / 1024);
            
            await message.reply('🗑️ Ejecutando garbage collection...');
            
            // Ejecutar GC
            global.gc();
            
            // Esperar un momento para que se complete
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const after = process.memoryUsage();
            const afterMB = Math.round(after.heapUsed / 1024 / 1024);
            const freedMB = beforeMB - afterMB;
            
            const text = `✅ *Garbage Collection Completado*\n\n` +
                        `📊 *Antes*: ${beforeMB}MB\n` +
                        `📊 *Después*: ${afterMB}MB\n` +
                        `🗑️ *Liberado*: ${freedMB > 0 ? '+' : ''}${freedMB}MB\n\n` +
                        `${freedMB > 10 ? '✅ Memoria liberada exitosamente' : 
                          freedMB > 0 ? '✅ Pequeña cantidad de memoria liberada' : 
                          '⚠️ No se liberó memoria significativa'}`;
            
            await message.reply(text);
            
        } catch (error) {
            console.error('Error en comando gc:', error.message);
            await message.reply('❌ Error al ejecutar garbage collection');
        }
    }
};
