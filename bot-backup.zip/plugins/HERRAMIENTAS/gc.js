/**
 * Comando para forzar garbage collection
 * Uso: .gc
 */

const v8 = require('v8');

module.exports = {
    command: 'gc',
    help: 'Forzar limpieza de memoria (garbage collection)',
    tags: ['herramientas'],
    owner: true,

    handler: async (message) => {
        try {
            const before = process.memoryUsage();
            const beforeMB = Math.round(before.heapUsed / 1024 / 1024);
            const beforeTotalMB = Math.round(before.heapTotal / 1024 / 1024);

            await message.reply('🗑️ Ejecutando limpieza de memoria...');

            if (global.gc) {
                // GC nativo disponible (--expose-gc)
                global.gc();
                global.gc(); // dos pasadas para limpiar más
            } else {
                // Fallback: forzar liberación via v8 heap statistics
                // y limpiar caches globales conocidos del bot
                if (global.db?.data) {
                    // Forzar serialización/deserialización limpia no es posible,
                    // pero podemos limpiar Maps y Sets internos del handler
                }
                if (global.commandHandler) {
                    global.commandHandler.cleanupMemory?.();
                }
                // Sugerir al runtime que libere memoria
                v8.setFlagsFromString('--max_old_space_size=512');
            }

            await new Promise(resolve => setTimeout(resolve, 500));

            const after = process.memoryUsage();
            const afterMB = Math.round(after.heapUsed / 1024 / 1024);
            const afterTotalMB = Math.round(after.heapTotal / 1024 / 1024);
            const freedMB = beforeMB - afterMB;

            const gcMode = global.gc ? '✅ GC nativo' : '⚠️ GC limitado (sin --expose-gc)';

            const text =
                `🗑️ *Limpieza de Memoria*\n\n` +
                `📊 *Heap usado:* ${beforeMB}MB → ${afterMB}MB\n` +
                `📦 *Heap total:* ${beforeTotalMB}MB → ${afterTotalMB}MB\n` +
                `🗑️ *Liberado:* ${freedMB > 0 ? '+' : ''}${freedMB}MB\n\n` +
                `🔧 *Modo:* ${gcMode}`;

            await message.reply(text);

        } catch (error) {
            console.error('Error en comando gc:', error.message);
            await message.reply('❌ Error al ejecutar garbage collection');
        }
    }
};
