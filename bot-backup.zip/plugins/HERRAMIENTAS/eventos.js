/**
 * Comando: .eventos
 * Descripción: Muestra eventos históricos de hoy o de una fecha específica
 * Uso: 
 *   .eventos hoy
 *   .eventos 11/10
 *   .eventos 11/10/2011
 */

let handler = async (message, { text }) => {
  try {
    if (!text || typeof text !== 'string') {
      return await message.reply(
        '❌ Debes escribir un argumento.\n\n' +
        '📌 *Uso del comando:*\n' +
        '• `.eventos hoy` → Muestra los eventos del día actual\n' +
        '• `.eventos dd/mm` → Muestra los eventos de un día específico\n' +
        '• `.eventos dd/mm/yyyy` → Muestra los eventos de un día y año específicos'
      );
    }

    text = text.trim().toLowerCase();

    let day, month, yearFilter = null;

    if (text === 'hoy') {
      const today = new Date();
      day = today.getDate();
      month = today.getMonth() + 1;
    } else {
      const parts = text.split('/');
      if (parts.length >= 2) {
        day = parseInt(parts[0]);
        month = parseInt(parts[1]);
        if (parts.length === 3) yearFilter = parseInt(parts[2]);
      } else {
        return await message.reply(
          '❌ Formato incorrecto. Usa `.eventos hoy`, `dd/mm` o `dd/mm/yyyy`'
        );
      }
    }

    await message.reply('📜 Consultando eventos históricos...');

    const fetchFn = global.fetch || (await import('node-fetch')).default;
    const url = `https://es.wikipedia.org/api/rest_v1/feed/onthisday/events/${month}/${day}`;
    const res = await fetchFn(url);
    if (!res.ok) throw new Error('No se pudo obtener los eventos.');
    const data = await res.json();

    let events = data.events || [];
    if (yearFilter) events = events.filter(e => e.year === yearFilter);

    if (events.length === 0) {
      return await message.reply('❌ No se encontraron eventos para esta fecha.');
    }

    let msg = `📜 *Eventos históricos del ${day}/${month}${yearFilter ? '/' + yearFilter : ''}*\n\n`;
    events.slice(0, 5).forEach(e => {
      msg += `🕰️ *${e.year}*: ${e.text}\n\n`;
    });

    msg += '⚠️ Datos históricos, pueden no ser 100% exactos.';

    await message.reply(msg);

  } catch (e) {
    console.error('Error en comando eventos:', e);
    await message.reply('❌ Ocurrió un error al obtener los eventos históricos.');
  }
};

handler.help = ['eventos <hoy|dd/mm[/yyyy]>'];
handler.tags = ['información', 'curiosidades'];
handler.command = /^(eventos)$/i;

module.exports = handler;
