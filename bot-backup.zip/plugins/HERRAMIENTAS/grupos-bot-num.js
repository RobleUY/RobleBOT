/**
 * Comando: grupos
 * Descripción: Muestra información sobre todos los grupos donde está el bot
 * Uso: .grupos
 */
let handler = async (message, { conn }) => {
    
    try {
        // --- 1. Obtener todos los grupos ---
        let groups = [];
        let groupsData = {};
        
        // Método 1: Intentar usar conn.chats (si existe)
        if (conn.chats && typeof conn.chats === 'object') {
            groups = Object.entries(conn.chats)
                .filter(([jid, chat]) => jid.endsWith('@g.us'))
                .map(([jid]) => jid);
        }
        
        // Método 2: Intentar usar conn.groupFetchAllParticipating() (@whiskeysockets/baileys)
        if (groups.length === 0 && typeof conn.groupFetchAllParticipating === 'function') {
            try {
                groupsData = await conn.groupFetchAllParticipating();
                groups = Object.keys(groupsData);
            } catch (e) {
                console.error('[ERROR] No se pudo obtener grupos con groupFetchAllParticipating:', e.message);
            }
        }
        
        // Método 3: Intentar usar conn.groupMetadata() con lista de grupos conocidos
        if (groups.length === 0 && global.db?.data?.chats) {
            groups = Object.keys(global.db.data.chats)
                .filter(jid => jid.endsWith('@g.us'));
        }
        
        if (groups.length === 0) {
            return await message.reply('❌ El bot no está en ningún grupo o no se pudieron obtener los datos.');
        }
        
        // --- 2. Obtener información detallada de cada grupo ---
        await message.reply(`⏳ Obteniendo información de chats y grupos...`);
        
        let groupList = [];
        
        for (const jid of groups) {
            try {
                let groupInfo;
                
                // Si ya tenemos los datos de groupFetchAllParticipating
                if (groupsData[jid]) {
                    groupInfo = groupsData[jid];
                } else {
                    // Obtener metadata del grupo
                    groupInfo = await conn.groupMetadata(jid);
                }
                
                const groupName = groupInfo.subject || 'Sin nombre';
                const participantsCount = groupInfo.participants?.length || 0;
                
                groupList.push({
                    jid,
                    name: groupName,
                    participants: participantsCount
                });
                
                // Pequeña pausa para evitar rate limit
                await new Promise(resolve => setTimeout(resolve, 100));
                
            } catch (error) {
                console.error(`[ERROR] No se pudo obtener info del grupo ${jid}:`, error.message);
                groupList.push({
                    jid,
                    name: 'Error al obtener nombre',
                    participants: 0
                });
            }
        }
        
        // --- 3. Formatear y enviar la respuesta ---
        const totalGroups = groupList.length;
        const totalParticipants = groupList.reduce((sum, g) => sum + g.participants, 0);
        const totalUsersDisplay = totalParticipants + 100; // Total de participantes +100
        
        let response = `╭━━━━━━━━━━━╮\n`;
        response += `┃ 🤖 *GRUPOS DEL BOT* 🤖\n`;
        response += `╰━━━━━━━━━━━╯\n\n`;
        response += `📊 *Total de grupos:* ${totalGroups}\n`;
        response += `👥 *Usuarios usando el bot:* ${totalUsersDisplay}\n\n`;
        response += `━━━━━━━━━━━━━━━\n\n`;
        
        // Ordenar por número de participantes (de mayor a menor)
        groupList.sort((a, b) => b.participants - a.participants);
        
        groupList.forEach((group, index) => {
            const number = (index + 1).toString().padStart(2, '0');
            response += `${number}. *${group.name}*\n`;
            response += `   👥 ${group.participants} miembros\n\n`;
        });
        
        response += `━━━━━━━━━━━━━━━\n`;
        response += `⏰ ${new Date().toLocaleString('es-UY', { timeZone: 'America/Montevideo' })}`;
        
        // Enviar la respuesta
        await message.reply(response);
        
    } catch (error) {
        console.error(`[ERROR] Error en comando grupos:`, error.message);
        console.error(error.stack);
        
        return await message.reply(
            `❌ Ocurrió un error inesperado:\n\n` +
            `\`\`\`${error.message}\`\`\`\n\n` +
            `Por favor, contacta al desarrollador del bot.`
        );
    }
};

// --- Configuración del Handler ---
handler.help = ['grupos', 'grouplist'];
handler.tags = ['info', 'admin'];
handler.command = /^(usuariosbot)$/i;

module.exports = handler;