/**
 * Comando: kick
 * Descripción: Expulsa a un usuario del grupo
 * Uso: .kick @usuario o responder a un mensaje con .kick
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- Verificaciones de permisos ---
        
        // 1. Obtener metadatos del grupo con manejo de errores
        let groupMetadata;
        try {
            groupMetadata = await conn.groupMetadata(message.from);
        } catch (metaError) {
            if (metaError.toString().includes('forbidden') || metaError.toString().includes('403')) {
                console.error('\x1b[31m[ERROR] Bot no está en el grupo o fue expulsado\x1b[0m');
                return await message.reply('❌ No puedo acceder a la información del grupo. Es posible que haya sido expulsado.');
            }
            throw metaError;
        }
        
        // 2. Obtener el número real del bot de diferentes maneras
        const botJid = conn.user.id;
        
        // Método: Buscar usando múltiples formatos
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        // Buscar al bot en los participantes probando diferentes formatos
        let botParticipant = null;
        
        // MÉTODO 1: Buscar por phoneNumber (más confiable)
        for (const participant of groupMetadata.participants) {
            if (participant.phoneNumber) {
                const phoneNum = participant.phoneNumber.split('@')[0].split(':')[0];
                if (possibleBotNumbers.includes(phoneNum)) {
                    botParticipant = participant;
                    break;
                }
            }
        }
        
        // MÉTODO 2: Buscar por ID (si no se encontró por phoneNumber)
        if (!botParticipant) {
            for (const participant of groupMetadata.participants) {
                const participantNumber = participant.id.split('@')[0].split(':')[0];
                
                // Verificar si coincide con alguno de los posibles números
                if (possibleBotNumbers.includes(participantNumber)) {
                    botParticipant = participant;
                    break;
                }
            }
        }
        
        // Si no encontramos el bot, NO ASUMIR que es admin
        if (!botParticipant) {
            console.log('\x1b[31m[ERROR] No se pudo identificar al bot en la lista de participantes\x1b[0m');
            return await message.reply('❌ No puedo verificar mis permisos en este grupo. Intenta nuevamente.');
        }
        
        // Verificar si el bot es administrador
        const botIsAdmin = botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin';
        
        if (!botIsAdmin) {
            return await message.reply('❌ No puedo expulsar usuarios porque *no soy administrador* del grupo.');
        }
        
        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Obtener el usuario a expulsar ---
        
        let targetUser = null;
        let targetJid = null;
        
        // Método 1: Si se mencionó a un usuario con @
        if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
        }
        // Método 2: Si se respondió a un mensaje
        else if (message.quoted) {
            targetJid = message.quoted.sender;
        }
        // Método 3: Si se escribió el número sin @
        else {
            const text = message.body.split(' ')[1];
            if (text) {
                // Limpiar el número (quitar caracteres no numéricos)
                const cleanNumber = text.replace(/\D/g, '');
                if (cleanNumber) {
                    targetJid = `${cleanNumber}@s.whatsapp.net`;
                }
            }
        }
        
        if (!targetJid) {
            return await message.reply('⚠️ Debes *mencionar* a un usuario con @ o *responder* a su mensaje.\n\n*Ejemplos:*\n`.kick @usuario`\n`.kick 5491123456789`\nO responder a un mensaje con `.kick`');
        }
        
        // Buscar al usuario objetivo en los participantes
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        
        const targetParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === targetNumber;
        });
        
        if (!targetParticipant) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }
        
        // Verificar que no intenten expulsar al bot
        if (botParticipant && targetParticipant.id === botParticipant.id) {
            return await message.reply('❌ No puedo expulsarme a mí mismo del grupo. 😅');
        }
        
        // Verificar que no intenten expulsar a otro admin (opcional, puedes quitarlo si quieres)
        const targetIsAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin';
        
        if (targetIsAdmin && userParticipant.admin !== 'superadmin') {
            return await message.reply('❌ No puedes expulsar a otro administrador.');
        }
        
        // --- Acción de expulsar ---
        
        try {
            // Expulsar al usuario
            await conn.groupParticipantsUpdate(
                message.from,
                [targetParticipant.id],
                'remove'
            );
            
            // Obtener nombre del usuario expulsado
            const targetName = message.quoted?.pushName || 
                              targetNumber || 
                              'Usuario';
            
            // Enviar mensaje de confirmación
            await message.reply(`✅ *Usuario expulsado correctamente.*`);
            
        } catch (kickError) {
            console.error('\x1b[31m[ERROR] Error al expulsar:', kickError.message || kickError, '\x1b[0m');
            
            if (kickError.toString().includes('forbidden') || kickError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos suficientes para expulsar a este usuario. Verifica que siga siendo administrador del grupo.');
            }
            
            if (kickError.toString().includes('not-authorized') || kickError.toString().includes('401')) {
                return await message.reply('❌ No tengo permisos de administrador para expulsar usuarios.\n\n💡 Asegúrate de que el bot sea *administrador* del grupo.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar expulsar al usuario.\n\n💡 Verifica que el bot sea administrador del grupo.');
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando kick:', error.message || error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
    }
};

// --- Configuración del Handler ---
handler.help = ['kick @usuario', 'expulsar @usuario', 'echar @usuario'];
handler.tags = ['admin'];
handler.command = /^(kick|expulsar|echar)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;