/**
 * Comando: deop (CON LOGGING COMPLETO)
 * Descripción: Quita administrador a un usuario del grupo
 * Uso: .deop @usuario o responder a un mensaje con .deop
 * Ubicación: plugins/deop.js
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);
        
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) || 
                   p.id.includes(possibleBotNumbers[0]) || 
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }
        
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        if (!botIsAdmin) {
            // LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'deop', '', false);
            }
            return await message.reply('❌ No puedo degradar usuarios porque *no soy administrador* del grupo.');
        }
        
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            // LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'deop', '', false);
            }
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener el usuario objetivo
        let targetJid = null;
        
        if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
        } else if (message.quoted) {
            targetJid = message.quoted.sender;
        } else {
            const text = message.body.split(' ')[1];
            if (text) {
                const cleanNumber = text.replace(/\D/g, '');
                if (cleanNumber) {
                    targetJid = `${cleanNumber}@s.whatsapp.net`;
                }
            }
        }
        
        if (!targetJid) {
            return await message.reply('⚠️ Debes *mencionar* a un usuario con @ o *responder* a su mensaje.\n\n*Ejemplos:*\n`.deop @usuario`\n`.deop 5491123456789`\nO responder a un mensaje con `.deop`');
        }
        
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        
        const targetParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === targetNumber;
        });
        
        if (!targetParticipant) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }
        
        if (botParticipant && targetParticipant.id === botParticipant.id) {
            return await message.reply('❌ No puedo degradarme a mí mismo. 😅');
        }
        
        const targetIsAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin';
        
        if (!targetIsAdmin) {
            return await message.reply('⚠️ Este usuario no es administrador del grupo.');
        }
        
        // DEGRADAR al usuario
        try {
            await conn.groupParticipantsUpdate(
                message.from,
                [targetParticipant.id],
                'demote'
            );
            
            // ✅ LOG DE COMANDO EXITOSO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'deop', 
                    `Degradó a @${targetNumber}`, 
                    true
                );
            }
            
            await message.reply('👤 *Administrador removido correctamente.*');
            
        } catch (demoteError) {
            console.error('[ERROR] Error al degradar:', demoteError.message);
            
            // ❌ LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'deop', 
                    `Intentó degradar a @${targetNumber}`, 
                    false
                );
            }
            
            if (demoteError.toString().includes('forbidden') || demoteError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos suficientes para degradar a este usuario.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar degradar al usuario.');
        }

    } catch (error) {
        console.error('[ERROR] Error en comando deop:', error.message);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

handler.help = ['deop @usuario', 'deadmin @usuario', 'demote @usuario'];
handler.tags = ['admin'];
handler.command = /^(deop|deadmin|demote)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;