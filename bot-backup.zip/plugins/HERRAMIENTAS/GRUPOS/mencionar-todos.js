// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    // Primero, separa el número si tiene un sufijo, luego limpia (deja solo dígitos).
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

// JIDs o números NORMALIZADOS con permiso especial.
const SPECIAL_USERS_PARTS = [
    normalizeNumber('159893900470'),
    '1149078365237384' // JID de LID
];

let handler = async (message, { text }) => {
    // Verificaciones iniciales
    if (!message.isGroup) {
        return await message.reply('❌ Este comando solo puede usarse en un grupo.');
    }
    
    if (!global.conn) {
        return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
    }

    // Obtener el JID del remitente
    const senderJid = message.author;
    
    if (!senderJid) {
        return await message.reply('❌ No se pudo obtener el identificador de remitente. Inténtalo de nuevo.');
    }
    
    try {
        // Obtener metadatos del grupo
        const groupMetadata = await global.conn.groupMetadata(message.from);
        
        // Normalizar el número del remitente
        const senderNumberNormalized = normalizeNumber(senderJid);
        
        // 🔍 VERIFICACIÓN DE PERMISOS MEJORADA
        
        // 1. Verificar si es usuario especial
        const isSpecialUser = SPECIAL_USERS_PARTS.includes(senderNumberNormalized);
        
        // 2. Verificar si es admin del grupo
        const participantInfo = groupMetadata.participants.find(p => {
            // Comparar tanto por JID completo como por número normalizado
            const participantNumber = normalizeNumber(p.id);
            return p.id === senderJid || participantNumber === senderNumberNormalized;
        });
        
        const isAdmin = participantInfo?.admin === 'admin' || participantInfo?.admin === 'superadmin';
        
        // 3. Debug log (opcional, comentar en producción)
        console.log(`[TAGALL DEBUG] Usuario: ${senderNumberNormalized} | Admin: ${isAdmin} | Special: ${isSpecialUser}`);
        
        // 4. Verificar permisos: debe ser admin O usuario especial
        if (!isAdmin && !isSpecialUser) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }
        
        // ✅ Si llegó aquí, tiene permisos. Ejecutar comando.
        
        // Obtener todos los participantes del grupo
        const participants = groupMetadata.participants.map(p => p.id);
        
        // Crear el texto con las menciones
        const mentionLines = participants.map(participant => {
            const number = participant.split('@')[0];
            return `@${number}`;
        });
        
        const messageText = mentionLines.join('\n');
        
        // Enviar mensaje con menciones
        await message.reply(messageText, { mentions: participants });
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al usar el comando todos (tagall):', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al obtener o mencionar a los participantes del grupo.');
    }
};

handler.help = ['todos', 'tagall'];
handler.tags = ['group'];
handler.command = /^(todos|tagall)$/i;
handler.group = true;

module.exports = handler;