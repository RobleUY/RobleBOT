/**
 * Plugin: inactivos / topinactivos
 * Muestra los miembros del grupo que no han enviado mensajes
 * en el período de tiempo indicado.
 *
 * Uso:
 *   .inactivos 1d      → sin mensaje en las últimas 24 horas
 *   .inactivos 12h     → sin mensaje en las últimas 12 horas
 *   .inactivos 30m     → sin mensaje en los últimos 30 minutos
 *   .topinactivos 7d   → alias del mismo comando
 */

// ── Parsear tiempo ────────────────────────────────────────────────────────────
function parseTime(str) {
    if (!str) return null;
    const match = str.trim().match(/^(\d+(?:\.\d+)?)\s*(m|h|d|s)$/i);
    if (!match) return null;

    const value = parseFloat(match[1]);
    const unit  = match[2].toLowerCase();

    const multipliers = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
    return value * multipliers[unit];
}

// ── Formatear duración legible ────────────────────────────────────────────────
function formatDuration(ms) {
    const d = Math.floor(ms / 86_400_000);
    const h = Math.floor((ms % 86_400_000) / 3_600_000);
    const m = Math.floor((ms % 3_600_000) / 60_000);

    const parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    return parts.length ? parts.join(' ') : 'menos de 1m';
}

// ── Handler principal ─────────────────────────────────────────────────────────
let handler = async (message, { text, args, conn }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    // Solo en grupos
    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    // Verificar que quien lo usa es admin o owner
    const senderJid = message.author || message.sender;
    const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');

    let isAdmin = false;
    try {
        const meta = await conn.groupMetadata(chatId);
        const participant = meta.participants.find(p => {
            const n = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
            return n === senderNum;
        });
        isAdmin = participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch (_) {}

    const isOwner = (global.botConfig?.isOwner?.(senderNum) || global.botConfig?.isOwner?.(`${senderNum}@s.whatsapp.net`));

    if (!isAdmin && !isOwner) {
        return message.reply('⚠️ Solo los administradores pueden usar este comando.');
    }

    // Parsear el tiempo del argumento
    const timeArg = args[0] || text?.trim().split(' ')[0];
    const thresholdMs = parseTime(timeArg);

    if (!thresholdMs) {
        return message.reply(
            '❌ Formato incorrecto.\n\n' +
            '📌 Uso: *.inactivos <tiempo>*\n\n' +
            'Ejemplos:\n' +
            '• .inactivos 1d  → inactivos en 24h\n' +
            '• .inactivos 12h → inactivos en 12h\n' +
            '• .inactivos 30m → inactivos en 30min\n' +
            '• .inactivos 7d  → inactivos en 7 días'
        );
    }

    const now = Date.now();
    const cutoff = now - thresholdMs;

    // Obtener miembros del grupo
    let participants = [];
    try {
        const meta = await conn.groupMetadata(chatId);
        participants = meta.participants || [];
    } catch (err) {
        return message.reply('❌ No pude obtener la lista de miembros del grupo.');
    }

    // Obtener actividad registrada para este grupo
    const groupActivity = global.db?.data?.groupActivity?.[chatId] || {};

    // Filtrar inactivos: miembros cuyo último mensaje fue antes del cutoff
    // o que nunca han enviado un mensaje (no están en el registro)
    const inactivos = [];

    for (const p of participants) {
        const num = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');

        // Ignorar al propio bot
        const botNum = global.mainBotNumber || '';
        if (num === botNum) continue;

        // Ignorar subbots
        const subNums = (global.subConns || [])
            .filter(c => c?.user)
            .map(c => c.user.id.split('@')[0].split(':')[0].replace(/\D/g, ''));
        if (subNums.includes(num)) continue;

        const lastSeen = (typeof groupActivity[num] === 'object')
            ? (groupActivity[num]?.last || 0)
            : (groupActivity[num] || 0);

        if (lastSeen < cutoff) {
            let apodo = '';
            try {
                const userData = global.db?.getUser?.(num);
                apodo = (userData?.apodo || '').trim();
            } catch (_) {}

            inactivos.push({
                jid: p.id,
                num,
                apodo,
                lastSeen,
                isAdmin: p.admin === 'admin' || p.admin === 'superadmin'
            });
        }
    }

    if (inactivos.length === 0) {
        return message.reply(
            `✅ No hay miembros inactivos en las últimas *${formatDuration(thresholdMs)}*.\n` +
            `Todos han enviado al menos un mensaje en ese período.`
        );
    }

    // Ordenar: primero los que llevan más tiempo sin escribir
    inactivos.sort((a, b) => a.lastSeen - b.lastSeen);

    // Construir mensaje con menciones
    const mentions = inactivos.map(u => u.jid);

    let lines = [];
    lines.push(`🔇 *Inactivos en las últimas ${formatDuration(thresholdMs)}*`);
    lines.push(`📊 Total: *${inactivos.length}* de *${participants.length}* miembros\n`);

    inactivos.forEach((u, i) => {
        const tag = `@${u.num}`;
        const nombre = u.apodo ? ` (${u.apodo})` : '';
        const adminTag = u.isAdmin ? ' 👑' : '';
        const tiempoStr = u.lastSeen > 0
            ? `hace ${formatDuration(now - u.lastSeen)}`
            : 'nunca ha escrito';
        lines.push(`${i + 1}. ${tag}${nombre}${adminTag} — ${tiempoStr}`);
    });

    lines.push(`\n⚠️ _Solo se registran mensajes desde que el bot está activo._`);

    await sock.sendMessage(chatId, {
        text: lines.join('\n'),
        mentions
    }, { quoted: message.baileyMessage || message._baileyMessage });
};

handler.help    = ['inactivos <tiempo>', 'topinactivos <tiempo>'];
handler.tags    = ['grupos', 'admin'];
handler.command = /^(inactivos|topinactivos|hijosdeputa)$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;

