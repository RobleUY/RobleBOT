const fs = require('fs')
const path = require('path')

const CHAT_USUARIOS_DIR = path.join(__dirname, '../../../CHATS-USUARIOS')

/**
 * Parsea el argumento de tiempo y devuelve los ms equivalentes.
 * Acepta: 1d, 2d, 3 dias, 1 dia, 2dias, etc.
 */
function parseTiempo(texto) {
    if (!texto) return null

    // Normalizar: quitar tildes, pasar a minúsculas
    const norm = texto.toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, '')

    // Patrones: 1d | 2dias | 3dia | 1h | 2horas | 30m | 30min
    const match = norm.match(/^(\d+(?:\.\d+)?)(d(?:ia(?:s)?)?|h(?:ora(?:s)?)?|m(?:in(?:utos?)?)?)$/)
    if (!match) return null

    const valor = parseFloat(match[1])
    const unidad = match[2]

    if (unidad.startsWith('d')) return valor * 24 * 60 * 60 * 1000
    if (unidad.startsWith('h')) return valor * 60 * 60 * 1000
    if (unidad.startsWith('m')) return valor * 60 * 1000

    return null
}

/**
 * Obtiene el timestamp del último mensaje de un usuario en un grupo.
 * Devuelve null si no tiene archivo o está vacío.
 */
function getUltimoMensaje(numero, groupId) {
    const file = path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
    if (!fs.existsSync(file)) return null

    try {
        const contenido = fs.readFileSync(file, 'utf-8').trim()
        if (!contenido) return null

        const lineas = contenido.split('\n').filter(Boolean)
        // La última línea con timestamp
        for (let i = lineas.length - 1; i >= 0; i--) {
            const match = lineas[i].match(/^\[(.+?)\]/)
            if (match) {
                const ts = new Date(match[1]).getTime()
                if (!isNaN(ts)) return ts
            }
        }
        return null
    } catch {
        return null
    }
}

/**
 * Formatea ms en texto legible: "2d 3h", "5h 20m", etc.
 */
function formatTiempo(ms) {
    const d = Math.floor(ms / (24 * 60 * 60 * 1000))
    const h = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))
    const m = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000))

    const partes = []
    if (d > 0) partes.push(`${d}d`)
    if (h > 0) partes.push(`${h}h`)
    if (m > 0 && d === 0) partes.push(`${m}m`) // solo mostrar minutos si no hay días
    return partes.length ? partes.join(' ') : 'menos de 1m'
}

let handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup)
            return message.reply('❌ Este comando solo puede usarse en grupos.')

        if (!text || !text.trim())
            return message.reply(
                '❌ *Uso:* .inactivos <tiempo>\n\n' +
                '*Ejemplos:*\n' +
                '• .inactivos 1d\n' +
                '• .inactivos 2 dias\n' +
                '• .inactivos 12h\n' +
                '• .inactivos 3 horas'
            )

        const umbralMs = parseTiempo(text.trim())
        if (!umbralMs)
            return message.reply(
                '❌ Formato de tiempo inválido.\n\n' +
                '*Ejemplos válidos:*\n' +
                '• 1d / 2dias / 3 dias\n' +
                '• 12h / 6 horas\n' +
                '• 30m / 45 minutos'
            )

        await message.reply('⏳ Analizando actividad del grupo...')

        const groupId = message.from
        const metadata = await conn.groupMetadata(groupId)
        const participants = metadata.participants

        const ahora = Date.now()
        const inactivos = []
        const sinRegistro = []

        for (const p of participants) {
            const numero = p.id.split('@')[0].replace(/\D/g, '')
            const ultimoMsg = getUltimoMensaje(numero, groupId)

            if (ultimoMsg === null) {
                // Nunca ha enviado mensajes registrados
                sinRegistro.push({ jid: p.id, numero })
            } else {
                const diff = ahora - ultimoMsg
                if (diff >= umbralMs) {
                    inactivos.push({ jid: p.id, numero, diff })
                }
            }
        }

        // Ordenar inactivos: los más inactivos primero
        inactivos.sort((a, b) => b.diff - a.diff)

        const totalInactivos = inactivos.length + sinRegistro.length

        if (totalInactivos === 0) {
            return message.reply(`✅ ¡Todos los miembros han enviado mensajes en las últimas *${text.trim()}*!`)
        }

        // Construir mensaje
        const tiempoLabel = text.trim()
        let txt = `😴 *INACTIVOS — últimas ${tiempoLabel}*\n`
        txt += `👥 Total: *${totalInactivos}* de ${participants.length} miembros\n`
        txt += `${'─'.repeat(30)}\n\n`

        const mentions = []

        // Usuarios con último mensaje conocido pero inactivos
        if (inactivos.length > 0) {
            txt += `*⏰ Sin actividad hace:*\n\n`
            for (const u of inactivos) {
                txt += `@${u.numero}\n`
                txt += `└ ⏱️ hace *${formatTiempo(u.diff)}*\n\n`
                mentions.push(u.jid)
            }
        }

        // Usuarios sin ningún mensaje registrado
        if (sinRegistro.length > 0) {
            txt += `*👻 Sin mensajes registrados:*\n\n`
            for (const u of sinRegistro) {
                txt += `@${u.numero}\n`
                txt += `└ ❓ nunca ha escrito\n\n`
                mentions.push(u.jid)
            }
        }

        txt += `\n_Umbral: mensajes sin actividad en ${tiempoLabel}_`

        return message.reply(txt.trim(), { mentions })

    } catch (err) {
        console.error('[INACTIVOS ERROR]', err?.message || err)
        return message.reply('❌ Error al analizar inactivos.')
    }
}

handler.help = ['inactivos <tiempo>']
handler.tags = ['grupos']
handler.command = /^inactivos$/i
handler.group = true

module.exports = handler
