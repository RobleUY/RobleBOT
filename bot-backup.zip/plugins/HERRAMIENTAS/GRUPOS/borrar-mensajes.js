let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }
        
        // Verificar que haya un mensaje al cual responder (citado)
        if (!message.quoted) {
            return await message.reply('⚠️ Debes *responder* al mensaje que quieres eliminar con el comando `.borrar`.');
        }

        // --- Verificaciones de permisos ---
        
        // 1. Obtener metadatos y participantes
        const groupMetadata = await conn.groupMetadata(message.from);
        
        // 2. Obtener el número real del bot de diferentes maneras
        let botNumber;
        
        // Método 1: Desde conn.user.id
        const botJid = conn.user.id;
        console.log('\x1b[36m[DEBUG] Bot JID desde conn.user.id:', botJid, '\x1b[0m');
        
        // Método 2: Buscar mensajes del bot en el grupo (fromMe = true)
        const botMessage = groupMetadata.participants.find(p => {
            // El bot será el que tiene fromMe en sus mensajes
            return p.id.includes('@lid') || p.id.includes('s.whatsapp.net');
        });
        
        console.log('\x1b[36m[DEBUG] Participantes completos:\x1b[0m');
        groupMetadata.participants.forEach(p => {
            console.log(`  - ${p.id} (admin: ${p.admin || 'no'})`);
        });
        
        // Método 3: Extraer del mensaje actual si es del bot
        if (message.key && message.key.fromMe) {
            const myJid = message.key.remoteJid;
            botNumber = myJid.split('@')[0].split(':')[0];
            console.log('\x1b[36m[DEBUG] Bot número desde message.key:', botNumber, '\x1b[0m');
        }
        
        // Método 4: Buscar usando múltiples formatos
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        console.log('\x1b[36m[DEBUG] Posibles números del bot:', possibleBotNumbers, '\x1b[0m');
        
        // Buscar al bot en los participantes probando diferentes formatos
        let botParticipant;
        
        for (const participant of groupMetadata.participants) {
            const participantNumber = participant.id.split('@')[0].split(':')[0];
            
            // Verificar si coincide con alguno de los posibles números
            if (possibleBotNumbers.includes(participantNumber)) {
                botParticipant = participant;
                console.log('\x1b[32m[DEBUG] ¡Bot encontrado! Participant:', participant.id, '\x1b[0m');
                break;
            }
            
            // También verificar si el participant.id contiene alguna parte del botJid
            if (participant.id.includes(possibleBotNumbers[0]) || participant.id.includes(possibleBotNumbers[1])) {
                botParticipant = participant;
                console.log('\x1b[32m[DEBUG] ¡Bot encontrado por coincidencia parcial! Participant:', participant.id, '\x1b[0m');
                break;
            }
        }
        
        console.log('\x1b[36m[DEBUG] Bot Participant encontrado:', botParticipant, '\x1b[0m');
        
        // Si no encontramos el bot, buscar quién envió el mensaje de comando
        if (!botParticipant) {
            console.log('\x1b[33m[WARN] No se encontró el bot por número, buscando de otra forma...\x1b[0m');
            
            // Buscar el participante que tenga el mismo formato que los mensajes del bot
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && p.admin;
            });
            
            console.log('\x1b[36m[DEBUG] Bot encontrado como admin con @lid:', botParticipant, '\x1b[0m');
        }
        
        // Verificar si el bot es administrador
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        if (!botIsAdmin) {
            return await message.reply('❌ No puedo eliminar mensajes porque *no soy administrador* del grupo.');
        }
        
        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        console.log('\x1b[36m[DEBUG] User JID:', userJid, '\x1b[0m');
        console.log('\x1b[36m[DEBUG] User número:', userNumber, '\x1b[0m');
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        console.log('\x1b[36m[DEBUG] User Participant encontrado:', userParticipant, '\x1b[0m');
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Acción de Eliminar ---
        
        console.log('\x1b[36m[DEBUG] Mensaje citado key:', JSON.stringify(message.quoted.key, null, 2), '\x1b[0m');
        
        // Verificar que el mensaje citado tenga una key válida
        if (!message.quoted.key || !message.quoted.key.id) {
            return await message.reply('❌ No se pudo obtener la información del mensaje citado. Intenta de nuevo.');
        }
        
        try {
            // Eliminar el mensaje citado
            await conn.sendMessage(message.from, { delete: message.quoted.key });
            console.log('\x1b[32m[SUCCESS] Mensaje citado eliminado correctamente\x1b[0m');
            
            // Eliminar el mensaje del comando
            await conn.sendMessage(message.from, { delete: message.key });
            console.log('\x1b[32m[SUCCESS] Mensaje del comando eliminado correctamente\x1b[0m');
            
        } catch (deleteError) {
            console.error('\x1b[31m[ERROR] Error al eliminar:', deleteError, '\x1b[0m');
            
            // Intentar método alternativo para el mensaje citado
            try {
                console.log('\x1b[33m[WARN] Intentando método alternativo para mensaje citado...\x1b[0m');
                
                const alternativeKey = {
                    remoteJid: message.from,
                    id: message.quoted.id,
                    participant: message.quoted.sender,
                    fromMe: message.quoted.fromMe || false
                };
                
                console.log('\x1b[36m[DEBUG] Key alternativa:', JSON.stringify(alternativeKey, null, 2), '\x1b[0m');
                
                await conn.sendMessage(message.from, { delete: alternativeKey });
                console.log('\x1b[32m[SUCCESS] Mensaje citado eliminado con método alternativo\x1b[0m');
                
                // Intentar eliminar el mensaje del comando también
                try {
                    await conn.sendMessage(message.from, { delete: message.key });
                    console.log('\x1b[32m[SUCCESS] Mensaje del comando eliminado\x1b[0m');
                } catch (cmdError) {
                    console.error('\x1b[31m[ERROR] No se pudo eliminar el mensaje del comando\x1b[0m');
                }
                
            } catch (altError) {
                console.error('\x1b[31m[ERROR] Método alternativo también falló:', altError, '\x1b[0m');
                return await message.reply('❌ No se pudo eliminar el mensaje. Puede ser muy antiguo o no tengo permisos suficientes.');
            }
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error general al usar .borrar:', error, '\x1b[0m');
        console.error('\x1b[31m[ERROR] Stack:', error.stack, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error inesperado al intentar eliminar el mensaje.');
    }
};

// --- Configuración del Handler ---
handler.help = ['borrar'];
handler.tags = ['admin'];
handler.command = /^(borrar|delete|del)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;