const fs = require('fs');
const path = require('path');

const DURATION_MAP = {
    '24h': 86400,
    '7d':  604800,
    '30d': 2592000,
};

// Archivo donde guardamos las keys de mensajes fijados por grupo
const PINNED_FILE = path.join(__dirname, 'pinned-messages.json');

function loadPinned() {
    try {
        if (fs.existsSync(PINNED_FILE)) {
            return JSON.parse(fs.readFileSync(PINNED_FILE, 'utf-8'));
        }
    } catch (_) {}
    return {};
}

function savePinned(data) {
    try {
        fs.writeFileSync(PINNED_FILE, JSON.stringify(data, null, 2));
    } catch (_) {}
}

let handler = async (message, { conn, args, command }) => {
    const sock = conn || message._sock || global.conn;
    if (!message.isGroup) return message.reply('❌ Este comando solo puede usarse en un grupo.');

    const quotedMessage = message.quoted;
    if (!quotedMessage) return message.reply('⚠️ Debes *responder* a un mensaje para fijarlo o desfijarlo.');

    try {
        const groupMetadata = await conn.groupMetadata(message.from);
        const participants = groupMetadata.participants || [];

        // --- Verificación bot admin ---
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });

        if (!botParticipant) {
            botParticipant = participants.find(p =>
                p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin')
            );
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        if (!botIsAdmin) return message.reply('❌ No puedo fijar/desfijar mensajes porque *no soy administrador* del grupo.');

        // --- Verificación usuario admin ---
        const userNumber = message.sender.split('@')[0].split(':')[0];
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });

        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        if (!userIsAdmin) return message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');

        // --- Construir key del mensaje citado ---
        const botNumber = possibleBotNumbers[0];
        const quotedSenderNumber = (quotedMessage.sender || '').split('@')[0].split(':')[0];
        const quotedFromMe = quotedSenderNumber === botNumber;

        const messageKey = {
            remoteJid: message.from,
            id: quotedMessage.id,
            participant: quotedMessage.sender || quotedMessage.key?.participant || undefined,
            fromMe: quotedFromMe
        };

        const isPinCommand = /^(pin|fijar)$/i.test(command);

        if (isPinCommand) {
            const durationArg = (args[0] || '').toLowerCase();
            const durationSeconds = DURATION_MAP[durationArg] || DURATION_MAP['24h'];
            const durationText = Object.keys(DURATION_MAP).find(k => DURATION_MAP[k] === durationSeconds) || '24h';

            await sock.sendMessage(message.from, {
                pin: messageKey,
                type: 1,
                time: durationSeconds
            });

            // Guardar la key para poder desfijar después
            const pinned = loadPinned();
            if (!pinned[message.from]) pinned[message.from] = {};
            pinned[message.from][quotedMessage.id] = messageKey;
            savePinned(pinned);

            return message.reply(`✅ Mensaje fijado por *${durationText}*.`);

        } else {
            // Buscar la key guardada cuando se fijó
            const pinned = loadPinned();
            const savedKey = pinned[message.from]?.[quotedMessage.id];

            if (!savedKey) {
                return message.reply('⚠️ No puedo desfijar ese mensaje porque no fue fijado con este bot, o ya fue desfijado.');
            }

            await sock.sendMessage(message.from, {
                pin: savedKey,
                type: 2,  // UNPIN_FOR_ALL = 2 (no 0, que es UNKNOWN_TYPE)
                time: 0
            });

            // Eliminar del registro
            delete pinned[message.from][quotedMessage.id];
            if (Object.keys(pinned[message.from]).length === 0) delete pinned[message.from];
            savePinned(pinned);

            return message.reply('✅ Mensaje desfijado correctamente.');
        }

    } catch (error) {
        console.error('[ERROR PIN/UNPIN]:', error);
        return message.reply('❌ Ocurrió un error al fijar/desfijar el mensaje.');
    }
};

handler.help = ['pin [24h|7d|30d]', 'unpin'];
handler.tags = ['admin'];
handler.command = /^(pin|unpin|fijar|desfijar)$/i;
handler.group = true;

module.exports = handler;

