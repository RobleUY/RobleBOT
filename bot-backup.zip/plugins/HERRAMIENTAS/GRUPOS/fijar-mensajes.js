/**
 * Comando: pin, unpin, fijar, desfijar
 * Descripción: Fija o desfija un mensaje en el chat de grupo.
 * Compatible con LIDs (multi-dispositivo y versiones modernas de Baileys)
 */

const cleanJid = (jid = '') => jid.split('@')[0].split(':')[0].replace(/\D/g, '');
const getBaseNumber = (jid = '') => jid?.replace(/[^0-9]/g, '') || '';

const DURATION_MAP_SECONDS = {
    '24h': 86400,
    '7d': 604800,
    '30d': 2592000,
    'default': 86400
};

let handler = async (message, { conn, args, command }) => {
    if (!message.isGroup) return message.reply('❌ Este comando solo puede usarse en un grupo.');

    const quotedMessage = message.quoted;
    if (!quotedMessage) return message.reply('⚠️ Debes *responder* a un mensaje para fijarlo o desfijarlo.');

    try {
        const groupMetadata = await conn.groupMetadata(message.from);
        const participants = groupMetadata.participants || [];

        // --- Identificación segura del bot ---
        const botIdRaw = conn.user?.id || '';
        const botJid = typeof conn.decodeJid === 'function' ? conn.decodeJid(botIdRaw) : botIdRaw;
        const botNumber = getBaseNumber(botIdRaw);
        const senderNumber = getBaseNumber(message.sender);

        let botParticipant = participants.find(p => {
            const idNum = getBaseNumber(p.id);
            return idNum === botNumber || p.id.includes(botJid.split('@')[0]);
        });

        if (!botParticipant && participants.length > 0) {
            const possibleLid = participants.find(p => p.id.includes('@lid'));
            if (possibleLid) {
                console.warn(`[INFO] Usando posible ID LID para el bot: ${possibleLid.id}`);
                botParticipant = possibleLid;
            }
        }

        const botIsAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
        const senderParticipant = participants.find(p => getBaseNumber(p.id) === senderNumber);
        const senderIsAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';

        if (!botIsAdmin) return await message.reply('❌ No puedo fijar/desfijar mensajes porque *no soy administrador* del grupo.');
        if (!senderIsAdmin) return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');

        // --- Lógica de fijado/desfijado ---
        const messageKey = {
            remoteJid: message.from,
            id: quotedMessage.id,
            participant: quotedMessage.sender
        };

        const isPinCommand = ['pin', 'fijar'].includes(command.toLowerCase());
        const isUnpinCommand = ['unpin', 'desfijar'].includes(command.toLowerCase());
        let logMessage = '';

        // Intentar obtener lista de mensajes fijados actuales
        let pinnedMessages = [];
        try {
            const info = await conn.groupMetadata(message.from);
            pinnedMessages = info.pinnedMessages || [];
        } catch { }

        if (isPinCommand) {
            const durationArg = args[0]?.toLowerCase();
            const durationSeconds = DURATION_MAP_SECONDS[durationArg] || DURATION_MAP_SECONDS['default'];
            const durationText = Object.keys(DURATION_MAP_SECONDS).find(
                key => DURATION_MAP_SECONDS[key] === durationSeconds
            ) || '24h';

            if (conn.groupPinMessage) {
                await conn.groupPinMessage(message.from, messageKey, true);
                await message.reply(`✅ Mensaje fijado correctamente por *${durationText}*.`);
            } else {
                await message.reply('⚠️ Tu versión de Baileys no soporta groupPinMessage(). Actualízala.');
            }

            logMessage = `Fijado por ${durationText}.`;

        } else if (isUnpinCommand) {
            const pinnedIds = pinnedMessages.map(m => m?.id).filter(Boolean);
            const isAlreadyPinned = pinnedIds.includes(quotedMessage.id);

            if (!isAlreadyPinned && pinnedMessages.length > 0) {
                await message.reply('⚠️ El mensaje citado no está fijado actualmente.');
                return;
            }

            if (conn.groupPinMessage) {
                await conn.groupPinMessage(message.from, messageKey, false);
                await message.reply('✅ Mensaje desfijado correctamente.');
            } else {
                await message.reply('⚠️ Tu versión de Baileys no soporta groupPinMessage(). Actualízala.');
            }

            logMessage = `Desfijado.`;
        }

        if (global.commandLogger) {
            global.commandLogger.logCommand(message, command, logMessage, true);
        }

    } catch (error) {
        console.error('[ERROR PIN/UNPIN]:', error);
        await message.reply('❌ Ocurrió un error al ejecutar el comando. Revisa la consola.');
    }
};

handler.help = ['pin [duración]', 'unpin'];
handler.tags = ['admin'];
handler.command = /^(pin|unpin|fijar|desfijar)$/i;
handler.group = true;

module.exports = handler;
