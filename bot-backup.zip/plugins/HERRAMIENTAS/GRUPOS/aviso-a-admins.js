// --- CONSTANTES Y UTILIDADES GLOBALES ---

// Cooldown de 30 segundos
const COOLDOWN_SECONDS = 30; 
// Almacenamiento de cuándo fue la última vez que un usuario usó el comando
const cooldowns = new Map(); 

// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    // Primero, separa el número si tiene un sufijo, luego limpia (deja solo dígitos).
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

// JIDs o números NORMALIZADOS con permiso especial (exentos de cooldown).
const SPECIAL_USERS_PARTS = [
    normalizeNumber('59893900470'),
    '149078365237384' // El JID de 15 dígitos que aparece en tu log (@lid).
];

let handler = async (message, { text }) => {
    // 1. Verificación: solo en grupos
    if (!message.isGroup) {
        return await message.reply('❌ Este comando solo puede usarse en un grupo.');
    }

    if (!global.conn) {
        return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
    }
    
    const senderJid = message.author;
    if (!senderJid) {
        return await message.reply('❌ No se pudo obtener el identificador de remitente.');
    }
    
    // --- LÓGICA DE COOLDOWN Y USUARIO ESPECIAL ---
    
    const senderNumberNormalized = normalizeNumber(senderJid);
    const isSpecialUser = SPECIAL_USERS_PARTS.includes(senderNumberNormalized);
    
    // Si NO es el usuario especial, aplicamos el cooldown
    if (!isSpecialUser) {
        const now = Date.now();
        const lastUsed = cooldowns.get(senderJid);
        const cooldownTime = COOLDOWN_SECONDS * 1000;

        if (lastUsed && now < lastUsed + cooldownTime) {
            const remaining = (lastUsed + cooldownTime - now) / 1000;
            return await message.reply(`⏳ Este comando tiene un *cooldown* de ${COOLDOWN_SECONDS} segundos. Por favor, espera ${remaining.toFixed(1)} segundos.`);
        }
        
        // Actualizar el tiempo de uso si el comando procede
        cooldowns.set(senderJid, now);
    }
    
    // ---------------------------------------------
    
    const messageToAdmins = text.trim();

    if (!messageToAdmins) {
        return await message.reply('❌ Debes escribir el mensaje que quieres enviar a los administradores. Ejemplo: .admins revisen la foto que envié.');
    }

    const senderNumber = senderJid.split('@')[0];

    try {
        // Obtener metadatos del grupo
        const groupMetadata = await global.conn.groupMetadata(message.from);
        
        // Filtrar y obtener los JIDs de solo los administradores
        const adminParticipants = groupMetadata.participants.filter(p => p.admin != null);
        
        // Obtener los JIDs de los administradores que serán mencionados
        const adminJids = adminParticipants.map(p => p.id);
        
        if (adminJids.length === 0) {
            return await message.reply('⚠️ No se encontraron administradores en este grupo.');
        }

        // 2. Construcción del mensaje para los administradores
        
        // a) Las menciones de los administradores (una por línea)
        const mentionLines = adminJids.map(jid => {
            const number = jid.split('@')[0];
            return `@${number}`;
        }).join('\n');
        
        // b) El mensaje final con la mención del remitente
        let finalMessage = `📣 *ATENCIÓN ADMINISTRADORES* 📣\n\n`;
        
        // Incluir la lista de menciones al inicio
        finalMessage += mentionLines + '\n\n';
        
        // Incluir la nota del remitente y su mensaje
        finalMessage += `👤 @${senderNumber} ha enviado un mensaje:\n\n`;
        finalMessage += `*Mensaje:* ${messageToAdmins}\n\n`;
        finalMessage += `*¡Por favor, revisen!*`;

        // Los JIDs a etiquetar deben incluir a todos los admins MÁS al remitente
        const allJidsToMention = [...adminJids, senderJid].filter(Boolean);
        
        // Enviar el mensaje
        await message.reply(finalMessage, { mentions: allJidsToMention });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al usar el comando admins:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al obtener o mencionar a los administradores.');
    }
};

handler.help = ['admins', 'admin'];
handler.tags = ['group'];
handler.command = /^(admins|admin)$/i;
handler.group = true; 

module.exports = handler;