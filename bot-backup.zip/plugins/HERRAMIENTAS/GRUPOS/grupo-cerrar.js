/**
 * Comando: close / cerrar
 * Descripción: Cierra el grupo (solo admins pueden enviar mensajes)
 * Uso: .close
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);

        // --- Verificación de permisos del Bot ---
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        // Buscar el bot en los participantes
        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            // Fallback
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }
        
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        if (!botIsAdmin) {
            return await message.reply('❌ No puedo cerrar el grupo porque *no soy administrador* del mismo.');
        }

        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Acción de cerrar el grupo (Solo Admins) ---
        try {
            await conn.groupSettingUpdate(message.from, 'announcement'); // 'announcement' = Solo Admins pueden enviar mensajes
            
            await message.reply('🔒 *¡Grupo cerrado!* Solo los administradores pueden enviar mensajes ahora.');
            
        } catch (updateError) {
            console.error('[ERROR] Error al cerrar grupo:', updateError.message);
            
            if (updateError.toString().includes('forbidden') || updateError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos para editar la configuración del grupo.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar cerrar el grupo.');
        }

    } catch (error) {
        console.error('[ERROR] Error en comando close:', error.message);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

handler.help = ['close', 'cerrar'];
handler.tags = ['admin'];
handler.command = /^(close|cerrar|modoadmins)$/i; // Se añadió 'modoadmins' como alias
handler.group = true;
handler.admin = true;

module.exports = handler;