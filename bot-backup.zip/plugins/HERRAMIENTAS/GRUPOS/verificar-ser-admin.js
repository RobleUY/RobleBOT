/**
 * Comando: vadmin
 * Descripción: Verifica si el usuario que ejecuta el comando es administrador en el grupo del enlace.
 * Uso: .vadmin https://chat.whatsapp.com/XXXXXXX
 */

const handler = async (message, { conn, text }) => {
    try {
        // ============================
        // VERIFICAR TEXTO
        // ============================
        if (!text) {
            return await message.reply(
                "⚠️ Debes proporcionar un *enlace de invitación* del grupo.\n\n" +
                "Ejemplo:\n.vadmin https://chat.whatsapp.com/ABC123xyz"
            );
        }

        // ============================
        // EXTRAER CÓDIGO DEL LINK
        // ============================
        let inviteCode = null;

        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        const codeMatch = text.match(/^([0-9A-Za-z]{20,24})$/);
        if (!inviteCode && codeMatch) inviteCode = codeMatch[1];

        if (!inviteCode) {
            return await message.reply("⚠️ Link *no válido*. Debes enviar un link de invitación válido.");
        }

        await message.reply("⏳ Obteniendo información del grupo...");

        // ============================
        // OBTENER INFO DEL GRUPO
        // ============================
        let groupInfo;
        try {
            groupInfo = await conn.groupGetInviteInfo(inviteCode);
        } catch (e) {
            const msg = e.toString().toLowerCase();
            if (msg.includes("invalid") || msg.includes("not found")) {
                return await message.reply("❌ El link de invitación *no es válido* o ha *expirado*.");
            }
            return await message.reply("❌ No pude obtener la información de ese grupo.");
        }

        const groupJid = groupInfo.id;

        if (!groupJid) {
            return await message.reply("❌ No pude identificar el grupo del enlace.");
        }

        // ============================
        // OBTENER PARTICIPANTES
        // ============================
        let metadata;
        try {
            metadata = await conn.groupMetadata(groupJid);
        } catch {
            return await message.reply("❌ No tengo permiso para ver los detalles de ese grupo.");
        }

        const participants = metadata.participants || [];

        // ============================
        // IDENTIFICAR AL USUARIO
        // ============================
        const senderJid = message?.key?.participant || message?.sender || null;

        if (!senderJid) {
            return await message.reply("❌ No pude identificar quién envió el mensaje.");
        }

        const user = participants.find(p => p.id === senderJid);

        if (!user) {
            return await message.reply(
                `⚠️ No estás en el grupo *${metadata.subject}*.\n\n` +
                "Por lo tanto, no puedes ser admin ahí."
            );
        }

        // ============================
        // VERIFICAR SI ES ADMIN
        // ============================
        const isAdmin = user.admin === "admin" || user.admin === "superadmin";

        if (isAdmin) {
            return await message.reply(
                `✅ *Sí eres administrador* del grupo:\n\n` +
                `🏷️ *${metadata.subject}*\n\n` +
                `👑 Rol: *${user.admin === "superadmin" ? "Super Admin" : "Admin"}*`
            );
        } else {
            return await message.reply(
                `❌ *No eres administrador* del grupo:\n\n` +
                `🏷️ *${metadata.subject}*`
            );
        }

    } catch (err) {
        console.error("[ERROR - vadmin]:", err);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

handler.help = ['vadmin <link>'];
handler.tags = ['tools'];
handler.command = /^(vadmin|veradmin)$/i;

module.exports = handler;
