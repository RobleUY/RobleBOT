/**
 * Comando: op (CON LOGGING COMPLETO)
 * Descripción: Da administrador a un usuario del grupo
 * Uso: .op @usuario o responder a un mensaje con .op
 * Ubicación: plugins/op.js
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);
        
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        let botParticipant;
        
        for (const participant of groupMetadata.participants) {
            const participantNumber = participant.id.split('@')[0].split(':')[0];
            
            if (possibleBotNumbers.includes(participantNumber)) {
                botParticipant = participant;
                break;
            }
            
            if (participant.id.includes(possibleBotNumbers[0]) || participant.id.includes(possibleBotNumbers[1])) {
                botParticipant = participant;
                break;
            }
        }
        
        if (!botParticipant) {
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && p.admin;
            });
        }
        
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        if (!botIsAdmin) {
            // LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'op', '', false);
            }
            return await message.reply('❌ No puedo promover usuarios porque *no soy administrador* del grupo.');
        }
        
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            // LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'op', '', false);
            }
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener el usuario objetivo
        let targetJid = null;
        
        if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
        } else if (message.quoted) {
            targetJid = message.quoted.sender;
        } else {
            const text = message.body.split(' ')[1];
            if (text) {
                const cleanNumber = text.replace(/\D/g, '');
                if (cleanNumber) {
                    targetJid = `${cleanNumber}@s.whatsapp.net`;
                }
            }
        }
        
        if (!targetJid) {
            return await message.reply('⚠️ Debes *mencionar* a un usuario con @ o *responder* a su mensaje.\n\n*Ejemplos:*\n`.op @usuario`\n`.op 5491123456789`\nO responder a un mensaje con `.op`');
        }
        
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        
        const targetParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === targetNumber;
        });
        
        if (!targetParticipant) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }
        
        if (botParticipant && targetParticipant.id === botParticipant.id) {
            return await message.reply('❌ No puedo promoverme a mí mismo. 😅');
        }
        
        const targetIsAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin';
        
        if (targetIsAdmin) {
            return await message.reply('⚠️ Este usuario ya es administrador del grupo.');
        }
        
        // Acción de promover
        try {
            await conn.groupParticipantsUpdate(
                message.from,
                [targetParticipant.id],
                'promote'
            );
            
            // ✅ LOG DE COMANDO EXITOSO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'op', 
                    `Promovió a @${targetNumber}`, 
                    true
                );
            }
            
            await message.reply('👑 *Usuario promovido a administrador correctamente.*');
            
        } catch (promoteError) {
            console.error('[ERROR] Error al promover:', promoteError);
            
            // ❌ LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'op', 
                    `Intentó promover a @${targetNumber}`, 
                    false
                );
            }
            
            if (promoteError.toString().includes('forbidden') || promoteError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos suficientes para promover a este usuario.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar promover al usuario.');
        }

    } catch (error) {
        console.error('[ERROR] Error en comando op:', error);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

handler.help = ['op @usuario', 'admin @usuario', 'promote @usuario'];
handler.tags = ['admin'];
handler.command = /^(op|admin|promote)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;