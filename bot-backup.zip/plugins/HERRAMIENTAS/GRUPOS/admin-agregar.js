/**
 * Comando: op (CON LOGGING COMPLETO)
 * Descripción: Da administrador a un usuario del grupo
 * Uso: .op @usuario o responder a un mensaje con .op
 * Ubicación: plugins/op.js
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);
        
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        let botParticipant = groupMetadata.participants.find(p => p.id === botJid);
        if (!botParticipant) {
            botParticipant = groupMetadata.participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return possibleBotNumbers.includes(participantNumber);
            });
        }
        
        if (!botParticipant) {
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && p.admin;
            });
        }
        
        if (!botParticipant) {
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'op', '', false);
            }
            return await message.reply('❌ No puedo determinar si soy administrador. Asegurate de que el bot está en este grupo y tiene permisos de administrador.');
        }
        
        const botIsAdmin = botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin';
        
        if (!botIsAdmin) {
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'op', '', false);
            }
            return await message.reply('❌ No puedo promover usuarios porque *no soy administrador* del grupo.');
        }
        
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            // LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(message, 'op', '', false);
            }
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener el usuario objetivo
        let targetJid = null;
        
        if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
        } else if (message.quoted) {
            targetJid = message.quoted.sender;
        } else {
            const text = message.body.split(' ')[1];
            if (text) {
                const cleanNumber = text.replace(/\D/g, '');
                if (cleanNumber) {
                    targetJid = `${cleanNumber}@s.whatsapp.net`;
                }
            }
        }
        
        if (!targetJid) {
            return await message.reply('⚠️ Debes *mencionar* a un usuario con @ o *responder* a su mensaje.\n\n*Ejemplos:*\n`.op @usuario`\n`.op 5491123456789`\nO responder a un mensaje con `.op`');
        }
        
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        
        const targetParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === targetNumber;
        });
        
        if (!targetParticipant) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }
        
        if (botParticipant && targetParticipant.id === botParticipant.id) {
            return await message.reply('❌ No puedo promoverme a mí mismo. 😅');
        }
        
        const targetIsAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin';
        
        if (targetIsAdmin) {
            return await message.reply('⚠️ Este usuario ya es administrador del grupo.');
        }
        
        // Acción de promover
        try {
            await conn.groupParticipantsUpdate(
                message.from,
                [targetParticipant.id],
                'promote'
            );
            
            // ✅ LOG DE COMANDO EXITOSO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'op', 
                    `Promovió a @${targetNumber}`, 
                    true
                );
            }
            
            await message.reply('👑 *Usuario promovido a administrador correctamente.*');
            
        } catch (promoteError) {
            console.error('[ERROR] Error al promover:', promoteError);
            
            // ❌ LOG DE COMANDO FALLIDO
            if (global.commandLogger) {
                await global.commandLogger.logCommand(
                    message, 
                    'op', 
                    `Intentó promover a @${targetNumber}`, 
                    false
                );
            }
            
            const errorCode = promoteError?.data || promoteError?.output?.statusCode;
            const isForbidden = errorCode === 403 || promoteError.toString().toLowerCase().includes('forbidden');
            const isUnauthorized = errorCode === 401;
            const isInternal = promoteError?.output?.statusCode === 500 || promoteError.toString().toLowerCase().includes('internal server error');
            
            if (isForbidden || isUnauthorized) {
                return await message.reply('❌ No tengo permisos suficientes para promover a este usuario. Asegurate de que el bot es administrador del grupo y que no haya restricciones de permisos en el mismo.');
            }
            
            if (isInternal) {
                return await message.reply('❌ Ocurrió un error interno al intentar promover al usuario. Por favor intentá de nuevo más tarde o verificá los permisos del bot.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar promover al usuario. Asegurate de que el bot es administrador del grupo y que el usuario está en el grupo.');
        }

    } catch (error) {
        console.error('[ERROR] Error en comando op:', error);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
    }
};

handler.help = ['op @usuario', 'admin @usuario', 'promote @usuario'];
handler.tags = ['admin'];
handler.command = /^(op|admin|promote)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;