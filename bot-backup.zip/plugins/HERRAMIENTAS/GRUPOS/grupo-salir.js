/**
 * Comando: leave
 * Descripción: El bot sale del grupo actual
 * Uso: .leave o .salir
 * Restricción: Solo administradores del grupo
 */

let handler = async (message, { conn, isAdmin, isBotAdmin }) => {
    try {
        // Verificar que el comando se ejecute en un grupo
        if (!message.key.remoteJid.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede usarse en *grupos*.');
        }

        // Obtener el JID del usuario que ejecutó el comando
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid.split('@')[0];

        // Números autorizados (owner y números específicos)
        const authorizedNumbers = [
            '59893900470',      // Owner principal
            '149078365237384'   // Número alternativo
        ];

        // Verificar si el usuario es autorizado o admin del grupo
        const isAuthorized = authorizedNumbers.some(num => senderNumber.includes(num) || num.includes(senderNumber));
        
        if (!isAuthorized && !isAdmin) {
            return await message.reply('❌ Solo los *administradores del grupo* o el *owner del bot* pueden usar este comando.');
        }

        // Verificar que el bot sea admin del grupo para poder salir correctamente
        if (!isBotAdmin) {
            console.log('\x1b[33m[WARN] El bot no es admin, pero intentará salir igualmente\x1b[0m');
        }

        const groupId = message.key.remoteJid;
        
        console.log('\x1b[33m[INFO] Saliendo del grupo:', groupId, '\x1b[0m');

        try {
            // Obtener información del grupo (opcional)
            let groupMetadata;
            try {
                groupMetadata = await conn.groupMetadata(groupId);
            } catch (metaError) {
                console.log('\x1b[33m[WARN] No se pudo obtener metadata del grupo:', metaError.message, '\x1b[0m');
            }

            // Enviar mensaje de despedida con mención
            const farewellMessage = `
👋 *DESPEDIDA*

Me voy del grupo por petición de @${senderNumber}

¡Hasta pronto! 🌟

*Creador:* RobleUY
*Contacto:* wa.me/59893900470`;

            await message.reply(farewellMessage, { mentions: [senderJid] });

            // Esperar 2 segundos antes de salir (para que se envíe el mensaje)
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Salir del grupo
            await conn.groupLeave(groupId);

            console.log('\x1b[32m[SUCCESS] Bot salió del grupo exitosamente:', groupId, '\x1b[0m');

        } catch (leaveError) {
            console.error('\x1b[31m[ERROR] Error al salir del grupo:', leaveError, '\x1b[0m');
            console.error('\x1b[31m[ERROR] Stack:', leaveError.stack, '\x1b[0m');

            // Manejo de errores específicos
            const errorMessage = leaveError.toString().toLowerCase();

            if (errorMessage.includes('forbidden') || errorMessage.includes('403')) {
                return await message.reply('❌ No tengo *permiso* para salir de este grupo.\n\nEs posible que haya un problema de configuración.');
            }

            if (errorMessage.includes('not found') || errorMessage.includes('404')) {
                return await message.reply('❌ No se encontró el grupo. Es posible que ya no exista.');
            }

            // Error genérico
            return await message.reply('❌ Ocurrió un error al intentar salir del grupo.\n\nIntenta nuevamente más tarde.');
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error general en comando leave:', error, '\x1b[0m');
        console.error('\x1b[31m[ERROR] Stack:', error.stack, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

// --- Configuración del Handler ---
handler.help = ['leave', 'salir'];
handler.tags = ['group'];
handler.command = /^(leave|salir|irse)$/i;
handler.group = true; // Solo puede usarse en grupos

module.exports = handler;