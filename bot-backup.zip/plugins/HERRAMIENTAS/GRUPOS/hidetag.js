// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

// JIDs o números NORMALIZADOS con permiso especial.
const SPECIAL_USERS_PARTS = [
    normalizeNumber('159893900470'),
    '1149078365237384' // JID de LID
];

let handler = async (message, { text }) => {

    // Verificación grupo
    if (!message.isGroup) {
        return await message.reply('❌ Este comando solo puede usarse en un grupo.');
    }

    if (!global.conn) {
        return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
    }

    const senderJid = message.author;

    if (!senderJid) {
        return await message.reply('❌ No se pudo obtener el identificador de remitente.');
    }

    try {
        const groupMetadata = await global.conn.groupMetadata(message.from);
        const senderNumberNormalized = normalizeNumber(senderJid);

        // 1️ Usuario especial
        const isSpecialUser = SPECIAL_USERS_PARTS.includes(senderNumberNormalized);

        // 2 Admin
        const participantInfo = groupMetadata.participants.find(p => {
            const participantNumber = normalizeNumber(p.id);
            return p.id === senderJid || participantNumber === senderNumberNormalized;
        });

        const isAdmin = participantInfo?.admin === 'admin' || participantInfo?.admin === 'superadmin';

        console.log(`[HIDETAGS DEBUG] Usuario: ${senderNumberNormalized} | Admin: ${isAdmin} | Special: ${isSpecialUser}`);

        // 3️ Validar permisos
        if (!isAdmin && !isSpecialUser) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // ————————————————————————————————
        //   📌 TEXTO PERSONALIZADO DEL USUARIO
        // ————————————————————————————————
        const finalText = text?.trim();

        if (!finalText) {
            return await message.reply('❌ Debes escribir un mensaje.\nEjemplo:\n*.hidetag Buenos días gente!*');
        }

        // Obtener todos los participantes
        const participants = groupMetadata.participants.map(p => p.id);

        // Enviar mensaje ocultando @ pero mencionando internamente
        await message.reply(finalText, { mentions: participants });

    } catch (error) {
        console.error('\x1b[31m[ERROR HIDETAGS]:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al mencionar a los participantes del grupo.');
    }
};

handler.help = ['hidetag <mensaje>'];
handler.tags = ['group'];
handler.command = /^(hidetag)$/i;
handler.group = true;

module.exports = handler;
