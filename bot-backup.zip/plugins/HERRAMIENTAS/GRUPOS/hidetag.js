const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

const SPECIAL_USERS_PARTS = [
    normalizeNumber('159893900470'),
    '1149078365237384'
];

let handler = async (message, { text }) => {
    if (!message.isGroup) {
        return await message.reply('❌ Este comando solo puede usarse en un grupo.');
    }

    if (!global.conn && !message._sock && !(global.subConns || []).find(c => c?.user)) {
        return await message.reply('❌ No hay ningún bot conectado disponible.');
    }

    const senderJid = message.author;
    if (!senderJid) {
        return await message.reply('❌ No se pudo obtener el identificador de remitente.');
    }

    try {
        const activeSock    = message._sock || global.conn
            || (global.subConns || []).find(c => c?.user);
        const groupMetadata = await activeSock.groupMetadata(message.from);
        const senderNumberNormalized = normalizeNumber(senderJid);

        const isSpecialUser = SPECIAL_USERS_PARTS.includes(senderNumberNormalized);

        const participantInfo = groupMetadata.participants.find(p => {
            const participantNumber = normalizeNumber(p.id);
            return p.id === senderJid || participantNumber === senderNumberNormalized;
        });

        const isAdmin = participantInfo?.admin === 'admin' || participantInfo?.admin === 'superadmin';

        if (!isAdmin && !isSpecialUser) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        const participants = groupMetadata.participants.map(p => p.id);
        const finalText    = text?.trim() || '';
        const chatJid      = message.from;
        const quotedKey    = message._baileyMessage?.key;

        // ── Detectar si el mensaje viene respondiendo a algún media ──────────
        const baileyMsg  = message._baileyMessage;
        const ctxInfo    = baileyMsg?.message?.extendedTextMessage?.contextInfo
                        || baileyMsg?.message?.audioMessage?.contextInfo
                        || baileyMsg?.message?.imageMessage?.contextInfo
                        || baileyMsg?.message?.videoMessage?.contextInfo
                        || baileyMsg?.message?.stickerMessage?.contextInfo
                        || baileyMsg?.message?.documentMessage?.contextInfo
                        || null;
        const quotedMsg  = ctxInfo?.quotedMessage || null;

        // Detectar tipo de media en el mensaje citado
        const mediaType = quotedMsg
            ? quotedMsg.imageMessage   ? 'image'
            : quotedMsg.videoMessage   ? 'video'
            : quotedMsg.stickerMessage ? 'sticker'
            : quotedMsg.audioMessage   ? 'audio'
            : quotedMsg.documentMessage ? 'document'
            : null
            : null;

        if (mediaType && quotedMsg) {
            // ── Descargar y reenviar el media con las menciones ───────────────
            try {
                let buffer = Buffer.alloc(0);
                const mediaMsg = quotedMsg[`${mediaType}Message`];
                const stream   = await downloadContentFromMessage(mediaMsg, mediaType);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                const mimetype = mediaMsg.mimetype || '';
                const caption  = finalText || mediaMsg.caption || '';

                let content;
                if (mediaType === 'image') {
                    content = { image: buffer, caption, mentions: participants };
                } else if (mediaType === 'video') {
                    content = { video: buffer, caption, mentions: participants };
                } else if (mediaType === 'sticker') {
                    // Stickers no soportan caption ni mentions directamente —
                    // enviamos el sticker y luego el texto si lo hay
                    await activeSock.sendMessage(chatJid, { sticker: buffer }, { quoted: quotedKey });
                    if (finalText) {
                        await activeSock.sendMessage(chatJid,
                            { text: finalText, mentions: participants },
                            { quoted: quotedKey }
                        );
                    }
                    return;
                } else if (mediaType === 'audio') {
                    // Audio tampoco soporta mentions — enviamos audio + texto aparte
                    const isPtt = !!mediaMsg.ptt;
                    await activeSock.sendMessage(chatJid,
                        { audio: buffer, mimetype: mimetype || 'audio/ogg; codecs=opus', ptt: isPtt },
                        { quoted: quotedKey }
                    );
                    if (finalText) {
                        await activeSock.sendMessage(chatJid,
                            { text: finalText, mentions: participants },
                            { quoted: quotedKey }
                        );
                    }
                    return;
                } else if (mediaType === 'document') {
                    content = {
                        document: buffer,
                        mimetype: mimetype || 'application/octet-stream',
                        fileName: mediaMsg.fileName || 'archivo',
                        caption,
                        mentions: participants
                    };
                }

                if (content) {
                    await activeSock.sendMessage(chatJid, content, { quoted: quotedKey });
                }
                return;

            } catch (dlErr) {
                console.error('[HIDETAG] Error descargando media del citado:', dlErr.message);
                // Si falla la descarga, caer al envío de texto normal
            }
        }

        // ── Sin media (o fallo de descarga): enviar texto con mentions ────────
        if (!finalText) {
            return await message.reply('❌ Debes escribir un mensaje.\nEjemplo: *.tag Buenos días gente!*');
        }

        await activeSock.sendMessage(
            chatJid,
            { text: finalText, mentions: participants },
            { quoted: quotedKey }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR HIDETAGS]:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al mencionar a los participantes del grupo.');
    }
};

handler.help    = ['hidetag', 'tag', 'hola'];
handler.tags    = ['admin'];
handler.command = /^(hello|hidetag|tag|hola)$/i;
handler.group   = true;
handler.admin   = true;

module.exports = handler;
