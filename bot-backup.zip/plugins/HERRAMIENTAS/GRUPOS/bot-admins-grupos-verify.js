/**
 * Plugin para listar grupos con menos de 10 participantes y salir de grupos
 * Comandos: .vgrupos, .leaveg <groupId>
 * Solo owner
 */

// Comando principal: Ver grupos pequeños
let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // Obtener todos los chats del bot
        const chats = Object.values(await conn.groupFetchAllParticipating());
        
        // Filtrar solo grupos con menos de 10 participantes
        const gruposPequenos = chats.filter(chat => {
            const participantes = chat.participants ? chat.participants.length : 0;
            return participantes < 10;
        });

        if (gruposPequenos.length === 0) {
            return await message.reply('✅ No hay grupos con menos de 10 participantes.');
        }

        // Ordenar por cantidad de participantes (menor a mayor)
        gruposPequenos.sort((a, b) => {
            const aParticipantes = a.participants ? a.participants.length : 0;
            const bParticipantes = b.participants ? b.participants.length : 0;
            return aParticipantes - bParticipantes;
        });

        // Crear mensaje de respuesta
        let responseMessage = `📊 *GRUPOS CON MENOS DE 10 PARTICIPANTES*\n\n`;
        responseMessage += `Total encontrados: ${gruposPequenos.length}\n`;
        responseMessage += `━━━━━━━━━━━━━━━━━━━━\n\n`;

        for (let i = 0; i < gruposPequenos.length; i++) {
            const grupo = gruposPequenos[i];
            const nombreGrupo = grupo.subject || 'Sin nombre';
            const participantes = grupo.participants ? grupo.participants.length : 0;
            const groupId = grupo.id;

            responseMessage += `${i + 1}. *${nombreGrupo}*\n`;
            responseMessage += `   👥 Participantes: ${participantes}\n`;
            responseMessage += `   🆔 ID: ${groupId}\n\n`;
        }

        responseMessage += `━━━━━━━━━━━━━━━━━━━━\n`;
        responseMessage += `💡 Tip: Usa *.leaveg <ID>* para salir de un grupo.`;

        await message.reply(responseMessage);

    } catch (error) {
        console.error('Error en comando vgrupos:', error);
        await message.reply('❌ Ocurrió un error al obtener la lista de grupos.');
    }
};

handler.help = ['vgrupos'];
handler.tags = ['owner', 'grupos'];
handler.command = /^(vgrupos|vergrupos)$/i;
handler.owner = true;

// Comando secundario: Salir de un grupo
const leaveGroupHandler = async (message, { conn, text, args }) => {
    try {
        if (!text || !args || args.length === 0) {
            return await message.reply('❌ Debes proporcionar el ID del grupo.\n\n💡 Uso: *.leaveg <groupId>*\n\nEjemplo: *.leaveg 123456789@g.us*');
        }

        const groupId = args[0].trim();

        // Validar que el ID tenga formato de grupo
        if (!groupId.endsWith('@g.us')) {
            return await message.reply('❌ El ID proporcionado no es válido. Debe terminar en *@g.us*');
        }

        // Verificar que el grupo existe
        try {
            const groupMetadata = await conn.groupMetadata(groupId);
            const groupName = groupMetadata.subject || 'Sin nombre';

            // Enviar mensaje de despedida al grupo antes de salir
            try {
                await sock.sendMessage(groupId, { 
                    text: '👋 El bot se retirará de este grupo por orden del owner. ¡Hasta pronto!' 
                });
            } catch (e) {
                console.log('No se pudo enviar mensaje de despedida:', e.message);
            }

            // Salir del grupo
            await conn.groupLeave(groupId);

            await message.reply(`✅ Salí exitosamente del grupo:\n\n*${groupName}*\n🆔 ${groupId}`);

        } catch (error) {
            if (error.message.includes('not-participant')) {
                return await message.reply('❌ El bot no es miembro de ese grupo.');
            } else if (error.message.includes('item-not-found')) {
                return await message.reply('❌ No se encontró el grupo con ese ID.');
            } else {
                throw error;
            }
        }

    } catch (error) {
        console.error('Error en comando leaveg:', error);
        await message.reply('❌ Ocurrió un error al intentar salir del grupo.');
    }
};

leaveGroupHandler.help = ['leaveg <groupId>'];
leaveGroupHandler.tags = ['owner', 'grupos'];
leaveGroupHandler.command = /^(leaveg|salirgrupo)$/i;
leaveGroupHandler.owner = true;

module.exports = handler;
module.exports.leaveGroupHandler = leaveGroupHandler;
