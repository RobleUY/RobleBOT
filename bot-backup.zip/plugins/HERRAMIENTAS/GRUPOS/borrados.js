const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones en la raíz del proyecto
const DATA_DIR = path.join(__dirname, '..', 'data');
const BORRADOS_FILE = path.join(DATA_DIR, 'borrados.json');

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(BORRADOS_FILE)) {
    fs.writeFileSync(BORRADOS_FILE, JSON.stringify({}, null, 2), 'utf8');
}

function loadBorradosConfig() {
    try {
        if (fs.existsSync(BORRADOS_FILE)) {
            const data = fs.readFileSync(BORRADOS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando borrados.json:', error.message);
    }
    return {};
}

function saveBorradosConfig(config) {
    try {
        fs.writeFileSync(BORRADOS_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando borrados.json:', error.message);
        return false;
    }
}

function isBorradosEnabled(groupJid) {
    const config = loadBorradosConfig();
    const cleanJid = groupJid.split('@')[0];
    return config[cleanJid] === true;
}

function setBorradosStatus(groupJid, enabled) {
    const config = loadBorradosConfig();
    const cleanJid = groupJid.split('@')[0];

    if (enabled) {
        config[cleanJid] = true;
    } else {
        delete config[cleanJid];
    }

    return saveBorradosConfig(config);
}

let handler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];

        const userJid = message.sender || message.author || message.key?.participant;
        const userNumber = userJid?.split('@')[0].split(':')[0];

        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });

        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los administradores del grupo pueden usar este comando.');
        }

        const body = (message.body || '').trim();
        const args = body.split(/\s+/).slice(1);
        const action = args[0] ? args[0].toLowerCase() : null;

        const currentStatus = isBorradosEnabled(chatId);

        if (!action) {
            const statusText = currentStatus ? '✅ Activado' : '❌ Desactivado';
            return await message.reply(
                `📌 *Borrados*

Estado actual: *${statusText}*

Usa:
• .borrados on  - Activar reenvío de mensajes borrados
• .borrados off - Desactivar reenvío de mensajes borrados`
            );
        }

        if (!['on', 'off', 'activar', 'desactivar'].includes(action)) {
            return await message.reply('⚠️ Usa: .borrados on/off');
        }

        const enabled = ['on', 'activar'].includes(action);
        if (setBorradosStatus(chatId, enabled)) {
            const emoji = enabled ? '✅' : '❌';
            const status = enabled ? 'activado' : 'desactivado';
            return await message.reply(`${emoji} .borrados ${status} en este grupo.`);
        }

        return await message.reply('❌ Error al guardar la configuración de borrados.');
    } catch (error) {
        console.error('Error en comando borrados:', error);
        return await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['borrados on/off'];
handler.tags = ['admin'];
handler.command = /^borrados$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.isBorradosEnabled = isBorradosEnabled;
module.exports.setBorradosStatus = setBorradosStatus;
