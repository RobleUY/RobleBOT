/**
 * Comando: getdesc
 * Descripción: Copia y envía la descripción actual del grupo.
 * Uso: .getdesc
 */

let handler = async (message, { conn }) => {
    try {
        // 1. Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // 2. Obtener metadatos del grupo
        // Nota: groupMetadata contiene la descripción.
        const groupMetadata = await conn.groupMetadata(message.from);

        // 3. Extraer la descripción
        const description = groupMetadata.desc;
        
        // 4. Verificar si hay una descripción
        if (!description) {
            return await message.reply('ℹ️ Este grupo no tiene una descripción establecida.');
        }

        // 5. Enviar la descripción
        // El bot no necesita ser admin para LEER los metadatos del grupo.
        // El usuario no necesita ser admin para EJECUTAR este comando.
        await message.reply(`📄 *Descripción del Grupo:*\n\n${description}`);

    } catch (error) {
        console.error('[ERROR] Error general en comando getdesc:', error.message);
        return await message.reply('❌ Ocurrió un error inesperado al intentar obtener la descripción.');
    }
};

// --- Configuración del Handler ---
handler.help = ['getdesc', 'verdesc'];
handler.tags = ['group']; // No es un comando de 'admin'
handler.command = /^(getdesc|verdesc|gdesc)$/i;
handler.group = true;
// NO se requiere que el usuario sea admin
handler.admin = false; // <--- CÓDIGO CLAVE

module.exports = handler;