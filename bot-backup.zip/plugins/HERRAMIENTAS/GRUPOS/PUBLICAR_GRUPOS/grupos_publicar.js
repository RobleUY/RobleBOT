const fs = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, 'grupos_users.json');
const OFFICIAL_GROUP_ID = '120363203689229697@g.us';

function normalizeJid(jid) {
    if (!jid) return '';
    return String(jid).split('@')[0].split(':')[0];
}

function loadGroups() {
    try {
        if (!fs.existsSync(dataFile)) {
            fs.writeFileSync(dataFile, '[]');
        }
        const raw = fs.readFileSync(dataFile, 'utf8') || '[]';
        const groups = JSON.parse(raw);
        // Asegurar que el grupo oficial siempre esté en la lista
        if (!groups.find(g => g.id === OFFICIAL_GROUP_ID)) {
            groups.unshift({ id: OFFICIAL_GROUP_ID, name: 'Grupo Oficial', participants: 0, invite: '', updatedAt: 0 });
            fs.writeFileSync(dataFile, JSON.stringify(groups, null, 2));
        }
        return groups;
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error cargando grupos:', error);
        return [];
    }
}

function saveGroups(groups) {
    try {
        // El grupo oficial nunca se elimina de la lista
        const hasOfficial = groups.find(g => g.id === OFFICIAL_GROUP_ID);
        if (!hasOfficial) {
            groups.unshift({ id: OFFICIAL_GROUP_ID, name: 'Grupo Oficial', participants: 0, invite: '', updatedAt: 0 });
        }
        fs.writeFileSync(dataFile, JSON.stringify(groups, null, 2));
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error guardando grupos:', error);
    }
}

function isGroupAdmin(participant) {
    return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
}

function findGroupParticipant(participants, jid) {
    const normalizedJid = normalizeJid(jid);
    return participants.find(p => normalizeJid(p.id) === normalizedJid);
}

/**
 * Devuelve todas las conexiones de bot disponibles (principal + subbots), sin duplicados.
 */
function getAllBotConns(conn) {
    const seen = new Set();
    const conns = [];
    for (const c of [conn, global.conn, ...(global.subConns || [])]) {
        if (c?.user?.id && !seen.has(c.user.id)) {
            seen.add(c.user.id);
            conns.push(c);
        }
    }
    return conns;
}

/**
 * Verifica si algún bot está en el grupo usando groupFetchAllParticipating.
 * Esto evita el problema de LIDs (nuevo formato de IDs de WhatsApp en algunos grupos).
 * Retorna { hasAnyBot, hasAdminBot }.
 */
async function checkBotInGroup(groupId, conn) {
    const allConns = getAllBotConns(conn);

    for (const botConn of allConns) {
        try {
            const groups = await botConn.groupFetchAllParticipating();
            if (!groups || !groups[groupId]) continue;

            // Este bot está en el grupo. Verificar si es admin.
            const groupMeta = groups[groupId];
            const metaParticipants = groupMeta.participants || [];
            const botNumNorm = normalizeJid(botConn.user.id);

            // Intento 1: match por número normalizado (grupos normales)
            let botParticipant = metaParticipants.find(p => normalizeJid(p.id) === botNumNorm);

            // Intento 2: grupos con LIDs — el JID del bot no aparece como número sino como @lid
            // En ese caso, intentamos obtener el enlace: solo admins pueden hacerlo
            if (!botParticipant) {
                try {
                    await botConn.groupInviteCode(groupId);
                    // Si no lanzó excepción, el bot tiene permisos de admin
                    return { hasAnyBot: true, hasAdminBot: true };
                } catch (e) {
                    const msg = (e?.message || '').toLowerCase();
                    const notAdmin = msg.includes('forbidden') || msg.includes('not-authorized') ||
                                     msg.includes('admin') || msg.includes('403');
                    // Si el error es de permisos, sabemos que no es admin
                    // Si es otro error (red, etc.), asumir que no es admin por seguridad
                    return { hasAnyBot: true, hasAdminBot: false };
                }
            }

            return { hasAnyBot: true, hasAdminBot: isGroupAdmin(botParticipant) };
        } catch (e) {
            // Conexión fallida, probar la siguiente
        }
    }

    return { hasAnyBot: false, hasAdminBot: false };
}

async function fetchGroupMetadata(groupId, conn) {
    try {
        if (conn && typeof conn.groupMetadata === 'function') {
            return await conn.groupMetadata(groupId);
        }
        if (global.conn && typeof global.conn.groupMetadata === 'function') {
            return await global.conn.groupMetadata(groupId);
        }
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error obteniendo metadata de grupo', groupId, error.message);
    }
    return null;
}

async function fetchInviteLink(groupId, conn) {
    const allConns = getAllBotConns(conn);
    for (const botConn of allConns) {
        try {
            if (typeof botConn.groupInviteCode === 'function') {
                const code = await botConn.groupInviteCode(groupId);
                return `https://chat.whatsapp.com/${code}`;
            }
        } catch (e) {
            // Probar siguiente bot
        }
    }
    return 'No disponible (requiere admin del bot/subbot).';
}

function buildGroupRecord(groupMeta, inviteLink) {
    return {
        id: groupMeta.id || groupMeta.subject || '',
        name: groupMeta.subject || 'Sin nombre',
        participants: (groupMeta.participants || []).length,
        invite: inviteLink,
        updatedAt: Date.now()
    };
}

async function getVisibleGroups(conn) {
    const groups = loadGroups();
    const visibleGroups = [];

    // Procesar grupos en paralelo para mayor velocidad
    const promises = groups.map(async (record) => {
        if (!record?.id) return null;

        const isOfficial = record.id === OFFICIAL_GROUP_ID;

        try {
            // Para el grupo oficial, siempre intentar mostrarlo
            if (isOfficial) {
                const groupMeta = await fetchGroupMetadata(record.id, conn);
                if (groupMeta) {
                    const inviteLink = await fetchInviteLink(record.id, conn);
                    return buildGroupRecord(groupMeta, inviteLink);
                } else {
                    // Si no se puede obtener metadata, usar datos guardados
                    return record;
                }
            }

            // Para otros grupos, verificar si podemos obtener el enlace (bot es admin)
            const groupMeta = await fetchGroupMetadata(record.id, conn);
            if (!groupMeta) {
                // Si no podemos obtener metadata, no mostrar el grupo
                return null;
            }

            const inviteLink = await fetchInviteLink(record.id, conn);
            // Si el enlace es "No disponible", significa que el bot no es admin
            if (inviteLink === 'No disponible (requiere admin del bot/subbot).') {
                return null;
            }

            return buildGroupRecord(groupMeta, inviteLink);
        } catch (error) {
            // Si hay error, no mostrar el grupo
            return null;
        }
    });

    const results = await Promise.all(promises);
    return results.filter(group => group !== null);
}

async function ensureGroupPublished(groupId, senderId, conn) {
    const groupMeta = await fetchGroupMetadata(groupId, conn);
    if (!groupMeta) return { ok: false, reason: 'No se pudo obtener los datos del grupo.' };

    const participants = groupMeta.participants || [];

    // Verificar que el sender es admin del grupo
    const senderParticipant = findGroupParticipant(participants, senderId);
    const senderIsAdmin = senderParticipant && isGroupAdmin(senderParticipant);
    if (!senderIsAdmin) {
        return { ok: false, reason: 'Solo los administradores del grupo pueden publicar o despublicar el grupo.' };
    }

    // Verificar presencia y admin del bot usando groupFetchAllParticipating (compatible con LIDs)
    const { hasAnyBot, hasAdminBot } = await checkBotInGroup(groupId, conn);

    if (!hasAnyBot) {
        return { ok: false, reason: 'El grupo debe tener al menos un bot o subbot dentro del grupo.' };
    }
    if (!hasAdminBot) {
        return { ok: false, reason: 'Al menos un bot o subbot debe ser administrador del grupo para publicarlo.' };
    }

    const inviteLink = await fetchInviteLink(groupId, conn);
    return { ok: true, groupMeta, inviteLink };
}

let handler = async (message, { conn: rawConn, command, isGroup, text }) => {
    // Asegura que conn siempre tenga .user para identificar el bot correctamente
    const conn = (rawConn?.user?.id ? rawConn : null) || global.conn;
    try {
        const fallbackText = (text || message.text || '').trim();
        const commandName = (command || (fallbackText.split(/\s+/)[0] || '')).toString().replace(/^\./, '').toLowerCase();
        const senderId = message.author || message.from;

        if (commandName === 'grupos') {
            await message.reply('🔄 Obteniendo lista de grupos publicados...');
            const visibleGroups = await getVisibleGroups(conn);

            if (visibleGroups.length === 0) {
                return await message.reply(
                    '❌ No hay grupos publicados disponibles en este momento.\n\n' +
                    '💡 *¿Querés publicar tu grupo?*\n' +
                    'Entrá al grupo y usá *.gpublico* (necesitás ser admin del grupo y el bot también).'
                );
            }

            // Grupo oficial siempre primero, luego el resto por participantes (mayor a menor)
            const official = visibleGroups.find(g => g.id === OFFICIAL_GROUP_ID);
            const rest = visibleGroups.filter(g => g.id !== OFFICIAL_GROUP_ID).sort((a, b) => b.participants - a.participants);
            const sorted = official ? [official, ...rest] : rest;

            const lines = sorted.map((g, index) => {
                const pin = g.id === OFFICIAL_GROUP_ID ? '📌 ' : '';
                return `${index + 1}. ${pin}*${g.name}*\n   👥 Miembros: ${g.participants}\n   🔗 Enlace: ${g.invite}`;
            });

            return await message.reply(
                `📚 *Grupos publicados (${sorted.length})*\n\n` +
                `${lines.join('\n\n')}\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `💡 *¿Querés publicar tu grupo?*\n` +
                `Entrá al grupo y usá *.gpublico* (necesitás ser admin y el bot también debe serlo).`
            );
        }

        if (commandName === 'gpublico' || commandName === 'gpublic') {
            if (!isGroup) {
                return await message.reply('❌ Este comando solo funciona dentro de un grupo.');
            }

            // Verificar que el sender es admin
            const groupMeta = await fetchGroupMetadata(message.from, conn);
            if (groupMeta) {
                const senderParticipant = findGroupParticipant(groupMeta.participants || [], senderId);
                if (!senderParticipant || !isGroupAdmin(senderParticipant)) {
                    return await message.reply('❌ Solo los administradores del grupo pueden publicarlo.');
                }
            }

            const existingGroups = loadGroups();
            if (existingGroups.find(g => g.id === message.from)) {
                return await message.reply('ℹ️ Este grupo ya está publicado en la lista.\n\nPara eliminarlo de la lista usa: *.gprivado*\nPara ver la lista de grupos usa: *.grupos*');
            }

            await message.reply('🔄 Publicando grupo...');
            const validation = await ensureGroupPublished(message.from, senderId, conn);
            if (!validation.ok) {
                return await message.reply(`❌ No se pudo publicar el grupo: ${validation.reason}`);
            }

            const record = buildGroupRecord(validation.groupMeta, validation.inviteLink);
            const groups = loadGroups().filter(g => g.id !== record.id);
            groups.push(record);
            saveGroups(groups);

            return await message.reply(
                `✅ *Grupo publicado correctamente*\n\n` +
                `*${record.name}*\n` +
                `👥 Miembros: ${record.participants}\n` +
                `🔗 Enlace: ${record.invite}\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `💡 Para eliminarlo de la lista, usá *.gprivado* desde este grupo (solo admins).`
            );
        }

        if (commandName === 'gprivado' || commandName === 'gprivate') {
            if (!isGroup) {
                return await message.reply('❌ Este comando solo funciona dentro de un grupo.');
            }

            const groups = loadGroups();
            const existing = groups.find(g => g.id === message.from);
            if (!existing) {
                return await message.reply('❌ Este grupo no está publicado.');
            }

            const groupMeta = await fetchGroupMetadata(message.from, conn);
            if (!groupMeta) {
                return await message.reply('❌ No se pudo verificar el grupo antes de eliminarlo.');
            }

            const participants = groupMeta.participants || [];
            const senderParticipant = findGroupParticipant(participants, senderId);
            const senderIsAdmin = senderParticipant && isGroupAdmin(senderParticipant);
            if (!senderIsAdmin) {
                return await message.reply('❌ Solo los administradores del grupo pueden despublicarlo.');
            }

            const filtered = groups.filter(g => g.id !== message.from);
            saveGroups(filtered);

            return await message.reply(
                '✅ Grupo eliminado de la lista de grupos publicados.\n\n' +
                '━━━━━━━━━━━━━━━━━━━━\n' +
                '💡 Si querés volver a publicarlo, usá *.gpublico* desde este grupo (solo admins).'
            );
        }

        return await message.reply('❌ Comando no reconocido. Usa .gpublico, .gpublic, .gprivado, .gprivate o .grupos.');
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error en comando:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando de publicación de grupos.');
    }
};

handler.help = ['gpublico', 'gpublic', 'gprivado', 'gprivate', 'grupos'];
handler.tags = ['group'];
handler.command = /^(gpublico|gpublic|gprivado|gprivate|grupos)$/i;
handler.group = false;
handler.admin = false;

module.exports = handler;