/**
 * Comando: pgrupo
 * Descripción: Permite a los admins de un grupo publicar su grupo en el listado
 * Uso: .pgrupo
 */

const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON (en la misma carpeta del script)
const GRUPOS_FILE = path.join(__dirname, 'grupos_users.json');

// Cargar grupos desde el JSON
function cargarGrupos() {
    try {
        if (!fs.existsSync(GRUPOS_FILE)) {
            fs.writeFileSync(GRUPOS_FILE, JSON.stringify([], null, 2));
            return [];
        }
        const data = fs.readFileSync(GRUPOS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('[ERROR] Error al cargar grupos:', error);
        return [];
    }
}

// Guardar grupos en el JSON
function guardarGrupos(grupos) {
    try {
        fs.writeFileSync(GRUPOS_FILE, JSON.stringify(grupos, null, 2));
        return true;
    } catch (error) {
        console.error('[ERROR] Error al guardar grupos:', error);
        return false;
    }
}

// Handler para pgrupo
let handlerPgrupo = async (message, { conn }) => {
    try {
        // Verificar que se use en un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse dentro de un grupo.');
        }

        // Obtener metadatos del grupo actual
        const groupMetadata = await conn.groupMetadata(message.from);
        const participants = groupMetadata.participants || [];

        // Verificar si el usuario es admin
        const senderJid = message.sender;
        const senderParticipant = participants.find(p => p.id === senderJid);
        const isAdmin = senderParticipant && (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

        if (!isAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden publicar el enlace.');
        }

        // Verificar si el bot es admin
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });

        if (!botParticipant) {
            botParticipant = participants.find(p => p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin'));
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!botIsAdmin) {
            return await message.reply('❌ El bot debe ser *administrador* del grupo para poder publicarlo.\n\n_Promociona al bot a administrador e intenta nuevamente._');
        }

        // Obtener el enlace de invitación
        let inviteLink;
        try {
            const code = await conn.groupInviteCode(message.from);
            inviteLink = `https://chat.whatsapp.com/${code}`;
        } catch (error) {
            console.error('[ERROR] No se pudo obtener el enlace:', error);
            return await message.reply('❌ No se pudo generar el enlace de invitación. Verifica que el bot sea administrador.');
        }

        // Cargar grupos existentes
        let grupos = cargarGrupos();

        // Verificar si el grupo ya está registrado
        const grupoExistente = grupos.find(g => g.groupId === message.from);

        if (grupoExistente) {
            // Solo actualizar el enlace
            grupoExistente.enlace = inviteLink;
            await message.reply(
                '✅ *Grupo actualizado exitosamente*\n\n' +
                `📌 *Nombre:* ${groupMetadata.subject}\n` +
                `👥 *Participantes:* ${participants.length}\n` +
                `🔗 *Enlace:* ${inviteLink}\n\n` +
                '_El grupo ya estaba publicado. Se actualizó el enlace._'
            );
        } else {
            // Agregar nuevo grupo (solo guardamos groupId y enlace)
            grupos.push({
                groupId: message.from,
                enlace: inviteLink
            });
            await message.reply(
                '✅ *Grupo publicado exitosamente*\n\n' +
                `📌 *Nombre:* ${groupMetadata.subject}\n` +
                `👥 *Participantes:* ${participants.length}\n` +
                `🔗 *Enlace:* ${inviteLink}\n\n` +
                '_El grupo ahora aparecerá en el listado de grupos disponibles._\n\n' +
                '_Usa /grupos para ver todos los grupos publicados._'
            );
        }

        // Guardar en el JSON
        if (!guardarGrupos(grupos)) {
            await message.reply('⚠️ El grupo fue publicado pero hubo un error al guardar en el archivo.');
        }

    } catch (error) {
        console.error('[ERROR] Error en comando pgrupo:', error);
        await message.reply('❌ Ocurrió un error al intentar publicar el grupo.');
    }
};

handlerPgrupo.help = ['pgrupo'];
handlerPgrupo.tags = ['group'];
handlerPgrupo.command = /^(pgrupo|publicargrupo)$/i;
handlerPgrupo.group = true;

// Handler para grupos
let handlerGrupos = async (message, { conn }) => {
    try {
        await message.reply('🔍 *Verificando grupos disponibles...*\n\n_Esto puede tomar unos momentos._');

        // Cargar grupos
        let grupos = cargarGrupos();

        if (grupos.length === 0) {
            return await message.reply('📭 No hay grupos publicados en este momento.\n\n_Los administradores pueden publicar sus grupos usando:_\n/pgrupo');
        }

        // Verificar cada grupo y obtener información actualizada
        const gruposValidos = [];
        const gruposInvalidos = [];

        for (const grupo of grupos) {
            try {
                // Extraer código del enlace
                const match = grupo.enlace.match(/chat\.whatsapp\.com\/([a-zA-Z0-9_-]+)/);
                if (!match) {
                    gruposInvalidos.push(grupo.groupId);
                    continue;
                }

                const code = match[1];

                // Verificar si el enlace funciona
                let groupInfo;
                try {
                    groupInfo = await conn.groupGetInviteInfo(code);
                    if (!groupInfo || !groupInfo.id) {
                        gruposInvalidos.push(grupo.groupId);
                        continue;
                    }
                } catch (error) {
                    console.log(`[INFO] Enlace inválido para grupo: ${grupo.groupId}`);
                    gruposInvalidos.push(grupo.groupId);
                    continue;
                }

                // Verificar que el bot esté en el grupo y obtener info actualizada
                const botNumbers = ['59892099606', '106502773850321'];
                let botEnGrupo = false;
                let nombreActual = groupInfo.subject || 'Sin nombre';
                let participantesActual = groupInfo.size || 0;

                try {
                    const groupMetadata = await conn.groupMetadata(grupo.groupId);
                    const participants = groupMetadata.participants || [];
                    
                    // Verificar si el bot está en el grupo
                    botEnGrupo = participants.some(p => {
                        const participantNumber = p.id.split('@')[0].split(':')[0];
                        return botNumbers.some(botNum => participantNumber.includes(botNum));
                    });

                    // Si el bot está en el grupo, usar la info más actualizada
                    if (botEnGrupo) {
                        nombreActual = groupMetadata.subject || nombreActual;
                        participantesActual = participants.length;
                    }
                } catch (error) {
                    console.log(`[INFO] No se pudo acceder a metadata del grupo: ${grupo.groupId}`);
                    // Si no se puede acceder a la metadata pero el enlace funciona,
                    // usamos la info del enlace
                    botEnGrupo = false;
                }

                // Si el bot no está en el grupo, lo removemos
                if (!botEnGrupo) {
                    gruposInvalidos.push(grupo.groupId);
                    continue;
                }

                // Agregar grupo válido con información actualizada
                gruposValidos.push({
                    groupId: grupo.groupId,
                    nombre: nombreActual,
                    participantes: participantesActual,
                    enlace: grupo.enlace
                });

            } catch (error) {
                console.error(`[ERROR] Error al verificar grupo ${grupo.groupId}:`, error);
                gruposInvalidos.push(grupo.groupId);
            }
        }

        // Eliminar grupos inválidos del JSON
        if (gruposInvalidos.length > 0) {
            const gruposActualizados = grupos.filter(g => !gruposInvalidos.includes(g.groupId));
            guardarGrupos(gruposActualizados);
            console.log(`[INFO] Se eliminaron ${gruposInvalidos.length} grupos inválidos del listado.`);
        }

        // Verificar si quedaron grupos válidos
        if (gruposValidos.length === 0) {
            return await message.reply('📭 No hay grupos disponibles en este momento.\n\n_Los grupos pueden haber sido eliminados o el bot fue removido de ellos._');
        }

        // Ordenar por cantidad de participantes (mayor a menor)
        gruposValidos.sort((a, b) => b.participantes - a.participantes);

        // Construir mensaje
        let mensaje = '📋 *L I S T A  D E  G R U P O S*\n\n';
        mensaje += `_Se encontraron ${gruposValidos.length} grupos activos_\n`;
        mensaje += '━━━━━━━━━━━━━━━\n\n';

        gruposValidos.forEach((grupo, index) => {
            mensaje += `*${index + 1}. ${grupo.nombre}*\n`;
            mensaje += `👥 Participantes: ${grupo.participantes}\n`;
            mensaje += `🔗 ${grupo.enlace}\n\n`;
        });

        mensaje += '━━━━━━━━━━━━━━━\n';
        mensaje += '_Para publicar tu grupo usa:_ /pgrupo';

        await message.reply(mensaje);

    } catch (error) {
        console.error('[ERROR] Error en comando grupos:', error);
        await message.reply('❌ Ocurrió un error al obtener la lista de grupos.');
    }
};

handlerGrupos.help = ['grupos'];
handlerGrupos.tags = ['group'];
handlerGrupos.command = /^(grupos)$/i;

// Exportar ambos handlers
module.exports = { handlerPgrupo, handlerGrupos };