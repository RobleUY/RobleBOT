const fs = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, 'grupos_users.json');

function normalizeJid(jid) {
    if (!jid) return '';
    return String(jid).split('@')[0].split(':')[0];
}

function loadGroups() {
    try {
        if (!fs.existsSync(dataFile)) {
            fs.writeFileSync(dataFile, '[]');
        }
        const raw = fs.readFileSync(dataFile, 'utf8') || '[]';
        return JSON.parse(raw);
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error cargando grupos:', error);
        return [];
    }
}

function saveGroups(groups) {
    try {
        fs.writeFileSync(dataFile, JSON.stringify(groups, null, 2));
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error guardando grupos:', error);
    }
}

function buildBotIds() {
    const ids = new Set();

    if (global.conn?.user?.id) {
        ids.add(global.conn.user.id);
    }

    if (Array.isArray(global.subConns)) {
        for (const sub of global.subConns) {
            if (sub?.user?.id) {
                ids.add(sub.user.id);
            }
        }
    }

    return Array.from(ids).map(id => normalizeJid(id));
}

function isGroupAdmin(participant) {
    return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
}

function findGroupParticipant(participants, jid) {
    const normalizedJid = normalizeJid(jid);
    return participants.find(p => normalizeJid(p.id) === normalizedJid);
}

function groupHasAnyBot(participants, botIds) {
    return participants.some(p => botIds.includes(normalizeJid(p.id)));
}

function groupHasAdminBot(participants, botIds) {
    return participants.some(p => botIds.includes(normalizeJid(p.id)) && isGroupAdmin(p));
}

async function fetchGroupMetadata(groupId, conn) {
    try {
        if (conn && typeof conn.groupMetadata === 'function') {
            return await conn.groupMetadata(groupId);
        }
        if (global.conn && typeof global.conn.groupMetadata === 'function') {
            return await global.conn.groupMetadata(groupId);
        }
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error obteniendo metadata de grupo', groupId, error.message);
    }
    return null;
}

async function fetchInviteLink(groupId, conn) {
    try {
        if (conn && typeof conn.groupInviteCode === 'function') {
            const code = await conn.groupInviteCode(groupId);
            return `https://chat.whatsapp.com/${code}`;
        }
        if (global.conn && typeof global.conn.groupInviteCode === 'function') {
            const code = await global.conn.groupInviteCode(groupId);
            return `https://chat.whatsapp.com/${code}`;
        }
    } catch (error) {
        return 'No disponible (requiere admin del bot/subbot).';
    }
    return 'No disponible.';
}

function buildGroupRecord(groupMeta, inviteLink) {
    return {
        id: groupMeta.id || groupMeta.subject || '',
        name: groupMeta.subject || 'Sin nombre',
        participants: (groupMeta.participants || []).length,
        invite: inviteLink,
        updatedAt: Date.now()
    };
}

async function verifyPublishedGroups(conn) {
    const botIds = buildBotIds();
    const groups = loadGroups();
    const updatedGroups = [];
    const removedGroups = [];

    for (const record of groups) {
        if (!record?.id) continue;
        const groupMeta = await fetchGroupMetadata(record.id, conn);
        if (!groupMeta) {
            removedGroups.push(record);
            continue;
        }

        const participants = groupMeta.participants || [];
        const hasAnyBot = groupHasAnyBot(participants, botIds);
        const hasAdminBot = groupHasAdminBot(participants, botIds);

        if (!hasAnyBot || !hasAdminBot) {
            removedGroups.push(record);
            continue;
        }

        const inviteLink = await fetchInviteLink(record.id, conn);
        updatedGroups.push(buildGroupRecord(groupMeta, inviteLink));
    }

    saveGroups(updatedGroups);
    return { updatedGroups, removedGroups };
}

async function ensureGroupPublished(groupId, senderId, conn) {
    const groupMeta = await fetchGroupMetadata(groupId, conn);
    if (!groupMeta) return { ok: false, reason: 'No se pudo obtener los datos del grupo.' };

    const participants = groupMeta.participants || [];
    const botIds = buildBotIds();

    const senderParticipant = findGroupParticipant(participants, senderId);
    const senderIsAdmin = senderParticipant && isGroupAdmin(senderParticipant);
    if (!senderIsAdmin) {
        return { ok: false, reason: 'Solo los administradores del grupo pueden publicar o despublicar el grupo.' };
    }

    const hasAnyBot = groupHasAnyBot(participants, botIds);
    const hasAdminBot = groupHasAdminBot(participants, botIds);
    if (!hasAnyBot) {
        return { ok: false, reason: 'El grupo debe tener al menos un bot o subbot dentro del grupo.' };
    }
    if (!hasAdminBot) {
        return { ok: false, reason: 'Al menos un bot o subbot debe ser administrador del grupo para publicarlo.' };
    }

    const inviteLink = await fetchInviteLink(groupId, conn);
    return { ok: true, groupMeta, inviteLink, botIds };
}

let handler = async (message, { conn, command, isGroup, text }) => {
    try {
        const fallbackText = (text || message.text || '').trim();
        const commandName = (command || (fallbackText.split(/\s+/)[0] || '')).toString().replace(/^\./, '').toLowerCase();
        const senderId = message.author || message.from;

        if (commandName === 'grupos') {
            const { updatedGroups, removedGroups } = await verifyPublishedGroups(conn);

            if (removedGroups.length > 0) {
                const removedNames = removedGroups.map(g => g.name || g.id).join('\n');
                await message.reply(`⚠️ Se eliminaron ${removedGroups.length} grupo(s) porque ya no tienen un bot/subbot admin o no se pudo obtener su metadata:\n${removedNames}`);
            }

            if (updatedGroups.length === 0) {
                return await message.reply('❌ No hay grupos publicados en este momento. Usa .gpublico en el grupo para publicarlo.');
            }

            const lines = updatedGroups.map((g, index) => {
                return `${index + 1}. ${g.name}\n   📌 ID: ${g.id}\n   👥 Miembros: ${g.participants}\n   🔗 Enlace: ${g.invite}`;
            });

            return await message.reply(
                `📚 *Grupos publicados (${updatedGroups.length})*\n\n${lines.join('\n\n')}`
            );
        }

        if (!isGroup) {
            return await message.reply('❌ Este comando solo funciona dentro de un grupo. Usa .grupos para ver los grupos publicados.');
        }

        if (commandName === 'gpublico' || commandName === 'gpublic') {
            const validation = await ensureGroupPublished(message.from, senderId, conn);
            if (!validation.ok) {
                return await message.reply(`❌ No se pudo publicar el grupo: ${validation.reason}`);
            }

            const record = buildGroupRecord(validation.groupMeta, validation.inviteLink);
            const groups = loadGroups().filter(g => g.id !== record.id);
            groups.push(record);
            saveGroups(groups);

            return await message.reply(
                `✅ Grupo publicado correctamente:\n` +
                `*${record.name}*\n` +
                `👥 Miembros: ${record.participants}\n` +
                `🔗 Enlace: ${record.invite}`
            );
        }

        if (commandName === 'gprivado' || commandName === 'gprivate') {
            const groups = loadGroups();
            const existing = groups.find(g => g.id === message.from);
            if (!existing) {
                return await message.reply('❌ Este grupo no está publicado.');
            }

            const groupMeta = await fetchGroupMetadata(message.from, conn);
            if (!groupMeta) {
                return await message.reply('❌ No se pudo verificar el grupo antes de eliminarlo.');
            }

            const participants = groupMeta.participants || [];
            const senderParticipant = findGroupParticipant(participants, senderId);
            const senderIsAdmin = senderParticipant && isGroupAdmin(senderParticipant);
            if (!senderIsAdmin) {
                return await message.reply('❌ Solo los administradores del grupo pueden despublicarlo.');
            }

            const filtered = groups.filter(g => g.id !== message.from);
            saveGroups(filtered);

            return await message.reply('✅ Grupo eliminado de la lista de grupos publicados.');
        }

        return await message.reply('❌ Comando no reconocido. Usa .gpublico, .gpublic, .gprivado, .gprivate o .grupos.');
    } catch (error) {
        console.error('[PUBLICAR_GRUPOS] Error en comando:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando de publicación de grupos.');
    }
};

handler.help = ['gpublico', 'gpublic', 'gprivado', 'gprivate', 'grupos'];
handler.tags = ['group'];
handler.command = /^(gpublico|gpublic|gprivado|gprivate|grupos)$/i;
handler.group = false;
handler.admin = false;

module.exports = handler;
