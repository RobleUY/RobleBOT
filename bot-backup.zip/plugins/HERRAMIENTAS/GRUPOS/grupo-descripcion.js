/**
 * Comando: desc / descripcion
 * Descripción: Cambia la descripción del grupo.
 * Uso: .desc <texto>
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- Obtener el nuevo texto de la descripción ---
        // Obtiene el texto después del comando (.desc o .descripcion)
        const text = message.body.split(' ').slice(1).join(' ').trim();

        if (!text) {
            return await message.reply('⚠️ Debes escribir la *nueva descripción* del grupo.\n\n*Ejemplo:*\n`.desc ¡Bienvenido a nuestro grupo oficial!`');
        }

        // Limitar la longitud de la descripción si es necesario (WhatsApp tiene un límite)
        const newDescription = text.substring(0, 1024); // El límite es alto, pero es bueno ser cauteloso.

        // --- Verificaciones de permisos ---

        // 1. Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);

        // 2. Verificar si el bot es administrador (similar a los otros handlers)
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            // Fallback: buscar por el formato de ID de los participantes admin
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!botIsAdmin) {
            return await message.reply('❌ No puedo cambiar la descripción porque *no soy administrador* del grupo.');
        }

        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];

        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });

        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Acción de cambiar la descripción ---

        try {
            // Se asume que 'conn.groupUpdateDescription' es la función correcta
            await conn.groupUpdateDescription(message.from, newDescription);

            // MODIFICACIÓN CLAVE AQUÍ: Solo se envía el mensaje de confirmación
            await message.reply('✅ *Descripción del grupo actualizada correctamente.*');

        } catch (updateError) {
            console.error('[ERROR] Error al cambiar la descripción:', updateError.message);

            if (updateError.toString().includes('forbidden') || updateError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos para editar la descripción del grupo.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar cambiar la descripción del grupo.');
        }

    } catch (error) {
        console.error('[ERROR] Error general en comando desc:', error.message);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

// --- Configuración del Handler ---
handler.help = ['desc <texto>', 'descripcion <texto>'];
handler.tags = ['admin'];
handler.command = /^(desc|descripcion)$/i; // Permite .desc o .descripcion
handler.group = true;
handler.admin = true;

module.exports = handler;