const handler = async (message, { conn, text }) => {
    try {
        // ============================
        // CONFIGURACIÓN DEL COMANDO
        // ============================
        const COMANDO_ACTIVADO = true; // Cambiar a false para desactivar el comando
        
        // Verificar si el comando está activado
        if (!COMANDO_ACTIVADO) {
            return await message.reply(
                `🚫 *Comando desactivado*\n\n` +
                `Lo siento, el comando *.join* está temporalmente desactivado.\n` +
                `Por favor, intenta más tarde.`
            );
        }

        const AUTHORIZED_GROUP = "120363203689229697@g.us";
        const AUTH_LINK = "https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv";

        const currentChat = message.chat || message.key.remoteJid;

        if (!message.isGroup) {
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        if (currentChat !== AUTHORIZED_GROUP) {
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        if (!text) {
            return await message.reply(
                "⚠️ Debes proporcionar un *link de invitación* del grupo.\n\n" +
                "Ejemplo:\n.join https://chat.whatsapp.com/ABC123xyz"
            );
        }

        let inviteCode = null;

        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        const codeMatch = text.match(/^([0-9A-Za-z]{20,24})$/);
        if (!inviteCode && codeMatch) inviteCode = codeMatch[1];

        if (!inviteCode) {
            return await message.reply("⚠️ Link de invitación *no válido*.");
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid ? senderJid.split('@')[0] : "Desconocido";

        await message.reply("⏳ Verificando grupo e intentando unirme...");

        let groupInfo;
        let groupJid;
        
        try {
            groupInfo = await conn.groupGetInviteInfo(inviteCode);
            groupJid = groupInfo.id;
            
            const participantCount = groupInfo.size || 0;

            const MIN_PARTICIPANTS = 10;

            if (participantCount < MIN_PARTICIPANTS) {
                return await message.reply(
                    `❌ *No puedo unirme al grupo.* 😔\n\n` +
                    `El grupo *"${groupInfo.subject}"* solo tiene *${participantCount}* participantes.\n` +
                    `Necesito un mínimo de *${MIN_PARTICIPANTS}* miembros para poder unirme.`
                );
            }
        } catch (infoError) {
            const errorMessage = infoError.toString().toLowerCase();

            if (errorMessage.includes('invalid') || errorMessage.includes('not found')) {
                return await message.reply('❌ El link de invitación *no es válido* o ha *expirado*.');
            }

            return await message.reply('❌ Ocurrió un error al verificar el link del grupo.');
        }

        // ============================
        // VERIFICAR SI EL USUARIO ES ADMIN DEL GRUPO
        // ============================
        if (!groupJid) {
            return await message.reply("❌ No pude identificar el grupo del enlace.");
        }

        let isUserAdmin = false;
        try {
            const metadata = await conn.groupMetadata(groupJid);
            const participants = metadata.participants || [];

            // Buscar al usuario en los participantes del grupo
            const user = participants.find(p => {
                // Comparar JIDs directamente
                if (p.id === senderJid) return true;
                
                // Comparar números (sin @s.whatsapp.net)
                const participantNumber = p.id.split('@')[0].split(':')[0];
                const senderNum = senderJid.split('@')[0].split(':')[0];
                if (participantNumber === senderNum) return true;
                
                // Comparación parcial
                if (p.id.includes(senderNum) || senderJid.includes(participantNumber)) return true;
                
                return false;
            });

            if (!user) {
                return await message.reply(
                    `⚠️ *No estás en el grupo*\n\n` +
                    `No eres miembro del grupo *"${metadata.subject}"*.\n` +
                    `Por lo tanto, no puedes ser admin ahí y no puedo unirme.`
                );
            }

            // Verificar si es admin
            isUserAdmin = user.admin === "admin" || user.admin === "superadmin";

            if (!isUserAdmin) {
                return await message.reply(
                    `❌ *No eres administrador del grupo*\n\n` +
                    `Solo los administradores del grupo *"${metadata.subject}"* pueden unir el bot.\n\n` +
                    `💡 Contacta a un administrador del grupo si necesitas unir el bot.`
                );
            }
        } catch (adminError) {
            console.error("[ERROR] Verificando admin del grupo:", adminError);
            return await message.reply('❌ No tengo permiso para ver los detalles de ese grupo o el grupo no existe.');
        }

        // --- Unirse al grupo ---
        let joinResult;
        try {
            joinResult = await conn.groupAcceptInvite(inviteCode);

            console.log("[SUCCESS] Join result:", joinResult);

            // Normalizar JID
            const groupJid =
                typeof joinResult === "string"
                    ? joinResult
                    : joinResult?.gid ||
                      joinResult?.id ||
                      joinResult?.groupId ||
                      null;

            if (!groupJid) {
                throw new Error("No se pudo obtener el JID del grupo luego de unirse.");
            }

            await message.reply("✅ *¡Me uní al grupo exitosamente!* 🎉");

            const welcomeMessage = `
┃ 〔 🌟 *ROBLEBOT* 🌟 〕
┃ ━━━━━━━━━━━━━
┃ ¡Hola! Fui invitado por @${senderNumber}
┃ 
┃ 📋 *Para comenzar:*
┃ Escribe */menu* para ver
┃ todos los comandos disponibles.
┃ 
┃ 👑 *Creador:* RobleUY
┃ 📱 *Contacto:*
┃    • Instagram: @robleuy
┃    • WhatsApp: +59893900470
┃━━━━━━━━━━━━━`;

            await conn.sendMessage(groupJid, {
                text: welcomeMessage,
                mentions: [senderJid]
            });

        } catch (joinError) {
            const errorMessage = joinError.toString().toLowerCase();

            if (errorMessage.includes('forbidden') || errorMessage.includes('403')) {
                return await message.reply('❌ No tengo *permiso* para unirme a este grupo.');
            }

            if (errorMessage.includes('already') || errorMessage.includes('participant') || errorMessage.includes('conflict')) {
                return await message.reply('⚠️ Ya soy *miembro* de este grupo.');
            }

            if (errorMessage.includes('limit') || errorMessage.includes('many')) {
                return await message.reply('❌ El grupo ha alcanzado el *límite máximo* de participantes.');
            }

            return await message.reply('❌ Ocurrió un error al intentar unirme al grupo.');
        }

    } catch (err) {
        console.error("[ERROR] General en join:", err);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

handler.help = ['join [link]'];
handler.tags = ['owner'];
handler.command = /^(join)$/i;

module.exports = handler;