

const handler = async (message, { conn, text }) => {
    try {
        // 🔹 ID del grupo oficial autorizado
        const AUTHORIZED_GROUP = "120363203689229697@g.us"; // <-- tu grupo oficial
        // 🔹 Link público del grupo oficial
        const AUTH_LINK = "https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv"; // <-- grupo oficial ROBLEBOT

        const currentChat = message.chat || message.key.remoteJid;
        console.log(`[DEBUG] Grupo actual: ${currentChat}`);
        console.log(`[DEBUG] isGroup: ${message.isGroup}`);

        // --- 1️⃣ Verificar si el comando se usa en un grupo ---
        if (!message.isGroup) {
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        // --- 2️⃣ Verificar si es el grupo autorizado ---
        if (currentChat !== AUTHORIZED_GROUP) {
            console.log("[ACCESS DENIED] Comando usado fuera del grupo oficial.");
            return await message.reply(
                `🚫 *No puedes usar este comando desde este lugar.*\n\n` +
                `Solo desde el grupo oficial tienes permiso para usar *.join*.\n\n` +
                `👉 Únete aquí:\n${AUTH_LINK}`
            );
        }

        // --- 3️⃣ Validar el link de invitación ---
        if (!text) {
            return await message.reply(
                "⚠️ Debes proporcionar un *link de invitación* del grupo.\n\n" +
                "Ejemplo:\n.join https://chat.whatsapp.com/ABC123xyz"
            );
        }

        let inviteCode = null;

        // Método 1: Link completo
        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        // Método 2: Solo el código
        if (!inviteCode) {
            const codeMatch = text.match(/^([0-9A-Za-z]{20,24})$/);
            if (codeMatch) inviteCode = codeMatch[1];
        }

        if (!inviteCode) {
            return await message.reply("⚠️ Link de invitación *no válido*.");
        }

        // --- 4️⃣ Extraer datos del remitente ---
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid ? senderJid.split('@')[0] : "Desconocido";

        console.log(`[INFO] Intentando unirse al grupo con código: ${inviteCode}`);
        await message.reply("⏳ Intentando unirme al grupo...");

        // --- 5️⃣ Intentar unirse al grupo ---
        try {
            const joinResult = await conn.groupAcceptInvite(inviteCode);
            console.log(`[SUCCESS] Bot unido al grupo: ${joinResult}`);

            await message.reply("✅ *¡Me uní al grupo exitosamente!* 🎉");

            // --- 6️⃣ Enviar mensaje de bienvenida ---
            const welcomeMessage = `
┃ 〔 🌟 *ROBLEBOT* 🌟 〕
┃ ━━━━━━━━━━━━━
┃ ¡Hola! Fui invitado por @${senderNumber}
┃ 
┃ 📋 *Para comenzar:*
┃ Escribe */menu* para ver
┃ todos los comandos disponibles.
┃ 
┃ 👑 *Creador:* RobleUY
┃ 📱 *Contacto:*
┃    • Instagram: @robleuy
┃    • WhatsApp: +59893900470
┃━━━━━━━━━━━━━`;

            await conn.sendMessage(joinResult, {
                text: welcomeMessage,
                mentions: senderJid ? [senderJid] : []
            });

        } catch (joinError) {
            console.error("[ERROR] Al unirse al grupo:", joinError);
            const errorMessage = joinError.toString().toLowerCase();

            if (errorMessage.includes('invalid') || errorMessage.includes('not found')) {
                return await message.reply('❌ El link de invitación *no es válido* o ha *expirado*.');
            }

            if (errorMessage.includes('forbidden') || errorMessage.includes('403')) {
                return await message.reply('❌ No tengo *permiso* para unirme a este grupo.');
            }

            if (errorMessage.includes('already') || errorMessage.includes('participant') || errorMessage.includes('conflict')) {
                return await message.reply('⚠️ Ya soy *miembro* de este grupo.');
            }

            if (errorMessage.includes('limit') || errorMessage.includes('many')) {
                return await message.reply('❌ El grupo ha alcanzado el *límite máximo* de participantes.');
            }

            return await message.reply('❌ Ocurrió un error al intentar unirme al grupo.\nVerifica el link o intenta más tarde.');
        }

    } catch (err) {
        console.error("[ERROR] General en joinzz:", err);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

// --- Configuración del Handler ---
handler.help = ['join [link]'];
handler.tags = ['owner'];
handler.command = /^(join)$/i;

module.exports = handler;
