const handler = async (message, { conn, text }) => {
    try {
        const AUTHORIZED_GROUP = "120363203689229697@g.us";
        const AUTH_LINK = "https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv";

        const currentChat = message.chat || message.key.remoteJid;

        // El comando solo funciona en el grupo oficial
        if (!message.isGroup || currentChat !== AUTHORIZED_GROUP) {
            return await message.reply(
                `🚫 *No puedes usar este comando aquí.*\n\n` +
                `Solo desde el *grupo oficial* puedes usar *.join*.\n\n👉 ${AUTH_LINK}`
            );
        }

        if (!text) {
            return await message.reply(
                "⚠️ Debes enviar un *link de invitación*.\n\nEjemplo:\n.join https://chat.whatsapp.com/ABC123"
            );
        }

        // Extraer código de invitación
        let inviteCode = null;
        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        if (!inviteCode)
            return await message.reply("❌ Link de invitación *no válido*.");

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid.split("@")[0];

        await message.reply("⏳ Verificando grupo...");

        // ============================================
        // OBTENER INFO DEL GRUPO SIN SER MIEMBRO
        // ============================================
        let groupInfo;
        try {
            groupInfo = await conn.groupGetInviteInfo(inviteCode);
        } catch (e) {
            return await message.reply("❌ El link está *expirado* o es *inválido*.");
        }

        const groupJid = groupInfo.id;

        // ============================================
        // VERIFICAR SI EL USUARIO ES ADMIN
        // (Se usa groupGetInviteInfo → NO necesita que el BOT esté dentro)
        // ============================================
        const participants = groupInfo.participants || [];
        const participant = participants.find(p => p.id === senderJid);

        if (!participant) {
            return await message.reply(
                `⚠️ No estás en el grupo *${groupInfo.subject}*.\n\n` +
                `Por lo tanto no puedes invitar al bot.`
            );
        }

        if (!participant.admin) {
            return await message.reply(
                `❌ *No eres administrador del grupo*\n\n` +
                `Solo *administradores* de *${groupInfo.subject}* pueden unir el bot.`
            );
        }

        // ============================================
        // INTENTAR UNIR AL BOT
        // ============================================
        try {
            const joinResult = await conn.groupAcceptInvite(inviteCode);

            await message.reply("✅ *¡Me uní al grupo exitosamente!* 🎉");

            const welcomeMessage = `
🌟 *ROBLEBOT* 🌟
━━━━━━━━━━━━━━━
¡Hola! Fui invitado por @${senderNumber}

Escribe */menu* para ver comandos.
            `;

            await conn.sendMessage(joinResult, {
                text: welcomeMessage,
                mentions: [senderJid]
            });

        } catch (err) {
            const txt = err.toString().toLowerCase();

            // Bot fue expulsado previamente
            if (txt.includes("403") || txt.includes("forbidden")) {
                return await message.reply(
                    `❌ *No puedo unirme al grupo.*\n\n` +
                    `Parece que fui *eliminado* previamente del grupo *${groupInfo.subject}*.\n\n` +
                    `Solo un *administrador actual del grupo* puede volver a agregarme.`
                );
            }

            if (txt.includes("participant") || txt.includes("already")) {
                return await message.reply("⚠️ Ya estoy en ese grupo.");
            }

            if (txt.includes("limit")) {
                return await message.reply("❌ El grupo alcanzó el límite de participantes.");
            }

            return await message.reply("❌ Ocurrió un error al intentar unirme.");
        }

    } catch (e) {
        console.error("[JOIN ERROR FATAL]", e);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

handler.help = ['join [link]'];
handler.tags = ['owner'];
handler.command = /^(join)$/i;

module.exports = handler;
