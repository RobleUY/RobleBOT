const handler = async (message, { conn, text }) => {
    // ============================================
    // 🔴 ACTIVAR/DESACTIVAR COMANDO
    // ============================================
    const COMMAND_ENABLED = true;

    if (!COMMAND_ENABLED) {
        return await message.reply(
            `🔴 *Comando Desactivado*\n\n` +
            `El comando *.join* está temporalmente desactivado.`
        );
    }
    // ============================================

    try {
        const AUTHORIZED_GROUP = "120363203689229697@g.us";
        const AUTH_LINK = "https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv";

        const currentChat = message.chat || message.key.remoteJid;

        if (!message.isGroup || currentChat !== AUTHORIZED_GROUP) {
            return await message.reply(
                `🚫 *No puedes usar este comando aquí.*\n\n` +
                `Solo desde el *grupo oficial* puedes usar *.join*.\n\n👉 ${AUTH_LINK}`
            );
        }

        if (!text) {
            return await message.reply(
                "⚠️ Debes enviar un *link de invitación*.\n\nEjemplo:\n.join https://chat.whatsapp.com/ABC123"
            );
        }

        let inviteCode = null;
        const linkMatch = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
        if (linkMatch) inviteCode = linkMatch[1];

        if (!inviteCode)
            return await message.reply("❌ Link de invitación *no válido*.");

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid.split("@")[0];

        await message.reply("⏳ Uniéndome al grupo...");

        // ============================================
        // INTENTAR UNIR AL BOT DIRECTO
        // ============================================
        try {
            const joinResult = await conn.groupAcceptInvite(inviteCode);

            await message.reply("✅ *¡Me uní al grupo exitosamente!* 🎉");

            const welcomeMessage =
                `🌟 *ROBLEBOT* 🌟\n` +
                `━━━━━━━━━━━━━━━\n` +
                `¡Hola! Fui invitado por @${senderNumber}\n\n` +
                `Escribe */menu* para ver comandos.`;

            await conn.sendMessage(joinResult, {
                text: welcomeMessage,
                mentions: [senderJid]
            });

        } catch (err) {
            const txt = err.toString().toLowerCase();

            if (txt.includes("403") || txt.includes("forbidden")) {
                return await message.reply(
                    `❌ *No puedo unirme al grupo.*\n\n` +
                    `Parece que fui *eliminado* previamente de ese grupo.\n\n` +
                    `Solo un *administrador actual* puede volver a agregarme manualmente.`
                );
            }

            if (txt.includes("participant") || txt.includes("already")) {
                return await message.reply("⚠️ Ya estoy en ese grupo.");
            }

            if (txt.includes("limit")) {
                return await message.reply("❌ El grupo alcanzó el límite de participantes.");
            }

            if (txt.includes("expire") || txt.includes("invalid")) {
                return await message.reply("❌ El link está *expirado* o es *inválido*.");
            }

            return await message.reply("❌ Ocurrió un error al intentar unirme.");
        }

    } catch (e) {
        console.error("[JOIN ERROR FATAL]", e);
        await message.reply("❌ Ocurrió un error interno al ejecutar el comando.");
    }
};

handler.help = ['join [link]'];
handler.tags = ['owner'];
handler.command = /^(join)$/i;

module.exports = handler;