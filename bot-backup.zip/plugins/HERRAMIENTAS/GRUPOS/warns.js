﻿/**
 * Sistema de advertencias (.warn / .unwarn / .warneados)
 * - Warns por grupo (no globales)
 * - Al 3er warn: expulsa automáticamente o avisa a admins si el bot no puede
 * - Solo admins pueden usar los comandos
 * - El bot debe ser admin para expulsar
 */

const fs = require('fs');
const path = require('path');

const WARNS_FILE = path.join(__dirname, '..', '..', '..', 'data', 'warns.json');

// ─── Helpers de datos ─────────────────────────────────────────────────────────

function getWarnsData() {
    try {
        if (fs.existsSync(WARNS_FILE)) {
            return JSON.parse(fs.readFileSync(WARNS_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('❌ Error leyendo warns.json:', e.message);
    }
    return {};
}

function saveWarnsData(data) {
    try {
        const dir = path.dirname(WARNS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(WARNS_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('❌ Error guardando warns.json:', e.message);
    }
}

function normalizeNumber(id) {
    if (!id) return '';
    return id.split('@')[0].split(':')[0].replace(/\D/g, '');
}

// ─── Helpers de grupo ─────────────────────────────────────────────────────────

async function getGroupInfo(conn, groupId, senderId) {
    const meta = await conn.groupMetadata(groupId);

    const botJid = conn.user.id;
    const possibleBotNums = [
        botJid.split(':')[0].split('@')[0],
        botJid.split('@')[0].split(':')[0]
    ];

    // Buscar bot: primero por phoneNumber, luego por id (igual que expulsar-usuarios.js)
    let botP = null;
    for (const p of meta.participants) {
        if (p.phoneNumber) {
            const n = p.phoneNumber.split('@')[0].split(':')[0];
            if (possibleBotNums.includes(n)) { botP = p; break; }
        }
    }
    if (!botP) {
        for (const p of meta.participants) {
            const n = p.id.split('@')[0].split(':')[0];
            if (possibleBotNums.includes(n)) { botP = p; break; }
        }
    }

    const senderNum = senderId.split('@')[0].split(':')[0];
    const senderP   = meta.participants.find(p => p.id.split('@')[0].split(':')[0] === senderNum);

    const botIsAdmin    = botP    && (botP.admin    === 'admin' || botP.admin    === 'superadmin');
    const senderIsAdmin = senderP && (senderP.admin === 'admin' || senderP.admin === 'superadmin');

    const admins = meta.participants
        .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
        .map(p => p.id);

    const find = (num) => meta.participants.find(p => p.id.split('@')[0].split(':')[0] === num);

    return { meta, botP, botIsAdmin, senderIsAdmin, admins, find };
}

function getTargetJid(message) {
    if (message.mentions?.length > 0) return message.mentions[0];
    if (message.quoted?.sender)       return message.quoted.sender;
    return null;
}

// ─── COMANDO .warn ────────────────────────────────────────────────────────────

let warnHandler = async (message, { args, conn, usedPrefix }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        // Permisos
        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden usar este comando.');
        }

        // Obtener usuario objetivo
        const targetJid = getTargetJid(message);
        if (!targetJid) {
            return await message.reply(
                `⚠️ Debes mencionar a un usuario o responder a su mensaje.\n\n` +
                `*Uso:* ${usedPrefix}warn @usuario <razón opcional>`
            );
        }

        const targetNum = normalizeNumber(targetJid);
        const targetP   = groupInfo.find(targetNum);

        if (!targetP) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }

        // No warnear al bot ni a otros admins
        if (normalizeNumber(conn.user.id) === targetNum) {
            return await message.reply('❌ No me puedo advertir a mí mismo. 😅');
        }
        if (targetP.admin === 'admin' || targetP.admin === 'superadmin') {
            return await message.reply('❌ No puedes advertir a un administrador.');
        }

        // Razón (todo lo que viene después de la mención)
        const reason = args.slice(1).join(' ').trim() || 'Sin especificar';

        // Guardar warn
        const data = getWarnsData();
        if (!data[groupId])             data[groupId] = {};
        if (!data[groupId][targetNum])  data[groupId][targetNum] = [];

        data[groupId][targetNum].push({
            reason,
            date: new Date().toISOString(),
            by: normalizeNumber(senderId)
        });

        const warnCount = data[groupId][targetNum].length;
        saveWarnsData(data);

        const mention = `@${targetNum}`;

        // ── 3 warns → expulsar ──────────────────────────────────────────────────
        if (warnCount >= 3) {
            if (groupInfo.botIsAdmin) {
                try {
                    await conn.groupParticipantsUpdate(groupId, [targetP.id], 'remove');

                    // Limpiar warns del usuario expulsado
                    delete data[groupId][targetNum];
                    saveWarnsData(data);

                    return await conn.sendMessage(groupId, {
                        text: `⚠️ ${mention} fue *expulsado* del grupo por acumular *3 advertencias*.\n\n📋 Última razón: ${reason}`,
                        mentions: [targetP.id]
                    }, { quoted: message._baileyMessage });
                } catch (kickErr) {
                    console.error('❌ Error al expulsar:', kickErr.message);
                    // Si falla la expulsión, avisar a admins
                }
            }

            // Bot no es admin o falló la expulsión → avisar a admins
            const adminMentions = groupInfo.admins;
            const adminTags = adminMentions.map(a => `@${normalizeNumber(a)}`).join(' ');

            return await conn.sendMessage(groupId, {
                text:
                    `🚨 *ALERTA: 3 advertencias acumuladas*\n\n` +
                    `👤 Usuario: ${mention}\n` +
                    `📋 Última razón: ${reason}\n\n` +
                    `⚠️ El bot ${groupInfo.botIsAdmin ? 'no pudo expulsar al usuario' : 'no es administrador y no puede expulsarlo'}.\n\n` +
                    `🔔 Admins, por favor tomen acción:\n${adminTags}`,
                mentions: [targetP.id, ...adminMentions]
            }, { quoted: message._baileyMessage });
        }

        // ── 1 o 2 warns → notificar ──────────────────────────────────────────────
        const warnEmoji = warnCount === 1 ? '1️⃣' : '2️⃣';
        const warnsLeft = 3 - warnCount;

        return await conn.sendMessage(groupId, {
            text:
                `⚠️ *Advertencia ${warnEmoji} para* ${mention}\n\n` +
                `📋 *Razón:* ${reason}\n` +
                `📊 *Advertencias:* ${warnCount}/3\n` +
                `💡 Le ${warnsLeft === 1 ? 'queda *1 advertencia*' : 'quedan *2 advertencias*'} antes de ser expulsado.`,
            mentions: [targetP.id]
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('❌ Error en .warn:', error);
        return await message.reply('❌ Ocurrió un error al aplicar la advertencia.');
    }
};

warnHandler.command  = /^warn$/i;
warnHandler.help     = ['warn @usuario <razón>'];
warnHandler.tags     = ['admin'];
warnHandler.group    = true;

// ─── COMANDO .unwarn ──────────────────────────────────────────────────────────

let unwarnHandler = async (message, { args, conn, usedPrefix }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden usar este comando.');
        }

        const targetJid = getTargetJid(message);
        if (!targetJid) {
            return await message.reply(
                `⚠️ Debes mencionar a un usuario o responder a su mensaje.\n\n` +
                `*Uso:* ${usedPrefix}unwarn @usuario <número de warn: 1 o 2>`
            );
        }

        const targetNum = normalizeNumber(targetJid);
        const data      = getWarnsData();

        if (!data[groupId]?.[targetNum]?.length) {
            return await message.reply(`ℹ️ @${targetNum} no tiene advertencias en este grupo.`);
        }

        const warns     = data[groupId][targetNum];
        const warnCount = warns.length;

        // Si se especifica número de warn (1 o 2), eliminar esa específica
        const warnIndex = parseInt(args[1]);
        if (!isNaN(warnIndex) && warnIndex >= 1 && warnIndex <= warnCount) {
            const removed = warns.splice(warnIndex - 1, 1)[0];
            if (warns.length === 0) delete data[groupId][targetNum];
            saveWarnsData(data);

            return await conn.sendMessage(groupId, {
                text:
                    `✅ Advertencia #${warnIndex} eliminada para @${targetNum}\n\n` +
                    `📋 *Razón eliminada:* ${removed.reason}\n` +
                    `📊 *Advertencias restantes:* ${data[groupId]?.[targetNum]?.length || 0}/3`,
                mentions: [targetJid]
            }, { quoted: message._baileyMessage });
        }

        // Sin número → eliminar la última
        const removed = warns.pop();
        if (warns.length === 0) delete data[groupId][targetNum];
        saveWarnsData(data);

        return await conn.sendMessage(groupId, {
            text:
                `✅ Última advertencia eliminada para @${targetNum}\n\n` +
                `📋 *Razón eliminada:* ${removed.reason}\n` +
                `📊 *Advertencias restantes:* ${data[groupId]?.[targetNum]?.length || 0}/3`,
            mentions: [targetJid]
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('❌ Error en .unwarn:', error);
        return await message.reply('❌ Ocurrió un error al eliminar la advertencia.');
    }
};

unwarnHandler.command = /^unwarn$/i;
unwarnHandler.help    = ['unwarn @usuario <número opcional>'];
unwarnHandler.tags    = ['admin'];
unwarnHandler.group   = true;

// ─── COMANDO .warneados ───────────────────────────────────────────────────────

let warneadosHandler = async (message, { conn }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden ver las advertencias.');
        }

        const data       = getWarnsData();
        const groupWarns = data[groupId] || {};
        const entries    = Object.entries(groupWarns).filter(([, w]) => w.length > 0);

        if (entries.length === 0) {
            return await message.reply('✅ No hay usuarios con advertencias en este grupo.');
        }

        const mentions = [];
        let text = `*⚠️ USUARIOS CON ADVERTENCIAS (${entries.length})*\n\n`;

        for (const [num, warns] of entries) {
            // Buscar el JID real del participante en el grupo para la mención correcta
            const participantP = groupInfo.find(num);
            const jid = participantP ? participantP.id : `${num}@s.whatsapp.net`;
            const displayNum = jid.split('@')[0]; // puede incluir :15 si aplica
            mentions.push(jid);
            text += `👤 @${displayNum} — *${warns.length}/3 warns*\n`;
            warns.forEach((w, i) => {
                const date = new Date(w.date).toLocaleDateString('es-ES');
                text += `   ${i + 1}. ${w.reason} _(${date})_\n`;
            });
            text += '\n';
        }

        return await conn.sendMessage(groupId, { text, mentions }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('❌ Error en .warneados:', error);
        return await message.reply('❌ Ocurrió un error al obtener las advertencias.');
    }
};

warneadosHandler.command = /^warneados$/i;
warneadosHandler.help    = ['warneados'];
warneadosHandler.tags    = ['admin'];
warneadosHandler.group   = true;

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports              = warnHandler;
module.exports.unwarnHandler    = unwarnHandler;
module.exports.warneadosHandler = warneadosHandler;