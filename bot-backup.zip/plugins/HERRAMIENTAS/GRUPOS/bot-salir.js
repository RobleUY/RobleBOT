/**
 * Comando: salirbot / botsalir
 * Descripción: El bot sale del grupo actual
 * Uso: .salirbot o .botsalir
 * Restricción: Solo owners, admins del bot, o admins del grupo
 */

const handler = async (message, { conn }) => {
    try {
        // Verificar que el comando se ejecute en un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en *grupos*.');
        }

        const groupId = message.from || message.key?.remoteJid;
        
        // Obtener el JID del usuario que ejecutó el comando
        const senderJid = message?.key?.participant || message?.sender || message?.key?.remoteJid;
        const senderNumber = senderJid ? senderJid.split('@')[0].split(':')[0].replace(/\D/g, '') : null;
        
        // Verificar si el usuario es owner del bot
        const isBotOwner = global.botConfig?.isOwner(senderNumber) || 
                          (senderJid && (await global.botConfig?.isOwnerJid(senderJid, groupId).catch(() => false)));
        
        // Verificar si el usuario es admin del bot
        const isBotAdmin = global.botConfig?.isAdmin(senderNumber) || 
                          (senderJid && (await global.botConfig?.isAdminJid(senderJid, groupId).catch(() => false)));
        
        // Verificar si el usuario es admin del grupo
        let isGroupAdmin = false;
        try {
            const groupMetadata = await conn.groupMetadata(groupId);
            const participants = groupMetadata.participants || [];
            
            const userParticipant = participants.find(p => {
                const participantJid = p.id;
                return participantJid === senderJid || 
                       participantJid.includes(senderNumber) ||
                       senderJid.includes(participantJid.split('@')[0]);
            });
            
            isGroupAdmin = userParticipant && 
                          (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        } catch (error) {
            console.error('[bot-salir] Error verificando admin del grupo:', error.message);
        }
        
        // Verificar permisos: debe ser owner, admin del bot, o admin del grupo
        if (!isBotOwner && !isBotAdmin && !isGroupAdmin) {
            return await message.reply(
                '❌ No tienes permisos para usar este comando.\n\n' +
                'Este comando solo puede ser usado por:\n' +
                '• Owners del bot\n' +
                '• Administradores del bot\n' +
                '• Administradores del grupo'
            );
        }

        console.log(`[bot-salir] Saliendo del grupo: ${groupId} por usuario: ${senderNumber}`);

        try {
            // Obtener información del grupo (opcional)
            let groupMetadata;
            try {
                groupMetadata = await conn.groupMetadata(groupId);
            } catch (metaError) {
                console.log(`[bot-salir] No se pudo obtener metadata del grupo: ${metaError.message}`);
            }

            const groupName = groupMetadata?.subject || 'este grupo';

            // Enviar mensaje de despedida con mención
            const farewellMessage = `
👋 *DESPEDIDA*

Me voy del grupo *${groupName}* por petición de @${senderNumber || 'un administrador'}

¡Hasta pronto! 🌟

*Creador:* RobleUY
*Contacto:* wa.me/59893900470`;

            await message.reply(farewellMessage, { 
                mentions: senderJid ? [senderJid] : []
            });

            // Esperar 2 segundos antes de salir (para que se envíe el mensaje)
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Salir del grupo
            await conn.groupLeave(groupId);

            console.log(`[bot-salir] ✅ Bot salió del grupo exitosamente: ${groupId}`);

        } catch (leaveError) {
            console.error(`[bot-salir] ❌ Error al salir del grupo:`, leaveError);
            console.error(`[bot-salir] Stack:`, leaveError.stack);

            // Manejo de errores específicos
            const errorMessage = leaveError.toString().toLowerCase();

            if (errorMessage.includes('forbidden') || errorMessage.includes('403')) {
                return await message.reply('❌ No tengo *permiso* para salir de este grupo.\n\nEs posible que haya un problema de configuración.');
            }

            if (errorMessage.includes('not found') || errorMessage.includes('404')) {
                return await message.reply('❌ No se encontró el grupo. Es posible que ya no exista.');
            }

            // Error genérico
            return await message.reply('❌ Ocurrió un error al intentar salir del grupo.\n\nIntenta nuevamente más tarde.');
        }

    } catch (error) {
        console.error(`[bot-salir] ❌ Error general:`, error);
        console.error(`[bot-salir] Stack:`, error.stack);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

// --- Configuración del Handler ---
handler.help = ['salirbot', 'botsalir'];
handler.tags = ['group'];
handler.command = /^(salirbot|botsalir)$/i;
handler.group = true; // Solo puede usarse en grupos

module.exports = handler;
