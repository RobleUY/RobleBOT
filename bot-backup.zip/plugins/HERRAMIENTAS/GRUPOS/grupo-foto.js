/**
 * Comando: fotog / fotogrupo
 * Descripción: Cambia la foto de perfil del grupo.
 * Uso: .fotog (respondiendo a una imagen)
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

async function detectQuotedImage() {
  try {
    console.log('🔍 Buscando imagen citada...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      console.log('❌ No hay mensaje de @whiskeysockets/baileys guardado');
      return null;
    }

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.imageMessage?.contextInfo) {
      contextInfo = baileyMsg.message.imageMessage.contextInfo;
    } else if (baileyMsg.message?.videoMessage?.contextInfo) {
      contextInfo = baileyMsg.message.videoMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) {
      console.log('❌ No hay mensaje citado');
      return null;
    }

    const quotedMessage = contextInfo.quotedMessage;

    // imageMessage
    if (quotedMessage.imageMessage) {
      console.log('🖼️ Imagen citada detectada, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
        const buffer = await streamToBuffer(stream);
        return buffer;
      } catch (err) {
        console.error('❌ Error descargando imagen citada:', err);
        return null;
      }
    }

    console.log('❌ El mensaje citado no es una imagen');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectQuotedImage:', error);
    return null;
  }
}

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- Verificaciones de permisos ---

        // 1. Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);

        // 2. Verificar si el bot es administrador
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            // Fallback: buscar por el formato de ID de los participantes admin
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!botIsAdmin) {
            return await message.reply('❌ No puedo cambiar la foto porque *no soy administrador* del grupo.');
        }

        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];

        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });

        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Detectar y descargar imagen citada ---
        console.log('📁 Buscando imagen citada...');
        const imageBuffer = await detectQuotedImage();

        if (!imageBuffer) {
            return await message.reply(
                '⚠️ Debes *responder a una imagen* para cambiar la foto del grupo.\n\n' +
                '*Ejemplo:*\n' +
                '1. Responde a una imagen con `.fotog`\n' +
                '2. El bot cambiará la foto del grupo'
            );
        }

        console.log('✅ Imagen detectada, cambiando foto del grupo...');

        // --- Cambiar la foto del grupo ---

        try {
            // Cambiar la foto del grupo usando el buffer
            await conn.updateProfilePicture(message.from, imageBuffer);

            await message.reply('✅ *Foto del grupo actualizada correctamente.*');

        } catch (updateError) {
            console.error('[ERROR] Error al cambiar la foto del grupo:', updateError.message);

            if (updateError.toString().includes('forbidden') || updateError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos para editar la foto del grupo.');
            }
            
            if (updateError.toString().includes('invalid')) {
                return await message.reply('❌ La imagen no es válida. Asegúrate de que sea un formato correcto (JPG/PNG).');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar cambiar la foto del grupo.');
        }

    } catch (error) {
        console.error('[ERROR] Error general en comando fotog:', error);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

// --- Configuración del Handler ---
handler.help = ['fotog', 'fotogrupo'];
handler.tags = ['admin'];
handler.command = /^(fotog|fotogrupo)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;