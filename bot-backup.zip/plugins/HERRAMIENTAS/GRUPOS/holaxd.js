// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

// JIDs o números NORMALIZADOS con permiso especial.
const SPECIAL_USERS_PARTS = [
    normalizeNumber('159893900470'),
    '1149078365237384' // JID de LID
];

let handler = async (message, { text }) => {
    // Verificaciones iniciales
    if (!message.isGroup) {
        await global.conn.sendMessage(message.chat, { text: '❌ Este comando solo puede usarse en un grupo.' });
        return;
    }
    
    if (!global.conn) {
        await global.conn.sendMessage(message.chat, { text: '❌ El bot no está conectado correctamente. Inténtalo de nuevo.' });
        return;
    }

    // Obtener el JID del remitente
    const senderJid = message.author;
    
    if (!senderJid) {
        await global.conn.sendMessage(message.chat, { text: '❌ No se pudo obtener el identificador de remitente. Inténtalo de nuevo.' });
        return;
    }
    
    try {
        // Obtener metadatos del grupo
        const groupMetadata = await global.conn.groupMetadata(message.from);
        
        // Normalizar el número del remitente
        const senderNumberNormalized = normalizeNumber(senderJid);
        
        // 🔍 VERIFICACIÓN DE PERMISOS
        
        // 1. Verificar si es usuario especial
        const isSpecialUser = SPECIAL_USERS_PARTS.includes(senderNumberNormalized);
        
        // 2. Verificar si es admin del grupo
        const participantInfo = groupMetadata.participants.find(p => {
            const participantNumber = normalizeNumber(p.id);
            return p.id === senderJid || participantNumber === senderNumberNormalized;
        });
        
        const isAdmin = participantInfo?.admin === 'admin' || participantInfo?.admin === 'superadmin';
        
        console.log(`[HOLAXD DEBUG] Usuario: ${senderNumberNormalized} | Admin: ${isAdmin} | Special: ${isSpecialUser}`);
        
        // 3. Verificar permisos
        if (!isAdmin && !isSpecialUser) {
            await global.conn.sendMessage(message.chat, { text: '❌ Solo los *administradores* del grupo pueden usar este comando.' });
            return;
        }
        
        // ✅ Si llegó aquí, tiene permisos. Ejecutar comando.

        const conn = global.conn;

        // Obtener todos los participantes del grupo (solo los válidos)
        const participants = groupMetadata.participants
            .map(p => p.id)
            .filter(id => typeof id === 'string' && id.endsWith('@s.whatsapp.net'));

        // Mensaje visible (sin @)
        const messageText = '_Te eliminó_';

        // Enviar mensaje SIN reply ni quote
        await conn.sendMessage(message.from, {
            text: messageText,
            mentions: participants
        });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al usar el comando eliminado:', error, '\x1b[0m');
        await global.conn.sendMessage(message.chat, { text: '❌ Ocurrió un error al mencionar a los participantes del grupo.' });
    }
};

handler.help = ['eliminado'];
handler.tags = ['group'];
handler.command = /^(eliminado)$/i;
handler.group = true;

module.exports = handler;
