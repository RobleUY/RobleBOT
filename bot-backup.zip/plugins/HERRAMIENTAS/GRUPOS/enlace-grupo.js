/**
 * Comando: enlace
 * Descripción: Obtiene el link de invitación del grupo actual
 * Uso: .enlace o .link
 * Restricción: El bot debe ser admin del grupo
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar que el comando se ejecute en un grupo
        const groupId = message.key.remoteJid;
        
        if (!groupId.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede usarse en *grupos*.');
        }

        // Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(groupId);

        // --- Verificación de permisos del Bot ---
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        // Buscar el bot en los participantes
        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            // Fallback
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }
        
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        if (!botIsAdmin) {
            return await message.reply('❌ Necesito ser *administrador del grupo* para obtener el enlace de invitación.\n\nPídele a un admin que me otorgue permisos de administrador.');
        }

        // Obtener información del usuario que ejecuta el comando
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        
        console.log('\x1b[33m[INFO] Obteniendo enlace de invitación del grupo:', groupId, '\x1b[0m');

        try {
            // Obtener metadata del grupo (nombre)
            const groupName = groupMetadata.subject || 'este grupo';

            // Obtener el código de invitación del grupo
            const inviteCode = await conn.groupInviteCode(groupId);
            
            if (!inviteCode) {
                return await message.reply('❌ No se pudo obtener el enlace de invitación del grupo.\nVerifica que el bot sea administrador del grupo.\n\nIntenta nuevamente más tarde.');
            }

            // Construir el link completo
            const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;

            console.log('\x1b[32m[SUCCESS] Enlace obtenido exitosamente:', inviteLink, '\x1b[0m');

            // Enviar el enlace con formato
            const linkMessage = `
🔗 *ENLACE DE INVITACIÓN*

📋 *Grupo:* ${groupName}

🌐 *Link:*
${inviteLink}

Solicitado por @${senderNumber}`;

            await message.reply(linkMessage, { mentions: [senderJid] });

        } catch (linkError) {
            console.error('\x1b[31m[ERROR] Error al obtener enlace:', linkError, '\x1b[0m');
            console.error('\x1b[31m[ERROR] Stack:', linkError.stack, '\x1b[0m');

            // Manejo de errores específicos
            const errorMessage = linkError.toString().toLowerCase();

            if (errorMessage.includes('forbidden') || errorMessage.includes('403')) {
                return await message.reply('❌ No tengo *permiso* para obtener el enlace de invitación.\n\nAsegúrate de que soy administrador del grupo.');
            }

            if (errorMessage.includes('not found') || errorMessage.includes('404')) {
                return await message.reply('❌ No se encontró el grupo. Es posible que ya no exista.');
            }

            if (errorMessage.includes('not admin') || errorMessage.includes('admin')) {
                return await message.reply('❌ Necesito ser *administrador del grupo* para obtener el enlace de invitación.');
            }

            // Error genérico
            return await message.reply('❌ Ocurrió un error al obtener el enlace de invitación.\nVerifica que el bot sea administrador del grupo.\n\nIntenta nuevamente más tarde.');
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error general en comando enlace:', error, '\x1b[0m');
        console.error('\x1b[31m[ERROR] Stack:', error.stack, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.');
    }
};

// --- Configuración del Handler ---
handler.help = ['enlace', 'link', 'invitacion'];
handler.tags = ['group'];
handler.command = /^(enlace|link|invitacion|invite)$/i;
handler.group = true; // Solo puede usarse en grupos

module.exports = handler;