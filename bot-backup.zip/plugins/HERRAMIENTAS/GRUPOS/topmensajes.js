/**
 * Plugin: topmensajes / topactivos / toppiolas
 * Ranking de mensajes por grupo, paginado de 10 en 10.
 * Solo usuarios que siguen en el grupo y tienen al menos 1 mensaje.
 * Formato idéntico a topcoins.
 */

function cleanNum(str) {
    return str.split('@')[0].split(':')[0].replace(/\D/g, '');
}

function formatAgo(ms) {
    if (!ms || ms <= 0) return 'nunca';
    const diff = Date.now() - ms;
    const d = Math.floor(diff / 86_400_000);
    const h = Math.floor((diff % 86_400_000) / 3_600_000);
    const m = Math.floor((diff % 3_600_000) / 60_000);
    const parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    return parts.length ? parts.join(' ') : '<1m';
}

function parseActivity(val) {
    if (!val) return { last: 0, count: 0 };
    if (typeof val === 'object') return { last: val.last || 0, count: val.count || 0 };
    return { last: val, count: 1 };
}

let handler = async (message, { conn }) => {
    try {
        const chatId = message.from;

        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];

        const groupActivity = global.db?.data?.groupActivity?.[chatId] || {};

        // Miembros actuales del grupo
        let participants = [];
        try {
            const meta = await conn.groupMetadata(chatId);
            participants = meta.participants || [];
        } catch {
            return await message.reply('❌ No pude obtener los miembros del grupo.');
        }

        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));

        // Solo usuarios que están en el grupo con al menos 1 mensaje
        const lista = [];
        for (const p of participants) {
            const num = cleanNum(p.id);
            if (num === botNum || subNums.includes(num)) continue;

            const activity = parseActivity(groupActivity[num]);
            if (activity.count < 1) continue;

            lista.push({
                jid: p.id,
                number: num,
                count: activity.count,
                last: activity.last
            });
        }

        if (lista.length === 0)
            return await message.reply('📊 No hay mensajes registrados en el ranking todavía.');

        // Ordenar de mayor a menor
        lista.sort((a, b) => b.count - a.count);

        const totalMsgs = groupActivity.__total || lista.reduce((s, u) => s + u.count, 0);

        const currentUserNumber = cleanNum(message.author || message.sender);
        const userIndex = lista.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // Paginación
        const itemsPerPage = 10;
        const totalPages = Math.max(1, Math.ceil(lista.length / itemsPerPage));
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        if (args[1] && !isNaN(args[1])) page = Math.max(1, parseInt(args[1]));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const pageUsers = lista.slice(start, start + itemsPerPage);

        // ===== CONSTRUIR MENSAJE =====
        let rankingText = `*🏆 TOP MENSAJES DEL GRUPO 💬*\n\n`;

        rankingText += `👥 *En este grupo:* ${lista.length} usuarios en el top\n`;
        rankingText += `👥 *Total de mensajes:* ${totalMsgs.toLocaleString()}\n\n`;

        if (userPosition > 0) {
            const cu = lista[userIndex];
            rankingText += `📍 *Tu posición:* #${userPosition} — (Pág. ${userPage}) — 💬 ${cu.count.toLocaleString()} mensajes\n`;
            if (userPage !== page)
                rankingText += `   ↳ Usa *${usedPrefix}${cmd} ${userPage}* para ir a tu página\n`;
        } else {
            rankingText += `📍 *Tu posición:* No estás en el ranking\n`;
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const prevPage = page > 1 ? page - 1 : null;
            const nextPage = page < totalPages ? page + 1 : null;
            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *${usedPrefix}${cmd} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *${usedPrefix}${cmd} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        // ===== LISTA DE USUARIOS =====
        const mentions = [];
        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;
            let medal;
            if (pos === 1)      medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else                medal = `${pos}.`;

            rankingText += `${medal} *@${u.number}*\n`;
            rankingText += `💬 ${u.count.toLocaleString()} | ⏱️ hace ${formatAgo(u.last)}\n\n`;
            mentions.push(u.jid);
        });

        await conn.sendMessage(chatId, { text: rankingText, mentions }, {
            quoted: message.baileyMessage || message._baileyMessage
        });

    } catch (error) {
        console.error('[ERROR EN TOPMENSAJES]:', error);
        await message.reply('⚠️ Error al obtener el top de mensajes.');
    }
};

handler.help    = ['topmensajes [página]', 'topactivos [página]', 'toppiolas [página]'];
handler.tags    = ['grupos', 'stats'];
handler.command = /^(topmensajes|topactivos|toppiolas|topmsg|topmsgs)$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;
