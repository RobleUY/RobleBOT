/**
 * Plugin: topmensajes / topactivos / toppiolas
 * Muestra el ranking de usuarios más activos del grupo por cantidad de mensajes.
 * Solo funciona en grupos (los datos son por grupo, no globales).
 *
 * Uso:
 *   .topmensajes        → página 1
 *   .topmensajes 2      → página 2
 *   .topactivos 3       → alias
 *   .toppiolas          → alias
 */

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Normaliza un JID/número a solo dígitos */
function cleanNum(str) {
    return str.split('@')[0].split(':')[0].replace(/\D/g, '');
}

/**
 * Formatea la diferencia de tiempo en días, horas y minutos.
 * Ej: "2d 3h 15m" o "hace menos de 1m"
 */
function formatAgo(ms) {
    if (!ms || ms <= 0) return 'nunca';
    const diff = Date.now() - ms;
    if (diff < 0) return 'ahora mismo';

    const d = Math.floor(diff / 86_400_000);
    const h = Math.floor((diff % 86_400_000) / 3_600_000);
    const m = Math.floor((diff % 3_600_000) / 60_000);

    const parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    return parts.length ? `hace ${parts.join(' ')}` : 'hace menos de 1m';
}

/**
 * Extrae { last, count } del valor guardado en groupActivity.
 * Compatible con el formato legacy (solo timestamp numérico).
 */
function parseActivity(val) {
    if (!val) return { last: 0, count: 0 };
    if (typeof val === 'object') return { last: val.last || 0, count: val.count || 0 };
    // Legacy: era solo un timestamp
    return { last: val, count: 1 };
}

// ── Handler ───────────────────────────────────────────────────────────────────

let handler = async (message, { conn, args }) => {
    const chatId = message.from;

    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    const body = message.body || '';
    const usedPrefix = body.charAt(0) || '.';
    const cmdMatch = body.trim().slice(1).split(/\s+/);
    const cmd = cmdMatch[0] || 'topmensajes';

    // Número de página (primer argumento numérico)
    const pageArg = args[0] && !isNaN(args[0]) ? parseInt(args[0]) : 1;

    // Actividad del grupo
    const groupActivity = global.db?.data?.groupActivity?.[chatId] || {};

    // Obtener miembros actuales del grupo
    let participants = [];
    try {
        const meta = await conn.groupMetadata(chatId);
        participants = meta.participants || [];
    } catch (err) {
        return message.reply('❌ No pude obtener la lista de miembros del grupo.');
    }

    // Número del bot para excluirlo
    const botNum = global.mainBotNumber || '';
    const subNums = (global.subConns || [])
        .filter(c => c?.user)
        .map(c => cleanNum(c.user.id));

    // Construir lista de usuarios con mensajes (solo los que tienen al menos 1)
    const lista = [];
    for (const p of participants) {
        const num = cleanNum(p.id);
        if (num === botNum || subNums.includes(num)) continue;

        const activity = parseActivity(groupActivity[num]);
        if (activity.count < 1) continue; // solo usuarios con al menos un mensaje

        let apodo = '';
        try {
            const userData = global.db?.getUser?.(num);
            apodo = (userData?.apodo || '').trim();
        } catch (_) {}

        lista.push({
            jid: p.id,
            num,
            apodo: apodo || `@${num}`,
            count: activity.count,
            last: activity.last,
            isAdmin: p.admin === 'admin' || p.admin === 'superadmin'
        });
    }

    if (lista.length === 0) {
        return message.reply('📊 Aún no hay mensajes registrados en este grupo.\n_Los mensajes se registran desde que el bot está activo._');
    }

    // Ordenar de mayor a menor mensajes
    lista.sort((a, b) => b.count - a.count);

    // Total de mensajes del grupo
    const totalMsgs = groupActivity.__total || lista.reduce((s, u) => s + u.count, 0);

    // Paginación
    const ITEMS_PER_PAGE = 10;
    const totalPages = Math.max(1, Math.ceil(lista.length / ITEMS_PER_PAGE));
    const page = Math.min(Math.max(1, pageArg), totalPages);
    const start = (page - 1) * ITEMS_PER_PAGE;
    const pageUsers = lista.slice(start, start + ITEMS_PER_PAGE);

    // Posición del usuario que ejecuta el comando
    const senderNum = cleanNum(message.author || message.sender);
    const senderIdx = lista.findIndex(u => u.num === senderNum);
    const senderPos = senderIdx + 1;
    const senderPage = senderPos > 0 ? Math.ceil(senderPos / ITEMS_PER_PAGE) : 0;

    // ── Construir mensaje ─────────────────────────────────────────────────────
    let text = `*💬 TOP MENSAJES DEL GRUPO*\n\n`;
    text += `📊 *Total mensajes registrados:* ${totalMsgs.toLocaleString()}\n`;
    text += `👥 *Usuarios activos:* ${lista.length}\n\n`;

    // Info del usuario que ejecuta
    if (senderPos > 0) {
        const su = lista[senderIdx];
        text += `📍 *Tu posición:* #${senderPos} — *${su.apodo}*\n`;
        text += `   💬 ${su.count.toLocaleString()} mensajes | ${formatAgo(su.last)}\n`;
        if (senderPage !== page) {
            text += `   ↳ Usa *${usedPrefix}${cmd} ${senderPage}* para ir a tu página\n`;
        }
    } else {
        text += `📍 *Tu posición:* No estás en el ranking aún\n`;
    }

    text += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

    // Navegación
    if (totalPages > 1) {
        text += `\n`;
        if (page > 1)          text += `⬅️ *${usedPrefix}${cmd} ${page - 1}* página anterior\n`;
        if (page < totalPages) text += `➡️ *${usedPrefix}${cmd} ${page + 1}* siguiente página\n`;
    }

    text += `\n`;

    // Lista de usuarios de la página
    const mentions = [];
    pageUsers.forEach((u, i) => {
        const pos = start + i + 1;
        let medal;
        if (pos === 1)      medal = '🥇';
        else if (pos === 2) medal = '🥈';
        else if (pos === 3) medal = '🥉';
        else                medal = `${pos}.`;

        const adminTag = u.isAdmin ? ' 👑' : '';
        const nombre = u.apodo.startsWith('@') ? `@${u.num}` : u.apodo;

        text += `${medal} *${nombre}*${adminTag}\n`;
        text += `   💬 ${u.count.toLocaleString()} msgs | ${formatAgo(u.last)}\n\n`;

        mentions.push(u.jid);
    });

    text += `⚠️ _Solo se registran mensajes desde que el bot está activo._`;

    await conn.sendMessage(chatId, { text, mentions }, {
        quoted: message.baileyMessage || message._baileyMessage
    });
};

handler.help    = ['topmensajes [página]', 'topactivos [página]', 'toppiolas [página]'];
handler.tags    = ['grupos', 'stats'];
handler.command = /^(topmensajes|topactivos|toppiolas|topmsg|topmsgs)$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;
