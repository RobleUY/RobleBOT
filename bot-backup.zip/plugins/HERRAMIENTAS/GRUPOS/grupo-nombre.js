/**
 * Comando: name / nombre
 * Descripción: Cambia el nombre del grupo.
 * Uso: .name <nuevo nombre>
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- Obtener el nuevo nombre ---
        const text = message.body.split(' ').slice(1).join(' ').trim();

        if (!text) {
            return await message.reply('⚠️ Debes escribir el *nuevo nombre* del grupo.\n\n*Ejemplo:*\n`.name Grupo Oficial`');
        }

        // Limitar la longitud del nombre si es necesario (WhatsApp permite hasta 25 caracteres)
        const newName = text.substring(0, 25);

        // --- Verificaciones de permisos ---

        // 1. Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);

        // 2. Verificar si el bot es administrador
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });

        if (!botParticipant) {
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!botIsAdmin) {
            return await message.reply('❌ No puedo cambiar el nombre porque *no soy administrador* del grupo.');
        }

        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];

        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });

        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Acción de cambiar el nombre ---
        try {
            await conn.groupUpdateSubject(message.from, newName);
            await message.reply('✅ *Nombre del grupo actualizado correctamente.*');
        } catch (updateError) {
            console.error('[ERROR] Error al cambiar el nombre del grupo:', updateError.message);

            if (updateError.toString().includes('forbidden') || updateError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos para editar el nombre del grupo.');
            }

            return await message.reply('❌ Ocurrió un error al intentar cambiar el nombre del grupo.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
        }

    } catch (error) {
        console.error('[ERROR] Error general en comando name:', error.message);
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
    }
};

// --- Configuración del Handler ---
handler.help = ['name <nuevo nombre>', 'nombre <nuevo nombre>'];
handler.tags = ['admin'];
handler.command = /^(gnamename|nameg|name|nombre|nombreg)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
