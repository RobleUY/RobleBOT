/**
 * Comando: infog
 * Descripción: Muestra información detallada del grupo (nombre, participantes, admins, creador, descripción y enlace).
 * Uso: .infog
 */

let handler = async (message, { conn }) => {
    try {
        // --- 1. Verificar si se usa en grupo ---
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- 2. Obtener metadatos del grupo ---
        const groupMetadata = await conn.groupMetadata(message.from);
        const participants = groupMetadata.participants || [];
        const totalParticipants = participants.length;

        // --- 3. Obtener administradores ---
        const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
        const adminsList = admins.map((p, index) =>
            `${index + 1}. @${p.id.split('@')[0]} (${p.admin === 'superadmin' ? 'Super Admin' : 'Admin'})`
        ).join('\n');

        // --- 4. Determinar el creador ---
        const ownerJid = groupMetadata.owner;
        const ownerMention = ownerJid ? `@${ownerJid.split('@')[0]}` : 'Desconocido';

        // --- 5. Formatear la fecha de creación ---
        const creationDate = groupMetadata.creation ?
            new Date(groupMetadata.creation * 1000).toLocaleDateString('es-ES', {
                year: 'numeric', month: 'long', day: 'numeric',
                hour: '2-digit', minute: '2-digit'
            }) : 'Desconocida';

        // --- 6. Verificar si el bot es administrador de forma robusta ---
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });

        // Fallback por si no se encontró
        if (!botParticipant) {
            botParticipant = participants.find(p => p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin'));
        }

        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        // --- 7. Intentar obtener el enlace de invitación ---
        let inviteLink = 'Requiere que el bot sea administrador para mostrar el enlace.';
        if (botIsAdmin) {
            try {
                const code = await conn.groupInviteCode(message.from);
                inviteLink = `https://chat.whatsapp.com/${code}`;
            } catch {
                inviteLink = 'El bot es Admin, pero no se pudo generar el enlace.';
            }
        }

        // --- 8. Construir mensaje final ---
        const info =
            '📌 *I N F O  D E L  G R U P O*\n\n' +
            `🏷️ *Nombre:* ${groupMetadata.subject || 'No definido'}\n` +
            `👥 *Participantes:* ${totalParticipants}\n` +
            `👑 *Creador:* ${ownerMention}\n` +
            `📅 *Fecha de Creación:* ${creationDate}\n\n` +
            '----------------------------------------\n' +
            `🔗 *Enlace de Invitación:*\n${inviteLink}\n` +
            '----------------------------------------\n\n' +
            `🛃 *Administradores (${admins.length}):*\n${adminsList || 'Ninguno'}\n\n` +
            `📄 *Descripción:*\n${groupMetadata.desc || 'No hay descripción.'}`;

        // --- 9. Crear lista de menciones (creador + admins) ---
        const mentions = [ownerJid, ...admins.map(a => a.id)].filter(Boolean);

        // --- 10. Enviar mensaje ---
        await message.reply(info, { mentions });

    } catch (error) {
        console.error('[ERROR] Error en comando infog:', error);
        await message.reply('❌ Ocurrió un error inesperado al intentar obtener la información del grupo.');
    }
};

// --- Configuración del Handler ---
handler.help = ['infog', 'ginfo'];
handler.tags = ['group'];
handler.command = /^(infog|ginfo|groupinfo)$/i;
handler.group = true;
handler.admin = false;

module.exports = handler;
