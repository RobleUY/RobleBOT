const axios = require('axios')
const fs = require('fs').promises
const fsSync = require('fs')
const path = require('path')
const os = require('os')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')

const API_KEY = "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"

// TTS gratuito via Google Translate
const TTS_URL = 'https://translate.google.com/translate_tts'

// 🧠 CONTEXTO desde archivo externo
const CONTEXT_FILE = path.join(__dirname, 'IA-CONTEXTO.md')
let SYSTEM_CONTEXT = 'Eres RobleBOT, un asistente de WhatsApp creado por RobleUY.'
if (fsSync.existsSync(CONTEXT_FILE)) {
    const raw = fsSync.readFileSync(CONTEXT_FILE, 'utf-8')
    // Limpiar markdown: quitar headers, bullets, asteriscos
    SYSTEM_CONTEXT = raw
        .replace(/^#+\s+/gm, '') // headers
        .replace(/^\s*[-*]\s+/gm, '') // bullets
        .replace(/\*\*([^*]+)\*\*/g, '$1') // negrita
        .replace(/\n{3,}/g, '\n\n') // múltiples saltos
        .trim()
}

function tmpFile(ext) {
    return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + '.' + ext)
}

async function textToSpeech(text, lang = 'es') {
    const url = `${TTS_URL}?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=tw-ob`
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 15000
    })
    return Buffer.from(res.data)
}

async function convertToOgg(inputPath) {
    const outputPath = tmpFile('ogg')
    return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
            .audioCodec('libopus')
            .format('ogg')
            .audioFilters('atempo=1.3')
            .on('end', () => resolve(outputPath))
            .on('error', reject)
            .save(outputPath)
    })
}


async function askGroq(text) {
    const res = await axios.post(
        "https://api.groq.com/openai/v1/chat/completions",
        {
            model: "llama-3.1-8b-instant",
            messages: [
                {
                    role: "system",
                    content: SYSTEM_CONTEXT + '\n\nIMPORTANTE para modo voz: responde en máximo 2 oraciones cortas y naturales, sin listas, sin formato y sin emojis.'
                },
                { role: "user", content: text }
            ],
            temperature: 0.7,
            max_tokens: 150
        },
        {
            headers: {
                "Authorization": `Bearer ${API_KEY}`,
                "Content-Type": "application/json"
            },
            timeout: 15000
        }
    )
    return res.data?.choices?.[0]?.message?.content?.trim()
}

let handler = async (message, { text }) => {
    try {
        if (!text || text.trim().length < 2) {
            return message.reply('❌ Uso: `.iavoz <texto>`\nEj: `.iavoz cuál es la capital de Francia?`')
        }

        const sock = global.conn
        if (!sock) return message.reply('❌ Conexión no disponible.')

        await message.reply('🎙️ Generando respuesta de voz...')

        // 1. Obtener respuesta de la IA
        const respuesta = await askGroq(text)
        if (!respuesta) return message.reply('❌ La IA no respondió.')

        // 2. Convertir a audio (quitar emojis antes del TTS)
        const respuestaLimpia = respuesta.replace(/[\u{1F000}-\u{1FFFF}]|[\u{2600}-\u{27BF}]|[\u{2300}-\u{23FF}]/gu, '').trim()
        const audioBuffer = await textToSpeech(respuestaLimpia, 'es')

        // 3. Guardar MP3 temporal y convertir a OGG Opus
        const mp3Path = tmpFile('mp3')
        await fs.writeFile(mp3Path, audioBuffer)
        const oggPath = await convertToOgg(mp3Path)
        const oggBuffer = await fs.readFile(oggPath)

        // Limpiar temporales
        fs.unlink(mp3Path).catch(() => {})
        fs.unlink(oggPath).catch(() => {})

        // 4. Enviar como nota de voz
        await sock.sendMessage(message.from, {
            audio: oggBuffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
        })

    } catch (err) {
        console.error('[IAVOZ ERROR]', err?.response?.data || err?.message || err)
        return message.reply('❌ Error al generar la nota de voz.')
    }
}

handler.help = ['iavoz <texto>']
handler.tags = ['ai', 'herramientas']
handler.command = /^iavoz$/i

module.exports = handler
