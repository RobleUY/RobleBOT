const axios = require('axios');
const fs = require('fs/promises');
const fsSync = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');

const HARDCODED_FALLBACK_KEY = "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";
const MODEL_LIST = ['openai/gpt-oss-20b','openai/gpt-oss-120b','qwen/qwen3-32b','meta-llama/llama-4-scout-17b-16e-instruct','llama-3.3-70b-versatile','llama-3.3-8b-instant','llama-3.1-8b-instant'];

function collectGroqKeys() {
    const keys = new Set();
    const variations = [
        'groq_api_key', 'GROQ_API_KEY',
        'groq_api_key1', 'GROQ_API_KEY1',
        'groq_api_key2', 'GROQ_API_KEY2',
        'groq_api_key3', 'GROQ_API_KEY3',
        'groq_api_key4', 'GROQ_API_KEY4'
    ];
    for (const name of variations) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0 && HARDCODED_FALLBACK_KEY) keys.add(HARDCODED_FALLBACK_KEY);
    return Array.from(keys);
}
const TTS_URL = 'https://translate.google.com/translate_tts';
const CONTEXT_FILE = path.join(__dirname, 'IA-CONTEXTO.md');

// 🧠 Cargar y limpiar contexto en memoria al iniciar
let SYSTEM_CONTEXT = 'Eres RobleBOT, un asistente de WhatsApp creado por RobleUY.';
try {
    if (fsSync.existsSync(CONTEXT_FILE)) {
        const raw = fsSync.readFileSync(CONTEXT_FILE, 'utf-8');
        SYSTEM_CONTEXT = raw
            .replace(/^#+\s+/gm, '') 
            .replace(/^\s*[-*]\s+/gm, '') 
            .replace(/\*\*([^*]+)\*\*/g, '$1') 
            .replace(/\n{3,}/g, '\n\n') 
            .trim();
    }
} catch (e) {
    console.error('[IAVOZ] No se pudo leer el contexto:', e.message);
}

// 🛠️ Generador de rutas temporales
const tmpFile = (ext) => path.join(os.tmpdir(), `${crypto.randomBytes(8).toString('hex')}.${ext}`);

// 🗣️ Text to Speech (Google Translate) - ¡AHORA SOPORTA TEXTOS LARGOS!
async function textToSpeech(text, lang = 'es') {
    const MAX_CHARS = 180; // Límite seguro debajo de los 200 de Google
    const words = text.split(' ');
    const chunks = [];
    let currentChunk = '';

    // Dividimos el texto largo en fragmentos que Google pueda procesar
    for (const word of words) {
        if ((currentChunk + word).length > MAX_CHARS) {
            if (currentChunk) chunks.push(currentChunk.trim());
            currentChunk = word + ' ';
        } else {
            currentChunk += word + ' ';
        }
    }
    if (currentChunk) chunks.push(currentChunk.trim());

    const buffers = [];
    
    // Solicitamos el audio por cada fragmento
    for (const chunk of chunks) {
        const url = `${TTS_URL}?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=${lang}&client=tw-ob`;
        try {
            const res = await axios.get(url, {
                responseType: 'arraybuffer',
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
                timeout: 15000
            });
            buffers.push(Buffer.from(res.data));
            // Pequeña pausa para evitar que Google nos bloquee por spam (Error 429)
            await new Promise(resolve => setTimeout(resolve, 300));
        } catch (error) {
            console.error('[TTS CHUNK ERROR]', error.message);
        }
    }

    // Concatenamos todos los MP3 nativamente (los MP3 se pueden pegar uno detrás de otro)
    return Buffer.concat(buffers);
}

// 🔄 Convertir MP3 concatenado a OGG Opus
function convertToOgg(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
            .audioCodec('libopus')
            .format('ogg')
            .audioFilters('atempo=1.3') // Acelera ligeramente la voz
            .on('end', () => resolve(outputPath))
            .on('error', (err) => reject(new Error(`FFmpeg error: ${err.message}`)))
            .save(outputPath);
    });
}

// 🤖 Consultar a la IA (Groq)
async function askGroq(text) {
    const systemPrompt = `${SYSTEM_CONTEXT}\n\nIMPORTANTE para modo voz: Eres un asistente conversacional. Responde de forma directa, sin listas, sin formato y sin emojis. Si el usuario te pide leer un número, texto o explicar algo, hazlo completo pero mantenlo hablado y natural.`;
    
    const keys = collectGroqKeys();
    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        try {
            const res = await axios.post(
                "https://api.groq.com/openai/v1/chat/completions",
                {
                    model: "llama-3.1-8b-instant",
                    messages: [
                        { role: "system", content: systemPrompt },
                        { role: "user", content: text }
                    ],
                    temperature: 0.5,
                    max_tokens: 600 // Aumentamos los tokens drásticamente para que pueda escribir números enormes
                },
                {
                    headers: {
                        "Authorization": `Bearer ${key}`,
                        "Content-Type": "application/json"
                    },
                    timeout: 20000
                }
            );
            return res.data?.choices?.[0]?.message?.content?.trim();
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            const apiErrCode = err.response?.data?.error?.code;
            console.log(`[IAVOZ] ⚠️ Key ${i + 1} failed (status=${status} code=${apiErrCode}). Trying next key.`);
            if (i === keys.length - 1) throw err;
            if (status && ![401,403,429].includes(status) && apiErrCode !== 'rate_limit_exceeded') throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// 🚀 Handler Principal
let handler = async (message, { text, conn }) => {
    if (!text || text.trim().length < 2) {
        return message.reply('❌ Uso: `.iavoz <texto>`\nEj: `.iavoz cuál es la capital de Francia?`');
    }

    const sock = conn || message._sock || global.conn;
    if (!sock) return message.reply('❌ Conexión no disponible.');

    let mp3Path = null;
    let oggPath = null;

    try {
        await message.reply('🎙️ Grabando nota de voz, puede tardar un poco si es largo...');

        // 1. Obtener respuesta
        const respuesta = await askGroq(text);
        if (!respuesta) return message.reply('❌ La IA no respondió.');

        // 2. Limpiar texto de emojis y caracteres que rompan el TTS
        const respuestaLimpia = respuesta.replace(/[\u{1F000}-\u{1FFFF}]|[\u{2600}-\u{27BF}]|[\u{2300}-\u{23FF}]|\*|#|_|~/gu, '').trim();
        if (!respuestaLimpia) return message.reply('❌ La respuesta de la IA no se pudo procesar a voz.');

        // 3. Generar Audio (ahora unirá múltiples buffers si es muy largo)
        const audioBuffer = await textToSpeech(respuestaLimpia, 'es');

        // 4. Guardar MP3
        mp3Path = tmpFile('mp3');
        oggPath = tmpFile('ogg');
        await fs.writeFile(mp3Path, audioBuffer);

        // 5. Convertir a OGG
        await convertToOgg(mp3Path, oggPath);
        const oggBuffer = await fs.readFile(oggPath);

        // 6. Enviar
        await sock.sendMessage(message.from, {
            audio: oggBuffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true 
        }, { quoted: message._baileyMessage });

    } catch (err) {
        console.error('[IAVOZ ERROR]', err?.response?.data || err?.message || err);
        return message.reply('❌ Error al generar la nota de voz. Intentá de nuevo más tarde.');
    } finally {
        if (mp3Path) await fs.unlink(mp3Path).catch(() => {});
        if (oggPath) await fs.unlink(oggPath).catch(() => {});
    }
};

handler.help = ['iavoz <texto>'];
handler.tags = ['ai', 'herramientas'];
handler.command = /^iavoz$/i;

module.exports = handler;