const axios = require('axios')
const fs = require('fs')
const path = require('path')

const API_KEY = "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"
const CHAT_USUARIOS_DIR = path.join(__dirname, '../../../CHATS-USUARIOS')
const MAX_CHARS = 15000

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

async function groqConRetry(messages, maxTokens = 250, reintentos = 4) {
    for (let intento = 1; intento <= reintentos; intento++) {
        try {
            const res = await axios.post(
                "https://api.groq.com/openai/v1/chat/completions",
                { model: "llama-3.1-8b-instant", messages, temperature: 0.5, max_tokens: maxTokens },
                { headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" }, timeout: 30000 }
            )
            return res.data?.choices?.[0]?.message?.content
        } catch (err) {
            if (err?.response?.status === 429 && intento < reintentos) {
                await sleep(10000 * intento)
            } else throw err
        }
    }
}

function getUserInfo(message, text) {
    const mentioned = message.mentions?.[0]
    if (mentioned) {
        const numero = mentioned.split('@')[0].replace(/\D/g, '')
        // quitar la mención del texto para quedarnos solo con la pregunta
        const pregunta = text.replace(/@\d+/g, '').trim()
        return { numero, jid: mentioned, esPropioUsuario: false, pregunta }
    }

    const senderJid = message.sender
    const numero = senderJid.split('@')[0].replace(/\D/g, '')
    return { numero, jid: senderJid, esPropioUsuario: true, pregunta: text.trim() }
}

function leerHistorial(numero, groupId) {
    const file = groupId
        ? path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
        : path.join(CHAT_USUARIOS_DIR, `${numero}.txt`)
    if (!fs.existsSync(file)) return null
    let contenido = fs.readFileSync(file, 'utf-8').trim()
    if (!contenido) return null
    // limpiar timestamps
    contenido = contenido.split('\n')
        .map(l => l.replace(/^\[.*?\]\s*/, '').trim())
        .filter(Boolean)
        .join('\n')
    if (contenido.length > MAX_CHARS) contenido = '...[recortado]\n' + contenido.slice(-MAX_CHARS)
    return contenido
}

async function preguntarSobre(historial, pregunta) {
    const prompt = `Basándote ÚNICAMENTE en los siguientes mensajes de WhatsApp de una persona, responde esta pregunta de forma breve y directa (máximo 80 palabras).
Algunos mensajes tienen el formato: (respondiendo a NUMERO: "mensaje original") respuesta — esto indica que la persona respondió a ese mensaje, úsalo como contexto adicional.

Pregunta: ${pregunta}

MENSAJES:
${historial}`

    return await groqConRetry([
        { role: "system", content: "Eres un analista de comportamiento. Responde en español, breve y directo, basándote solo en los mensajes dados." },
        { role: "user", content: prompt }
    ], 250)
}

let handler = async (message, { text }) => {
    try {
        if (!text || text.trim().length < 3) {
            return message.reply('❓ Escribe una pregunta. Ej: `/sobre @usuario está feliz?`')
        }

        const { numero, jid, esPropioUsuario, pregunta } = getUserInfo(message, text)

        if (!pregunta) {
            return message.reply('❓ Falta la pregunta. Ej: `/sobre @usuario está feliz?`')
        }

        const historial = leerHistorial(numero, message.from)

        if (!historial) {
            const msg = esPropioUsuario
                ? '❌ No tengo mensajes tuyos guardados aún.'
                : `❌ No tengo historial de @${jid.split('@')[0]}.`
            return message.reply(msg, { mentions: esPropioUsuario ? [] : [jid] })
        }

        await message.reply('🔍 Analizando...')

        const respuesta = await preguntarSobre(historial, pregunta)

        const header = esPropioUsuario
            ? `🧠 *Sobre ti:*\n`
            : `🧠 *Sobre @${jid.split('@')[0]}:*\n`

        return message.reply(header + respuesta.trim(), { mentions: esPropioUsuario ? [] : [jid] })

    } catch (err) {
        console.error('[SOBRE ERROR]', err?.message || err)
        return message.reply('❌ Error al procesar la pregunta.')
    }
}

handler.help = ['sobre @usuario <pregunta>']
handler.tags = ['ai', 'herramientas']
handler.command = /^(sobre|ask)$/i

module.exports = handler
