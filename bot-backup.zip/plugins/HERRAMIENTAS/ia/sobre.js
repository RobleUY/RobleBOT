'use strict';
/**
 * Comando: .sobre
 * Hace una pregunta sobre ti o sobre otro usuario basándose en su historial de chat
 * Uso: .sobre [pregunta] o .sobre @usuario [pregunta]
 */

const { getUserDb } = require('../../../chatLogger');
const axios = require('axios');

const GROQ_API_KEY = "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";
const MAX_CHARS = 8000;

async function askGroq(prompt) {
    try {
        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: 'llama-3.3-70b-versatile',
                messages: [
                    {
                        role: 'system',
                        content: 'Eres un analista experto de conversaciones de WhatsApp. Tu trabajo es responder preguntas sobre el comportamiento, mensajes, personalidad o dudas de un usuario usando el historial de chat provisto. Responde de forma BREVE, DIRECTA y al grano en máximo 3-4 oraciones. Responde en español.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.7,
                max_tokens: 300
            },
            {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            }
        );

        return response.data.choices[0].message.content;
    } catch (e) {
        console.error('[sobre] Error en Groq:', e.message);
        throw new Error('Error consultando IA: ' + e.message);
    }
}

const handler = async (message, { args }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        const mentionedJids = message?.mentions;
        const mentioned = mentionedJids && mentionedJids.length > 0 ? mentionedJids[0] : null;
        
        let targetUser = mentioned;
        // Guardamos la pregunta original intacta para que la IA entienda el contexto completo
        const originalQuestion = args ? args.join(' ') : '';
        let cleanQuestion = originalQuestion;

        // Identificar al que ejecuta el comando (.sender)
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid.split('@')[0].split(':')[0];

        if (!mentioned) {
            // Si no hay mención, el objetivo es el mismo que escribe
            targetUser = senderJid;
        } else {
            // Limpiamos los @ del texto solo para los encabezados, no para el análisis de la IA
            cleanQuestion = cleanQuestion.replace(/@\d+/g, '').trim();
        }

        if (!targetUser) {
            return message.reply('❌ No se pudo determinar el usuario a analizar.');
        }

        if (!originalQuestion) {
            return message.reply(
                '*🤔 PREGUNTAS SOBRE USUARIOS*\n\n' +
                'Uso:\n' +
                '• `.sobre [pregunta]` - Pregunta sobre ti\n' +
                '• `.sobre @usuario [pregunta]` - Pregunta sobre otro usuario\n\n' +
                'Ejemplos:\n' +
                '• `.sobre cuál fue mi último mensaje?`\n' +
                '• `.sobre @pepe es normal?`\n' +
                '_Analiza hasta 8000 caracteres del historial de chat_'
            );
        }

        const targetNumber = targetUser.split('@')[0].split(':')[0];
        const isSelf = targetUser === senderJid;

        await message.reply('🤔 Analizando mensajes...');

        // Obtener mensajes de la base de datos
        const db = getUserDb(targetNumber);
        const messages = db.prepare(`
            SELECT content, quoted_content, transcription, timestamp, message_type
            FROM messages
            WHERE group_jid = ?
            ORDER BY timestamp DESC
            LIMIT 200
        `).all(message.from);

        if (!messages || messages.length === 0) {
            return message.reply(`📭 No hay mensajes guardados de ${isSelf ? 'ti' : 'ese usuario'} en este grupo.`);
        }

        // Construir contexto del historial (Los mensajes más nuevos quedarán al final para que la IA los priorice)
        let context = '';
        let charCount = 0;

        for (const msg of messages.reverse()) {
            let msgText = '';

            if (msg.quoted_content) {
                msgText += `[Respondiendo a: "${msg.quoted_content}"] `;
            }

            if (msg.transcription) {
                msgText += `(nota de voz) ${msg.transcription}`;
            } else if (msg.content) {
                msgText += msg.content;
            }

            if (msgText.trim()) {
                const line = `- ${msgText}\n`;
                if (charCount + line.length > MAX_CHARS) break;
                context += line;
                charCount += line.length;
            }
        }

        if (!context.trim()) {
            return message.reply('❌ No hay suficiente contenido de texto para analizar.');
        }

        // --- SOLUCIÓN DEL CONTEXTO ---
        // Le pasamos la pregunta COMPLETAMENTE INTACTA (originalQuestion) y le explicamos la estructura a la IA
        let prompt = `CONTEXTO DEL SISTEMA:\n`;
        prompt += `El usuario ejecutor es @${senderNumber}.\n`;
        prompt += `El historial provisto abajo pertenece UNICAMENTE al usuario objetivo @${targetNumber}.\n`;
        prompt += `Nota: El último mensaje enviado por el usuario objetivo @${targetNumber} está al FINAL de la lista de mensajes provista.\n\n`;
        
        prompt += `PREGUNTA DEL USUARIO EJECUTOR:\n`;
        prompt += `"${originalQuestion}"\n\n`;
        
        prompt += `HISTORIAL DE MENSAJES DE @${targetNumber} (De más antiguo a más reciente):\n${context}\n\n`;
        prompt += `Respuesta analítica basada estrictamente en el historial anterior:`;

        // Consultar IA
        const response = await askGroq(prompt);

        // El título del mensaje queda limpio y bonito en el chat
        const header = isSelf
            ? `🤔 *Sobre ti: ${cleanQuestion}*\n\n`
            : `🤔 *Sobre @${targetNumber}: ${cleanQuestion}*\n\n`;

        let mentions = [senderJid];
        if (!isSelf) mentions.push(targetUser);

        await message.reply(header + response, { mentions: mentions });

    } catch (e) {
        console.error('[sobre] Error:', e);
        await message.reply('❌ Error: ' + e.message);
    }
};

handler.help = ['sobre'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(sobre|about)$/i;

module.exports = handler;