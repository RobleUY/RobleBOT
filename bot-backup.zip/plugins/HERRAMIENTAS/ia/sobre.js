'use strict';
/**
 * Comando: .sobre
 * Hace una pregunta sobre ti o sobre otro usuario basándose en su historial de chat
 * Uso: .sobre [pregunta] o .sobre @usuario [pregunta]
 */

const { getUserDb } = require('../../../chatLogger');
const axios = require('axios');

const GROQ_API_KEY = "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";
const MAX_CHARS = 8000;

async function askGroq(prompt) {
    try {
        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: 'llama-3.3-70b-versatile',
                messages: [
                    {
                        role: 'system',
                        content: 'Eres un asistente que analiza conversaciones de WhatsApp. Responde de forma BREVE y DIRECTA en máximo 3-4 oraciones. Sé honesto y perspicaz pero conciso. Responde en español.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.7,
                max_tokens: 300
            },
            {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            }
        );

        return response.data.choices[0].message.content;
    } catch (e) {
        console.error('[sobre] Error en Groq:', e.message);
        throw new Error('Error consultando IA: ' + e.message);
    }
}

const handler = async (message, { args }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Detectar si hay usuario mencionado
        const mentioned = message.mentionedJid?.[0];
        let targetUser = mentioned;
        let question = args.join(' ');

        if (!mentioned) {
            // Sin mención = pregunta sobre el usuario que ejecuta el comando
            targetUser = message.sender;
        } else {
            // Con mención = quitar la mención de la pregunta
            question = question.replace(/@\d+/g, '').trim();
        }

        if (!question) {
            return message.reply(
                '*🤔 PREGUNTAS SOBRE USUARIOS*\n\n' +
                'Uso:\n' +
                '• `.sobre [pregunta]` - Pregunta sobre ti\n' +
                '• `.sobre @usuario [pregunta]` - Pregunta sobre otro usuario\n\n' +
                'Ejemplos:\n' +
                '• `.sobre soy agresivo?`\n' +
                '• `.sobre @pepe es normal?`\n' +
                '• `.sobre qué tipo de persona soy?`\n' +
                '• `.sobre @juan es confiable?`\n\n' +
                '_Analiza hasta 8000 caracteres del historial de chat_'
            );
        }

        const userNumber = targetUser.split('@')[0].split(':')[0];
        const isSelf = targetUser === message.sender;

        await message.reply('🤔 Analizando mensajes...');

        // Obtener mensajes del usuario en este grupo
        const db = getUserDb(userNumber);
        const messages = db.prepare(`
            SELECT content, quoted_content, transcription, timestamp, message_type
            FROM messages
            WHERE group_jid = ?
            ORDER BY timestamp DESC
            LIMIT 200
        `).all(message.from);

        if (messages.length === 0) {
            return message.reply(`📭 No hay mensajes guardados de ${isSelf ? 'ti' : 'ese usuario'} en este grupo.`);
        }

        // Construir contexto (hasta 8000 caracteres)
        let context = '';
        let charCount = 0;

        for (const msg of messages.reverse()) {
            let msgText = '';

            if (msg.quoted_content) {
                msgText += `[Respondiendo a: "${msg.quoted_content}"] `;
            }

            if (msg.transcription) {
                msgText += `(nota de voz) ${msg.transcription}`;
            } else if (msg.content) {
                msgText += msg.content;
            }

            if (msgText.trim()) {
                const line = `- ${msgText}\n`;
                if (charCount + line.length > MAX_CHARS) break;
                context += line;
                charCount += line.length;
            }
        }

        if (!context.trim()) {
            return message.reply('❌ No hay suficiente contenido de texto para analizar.');
        }

        // Construir prompt
        const userName = isSelf ? 'el usuario' : 'la persona mencionada';
        const prompt = `Basándote en estos mensajes de WhatsApp de ${userName}, responde en MÁXIMO 3-4 oraciones: "${question}"\n\nMensajes:\n${context}\n\nRespuesta breve y directa:`;

        // Consultar IA
        const response = await askGroq(prompt);

        const header = isSelf
            ? `🤔 *${question}*\n\n`
            : `🤔 *Sobre ${userNumber}: ${question}*\n\n`;

        await message.reply(header + response);

    } catch (e) {
        console.error('[sobre] Error:', e);
        await message.reply('❌ Error: ' + e.message);
    }
};

handler.help = ['sobre'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(sobre|about)$/i;

module.exports = handler;
