/**
 * Comando: ia2 / iavoz
 * Descripción: Consulta a la IA y responde con audio de voz
 * Uso: .ia2 <texto> o .iavoz <texto>
 */
const axios = require('axios');
const gtts = require('node-gtts');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

/* --------------------------- CONFIGURACIÓN IA --------------------------- */
const contextPrompt = `Eres RobleBOT, desarrollado por RobleUY. 
Responde siempre en español, salvo que explícitamente te pidan otro idioma.
Mantén conversaciones naturales y fluidas. Recuerda el contexto de la conversación.
Sé conciso en tus respuestas ya que serán convertidas a audio.`;

const GEMINI_API_KEY = "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE";
const GOOGLE_SEARCH_API_KEY = "AIzaSyCjHilWpVdqZFxgeXql08pdUH7KXibkh0E";
const GOOGLE_SEARCH_ENGINE_ID = "b33d1939141004dcf";

/* --------------------------- FUNCIONES AUXILIARES --------------------------- */
function tmpFileName(ext = '') {
  const name = crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function searchGoogle(query) {
  try {
    const res = await axios.get("https://www.googleapis.com/customsearch/v1", {
      params: {
        key: GOOGLE_SEARCH_API_KEY,
        cx: GOOGLE_SEARCH_ENGINE_ID,
        q: query
      }
    });
    if (res.data.items && res.data.items.length > 0) {
      return res.data.items.slice(0, 3).map(item => `${item.title}: ${item.snippet}`).join("\n");
    } else {
      return "";
    }
  } catch (err) {
    console.error("[ERROR] Falló la búsqueda en Google:", err.response?.data || err.message);
    return "";
  }
}

/* --------------------------- FUNCIÓN TEXTO A VOZ --------------------------- */
async function textToSpeech(text) {
  const tempMp3 = tmpFileName('mp3');
  const tempOpus = tmpFileName('opus');
  
  const tts = gtts('es'); 
  
  try {
    // Generar MP3 con Google TTS
    await new Promise((resolve, reject) => {
      tts.save(tempMp3, text, (err) => (err ? reject(err) : resolve()));
    });
    
    // Convertir MP3 → OGG (opus) con velocidad aumentada
    const args = [
      '-y',
      '-i', tempMp3,
      '-filter:a', 'atempo=1.2',
      '-ar', '48000',
      '-ac', '1',
      '-c:a', 'libopus',
      '-b:a', '64k',
      '-vbr', 'on',
      tempOpus
    ];
    
    await execFileAsync('ffmpeg', args, { windowsHide: true });
    const audioBuffer = await fs.readFile(tempOpus);
    return audioBuffer;
    
  } finally {
    await fs.unlink(tempMp3).catch(() => {});
    await fs.unlink(tempOpus).catch(() => {});
  }
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message, { text, conn }) => {
  try {
    if (!conn) return await message.reply('❌ Error: conexión no disponible.');
    
    if (!text || !text.trim()) {
      return await message.reply(
        '*🤖 IA CON VOZ*\n\n' +
        '💡 *Uso:*\n' +
        '• */iavoz <pregunta>*\n\n' +
        '📝 La IA responderá con un mensaje de audio.\n' +
        '⚠️ Recomendado: Preguntas cortas para respuestas más concisas.'
      );
    }

    // Mensaje 1: La IA está respondiendo
    await message.reply('🤖 RobleBOT está respondiendo...');

    // Buscar en Google información relevante
    const googleResults = await searchGoogle(text);
    
    // Crear prompt completo para la IA
    const fullPrompt = `${contextPrompt}\n\nSi necesitas información actualizada o hechos concretos, usa lo siguiente:\n${googleResults}\n\nSolicitud del usuario: ${text}`;

    // Consultar a Gemini
    const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    const response = await axios.post(`${API_URL}?key=${GEMINI_API_KEY}`, {
      contents: [{ parts: [{ text: fullPrompt }] }]
    }, {
      headers: { "Content-Type": "application/json" }
    });

    if (!response.data || !response.data.candidates || !response.data.candidates[0]) {
      throw new Error("Respuesta inválida de la API");
    }

    let aiResponse = response.data.candidates[0].content.parts[0].text;
    
    // Limitar longitud para el audio (máximo 1000 caracteres)
    if (aiResponse.length > 1000) {
      aiResponse = aiResponse.slice(0, 997) + "...";
    }

    // Generar audio de la respuesta
    const audioBuffer = await textToSpeech(aiResponse);
    
    if (!audioBuffer) {
      return await message.reply('❌ Error al generar el audio.');
    }

    // Mensaje 2: Enviar el audio como respuesta al comando original (igual que musicyt)
    await conn.sendMessage(message.from, {
      audio: audioBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { quoted: message._baileyMessage });

    console.log('✅ Audio de IA enviado correctamente');

  } catch (error) {
    console.error("[ERROR] Error en comando IA con voz:", error.response?.data || error.message);
    return await message.reply("❌ Ocurrió un error al procesar tu solicitud. Por favor, intenta de nuevo.");
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['ia2 <texto>', 'iavoz <texto>'];
handler.tags = ['ai'];
handler.command = /^(ia2|iavoz)$/i;

module.exports = handler;