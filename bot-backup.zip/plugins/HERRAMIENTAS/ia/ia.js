const https = require('https');
const http = require('http');

// Circuit breaker global de red (accesible via global.networkGuard si está disponible)
function getNetGuard() { return (typeof global !== 'undefined' && global.networkGuard) ? global.networkGuard : null; }

// ─── Configuración ────────────────────────────────────────────────────────────
const TIMEOUT = 20000;
const MODEL_LIST = [
    'openai/gpt-oss-20b',
    'openai/gpt-oss-120b',
    'qwen/qwen3-32b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'llama-3.3-70b-versatile',
    'llama-3.3-8b-instant',
    'llama-3.1-8b-instant'
];

const SYSTEM_PROMPT = `
Nombre: RobleBOT
Rol: Asistente de WhatsApp
Creador: Dev RobleUY (Desarrollador uruguayo, nacido el 13 de enero de 2004, estudió programación, ingeniería de software e ingeniería en robótica)
Idioma: Español

Reglas de formato y comportamiento:
- Formato WhatsApp: Usa *negrita* (NUNCA **negrita**), _cursiva_, ~tachado~ y \`\`\`código\`\`\`.
- Estilo: Mensajes decorados, claros, útiles y amigables, con el uso de algunos pocos emojis.
- Identidad: Si te preguntan quién te creó o de dónde sos, menciona a Dev RobleUY y que sos un bot uruguayo.
- Longitud: Sé conciso, salvo que el usuario pida una respuesta detallada.
`.trim();

function collectGroqApiKeys() {
    const keys = new Set();
    const envNames = Object.keys(process.env);
    const keyPattern = /^groq_api_key(?:\d*)?$/i;

    for (const name of envNames) {
        if (!keyPattern.test(name)) continue;
        const value = process.env[name];
        if (value && typeof value === 'string') {
            const trimmed = value.trim();
            if (trimmed) keys.add(trimmed);
        }
    }

    return Array.from(keys);
}

// ─── Groq API ─────────────────────────────────────────────────────────────────
async function callGroq(systemPrompt, userText) {
    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) {
        throw new Error('No hay claves Groq configuradas');
    }

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        const apiKey = apiKeys[keyIndex];
        for (let modelIndex = 0; modelIndex < MODEL_LIST.length; modelIndex++) {
            const model = MODEL_LIST[modelIndex];
            try {
                const result = await groqRequest(apiKey, model, systemPrompt, userText);
                return result;
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[ia] Groq key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
                if (keyIndex === apiKeys.length - 1 && modelIndex === MODEL_LIST.length - 1) break;
            }
        }
    }

    throw lastErr || new Error('Groq falló');
}

function groqRequest(apiKey, model, systemPrompt, userText) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userText }
            ],
            max_tokens: 600,
            temperature: 0.7,
            top_p: 0.95
        });

        const options = {
            hostname: 'api.groq.com',
            path: '/openai/v1/chat/completions',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'Content-Length': Buffer.byteLength(body)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    const content = parsed.choices?.[0]?.message?.content?.trim();
                    if (!content) return reject(new Error('Respuesta vacía de Groq'));
                    resolve(content);
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT, () => {
            req.destroy();
            reject(new Error('Timeout Groq'));
        });

        req.write(body);
        req.end();
    });
}

// ─── Delirius APIs (fallback) ──────────────────────────────────────────────────
function httpGet(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { timeout: TIMEOUT }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch { reject(new Error('Error parseando respuesta')); }
            });
        });
        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

async function deliriusGptPrompt(systemPrompt, userText) {
    const url = `https://api.delirius.online/ia/gptprompt?text=${encodeURIComponent(userText)}&prompt=${encodeURIComponent(systemPrompt)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gptprompt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gptprompt: sin contenido');
    return text.trim();
}

async function deliriusGemini(systemPrompt, userText) {
    const query = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/gemini?query=${encodeURIComponent(query)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gemini: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gemini: sin contenido');
    return text.trim();
}

async function deliriusChatgpt(systemPrompt, userText) {
    const q = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/chatgpt?q=${encodeURIComponent(q)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius chatgpt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius chatgpt: sin contenido');
    return text.trim();
}

// ─── Llamada principal: TODAS las IAs en paralelo, gana la más rápida ─────────
async function callIA(systemPrompt, userText) {
    // Si el circuit breaker detecta la red caída, no intentamos nada
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) {
        console.warn('[ia] Red caída (circuit breaker activo) — omitiendo peticiones IA.');
        throw new Error('_SILENT_FAIL_');
    }

    const attempts = [
        callGroq(systemPrompt, userText),
        deliriusGptPrompt(systemPrompt, userText),
        deliriusGemini(systemPrompt, userText),
        deliriusChatgpt(systemPrompt, userText)
    ];

    const names = ['Groq', 'Delirius-gptprompt', 'Delirius-gemini', 'Delirius-chatgpt'];
    const labeled = attempts.map((p, i) => p.catch(e => {
        console.warn(`[ia] ${names[i]} falló:`, e.message);
        throw e;
    }));

    try {
        return await Promise.any(labeled);
    } catch (aggregateErr) {
        const details = Array.isArray(aggregateErr?.errors)
            ? aggregateErr.errors.map(e => e.message).join(' | ')
            : aggregateErr.message;
        console.error('[ia] Todas las IAs fallaron:', details);
        throw new Error('_SILENT_FAIL_');
    }
}

// ─── Handler principal ────────────────────────────────────────────────────────
let handler = async (message, { text }) => {
    if (!text || !text.trim()) {
        return await message.reply(
            '⚠️ Uso correcto:\n.ia pregunta o mensaje\n\n' +
            'Ejemplo:\n.ia ¿quién te creó?'
        );
    }

    try {
        await message.reply('⏳ _Pensando..._');
    } catch (_) {}

    let response;
    try {
        response = await callIA(SYSTEM_PROMPT, text.trim());
    } catch (e) {
        console.error('[ia] Todas las IAs fallaron:', e.message);
        return await message.reply('⚠️ No pude obtener respuesta en este momento. Intentá de nuevo más tarde.');
    }

    return await message.reply(response);
};

handler.help = ['ia <pregunta>'];
handler.tags = ['ia', 'fun'];
handler.command = /^ia$/i;
handler.callIA = callIA;

module.exports = handler;