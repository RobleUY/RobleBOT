const axios = require('axios');
const FormData = require('form-data');
const { Sticker } = require('wa-sticker-formatter');

const API_KEY = "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";
const TIMEOUT = 20000;
const MODEL = 'llama-3.3-70b-versatile';
const ROBLE_API = 'https://www.robleuy.site/robleapi';
const SANKA_API = 'https://www.sankavollerei.com/search/google?apikey=planaai';
const PINTEREST_API = 'https://www.robleuy.site/robleapi/buscador/pinterest';

// Memoria caché para guardar las zonas horarias de la API al arrancar
let cacheTimezones = [];

// Función para cargar las zonas horarias al inicio
async function cargarTimezones() {
    try {
        const res = await axios.get(`${ROBLE_API}/tools/datetime/timezones`, { timeout: TIMEOUT });
        if (res.data?.ok && Array.isArray(res.data.timezones)) {
            cacheTimezones = res.data.timezones;
            console.log(`[IA] ${cacheTimezones.length} zonas horarias cargadas con éxito.`);
        }
    } catch (e) {
        console.error('[IA ERROR] No se pudieron cargar las zonas horarias:', e.message);
    }
}
// Ejecutar la carga inicial
cargarTimezones();

// ============================================================
// STICKER BRAT (usa RobleAPI igual que brat.js)
// ============================================================

async function enviarStickerBrat(sock, jid, text, quotedMsg) {
    try {
        const apiUrl = `https://www.robleuy.site/robleapi/imagen/brat?q=${encodeURIComponent(text)}`;
        const res = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: TIMEOUT });
        const imageBuffer = Buffer.from(res.data);

        const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
        const sticker = new Sticker(imageBuffer, {
            pack: 'RobleBOT',
            author: authorText,
            type: 'default',
            quality: 100
        });
        const stickerBuffer = await sticker.toBuffer();
        await sock.sendMessage(jid, { sticker: stickerBuffer }, quotedMsg ? { quoted: quotedMsg } : {});
        return true;
    } catch (err) {
        console.error('[IA BRAT ERROR]', err.message);
        return false;
    }
}

// ============================================================
// ANÁLISIS VISUAL DE IMÁGENES (ImgBB + Delirius Visual API)
// ============================================================

async function analizarImagen(imgBuffer, query) {
    try {
        // 1. Subir imagen a ImgBB para obtener URL pública
        const form = new FormData();
        form.append('image', imgBuffer, { filename: 'image.jpg' });
        const uploadRes = await axios.post(
            'https://api.imgbb.com/1/upload?key=4ce3fe016a9c978bf9c8cba581c22bd3',
            form,
            { headers: form.getHeaders(), timeout: TIMEOUT }
        );
        const imageUrl = uploadRes.data?.data?.url;
        if (!imageUrl) return null;

        // 2. Consultar la API visual con la URL y la pregunta del usuario
        const apiUrl = `https://api.delirius.store/ia/visual?image=${encodeURIComponent(imageUrl)}&query=${encodeURIComponent(query)}`;
        const { data } = await axios.get(apiUrl, { timeout: TIMEOUT });

        if (data?.status && data?.data?.result) {
            return data.data.result;
        }
        return null;
    } catch (err) {
        console.error('[IA VISUAL ERROR]', err.message);
        return null;
    }
}

// ============================================================
// HERRAMIENTAS DISPONIBLES
// ============================================================
const TOOLS = {
    async buscarWeb(query) {
        try {
            const res = await axios.get(`${SANKA_API}&q=${encodeURIComponent(query)}`, { timeout: TIMEOUT });
            if (!res.data?.result?.length) return null;
            return res.data.result
                .slice(0, 4)
                .map(r => `• ${r.title}\n  ${r.description}`)
                .join('\n');
        } catch { return null; }
    },

    async traducir(text, language) {
        try {
            const res = await axios.get(`${ROBLE_API}/tools/translate?text=${encodeURIComponent(text)}&language=${language}`, { timeout: TIMEOUT });
            return res.data?.ok ? res.data.text : null;
        } catch { return null; }
    },

    async fechaHora(timezone = 'America/Montevideo') {
        try {
            const res = await axios.get(`${ROBLE_API}/tools/datetime?timezone=${encodeURIComponent(timezone)}`, { timeout: TIMEOUT });
            if (!res.data?.ok) return null;
            const { fecha, hora, pais } = res.data;
            return `PAÍS_SOLICITADO: ${pais}\nZONA_HORARIA: ${timezone}\nHORA_EXACTA: ${hora.formato}\nFECHA_EXACTA: ${fecha.formato}`;
        } catch { return null; }
    },

    async clima(city) {
        try {
            const res = await axios.get(`${ROBLE_API}/tools/clima?city=${encodeURIComponent(city)}`, { timeout: TIMEOUT });
            if (!res.data?.ok) return null;
            const { lugar, ahora, pronostico } = res.data;
            const hoy = pronostico?.[0];
            return `📍 ${lugar.ciudad}, ${lugar.region}, ${lugar.pais}
🌡️ ${ahora.temp_C}°C (sensación ${ahora.sensacion_C}°C)
☁️ ${ahora.descripcion}
💧 Humedad: ${ahora.humedad}% | 💨 Viento: ${ahora.viento_kmh} km/h ${ahora.dir_viento}
👁️ Visibilidad: ${ahora.visibilidad_km} km | 🌊 Presión: ${ahora.presion_hPa} hPa
📅 Hoy: máx ${hoy?.max_C}°C / mín ${hoy?.min_C}°C — ${hoy?.descripcion}`;
        } catch { return null; }
    },

    async frase() {
        try {
            const res = await axios.get(`${ROBLE_API}/random/quotes`, { timeout: TIMEOUT });
            return res.data?.ok ? `"${res.data.quote}" — ${res.data.author}` : null;
        } catch { return null; }
    },

    async buscarImagenPinterest(query) {
        try {
            const res = await axios.get(`${PINTEREST_API}?q=${encodeURIComponent(query)}`, { timeout: TIMEOUT });
            if (!res.data?.ok || !Array.isArray(res.data.images) || res.data.images.length === 0) return null;
            const imgs = res.data.images;
            const random = imgs[Math.floor(Math.random() * imgs.length)];
            return random.large || random.small || null;
        } catch { return null; }
    }
};

// ============================================================
// DETECTAR QUÉ HERRAMIENTAS NECESITA EL MENSAJE
// ============================================================
function detectarHerramientas(text) {
    const t = text.toLowerCase();
    const herramientas = [];

    if (/clima|tiempo|lluvi|temperatura|calor|frio|frío|pronostico|pronóstico|nublado|sol|viento/.test(t))
        herramientas.push('clima');

    if (/fecha|hora|día|dia|hoy|ahora|qué día|que dia|qué hora|que hora|timezone|zona horaria/.test(t))
        herramientas.push('fechaHora');

    if (/tradu|translate|en inglés|en ingles|en español|en frances|en francés|en alemán|en aleman|en portugués|en portugues|en ruso|en chino|en japonés|en japones/.test(t))
        herramientas.push('traducir');

    if (/busca|search|qué es|que es|cómo|como|quién|quien|cuál|cual|explica|define|información|informacion|wikipedia|noticia|saber sobre/.test(t))
        herramientas.push('buscarWeb');

    if (/frase|motivacion|motivación|cita|quote|inspiracion|inspiración/.test(t))
        herramientas.push('frase');

    if (/imagen|foto|picture|pic|imágen|fotografia|fotografía|muéstrame|muestrame|quiero ver|manda una|envía una|envia una|busca una imagen|descarga una imagen|descarga una foto/.test(t))
        herramientas.push('imagen');

    if (/brat|sticker brat|hazme un brat|crea un brat|sticker de brat/.test(t))
        herramientas.push('brat');

    return herramientas;
}

// ============================================================
// EXTRAER PARÁMETROS DEL TEXTO
// ============================================================
function extraerParams(text) {
    const t = text.toLowerCase();

    // Ciudad para clima
    let ciudad = null;
    const matchCiudad = text.match(/clima (?:en|de|para)?\s*([A-ZÁÉÍÓÚÑa-záéíóúñ\s]+?)(?:\?|$|,)/i);
    if (matchCiudad) ciudad = matchCiudad[1].trim();
    else if (/clima|tiempo/.test(t)) ciudad = 'Montevideo Uruguay';

    // Idioma para traducción
    const IDIOMAS = { inglés:'en', ingles:'en', español:'es', francés:'fr', frances:'fr', alemán:'de', aleman:'de', portugués:'pt', portugues:'pt', ruso:'ru', chino:'zh', japonés:'ja', japones:'ja', italiano:'it', árabe:'ar', arabe:'ar', coreano:'ko' };
    let idioma = 'en';
    for (const [nombre, codigo] of Object.entries(IDIOMAS)) {
        if (t.includes(nombre)) { idioma = codigo; break; }
    }

    let textoTraducir = text.replace(/tradu[a-z]* al? \w+/i, '').replace(/tradu[a-z]*/i, '').trim();

    // Búsqueda de Timezone dinámico
    let timezone = 'America/Montevideo'; 
    if (cacheTimezones.length > 0) {
        const normalizar = (str) => str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        const textoNormalizado = normalizar(t);

        const coincidencia = cacheTimezones.find(item => {
            const paisNorm = normalizar(item.pais);
            const tzNorm = normalizar(item.tz);
            return textoNormalizado.includes(paisNorm) || textoNormalizado.includes(tzNorm.split('/')[1] || '');
        });

        if (coincidencia) {
            timezone = coincidencia.tz;
        }
    }

    // Query para búsqueda de imagen en Pinterest
    let queryImagen = text
        .replace(/^(ia|ai)\s*/i, '')
        .replace(/quiero (una |ver )?(imagen|foto|picture|pic|fotografia|fotografía)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/busca (una )?(imagen|foto)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/descarga (una )?(imagen|foto)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/manda (una )?(imagen|foto)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/envía? (una )?(imagen|foto)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/muéstrame (una )?(imagen|foto)\s*(de|del|sobre|con)?\s*/i, '')
        .replace(/(imagen|foto|picture|pic)\s*(de|del|sobre|con)?\s*/i, '')
        .trim() || text;

    // Texto para sticker brat
    let textoBrat = text
        .replace(/^(ia|ai)\s*/i, '')
        .replace(/\b(dame|hazme|crea|genera|quiero|manda|enviame|envíame)\s+(un|una|el|la)?\s*/i, '')
        .replace(/sticker\s+brat\s*(que diga|con|de|:)?\s*/i, '')
        .replace(/brat\s*(que diga|con|de|:)?\s*/i, '')
        .trim() || text;

    return { ciudad, idioma, textoTraducir, timezone, queryImagen, textoBrat };
}

// ============================================================
// FORMATEAR RESPUESTA PARA WHATSAPP
// ============================================================
function formatearParaWhatsApp(texto) {
    if (!texto) return '';
    return texto
        .replace(/\r\n/g, '\n')
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\*{1,3}([^*\n]+)\*{1,3}/g, '$1')
        .replace(/_{1,2}([^_\n]+)_{1,2}/g, '$1')
        .replace(/~~([^~\n]+)~~/g, '$1')
        .replace(/^[ \t]*[\*\-]\s+/gm, '• ')
        .replace(/^[-=]{3,}$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// ============================================================
// LLAMAR A GROQ CON CONTEXTO DE HERRAMIENTAS
// ============================================================
async function llamarGroq(userText, contexto = '') {
    // Restricciones severas en el system prompt para evitar rodeos matemáticos o comparativas con Uruguay
    const systemPrompt = `Eres RobleBOT, un asistente de WhatsApp creado por RobleUY. Responde en español de forma natural, directa y extremadamente concisa.
REGLA CRUCIAL PARA FECHA Y HORA: Si el usuario te pregunta la hora o fecha de un país, limítate a responder exactamente eso utilizando los datos del contexto provisto. NO menciones otros países, NO hagas comparaciones horarias, NO expliques la diferencia horaria ni muestres cálculos matemáticos. Da la respuesta en una sola línea corta y limpia (Ejemplo: "Son las 11:55 en Colombia.").
${contexto ? `\nContexto real actual:\n${contexto}` : ''}`;

    const res = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
            model: MODEL,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userText }
            ],
            temperature: 0.1, // Temperatura baja al mínimo para evitar que la IA "delire" o invente explicaciones
            max_tokens: 200
        },
        {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            },
            timeout: TIMEOUT
        }
    );

    return res.data?.choices?.[0]?.message?.content || null;
}

// ============================================================
// HANDLER PRINCIPAL
// ============================================================
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        if (!text) return message.reply('❌ Escribe algo. Ejemplo: .ia como funciona el casino');

        if (cacheTimezones.length === 0) {
            await cargarTimezones();
        }

        const herramientas = detectarHerramientas(text);
        const params = extraerParams(text);

        // ── Análisis visual: si responde a una imagen, la analiza con IA ──
        const quoted = message.quoted ? message.quoted : null;
        const quotedMime = (quoted?.msg || quoted)?.mimetype || '';
        if (quoted && /image/.test(quotedMime)) {
            await message.reply('🔍 Analizando la imagen, puede tardar unos segundos...');
            try {
                const imgBuffer = await quoted.download();
                const query = text || '¿Qué ves en esta imagen?';
                const resultado = await analizarImagen(imgBuffer, query);
                if (resultado) {
                    return message.reply(formatearParaWhatsApp(resultado));
                } else {
                    return message.reply('❌ La IA no pudo analizar la imagen. Intentá de nuevo.');
                }
            } catch (err) {
                console.error('[IA VISUAL HANDLER ERROR]', err.message);
                return message.reply('❌ No se pudo descargar o analizar la imagen.');
            }
        }

        // ── Solicitud de imagen: buscar en Pinterest y enviar directamente ──
        if (herramientas.includes('imagen')) {
            await message.reply('🖼️ Buscando imagen en Pinterest, un momento...');
            const imageUrl = await TOOLS.buscarImagenPinterest(params.queryImagen);
            if (!imageUrl) {
                return message.reply('❌ No encontré imágenes para eso. Intentá con otro término.');
            }
            try {
                const imgRes = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: TIMEOUT });
                const imgBuffer = Buffer.from(imgRes.data, 'binary');
                await sock.sendMessage(message.from, {
                    image: imgBuffer,
                    caption: `🖼️ Aquí tu imagen de: *${params.queryImagen}*`
                }, { quoted: message._baileyMessage });
            } catch {
                return message.reply(`❌ Encontré la imagen pero no pude descargarla. Intentá de nuevo.`);
            }
            return;
        }

        // ── Sticker brat ──
        if (herramientas.includes('brat')) {
            if (!params.textoBrat) {
                return message.reply('❌ Escribí el texto para el sticker brat. Ejemplo: .ia brat i am so brat');
            }
            await message.reply('🟢 Generando sticker brat, un momento...');
            const ok = await enviarStickerBrat(sock, message.from, params.textoBrat, message._baileyMessage);
            if (!ok) return message.reply('❌ No se pudo crear el sticker brat. Intentá de nuevo.');
            return;
        }

        // ── Resto de herramientas + Groq ──
        await message.reply('🤖 Pensando...');

        const contextos = [];
        await Promise.all(herramientas.map(async (h) => {
            let resultado = null;

            if (h === 'buscarWeb')  resultado = await TOOLS.buscarWeb(text);
            if (h === 'clima')      resultado = await TOOLS.clima(params.ciudad);
            if (h === 'fechaHora')  resultado = await TOOLS.fechaHora(params.timezone);
            if (h === 'traducir')   resultado = await TOOLS.traducir(params.textoTraducir, params.idioma);
            if (h === 'frase')      resultado = await TOOLS.frase();

            if (resultado) {
                const labels = {
                    buscarWeb:  'Resultados Web',
                    clima:      'Clima',
                    fechaHora:  'Datos de Fecha y Hora',
                    traducir:   'Traducción',
                    frase:      'Frase',
                };
                contextos.push(`[${labels[h]}]\n${resultado}`);
            }
        }));

        const contextoFinal = contextos.join('\n\n');
        const respuesta = await llamarGroq(text, contextoFinal);

        return message.reply(formatearParaWhatsApp(respuesta) || '🤔 No obtuve respuesta.');

    } catch (err) {
        const apiErr = err.response?.data?.error;
        console.error('[IA ERROR]', apiErr || err.message);
        return message.reply('❌ Error con la IA. Intentá de nuevo.');
    }
};

handler.help = ['ia <texto>', 'ai <texto>'];
handler.tags = ['ai'];
handler.command = /^(ia|ai)$/i;

module.exports = handler;