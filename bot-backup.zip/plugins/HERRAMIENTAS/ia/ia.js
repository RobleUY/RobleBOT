const axios = require('axios')
const fs = require('fs')
const path = require('path')

// ⚠️ TU API KEY
const API_KEY = "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"

const TIMEOUT = 15000
const MAX_MESSAGES = 100

// 📁 Carpeta de chats
const CHAT_DIR = path.join(__dirname, '../CHATS-CON-IA')

// crear carpeta si no existe
if (!fs.existsSync(CHAT_DIR)) {
    fs.mkdirSync(CHAT_DIR)
}

// 🧠 CONTEXTO desde archivo externo
const CONTEXT_FILE = path.join(__dirname, 'IA-CONTEXTO.md')
let SYSTEM_PROMPT = 'Eres RobleBOT, un asistente de WhatsApp creado por RobleUY.'
if (fs.existsSync(CONTEXT_FILE)) {
    const raw = fs.readFileSync(CONTEXT_FILE, 'utf-8')
    SYSTEM_PROMPT = raw
        .replace(/^#+\s+/gm, '')
        .replace(/^\s*[-*]\s+/gm, '')
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

// 📄 obtener archivo del usuario
function getUserFile(user) {
    return path.join(CHAT_DIR, `${user}.txt`)
}

// 📥 leer historial
function getChatHistory(user) {
    const file = getUserFile(user)

    if (!fs.existsSync(file)) return []

    const data = fs.readFileSync(file, 'utf-8')
    return data.split('\n').filter(Boolean)
}

// 💾 guardar historial (máx 50)
function saveMessage(user, role, content) {
    const file = getUserFile(user)

    let history = getChatHistory(user)

    history.push(`${role}: ${content}`)

    // limitar a 50
    if (history.length > MAX_MESSAGES) {
        history = history.slice(-MAX_MESSAGES)
    }

    fs.writeFileSync(file, history.join('\n'))
}

// 🧠 convertir historial a formato IA
function buildMessages(history, userMessage) {
    const messages = [
        { role: "system", content: SYSTEM_PROMPT }
    ]

    for (const line of history) {
        if (line.startsWith('user:')) {
            messages.push({
                role: "user",
                content: line.replace('user: ', '')
            })
        } else if (line.startsWith('bot:')) {
            messages.push({
                role: "assistant",
                content: line.replace('bot: ', '')
            })
        }
    }

    // mensaje actual
    messages.push({
        role: "user",
        content: userMessage
    })

    return messages
}

function formatearParaWhatsApp(texto) {
    if (!texto) return ''

    return texto
        .replace(/\r\n/g, '\n')
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/^\s*#{1,6}\s*/gm, '')
        // Quitar negrita/cursiva combinada y sola — sin excepción
        .replace(/\*{1,3}([^*\n]+)\*{1,3}/g, '$1')
        .replace(/_{1,2}([^_\n]+)_{1,2}/g, '$1')
        .replace(/~~([^~\n]+)~~/g, '$1')
        .replace(/^[ \t]*[\*\-]\s+/gm, '• ')
        .replace(/^[-=]{3,}$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

async function askGroq(messages) {
    try {
        const res = await axios.post(
            "https://api.groq.com/openai/v1/chat/completions",
            {
                model: "llama-3.1-8b-instant",
                messages: messages,
                temperature: 0.7,
                max_tokens: 300
            },
            {
                headers: {
                    "Authorization": `Bearer ${API_KEY}`,
                    "Content-Type": "application/json"
                },
                timeout: TIMEOUT
            }
        )

        return res.data?.choices?.[0]?.message?.content

    } catch (e) {
        throw new Error(e.response?.data?.error?.message || e.message)
    }
}

// 🔄 Función compartida para procesar mensajes de IA
async function procesarMensajeIA(message, text) {
    try {
        const user = message.sender.replace(/[^0-9]/g, '') // número limpio

        await message.reply('🤖 Pensando...')

        // 📥 historial
        const history = getChatHistory(user)

        // 🧠 construir mensajes
        const messages = buildMessages(history, text)

        // 🤖 IA
        const respuesta = await askGroq(messages)

        const limpio = formatearParaWhatsApp(respuesta)

        // 💾 guardar
        saveMessage(user, 'user', text)
        saveMessage(user, 'bot', limpio)

        return message.reply(limpio)

    } catch (err) {
        console.error('[IA ERROR]', err?.message || err)
        return message.reply('❌ Error con la IA')
    }
}

// 🎯 Handler principal del comando .ia
let handler = async (message, { text, usedPrefix, command }) => {
    try {
        if (!text) {
            return message.reply(`❌ Escribe algo`)
        }

        return await procesarMensajeIA(message, text)

    } catch (err) {
        console.error('[IA ERROR]', err?.message || err)
        return message.reply('❌ Error con la IA')
    }
}

// 🆕 Handler para detectar respuestas automáticas
async function textReplyHandler(message) {
    try {
        console.log('\x1b[36m[IA REPLY] Verificando mensaje...\x1b[0m')

        // Detectar si es una respuesta/reply
        let isReply = false
        let quotedMsg = null

        if (message.hasQuotedMsg === true || message._data?.quotedMsg) {
            isReply = true
            quotedMsg = message._data?.quotedMsg
        } else if (typeof message.getQuotedMessage === 'function') {
            try {
                quotedMsg = await message.getQuotedMessage()
                if (quotedMsg) isReply = true
            } catch (e) {
                // Ignorar error
            }
        }

        // Si no es una respuesta, ignorar
        if (!isReply) {
            return
        }

        console.log('\x1b[36m[IA REPLY] Es una respuesta, verificando si es del bot...\x1b[0m')

        // Verificar si el mensaje citado es del bot
        const botNumber = (global.conn?.user?.jid || global.conn?.user?.id || '').split('@')[0]
        const quotedFrom = (quotedMsg?.from || quotedMsg?.participant || quotedMsg?.key?.participant || '').split('@')[0]
        
        console.log('\x1b[36m[IA REPLY] Bot:', botNumber, '| Quoted from:', quotedFrom, '\x1b[0m')

        // Si no es del bot, ignorar
        if (!botNumber || quotedFrom !== botNumber) {
            console.log('\x1b[36m[IA REPLY] No es del bot, ignorando\x1b[0m')
            return
        }

        // Verificar que el mensaje citado contenga texto (probablemente de la IA)
        const quotedBody = quotedMsg?.body || quotedMsg?.message?.conversation || ''
        
        // Ignorar si el mensaje citado está vacío o es muy corto (probablemente no es de la IA)
        if (!quotedBody || quotedBody.length < 10) {
            console.log('\x1b[36m[IA REPLY] Mensaje citado muy corto, ignorando\x1b[0m')
            return
        }

        // Obtener el texto del usuario
        const textoUsuario = (message.body || '').trim()
        
        if (!textoUsuario) {
            console.log('\x1b[36m[IA REPLY] Mensaje vacío, ignorando\x1b[0m')
            return
        }

        // Ignorar si el mensaje empieza con un comando (punto)
        if (textoUsuario.startsWith('.') || textoUsuario.startsWith('/')) {
            console.log('\x1b[36m[IA REPLY] Es un comando, ignorando\x1b[0m')
            return
        }

        console.log('\x1b[36m[IA REPLY] ✅ Procesando respuesta automática:', textoUsuario, '\x1b[0m')

        // Procesar con la IA
        await procesarMensajeIA(message, textoUsuario)

    } catch (error) {
        console.error('\x1b[31m[IA REPLY ERROR]', error, '\x1b[0m')
    }
}

handler.help = ['ia <texto>']
handler.tags = ['ai']
handler.command = /^(ia|ai)$/i

module.exports = handler
module.exports.textReplyHandler = textReplyHandler