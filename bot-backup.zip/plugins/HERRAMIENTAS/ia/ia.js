const axios = require('axios')

const API_KEY = "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"
const TIMEOUT = 15000
const MODEL = 'llama-3.3-70b-versatile'

const SYSTEM_PROMPT = 'Eres RobleBOT, un asistente de WhatsApp creado por RobleUY. Responde en español de forma natural y útil.'

function formatearParaWhatsApp(texto) {
    if (!texto) return ''
    return texto
        .replace(/\r\n/g, '\n')
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\*{1,3}([^*\n]+)\*{1,3}/g, '$1')
        .replace(/_{1,2}([^_\n]+)_{1,2}/g, '$1')
        .replace(/~~([^~\n]+)~~/g, '$1')
        .replace(/^[ \t]*[\*\-]\s+/gm, '• ')
        .replace(/^[-=]{3,}$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

let handler = async (message, { text }) => {
    try {
        if (!text) {
            return message.reply('❌ Escribe algo. Ejemplo: .ia como funciona el casino')
        }

        await message.reply('🤖 Pensando...')

        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    { role: 'system', content: SYSTEM_PROMPT },
                    { role: 'user', content: text }
                ],
                temperature: 0.7,
                max_tokens: 600
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        )

        const respuesta = res.data?.choices?.[0]?.message?.content
        return message.reply(formatearParaWhatsApp(respuesta) || '🤔 No obtuve respuesta.')

    } catch (err) {
        const apiErr = err.response?.data?.error
        console.error('[IA ERROR]', apiErr || err.message)
        return message.reply('❌ Error con la IA. Intentá de nuevo.')
    }
}

handler.help = ['ia <texto>']
handler.tags = ['ai']
handler.command = /^(ia|ai)$/i

module.exports = handler
