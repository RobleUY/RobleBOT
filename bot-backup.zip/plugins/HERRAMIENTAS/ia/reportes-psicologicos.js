const fs = require('fs')
const path = require('path')
const axios = require('axios')

const API_KEY = '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'
const MODEL = 'llama-3.3-70b-versatile'
const TIMEOUT = 30000
const MAX_CHARS = 8000

const CHAT_DIR = path.join(__dirname, '../../../data/CHATS-USUARIOS')

/**
 * Lee hasta MAX_CHARS caracteres del historial de un usuario en un grupo,
 * tomando los mensajes más recientes (desde el final del archivo).
 */
function leerChatReciente(numero, groupId) {
    const filePath = path.join(CHAT_DIR, groupId, `${numero}.txt`)
    if (!fs.existsSync(filePath)) return null

    const contenido = fs.readFileSync(filePath, 'utf-8').trim()
    if (!contenido) return null

    // Tomar desde el final para que sea lo más actualizado posible
    if (Buffer.byteLength(contenido, 'utf-8') <= MAX_CHARS) return contenido

    // Recortar desde el final
    const bytes = Buffer.from(contenido, 'utf-8')
    const recortado = bytes.slice(bytes.length - MAX_CHARS).toString('utf-8')
    // Eliminar primera línea incompleta
    const primerSalto = recortado.indexOf('\n')
    return primerSalto !== -1 ? recortado.slice(primerSalto + 1) : recortado
}

let handler = async (message, { args, conn }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.')
        }

        const groupId = message.from

        // Determinar el usuario objetivo
        let targetJid = null
        let targetNumero = null

        const mentioned = message.mentions?.[0]
        if (mentioned) {
            targetJid = mentioned
            targetNumero = mentioned.split('@')[0].replace(/\D/g, '')
        } else {
            targetJid = message.sender
            targetNumero = message.sender.split('@')[0].replace(/\D/g, '')
        }

        // Leer historial
        const chat = leerChatReciente(targetNumero, groupId)
        if (!chat) {
            const esPropioUsuario = !mentioned
            if (esPropioUsuario) {
                return message.reply('❌ No tengo mensajes tuyos guardados en este grupo todavía.')
            } else {
                return message.reply(`❌ No tengo mensajes guardados de @${targetNumero} en este grupo.`, { mentions: [targetJid] })
            }
        }

        await message.reply('🧠 Analizando perfil psicológico...')

        const prompt = `A continuación tienes una muestra de mensajes enviados por una persona en un grupo de WhatsApp. Basándote ÚNICAMENTE en estos mensajes, realiza un análisis psicológico detallado de la persona. Incluye: rasgos de personalidad, estilo de comunicación, posibles estados emocionales, patrones de comportamiento, y cualquier observación relevante. Sé directo, específico y fundamenta cada punto en los mensajes. No inventes información que no esté en los mensajes.

MENSAJES:
${chat}`

        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    { role: 'system', content: 'Eres un psicólogo experto en análisis de comportamiento digital. Analizas mensajes de texto para identificar rasgos de personalidad y patrones psicológicos. Responde siempre en español.' },
                    { role: 'user', content: prompt }
                ],
                temperature: 0.7,
                max_tokens: 1000
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        )

        const respuesta = res.data?.choices?.[0]?.message?.content
        if (!respuesta) return message.reply('❌ No se pudo generar el análisis.')

        const esPropioUsuario = !mentioned
        const header = esPropioUsuario
            ? `🧠 *Reporte Psicológico — Tú*\n${'─'.repeat(30)}\n`
            : `🧠 *Reporte Psicológico — @${targetNumero}*\n${'─'.repeat(30)}\n`

        const mentions = esPropioUsuario ? [] : [targetJid]
        return message.reply(header + respuesta.trim(), { mentions })

    } catch (err) {
        const apiErr = err.response?.data?.error
        console.error('[REPORTE-PSICO ERROR]', apiErr || err.message)
        return message.reply('❌ Error al generar el reporte. Intentá de nuevo.')
    }
}

handler.help = ['.rp [@usuario]', '.rs [@usuario]']
handler.tags = ['ia']
handler.command = /^(rp|rs)$/i

module.exports = handler
