const fs = require('fs')
const path = require('path')
const axios = require('axios')

const API_KEY = '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'
const MODEL = 'llama-3.3-70b-versatile'
const TIMEOUT = 30000
const MAX_CHARS = 8000

const CHAT_DIR = path.join(__dirname, '../../../data/CHATS-USUARIOS')

/**
 * Lee hasta MAX_CHARS caracteres del historial de un usuario en un grupo,
 * tomando los mensajes más recientes (desde el final del archivo).
 */
function leerChatReciente(numero, groupId) {
    const filePath = path.join(CHAT_DIR, groupId, `${numero}.txt`)
    if (!fs.existsSync(filePath)) return null

    const contenido = fs.readFileSync(filePath, 'utf-8').trim()
    if (!contenido) return null

    // Tomar desde el final para que sea lo más actualizado posible
    if (Buffer.byteLength(contenido, 'utf-8') <= MAX_CHARS) return contenido

    // Recortar desde el final
    const bytes = Buffer.from(contenido, 'utf-8')
    const recortado = bytes.slice(bytes.length - MAX_CHARS).toString('utf-8')
    // Eliminar primera línea incompleta
    const primerSalto = recortado.indexOf('\n')
    return primerSalto !== -1 ? recortado.slice(primerSalto + 1) : recortado
}

let handler = async (message, { args, conn }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.')
        }

        const groupId = message.from

        // Determinar el usuario objetivo
        let targetJid = null
        let targetNumero = null

        const mentioned = message.mentions?.[0]
        if (mentioned) {
            targetJid = mentioned
            targetNumero = mentioned.split('@')[0].replace(/\D/g, '')
        } else {
            targetJid = message.sender
            targetNumero = message.sender.split('@')[0].replace(/\D/g, '')
        }

        // Leer historial
        const chat = leerChatReciente(targetNumero, groupId)
        if (!chat) {
            const esPropioUsuario = !mentioned
            if (esPropioUsuario) {
                return message.reply('❌ No tengo mensajes tuyos guardados en este grupo todavía.')
            } else {
                return message.reply(`❌ No tengo mensajes guardados de @${targetNumero} en este grupo.`, { mentions: [targetJid] })
            }
        }

        await message.reply('🧠 Analizando...')

        const prompt = `Analiza estos mensajes de WhatsApp y da un reporte psicológico BREVE (máximo 5 puntos cortos): personalidad, forma de comunicarse, emociones, y algo destacable. Solo lo que se vea claramente en los mensajes.

MENSAJES:
${chat}`

        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    { role: 'system', content: 'Eres un psicólogo que da reportes breves y directos basados en mensajes de WhatsApp. Responde en español, máximo 5 puntos concisos, sin introducciones ni cierres.' },
                    { role: 'user', content: prompt }
                ],
                temperature: 0.7,
                max_tokens: 400
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        )

        const respuesta = res.data?.choices?.[0]?.message?.content
        if (!respuesta) return message.reply('❌ No se pudo generar el análisis.')

        const esPropioUsuario = !mentioned
        const header = esPropioUsuario
            ? `🧠 *Reporte Psicológico — Tú*\n${'─'.repeat(20)}\n`
            : `🧠 *Reporte Psicológico — @${targetNumero}*\n${'─'.repeat(20)}\n`

        const mentions = esPropioUsuario ? [] : [targetJid]
        const textoFinal = header + respuesta.trim()

        // Enviar en partes si supera el límite de WhatsApp (~65000 chars, usamos 4000 por seguridad)
        const LIMITE = 4000
        if (textoFinal.length <= LIMITE) {
            return message.reply(textoFinal, { mentions })
        }

        const partes = []
        let restante = textoFinal
        while (restante.length > 0) {
            if (restante.length <= LIMITE) {
                partes.push(restante)
                break
            }
            // Cortar en el último salto de línea antes del límite
            let corte = restante.lastIndexOf('\n', LIMITE)
            if (corte <= 0) corte = LIMITE
            partes.push(restante.slice(0, corte))
            restante = restante.slice(corte + 1)
        }

        for (let i = 0; i < partes.length; i++) {
            await message.reply(partes[i], { mentions: i === 0 ? mentions : [] })
            if (i < partes.length - 1) await new Promise(r => setTimeout(r, 500))
        }

    } catch (err) {
        const apiErr = err.response?.data?.error
        console.error('[REPORTE-PSICO ERROR]', apiErr || err.message)
        return message.reply('❌ Error al generar el reporte. Intentá de nuevo.')
    }
}

handler.help = ['.rp [@usuario]', '.rs [@usuario]']
handler.tags = ['ia']
handler.command = /^(rp|rs)$/i

module.exports = handler
