'use strict';

/**
 * Comando: .humillar / .roast
 * Humilla de forma directa e hiriente basándose en el historial real de mensajes del chat.
 * Uso: .humillar @usuario o .humillar (para auto-humillarse)
 */

const { getUserDb } = require('../../../chatLogger');
const axios = require('axios');

const API_KEY = "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";
const TIMEOUT = 25000;
const MODEL = 'llama-3.3-70b-versatile';
const MAX_CHARS = 7000;

// Prompt ultra directo, frío e hiriente. Sin introducciones ni rodeos.
const SYSTEM_PROMPT = 'Eres RobleBOT y eres Latino. Destruye al usuario basándote en su historial de mensajes. Sé sumamente DIRECTO, HIRIENTE, FRÍO y CRUEL. No uses introducciones ni textos largos. Responde en MÁXIMO 2 o 3 oraciones letales. Ataca sus inseguridades, faltas de ortografía o tonterías directamente al hueso. Usa jergas latinoamericanas si es necesario.';

function formatearParaWhatsApp(texto) {
    if (!texto) return ''
    return texto
        .replace(/\r\n/g, '\n')
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\*{1,3}([^*\n]+)\*{1,3}/g, '$1')
        .replace(/_{1,2}([^_\n]+)_{1,2}/g, '$1')
        .replace(/~~([^~\n]+)~~/g, '$1')
        .replace(/^[ \t]*[\*\-]\s+/gm, '• ')
        .replace(/^[-=]{3,}$/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

let handler = async (message, { text }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return;

        const senderNumber = senderJid.split('@')[0].split(':')[0];

        let targetJid = null;
        let extraText = text ? text.trim() : '';
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = extraText.replace(/@\d+/g, "").trim();
        }

        if (!targetJid) {
            targetJid = senderJid;
        }

        const targetNumber = targetJid.split('@')[0].split(':')[0];
        const isSelf = targetJid === senderJid;

        // Obtener historial de la base de datos
        const db = getUserDb(targetNumber);
        const messages = db.prepare(`
            SELECT content, quoted_content, transcription 
            FROM messages 
            WHERE group_jid = ? 
            ORDER BY timestamp DESC 
            LIMIT 150
        `).all(message.from);

        let context = '';
        let charCount = 0;

        if (messages && messages.length > 0) {
            for (const msg of messages.reverse()) {
                let msgText = '';
                if (msg.transcription) {
                    msgText += msg.transcription;
                } else if (msg.content) {
                    msgText += msg.content;
                }

                if (msgText.trim()) {
                    const line = `- ${msgText}\n`;
                    if (charCount + line.length > MAX_CHARS) break;
                    context += line;
                    charCount += line.length;
                }
            }
        }

        let promptIA = '';
        if (context.trim()) {
            promptIA = `Historial de mensajes de @${targetNumber}:\n\n${context}\nUsa esto para humillarlo de forma directa en 2 frases letales. ${extraText ? `Contexto extra: ${extraText}` : ''}`;
        } else {
            promptIA = `Destruye a @${targetNumber} en dos frases por ser un fantasma que ni escribe en el grupo. ${extraText ? `Contexto extra: ${extraText}` : ''}`;
        }

        // Petición directa sin avisos previos
        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    { role: 'system', content: SYSTEM_PROMPT },
                    { role: 'user', content: promptIA }
                ],
                temperature: 0.88, // Más alto para que sea más afilado y espontáneo
                max_tokens: 150 // Reducido drásticamente para obligar a que sea corto y al grano
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        );

        const respuesta = res.data?.choices?.[0]?.message?.content;
        if (!respuesta) return;

        let mentions = [senderJid];
        if (!isSelf) mentions.push(targetJid);

        return await message.reply(formatearParaWhatsApp(respuesta), { mentions: mentions });

    } catch (error) {
        console.error('[HUMILLAR ERROR]:', error);
        return message.reply('❌ Salió mal el ataque.');
    }
};

handler.help = ['humillar'];
handler.tags = ['fun'];
handler.command = /^(humillar|roast)$/i;

module.exports = handler;