const axios = require('axios')
const fs = require('fs')
const path = require('path')

const API_KEY = "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"
const CHAT_USUARIOS_DIR = path.join(__dirname, '../../../CHATS-USUARIOS')
const MAX_CHARS_POR_USUARIO = 12000 // leer más contexto por usuario
const DELAY_ENTRE_USUARIOS = 4000 // 4s entre cada llamada

// Análisis en curso por grupo para evitar duplicados
const analisisEnCurso = new Map()

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

function leerMensajesLimpios(numero, groupId) {
    const file = path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
    if (!fs.existsSync(file)) return null
    const lineas = fs.readFileSync(file, 'utf-8').trim().split('\n').filter(Boolean)
    if (!lineas.length) return null

    // Limpiar timestamps igual que reporte-psicologico
    let contenido = lineas
        .map(l => l.replace(/^\[.*?\]\s*/, '').trim())
        .filter(m => m.length > 2)
        .join('\n')

    if (!contenido) return null

    // Tomar los últimos MAX_CHARS_POR_USUARIO chars (los más recientes)
    if (contenido.length > MAX_CHARS_POR_USUARIO) {
        contenido = contenido.slice(-MAX_CHARS_POR_USUARIO)
    }

    return contenido
}

function buildLidMap(participants) {
    const map = {}
    for (const p of participants) {
        const id = p.id || ''
        const lid = p.lid || ''
        if (lid) map[lid] = id
        if (id) map[id] = id
    }
    return map
}

function resolveJid(jid, lidMap) {
    const resolved = lidMap[jid] || jid
    return {
        jid: resolved,
        numero: resolved.split('@')[0].replace(/\D/g, '')
    }
}

async function groqConRetry(systemPrompt, userPrompt, maxTokens = 300, reintentos = 4) {
    for (let intento = 1; intento <= reintentos; intento++) {
        try {
            const res = await axios.post(
                "https://api.groq.com/openai/v1/chat/completions",
                {
                    model: "llama-3.1-8b-instant",
                    messages: [
                        { role: "system", content: systemPrompt },
                        { role: "user", content: userPrompt }
                    ],
                    temperature: 0.7,
                    max_tokens: maxTokens
                },
                {
                    headers: {
                        "Authorization": `Bearer ${API_KEY}`,
                        "Content-Type": "application/json"
                    },
                    timeout: 30000
                }
            )
            return res.data?.choices?.[0]?.message?.content?.trim()
        } catch (err) {
            const status = err?.response?.status
            if (status === 429 && intento < reintentos) {
                const espera = 10000 * intento
                console.log(`[RSASK] Rate limit 429, esperando ${espera / 1000}s (intento ${intento}/${reintentos})`)
                await sleep(espera)
            } else {
                throw err
            }
        }
    }
}

async function resumirUsuario(historial) {
    return await groqConRetry(
        "Eres un psicólogo experto en análisis de comportamiento digital. Responde en español. Algunos mensajes tienen el formato: (respondiendo a NUMERO: \"mensaje original\") respuesta — indica que la persona respondió a alguien, úsalo como contexto.",
        `Analiza estos mensajes de WhatsApp y describe en 2-3 oraciones: personalidad, estado emocional y rasgos destacados. Solo el análisis, sin presentación.\n\nMensajes:\n${historial}`,
        150
    )
}

async function compararYResponder(perfiles, pregunta) {
    let contexto = "Perfiles psicológicos de los usuarios:\n\n"
    for (const p of perfiles) {
        contexto += `USUARIO ${p.id}: ${p.resumen}\n\n`
    }
    return await groqConRetry(
        "Eres un analista de grupos de WhatsApp con conocimiento psicológico. Responde en español, directo y conciso. Identifica usuarios como USUARIO X.",
        `${contexto}\nPregunta: ${pregunta}\n\nResponde en máximo 150 palabras basándote en los perfiles.`,
        350
    )
}

function procesarRespuesta(respuestaIA, perfiles) {
    let texto = respuestaIA
    const mentions = []
    const regex = /USUARIO\s+(\d+)/gi
    const matches = [...new Set([...texto.matchAll(regex)].map(m => m[0]))]
    for (const match of matches) {
        const num = parseInt(match.match(/\d+/)[0]) - 1
        if (num >= 0 && num < perfiles.length) {
            const u = perfiles[num]
            const numero = u.jid.split('@')[0]
            texto = texto.replaceAll(match, `@${numero}`)
            if (!mentions.includes(u.jid)) mentions.push(u.jid)
        }
    }
    return { texto, mentions }
}

function formatearTiempo(segundos) {
    if (segundos < 60) return `~${segundos} segundos`
    const min = Math.floor(segundos / 60)
    const seg = segundos % 60
    return seg > 0 ? `~${min} min ${seg} seg` : `~${min} minutos`
}

let handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup)
            return message.reply('❌ Este comando solo funciona en grupos.')

        if (!text || text.trim().length < 3)
            return message.reply('❓ Escribe una pregunta. Ej: `.rsask quién es el más amoroso?`')

        const chatId = message.from

        if (analisisEnCurso.has(chatId)) {
            const enCurso = analisisEnCurso.get(chatId)
            const elapsed = Math.floor((Date.now() - enCurso.timestamp) / 1000)
            return message.reply(`⏳ Ya hay un análisis en curso (${elapsed}s transcurridos). Espera a que termine.`)
        }

        const groupMetadata = await conn.groupMetadata(chatId)
        const allParticipants = groupMetadata.participants
        const lidMap = buildLidMap(allParticipants)

        // Recopilar todos los usuarios del grupo con mensajes guardados
        const participantesData = []
        for (const p of allParticipants) {
            const { jid, numero } = resolveJid(p.id, lidMap)
            const historial = leerMensajesLimpios(numero, chatId)
            if (historial) participantesData.push({ jid, numero, historial })
        }

        if (participantesData.length === 0)
            return message.reply('❌ No hay mensajes guardados de ningún usuario del grupo.')

        if (participantesData.length < 2)
            return message.reply('❌ Se necesitan al menos 2 usuarios con mensajes guardados.')

        // Calcular tiempo estimado
        const tiempoEstimado = formatearTiempo(Math.ceil(participantesData.length * DELAY_ENTRE_USUARIOS / 1000))

        // Mensaje inicial con tiempo estimado, en respuesta al comando
        const sentMsg = await conn.sendMessage(chatId, {
            text: `🔍 *Analizando grupo...*\n❓ Solicitud: _${text}_\n📊 Usuarios con datos: *${participantesData.length}*\n⏱️ Tiempo estimado: *${tiempoEstimado}*\n\n⏳ Progreso: 0/${participantesData.length}`,
            contextInfo: {
                stanzaId: message.key.id,
                participant: message.key.participant || message.key.remoteJid,
                quotedMessage: message.message,
                remoteJid: message.key.remoteJid
            }
        })
        const msgKey = sentMsg.key

        analisisEnCurso.set(chatId, { timestamp: Date.now() })

        try {
            const perfiles = []
            const BATCH = 10 // Cuántos usuarios mostrar por "bloque" en el mensaje

            for (let i = 0; i < participantesData.length; i++) {
                const p = participantesData[i]
                const resumen = await resumirUsuario(p.historial)
                perfiles.push({ ...p, resumen, id: i + 1 })

                console.log(`[RSASK] ✅ ${i + 1}/${participantesData.length}`)

                // Calcular qué batch estamos mostrando
                const batchActual = Math.floor(i / BATCH)
                const batchInicio = batchActual * BATCH + 1
                const batchFin = Math.min((batchActual + 1) * BATCH, participantesData.length)

                // Construir líneas del batch actual
                let lineasBatch = ''
                for (let j = batchInicio - 1; j <= i; j++) {
                    const num = participantesData[j].jid.split('@')[0]
                    lineasBatch += `  ✅ @${num}\n`
                }
                // Rellenar los pendientes del batch
                for (let j = i + 1; j < batchFin; j++) {
                    const num = participantesData[j].jid.split('@')[0]
                    lineasBatch += `  ⏳ @${num}\n`
                }

                const progreso = i + 1
                const textoEdit = `🔍 *Analizando grupo...*\n❓ Solicitud: _${text}_\n📊 Usuarios con datos: *${participantesData.length}*\n⏱️ Tiempo estimado: *${tiempoEstimado}*\n\n⏳ Progreso: ${progreso}/${participantesData.length}\n\n*Bloque ${batchActual + 1}:*\n${lineasBatch.trim()}`

                await conn.sendMessage(chatId, { text: textoEdit, edit: msgKey, mentions: participantesData.slice(batchInicio - 1, batchFin).map(u => u.jid) })

                if (i < participantesData.length - 1) await sleep(DELAY_ENTRE_USUARIOS)
            }

            // Editar a "generando respuesta"
            await conn.sendMessage(chatId, {
                text: `✅ *Análisis completado* (${participantesData.length} usuarios)\n\n🧠 Generando respuesta final...`,
                edit: msgKey
            })

            await sleep(1000)
            const respuestaIA = await compararYResponder(perfiles, text)
            if (!respuestaIA) return message.reply('❌ No se pudo generar una respuesta.')

            const { texto, mentions } = procesarRespuesta(respuestaIA, perfiles)

            // Editar el mensaje de progreso a "listo"
            await conn.sendMessage(chatId, {
                text: `✅ *Análisis listo* (${participantesData.length} usuarios analizados)`,
                edit: msgKey
            })

            // Enviar resultado final con reply para que las menciones funcionen correctamente
            await message.reply(`🧠 *Análisis del grupo*\n${'─'.repeat(28)}\n\n${texto.trim()}`, { mentions })

        } finally {
            analisisEnCurso.delete(chatId)
        }

    } catch (err) {
        analisisEnCurso.delete(message.from)
        console.error('[RSASK ERROR]', err?.message || err)
        const msg = err?.response?.status === 429
            ? '❌ La IA sigue saturada. Intenta en unos minutos.'
            : '❌ Error al analizar el grupo.'
        return message.reply(msg)
    }
}

handler.help = ['rsask <pregunta>']
handler.tags = ['ai', 'herramientas']
handler.command = /^rsask$/i
handler.group = true

module.exports = handler
