'use strict';

/**
 * iauser.js
 * Comando: .iauser / .ia-user / .useria
 *
 * Usos:
 *   .iauser <mensaje>             → La IA responde al mensaje imitando tu propio perfil social en el grupo.
 *   .iauser @usuario <mensaje>    → La IA responde al mensaje imitando el estilo/perfil social de ese usuario en el grupo.
 *   .iauser <apodo> <mensaje>     → La IA responde imitando al usuario buscando por su apodo.
 *   [Respondiendo mensaje] .iauser <mensaje> → La IA responde imitando al autor del mensaje citado.
 *
 * Requisitos:
 *   - Funciona solo en grupos (isGroup = true) para leer el historial social de chatHistory.js.
 */

const axios = require('axios');
const chatHistory = require('../../../chatHistory');
const db = require('../../../database');

// ── Config IA Fallbacks (Gemini / Groq / Unified Engine) ─────────────────────
const GEMINI_HARDCODED_KEY  = process.env.GEMINI_API_KEY || process.env.gemini_api_key || "";
const GEMINI_MODEL          = 'gemini-flash-latest';
const GEMINI_URL            = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const GROQ_HARDCODED_KEY    = process.env.GROQ_API_KEY || process.env.groq_api_key || "";
const GROQ_MODEL            = 'llama-3.3-70b-versatile';
const GROQ_FALLBACK_MODEL   = 'llama-3.1-8b-instant';
const TIMEOUT               = 25000;

// Palabras comunes a ignorar al buscar por apodo para evitar falsos positivos
const STOP_WORDS = new Set([
    'hola', 'chau', 'que', 'como', 'quien', 'cuando', 'donde', 'bro',
    'si', 'no', 'por', 'para', 'con', 'sin', 'de', 'la', 'el', 'un', 'una',
    'y', 'o', 'me', 'te', 'se', 'mi', 'tu', 'su', 'del', 'al', 'lo', 'los',
    'las', 'nos', 'os', 'eso', 'esto', 'aqui', 'alla', 'bien', 'mal', 'jaja',
    'jajaja', 'xd', 'k', 'q', 'vos', 'che', 'bot', 'ia', 'user', 'iauser'
]);

// ── Helpers ───────────────────────────────────────────────────────────────────

const normalizeNumber = (jid) =>
    jid ? jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim() : '';

function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

function collectGeminiKeys() {
    const keys = new Set();
    for (const name of ['gemini_api_key','GEMINI_API_KEY','gemini_api_key1','GEMINI_API_KEY1',
                        'gemini_api_key2','GEMINI_API_KEY2','gemini_api_key3','GEMINI_API_KEY3']) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0) keys.add(GEMINI_HARDCODED_KEY);
    return Array.from(keys);
}

function collectGroqKeys() {
    const keys = new Set();
    for (const name of ['groq_api_key','GROQ_API_KEY','groq_api_key1','GROQ_API_KEY1',
                        'groq_api_key2','GROQ_API_KEY2','groq_api_key3','GROQ_API_KEY3',
                        'groq_api_key4','GROQ_API_KEY4']) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0) keys.add(GROQ_HARDCODED_KEY);
    return Array.from(keys);
}

async function llamarGemini(systemPrompt, userPrompt, maxTokens = 500) {
    const keys = collectGeminiKeys();
    const body = {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        generationConfig: {
            temperature: 0.7,
            maxOutputTokens: maxTokens,
            thinkingConfig: { thinkingBudget: 0 }
        }
    };
    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        try {
            const res = await axios.post(GEMINI_URL, body, {
                headers: { 'Content-Type': 'application/json', 'X-goog-api-key': keys[i] },
                timeout: TIMEOUT
            });
            const candidate = res.data?.candidates?.[0];
            const texto = candidate?.content?.parts?.map(p => p.text).join('') || '';
            if (!texto) throw new Error('Respuesta vacía de Gemini');
            console.log(`[IAUSER] ✅ Gemini key ${i + 1} OK`);
            return texto.trim();
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            console.log(`[IAUSER] ⚠️ Gemini key ${i + 1} falló (status=${status}): ${err.response?.data?.error?.message || err.message}`);
            if (status && ![400, 401, 403, 404, 429].includes(status)) throw err;
        }
    }
    throw lastErr || new Error('Gemini: todas las keys fallaron.');
}

async function llamarGroq(systemPrompt, userPrompt, maxTokens = 500, model = GROQ_MODEL) {
    const keys = collectGroqKeys();
    const messages = [
        { role: 'system', content: systemPrompt },
        { role: 'user',   content: userPrompt   }
    ];
    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        try {
            const res = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                { model, messages, temperature: 0.7, max_tokens: maxTokens },
                {
                    headers: { 'Authorization': 'Bearer ' + keys[i], 'Content-Type': 'application/json' },
                    timeout: TIMEOUT
                }
            );
            const texto = res.data?.choices?.[0]?.message?.content?.trim() || '';
            console.log(`[IAUSER] ✅ Groq key ${i + 1} OK (model=${model})`);
            return texto;
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            const code   = err.response?.data?.error?.code;
            console.log(`[IAUSER] ⚠️ Groq key ${i + 1} falló (status=${status} code=${code}): ${err.message}`);
            if (status && ![401, 403, 429].includes(status) && code !== 'rate_limit_exceeded') throw err;
        }
    }
    throw lastErr || new Error('Groq: todas las keys fallaron.');
}

async function llamarGroqConReintentos(systemPrompt, userPrompt, maxTokens = 500) {
    try {
        return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_MODEL);
    } catch (err) {
        const status = err.response?.status;
        const code   = err.response?.data?.error?.code;
        const isRate = status === 429 || code === 'rate_limit_exceeded';
        if (!isRate) throw err;
    }
    for (const delay of [600, 1400]) {
        await new Promise(r => setTimeout(r, delay));
        try { return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_MODEL); } catch (_) {}
    }
    console.log('[IAUSER] ⚠️ Probando modelo ligero de Groq...');
    return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_FALLBACK_MODEL);
}

async function llamarIA(systemPrompt, userPrompt, maxTokens = 500) {
    try {
        const iaModule = require('./ia');
        const callIA = iaModule.callIA || iaModule;
        if (typeof callIA === 'function') {
            const res = await callIA(systemPrompt, userPrompt);
            if (res && res !== '_SILENT_FAIL_') return res;
        }
    } catch (e) {
        console.warn(`[IAUSER] Motor unificado falló (${e.message}), probando Gemini/Groq fallback...`);
    }

    try {
        return await llamarGemini(systemPrompt, userPrompt, maxTokens);
    } catch (err) {
        console.log(`[IAUSER] ❌ Gemini no disponible (${err.message}). Usando Groq...`);
    }
    return await llamarGroqConReintentos(systemPrompt, userPrompt, maxTokens);
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

/**
 * Busca a un usuario en la DB por su apodo de forma estricta.
 * Devuelve { userId, apodo, matchedLength } o null.
 */
function findUserByApodo(textQuery) {
    if (!textQuery) return null;
    const words = textQuery.trim().split(/\s+/);
    if (words.length === 0) return null;

    const firstWordNorm = normalizeText(words[0]);
    if (!firstWordNorm || STOP_WORDS.has(firstWordNorm)) {
        return null;
    }

    const allUsers = (db.data && db.data.users) || (global.db && global.db.data && global.db.data.users) || {};
    const normQuery = normalizeText(textQuery);
    let bestMatch = null;
    let maxMatchLen = 0;

    for (const [userId, userData] of Object.entries(allUsers)) {
        if (!userData || !userData.apodo || userData.apodo === 'sin apodo') continue;
        const normApodo = normalizeText(userData.apodo);
        if (!normApodo || STOP_WORDS.has(normApodo)) continue;

        // Coincidencia exacta o la consulta comienza con el apodo seguido de espacio
        if (normQuery === normApodo || normQuery.startsWith(normApodo + ' ')) {
            if (normApodo.length > maxMatchLen) {
                maxMatchLen = normApodo.length;
                const wordsCount = normApodo.split(' ').length;
                const matchedWords = words.slice(0, wordsCount).join(' ');

                bestMatch = {
                    userId: userId.split('@')[0],
                    apodo: userData.apodo,
                    matchedLength: matchedWords.length
                };
            }
        }
    }

    return bestMatch;
}

// ── Handler principal ─────────────────────────────────────────────────────────

const handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        const rawBody = message.body || '';
        const fullArg = (text || '').trim();

        const senderJid = message?.key?.participant || message?.key?.remoteJid || message?.sender;
        const senderNumber = senderJid ? normalizeNumber(senderJid) : '';

        let targetUserId = null;
        let targetJid    = null;
        let targetName   = '';
        let promptText   = '';

        // 1. Verificar si hay un mensaje citado (reply explícito)
        const quotedSender = message.quoted?.sender || message.quoted?.participant ||
            (message.message?.extendedTextMessage?.contextInfo?.participant);

        // 2. Verificar si el usuario escribió una mención explícita con @ en la orden
        const hasExplicitMention = /@\d+/.test(rawBody) || /@\d+/.test(fullArg);
        const allMentions = (hasExplicitMention && Array.isArray(message.mentions)) ? message.mentions : [];

        if (quotedSender) {
            targetJid    = quotedSender;
            targetUserId = normalizeNumber(quotedSender);
            promptText   = fullArg;
        } else if (hasExplicitMention && allMentions.length > 0) {
            targetJid    = allMentions[0];
            targetUserId = normalizeNumber(targetJid);
            promptText   = fullArg.replace(/@\d+/g, '').trim();
        } else if (fullArg) {
            // 3. Probar si la primera palabra es un número de teléfono directo o apodo
            const firstWord = fullArg.split(/\s+/)[0];
            if (/^\d{7,15}$/.test(firstWord)) {
                targetUserId = firstWord;
                targetJid    = `${targetUserId}@s.whatsapp.net`;
                promptText   = fullArg.substring(firstWord.length).trim();
            } else {
                const apodoMatch = findUserByApodo(fullArg);
                if (apodoMatch) {
                    targetUserId = apodoMatch.userId;
                    targetJid    = `${targetUserId}@s.whatsapp.net`;
                    targetName   = apodoMatch.apodo;
                    promptText   = fullArg.substring(apodoMatch.matchedLength).trim();
                }
            }
        }

        // 4. Si NO se especificó target por cita, ni mención con @, ni apodo válido, usar al SENDER (propio usuario)
        if (!targetUserId && senderJid) {
            targetJid    = senderJid;
            targetUserId = senderNumber;
            promptText   = fullArg;
        }

        // Si no se proveyó un mensaje para responder, dar un saludo por defecto
        if (!promptText) {
            promptText = 'hola, ¿qué hacés?';
        }

        // Obtener el apodo guardado en DB si no lo tenemos aún
        if (!targetName && db && targetUserId) {
            const userData = db.getUser ? db.getUser(targetUserId) : null;
            if (userData && userData.apodo && userData.apodo !== 'sin apodo') {
                targetName = userData.apodo;
            }
        }

        // ── Obtener historial del target en este grupo ─────────────────────────
        if (!chatHistory.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún.');
        }

        const groupId  = message.from;
        const histData = chatHistory.getUserHistory(groupId, targetUserId);

        const esSelf = targetUserId === senderNumber;

        if (!histData || !histData.history || histData.history.trim() === '') {
            const mentionsOut = [senderJid].filter(Boolean);
            if (!esSelf && targetJid && !mentionsOut.includes(targetJid)) {
                mentionsOut.push(targetJid);
            }

            const sock = conn || message._sock || global.conn;
            const targetDisp = esSelf
                ? `Todavía no tenés`
                : (targetName ? `*${targetName}* (@${targetUserId}) todavía no tiene` : `@${targetUserId} todavía no tiene`);

            return sock.sendMessage(
                message.from,
                {
                    text: `📭 ${targetDisp} suficientes mensajes registrados en este grupo para imitar su perfil social.`,
                    mentions: mentionsOut
                },
                { quoted: message._baileyMessage || message }
            );
        }

        await message.reply('🎭 _Analizando personalidad e imitando a usuario..._');

        // ── Construir System Prompt para la IA ─────────────────────────────────
        const systemPrompt =
            'Sos una Inteligencia Artificial que imita a la perfección a una persona real de un grupo de WhatsApp.\n' +
            'A continuación se te provee el historial de mensajes que esta persona escribió en este grupo.\n\n' +
            'REGLAS DE ACTUACIÓN OBLIGATORIAS:\n' +
            '1. Analizá detalladamente su forma de hablar: tono (amigable, seco, gracioso, tóxico, irónico, educado, etc.), vocabulario, slang/jerga local, modismos, uso de emojis, minusculación, mayúsculas, faltas de ortografía y longitud típica de mensajes.\n' +
            '2. RESPONDÉ AL MENSAJE QUE TE ENVIARON ADOPTANDO 100% SU PERFIL SOCIAL Y ESTILO DE ESCRITURA.\n' +
            '3. NUNCA rompas el personaje. NUNCA digas que sos una IA, un bot ni un asistente.\n' +
            '4. Sé conciso y natural (1 a 3 oraciones), tal como respondería esa persona en un chat real de WhatsApp.\n' +
            '5. Respondé directamente a lo que te dicen o preguntan, manteniendo sus opiniones o personalidad reflejada en el historial.';

        const userPrompt =
            `Historial de mensajes de esta persona en el grupo (${histData.msgCount} mensajes registrados):\n` +
            `---\n${histData.history}\n---\n\n` +
            `Mensaje recibido al que debes responder en su personaje:\n"${promptText}"`;

        const respuestaIA = await llamarIA(systemPrompt, userPrompt, 500);

        // ── Formatear y Enviar respuesta final ─────────────────────────────────
        const targetLabel = esSelf
            ? `Tu Perfil (@${targetUserId})`
            : (targetName ? `${targetName} (@${targetUserId})` : `@${targetUserId}`);

        const msgFinal =
            `🎭 *[IA - ${targetLabel}]*\n\n` +
            formatear(respuestaIA);

        const mentionsOut = [senderJid].filter(Boolean);
        if (!esSelf && targetJid && !mentionsOut.includes(targetJid)) {
            mentionsOut.push(targetJid);
        }

        const sock = conn || message._sock || global.conn;
        await sock.sendMessage(
            message.from,
            { text: msgFinal, mentions: mentionsOut },
            { quoted: message._baileyMessage || message }
        );

    } catch (err) {
        console.error('[IAUSER] Error:', err.message || err);
        const status = err.response?.status;
        const code   = err.response?.data?.error?.code;
        const isRate = status === 429 || code === 'rate_limit_exceeded';
        if (isRate) {
            return message.reply('⏳ Las IAs están saturadas en este momento. Intentá de nuevo en unos segundos.');
        }
        return message.reply('❌ Ocurrió un error al imitar al usuario. Intentá de nuevo.');
    }
};

handler.help    = ['iauser <mensaje>', 'iauser @usuario <mensaje>', 'iauser <apodo> <mensaje>'];
handler.tags    = ['ia', 'fun', 'herramientas'];
handler.command = /^(iauser|ia-user|useria)$/i;
handler.group   = true;

module.exports = handler;
