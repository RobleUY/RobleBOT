const fs = require('fs')
const path = require('path')
const axios = require('axios')

const API_KEY = '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'
const MODEL = 'llama-3.3-70b-versatile'
const TIMEOUT = 30000
const MAX_CHARS = 8000

const CHAT_DIR = path.join(__dirname, '../../../data/CHATS-USUARIOS')

/**
 * Lee hasta MAX_CHARS caracteres del historial de un usuario en un grupo,
 * tomando los mensajes más recientes (desde el final del archivo).
 */
function leerChatReciente(numero, groupId) {
    const filePath = path.join(CHAT_DIR, groupId, `${numero}.txt`)
    if (!fs.existsSync(filePath)) return null

    const contenido = fs.readFileSync(filePath, 'utf-8').trim()
    if (!contenido) return null

    if (Buffer.byteLength(contenido, 'utf-8') <= MAX_CHARS) return contenido

    const bytes = Buffer.from(contenido, 'utf-8')
    const recortado = bytes.slice(bytes.length - MAX_CHARS).toString('utf-8')
    const primerSalto = recortado.indexOf('\n')
    return primerSalto !== -1 ? recortado.slice(primerSalto + 1) : recortado
}

let handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.')
        }

        if (!text || !text.trim()) {
            return message.reply('❌ Escribe una pregunta.\n\nEjemplos:\n*.sobre soy agresivo?*\n*.sobre @Usuario es amable?*')
        }

        const groupId = message.from

        // Detectar si hay un @mencionado en el texto
        const mentioned = message.mentions?.[0]
        let targetJid = null
        let targetNumero = null
        let pregunta = text.trim()

        if (mentioned) {
            targetJid = mentioned
            targetNumero = mentioned.split('@')[0].replace(/\D/g, '')
            // Limpiar la mención del texto de la pregunta
            pregunta = pregunta.replace(/@\d+/g, '').replace(/\s+/g, ' ').trim()
        } else {
            targetJid = message.sender
            targetNumero = message.sender.split('@')[0].replace(/\D/g, '')
        }

        if (!pregunta) {
            return message.reply('❌ Escribe una pregunta después del comando.')
        }

        // Leer historial
        const chat = leerChatReciente(targetNumero, groupId)
        if (!chat) {
            const esPropioUsuario = !mentioned
            if (esPropioUsuario) {
                return message.reply('❌ No tengo mensajes tuyos guardados en este grupo todavía.')
            } else {
                return message.reply(`❌ No tengo mensajes guardados de @${targetNumero} en este grupo.`, { mentions: [targetJid] })
            }
        }

        await message.reply('🤔 Analizando...')

        const esPropioUsuario = !mentioned
        const contexto = esPropioUsuario
            ? 'Los mensajes son del propio usuario que hace la pregunta sobre sí mismo.'
            : `Los mensajes son de otra persona (@${targetNumero}) sobre quien se hace la pregunta.`

        const prompt = `Tienes acceso a una muestra de mensajes de WhatsApp de una persona en un grupo. ${contexto}

Basándote ÚNICAMENTE en estos mensajes, responde la siguiente pregunta de forma directa y fundamentada:

PREGUNTA: ${pregunta}

MENSAJES:
${chat}

Responde de forma concisa y directa, citando ejemplos de los mensajes cuando sea relevante.`

        const res = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: MODEL,
                messages: [
                    { role: 'system', content: 'Eres un asistente que analiza mensajes de WhatsApp para responder preguntas sobre el comportamiento y personalidad de las personas. Responde siempre en español, de forma directa y basándote solo en los mensajes proporcionados.' },
                    { role: 'user', content: prompt }
                ],
                temperature: 0.7,
                max_tokens: 700
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: TIMEOUT
            }
        )

        const respuesta = res.data?.choices?.[0]?.message?.content
        if (!respuesta) return message.reply('❌ No se pudo generar la respuesta.')

        const header = esPropioUsuario
            ? `💬 *Sobre ti* — _${pregunta}_\n${'─'.repeat(20)}\n`
            : `💬 *Sobre @${targetNumero}* — _${pregunta}_\n${'─'.repeat(20)}\n`

        const mentions = esPropioUsuario ? [] : [targetJid]
        return message.reply(header + respuesta.trim(), { mentions })

    } catch (err) {
        const apiErr = err.response?.data?.error
        console.error('[SOBRE-USUARIOS ERROR]', apiErr || err.message)
        return message.reply('❌ Error al procesar la consulta. Intentá de nuevo.')
    }
}

handler.help = ['.sobre <pregunta>', '.sobre @Usuario <pregunta>']
handler.tags = ['ia']
handler.command = /^(sobre)$/i

module.exports = handler
