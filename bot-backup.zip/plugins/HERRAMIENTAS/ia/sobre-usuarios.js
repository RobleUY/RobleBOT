'use strict';

/**
 * sobre-usuarios.js
 * Comando: .sobre
 *
 * Usos:
 *   .sobre <pregunta>              → analiza tu propio historial de chat y responde
 *   .sobre @usuario <pregunta>     → analiza el historial del usuario mencionado y responde
 *
 * Restricciones:
 *   - Solo se permite UNA mención como mucho (el target)
 *   - La pregunta NO puede contener menciones adicionales
 *   - Solo funciona en grupos (el historial es por grupo)
 */

const axios = require('axios');

// ── Config IA (igual que ayuda-bot-ia) ───────────────────────────────────────
const GEMINI_HARDCODED_KEY  = 'AQ.Ab8RN6ITI3xTBtxQzTdTLDLEvNyhF7T4swUH1nh7gEOWRExmiw';
const GEMINI_MODEL          = 'gemini-flash-latest';
const GEMINI_URL            = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const GROQ_HARDCODED_KEY    = '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';
const GROQ_MODEL            = 'llama-3.3-70b-versatile';
const GROQ_FALLBACK_MODEL   = 'llama-3.1-8b-instant';
const TIMEOUT               = 25000;
const MODEL_LIST = ['openai/gpt-oss-20b','openai/gpt-oss-120b','qwen/qwen3-32b','meta-llama/llama-4-scout-17b-16e-instruct','llama-3.3-70b-versatile','llama-3.3-8b-instant','llama-3.1-8b-instant'];

// ── Helpers ───────────────────────────────────────────────────────────────────

const normalizeNumber = (jid) =>
    jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim();

function collectGeminiKeys() {
    const keys = new Set();
    for (const name of ['gemini_api_key','GEMINI_API_KEY','gemini_api_key1','GEMINI_API_KEY1',
                        'gemini_api_key2','GEMINI_API_KEY2','gemini_api_key3','GEMINI_API_KEY3']) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0) keys.add(GEMINI_HARDCODED_KEY);
    return Array.from(keys);
}

function collectGroqKeys() {
    const keys = new Set();
    for (const name of ['groq_api_key','GROQ_API_KEY','groq_api_key1','GROQ_API_KEY1',
                        'groq_api_key2','GROQ_API_KEY2','groq_api_key3','GROQ_API_KEY3',
                        'groq_api_key4','GROQ_API_KEY4']) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0) keys.add(GROQ_HARDCODED_KEY);
    return Array.from(keys);
}

async function llamarGemini(systemPrompt, userPrompt, maxTokens = 400) {
    const keys = collectGeminiKeys();
    const body = {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        generationConfig: {
            temperature: 0.5,
            maxOutputTokens: maxTokens,
            thinkingConfig: { thinkingBudget: 0 }
        }
    };
    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        try {
            const res = await axios.post(GEMINI_URL, body, {
                headers: { 'Content-Type': 'application/json', 'X-goog-api-key': keys[i] },
                timeout: TIMEOUT
            });
            const candidate = res.data?.candidates?.[0];
            const texto = candidate?.content?.parts?.map(p => p.text).join('') || '';
            if (!texto) throw new Error('Respuesta vacía de Gemini');
            console.log(`[SOBRE] ✅ Gemini key ${i + 1} OK`);
            return texto.trim();
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            console.log(`[SOBRE] ⚠️ Gemini key ${i + 1} falló (status=${status}): ${err.response?.data?.error?.message || err.message}`);
            if (status && ![400, 401, 403, 404, 429].includes(status)) throw err;
        }
    }
    throw lastErr || new Error('Gemini: todas las keys fallaron.');
}

async function llamarGroq(systemPrompt, userPrompt, maxTokens = 400, model = GROQ_MODEL) {
    const keys = collectGroqKeys();
    const messages = [
        { role: 'system', content: systemPrompt },
        { role: 'user',   content: userPrompt   }
    ];
    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        try {
            const res = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                { model, messages, temperature: 0.5, max_tokens: maxTokens },
                {
                    headers: { 'Authorization': 'Bearer ' + keys[i], 'Content-Type': 'application/json' },
                    timeout: TIMEOUT
                }
            );
            const texto = res.data?.choices?.[0]?.message?.content?.trim() || '';
            console.log(`[SOBRE] ✅ Groq key ${i + 1} OK (model=${model})`);
            return texto;
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            const code   = err.response?.data?.error?.code;
            console.log(`[SOBRE] ⚠️ Groq key ${i + 1} falló (status=${status} code=${code}): ${err.message}`);
            if (status && ![401, 403, 429].includes(status) && code !== 'rate_limit_exceeded') throw err;
        }
    }
    throw lastErr || new Error('Groq: todas las keys fallaron.');
}

// Groq con reintentos y fallback a modelo ligero
async function llamarGroqConReintentos(systemPrompt, userPrompt, maxTokens = 400) {
    try {
        return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_MODEL);
    } catch (err) {
        const status = err.response?.status;
        const code   = err.response?.data?.error?.code;
        const isRate = status === 429 || code === 'rate_limit_exceeded';
        if (!isRate) throw err;
    }
    // Reintentos con delay
    for (const delay of [600, 1400]) {
        await new Promise(r => setTimeout(r, delay));
        try { return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_MODEL); } catch (_) {}
    }
    // Último recurso: modelo ligero
    console.log('[SOBRE] ⚠️ Probando modelo ligero de Groq...');
    return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_FALLBACK_MODEL);
}

// Punto de entrada: IAs unificadas en paralelo (Groq + Delirius GPT/Gemini/ChatGPT)
async function llamarIA(systemPrompt, userPrompt, maxTokens = 400) {
    try {
        const iaModule = require('./ia');
        const callIA = iaModule.callIA || iaModule;
        if (typeof callIA === 'function') {
            const res = await callIA(systemPrompt, userPrompt);
            if (res && res !== '_SILENT_FAIL_') return res;
        }
    } catch (e) {
        console.warn(`[SOBRE] Motor unificado falló (${e.message}), probando Gemini/Groq fallback...`);
    }

    try {
        return await llamarGemini(systemPrompt, userPrompt, maxTokens);
    } catch (err) {
        console.log(`[SOBRE] ❌ Gemini no disponible (${err.message}). Usando Groq...`);
    }
    return await llamarGroqConReintentos(systemPrompt, userPrompt, maxTokens);
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// ── Handler ───────────────────────────────────────────────────────────────────

const handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup)
            return message.reply('❌ Este comando solo funciona en grupos.');

        const rawBody = message.body || '';

        // ── Detectar menciones en el mensaje completo ─────────────────────────
        // Las menciones vienen en message.mentions (array de JIDs)
        const allMentions = Array.isArray(message.mentions) ? message.mentions : [];

        // Contar cuántas menciones @numero hay en el texto completo (body)
        const mentionMatches = rawBody.match(/@\d+/g) || [];

        // Extraer el texto después del comando para analizarlo
        // text = todo lo que viene después del comando (.sobre)
        const fullArg = (text || '').trim();

        if (!fullArg)
            return message.reply(
                '❓ *¿Sobre quién querés preguntar?*\n\n' +
                'Usos:\n' +
                '• *.sobre* <pregunta> → analiza tu propio chat\n' +
                '• *.sobre @usuario* <pregunta> → analiza el chat de esa persona\n\n' +
                '_Ejemplo: .sobre @Juan es buena persona?_'
            );

        // ── Validar: no se permiten múltiples menciones ───────────────────────
        if (mentionMatches.length > 1 || allMentions.length > 1)
            return message.reply('⚠️ Solo podés mencionar a *una persona* como máximo en este comando.');

        // ── Determinar target y pregunta ──────────────────────────────────────
        let targetUserId = null;   // número limpio del target
        let targetJid    = null;   // JID completo para la mención en la respuesta
        let targetLabel  = '';     // cómo llamar al target en la respuesta
        let pregunta     = fullArg;

        if (allMentions.length === 1) {
            // Modo .sobre @usuario <pregunta>
            targetJid    = allMentions[0];
            targetUserId = normalizeNumber(targetJid);

            // Verificar que la mención está al INICIO del argumento (es el target, no la pregunta)
            // Si @numero aparece dentro de la pregunta → error
            const primerToken = fullArg.split(/\s+/)[0];
            if (!primerToken.startsWith('@')) {
                // La mención no es el primer token → está dentro de la pregunta
                return message.reply('⚠️ No podés mencionar a alguien dentro de la pregunta.\n_Usá: .sobre @usuario <pregunta>_');
            }

            // Quitar el primer token (@numero) para obtener solo la pregunta
            pregunta = fullArg.replace(/^@\d+\s*/, '').trim();

            if (!pregunta)
                return message.reply('⚠️ Falta la pregunta. Usá: *.sobre @usuario <pregunta>*');

            // Verificar que la pregunta no tenga menciones adicionales
            const mentionesEnPregunta = pregunta.match(/@\d+/g) || [];
            if (mentionesEnPregunta.length > 0)
                return message.reply('⚠️ La pregunta no puede contener menciones.\n_Solo podés mencionar al target al inicio._');

            targetLabel = `@${targetUserId}`;
        } else {
            // Modo .sobre <pregunta> → el target es el propio usuario
            // Verificar que la pregunta no tenga menciones
            const mentionesEnPregunta = pregunta.match(/@\d+/g) || [];
            if (mentionesEnPregunta.length > 0)
                return message.reply('⚠️ No podés mencionar a nadie en la pregunta cuando consultás sobre vos mismo.\n_Para preguntar sobre otro usá: .sobre @usuario <pregunta>_');

            const senderJid  = message.key?.participant || message.sender || message.author || '';
            targetJid        = senderJid;
            targetUserId     = normalizeNumber(senderJid);
            targetLabel      = 'vos';
        }

        // ── Obtener historial del target en este grupo ─────────────────────────
        const chatHistory = require('../../../chatHistory');
        if (!chatHistory.isReady)
            return message.reply('❌ El historial de chat no está disponible aún.');

        const groupId  = message.from;
        const histData = chatHistory.getUserHistory(groupId, targetUserId);

        if (!histData || !histData.history || histData.history.trim() === '') {
            const senderJid    = message?.key?.participant || message?.key?.remoteJid;
            const senderNumber = senderJid ? senderJid.split('@')[0] : '';
            const targetNumber = targetJid ? targetJid.split('@')[0] : '';

            const esSelf = targetLabel === 'vos';
            const quien  = esSelf
                ? `@${senderNumber} todavía no tiene`
                : `@${targetNumber} todavía no tiene`;

            const mentionsNo = [senderJid].filter(Boolean);
            if (!esSelf && targetJid) mentionsNo.push(targetJid);

            const sock = conn || message._sock || global.conn;
            return sock.sendMessage(
                message.from,
                { text: `📭 ${quien} mensajes registrados en este grupo para analizar.`, mentions: mentionsNo },
                { quoted: message._baileyMessage || message }
            );
        }

        // ── Calcular días desde el último mensaje ──────────────────────────────
        const diasInactivo = histData.lastMsgTs
            ? Math.floor((Date.now() - histData.lastMsgTs) / 86400000)
            : null;

        const ultimaActividad = diasInactivo !== null
            ? (diasInactivo === 0 ? 'hoy' : `hace ${diasInactivo} día${diasInactivo > 1 ? 's' : ''}`)
            : 'desconocida';

        // ── Llamar a Gemini ───────────────────────────────────────────────────
        await message.reply('🔍 _Analizando historial..._');

        const systemPrompt =
            'Sos un analizador de conversaciones de WhatsApp. ' +
            'Te van a dar mensajes que UNA MISMA PERSONA escribió en un grupo, y una pregunta sobre ella.\n\n' +
            'REGLAS ESTRICTAS:\n' +
            '1. Cada línea del historial es algo que ESA PERSONA dijo — no otros hablando de ella.\n' +
            '2. SIEMPRE respondé la pregunta basándote en lo que haya. Aunque sea poco contexto, sacá conclusiones.\n' +
            '3. Si la info es escasa, especulá razonablemente a partir del tono, vocabulario o temas que usa.\n' +
            '4. NUNCA digas "no hay suficiente información", "no puedo determinar" ni frases similares. ' +
            'Si no hay nada concreto, describí cómo parece ser la persona por cómo escribe.\n' +
            '5. Respondé directo, máximo 3 oraciones. Español informal. Sin markdown exagerado.';

        const userPrompt =
            `Mensajes de esta persona en el grupo (${histData.msgCount} mensajes, ` +
            `última actividad: ${ultimaActividad}):\n` +
            `---\n${histData.history}\n---\n\n` +
            `Pregunta: ${pregunta}`;

        const respuestaIA = await llamarIA(systemPrompt, userPrompt, 500);

        // ── Construir respuesta final ─────────────────────────────────────────
        // Patrón exacto de plugins MENCIONAR:
        //   senderJid  = message?.key?.participant || message?.key?.remoteJid
        //   targetJid  = message?.mentions[0]   (ya lo tenemos en targetJid)
        //   texto      = "@${jid.split('@')[0]}"
        //   mentions   = [senderJid, targetJid]   ← ambos JIDs completos

        const senderJid    = message?.key?.participant || message?.key?.remoteJid;
        const senderNumber = senderJid ? senderJid.split('@')[0] : '';
        const targetNumber = targetJid ? targetJid.split('@')[0] : '';

        const esSelf = targetLabel === 'vos';

        const header = esSelf
            ? `🔎 *Análisis del historial de @${senderNumber}*`
            : `🔎 *Análisis del historial de @${targetNumber}*`;

        const msgFinal =
            `${header}\n` +
            `💬 _"${pregunta}"_\n\n` +
            formatear(respuestaIA);

        // mentions siempre incluye al sender; si hay target distinto, también él
        const mentionsOut = [senderJid].filter(Boolean);
        if (!esSelf && targetJid) mentionsOut.push(targetJid);

        const sock = conn || message._sock || global.conn;
        await sock.sendMessage(
            message.from,
            { text: msgFinal, mentions: mentionsOut },
            { quoted: message._baileyMessage || message }
        );

    } catch (err) {
        console.error('[SOBRE] Error:', err.message || err);
        const status = err.response?.status;
        const code   = err.response?.data?.error?.code;
        const isRate = status === 429 || code === 'rate_limit_exceeded';
        if (isRate)
            return message.reply('⏳ Todas las IAs están saturadas ahora mismo. Intentá en unos segundos.');
        return message.reply('❌ Error al procesar la consulta. Intentá de nuevo.');
    }
};

handler.help    = ['sobre <pregunta>', 'sobre @usuario <pregunta>'];
handler.tags    = ['ia', 'info'];
handler.command = /^sobre$/i;
handler.group   = true;

module.exports = handler;
