'use strict';

/**
 * sobre-usuarios.js
 * Comando: .sobre
 *
 * Usos:
 *   .sobre <pregunta>              → analiza tu propio historial de chat y responde
 *   .sobre @usuario <pregunta>     → analiza el historial del usuario mencionado y responde
 *
 * Restricciones:
 *   - Solo se permite UNA mención como mucho (el target)
 *   - La pregunta NO puede contener menciones adicionales
 *   - Solo funciona en grupos (el historial es por grupo)
 */

const axios = require('axios');

// ── Config Gemini (igual que ayuda-bot-ia) ────────────────────────────────────
const GEMINI_HARDCODED_KEY = 'AQ.Ab8RN6ITI3xTBtxQzTdTLDLEvNyhF7T4swUH1nh7gEOWRExmiw';
const GEMINI_MODEL         = 'gemini-flash-latest';
const GEMINI_URL           = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const TIMEOUT              = 25000;

// ── Helpers ───────────────────────────────────────────────────────────────────

const normalizeNumber = (jid) =>
    jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim();

function collectGeminiKeys() {
    const keys = new Set();
    const vars = [
        'gemini_api_key',  'GEMINI_API_KEY',
        'gemini_api_key1', 'GEMINI_API_KEY1',
        'gemini_api_key2', 'GEMINI_API_KEY2',
        'gemini_api_key3', 'GEMINI_API_KEY3',
    ];
    for (const name of vars) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0) keys.add(GEMINI_HARDCODED_KEY);
    return Array.from(keys);
}

async function llamarGemini(systemPrompt, userPrompt, maxTokens = 400) {
    const keys = collectGeminiKeys();

    const body = {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        generationConfig: {
            temperature: 0.5,
            maxOutputTokens: maxTokens,
            thinkingConfig: { thinkingBudget: 0 }
        }
    };

    let lastErr = null;
    for (let i = 0; i < keys.length; i++) {
        try {
            const res = await axios.post(GEMINI_URL, body, {
                headers: {
                    'Content-Type': 'application/json',
                    'X-goog-api-key': keys[i]
                },
                timeout: TIMEOUT
            });
            const candidate = res.data?.candidates?.[0];
            const texto = candidate?.content?.parts?.map(p => p.text).join('') || '';
            if (!texto) throw new Error('Respuesta vacía de Gemini');
            return texto.trim();
        } catch (err) {
            lastErr = err;
            const status = err.response?.status;
            console.log(`[SOBRE] ⚠️ Gemini key ${i + 1} falló (status=${status}): ${err.response?.data?.error?.message || err.message}`);
            if (status && ![400, 401, 403, 404, 429].includes(status)) throw err;
        }
    }
    throw lastErr || new Error('Gemini falló sin detalle de error.');
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// ── Handler ───────────────────────────────────────────────────────────────────

const handler = async (message, { text, conn }) => {
    try {
        if (!message.isGroup)
            return message.reply('❌ Este comando solo funciona en grupos.');

        const rawBody = message.body || '';

        // ── Detectar menciones en el mensaje completo ─────────────────────────
        // Las menciones vienen en message.mentions (array de JIDs)
        const allMentions = Array.isArray(message.mentions) ? message.mentions : [];

        // Contar cuántas menciones @numero hay en el texto completo (body)
        const mentionMatches = rawBody.match(/@\d+/g) || [];

        // Extraer el texto después del comando para analizarlo
        // text = todo lo que viene después del comando (.sobre)
        const fullArg = (text || '').trim();

        if (!fullArg)
            return message.reply(
                '❓ *¿Sobre quién querés preguntar?*\n\n' +
                'Usos:\n' +
                '• *.sobre* <pregunta> → analiza tu propio chat\n' +
                '• *.sobre @usuario* <pregunta> → analiza el chat de esa persona\n\n' +
                '_Ejemplo: .sobre @Juan es buena persona?_'
            );

        // ── Validar: no se permiten múltiples menciones ───────────────────────
        if (mentionMatches.length > 1 || allMentions.length > 1)
            return message.reply('⚠️ Solo podés mencionar a *una persona* como máximo en este comando.');

        // ── Determinar target y pregunta ──────────────────────────────────────
        let targetUserId = null;   // número limpio del target
        let targetJid    = null;   // JID completo para la mención en la respuesta
        let targetLabel  = '';     // cómo llamar al target en la respuesta
        let pregunta     = fullArg;

        if (allMentions.length === 1) {
            // Modo .sobre @usuario <pregunta>
            targetJid    = allMentions[0];
            targetUserId = normalizeNumber(targetJid);

            // Verificar que la mención está al INICIO del argumento (es el target, no la pregunta)
            // Si @numero aparece dentro de la pregunta → error
            const primerToken = fullArg.split(/\s+/)[0];
            if (!primerToken.startsWith('@')) {
                // La mención no es el primer token → está dentro de la pregunta
                return message.reply('⚠️ No podés mencionar a alguien dentro de la pregunta.\n_Usá: .sobre @usuario <pregunta>_');
            }

            // Quitar el primer token (@numero) para obtener solo la pregunta
            pregunta = fullArg.replace(/^@\d+\s*/, '').trim();

            if (!pregunta)
                return message.reply('⚠️ Falta la pregunta. Usá: *.sobre @usuario <pregunta>*');

            // Verificar que la pregunta no tenga menciones adicionales
            const mentionesEnPregunta = pregunta.match(/@\d+/g) || [];
            if (mentionesEnPregunta.length > 0)
                return message.reply('⚠️ La pregunta no puede contener menciones.\n_Solo podés mencionar al target al inicio._');

            targetLabel = `@${targetUserId}`;
        } else {
            // Modo .sobre <pregunta> → el target es el propio usuario
            // Verificar que la pregunta no tenga menciones
            const mentionesEnPregunta = pregunta.match(/@\d+/g) || [];
            if (mentionesEnPregunta.length > 0)
                return message.reply('⚠️ No podés mencionar a nadie en la pregunta cuando consultás sobre vos mismo.\n_Para preguntar sobre otro usá: .sobre @usuario <pregunta>_');

            const senderJid  = message.key?.participant || message.sender || message.author || '';
            targetJid        = senderJid;
            targetUserId     = normalizeNumber(senderJid);
            targetLabel      = 'vos';
        }

        // ── Obtener historial del target en este grupo ─────────────────────────
        const chatHistory = require('../../../chatHistory');
        if (!chatHistory.isReady)
            return message.reply('❌ El historial de chat no está disponible aún.');

        const groupId  = message.from;
        const histData = chatHistory.getUserHistory(groupId, targetUserId);

        if (!histData || !histData.history || histData.history.trim() === '') {
            const quien = targetLabel === 'vos' ? 'Todavía no tenés' : `${targetLabel} todavía no tiene`;
            return message.reply(`📭 ${quien} mensajes registrados en este grupo para analizar.`);
        }

        // ── Calcular días desde el último mensaje ──────────────────────────────
        const diasInactivo = histData.lastMsgTs
            ? Math.floor((Date.now() - histData.lastMsgTs) / 86400000)
            : null;

        const ultimaActividad = diasInactivo !== null
            ? (diasInactivo === 0 ? 'hoy' : `hace ${diasInactivo} día${diasInactivo > 1 ? 's' : ''}`)
            : 'desconocida';

        // ── Llamar a Gemini ───────────────────────────────────────────────────
        await message.reply('🔍 _Analizando historial..._');

        const systemPrompt =
            'Sos un analizador de conversaciones de WhatsApp.\n' +
            'Te voy a dar el historial de mensajes de una persona en un grupo de WhatsApp ' +
            'y una pregunta sobre esa persona.\n\n' +
            'REGLAS:\n' +
            '1. Respondé ÚNICAMENTE basándote en los mensajes del historial.\n' +
            '2. Si el historial no tiene información suficiente para responder, decilo claramente.\n' +
            '3. Sé objetivo, breve y directo. Máximo 5 oraciones.\n' +
            '4. No inventes ni supongas cosas que no están en el historial.\n' +
            '5. Escribí en español, tono informal y natural.\n' +
            '6. No uses markdown exagerado, solo negrita para puntos clave.';

        const userPrompt =
            `*Historial de mensajes de la persona (${histData.msgCount} mensajes en total, ` +
            `última actividad: ${ultimaActividad}):*\n\n` +
            `${histData.history}\n\n` +
            `*Pregunta:* ${pregunta}`;

        const respuestaIA = await llamarGemini(systemPrompt, userPrompt, 400);

        // ── Construir respuesta final ──────────────────────────────────────────
        const esSelf = targetLabel === 'vos';
        const header = esSelf
            ? `🔎 *Análisis de tu historial*`
            : `🔎 *Análisis del historial de @${targetUserId}*`;

        const msgFinal =
            `${header}\n` +
            `💬 _"${pregunta}"_\n\n` +
            formatear(respuestaIA);

        // Mencionar al target si no es el propio usuario (para que sea visible en el grupo)
        const mentionsOut = (!esSelf && targetJid) ? [targetJid] : [];

        await message.reply(msgFinal, { mentions: mentionsOut });

    } catch (err) {
        console.error('[SOBRE] Error:', err.message || err);
        const status = err.response?.status;
        if (status === 429)
            return message.reply('⏳ Demasiadas consultas seguidas. Intentá en unos segundos.');
        return message.reply('❌ Error al procesar la consulta. Intentá de nuevo.');
    }
};

handler.help    = ['sobre <pregunta>', 'sobre @usuario <pregunta>'];
handler.tags    = ['ia', 'info'];
handler.command = /^sobre$/i;
handler.group   = true;

module.exports = handler;
