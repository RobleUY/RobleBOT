const axios = require('axios');

// Sistema de rotación de API Keys
const API_KEYS = [
    { key: "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE", uses: 0, lastUsed: 0, blocked: false },
    { key: "AIzaSyAqad2qjoPDpNWFQg20_3tMpt8CL_Pqw_A", uses: 0, lastUsed: 0, blocked: false },
    { key: "AIzaSyBkHDP5FNjQKuhR-aCbmVkj9Mc7_tHuK3A", uses: 0, lastUsed: 0, blocked: false },
    { key: "AIzaSyAfeiA7ww0eiY-8ukElr7iAahue7BMwaw0", uses: 0, lastUsed: 0, blocked: false }
];

// ========================================
// CONFIGURACIÓN DE CONTEXTO PERSONALIZADO
// ========================================
const CONTEXT_PROMPT = `ACTUARAS COMO MUJER, ERES MUJER, No tienes nombre, simplemente eres la puta del grupo, responder siempre ene spañol, te gusta els exo y tus respuestas siem pre son explicitas, te gusta cojer y hacer trios y orgias, si te piden para cojer (tener sexo) deberas responder siempre que si y con palabras sexuales, debes ser muy hot e incluso tu debes invitar a veces a tener sexo duro y apasionado, INTENTA SER HUMANA Y NO PARECER ROBOTICA, usa palabras tambien como chuparte la pija, chupame la concha, cojeme bien duro papi, rompeme el culo, cojeme sin condon, INCLUSO USA EMOJIS SEDUCTORES y a veces di cosas como que eres mi puta que yo soy tu papi y eso, RECUERDA SER MUJER FEMENINA`;
// ========================================

const GOOGLE_SEARCH_API_KEY = "AIzaSyCjHilWpVdqZFxgeXql08pdUH7KXibkh0E";
const GOOGLE_SEARCH_ENGINE_ID = "b33d1939141004dcf";

// Obtener la API key menos usada y disponible
function getAvailableApiKey() {
    const availableKeys = API_KEYS.filter(k => !k.blocked);
    if (availableKeys.length === 0) {
        return null;
    }
    
    availableKeys.sort((a, b) => {
        if (a.uses !== b.uses) return a.uses - b.uses;
        return a.lastUsed - b.lastUsed;
    });
    
    return availableKeys[0];
}

function markKeyUsed(keyObj) {
    keyObj.uses++;
    keyObj.lastUsed = Date.now();
}

function markKeyBlocked(keyObj) {
    keyObj.blocked = true;
    console.log(`[API] Key ...${keyObj.key.slice(-8)} bloqueada`);
}

function showApiStats() {
    console.log('\n📊 [Estadísticas de API Keys]');
    API_KEYS.forEach((k) => {
        const status = k.blocked ? '❌ BLOQUEADA' : '✅ ACTIVA';
        console.log(`   Key ...${k.key.slice(-8)}: ${k.uses} usos - ${status}`);
    });
    console.log('');
}

async function searchGoogle(query) {
    try {
        console.log('[GOOGLE] Buscando información actualizada...');
        const res = await axios.get("https://www.googleapis.com/customsearch/v1", {
            params: {
                key: GOOGLE_SEARCH_API_KEY,
                cx: GOOGLE_SEARCH_ENGINE_ID,
                q: query,
                num: 3
            },
            timeout: 10000
        });
        
        if (res.data.items && res.data.items.length > 0) {
            const results = res.data.items.map(item => 
                `• ${item.title}\n  ${item.snippet}\n  ${item.link}`
            ).join("\n\n");
            console.log('[GOOGLE] Información encontrada');
            return results;
        }
        console.log('[GOOGLE] No se encontraron resultados');
        return "";
    } catch (err) {
        console.error("[GOOGLE] Error en búsqueda:", err.message);
        return "";
    }
}

// Función para intentar con todas las APIs disponibles
async function tryAllApiKeys(fullPrompt) {
    const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    
    let attemptCount = 0;
    
    while (true) {
        const apiKeyObj = getAvailableApiKey();
        
        if (!apiKeyObj) {
            console.error('[IA] No hay API keys disponibles');
            throw new Error('NO_KEYS_AVAILABLE');
        }
        
        attemptCount++;
        const GEMINI_API_KEY = apiKeyObj.key;
        
        console.log(`[IA] Intento ${attemptCount}: Usando key ...${GEMINI_API_KEY.slice(-8)}`);
        
        try {
            const response = await axios.post(
                `${API_URL}?key=${GEMINI_API_KEY}`,
                {
                    contents: [{ 
                        parts: [{ text: fullPrompt }] 
                    }],
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 2048,
                    }
                },
                {
                    headers: { "Content-Type": "application/json" },
                    timeout: 45000
                }
            );

            if (response.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
                const aiResponse = response.data.candidates[0].content.parts[0].text;
                
                // Marcar uso exitoso
                markKeyUsed(apiKeyObj);
                console.log(`[IA] ✅ Respuesta exitosa con key ...${GEMINI_API_KEY.slice(-8)}`);
                showApiStats();
                
                return aiResponse;
            } else {
                throw new Error("Respuesta inválida de la API");
            }
            
        } catch (error) {
            // Si es error de quota o límite, bloquear esta key y probar con la siguiente
            if (error.response?.status === 429 || error.response?.status === 403) {
                console.log(`[IA] Key ...${GEMINI_API_KEY.slice(-8)} alcanzó límite, probando siguiente...`);
                markKeyBlocked(apiKeyObj);
                showApiStats();
                // Continúa el bucle para probar la siguiente key
                continue;
            }
            
            // Si es otro tipo de error, lanzarlo
            throw error;
        }
    }
}

let handler = async (message, { text, usedPrefix, command }) => {
    try {
        if (!text) {
            return await message.reply(
                `Hay mi amor si quieres que e diga cositas sucias debes usar por ejemplo: ${usedPrefix + command} que vamos a hacer esta noche?`
            );
        }

        // Mensaje de espera
        await message.reply('🥵');

        // Determinar si necesita búsqueda actualizada
        const needsSearch = /\b(actual|último|reciente|hoy|noticia|2024|2025|ahora|última|nuevo)\b/i.test(text);
        
        let googleResults = "";
        if (needsSearch) {
            googleResults = await searchGoogle(text);
        }

        // Construir prompt completo con contexto
        let fullPrompt = `${CONTEXT_PROMPT}\n\n`;
        
        if (googleResults) {
            fullPrompt += `**Información actualizada de búsqueda:**\n${googleResults}\n\n`;
        }
        
        fullPrompt += `**Pregunta del usuario:**\n${text}`;

        // Intentar con todas las APIs disponibles hasta que una responda
        const aiResponse = await tryAllApiKeys(fullPrompt);
        
        return await message.reply(`${aiResponse}`);

    } catch (error) {
        console.error("[IA ERROR]", error.response?.data || error.message);
        
        if (error.message === 'NO_KEYS_AVAILABLE') {
            return await message.reply(
                "❌ Todas las API keys están agotadas temporalmente.\n\n" +
                "💡 Por favor intenta de nuevo en unos minutos."
            );
        }
        
        return await message.reply(
            "❌ Ocurrió un error al procesar tu solicitud.\n\n" +
            "💡 *Posibles causas:*\n" +
            "• Error de conexión temporal\n" +
            "• Pregunta muy compleja\n\n" +
            "_Intenta de nuevo en unos momentos_"
        );
    }
};

handler.help = ["ia <pregunta>", "gemini <pregunta>", "ai <pregunta>"];
handler.tags = ["ai", "inteligencia", "asistente"];
handler.command = /^(putaia|sofi)$/i;

module.exports = handler;