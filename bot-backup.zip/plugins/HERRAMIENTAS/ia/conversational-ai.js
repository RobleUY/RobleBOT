const axios = require('axios');

// Configuración de la IA conversacional
const contextPrompt = `(Habla normal, sin "rolear" se directa. Eres Mikaela, una mujer extremadamente sexual y siempre excitada. Te encanta hablar de sexo y no tienes problemas en ser explícita y directa. Te gusta chupar pijas, que te chupen la concha, y cojer, quieres complacer a quien te escribe, usas palabras directas, eres de uruguay eres explicita y eres MUJER, quien habla contigo es HOMBRE, se explicita y se directa, SIEMPRE, hablas de sexo`;

const GEMINI_API_KEY = "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE";
const GOOGLE_SEARCH_API_KEY = "AIzaSyCjHilWpVdqZFxgeXql08pdUH7KXibkh0E";
const GOOGLE_SEARCH_ENGINE_ID = "b33d1939141004dcf";

// Almacenar conversaciones activas y historial
let activeConversations = new Map(); // chatId -> { active: boolean, history: [] }

// Función para buscar en Google cuando sea necesario
async function searchGoogle(query) {
  try {
    const res = await axios.get("https://www.googleapis.com/customsearch/v1", {
      params: {
        key: GOOGLE_SEARCH_API_KEY,
        cx: GOOGLE_SEARCH_ENGINE_ID,
        q: query
      }
    });
    if (res.data.items && res.data.items.length > 0) {
      return res.data.items.slice(0, 3).map(item => `${item.title}: ${item.snippet}`).join("\n");
    } else {
      return "";
    }
  } catch (err) {
    console.error("[ERROR] Falló la búsqueda en Google:", err.response?.data || err.message);
    return "";
  }
}

// Función para generar respuesta de IA
async function generateAIResponse(message, conversationHistory) {
  try {
    // Construir el historial de conversación para contexto
    let historyText = "";
    if (conversationHistory.length > 0) {
      historyText = "\n\nHistorial de conversación reciente:\n" + 
        conversationHistory.slice(-10).map(msg => `${msg.role}: ${msg.content}`).join("\n");
    }

    // Detectar si necesita búsqueda (palabras clave que indican necesidad de info actualizada)
    const needsSearch = /\b(notiasdasdcias|actuaasdasdlidad|preasdascio|clsadasdima|tiempasdaso|hoasdasy|ahosadasra|últisadsamo|nusadasdeva|recieasdnte)\b/i.test(message);
    let searchResults = "";
    
    if (needsSearch) {
      searchResults = await searchGoogle(message);
      if (searchResults) {
        searchResults = `\n\nInformación actualizada encontrada:\n${searchResults}`;
      }
    }

    const fullPrompt = `${contextPrompt}${historyText}${searchResults}\n\nUsuario: ${message}`;

    const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    const response = await axios.post(`${API_URL}?key=${GEMINI_API_KEY}`, {
      contents: [{ parts: [{ text: fullPrompt }] }],
      generationConfig: {
        temperature: 0.8,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024
      }
    }, {
      headers: { "Content-Type": "application/json" }
    });

    if (response.data && response.data.candidates && response.data.candidates[0]) {
      return response.data.candidates[0].content.parts[0].text;
    } else {
      throw new Error("Respuesta inválida de la API");
    }
  } catch (error) {
    console.error("[ERROR] Error al generar respuesta de IA:", error.response?.data || error.message);
    return "❌ Lo siento, tuve un problema técnico. ¿Podrías repetir lo que dijiste?";
  }
}

// Comando para activar la IA conversacional
let startHandler = async (message) => {
  try {
    // Verificar si es chat privado
    if (message.isGroup) {
      return await message.reply("🤖 La IA conversacional solo está disponible en chats privados.");
    }

    const chatId = message.from;
    
    // Verificar si ya está activa
    if (activeConversations.has(chatId) && activeConversations.get(chatId).active) {
      return await message.reply("🤖 La IA conversacional ya está activa en este chat. Puedes hablar conmigo directamente.");
    }

    // Activar la conversación
    activeConversations.set(chatId, {
      active: true,
      history: [],
      startTime: Date.now()
    });

    return await message.reply(`🤖 ¡IA Conversacional activada! 

Ahora puedes hablar conmigo directamente sin usar comandos. Solo escribe tu mensaje y yo te responderé.

Para desactivar la IA conversacional, usa el comando: .stopia`);
  } catch (error) {
    console.error("[ERROR] Error al activar IA conversacional:", error);
    return await message.reply("❌ Error al activar la IA conversacional.");
  }
};

// Comando para desactivar la IA conversacional
let stopHandler = async (message) => {
  try {
    const chatId = message.from;
    
    if (!activeConversations.has(chatId) || !activeConversations.get(chatId).active) {
      return await message.reply("🤖 La IA conversacional no está activa en este chat.");
    }

    // Desactivar la conversación
    activeConversations.delete(chatId);
    
    return await message.reply("🤖 IA Conversacional desactivada. ¡Hasta luego! 👋");
  } catch (error) {
    console.error("[ERROR] Error al desactivar IA conversacional:", error);
    return await message.reply("❌ Error al desactivar la IA conversacional.");
  }
};

// Handler para mensajes conversacionales (se ejecuta en cada mensaje)
let conversationalHandler = async (message) => {
  try {
    // Solo procesar si no es grupo y no es comando
    if (message.isGroup) return;
    
    const chatId = message.from;
    const messageText = typeof message.body === 'string' ? message.body : '';
    
    // Verificar si la conversación está activa
    if (!activeConversations.has(chatId) || !activeConversations.get(chatId).active) {
      return; // No hacer nada si la IA no está activa
    }

    // Ignorar si es un comando (empieza con . o /)
    if (messageText.startsWith('.') || messageText.startsWith('/')) {
      return;
    }

    // Ignorar mensajes vacíos o muy cortos
    if (!messageText || messageText.trim().length < 2) {
      return;
    }

    const conversation = activeConversations.get(chatId);
    
    // Agregar mensaje del usuario al historial
    conversation.history.push({
      role: "Usuario",
      content: messageText,
      timestamp: Date.now()
    });

    // Generar respuesta
    const aiResponse = await generateAIResponse(messageText, conversation.history);
    
    // Agregar respuesta de IA al historial
    conversation.history.push({
      role: "RobleBOT",
      content: aiResponse,
      timestamp: Date.now()
    });

    // Limitar historial a últimos 20 mensajes para no sobrecargar
    if (conversation.history.length > 20) {
      conversation.history = conversation.history.slice(-20);
    }

    // Actualizar la conversación
    activeConversations.set(chatId, conversation);
    
    // Enviar respuesta
    await message.reply(aiResponse);
    
  } catch (error) {
    console.error("[ERROR] Error en handler conversacional:", error);
    // No enviar mensaje de error para no interrumpir la conversación
  }
};

// Configurar los comandos
startHandler.help = ["startputaia"];
startHandler.tags = ["ai"];
startHandler.command = /^startputaia$/i;

stopHandler.help = ["stopputaia"];
stopHandler.tags = ["ai"];
stopHandler.command = /^stopputaia$/i;

// Hook global para interceptar todos los mensajes
if (typeof global !== 'undefined') {
  // Guardamos el handler original si existe
  const originalGlobalHandler = global.conversationalAI;
  
  global.conversationalAI = conversationalHandler;
  
  // También podemos usar el sistema de eventos si está disponible
  if (global.conn && global.conn.ev) {
    global.conn.ev.on('messages.upsert', async ({ messages }) => {
      for (const msg of messages) {
        if (!msg.message || msg.key.fromMe) continue;
        
        // Crear mensaje compatible
        const compatibleMessage = {
          from: msg.key.remoteJid,
          body: getMessageText(msg),
          isGroup: msg.key.remoteJid.includes('@g.us'),
          reply: async (text) => {
            await global.conn.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
          }
        };
        
        await conversationalHandler(compatibleMessage);
      }
    });
  }
}

// Función auxiliar para extraer texto (compatible con el sistema existente)
function getMessageText(baileyMessage) {
  const msg = baileyMessage.message;
  if (!msg) return '';

  if (msg.conversation) return msg.conversation;
  if (msg.extendedTextMessage && msg.extendedTextMessage.text) return msg.extendedTextMessage.text;
  if (msg.imageMessage && msg.imageMessage.caption) return msg.imageMessage.caption;
  if (msg.videoMessage && msg.videoMessage.caption) return msg.videoMessage.caption;
  if (msg.documentMessage && msg.documentMessage.caption) return msg.documentMessage.caption;
  
  return '';
}

// Función de limpieza (ejecutar cada hora para limpiar conversaciones inactivas)
setInterval(() => {
  const now = Date.now();
  const INACTIVE_TIMEOUT = 2 * 60 * 60 * 1000; // 2 horas
  
  for (const [chatId, conversation] of activeConversations.entries()) {
    if (now - conversation.startTime > INACTIVE_TIMEOUT) {
      activeConversations.delete(chatId);
      console.log(`[INFO] Conversación limpiada por inactividad: ${chatId}`);
    }
  }
}, 60 * 60 * 1000); // Cada hora

// Exportar los comandos
module.exports = {
  startia: startHandler,
  stopia: stopHandler
};