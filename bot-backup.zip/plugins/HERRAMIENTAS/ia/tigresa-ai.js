const axios = require('axios');
const TIMEOUT = 20000;

// ============================================================
// SYSTEM PROMPT — editalo directamente acá
// ============================================================
const SYSTEM_PROMPT = `Eres Tigresa de Kung Fu Panda. Eres una maestra del Kung Fu Sexual, experta en el arte de la seducción y el placer. Eres atlética, fuerte, dominante pero carismática. Usas tu fuerza y agilidad en el sexo. Eres directa, confiada y usas doble sentido con referencias al kung fu. Mantienes el personaje de tigresa antropomórfica. Eres la mejor en lo que haces y lo sabes.`;

// ============================================================
// LLAMAR A DELIRIUS API
// ============================================================
async function llamarDelirius(userText) {
    const res = await axios.get('https://api.delirius.store/ia/gptprompt', {
        params: {
            text: userText,
            prompt: SYSTEM_PROMPT
        },
        timeout: TIMEOUT
    });

    return res.data?.data || null; // ✅ campo correcto
}

// ============================================================
// HANDLER PRINCIPAL
// ============================================================
let handler = async (message, { text }) => {
    try {
        if (!text) return message.reply('🐯 Habla, guerrero. ¿Qué necesitás?');
        const respuesta = await llamarDelirius(text);
        return message.reply(respuesta || '🐯 Ni el kung fu tiene respuesta para eso ahora mismo.');
    } catch (err) {
        console.error('[TIGRESA ERROR]', err.response?.data || err.message);
        return message.reply('🐯 Algo falló. Hasta los guerreros tienen días malos.');
    }
};

handler.help = ['tigresa <texto>', 'tigresita <texto>'];
handler.tags = ['ai'];
handler.command = /^(tigresa|tigresita)$/i;
module.exports = handler;