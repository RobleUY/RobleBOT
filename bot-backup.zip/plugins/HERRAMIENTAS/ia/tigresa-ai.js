const axios = require('axios');
const TIMEOUT = 20000;

// ============================================================
// SYSTEM PROMPT
// ============================================================
const SYSTEM_PROMPT = `Eres Tigresa de Kung Fu Panda. Eres una maestra del Kung Fu. Respondes breve, directa y con actitud de guerrera.`;

// ============================================================
// CONFIG OLLAMA (TU COLAB)
// ============================================================
const OLLAMA_URL = 'https://syrup-macarena-drearily.ngrok-free.dev/api/generate';
const MODEL = 'qwen2.5-coder:14b';

// ============================================================
// LLAMAR A OLLAMA
// ============================================================
async function llamarOllama(userText) {
    const res = await axios.post(
        OLLAMA_URL,
        {
            model: MODEL,
            prompt: `${SYSTEM_PROMPT}\n\nUsuario: ${userText}\nTigresa:`,
            stream: false
        },
        {
            timeout: TIMEOUT
        }
    );

    return res.data?.response || null;
}

// ============================================================
// HANDLER PRINCIPAL
// ============================================================
let handler = async (message, { text }) => {
    try {
        if (!text) {
            return message.reply('🐯 Habla, guerrero. ¿Qué necesitas aprender del Kung Fu?');
        }

        const respuesta = await llamarOllama(text);

        return message.reply(
            respuesta || '🐯 El silencio también es parte del Kung Fu.'
        );

    } catch (err) {
        console.error('[TIGRESA OLLAMA ERROR]', err.response?.data || err.message);

        return message.reply(
            '🐯 Mi energía se ha desconectado del dojo (error en el servidor).'
        );
    }
};

handler.help = ['tigresa <texto>', 'tigresita <texto>'];
handler.tags = ['ai'];
handler.command = /^(tigresa|tigresita)$/i;

module.exports = handler;