'use strict';
/**
 * Comando: .rp / .reportepsicologo
 * Genera un reporte psicológico completo basado en el historial de chat
 * Uso: .rp o .rp @usuario
 */

const { getUserDb } = require('../../../chatLogger');
const axios = require('axios');

const GROQ_API_KEY = "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";
const MAX_CHARS = 8000;

async function generateReport(prompt) {
    try {
        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: 'llama-3.3-70b-versatile',
                messages: [
                    {
                        role: 'system',
                        content: 'Eres un psicólogo que analiza chats de WhatsApp. Genera reportes BREVES y CONCISOS. Máximo 8-10 oraciones en total. Usa viñetas. Sé directo y profesional. Responde en español.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.8,
                max_tokens: 600
            },
            {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 45000
            }
        );

        return response.data.choices[0].message.content;
    } catch (e) {
        console.error('[reporte-psicologico] Error en Groq:', e.message);
        throw new Error('Error generando reporte: ' + e.message);
    }
}

const handler = async (message, { args }) => {
    try {
        if (!message.isGroup) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Detectar si hay usuario mencionado
        const mentioned = message.mentionedJid?.[0];
        let targetUser = mentioned || message.sender;
        const isSelf = targetUser === message.sender;

        const userNumber = targetUser.split('@')[0].split(':')[0];

        await message.reply('🧠 Generando reporte psicológico... (esto puede tardar un momento)');

        // Obtener mensajes del usuario en este grupo
        const db = getUserDb(userNumber);
        const messages = db.prepare(`
            SELECT content, quoted_content, transcription, timestamp, message_type
            FROM messages
            WHERE group_jid = ?
            ORDER BY timestamp DESC
            LIMIT 300
        `).all(message.from);

        if (messages.length === 0) {
            return message.reply(`📭 No hay mensajes guardados de ${isSelf ? 'ti' : 'ese usuario'} en este grupo.`);
        }

        if (messages.length < 10) {
            return message.reply(`⚠️ Hay muy pocos mensajes (${messages.length}) para generar un reporte confiable. Se necesitan al menos 10 mensajes.`);
        }

        // Construir contexto (hasta 8000 caracteres)
        let context = '';
        let charCount = 0;
        let voiceNoteCount = 0;
        let textCount = 0;
        let quotedCount = 0;

        for (const msg of messages.reverse()) {
            let msgText = '';

            if (msg.quoted_content) {
                msgText += `[Respondiendo a: "${msg.quoted_content}"] `;
                quotedCount++;
            }

            if (msg.transcription) {
                msgText += `(nota de voz) ${msg.transcription}`;
                voiceNoteCount++;
            } else if (msg.content && msg.message_type === 'text') {
                msgText += msg.content;
                textCount++;
            }

            if (msgText.trim()) {
                const line = `- ${msgText}\n`;
                if (charCount + line.length > MAX_CHARS) break;
                context += line;
                charCount += line.length;
            }
        }

        if (!context.trim()) {
            return message.reply('❌ No hay suficiente contenido de texto para analizar.');
        }

        // Construir prompt
        const prompt = `Genera un reporte psicológico BREVE (máximo 8-10 oraciones) basado en estos mensajes de WhatsApp. Analiza:

• Comunicación: Tono y estilo
• Emociones: Estado predominante
• Social: Cómo interactúa
• Personalidad: 2-3 rasgos clave

Estadísticas: ${messages.length} mensajes (${textCount} textos, ${voiceNoteCount} audios, ${quotedCount} respuestas)

Mensajes:
${context}

Reporte breve con viñetas:`;

        // Generar reporte
        const report = await generateReport(prompt);

        const header = isSelf
            ? `🧠 *REPORTE PSICOLÓGICO*\n\n`
            : `🧠 *REPORTE: ${userNumber}*\n\n`;

        const footer = `\n\n📊 ${messages.length} mensajes analizados\n⚠️ _Reporte de IA para entretenimiento_`;

        await message.reply(header + report + footer);

    } catch (e) {
        console.error('[reporte-psicologico] Error:', e);
        await message.reply('❌ Error: ' + e.message);
    }
};

handler.help = ['rp', 'reportepsicologo', 'rs'];
handler.tags = ['ia', 'herramientas'];
handler.command = /^(rp|reportepsicologo|reportepsicologico|rs)$/i;

module.exports = handler;
