const axios = require('axios')
const fs = require('fs')
const path = require('path')

const API_KEY = "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"
const CHAT_USUARIOS_DIR = path.join(__dirname, '../../../CHATS-USUARIOS')
const MAX_CHARS = 15000 // más contexto = análisis más preciso

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

async function groqConRetry(messages, maxTokens = 500, reintentos = 4) {
    for (let intento = 1; intento <= reintentos; intento++) {
        try {
            const res = await axios.post(
                "https://api.groq.com/openai/v1/chat/completions",
                { model: "llama-3.1-8b-instant", messages, temperature: 0.6, max_tokens: maxTokens },
                { headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" }, timeout: 30000 }
            )
            return res.data?.choices?.[0]?.message?.content
        } catch (err) {
            if (err?.response?.status === 429 && intento < reintentos) {
                await sleep(10000 * intento)
            } else throw err
        }
    }
}

function getUserInfo(message, args) {
    // Si menciona a alguien (@user)
    const mentioned = message.mentions?.[0]
    if (mentioned) {
        const numero = mentioned.split('@')[0].replace(/\D/g, '')
        return { numero, jid: mentioned, esPropioUsuario: false }
    }

    // Si escribe "me", "yo" o nada → el propio usuario
    const arg = args?.[0]?.toLowerCase()
    const senderJid = message.sender
    const senderNumero = senderJid.replace(/\D/g, '').replace(/^(\d+).*/, '$1').split('@')[0]

    if (!arg || arg === 'me' || arg === 'yo') {
        return { numero: senderNumero, jid: senderJid, esPropioUsuario: true }
    }

    return { numero: senderNumero, jid: senderJid, esPropioUsuario: true }
}

function leerHistorial(numero, groupId) {
    // Si hay groupId, buscar en esa carpeta; si no (chat privado), buscar en la raíz
    const file = groupId
        ? path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
        : path.join(CHAT_USUARIOS_DIR, `${numero}.txt`)

    if (!fs.existsSync(file)) return null

    let contenido = fs.readFileSync(file, 'utf-8').trim()
    if (!contenido) return null

    // limpiar timestamps del formato [2024-...] texto
    contenido = contenido.split('\n')
        .map(l => l.replace(/^\[.*?\]\s*/, '').trim())
        .filter(Boolean)
        .join('\n')

    if (contenido.length > MAX_CHARS) {
        contenido = '...[historial recortado]\n' + contenido.slice(-MAX_CHARS)
    }

    return contenido
}

async function generarReporte(historial) {
    const prompt = `Eres un psicólogo experto en análisis de comportamiento digital. 
Analiza los siguientes mensajes enviados por una persona en WhatsApp y genera un reporte psicológico detallado.
Algunos mensajes tienen el formato: (respondiendo a NUMERO: "mensaje original") respuesta — esto indica que la persona respondió a ese mensaje.

El reporte debe incluir (de forma breve y directa, sin explayarte):
- Perfil de personalidad
- Estado emocional predominante
- Patrones de comunicación
- Rasgos psicológicos destacados
- Intereses frecuentes
- Observación final

Sé conciso. Máximo 300 palabras en total. Basa todo en los mensajes reales.

MENSAJES DEL USUARIO:
${historial}`

    return await groqConRetry([
        { role: "system", content: "Eres un psicólogo experto. Responde en español, de forma clara y estructurada." },
        { role: "user", content: prompt }
    ], 500)
}

function formatear(texto) {
    if (!texto) return ''
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

let handler = async (message, { args }) => {
    try {
        const { numero, jid, esPropioUsuario } = getUserInfo(message, args)
        const displayName = esPropioUsuario ? 'tuyo' : `@${jid.split('@')[0]}`

        await message.reply('🧠 Analizando historial de mensajes...')

        const historial = leerHistorial(numero, message.from)

        if (!historial) {
            const noDataMsg = esPropioUsuario
                ? '❌ No tengo mensajes tuyos guardados aún. Escribe más en el chat y vuelve a intentarlo.'
                : `❌ No tengo historial de mensajes de @${jid.split('@')[0]}.`
            return message.reply(noDataMsg, { mentions: esPropioUsuario ? [] : [jid] })
        }

        const reporte = await generarReporte(historial)
        const limpio = formatear(reporte)

        const header = esPropioUsuario
            ? `🧠 *Reporte Psicológico* — Tuyo\n${'─'.repeat(30)}\n\n`
            : `🧠 *Reporte Psicológico* — @${jid.split('@')[0]}\n${'─'.repeat(30)}\n\n`

        return message.reply(header + limpio, { mentions: esPropioUsuario ? [] : [jid] })

    } catch (err) {
        console.error('[REPORTE-PSI ERROR]', err?.message || err)
        return message.reply('❌ Error al generar el reporte psicológico.')
    }
}

handler.help = ['rs [@usuario|me]', 'reportepsicologico [@usuario|me]']
handler.tags = ['ai', 'herramientas']
handler.command = /^(rs|reportepsicologico|reporte)$/i

module.exports = handler
