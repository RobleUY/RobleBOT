const axios = require('axios')
const fs = require('fs')
const path = require('path')

const API_KEY = "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"
const CHAT_USUARIOS_DIR = path.join(__dirname, '../../../CHATS-USUARIOS')
const MAX_CHARS = 6000 // Suficiente contexto para un análisis rápido

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

async function groqConRetry(messages, maxTokens = 600) {
    try {
        const res = await axios.post(
            "https://api.groq.com/openai/v1/chat/completions",
            { 
                model: "llama-3.1-8b-instant", 
                messages, 
                temperature: 0.5, // Menos temperatura = respuestas más directas y menos "alucinadas"
                max_tokens: maxTokens 
            },
            { headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" }, timeout: 25000 }
        )
        return res.data?.choices?.[0]?.message?.content
    } catch (err) {
        throw err
    }
}

function getUserInfo(message, args) {
    const mentioned = message.mentions?.[0]
    if (mentioned) return { numero: mentioned.split('@')[0].replace(/\D/g, ''), jid: mentioned, esPropioUsuario: false }
    
    const senderJid = message.sender
    const senderNumero = senderJid.replace(/\D/g, '').replace(/^(\d+).*/, '$1')
    return { numero: senderNumero, jid: senderJid, esPropioUsuario: true }
}

function leerHistorial(numero, groupId) {
    const file = groupId ? path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`) : path.join(CHAT_USUARIOS_DIR, `${numero}.txt`)
    if (!fs.existsSync(file)) return null
    let contenido = fs.readFileSync(file, 'utf-8').trim()
    if (!contenido) return null

    // Tomar solo los últimos mensajes para que el análisis sea sobre lo más reciente y no pese tanto
    const lineas = contenido.split('\n').map(l => l.replace(/^\[.*?\]\s*/, '').trim()).filter(Boolean)
    return lineas.slice(-60).join('\n') // Analiza los últimos 60 mensajes únicamente
}

async function generarReporte(historial) {
    const prompt = `Analiza estos mensajes y genera un reporte PSICOLÓGICO FLASH.
REGLA DE ORO: Máximo 2 frases cortas por sección. Sé muy directo, casi rudo.

Formato:
- *Personalidad:* [Resumen]
- *Ánimo:* [Estado actual]
- *Comunicación:* [Estilo]
- *Rasgos:* [2 rasgos clave]
- *Intereses:* [Temas]
- *Conclusión:* [Consejo breve]

MENSAJES:
${historial}`

    return await groqConRetry([
        { role: "system", content: "Eres un psicólogo clínico que hace diagnósticos rápidos y breves. No saludes. No des introducciones. Usa español." },
        { role: "user", content: prompt }
    ])
}

function formatear(texto) {
    return texto.replace(/\*\*/g, '*').replace(/#{1,}/g, '').trim()
}

let handler = async (message, { args }) => {
    try {
        const { numero, jid, esPropioUsuario } = getUserInfo(message, args)
        await message.reply('🔍 *Analizando rápidamente...*')

        const historial = leerHistorial(numero, message.from)
        if (!historial) return message.reply('❌ Sin datos.')

        const reporte = await generarReporte(historial)
        const limpio = formatear(reporte)

        const header = `🧠 *PERFIL PSICOLÓGICO* (@${numero})\n\n`
        return message.reply(header + limpio, { mentions: [jid] })

    } catch (err) {
        return message.reply('❌ Error en el análisis.')
    }
}

handler.help = ['reporte']
handler.tags = ['ai']
handler.command = /^(rs|reportepsicologico|reporte)$/i

module.exports = handler