const axios = require('axios')

const HARDCODED_FALLBACK_KEY = "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"
const MODEL_LIST = ['openai/gpt-oss-20b','openai/gpt-oss-120b','qwen/qwen3-32b','meta-llama/llama-4-scout-17b-16e-instruct','llama-3.3-70b-versatile','llama-3.3-8b-instant','llama-3.1-8b-instant']

function collectGroqKeys() {
    const keys = new Set();
    const variations = [
        'groq_api_key', 'GROQ_API_KEY',
        'groq_api_key1', 'GROQ_API_KEY1',
        'groq_api_key2', 'GROQ_API_KEY2',
        'groq_api_key3', 'GROQ_API_KEY3',
        'groq_api_key4', 'GROQ_API_KEY4'
    ];
    for (const name of variations) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    if (keys.size === 0 && HARDCODED_FALLBACK_KEY) keys.add(HARDCODED_FALLBACK_KEY);
    return Array.from(keys);
}

let handler = async (message, { text }) => {
    try {
        if (!text || text.trim().length < 2) { 
            return message.reply('❌ Uso: `.tradai <texto> en <idioma>`\nEj: `.tradai hola en inglés`')
        }

        const keys = collectGroqKeys();
        let res = null;
        let lastErr = null;
        for (let i = 0; i < keys.length; i++) {
            const key = keys[i];
            try {
                res = await axios.post(
                    "https://api.groq.com/openai/v1/chat/completions",
                    {
                        model: "llama-3.3-70b-versatile",
                        messages: [
                            {
                                role: "system",
                                content: "Eres un traductor. El usuario te enviará un mensaje indicando qué traducir y a qué idioma. Identifica el texto a traducir y el idioma destino, luego responde ÚNICAMENTE con la traducción en ese idioma. Sin explicaciones, sin comillas, sin texto adicional. Ejemplo: 'como se dice hola en inglés' → 'Hello'"
                            },
                            {
                                role: "user",
                                content: text
                            }
                        ],
                        temperature: 0.3,
                        max_tokens: 300
                    },
                    {
                        headers: {
                            "Authorization": `Bearer ${key}`,
                            "Content-Type": "application/json"
                        },
                        timeout: 15000
                    }
                );
                break;
            } catch (err) {
                lastErr = err;
                const status = err.response?.status;
                const apiErrCode = err.response?.data?.error?.code;
                console.log(`[TRADAI] ⚠️ Key ${i + 1} failed (status=${status} code=${apiErrCode}). Trying next key.`);
                if (i === keys.length - 1) throw err;
                if (status && ![401,403,429].includes(status) && apiErrCode !== 'rate_limit_exceeded') throw err;
            }
        }

        const traduccion = res.data?.choices?.[0]?.message?.content?.trim()
        if (!traduccion) return message.reply('❌ No se pudo traducir.')

        return message.reply(`🌐 *Traducción:*\n${traduccion}`)

    } catch (err) {
        console.error('[TRADAI ERROR]', err?.message || err)
        return message.reply('❌ Error al traducir.')
    }
}

handler.help = ['tradai <texto> en <idioma>']
handler.tags = ['ai', 'herramientas']
handler.command = /^(tradai|trad|tradc|tradcur|traductor|traducir|translate)$/i

module.exports = handler
