const axios = require('axios')

const API_KEY = "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"

let handler = async (message, { text }) => {
    try {
        if (!text || text.trim().length < 2) { 
            return message.reply('❌ Uso: `.tradai <texto> en <idioma>`\nEj: `.tradai hola en inglés`')
        }

        const res = await axios.post(
            "https://api.groq.com/openai/v1/chat/completions",
            {
                model: "llama-3.3-70b-versatile",
                messages: [
                    {
                        role: "system",
                        content: "Eres un traductor. El usuario te enviará un mensaje indicando qué traducir y a qué idioma. Identifica el texto a traducir y el idioma destino, luego responde ÚNICAMENTE con la traducción en ese idioma. Sin explicaciones, sin comillas, sin texto adicional. Ejemplo: 'como se dice hola en inglés' → 'Hello'"
                    },
                    {
                        role: "user",
                        content: text
                    }
                ],
                temperature: 0.3,
                max_tokens: 300
            },
            {
                headers: {
                    "Authorization": `Bearer ${API_KEY}`,
                    "Content-Type": "application/json"
                },
                timeout: 15000
            }
        )

        const traduccion = res.data?.choices?.[0]?.message?.content?.trim()
        if (!traduccion) return message.reply('❌ No se pudo traducir.')

        return message.reply(`🌐 *Traducción:*\n${traduccion}`)

    } catch (err) {
        console.error('[TRADAI ERROR]', err?.message || err)
        return message.reply('❌ Error al traducir.')
    }
}

handler.help = ['tradai <texto> en <idioma>']
handler.tags = ['ai', 'herramientas']
handler.command = /^tradai$/i

module.exports = handler
