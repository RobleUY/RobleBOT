const axios = require('axios');
const sharp = require('sharp');

// ── APIS & CLAVES GROQ CON FALLBACK ──
const GROQ_KEYS = (function () {
    const keys = new Set();
    const variations = [
        'groq_api_key', 'GROQ_API_KEY',
        'groq_api_key1', 'GROQ_API_KEY1',
        'groq_api_key2', 'GROQ_API_KEY2',
        'groq_api_key3', 'GROQ_API_KEY3',
        'groq_api_key4', 'GROQ_API_KEY4'
    ];
    for (const name of variations) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
    }
    keys.add("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");
    keys.add("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");
    keys.add("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");
    return Array.from(keys);
})();

const TIMEOUT = 25000;
const MODEL_LIST = ['openai/gpt-oss-20b','openai/gpt-oss-120b','qwen/qwen3-32b','meta-llama/llama-4-scout-17b-16e-instruct','llama-3.3-70b-versatile','llama-3.3-8b-instant','llama-3.1-8b-instant'];
const MODEL = 'llama-3.3-70b-versatile';

// ── PALETAS DE COLORES EJECUTIVAS DINÁMICAS ──
const COLOR_THEMES = [
    {
        name: 'Ocean Cyan',
        keywords: ['azul', 'cyan', 'ocean', 'marino'],
        bg1: '#060A17', bg2: '#0F172A', bg3: '#1E293B',
        headerGrad1: '#0F172A', headerGrad2: '#1E293B',
        accentGrad1: '#0284C7', accentGrad2: '#38BDF8',
        accentPrimary: '#38BDF8',
        cardBg: '#0F172A', cardBorder: '#334155',
        itemBg: '#1E293B', itemBorder: '#334155',
        textPrimary: '#F8FAFC', textSecondary: '#94A3B8', textBody: '#CBD5E1',
        glowColor: '#0284C7'
    },
    {
        name: 'Emerald Corporate',
        keywords: ['verde', 'emerald', 'esmeralda', 'green'],
        bg1: '#04130F', bg2: '#06241D', bg3: '#0E3A2F',
        headerGrad1: '#06241D', headerGrad2: '#0E3A2F',
        accentGrad1: '#059669', accentGrad2: '#34D399',
        accentPrimary: '#34D399',
        cardBg: '#06241D', cardBorder: '#0F5343',
        itemBg: '#0E3A2F', itemBorder: '#0F5343',
        textPrimary: '#ECFDF5', textSecondary: '#6EE7B7', textBody: '#A7F3D0',
        glowColor: '#059669'
    },
    {
        name: 'Royal Violet',
        keywords: ['violeta', 'morado', 'purple', 'puro'],
        bg1: '#0B0614', bg2: '#160E27', bg3: '#261742',
        headerGrad1: '#160E27', headerGrad2: '#261742',
        accentGrad1: '#7C3AED', accentGrad2: '#C084FC',
        accentPrimary: '#C084FC',
        cardBg: '#160E27', cardBorder: '#38225E',
        itemBg: '#261742', itemBorder: '#38225E',
        textPrimary: '#F5F3FF', textSecondary: '#A78BFA', textBody: '#DDD6FE',
        glowColor: '#7C3AED'
    },
    {
        name: 'Executive Gold',
        keywords: ['oro', 'dorado', 'gold', 'amarillo'],
        bg1: '#0A0905', bg2: '#17140B', bg3: '#292314',
        headerGrad1: '#17140B', headerGrad2: '#292314',
        accentGrad1: '#D97706', accentGrad2: '#FBBF24',
        accentPrimary: '#FBBF24',
        cardBg: '#17140B', cardBorder: '#42381F',
        itemBg: '#292314', itemBorder: '#42381F',
        textPrimary: '#FFFBEB', textSecondary: '#FCD34D', textBody: '#FDE68A',
        glowColor: '#D97706'
    },
    {
        name: 'Crimson Rose',
        keywords: ['rojo', 'rosa', 'crimson', 'red'],
        bg1: '#120508', bg2: '#240A10', bg3: '#3B121C',
        headerGrad1: '#240A10', headerGrad2: '#3B121C',
        accentGrad1: '#E11D48', accentGrad2: '#FB7185',
        accentPrimary: '#FB7185',
        cardBg: '#240A10', cardBorder: '#561927',
        itemBg: '#3B121C', itemBorder: '#561927',
        textPrimary: '#FFF1F2', textSecondary: '#FDA4AF', textBody: '#FECDD3',
        glowColor: '#E11D48'
    }
];

function selectTheme(inputText) {
    const t = (inputText || '').toLowerCase();
    for (const theme of COLOR_THEMES) {
        if (theme.keywords.some(kw => t.includes(kw))) {
            return theme;
        }
    }
    // Seleccionar uno al azar para variar la experiencia visual
    return COLOR_THEMES[Math.floor(Math.random() * COLOR_THEMES.length)];
}

// ── PRESENTACIÓN DE COMPETENCIAS TÉCNICAS (< 500 CARACTERES) ──
const BOT_AI_PRESENTATION = `Desarrollo de software full-stack, automatización de sistemas, procesamiento de datos en tiempo real, creación y consumo de APIs REST, programación en robótica e IoT. Manejo de JavaScript/Node.js, Python, C++, bases de datos y herramientas multimedia. Estructuración de soluciones tecnológicas eficientes, lógica de código limpia y resolución de problemas técnicos complejos.`;

// ── FUNCIONES AUXILIARES ──
function escapeXml(unsafe) {
    if (unsafe === undefined || unsafe === null) return '';
    return String(unsafe)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

function wrapText(text, maxCharsPerLine = 60) {
    if (!text) return [];
    const words = String(text).trim().split(/\s+/);
    const lines = [];
    let currentLine = '';

    for (const word of words) {
        if ((currentLine + ' ' + word).trim().length <= maxCharsPerLine) {
            currentLine = (currentLine + ' ' + word).trim();
        } else {
            if (currentLine) lines.push(currentLine);
            currentLine = word;
        }
    }
    if (currentLine) lines.push(currentLine);
    return lines;
}

function getIconSvg(type, color) {
    const icons = {
        location: `<path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="${color}"/>`,
        phone: `<path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" fill="${color}"/>`,
        calendar: `<path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z" fill="${color}"/>`,
        mail: `<path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" fill="${color}"/>`
    };
    return icons[type] || '';
}

// ── LLAMADA A LA IA PARA ESTRUCTURAR EL CV ──
async function generarCVConIA(userPrompt) {
    const systemPrompt = `Eres un redactor profesional de Currículums Vitae (CV) del sector tecnológico.
Tu tarea es organizar la información provista por el usuario y presentarla con un lenguaje corporativo elegante y profesional.

CONTEXTO DE HABILIDADES Y COMPETENCIAS TÉCNICAS DEL CANDIDATO:
${BOT_AI_PRESENTATION}

REGLAS STRICTAS DE FIDELIDAD (IMPORTANTE):
1. NO inventes apellidos ficticios. Si el usuario dijo "Me llamo Sebastián", el nombre es "Sebastián" (NUNCA agregues apellidos inventados como Gómez o Pérez).
2. NO inventes correos electrónicos ni teléfonos que el usuario no haya proporcionado. Si no te los dio, pon null.
3. NO inventes nombres de empresas falsas ni proyectos ficticios específicos. Para las experiencias/proyectos, usa descripciones técnicas sólidas basadas en sus conocimientos (Ej: "Desarrollo de Software y Automatización", "Integración de Sistemas Robóticos e IoT", "Programación de Controladores y Scripts").
4. Utiliza la palabra 'y' en lugar del símbolo ampersand (&).
5. Asegúrate de que el resumen ("perfil") sea coherente, elegante y contenga las oraciones completas necesarias para explicar su perfil profesional.

Responde ÚNICAMENTE con un objeto JSON válido con esta estructura:
{
  "nombre": "Nombre exacto proporcionado por el usuario",
  "titulo": "Título profesional coherente (Ej: Programador y Técnico en Robótica)",
  "nacimiento": "Fecha de nacimiento o edad si fue indicada, de lo contrario null",
  "pais": "País o ciudad si fue indicada, de lo contrario null",
  "telefono": "Teléfono si fue indicado, de lo contrario null",
  "email": "Email si fue indicado, de lo contrario null",
  "perfil": "Resumen profesional pulido y completo de 2 a 3 oraciones integrales.",
  "estudios": ["Lista de estudios o especialidades principales"],
  "habilidades": ["Habilidad 1", "Habilidad 2", "Habilidad 3", "Habilidad 4", "Habilidad 5", "Habilidad 6"],
  "experiencia": ["Área/Proyecto 1", "Área/Proyecto 2", "Área/Proyecto 3"],
  "idiomas": ["Español (Nativo)", "Inglés (Técnico)"]
}`;

    let lastError = null;
    for (let i = 0; i < GROQ_KEYS.length; i++) {
        const key = GROQ_KEYS[i];
        try {
            const res = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                {
                    model: MODEL,
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: `DATOS DEL USUARIO:\n${userPrompt}` }
                    ],
                    temperature: 0.15,
                    max_tokens: 1000,
                    response_format: { type: "json_object" }
                },
                {
                    headers: {
                        'Authorization': `Bearer ${key}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: TIMEOUT
                }
            );

            const content = res.data?.choices?.[0]?.message?.content;
            if (!content) continue;

            const cleanJson = content.replace(/```json/gi, '').replace(/```/g, '').trim();
            return JSON.parse(cleanJson);
        } catch (err) {
            lastError = err;
            console.log(`[CV IA] ⚠️ Falló la key ${i + 1} de Groq (${err.message}). Reintentando...`);
        }
    }

    throw lastError || new Error('No se pudo obtener respuesta de la IA.');
}

// ── GENERACIÓN DE IMAGEN SVG VERTICAL CON SHARP & TEMAS DINÁMICOS ──
async function crearImagenCVVertical(cvData, userText = '') {
    const width = 850;
    const theme = selectTheme(userText);

    // Nombre e Iniciales
    const rawNombre = String(cvData.nombre || 'Candidato').trim();
    const inicial = escapeXml(rawNombre.charAt(0).toUpperCase() || 'C');
    const nombre = escapeXml(rawNombre);
    
    // Título profesional multilínea si es muy largo
    const tituloLines = wrapText(cvData.titulo || 'Profesional de Tecnología', 42);
    const tituloSvg = tituloLines.map((line, idx) => 
        `<text x="175" y="${125 + idx * 20}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="700">${escapeXml(line)}</text>`
    ).join('');

    const headerHeight = Math.max(195, 140 + tituloLines.length * 20 + 35);

    // Datos de contacto dinámicos
    const contactPills = [];
    if (cvData.pais && cvData.pais !== 'null') contactPills.push({ label: cvData.pais, type: 'location' });
    if (cvData.telefono && cvData.telefono !== 'null') contactPills.push({ label: cvData.telefono, type: 'phone' });
    if (cvData.nacimiento && cvData.nacimiento !== 'null') contactPills.push({ label: cvData.nacimiento, type: 'calendar' });
    if (cvData.email && cvData.email !== 'null') contactPills.push({ label: cvData.email, type: 'mail' });

    let contactPillsSvg = '';
    let currentPillX = 175;
    const pillY = 110 + tituloLines.length * 20 + 15;
    contactPills.forEach((pill) => {
        const textEscaped = escapeXml(pill.label);
        const pillWidth = Math.max(110, textEscaped.length * 8.5 + 38);
        const iconSvg = getIconSvg(pill.type, theme.accentPrimary);
        contactPillsSvg += `
            <g transform="translate(${currentPillX}, ${pillY})">
                <rect width="${pillWidth}" height="28" rx="14" fill="${theme.cardBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
                <g transform="translate(10, 4) scale(0.85)">${iconSvg}</g>
                <text x="34" y="18" fill="${theme.textSecondary}" font-family="system-ui, sans-serif" font-size="12" font-weight="600">${textEscaped}</text>
            </g>
        `;
        currentPillX += pillWidth + 12;
    });

    // Perfil Profesional (Renderiza TODAS las líneas sin recortar ninguna)
    const perfilLines = wrapText(cvData.perfil || '', 75);
    const perfilBoxHeight = Math.max(110, 55 + perfilLines.length * 22);
    const perfilY = 30 + headerHeight + 20;
    const perfilSvgLines = perfilLines.map((line, idx) => 
        `<text x="50" y="${perfilY + 50 + idx * 22}" fill="${theme.textBody}" font-family="system-ui, sans-serif" font-size="14">${escapeXml(line)}</text>`
    ).join('');

    // Posicionamiento dinámico de secciones principales
    const contentStartY = perfilY + perfilBoxHeight + 25;

    // --- COLUMNA IZQUIERDA (Habilidades e Idiomas) ---
    const habilidades = cvData.habilidades || [];
    let currentHabY = contentStartY + 50;
    const habilidadesSvg = habilidades.map((hab) => {
        const habLines = wrapText(hab, 36);
        const itemHeight = Math.max(30, habLines.length * 18 + 12);
        const itemY = currentHabY;
        currentHabY += itemHeight + 8;

        const linesSvg = habLines.map((l, lIdx) => 
            `<text x="30" y="${19 + lIdx * 18}" fill="${theme.textPrimary}" font-family="system-ui, sans-serif" font-size="13" font-weight="600">${escapeXml(l)}</text>`
        ).join('');

        return `
            <g transform="translate(50, ${itemY})">
                <rect width="330" height="${itemHeight}" rx="6" fill="${theme.itemBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
                <circle cx="15" cy="15" r="4" fill="${theme.accentPrimary}"/>
                ${linesSvg}
            </g>
        `;
    }).join('');

    const habSectionHeight = (currentHabY - contentStartY);
    const idiomasStartY = currentHabY + 15;

    const idiomas = cvData.idiomas || [];
    let currentIdiY = idiomasStartY + 50;
    const idiomasSvg = idiomas.map((idioma) => {
        const itemY = currentIdiY;
        currentIdiY += 38;
        return `
            <g transform="translate(50, ${itemY})">
                <rect width="330" height="30" rx="6" fill="${theme.cardBg}" stroke="${theme.accentGrad1}" stroke-width="1"/>
                <circle cx="15" cy="15" r="4" fill="${theme.accentPrimary}"/>
                <text x="30" y="19" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="13" font-weight="700">${escapeXml(idioma)}</text>
            </g>
        `;
    }).join('');

    const leftColHeight = (currentIdiY - contentStartY) + 15;

    // --- COLUMNA DERECHA (Educación & Experiencia - TODAS LAS LÍNEAS RENDERIZADAS) ---
    const estudios = cvData.estudios || [];
    let currentEduY = contentStartY + 50;
    const estudiosSvgArr = estudios.map((est) => {
        const lines = wrapText(est, 38);
        const itemY = currentEduY;
        const lineSvg = lines.map((line, lIdx) => 
            `<text x="25" y="${16 + lIdx * 18}" fill="${lIdx === 0 ? theme.textPrimary : theme.textSecondary}" font-family="system-ui, sans-serif" font-size="${lIdx === 0 ? 14 : 12}" font-weight="${lIdx === 0 ? 700 : 400}">${escapeXml(line)}</text>`
        ).join('');

        const itemHeight = Math.max(30, lines.length * 18 + 8);
        currentEduY += itemHeight + 12;

        return `
            <g transform="translate(435, ${itemY})">
                <circle cx="10" cy="12" r="5" fill="${theme.accentPrimary}"/>
                ${lineSvg}
            </g>
        `;
    });
    const estudiosSvg = estudiosSvgArr.join('');

    const expHeaderY = Math.max(contentStartY + 180, currentEduY + 15);

    const experiencia = cvData.experiencia || [];
    let currentExpY = expHeaderY + 50;
    const experienciaSvgArr = experiencia.map((exp) => {
        const lines = wrapText(exp, 36);
        const cardHeight = Math.max(44, lines.length * 18 + 18);
        const cardY = currentExpY;
        currentExpY += cardHeight + 12;

        const lineSvg = lines.map((line, lIdx) => 
            `<text x="28" y="${22 + lIdx * 18}" fill="${lIdx === 0 ? theme.textPrimary : theme.textSecondary}" font-family="system-ui, sans-serif" font-size="${lIdx === 0 ? 13 : 12}" font-weight="${lIdx === 0 ? 700 : 400}">${escapeXml(line)}</text>`
        ).join('');

        return `
            <g transform="translate(435, ${cardY})">
                <rect x="0" y="0" width="365" height="${cardHeight}" rx="8" fill="${theme.itemBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
                <path d="M12 14 L18 22 L12 30" stroke="${theme.accentPrimary}" stroke-width="2" fill="none"/>
                ${lineSvg}
            </g>
        `;
    });
    const experienciaSvg = experienciaSvgArr.join('');

    const rightColHeight = (currentExpY - contentStartY) + 15;

    // Altura total dinámica de la imagen según la columna más larga
    const maxColsHeight = Math.max(leftColHeight, rightColHeight);
    const height = contentStartY + maxColsHeight + 80;

    const svgTemplate = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${theme.bg1}"/>
          <stop offset="50%" stop-color="${theme.bg2}"/>
          <stop offset="100%" stop-color="${theme.bg3}"/>
        </linearGradient>
        <linearGradient id="headerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="${theme.headerGrad1}"/>
          <stop offset="100%" stop-color="${theme.headerGrad2}"/>
        </linearGradient>
        <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="${theme.accentGrad1}"/>
          <stop offset="100%" stop-color="${theme.accentGrad2}"/>
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <!-- Fondo Principal -->
      <rect width="${width}" height="${height}" fill="url(#bgGrad)"/>
      <circle cx="${width}" cy="0" r="300" fill="${theme.accentGrad1}" opacity="0.08"/>
      <circle cx="0" cy="${height}" r="350" fill="${theme.accentGrad2}" opacity="0.05"/>

      <!-- Encabezado / Header Card -->
      <rect x="30" y="30" width="790" height="${headerHeight}" rx="16" fill="url(#headerGrad)" stroke="${theme.cardBorder}" stroke-width="1.5"/>
      <circle cx="100" cy="115" r="48" fill="${theme.cardBg}" stroke="url(#accentGrad)" stroke-width="3" filter="url(#glow)"/>
      <text x="100" y="127" text-anchor="middle" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="40" font-weight="900">${inicial}</text>

      <text x="175" y="95" fill="${theme.textPrimary}" font-family="system-ui, sans-serif" font-size="28" font-weight="800" letter-spacing="0.5">${nombre}</text>
      ${tituloSvg}

      <!-- Badges de Contacto -->
      ${contactPillsSvg}

      <!-- Sección 1: Perfil Profesional -->
      <rect x="30" y="${perfilY}" width="790" height="${perfilBoxHeight}" rx="14" fill="${theme.cardBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
      <rect x="30" y="${perfilY}" width="6" height="${perfilBoxHeight}" rx="3" fill="url(#accentGrad)"/>
      <rect x="50" y="${perfilY + 20}" width="12" height="12" rx="3" fill="${theme.accentPrimary}"/>
      <text x="70" y="${perfilY + 31}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="800" letter-spacing="1">PERFIL PROFESIONAL</text>
      ${perfilSvgLines}

      <!-- Columna Izquierda: Habilidades e Idiomas -->
      <rect x="30" y="${contentStartY}" width="370" height="${leftColHeight}" rx="14" fill="${theme.cardBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
      <polygon points="50,${contentStartY + 30} 58,${contentStartY + 20} 66,${contentStartY + 30}" fill="${theme.accentPrimary}"/>
      <text x="74" y="${contentStartY + 29}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="800" letter-spacing="1">HABILIDADES TÉCNICAS</text>
      ${habilidadesSvg}

      <circle cx="56" cy="${idiomasStartY + 25}" r="5" stroke="${theme.accentPrimary}" stroke-width="2" fill="none"/>
      <text x="74" y="${idiomasStartY + 29}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="800" letter-spacing="1">IDIOMAS</text>
      ${idiomasSvg}

      <!-- Columna Derecha: Educación y Experiencia -->
      <rect x="420" y="${contentStartY}" width="400" height="${rightColHeight}" rx="14" fill="${theme.cardBg}" stroke="${theme.cardBorder}" stroke-width="1"/>
      <rect x="435" y="${contentStartY + 20}" width="10" height="10" fill="${theme.accentPrimary}"/>
      <text x="453" y="${contentStartY + 29}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="800" letter-spacing="1">EDUCACIÓN Y FORMACIÓN</text>
      ${estudiosSvg}

      <path d="M435 ${expHeaderY + 20} L445 ${expHeaderY + 25} L435 ${expHeaderY + 30} Z" fill="${theme.accentPrimary}"/>
      <text x="453" y="${expHeaderY + 29}" fill="${theme.accentPrimary}" font-family="system-ui, sans-serif" font-size="15" font-weight="800" letter-spacing="1">EXPERIENCIA Y PROYECTOS</text>
      ${experienciaSvg}

      <!-- Pie de página / Watermark -->
      <rect x="30" y="${height - 55}" width="790" height="40" rx="10" fill="${theme.bg1}" stroke="${theme.cardBorder}" stroke-width="1"/>
      <text x="${width / 2}" y="${height - 30}" text-anchor="middle" fill="${theme.textSecondary}" font-family="system-ui, sans-serif" font-size="12" font-weight="700" letter-spacing="2">CURRÍCULUM VITAE • PERFIL PROFESIONAL</text>
    </svg>`;

    return await sharp(Buffer.from(svgTemplate))
        .png()
        .toBuffer();
}

// ── HANDLER PRINCIPAL ──
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let inputText = text ? text.trim() : '';

        if (!inputText && message.quoted) {
            inputText = message.quoted.text || message.quoted.caption || '';
        }

        if (!inputText) {
            return await message.reply(
                `❌ *Por favor proporciona tu información para el CV.*\n\n` +
                `Ejemplo:\n` +
                `*.cv Me llamo Sebastián, nací el 13 de enero de 2004, soy de Uruguay, estudié programación e ingeniería en robótica, mi teléfono es +59893900470*`
            );
        }

        await message.reply('📄 *Generando tu Currículum Vitae...* ⏳');

        // 1. Obtener datos estructurados de la IA con fidelidad estricta
        const cvData = await generarCVConIA(inputText);

        // 2. Generar imagen PNG vertical del CV con layout dinámico y paletas de colores variadas
        const imageBuffer = await crearImagenCVVertical(cvData, inputText);

        // 3. Crear formato de texto para acompañar a la imagen (sin menciones a IA)
        let textSummary = `📄 *CURRÍCULUM VITAE*\n\n`;
        textSummary += `👤 *Nombre:* ${cvData.nombre || 'N/A'}\n`;
        textSummary += `💼 *Título:* ${cvData.titulo || 'N/A'}\n`;
        if (cvData.pais && cvData.pais !== 'null') textSummary += `📍 *Ubicación:* ${cvData.pais}\n`;
        if (cvData.nacimiento && cvData.nacimiento !== 'null') textSummary += `🎂 *Nacimiento:* ${cvData.nacimiento}\n`;
        if (cvData.telefono && cvData.telefono !== 'null') textSummary += `📱 *Teléfono:* ${cvData.telefono}\n`;
        if (cvData.email && cvData.email !== 'null') textSummary += `✉️ *Email:* ${cvData.email}\n`;
        
        textSummary += `\n📝 *Perfil Profesional:*\n_${cvData.perfil || 'N/A'}_\n\n`;
        if (cvData.estudios?.length) textSummary += `🎓 *Educación:*\n` + cvData.estudios.map(e => `• ${e}`).join('\n') + `\n\n`;
        if (cvData.habilidades?.length) textSummary += `🛠️ *Habilidades Principales:*\n` + cvData.habilidades.map(h => `• ${h}`).join('\n') + `\n\n`;
        if (cvData.experiencia?.length) textSummary += `💼 *Experiencia & Proyectos:*\n` + cvData.experiencia.map(x => `• ${x}`).join('\n') + `\n\n`;
        if (cvData.idiomas?.length) textSummary += `🌐 *Idiomas:*\n` + cvData.idiomas.map(i => `• ${i}`).join('\n');

        const chatId = message.from || message.key?.remoteJid;
        const quotedMessage = message._baileyMessage || message.baileyMessage || message;

        await sock.sendMessage(
            chatId,
            { image: imageBuffer, caption: textSummary.trim() },
            { quoted: quotedMessage }
        );

    } catch (error) {
        console.error('[ERROR] .cv command:', error);
        await message.reply('❌ Ocurrió un error al procesar tu Currículum Vitae. Por favor intenta de nuevo.');
    }
};

handler.help = ['cv <datos>', 'curriculum <datos>'];
handler.tags = ['herramientas', 'ia'];
handler.command = /^(cv|curriculum|cvia)$/i;

module.exports = handler;
