const yts = require('yt-search'); // Búsqueda en YouTube

// --- Handler ---
let handler = async (message, { text, usedPrefix, command }) => {
    if (!text) return await message.reply(`❌ Envía un término para buscar en YouTube.\nEjemplo:\n• ${usedPrefix + command} Robleuy`);

    try {
        await message.reply(`🔍 Buscando "${text}" en YouTube...`);

        const r = await yts(text);
        if (!r?.videos?.length) return await message.reply('❌ No se encontraron resultados.');

        // Tomamos los primeros 5 resultados (puedes cambiar el número)
        const results = r.videos.slice(0, 10)
            .map((v, i) => `🔹 ${i + 1}. ${v.title}\n${v.url}`)
            .join('\n\n');

        await message.reply(`🎵 Resultados de búsqueda:\n\n${results}`);

    } catch (err) {
        console.error('[YTS] Error:', err.message);
        await message.reply('❌ Ocurrió un error al buscar en YouTube.');
    }
};

handler.help = ['ytsearch <término>'];
handler.tags = ['search', 'youtube'];
handler.command = /^(ytsearch|yts)$/i;

module.exports = handler;
