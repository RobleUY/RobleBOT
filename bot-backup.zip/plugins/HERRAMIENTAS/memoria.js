/**
 * Comando para ver el estado de la memoria del bot
 * Uso: .memoria
 */

module.exports = {
    command: 'memoria',
    help: 'Ver estado de la memoria del bot',
    tags: ['herramientas'],
    owner: true,

    handler: async (message) => {
        try {
            const usage = process.memoryUsage();
            const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
            const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
            const rssMB = Math.round(usage.rss / 1024 / 1024);
            const externalMB = Math.round(usage.external / 1024 / 1024);
            
            // Uptime
            const uptimeMs = process.uptime() * 1000;
            const uptimeHours = Math.floor(uptimeMs / (60 * 60 * 1000));
            const uptimeMinutes = Math.floor((uptimeMs % (60 * 60 * 1000)) / (60 * 1000));
            
            // Estadísticas globales
            const activeSubbots = global.subConns ? global.subConns.filter(c => c && c.user).length : 0;
            const totalSubbots = global.subConns ? global.subConns.length : 0;
            const users = global.db?.data?.users ? Object.keys(global.db.data.users).length : 0;
            const groups = global.db?.data?.groups ? Object.keys(global.db.data.groups).length : 0;
            const commands = global.commandHandler?.commands ? global.commandHandler.commands.size : 0;
            
            // Monitor stats
            let monitorStats = '';
            if (global.memoryMonitor) {
                const stats = global.memoryMonitor.getStats();
                monitorStats = `\n📊 *Monitor*\n` +
                              `   • Pico: ${stats.peak}MB\n` +
                              `   • Muestras: ${stats.samples}`;
            }
            
            const text = `📊 *ESTADO DE MEMORIA*\n\n` +
                        `⏱️ *Uptime*: ${uptimeHours}h ${uptimeMinutes}m\n\n` +
                        `💾 *Memoria*\n` +
                        `   • Heap: ${heapUsedMB}MB / ${heapTotalMB}MB\n` +
                        `   • RSS: ${rssMB}MB\n` +
                        `   • External: ${externalMB}MB\n` +
                        monitorStats + `\n\n` +
                        `🤖 *Subbots*: ${activeSubbots}/${totalSubbots} activos\n` +
                        `👥 *Usuarios*: ${users}\n` +
                        `👥 *Grupos*: ${groups}\n` +
                        `⚙️ *Comandos*: ${commands}\n\n` +
                        `${heapUsedMB > 600 ? '⚠️ *Memoria alta* - Considera reiniciar' : 
                          heapUsedMB > 400 ? '⚠️ *Memoria moderada*' : 
                          '✅ *Memoria normal*'}`;
            
            await message.reply(text);
            
        } catch (error) {
            console.error('Error en comando memoria:', error.message);
            await message.reply('❌ Error al obtener información de memoria');
        }
    }
};
