const fs = require('fs');
const path = require('path');

// Archivo para guardar los recordatorios
const RECORDATORIOS_FILE = path.join(__dirname, '..', '..', 'data', 'recordatorios.json');

// Mapa para almacenar los timeouts activos
const activeTimeouts = new Map();

// ─── Funciones de utilidad ───────────────────────────────────────────────────

function loadRecordatorios() {
    try {
        if (fs.existsSync(RECORDATORIOS_FILE)) {
            const data = fs.readFileSync(RECORDATORIOS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('❌ Error leyendo recordatorios.json:', error.message);
    }
    return [];
}

function saveRecordatorios(recordatorios) {
    try {
        const dir = path.dirname(RECORDATORIOS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(RECORDATORIOS_FILE, JSON.stringify(recordatorios, null, 2), 'utf8');
    } catch (error) {
        console.error('❌ Error guardando recordatorios.json:', error.message);
    }
}

function parseTime(timeStr) {
    const regex = /^(\d+)(s|second|seconds|segundo|m|minute|minutes|minuto|minutos|h|hour|hours|hora|horas|d|day|days|dia|dias)$/i;
    const match = timeStr.match(regex);
    
    if (!match) return null;
    
    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    let milliseconds;
    
    switch (unit) {
        case 's':
        case 'second':
        case 'seconds':
        case 'segundo':
        case 'segundos':
            milliseconds = value * 1000;
            break;
        case 'm':
        case 'minute':
        case 'minutes':
        case 'minuto':
        case 'minutos':
            milliseconds = value * 60 * 1000;
            break;
        case 'h':
        case 'hour':
        case 'hours':
        case 'hora':
        case 'horas':
            milliseconds = value * 60 * 60 * 1000;
            break;
        case 'd':
        case 'day':
        case 'days':
        case 'dia':
        case 'dias':
            milliseconds = value * 24 * 60 * 60 * 1000;
            break;
        default:
            return null;
    }
    
    return { value, unit, milliseconds };
}

function formatTime(milliseconds) {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} día${days > 1 ? 's' : ''}`;
    if (hours > 0) return `${hours} hora${hours > 1 ? 's' : ''}`;
    if (minutes > 0) return `${minutes} minuto${minutes > 1 ? 's' : ''}`;
    return `${seconds} segundo${seconds > 1 ? 's' : ''}`;
}

function getUserNumber(jid) {
    return jid.split('@')[0].split(':')[0];
}

async function sendReminder(conn, recordatorio) {
    try {
        const userNumber = getUserNumber(recordatorio.userJid);
        const mention = `@${userNumber}`;
        
        await conn.sendMessage(recordatorio.chatId, {
            text: `${mention} 🔔 *Recordatorio:*\n\n${recordatorio.mensaje}`,
            mentions: [recordatorio.userJid]
        });
        
        console.log(`✅ Recordatorio enviado a ${userNumber} en chat ${recordatorio.chatId}`);
    } catch (error) {
        console.error('❌ Error enviando recordatorio:', error.message);
    }
}

function scheduleReminder(conn, recordatorio) {
    const timeoutId = setTimeout(async () => {
        // Enviar el recordatorio
        await sendReminder(conn, recordatorio);
        
        // Remover de la lista de recordatorios activos
        const recordatorios = loadRecordatorios();
        const updatedRecordatorios = recordatorios.filter(r => r.id !== recordatorio.id);
        saveRecordatorios(updatedRecordatorios);
        
        // Remover del mapa de timeouts activos
        activeTimeouts.delete(recordatorio.id);
        
    }, recordatorio.timeRemaining);
    
    activeTimeouts.set(recordatorio.id, timeoutId);
}

function initializeReminders(conn) {
    const recordatorios = loadRecordatorios();
    const now = Date.now();
    
    recordatorios.forEach(recordatorio => {
        const timeRemaining = recordatorio.triggerTime - now;
        
        if (timeRemaining <= 0) {
            // El recordatorio ya debería haber sido enviado
            sendReminder(conn, recordatorio);
        } else {
            // Programar el recordatorio
            recordatorio.timeRemaining = timeRemaining;
            scheduleReminder(conn, recordatorio);
        }
    });
    
    // Limpiar recordatorios vencidos
    const activeRecordatorios = recordatorios.filter(r => r.triggerTime > now);
    if (activeRecordatorios.length !== recordatorios.length) {
        saveRecordatorios(activeRecordatorios);
    }
}

// ─── COMANDO .recordar ───────────────────────────────────────────────────────

let handlerRecordar = async (message, { conn, args, usedPrefix }) => {
    try {
        if (args.length < 2) {
            return await message.reply(
                `📝 *Uso correcto:*\n` +
                `${usedPrefix}recordar <tiempo> <mensaje>\n\n` +
                `*Ejemplos de tiempo:*\n` +
                `• 30s - 30 segundos\n` +
                `• 5m - 5 minutos\n` +
                `• 2h - 2 horas\n` +
                `• 1d - 1 día\n\n` +
                `*Ejemplo completo:*\n` +
                `${usedPrefix}recordar 1h Cerrar el grupo`
            );
        }

        const timeStr = args[0];
        const mensaje = args.slice(1).join(' ');
        
        const timeInfo = parseTime(timeStr);
        if (!timeInfo) {
            return await message.reply(
                `❌ *Formato de tiempo inválido*\n\n` +
                `*Formatos válidos:*\n` +
                `• s, second, seconds, segundo\n` +
                `• m, minute, minutes, minuto, minutos\n` +
                `• h, hour, hours, hora, horas\n` +
                `• d, day, days, dia, dias\n\n` +
                `*Ejemplo:* ${usedPrefix}recordar 30m Revisar el correo`
            );
        }

        // Validar límites de tiempo
        if (timeInfo.milliseconds < 1000) {
            return await message.reply('❌ El tiempo mínimo es 1 segundo.');
        }
        
        if (timeInfo.milliseconds > 30 * 24 * 60 * 60 * 1000) { // 30 días
            return await message.reply('❌ El tiempo máximo es 30 días.');
        }

        const userJid = message.author || message.sender || message.key?.participant || message.from;
        const chatId = message.from;
        const now = Date.now();
        
        // Crear el recordatorio
        const recordatorio = {
            id: now + Math.random().toString(36).substr(2, 9),
            userJid: userJid,
            chatId: chatId,
            mensaje: mensaje,
            createdAt: now,
            triggerTime: now + timeInfo.milliseconds,
            timeRemaining: timeInfo.milliseconds
        };

        // Guardar en archivo
        const recordatorios = loadRecordatorios();
        recordatorios.push(recordatorio);
        saveRecordatorios(recordatorios);

        // Programar el recordatorio
        scheduleReminder(conn, recordatorio);

        // Obtener número del recordatorio (posición en la lista del usuario)
        const userRecordatorios = recordatorios.filter(r => r.userJid === userJid);
        const numeroRecordatorio = userRecordatorios.length;

        const userNumber = getUserNumber(userJid);
        await message.reply(
            `✅ *Recordatorio creado*\n\n` +
            `📝 *Mensaje:* ${mensaje}\n` +
            `⏰ *Tiempo:* ${formatTime(timeInfo.milliseconds)}\n` +
            `🔢 *Número:* ${numeroRecordatorio}\n` +
            `👤 *Para:* @${userNumber}\n\n` +
            `💡 *Tip:* Usa \`${usedPrefix}recordatorio\` para ver todos tus recordatorios`
        );

    } catch (error) {
        console.error('❌ Error en .recordar:', error);
        await message.reply('❌ Ocurrió un error al crear el recordatorio.');
    }
};

handlerRecordar.command = /^recordar$/i;
handlerRecordar.help = ['recordar <tiempo> <mensaje>'];
handlerRecordar.tags = ['herramientas'];

// ─── COMANDO .recordatorio ───────────────────────────────────────────────────

let handlerRecordatorio = async (message, { conn, args, usedPrefix }) => {
    try {
        const userJid = message.author || message.sender || message.key?.participant || message.from;
        const recordatorios = loadRecordatorios();
        const userRecordatorios = recordatorios.filter(r => r.userJid === userJid);

        if (args.length === 0) {
            // Mostrar lista de recordatorios
            if (userRecordatorios.length === 0) {
                return await message.reply('📝 No tienes recordatorios activos.');
            }

            const userNumber = getUserNumber(userJid);
            let texto = `📝 *Recordatorios de @${userNumber}*\n\n`;

            userRecordatorios.forEach((recordatorio, index) => {
                const now = Date.now();
                const timeRemaining = recordatorio.triggerTime - now;
                const timeLeft = formatTime(timeRemaining);
                
                texto += `*${index + 1}.* ${recordatorio.mensaje}\n`;
                texto += `   ⏰ Faltan: ${timeLeft}\n`;
                texto += `   🆔 ID: ${recordatorio.id.substr(-6)}\n\n`;
            });

            texto += `💡 *Tip:* Usa \`${usedPrefix}recordatorio off <número>\` para cancelar`;

            return await conn.sendMessage(message.from, {
                text: texto,
                mentions: [userJid]
            }, { quoted: message._baileyMessage });
        }

        // Comando para cancelar recordatorio
        if (args[0].toLowerCase() === 'off' || args[0].toLowerCase() === 'apagar') {
            if (args.length < 2) {
                return await message.reply(
                    `❌ *Uso correcto:*\n` +
                    `${usedPrefix}recordatorio off <número>\n\n` +
                    `*Ejemplo:* ${usedPrefix}recordatorio off 1`
                );
            }

            const numero = parseInt(args[1]);
            if (isNaN(numero) || numero < 1 || numero > userRecordatorios.length) {
                return await message.reply(
                    `❌ Número de recordatorio inválido.\n` +
                    `Tienes ${userRecordatorios.length} recordatorio(s) activo(s).`
                );
            }

            const recordatorioACancelar = userRecordatorios[numero - 1];
            
            // Cancelar el timeout
            if (activeTimeouts.has(recordatorioACancelar.id)) {
                clearTimeout(activeTimeouts.get(recordatorioACancelar.id));
                activeTimeouts.delete(recordatorioACancelar.id);
            }

            // Remover de la lista
            const todosRecordatorios = loadRecordatorios();
            const recordatoriosActualizados = todosRecordatorios.filter(r => r.id !== recordatorioACancelar.id);
            saveRecordatorios(recordatoriosActualizados);

            await message.reply(
                `✅ *Recordatorio cancelado*\n\n` +
                `📝 *Mensaje:* ${recordatorioACancelar.mensaje}\n` +
                `🔢 *Número:* ${numero}`
            );
        }

    } catch (error) {
        console.error('❌ Error en .recordatorio:', error);
        await message.reply('❌ Ocurrió un error al gestionar los recordatorios.');
    }
};

handlerRecordatorio.command = /^recordatorio$/i;
handlerRecordatorio.help = ['recordatorio', 'recordatorio off <número>'];
handlerRecordatorio.tags = ['herramientas'];

// ─── Inicialización ──────────────────────────────────────────────────────────

// Esta función debe ser llamada cuando el bot se inicie
function initRecordatorios(conn) {
    console.log('🔄 Inicializando sistema de recordatorios...');
    initializeReminders(conn);
    console.log('✅ Sistema de recordatorios inicializado');
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = handlerRecordar;
module.exports.recordatorio = handlerRecordatorio;
module.exports.initRecordatorios = initRecordatorios;