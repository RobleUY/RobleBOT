const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'limpiar-cache',
  aliases: ['cleancache', 'limpiarcache'],
  category: 'herramientas',
  description: 'Limpia archivos cache de baileys_auth',
  ownerOnly: true,
  
  async execute(sock, msg, args) {
    const jid = msg.messages[0].key.remoteJid;
    
    try {
      await sock.sendMessage(jid, { text: '🧹 Iniciando limpieza de cache...' });
      
      const authFolder = path.join(__dirname, '../../baileys_auth');
      if (!fs.existsSync(authFolder)) {
        return await sock.sendMessage(jid, { text: '❌ No existe la carpeta baileys_auth' });
      }

      const files = fs.readdirSync(authFolder);
      const totalBefore = files.length;
      let cleaned = 0;

      // Límites de archivos
      const limits = {
        'pre-key-': 100,
        'device-list-': 20,
        'lid-mapping-': 50,
        'session-': 10
      };

      for (const [prefix, limit] of Object.entries(limits)) {
        const matchingFiles = files
          .filter(f => f.startsWith(prefix) && f.endsWith('.json'))
          .map(f => ({
            name: f,
            path: path.join(authFolder, f),
            mtime: fs.statSync(path.join(authFolder, f)).mtimeMs
          }))
          .sort((a, b) => b.mtime - a.mtime);

        if (matchingFiles.length > limit) {
          const toDelete = matchingFiles.slice(limit);
          for (const file of toDelete) {
            try {
              fs.unlinkSync(file.path);
              cleaned++;
            } catch (e) {}
          }
        }
      }

      const totalAfter = fs.readdirSync(authFolder).length;
      
      const response = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ LIMPIEZA COMPLETADA

📊 Archivos antes: ${totalBefore}
📊 Archivos después: ${totalAfter}
🗑️  Archivos eliminados: ${cleaned}
💾 Espacio liberado: ~${Math.round(cleaned * 0.01)}MB
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sock.sendMessage(jid, { text: response });
      
    } catch (error) {
      console.error('Error en limpiar-cache:', error);
      await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` });
    }
  }
};
