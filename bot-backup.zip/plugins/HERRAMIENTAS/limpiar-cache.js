const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'limpiar-cache',
  aliases: ['cleancache', 'limpiarcache'],
  category: 'herramientas',
  description: 'Limpia archivo de sesión .db del bot principal',
  ownerOnly: true,
  
  async execute(sock, msg, args) {
    const jid = msg.messages[0].key.remoteJid;
    
    try {
      await sock.sendMessage(jid, { text: '🧹 Iniciando limpieza de sesión...' });
      
      const sessionFile = path.join(__dirname, '../../main-session.db');
      if (!fs.existsSync(sessionFile)) {
        return await sock.sendMessage(jid, { text: '❌ No existe el archivo de sesión main-session.db' });
      }

      // Para archivo .db, solo podemos eliminarlo completamente o dejarlo
      // No hay limpieza selectiva como con múltiples archivos JSON
      const stats = fs.statSync(sessionFile);
      const sizeInMB = (stats.size / (1024 * 1024)).toFixed(2);
      
      const response = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 INFORMACIÓN DE SESIÓN

📁 Archivo: main-session.db
📊 Tamaño actual: ${sizeInMB} MB
📅 Última modificación: ${new Date(stats.mtime).toLocaleString()}

⚠️ Para limpiar completamente la sesión, usa el comando de reinicio
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sock.sendMessage(jid, { text: response });
      
    } catch (error) {
      console.error('Error en limpiar-cache:', error);
      await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` });
    }
  }
};
