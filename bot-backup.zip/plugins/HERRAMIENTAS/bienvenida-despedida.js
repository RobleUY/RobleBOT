'use strict';

const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', '..', 'data', 'bienvenida-despedida.json');
const DEFAULT_GROUP_CONFIG = {
    welcomeEnabled: false,
    goodbyeEnabled: false,
    welcomeMessage: '¡Hola @user! Bienvenido a @group 👋',
    goodbyeMessage: 'Adiós @user, esperamos verte pronto. 👋'
};

let persistedData = null;

function ensureDataFile() {
    const dataDir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    if (!fs.existsSync(DATA_FILE)) {
        persistedData = { groups: {} };
        fs.writeFileSync(DATA_FILE, JSON.stringify(persistedData, null, 2), 'utf8');
        return;
    }

    if (persistedData) return;

    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        persistedData = JSON.parse(raw || '{}');
        if (!persistedData.groups || typeof persistedData.groups !== 'object') {
            persistedData.groups = {};
        }
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error cargando datos:', error.message);
        persistedData = { groups: {} };
    }
}

function saveData() {
    if (!persistedData) persistedData = { groups: {} };
    ensureDataFile();
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(persistedData, null, 2), 'utf8');
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error guardando datos:', error.message);
    }
}

function getGroupConfig(groupId) {
    ensureDataFile();
    if (!persistedData.groups[groupId]) {
        persistedData.groups[groupId] = { ...DEFAULT_GROUP_CONFIG };
        saveData();
    }
    return persistedData.groups[groupId];
}

function normalizeParticipantJid(participant) {
    if (!participant) return null;
    if (typeof participant === 'string') return participant;
    if (typeof participant === 'object') {
        return participant.id || participant.jid || participant[0]?.id || participant[0]?.jid || null;
    }
    return null;
}

function formatMessage(template, participant, groupMetadata) {
    const participantJid = normalizeParticipantJid(participant);
    if (!participantJid) return template;

    const userNumber = participantJid.split('@')[0].replace(/[^0-9]/g, '');
    const mention = `@${userNumber}`;
    const groupName = groupMetadata?.subject || participantJid.split('@')[0] || 'este grupo';

    return template
        .replace(/@user/g, mention)
        .replace(/@group/g, groupName)
        .replace(/@name/g, mention);
}

async function isGroupAdmin(conn, groupId, senderJid) {
    if (!conn || !groupId || !senderJid) return false;
    try {
        const metadata = await conn.groupMetadata(groupId);
        if (!metadata || !Array.isArray(metadata.participants)) return false;
        const participant = metadata.participants.find(p => p.id === senderJid || p.id === senderJid.replace(/:.*$/, ''));
        return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch (error) {
        return false;
    }
}

function ensureArgsText(args, startIndex = 0) {
    return args.slice(startIndex).join(' ').trim();
}

async function handleCommand(message, { text, args, conn, command }) {
    const chatId = message.from || message.key?.remoteJid;
    if (!chatId || !chatId.endsWith('@g.us')) {
        return await message.reply('⚠️ Este comando solo puede usarse en grupos.');
    }

    const senderJid = message.author || message.sender || message.key?.participant;
    if (!senderJid) {
        return await message.reply('⚠️ No se pudo identificar tu usuario.');
    }

    const isAdmin = await isGroupAdmin(conn, chatId, senderJid);
    if (!isAdmin) {
        return await message.reply('❌ Solo administradores del grupo pueden usar este comando.');
    }

    const type = command.toLowerCase();
    const subCommand = (args[0] || '').toLowerCase();
    const groupConfig = getGroupConfig(chatId);

    const enableAliases = ['on', 'activar'];
    const disableAliases = ['off', 'desactivar'];
    const viewAliases = ['ver', 'view'];

    if (type === 'bienvenida') {
        if (enableAliases.includes(subCommand)) {
            groupConfig.welcomeEnabled = true;
            saveData();
            return await message.reply(`✅ Bienvenida activada.

La bienvenida se enviará cuando llegue un nuevo miembro.`);
        }

        if (disableAliases.includes(subCommand)) {
            groupConfig.welcomeEnabled = false;
            saveData();
            return await message.reply('✅ Bienvenida desactivada.');
        }

        if (viewAliases.includes(subCommand)) {
            const sample = formatMessage(groupConfig.welcomeMessage, senderJid, await conn.groupMetadata(chatId).catch(() => null));
            return await message.reply(
                `🌟 Bienvenida: *${groupConfig.welcomeEnabled ? 'ACTIVADA' : 'DESACTIVADA'}*

` +
                `Mensaje actual:
${groupConfig.welcomeMessage}

` +
                `Vista previa:
${sample}`
            );
        }

        if (subCommand === 'set') {
            const nextArg = (args[1] || '').toLowerCase();
            const textStart = nextArg === 'texto' ? 2 : 1;
            const newMessage = ensureArgsText(args, textStart);

            if (!newMessage) {
                return await message.reply('⚠️ Uso incorrecto. Ejemplo:\n.bienvenida set texto Hola @user, bienvenido a @group');
            }

            groupConfig.welcomeMessage = newMessage;
            saveData();
            const sample = formatMessage(newMessage, senderJid, await conn.groupMetadata(chatId).catch(() => null));
            return await message.reply(
                `✅ Mensaje de bienvenida guardado.

Mensaje guardado:
${newMessage}

Vista previa:
${sample}`
            );
        }

        return await message.reply(
            '📌 Comandos de bienvenida:\n' +
            '• .bienvenida on / activar\n' +
            '• .bienvenida off / desactivar\n' +
            '• .bienvenida ver / view\n' +
            '• .bienvenida set texto <mensaje>\n\n' +
            'Puedes usar @user para mencionar al nuevo miembro y @group para el nombre del grupo.'
        );
    }

    if (type === 'despedida') {
        if (enableAliases.includes(subCommand)) {
            groupConfig.goodbyeEnabled = true;
            saveData();
            return await message.reply('✅ Despedida activada.');
        }

        if (disableAliases.includes(subCommand)) {
            groupConfig.goodbyeEnabled = false;
            saveData();
            return await message.reply('✅ Despedida desactivada.');
        }

        if (viewAliases.includes(subCommand)) {
            const sample = formatMessage(groupConfig.goodbyeMessage, senderJid, await conn.groupMetadata(chatId).catch(() => null));
            return await message.reply(
                `🌙 Despedida: *${groupConfig.goodbyeEnabled ? 'ACTIVADA' : 'DESACTIVADA'}*

` +
                `Mensaje actual:
${groupConfig.goodbyeMessage}

` +
                `Vista previa:
${sample}`
            );
        }

        if (subCommand === 'set') {
            const nextArg = (args[1] || '').toLowerCase();
            const textStart = nextArg === 'texto' ? 2 : 1;
            const newMessage = ensureArgsText(args, textStart);

            if (!newMessage) {
                return await message.reply('⚠️ Uso incorrecto. Ejemplo:\n.despedida set texto Adiós @user, te extrañaremos.');
            }

            groupConfig.goodbyeMessage = newMessage;
            saveData();
            const sample = formatMessage(newMessage, senderJid, await conn.groupMetadata(chatId).catch(() => null));
            return await message.reply(
                `✅ Mensaje de despedida guardado.

Mensaje guardado:
${newMessage}

Vista previa:
${sample}`
            );
        }

        return await message.reply(
            '📌 Comandos de despedida:\n' +
            '• .despedida on / activar\n' +
            '• .despedida off / desactivar\n' +
            '• .despedida ver / view\n' +
            '• .despedida set texto <mensaje>\n\n' +
            'Puedes usar @user para mencionar al miembro que se va y @group para el nombre del grupo.'
        );
    }
}

async function sendWelcomeOrGoodbye(conn, groupId, participant, mode) {
    if (!conn || !groupId || !participant) return;
    const participantJid = normalizeParticipantJid(participant);
    if (!participantJid) return;
    if (participantJid === conn.user?.id) return;

    const groupConfig = getGroupConfig(groupId);
    const enabled = mode === 'welcome' ? groupConfig.welcomeEnabled : groupConfig.goodbyeEnabled;
    if (!enabled) return;

    const groupMetadata = await conn.groupMetadata(groupId).catch(() => null);
    const template = mode === 'welcome' ? groupConfig.welcomeMessage : groupConfig.goodbyeMessage;
    const text = formatMessage(template, participantJid, groupMetadata);

    try {
        await conn.sendMessage(groupId, { text, mentions: [participantJid] });
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error enviando mensaje:', error.message);
    }
}

function attachParticipantEvents(sock) {
    if (!sock || sock.__welcomeGoodbyeAttached) return;
    sock.__welcomeGoodbyeAttached = true;

    sock.ev.on('group-participants.update', async (update) => {
        if (!update || !update.id || !Array.isArray(update.participants)) return;
        const groupId = update.id;
        const action = (update.action || '').toLowerCase();
        const participants = update.participants;

        if (!groupId.endsWith('@g.us')) return;

        if (['add', 'invite', 'promote'].includes(action)) {
            for (const participant of participants) {
                await sendWelcomeOrGoodbye(sock, groupId, participant, 'welcome');
            }
        } else if (['remove', 'leave', 'demote', 'kick'].includes(action)) {
            for (const participant of participants) {
                await sendWelcomeOrGoodbye(sock, groupId, participant, 'goodbye');
            }
        }
    });
}

module.exports = {
    handler: handleCommand,
    command: /^(bienvenida|despedida)$/i,
    tags: ['group', 'herramientas'],
    help: ['bienvenida', 'despedida'],
    group: true,
    init: attachParticipantEvents
};
