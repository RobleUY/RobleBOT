'use strict';

const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', '..', 'data', 'bienvenida-despedida.json');
const DEFAULT_GROUP_CONFIG = {
    welcomeEnabled: false,
    goodbyeEnabled: false,
    welcomeMessage: '¡Hola *@user*! Bienvenido al grupo *@group* 👋\nRecuerda leer la descripción:\n@desc',
    goodbyeMessage: 'Adiós @user, esperamos verte pronto. 👋'
};

let persistedData = null;

function ensureDataFile() {
    const dataDir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    if (!fs.existsSync(DATA_FILE)) {
        persistedData = { groups: {} };
        fs.writeFileSync(DATA_FILE, JSON.stringify(persistedData, null, 2), 'utf8');
        return;
    }

    if (persistedData) return;

    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        persistedData = JSON.parse(raw || '{}');
        if (!persistedData.groups || typeof persistedData.groups !== 'object') {
            persistedData.groups = {};
        }
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error cargando datos:', error.message);
        persistedData = { groups: {} };
    }
}

function saveData() {
    if (!persistedData) persistedData = { groups: {} };
    ensureDataFile();
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(persistedData, null, 2), 'utf8');
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error guardando datos:', error.message);
    }
}

function getGroupConfig(groupId) {
    ensureDataFile();

    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        persistedData = JSON.parse(raw || '{}');
        if (!persistedData.groups || typeof persistedData.groups !== 'object') {
            persistedData.groups = {};
        }
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error recargando datos:', error.message);
        if (!persistedData) persistedData = { groups: {} };
    }

    if (!persistedData.groups[groupId]) {
        persistedData.groups[groupId] = { ...DEFAULT_GROUP_CONFIG };
        saveData();
    }

    const config = persistedData.groups[groupId];
    let changed = false;
    for (const [key, val] of Object.entries(DEFAULT_GROUP_CONFIG)) {
        if (config[key] === undefined) {
            config[key] = val;
            changed = true;
        }
    }
    if (changed) saveData();

    return config;
}

function normalizeParticipantJid(participant) {
    if (!participant) return null;
    if (typeof participant === 'string') return participant;
    if (Array.isArray(participant) && participant.length > 0) {
        return normalizeParticipantJid(participant[0]);
    }
    if (typeof participant === 'object') {
        return participant.id || participant.jid || participant.participant || participant.user || participant[0]?.id || participant[0]?.jid || null;
    }
    return null;
}

function formatMessage(template, participant, groupMetadata) {
    try {
        if (typeof template !== 'string') return '';
        const participantJid = normalizeParticipantJid(participant);
        if (!participantJid) return template;

        const userNumber = String(participantJid).split('@')[0].replace(/[^0-9]/g, '');
        const mention = userNumber ? `@${userNumber}` : '@user';
        const resolvedGroupName = typeof groupMetadata?.subject === 'string' && groupMetadata.subject.trim()
            ? groupMetadata.subject.trim()
            : String(participantJid).split('@')[0] || 'este grupo';
        const groupDesc = typeof groupMetadata?.desc === 'string' && groupMetadata.desc.trim()
            ? groupMetadata.desc.trim()
            : 'N/A';

        return template
            .replace(/@user/g, mention)
            .replace(/@group/g, resolvedGroupName)
            .replace(/@desc/g, groupDesc)
            .replace(/@name/g, mention);
    } catch (error) {
        console.error('[Bienvenida/Despedida] Error formateando mensaje:', error.message);
        return template || '';
    }
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function isGroupAdmin(conn, groupId, senderJid) {
    if (!conn || !groupId || !senderJid) return false;
    try {
        const metadata = await conn.groupMetadata(groupId);
        if (!metadata || !Array.isArray(metadata.participants)) return false;
        const participant = metadata.participants.find(p => p.id === senderJid || p.id === senderJid.replace(/:.*$/, ''));
        return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch (error) {
        return false;
    }
}

function ensureArgsText(args, startIndex = 0) {
    return args.slice(startIndex).join(' ').trim();
}

async function handleCommand(message, { text, args, conn, command }) {
    const chatId = message.from || message.key?.remoteJid;
    if (!chatId || !chatId.endsWith('@g.us')) {
        return await message.reply('⚠️ Este comando solo puede usarse en grupos.');
    }

    const senderJid = message.key?.participant || message.author || message.sender;
    if (!senderJid) {
        return await message.reply('⚠️ No se pudo identificar tu usuario.');
    }

    const isAdmin = await isGroupAdmin(conn, chatId, senderJid);
    if (!isAdmin) {
        return await message.reply('❌ Solo administradores del grupo pueden usar este comando.');
    }

    let type = command.toLowerCase();
    if (type === 'welcome') type = 'bienvenida';
    if (type === 'farewell') type = 'despedida';

    const subCommand = (args[0] || '').toLowerCase();
    const groupConfig = getGroupConfig(chatId);

    const enableAliases = ['on', 'activar'];
    const disableAliases = ['off', 'desactivar'];
    const viewAliases = ['ver', 'view'];

    if (type === 'bienvenida') {
        if (enableAliases.includes(subCommand)) {
            groupConfig.welcomeEnabled = true;
            saveData();
            return await message.reply('✅ Bienvenida activada.\n\nLa bienvenida se enviará cuando llegue un nuevo miembro.');
        }

        if (disableAliases.includes(subCommand)) {
            groupConfig.welcomeEnabled = false;
            saveData();
            return await message.reply('✅ Bienvenida desactivada.');
        }

        if (viewAliases.includes(subCommand)) {
            return await message.reply(
                `🌟 Bienvenida: *${groupConfig.welcomeEnabled ? 'ACTIVADA' : 'DESACTIVADA'}*\n\n` +
                `Mensaje actual:\n${groupConfig.welcomeMessage}`
            );
        }

        if (subCommand === 'set') {
            const newMessage = ensureArgsText(args, 1);
            if (!newMessage) {
                return await message.reply('⚠️ Uso incorrecto. Ejemplo:\n.bienvenida set Hola @user, bienvenido a @group\n\nPlaceholders disponibles: @user, @group, @desc');
            }
            groupConfig.welcomeMessage = newMessage;
            saveData();
            return await message.reply(`✅ Mensaje de bienvenida guardado.\n\nMensaje guardado:\n${newMessage}`);
        }

        return await message.reply(
            '📌 Comandos de bienvenida:\n' +
            '• .bienvenida on / activar\n' +
            '• .bienvenida off / desactivar\n' +
            '• .bienvenida ver / view\n' +
            '• .bienvenida set <mensaje>\n\n' +
            'Placeholders: @user, @group, @desc'
        );
    }

    if (type === 'despedida') {
        if (enableAliases.includes(subCommand)) {
            groupConfig.goodbyeEnabled = true;
            saveData();
            return await message.reply('✅ Despedida activada.');
        }

        if (disableAliases.includes(subCommand)) {
            groupConfig.goodbyeEnabled = false;
            saveData();
            return await message.reply('✅ Despedida desactivada.');
        }

        if (viewAliases.includes(subCommand)) {
            return await message.reply(
                `🌙 Despedida: *${groupConfig.goodbyeEnabled ? 'ACTIVADA' : 'DESACTIVADA'}*\n\n` +
                `Mensaje actual:\n${groupConfig.goodbyeMessage}`
            );
        }

        if (subCommand === 'set') {
            const newMessage = ensureArgsText(args, 1);
            if (!newMessage) {
                return await message.reply('⚠️ Uso incorrecto. Ejemplo:\n.despedida set Adiós @user, te extrañaremos.\n\nPlaceholders disponibles: @user, @group, @desc');
            }
            groupConfig.goodbyeMessage = newMessage;
            saveData();
            return await message.reply(`✅ Mensaje de despedida guardado.\n\nMensaje guardado:\n${newMessage}`);
        }

        return await message.reply(
            '📌 Comandos de despedida:\n' +
            '• .despedida on / activar\n' +
            '• .despedida off / desactivar\n' +
            '• .despedida ver / view\n' +
            '• .despedida set <mensaje>\n\n' +
            'Placeholders: @user, @group, @desc'
        );
    }
}

async function sendWelcomeOrGoodbye(conn, groupId, participant, mode) {
    if (!conn || !groupId || !participant) return;
    const participantJid = normalizeParticipantJid(participant);
    if (!participantJid) return;

    const botJid = conn.user?.id || conn.user?.jid;
    if (botJid && (participantJid === botJid || participantJid.includes(botJid.split('@')[0]))) return;

    const groupConfig = getGroupConfig(groupId);
    if (!groupConfig) return;

    const enabled = mode === 'welcome' ? groupConfig.welcomeEnabled : groupConfig.goodbyeEnabled;
    if (!enabled) return;

    const groupMetadata = await conn.groupMetadata(groupId).catch(() => null);
    const template = mode === 'welcome' ? groupConfig.welcomeMessage : groupConfig.goodbyeMessage;
    const text = formatMessage(template, participantJid, groupMetadata);
    if (!text) return;

    try {
        await conn.sendMessage(groupId, { text, mentions: [participantJid] });
    } catch (error) {
        const errMsg = String(error?.message || error || '').toLowerCase();
        if (errMsg.includes('rate-overlimit') || error?.data === 429 || errMsg.includes('rate limit')) {
            console.warn('[Bienvenida/Despedida] Rate limit detectado, reintentando en 5s...');
            await sleep(5000);
            try {
                await conn.sendMessage(groupId, { text, mentions: [participantJid] });
            } catch (retryError) {}
        } else {
            console.error('[Bienvenida/Despedida] Error enviando mensaje:', error?.message || error);
        }
    }
}

function attachParticipantEvents(sock) {
    if (!sock || sock.__welcomeGoodbyeAttached) return;
    sock.__welcomeGoodbyeAttached = true;

    sock.ev.on('group-participants.update', async (update) => {
        try {
            if (!update || !update.id || !Array.isArray(update.participants)) return;
            const groupId = update.id;
            const action = (update.action || '').toLowerCase();
            const participants = update.participants;

            if (!groupId.endsWith('@g.us')) return;

            const isAdd = ['add', 'invite'].includes(action);
            const isRemove = ['remove', 'leave', 'kick'].includes(action);
            if (!isAdd && !isRemove) return;

            // Verificar si bienvenida o despedida están activas ANTES de consultar metadata
            const config = getGroupConfig(groupId);
            if (isAdd && !config.welcomeEnabled) return;
            if (isRemove && !config.goodbyeEnabled) return;

            const botJid = sock.user?.id || sock.user?.jid;
            const cleanBot = botJid ? botJid.split('@')[0].split(':')[0] : null;

            // Filtrar participantes para excluir al propio bot
            const humanParticipants = participants.filter(p => {
                const pJid = normalizeParticipantJid(p);
                if (!pJid) return false;
                const pNum = pJid.split('@')[0].split(':')[0];
                return !(cleanBot && pNum === cleanBot);
            });

            if (humanParticipants.length === 0) return;

            // ── EVITAR DUPLICADOS ENTRE BOT PRINCIPAL Y SUB-BOTS ──
            if (sock._subNum && global.conn?.user) {
                try {
                    const mainBotId = global.conn.user.id.split(':')[0];
                    const meta = await sock.groupMetadata(groupId);
                    const isMainBotPresent = meta?.participants?.some(p => p.id.includes(mainBotId));
                    if (isMainBotPresent) {
                        // El bot principal está en el grupo, dejamos que él envíe el mensaje
                        return;
                    }
                } catch (e) { }
            }

            if (isAdd) {
                for (const participant of humanParticipants) {
                    await sendWelcomeOrGoodbye(sock, groupId, participant, 'welcome');
                }
            } else if (isRemove) {
                for (const participant of humanParticipants) {
                    await sendWelcomeOrGoodbye(sock, groupId, participant, 'goodbye');
                }
            }
        } catch (error) {
            console.error('[Bienvenida/Despedida] Error en evento de participantes:', error.message);
        }
    });
}

module.exports = {
    handler: handleCommand,
    command: /^(bienvenida|despedida|welcome|farewell)$/i,
    tags: ['group', 'herramientas'],
    help: ['bienvenida', 'despedida', 'welcome', 'farewell'],
    group: true,
    init: attachParticipantEvents
};