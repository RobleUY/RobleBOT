/**
 * Plugin: .historia / .subirestado
 * Sube una historia (estado) a WhatsApp.
 *
 * En Baileys 7.x los estados de texto requieren backgroundColor y font
 * para que WhatsApp los procese como historia real.
 */

// Colores de fondo disponibles para estados de texto
const BACKGROUNDS = [
    0xFF2D55FF, // Rosa
    0xFF5722FF, // Naranja
    0xFF9800FF, // Amarillo
    0xFF4CAF50, // Verde
    0xFF2196F3, // Azul
    0xFF9C27B0, // Violeta
    0xFF000000, // Negro
];

let handler = async (message, { text, conn, usedPrefix, command, args }) => {
    const quoted = message.quoted;
    const mime = quoted?.mimetype || '';

    if (!quoted && !text) {
        return await message.reply(
            `⚠️ Ingresa un texto o responde a una imagen/video para subir como estado.\n\n` +
            `*Ejemplos:*\n` +
            `• ${usedPrefix + command} ¡Buenas noches! 🌙\n` +
            `• Responde una imagen con ${usedPrefix + command}`
        );
    }

    try {
        await message.reply('📤 Subiendo estado...');

        // Armar statusJidList con usuarios de la BD
        let statusJidList = [];
        try {
            if (conn.store?.contacts) {
                statusJidList = Object.keys(conn.store.contacts)
                    .filter(jid => jid.endsWith('@s.whatsapp.net'));
            }
        } catch (_) {}

        if (statusJidList.length === 0 && global.db) {
            try {
                const users = global.db.data?.users || {};
                statusJidList = Object.keys(users)
                    .filter(num => /^\d+$/.test(num))
                    .map(num => `${num}@s.whatsapp.net`);
            } catch (_) {}
        }

        // Incluir el propio bot
        if (conn.user?.id) {
            const botJid = conn.user.id.split(':')[0] + '@s.whatsapp.net';
            if (!statusJidList.includes(botJid)) statusJidList.unshift(botJid);
        }

        // Limitar a 256 para no saturar (límite real de WhatsApp)
        if (statusJidList.length > 256) statusJidList = statusJidList.slice(0, 256);

        let content = null;

        if (/image/.test(mime)) {
            const media = await quoted.download();
            content = {
                image: media,
                caption: text || '',
                statusJidList
            };
        } else if (/video/.test(mime)) {
            const media = await quoted.download();
            content = {
                video: media,
                caption: text || '',
                statusJidList
            };
        } else if (text) {
            // Estado de texto: backgroundColor y font son obligatorios en Baileys 7.x
            // para que WhatsApp lo publique como historia
            const bgColor = BACKGROUNDS[Math.floor(Math.random() * BACKGROUNDS.length)];
            content = {
                text,
                backgroundColor: bgColor,
                font: 0,          // 0 = SANS_SERIF, 1 = SERIF, 2 = NORICAN, 3 = BRYNDAN_WRITE, 4 = BEBASNEUE, 5 = OSWALD
                statusJidList
            };
        } else {
            return await message.reply('⚠️ Solo se admiten imágenes, videos o texto.');
        }

        const result = await conn.sendMessage('status@broadcast', content);

        console.log(`[HISTORIA] Status: ${result?.status} | ID: ${result?.key?.id} | Contactos: ${statusJidList.length}`);

        await message.reply(
            `✅ *Estado subido con éxito.*\n` +
            `👥 Enviado a *${statusJidList.length}* contacto(s).\n\n` +
            `_Si no lo ves, asegúrate de tener el número del bot guardado en tus contactos._`
        );

    } catch (error) {
        console.error('[HISTORIA] Error:', error.message);
        await message.reply(`❌ Error al subir el estado:\n\n*${error.message}*`);
    }
};

handler.help = ['historia <texto>', 'historia (responder imagen/video)'];
handler.tags = ['herramientas'];
handler.command = /^(historia|subirestado)$/i;
handler.owner = true;

module.exports = handler;
