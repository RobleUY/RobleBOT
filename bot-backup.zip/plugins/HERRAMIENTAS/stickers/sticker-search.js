const axios = require('axios');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { Image: WebPImage } = require('node-webpmux');
const { runFFmpeg, limitMediaJob } = require('../../../lib/mediaLimiter');

/**
 * 🔑 API Keys de Klipy (en orden de prioridad).
 */
const KLIPY_API_KEYS = [
  'VbYdj6L0B30rUXIisnilRoBbapmOEZKaQMT6ONFBsZ9QXUlA7Yph0FaEFyvIIh79',
  'b4wVNTCmDSmSBWPIhvB512E0dhYZjTIuTPdzNVnqpqoc4Agyk8XrhzzE3zgp4gYD',
  'BTeDDOybI5M2aJ2YVbGm1K0IFj50Z2zyquUEa4KRLD5GHthel3CSXEI3HDrYVcf8',
];

function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

function buildKlipySearchUrl(apiKey, query, customerId) {
  const baseUrl = `https://api.klipy.com/api/v1/${apiKey}/stickers/search`;
  const params = new URLSearchParams({
    q: query,
    customer_id: customerId || 'roblebot-default',
    per_page: '24',
    page: '1'
  });
  return `${baseUrl}?${params.toString()}`;
}

/**
 * Extrae la URL del medio priorizando MP4 y GIF animados 
 * para garantizar que el sticker sea animado.
 */
function extractMediaUrl(item) {
  if (!item || typeof item !== 'object') return null;

  // Priorizar MP4 y GIF sobre WebP estático
  const candidatePaths = [
    item?.file?.md?.mp4?.url,
    item?.file?.hd?.mp4?.url,
    item?.file?.sm?.mp4?.url,
    item?.file?.md?.gif?.url,
    item?.file?.hd?.gif?.url,
    item?.file?.sm?.gif?.url,
    item?.file?.mp4,
    item?.file?.gif,
    item?.file?.md?.webp?.url,
    item?.file?.hd?.webp?.url,
    item?.file?.sm?.webp?.url,
    item?.file?.url,
    item?.file?.webp,
    item?.url,
    item?.mp4,
    item?.gif,
    item?.webp
  ];

  for (const candidate of candidatePaths) {
    if (typeof candidate === 'string' && candidate.startsWith('http')) {
      return candidate;
    }
  }

  const stack = [item];
  const seen = new Set();
  while (stack.length) {
    const current = stack.pop();
    if (!current || typeof current !== 'object' || seen.has(current)) continue;
    seen.add(current);

    for (const value of Object.values(current)) {
      if (typeof value === 'string' && value.startsWith('http') &&
          /\.(mp4|gif|webp)(\?|$)/i.test(value)) {
        return value;
      } else if (value && typeof value === 'object') {
        stack.push(value);
      }
    }
  }

  return null;
}

async function searchKlipyStickers(query, customerId) {
  for (const apiKey of KLIPY_API_KEYS) {
    try {
      const searchUrl = buildKlipySearchUrl(apiKey, query, customerId);
      const response = await axios.get(searchUrl, { timeout: 15000 });
      const items = response?.data?.data?.data;

      if (!response.data || !response.data.result || !Array.isArray(items) || items.length === 0) {
        continue;
      }

      const validResults = items
        .map(item => ({ item, mediaUrl: extractMediaUrl(item) }))
        .filter(entry => entry.mediaUrl);

      if (validResults.length === 0) continue;

      const randomIndex = Math.floor(Math.random() * validResults.length);
      const selected = validResults[randomIndex];

      return {
        ...selected.item,
        mediaUrl: selected.mediaUrl
      };
    } catch (error) {
      continue;
    }
  }
  return null;
}

async function downloadKlipyMedia(mediaUrl) {
  try {
    const response = await axios.get(mediaUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    return Buffer.from(response.data);
  } catch (error) {
    console.error('❌ Error al descargar el archivo multimedia:', error.message);
    return null;
  }
}

/**
 * Convierte el video/GIF a WebP animado con FFmpeg manteniendo la proporción y sin deformar.
 */
async function ffmpegConvertToAnimatedWebP(inputBuffer) {
  const inputPath = tmpFileName('mp4');
  const outputPath = tmpFileName('webp');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    const baseArgs = [
      '-y',
      '-t', '5',
      '-i', inputPath,
      '-vf', [
        'fps=10',
        'scale=320:320:flags=lanczos:force_original_aspect_ratio=decrease',
        'pad=320:320:(ow-iw)/2:(oh-ih)/2:color=0x00000000'
      ].join(','),
      '-vcodec', 'libwebp',
      '-lossless', '0',
      '-qscale', '50',
      '-compression_level', '6',
      '-preset', 'picture',
      '-loop', '0',
      '-an',
      '-vsync', '0',
      outputPath
    ];

    return await limitMediaJob(async () => {
      await runFFmpeg(baseArgs, { timeout: 60_000 });
      return await fs.readFile(outputPath);
    });
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * Inyecta metadatos EXIF sin re-encodear
 */
async function injectWebPMetadata(webpBuffer, packname, author) {
  try {
    const json = JSON.stringify({
      'sticker-pack-id': Math.random().toString(36).slice(2),
      'sticker-pack-name': packname,
      'sticker-pack-publisher': author,
      'emojis': []
    });

    const exifArr = [
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ];
    const jsonBuf = Buffer.from(json, 'utf-8');
    const exif = Buffer.concat([Buffer.from(exifArr), jsonBuf]);
    exif.writeUIntLE(jsonBuf.length, 14, 4);

    const img = new WebPImage();
    await img.load(webpBuffer);
    img.exif = exif;
    return await img.save(null);
  } catch (e) {
    return webpBuffer;
  }
}

async function sendKlipySticker(sock, jid, mediaBuffer, options = {}) {
  try {
    if (!mediaBuffer || !(mediaBuffer instanceof Buffer)) {
      throw new Error('Buffer multimedia no válido.');
    }

    const packname = options.packname || 'RobleBOT Search';
    const authorText = options.author || '\nRobleBOT\nInstagram: @robleuy';

    let webpBuffer;
    const isWebP = options.mediaUrl && options.mediaUrl.includes('.webp');

    // Si es un archivo estático .webp lo procesamos con Sharp
    if (isWebP) {
      webpBuffer = await sharp(mediaBuffer)
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 90 })
        .toBuffer();
    } else {
      // Si es MP4/GIF se convierte a WebP animado con FFmpeg
      webpBuffer = await ffmpegConvertToAnimatedWebP(mediaBuffer);
    }

    const finalStickerBuffer = await injectWebPMetadata(webpBuffer, packname, authorText);

    await sock.sendMessage(jid, { 
      sticker: finalStickerBuffer
    }, options.quoted ? { quoted: options.quoted } : {});

    return true;
  } catch (error) {
    console.error('❌ Error enviando sticker:', error.message);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `🔍 *Buscar Stickers en Klipy*\n\n` +
        `📌 *Uso:*\n` +
        `• /ss gatos graciosos\n` +
        `✨ *Busca y convierte videos/gifs de Klipy en stickers*\n`
      );
    }

    await message.reply('🔍 *Buscando sticker...* ⏳');

    const botNumber = getBotNumber(sock);
    const customerId = message.sender
      ? message.sender.replace(/[^0-9]/g, '')
      : (botNumber || 'roblebot-default');

    const stickerResult = await searchKlipyStickers(text, customerId);
    if (!stickerResult) {
      return await message.reply(
        '❌ No se encontraron resultados.\n' +
        '💡 Intenta de nuevo o prueba con términos en inglés (ej: *funny cat*, *meme*).'
      );
    }

    const mediaBuffer = await downloadKlipyMedia(stickerResult.mediaUrl);
    if (!mediaBuffer) {
      return await message.reply(
        '❌ No se pudo descargar el archivo de Klipy.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';
    const success = await sendKlipySticker(sock, message.from, mediaBuffer, {
      packname: 'RobleBOT Search',
      author: authorText,
      mediaUrl: stickerResult.mediaUrl,
      quoted: message._baileyMessage
    });

    if (!success) {
      await message.reply('⚠️ No se pudo procesar o convertir el archivo a sticker.');
    }

  } catch (error) {
    await message.reply('❌ Error inesperado al buscar stickers.');
  }
};

handler.help = ['ss <búsqueda>', 'stickersearch <búsqueda>', 'searchsticker <búsqueda>'];
handler.tags = ['sticker'];
handler.command = /^(ss|stickersearch|searchsticker)$/i;

module.exports = handler;