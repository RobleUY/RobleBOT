const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de búsqueda en Tenor
 */
function buildTenorSearchUrl(query) {
  const baseUrl = 'https://api.delirius.store/search/tenor';
  const encodedQuery = encodeURIComponent(query);
  return `${baseUrl}?q=${encodedQuery}`;
}

/**
 * Busca stickers en Tenor, acepta MP4/GIF y devuelve un resultado aleatorio
 */
async function searchTenorStickers(query) {
  try {
    const searchUrl = buildTenorSearchUrl(query);

    const response = await axios.get(searchUrl, {
      timeout: 15000
    });

    // Validar estructura básica de la respuesta de la API
    if (!response.data || !response.data.status || !response.data.data || response.data.data.length === 0) {
      return null;
    }

    // 1️⃣ Intentar filtrar por MP4 (Lógica principal)
    let validResults = response.data.data.filter(item => 
      item.mp4 && 
      item.mp4.startsWith('http') && 
      item.mp4.includes('.mp4')
    );

    // 2️⃣ PLAN B: Si no hay MP4, intentar buscar GIFs animados o URLs alternativas
    if (validResults.length === 0) {
      validResults = response.data.data.filter(item => 
        (item.gif && item.gif.startsWith('http')) || 
        (item.url && item.url.startsWith('http'))
      );
    }

    if (validResults.length === 0) {
      return null;
    }

    // Seleccionar uno aleatorio de la lista final
    const randomIndex = Math.floor(Math.random() * validResults.length);
    const selectedSticker = validResults[randomIndex];

    // Asegurar que la propiedad 'mp4' contenga el enlace jugoso (sea mp4 o gif)
    return {
      ...selectedSticker,
      mp4: selectedSticker.mp4 || selectedSticker.gif || selectedSticker.url
    };

  } catch (error) {
    console.error('❌ Error de conexión con la API de Tenor:', error.message);
    return null;
  }
}

/**
 * Descarga el video o gif desde Tenor
 */
async function downloadTenorVideo(mediaUrl) {
  try {
    const response = await axios.get(mediaUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    return Buffer.from(response.data);
  } catch (error) {
    console.error('❌ Error al descargar el archivo multimedia:', error.message);
    return null;
  }
}

/**
 * Convierte el video/gif a sticker y lo envía
 */
async function sendTenorSticker(sock, jid, videoBuffer, stickerInfo, options = {}) {
  try {
    if (!videoBuffer || !(videoBuffer instanceof Buffer)) {
      throw new Error('Buffer multimedia no válido.');
    }

    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    // Configuración optimizada para stickers animados
    const sticker = new Sticker(videoBuffer, {
      pack: options.packname || 'RobleBOT Search',
      author: options.author || authorText,
      type: 'full',
      quality: 40, 
      background: 'transparent',
      crop: false,
      fps: 12, 
      loop: 0
    });

    const stickerBuffer = await sticker.toBuffer();
    
    await sock.sendMessage(jid, { 
      sticker: stickerBuffer,
      mimetype: 'image/webp'
    }, options.quoted ? { quoted: options.quoted } : {});

    return true;
  } catch (error) {
    // Intentar con configuración de emergencia más ligera
    try {
      const sticker = new Sticker(videoBuffer, {
        pack: options.packname || 'RobleBOT Search',
        author: options.author || authorText,
        type: 'default',
        quality: 25
      });

      const stickerBuffer = await sticker.toBuffer();
      await sock.sendMessage(jid, { sticker: stickerBuffer });
      
      return true;
    } catch (altError) {
      return false;
    }
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `🔍 *Buscar Stickers en Tenor*\n\n` +
        `📌 *Uso:*\n` +
        `• /ss gatos graciosos\n` +
        `✨ *Busca y convierte videos de Tenor en stickers*\n`
      );
    }

    // Mensaje 1: Avisar que empezó la búsqueda
    await message.reply('🔍 *Buscando sticker...* ⏳');

    // Buscar en la API
    const stickerResult = await searchTenorStickers(text);
    if (!stickerResult) {
      return await message.reply(
        '❌ No se encontraron resultados.\n' +
        '💡 Intenta de nuevo o prueba con términos en inglés (ej: *funny cat*, *meme*).'
      );
    }

    // Descargar el archivo
    const videoBuffer = await downloadTenorVideo(stickerResult.mp4);
    if (!videoBuffer) {
      return await message.reply(
        '❌ No se pudo descargar el archivo de Tenor.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    // Convertir y enviar como Mensaje 2 (Sticker)
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
    const success = await sendTenorSticker(sock, message.from, videoBuffer, stickerResult, {
      packname: 'RobleBOT Search',
      author: authorText,
      quoted: message._baileyMessage
    });

    if (!success) {
      await message.reply('⚠️ No se pudo procesar o convertir el archivo a sticker.');
    }

  } catch (error) {
    await message.reply('❌ Error inesperado al buscar stickers.');
  }
};

handler.help = ['ss <búsqueda>', 'stickersearch <búsqueda>', 'searchsticker <búsqueda>'];
handler.tags = ['sticker'];
handler.command = /^(ss|stickersearch|searchsticker)$/i;

module.exports = handler;