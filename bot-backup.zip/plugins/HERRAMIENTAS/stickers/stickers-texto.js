// handler-tts.js
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const sharp = require('sharp');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    
    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];
    
    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

// 🎨 Colores válidos
const COLORS = {
  negro: '#000000',
  blanco: '#ffffff',
  rojo: '#ff0000',
  azul: '#0000ff',
  verde: '#00ff00',
  amarillo: '#ffff00',
  celeste: '#00ffff',
  violeta: '#8000ff',
  rosa: '#ff00ff',
  gris: '#888888',
  naranja: '#ff8000',
  morado: '#800080',
  turquesa: '#40E0D0',
  fucsia: '#FF00FF'
};

function parseTextColor(input) {
  input = input.trim();
  let textColor = '#ffffff'; // texto blanco por defecto
  let bgColor = '#000000';   // fondo negro por defecto
  let content = input;

  // 🔍 Detectar color de texto y fondo
  const regex = /^(?<color>\w+)\s+(?<texto>.+)$/i;
  const fondoRegex = /fondo\s+(\w+)/i;

  let match = input.match(regex);
  if (match && COLORS[match.groups.color.toLowerCase()]) {
    textColor = COLORS[match.groups.color.toLowerCase()];
    content = match.groups.texto;
  }

  let fondoMatch = input.match(fondoRegex);
  if (fondoMatch && COLORS[fondoMatch[1].toLowerCase()]) {
    bgColor = COLORS[fondoMatch[1].toLowerCase()];
    // quitar "fondo X" del texto visible
    content = content.replace(fondoRegex, '').trim();
  }

  return { textColor, bgColor, text: content.trim() };
}

/**
 * 🧠 Divide el texto en líneas inteligentemente
 */
function splitTextIntoLines(text, maxCharsPerLine = 12) {
  const words = text.split(/\s+/);
  const lines = [];
  let currentLine = '';

  for (let word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    
    if (testLine.length <= maxCharsPerLine) {
      currentLine = testLine;
    } else {
      if (currentLine) lines.push(currentLine);
      currentLine = word;
    }
  }
  
  if (currentLine) lines.push(currentLine);
  return lines;
}

/**
 * 🧠 Crea SVG con texto centrado, multilinea y escalado dinámico
 */
function createAdaptiveSVG(text, textColor, bgColor) {
  const width = 512;
  const height = 512;
  
  // Dividir texto en líneas inteligentemente
  const lines = splitTextIntoLines(text, 12);
  
  // Calcular tamaño de fuente según cantidad de líneas y longitud
  let fontSize = 55;
  const maxLineLength = Math.max(...lines.map(l => l.length));
  
  if (lines.length >= 2) fontSize = 50;
  if (lines.length >= 3) fontSize = 45;
  if (lines.length >= 4) fontSize = 40;
  if (lines.length >= 5) fontSize = 35;
  if (lines.length >= 7) fontSize = 30;
  if (lines.length >= 9) fontSize = 25;
  
  // Ajustar si hay líneas muy largas
  if (maxLineLength > 15) fontSize = Math.min(fontSize, 40);
  if (maxLineLength > 20) fontSize = Math.min(fontSize, 35);

  // Espaciado entre líneas (más profesional)
  const lineHeight = fontSize * 1.3;
  const totalTextHeight = lines.length * lineHeight;
  const startY = (height - totalTextHeight) / 2 + lineHeight / 2;

  // Crear líneas de texto con sombra para mejor legibilidad
  const svgLines = lines.map((line, i) => {
    const y = startY + i * lineHeight;
    // Escape de caracteres especiales XML
    const escapedLine = line
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
    
    return `
      <!-- Sombra para profundidad -->
      <text x="50%" y="${y + 2}" class="text-shadow">${escapedLine}</text>
      <!-- Texto principal -->
      <text x="50%" y="${y}" class="text-main">${escapedLine}</text>
    `;
  }).join('\n');

  const svg = `
  <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <!-- Degradado sutil para el fondo (opcional) -->
      <linearGradient id="bgGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" style="stop-color:${bgColor};stop-opacity:1" />
        <stop offset="100%" style="stop-color:${bgColor};stop-opacity:0.95" />
      </linearGradient>
    </defs>
    
    <!-- Fondo con degradado sutil -->
    <rect width="100%" height="100%" fill="url(#bgGradient)"/>
    
    <style>
      .text-main {
        fill: ${textColor};
        font-size: ${fontSize}px;
        font-family: "Impact", "Arial Black", "Arial", sans-serif;
        font-weight: 900;
        text-anchor: middle;
        dominant-baseline: middle;
        letter-spacing: 1px;
      }
      .text-shadow {
        fill: ${bgColor === '#000000' ? '#ffffff' : '#000000'};
        opacity: 0.3;
        font-size: ${fontSize}px;
        font-family: "Impact", "Arial Black", "Arial", sans-serif;
        font-weight: 900;
        text-anchor: middle;
        dominant-baseline: middle;
        letter-spacing: 1px;
        filter: blur(2px);
      }
    </style>
    
    ${svgLines}
  </svg>`;

  return Buffer.from(svg);
}

async function convertTextToSticker(text, textColor, bgColor) {
  try {
    const svgBuffer = createAdaptiveSVG(text, textColor, bgColor);

    const webpBuffer = await sharp(svgBuffer)
      .resize(512, 512, {
        fit: 'contain',
        background: { r: 0, g: 0, b: 0, alpha: 1 }
      })
      .webp({ quality: 100, lossless: true })
      .toBuffer();

    return webpBuffer;
  } catch (err) {
    console.error('❌ Error convirtiendo texto a sticker:', err);
    return null;
  }
}

async function sendSticker(sock, jid, webpBuffer, options = {}) {
  try {
    const authorText = '\nRobleBOT\nInstagram: @robleuy';
    
    const sticker = new Sticker(webpBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    
    await sock.sendMessage(jid, { sticker: stickerBuffer }, options.quoted ? { quoted: options.quoted } : {});
    console.log('✅ Sticker de texto enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = conn || message._sock || global.conn;
    if (!sock) {
      return await message.reply('❌ Error: conexión no disponible.');
    }

    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers de texto personalizados*\n\n` +
        `📝 *Uso:*\n` +
        `• .tts hola mundo\n` +
        `• .tts rojo feliz cumpleaños\n` +
        `• .tts azul buenos días fondo amarillo\n\n` +
        `🎨 *Colores disponibles:*\n` +
        `blanco, negro, rojo, azul, verde, amarillo, celeste, violeta, rosa, gris, naranja, morado, turquesa, fucsia`
      );
    }

    const { textColor, bgColor, text: cleanText } = parseTextColor(text);
    const webpBuffer = await convertTextToSticker(cleanText, textColor, bgColor);
    if (!webpBuffer) {
      return await message.reply('❌ No se pudo crear el sticker de texto.');
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';
    
    await sendSticker(sock, message.from, webpBuffer, {
      packname: 'RobleBOT',
      author: authorText,
      quoted: message._baileyMessage
    });
  } catch (err) {
    console.error('❌ Error general en handler-tts:', err);
    await message.reply('❌ Ocurrió un error al crear el sticker de texto.');
  }
};

handler.help = ['tts <texto>'];
handler.tags = ['stickers', 'diversión'];
handler.command = /^tts$/i;

module.exports = handler;