// emojitos.js
// Comando: .emojitos <emoji>
// Convierte un emoji en un sticker de WhatsApp usando las imágenes de Twemoji.

const sharp = require('sharp');
const { Sticker } = require('wa-sticker-formatter');

// Node 18+ trae fetch global. Si tu Node es más viejo, esto hace fallback a node-fetch.
const fetchFn = (typeof fetch !== 'undefined')
  ? fetch
  : (...args) => import('node-fetch').then(({ default: f }) => f(...args));

// Regex de respaldo (por si Intl.Segmenter no está disponible en tu Node).
// No cubre 100% los casos raros, pero sirve como fallback.
const EMOJI_REGEX_FALLBACK = /(?:\p{Regional_Indicator}{2})|(?:(?:\p{Emoji_Presentation}|\p{Extended_Pictographic})(?:\p{Emoji_Modifier})?(?:\u200d(?:\p{Emoji_Presentation}|\p{Extended_Pictographic})(?:\p{Emoji_Modifier})?)*\ufe0f?)|(?:[0-9#*]\ufe0f?\u20e3)/u;

// Detecta si un "grafema" (cluster de caracteres) es o contiene un emoji real,
// para no confundirlo con letras, números sueltos, signos de puntuación, etc.
const EMOJI_PRESENCE_REGEX = /\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20e3/u;

/**
 * Convierte un emoji a su representación de codepoints hexadecimales,
 * tal como los nombra Twemoji para sus assets (ej: "1f525" para 🔥).
 */
function toCodePoints(str, { keepVariationSelector } = {}) {
  const points = [];
  for (const char of str) {
    const cp = char.codePointAt(0);
    if (!keepVariationSelector && cp === 0xfe0f) continue; // variation selector
    points.push(cp.toString(16));
  }
  return points.join('-');
}

/**
 * Descarga el PNG del emoji desde el CDN de Twemoji.
 * Intenta primero sin variation selector y después con él, por si acaso.
 */
async function fetchTwemojiPNG(emoji) {
  const base = 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/72x72/';
  const candidates = [
    toCodePoints(emoji, { keepVariationSelector: false }),
    toCodePoints(emoji, { keepVariationSelector: true }),
  ];

  const tried = new Set();
  for (const cp of candidates) {
    if (!cp || tried.has(cp)) continue;
    tried.add(cp);
    const url = `${base}${cp}.png`;
    try {
      const res = await fetchFn(url);
      if (res.ok) {
        const arrayBuffer = await res.arrayBuffer();
        return Buffer.from(arrayBuffer);
      }
    } catch (err) {
      console.warn(`⚠️ Falló la descarga de ${url}:`, err.message);
    }
  }
  return null;
}

/**
 * Extrae el primer emoji válido (grafema completo) de un texto.
 * Usa Intl.Segmenter cuando está disponible, que agrupa correctamente
 * secuencias con tono de piel, banderas (regional indicators), ZWJ y keycaps
 * como un único emoji, sin cortarlas a la mitad.
 */
function extractEmoji(text) {
  if (typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function') {
    const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });
    for (const { segment } of segmenter.segment(text)) {
      if (EMOJI_PRESENCE_REGEX.test(segment)) {
        return segment;
      }
    }
    return null;
  }

  // Fallback para Node sin soporte de Intl.Segmenter (poco común en Node 16+)
  const match = text.match(EMOJI_REGEX_FALLBACK);
  return match ? match[0] : null;
}

/**
 * Convierte el PNG del emoji a WebP cuadrado, listo para sticker.
 */
async function pngToStickerWebp(pngBuffer) {
  return sharp(pngBuffer)
    .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
    .webp({ quality: 100, lossless: false, effort: 4 })
    .toBuffer();
}

async function sendEmojiSticker(sock, jid, emoji, options = {}) {
  const pngBuffer = await fetchTwemojiPNG(emoji);
  if (!pngBuffer) return { ok: false, reason: 'download' };

  const webpBuffer = await pngToStickerWebp(pngBuffer);

  const packname   = options.packname || 'RobleBOT';
  const authorText = options.author   || '\nInstagram: @robleuy\n\nrobleuy.vercel.app/roblebot';

  const sticker = new Sticker(webpBuffer, {
    pack: packname,
    author: authorText,
    type: 'default',
    quality: 100,
  });

  const finalBuffer = await sticker.toBuffer();
  const sendOptions = options.quoted ? { quoted: options.quoted } : {};
  await sock.sendMessage(jid, { sticker: finalBuffer }, sendOptions);

  return { ok: true };
}

// Handler principal exportado
let handler = async (message, { text, args, conn }) => {
  try {
    console.log('🚀 Iniciando comando emojitos...');
    const sock = conn || message._sock || global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    const input = (text || (args && args.join(' ')) || '').trim();
    if (!input) {
      return await message.reply('❌ *Escribí un emoji junto al comando. Ejemplo:* `.emojitos 🔥`');
    }

    const emoji = extractEmoji(input);
    if (!emoji) {
      return await message.reply('❌ No encontré ningún emoji válido en tu mensaje.');
    }

    await message.reply(`⏳ Creando sticker del emoji ${emoji}...`);

    const result = await sendEmojiSticker(sock, message.from, emoji, {
      packname: 'RobleBOT',
      author: '\nRobleBOT\nInstagram: @robleuy',
      quoted: message._baileyMessage,
    });

    if (!result.ok) {
      return await message.reply('❌ No pude generar el sticker de ese emoji. Probá con otro.');
    }

    console.log('✅ Sticker de emoji enviado correctamente');
  } catch (error) {
    console.error('❌ Error general en handler (emojitos):', error);
    await message.reply('❌ Ocurrió un error al crear el sticker del emoji.');
  }
};

handler.help = ['emojitos <emoji>'];
handler.tags = ['stickers'];
handler.command = /^(emojitos|emojisticker|emoji2sticker)$/i;

module.exports = handler;