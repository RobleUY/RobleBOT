// plugins/HERRAMIENTAS/stickers/sticker-60fps.js
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { Sticker } = require('wa-sticker-formatter');
const { Image: WebPImage } = require('node-webpmux');

const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * Inyecta metadatos EXIF en WebP sin re-encodear
 */
async function injectWebPMetadata(webpBuffer, packname, author) {
  try {
    const json = JSON.stringify({
      'sticker-pack-id': Math.random().toString(36).slice(2),
      'sticker-pack-name': packname,
      'sticker-pack-publisher': author,
      'emojis': []
    });

    const exifArr = [
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ];
    const jsonBuf = Buffer.from(json, 'utf-8');
    const exif = Buffer.concat([Buffer.from(exifArr), jsonBuf]);
    exif.writeUIntLE(jsonBuf.length, 14, 4);

    const img = new WebPImage();
    await img.load(webpBuffer);
    img.exif = exif;
    return await img.save(null);
  } catch (e) {
    console.warn('⚠️ No se pudieron inyectar metadatos EXIF:', e.message);
    return webpBuffer;
  }
}

/**
 * Convierte video/gif a WebP animado de alta fluidez (60 FPS).
 * Ajusta automáticamente parámetros para no superar el límite estricto de 1MB de WhatsApp.
 */
async function ffmpegConvertTo60FpsWebP(inputBuffer) {
  const inputPath = tmpFileName('mp4');
  const outputPath = tmpFileName('webp');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    // Intentos progresivos para maximizar los FPS y la fluidez mientras se respeta < 1MB (1,000,000 bytes)
    const attempts = [
      { fps: 60, scale: 480, duration: 4, qscale: 45 },
      { fps: 60, scale: 380, duration: 3.5, qscale: 40 },
      { fps: 50, scale: 360, duration: 3.5, qscale: 35 },
      { fps: 45, scale: 320, duration: 3, qscale: 30 }
    ];

    let outBuffer = null;

    for (let i = 0; i < attempts.length; i++) {
      const cfg = attempts[i];
      console.log(`🎥 Intento ${i + 1} de renderizado 60FPS: fps=${cfg.fps}, res=${cfg.scale}x${cfg.scale}, dur=${cfg.duration}s, qscale=${cfg.qscale}`);

      const args = [
        '-y',
        '-t', String(cfg.duration),
        '-i', inputPath,
        '-vf', [
          `fps=${cfg.fps}`,
          `scale=${cfg.scale}:${cfg.scale}:flags=lanczos:force_original_aspect_ratio=decrease`,
          `pad=${cfg.scale}:${cfg.scale}:(ow-iw)/2:(oh-ih)/2:color=0x00000000`
        ].join(','),
        '-vcodec', 'libwebp',
        '-lossless', '0',
        '-qscale', String(cfg.qscale),
        '-compression_level', '6',
        '-preset', 'picture',
        '-loop', '0',
        '-an',
        '-vsync', '0',
        outputPath
      ];

      try {
        await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 60_000 });
        outBuffer = await fs.readFile(outputPath);
        console.log(`📊 Tamaño generado: ${(outBuffer.length / 1024).toFixed(1)} KB`);

        // Límite de WhatsApp: 1,000,000 bytes (1 MB)
        if (outBuffer.length < 980_000) {
          console.log(`✅ Sticker 60FPS aceptado a ${cfg.fps} FPS!`);
          break;
        } else {
          console.warn(`⚠️ Excede 1MB (${(outBuffer.length / 1024).toFixed(1)} KB), probando ajuste más liviano...`);
        }
      } catch (err) {
        console.error(`❌ Error en intento ${i + 1}:`, err.message);
      }
    }

    if (!outBuffer || outBuffer.length >= 1_020_000) {
      throw new Error('No se pudo generar un sticker < 1MB a 60FPS.');
    }

    return outBuffer;
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * Detecta media en el mensaje o mensaje citado
 */
async function detectMediaFromBailey(baileyMsg) {
  if (!baileyMsg) return null;

  function unwrap(msg) {
    if (!msg) return null;
    return (
      msg.viewOnceMessage?.message ||
      msg.viewOnceMessageV2?.message ||
      msg.viewOnceMessageV2Extension?.message ||
      msg.ephemeralMessage?.message ||
      msg.documentWithCaptionMessage?.message ||
      msg.buttonReplyMessage?.message ||
      msg.buttonsResponseMessage?.message ||
      msg.templateButtonReplyMessage?.message ||
      msg
    );
  }

  const rawMsg = baileyMsg.message;
  const inner = unwrap(rawMsg);

  async function downloadMsg(msgObj, type) {
    try {
      const stream = await downloadContentFromMessage(msgObj, type);
      return await streamToBuffer(stream);
    } catch (e) {
      console.error(`❌ Error descargando ${type}:`, e.message);
      return null;
    }
  }

  // 1. Mensaje actual
  if (inner?.videoMessage) {
    const isGif = !!inner.videoMessage.gifPlayback;
    const buf = await downloadMsg(inner.videoMessage, 'video');
    if (buf) return { data: buf, mimetype: inner.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
  }

  if (inner?.imageMessage) {
    const buf = await downloadMsg(inner.imageMessage, 'image');
    if (buf) return { data: buf, mimetype: inner.imageMessage.mimetype || 'image/jpeg', type: 'image' };
  }

  // 2. Mensaje citado
  const contextInfo =
    inner?.extendedTextMessage?.contextInfo ||
    inner?.imageMessage?.contextInfo ||
    inner?.videoMessage?.contextInfo ||
    inner?.stickerMessage?.contextInfo ||
    rawMsg?.extendedTextMessage?.contextInfo ||
    null;

  const quoted = contextInfo?.quotedMessage;
  if (!quoted) return null;

  const quotedInner = unwrap(quoted) || quoted;

  if (quotedInner?.videoMessage) {
    const isGif = !!quotedInner.videoMessage.gifPlayback;
    const buf = await downloadMsg(quotedInner.videoMessage, 'video');
    if (buf) return { data: buf, mimetype: quotedInner.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
  }

  if (quotedInner?.imageMessage) {
    const buf = await downloadMsg(quotedInner.imageMessage, 'image');
    if (buf) return { data: buf, mimetype: quotedInner.imageMessage.mimetype || 'image/jpeg', type: 'image' };
  }

  if (quotedInner?.stickerMessage) {
    const buf = await downloadMsg(quotedInner.stickerMessage, 'sticker');
    if (buf) return { data: buf, mimetype: quotedInner.stickerMessage.mimetype || 'image/webp', type: 'sticker' };
  }

  return null;
}

let handler = async (message, { conn }) => {
  try {
    const sock = conn || message._sock || global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    const baileyMsg = message._baileyMessage
      || (global.lastBaileyMessage?.key?.id === message.id ? global.lastBaileyMessage : null);
    
    let media = baileyMsg ? await detectMediaFromBailey(baileyMsg) : null;

    if (!media && message.quoted?.download) {
      try {
        const buf = await message.quoted.download();
        if (buf && buf.length > 100) {
          const mime = message.quoted.mimetype || 'video/mp4';
          const type = mime.includes('video') ? 'video' : mime.includes('webp') ? 'sticker' : 'image';
          media = { data: buf, mimetype: mime, type };
        }
      } catch (_) {}
    }

    if (!media) {
      return await message.reply(
        '❌ *Responde a un video o GIF con .s60fps para convertirlo en un sticker animado fluido de 60 FPS.*'
      );
    }

    await message.reply('⚡ *Creando sticker fluido a 60 FPS (alta calidad)...*');

    let webpBuffer;

    if (media.type === 'video' || media.type === 'gif') {
      webpBuffer = await ffmpegConvertTo60FpsWebP(media.data);
    } else if (media.type === 'image') {
      webpBuffer = await sharp(media.data)
        .resize(512, 512, { fit: 'contain', background: { r:255,g:255,b:255,alpha:0 } })
        .webp({ quality: 95, lossless: false, effort: 4 })
        .toBuffer();
    } else {
      webpBuffer = media.data;
    }

    const packname = 'RobleBOT 60FPS';
    const authorText = '\nInstagram: @robleuy\n\nrobleuy.vercel.app/roblebot';
    const finalSticker = await injectWebPMetadata(webpBuffer, packname, authorText);

    const sendOptions = message._baileyMessage ? { quoted: message._baileyMessage } : {};
    await sock.sendMessage(message.from, { sticker: finalSticker }, sendOptions);
    console.log('✅ Sticker 60FPS enviado exitosamente!');

  } catch (error) {
    console.error('❌ Error en sticker 60fps:', error);
    await message.reply('❌ Error al procesar el sticker a 60 FPS. Verifica que el video no sea muy largo.');
  }
};

handler.help = ['s60fps', 'sticker60fps', 'sfps'];
handler.tags = ['stickers'];
handler.command = /^(s60fps|sticker60fps|sfps|s60|sticker60|sfluido)$/i;

module.exports = handler;
