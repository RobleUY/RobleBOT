const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const { spawn } = require('child_process');
const { Image } = require('node-webpmux');
const { TextEncoder } = require('util');
const sharp = require('sharp');

// Metadata igual que brat.js
const PACK_NAME = 'RobleBOT';
const AUTHOR_TEXT = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

/**
 * Ejecuta ffmpeg/ffprobe leyendo desde stdin y escribiendo a stdout (100% en memoria).
 */
function ffmpegPipe(bin, args, input) {
  return new Promise((resolve, reject) => {
    const proc = spawn(bin, args, { windowsHide: true });
    const chunks = [];
    const errChunks = [];
    proc.stdout.on('data', chunk => chunks.push(chunk));
    proc.stderr.on('data', chunk => errChunks.push(chunk));
    proc.on('close', code => {
      if (code === 0 && chunks.length > 0) {
        resolve(Buffer.concat(chunks));
      } else {
        const errMsg = Buffer.concat(errChunks).toString().slice(-800);
        console.error(`❌ ${bin} stderr:`, errMsg);
        reject(new Error(`${bin} terminó con código ${code}`));
      }
    });
    proc.on('error', reject);
    if (input) {
      proc.stdin.write(input);
    }
    proc.stdin.end();
  });
}

/**
 * Obtiene el FPS real del video usando ffprobe (desde stdin, sin disco).
 * Devuelve un número, máximo 60. Default 30 si falla.
 */
async function getVideoFps(videoBuffer) {
  try {
    const result = await new Promise((resolve, reject) => {
      const proc = spawn('ffprobe', [
        '-v', 'quiet',
        '-print_format', 'json',
        '-show_streams',
        '-i', 'pipe:0'
      ], { windowsHide: true });

      const chunks = [];
      proc.stdout.on('data', chunk => chunks.push(chunk));
      proc.stderr.on('data', () => {});
      proc.on('close', () => resolve(Buffer.concat(chunks).toString()));
      proc.on('error', reject);
      proc.stdin.write(videoBuffer);
      proc.stdin.end();
    });

    const info = JSON.parse(result);
    const videoStream = info.streams?.find(s => s.codec_type === 'video');
    if (!videoStream?.r_frame_rate) return 30;

    // r_frame_rate viene como "60/1" o "30000/1001"
    const [num, den] = videoStream.r_frame_rate.split('/').map(Number);
    const fps = Math.round(num / den);
    return Math.min(fps, 60); // máximo 60fps
  } catch {
    return 30; // fallback
  }
}

/**
 * Construye el buffer EXIF con metadata de sticker de WhatsApp.
 * Replica exactamente lo que hace wa-sticker-formatter internamente.
 */
function buildExif(packname, author) {
  const metadata = JSON.stringify({
    'sticker-pack-id': 'roblebot-pack-001',
    'sticker-pack-name': packname,
    'sticker-pack-publisher': author,
    'emojis': []
  });
  const dataBytes = Buffer.from(metadata, 'utf-8');
  const exif = Buffer.concat([
    Buffer.from([
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ]),
    dataBytes
  ]);
  exif.writeUIntLE(new TextEncoder().encode(metadata).length, 14, 4);
  return exif;
}

/**
 * Inyecta metadata EXIF en un WebP usando node-webpmux.
 */
async function addExifToWebp(webpBuffer, packname, author) {
  const exif = buildExif(packname, author);
  const img = new Image();
  await img.load(webpBuffer);
  img.exif = exif;
  return await img.save(null);
}

/**
 * Convierte video a GIF en memoria usando ffmpeg (pipe:0 → pipe:1).
 * Usa el fps real del video (máx 60) para que la velocidad sea correcta.
 */
async function videoToGifInMemory(videoBuffer, maxSeconds = 10, fps = 30) {
  // Limitamos el GIF a máx 30fps para no explotar la RAM con el intermediario
  // (sharp igual respeta el delay correcto al convertir a WebP)
  const gifFps = Math.min(fps, 30);

  return ffmpegPipe('ffmpeg', [
    '-y',
    '-fflags', '+genpts',
    '-f', 'mp4',
    '-i', 'pipe:0',
    '-t', String(maxSeconds),
    '-vf', [
      'scale=512:512:force_original_aspect_ratio=decrease',
      'pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000:eval=init',
      `fps=${gifFps}`,
      'split[s0][s1]',
      '[s0]palettegen=max_colors=256[p]',
      '[s1][p]paletteuse=dither=bayer'
    ].join(','),
    '-loop', '0',
    '-an',
    '-f', 'gif',
    'pipe:1'
  ], videoBuffer);
}

/**
 * Convierte un video a WebP animado para sticker de WhatsApp, 100% en memoria:
 * video → fps real (ffprobe) → GIF (ffmpeg pipe) → WebP animado (sharp) → +EXIF (node-webpmux)
 */
async function videoToWebpSticker(videoBuffer, maxSeconds = 10) {
  // Paso 1: detectar fps real del video
  const fps = await getVideoFps(videoBuffer);
  console.log(`🎞️ FPS detectado: ${fps}`);

  // Paso 2: video → GIF en memoria con el fps correcto
  console.log('🎬 video → GIF...');
  let gifBuffer = await videoToGifInMemory(videoBuffer, maxSeconds, fps);
  console.log(`   GIF: ${(gifBuffer.length / 1024).toFixed(0)} KB`);

  // Paso 3: GIF → WebP animado con sharp
  // El delay por frame del GIF ya refleja el fps real, sharp lo hereda
  console.log('🖼️ GIF → WebP...');
  const webpBuffer = await sharp(gifBuffer, { animated: true })
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 100, lossless: false, effort: 4 })
    .toBuffer();

  // Liberar GIF de memoria
  gifBuffer = null;
  console.log(`   WebP: ${(webpBuffer.length / 1024).toFixed(0)} KB`);

  // Paso 4: inyectar EXIF
  const finalBuffer = await addExifToWebp(webpBuffer, PACK_NAME, AUTHOR_TEXT);
  console.log(`✅ Sticker listo: ${(finalBuffer.length / 1024).toFixed(0)} KB`);

  return finalBuffer;
}

/**
 * Envía el sticker al chat.
 * - Imágenes: usa wa-sticker-formatter (igual que brat.js)
 * - Videos:   video→GIF→WebP+EXIF completamente en memoria (sin tocar disco)
 */
async function sendSticker(sock, jid, mediaBuffer, isAnimated = false) {
  try {
    if (!mediaBuffer || !(mediaBuffer instanceof Buffer)) {
      throw new Error('Buffer de medio no válido.');
    }

    let stickerBuffer;

    if (isAnimated) {
      stickerBuffer = await videoToWebpSticker(mediaBuffer, 10);
    } else {
      // Igual que brat.js: type 'default', quality 100
      const sticker = new Sticker(mediaBuffer, {
        pack: PACK_NAME,
        author: AUTHOR_TEXT,
        type: 'default',
        quality: 100
      });
      stickerBuffer = await sticker.toBuffer();
    }

    if (stickerBuffer.length > 1 * 1024 * 1024) {
      console.warn(`⚠️ Sticker pesa ${(stickerBuffer.length / 1024 / 1024).toFixed(2)} MB`);
    }

    await sock.sendMessage(jid, { sticker: stickerBuffer });
    console.log('✅ Sticker enviado');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { usedPrefix, command }) => {
  try {
    const sock = message._sock || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    const quoted = message.quoted ? message.quoted : message;
    const mime = (quoted.msg || quoted).mimetype || '';

    if (!/image|video/.test(mime)) {
      return await message.reply(
        `📸 *Creador de Stickers* 🎥\n\n` +
        `📌 *Uso:*\n` +
        `• Responde a una *Imagen*, *Video* o *GIF* usando el comando:\n` +
        `👉 *${usedPrefix + command}*`
      );
    }

    await message.reply('⏳ *Convirtiendo multimedia a sticker...*');

    const mediaBuffer = await quoted.download();
    if (!mediaBuffer) {
      return await message.reply('❌ No se pudo descargar el archivo multimedia.');
    }

    const isAnimated = mime.includes('video');

    const success = await sendSticker(sock, message.from, mediaBuffer, isAnimated);

    if (!success) {
      await message.reply('⚠️ No se pudo crear el sticker. Asegúrate de que el archivo sea una imagen, video o GIF válido.');
    }

  } catch (error) {
    console.error('❌ Error general en el plugin de sticker:', error);
    await message.reply('❌ Ocurrió un error inesperado al procesar el sticker.');
  }
};

handler.help = ['s', 'sticker', 'stickers'];
handler.tags = ['sticker'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;
