const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const { spawn } = require('child_process');

/**
 * Ejecuta ffmpeg leyendo desde stdin y escribiendo a stdout (100% en memoria).
 * @param {string[]} args  - Argumentos de ffmpeg
 * @param {Buffer}   input - Buffer de entrada enviado por stdin
 * @returns {Promise<Buffer>}
 */
function ffmpegPipe(args, input) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { windowsHide: true });
    const chunks = [];
    proc.stdout.on('data', chunk => chunks.push(chunk));
    proc.stderr.on('data', () => {}); // silenciar logs internos de ffmpeg
    proc.on('close', code => {
      if (code === 0 && chunks.length > 0) resolve(Buffer.concat(chunks));
      else reject(new Error(`ffmpeg terminó con código ${code}`));
    });
    proc.on('error', reject);
    proc.stdin.write(input);
    proc.stdin.end();
  });
}

/**
 * Convierte un video a WebP animado (formato sticker WhatsApp) completamente
 * en memoria, sin escribir nada en disco. Recorta a máximo `maxSeconds`.
 * @param {Buffer} videoBuffer
 * @param {number} maxSeconds
 * @returns {Promise<Buffer>} WebP animado
 */
async function videoToWebpSticker(videoBuffer, maxSeconds = 10) {
  return ffmpegPipe([
    '-y',
    '-i', 'pipe:0',
    '-t', String(maxSeconds),
    '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=15',
    '-vcodec', 'libwebp',
    '-lossless', '0',
    '-compression_level', '6',
    '-q:v', '30',
    '-loop', '0',      // loop infinito (requerido por WhatsApp)
    '-preset', 'default',
    '-an',
    '-vsync', '0',
    '-f', 'webp',
    'pipe:1'
  ], videoBuffer);
}

/**
 * Envía el sticker al chat.
 * - Imágenes: usa wa-sticker-formatter (solo procesa en memoria)
 * - Videos:   usa ffmpeg directo → WebP animado en memoria (sin tocar disco)
 */
async function sendSticker(sock, jid, mediaBuffer, isAnimated = false, options = {}) {
  try {
    if (!mediaBuffer || !(mediaBuffer instanceof Buffer)) {
      throw new Error('Buffer de medio no válido.');
    }

    let stickerBuffer;

    if (isAnimated) {
      // Video → WebP animado completamente en memoria
      console.log('🎞️ Convirtiendo video a WebP animado en memoria...');
      stickerBuffer = await videoToWebpSticker(mediaBuffer, 10);
      console.log(`✅ WebP generado: ${(stickerBuffer.length / 1024).toFixed(1)} KB`);
    } else {
      // Imagen estática → wa-sticker-formatter
      const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
      const sticker = new Sticker(mediaBuffer, {
        pack: options.packname || 'RobleBOT',
        author: options.author || authorText,
        type: StickerTypes.FULL,
        quality: 85,
        width: 512,
        height: 512
      });
      stickerBuffer = await sticker.toBuffer();
    }

    if (stickerBuffer.length > 1 * 1024 * 1024) {
      console.warn(`⚠️ El sticker pesa demasiado: ${(stickerBuffer.length / 1024 / 1024).toFixed(2)} MB`);
    }

    await sock.sendMessage(jid, { sticker: stickerBuffer });
    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { usedPrefix, command }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    const quoted = message.quoted ? message.quoted : message;
    const mime = (quoted.msg || quoted).mimetype || '';

    if (!/image|video/.test(mime)) {
      return await message.reply(
        `📸 *Creador de Stickers* 🎥\n\n` +
        `📌 *Uso:*\n` +
        `• Responde a una *Imagen*, *Video* o *GIF* usando el comando:\n` +
        `👉 *${usedPrefix + command}*`
      );
    }

    await message.reply('⏳ *Convirtiendo multimedia a sticker...*');

    const mediaBuffer = await quoted.download();
    if (!mediaBuffer) {
      return await message.reply('❌ No se pudo descargar el archivo multimedia.');
    }

    const isAnimated = mime.includes('video');
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    const success = await sendSticker(sock, message.from, mediaBuffer, isAnimated, {
      packname: 'RobleBOT',
      author: authorText
    });

    if (!success) {
      await message.reply('⚠️ No se pudo crear el sticker. Asegúrate de que el archivo sea una imagen, video o GIF válido.');
    }

  } catch (error) {
    console.error('❌ Error general en el plugin de sticker:', error);
    await message.reply('❌ Ocurrió un error inesperado al procesar el sticker.');
  }
};

handler.help = ['s', 'sticker', 'stickers'];
handler.tags = ['sticker'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;
