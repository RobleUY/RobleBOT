// stickers.js
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { Sticker } = require('wa-sticker-formatter');
const execFileAsync = promisify(execFile);

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    
    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];
    
    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * Detecta si el mensaje actual tiene una imagen o video.
 * @returns {object|null}
 */
async function detectCurrentMedia() {
  try {
    console.log('🔍 Buscando medios en el mensaje actual...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      // console.log('❌ No hay mensaje de @whiskeysockets/baileys guardado');
      return null;
    }

    // imageMessage
    if (baileyMsg.message?.imageMessage) {
      console.log('🖼️ Imagen detectada en el mensaje actual, descargando...');
      try {
        const stream = await downloadContentFromMessage(baileyMsg.message.imageMessage, 'image');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: baileyMsg.message.imageMessage.mimetype || 'image/jpeg',
          type: 'image'
        };
      } catch (err) {
        console.error('❌ Error descargando imagen actual:', err);
        return null;
      }
    }

    // videoMessage (incluye GIFs - gifPlayback = true)
    if (baileyMsg.message?.videoMessage) {
      const isGif = !!baileyMsg.message.videoMessage.gifPlayback;
      console.log(isGif ? '🎭 GIF detectado en el mensaje actual, descargando...' : '🎥 Video detectado en el mensaje actual, descargando...');
      try {
        const stream = await downloadContentFromMessage(baileyMsg.message.videoMessage, 'video');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: baileyMsg.message.videoMessage.mimetype || 'video/mp4',
          type: isGif ? 'gif' : 'video'
        };
      } catch (err) {
        console.error('❌ Error descargando video/gif actual:', err);
        return null;
      }
    }

    // console.log('❌ No se detectaron medios soportados en el mensaje actual');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectCurrentMedia:', error);
    return null;
  }
}

/**
 * Detecta medios citados (respondiendo a un mensaje anterior).
 * @returns {object|null}
 */
async function detectQuotedMedia() {
  try {
    console.log('🔍 Buscando mensaje citado...');
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) {
      console.log('❌ No hay mensaje de @whiskeysockets/baileys guardado');
      return null;
    }

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.imageMessage?.contextInfo) {
      contextInfo = baileyMsg.message.imageMessage.contextInfo;
    } else if (baileyMsg.message?.videoMessage?.contextInfo) {
      contextInfo = baileyMsg.message.videoMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) {
      console.log('❌ No hay mensaje citado');
      return null;
    }

    const quotedMessage = contextInfo.quotedMessage;

    // stickerMessage (si el usuario respondió a un sticker)
    if (quotedMessage.stickerMessage) {
      console.log('🎟️ Sticker citado detectado, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.stickerMessage, 'sticker');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.stickerMessage.mimetype || 'image/webp',
          type: 'sticker'
        };
      } catch (err) {
        console.error('❌ Error descargando sticker citado:', err);
        return null;
      }
    }

    // imageMessage
    if (quotedMessage.imageMessage) {
      console.log('🖼️ Imagen citada detectada, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg',
          type: 'image'
        };
      } catch (err) {
        console.error('❌ Error descargando imagen citada:', err);
        return null;
      }
    }

    // videoMessage (incluye GIFs - gifPlayback = true)
    if (quotedMessage.videoMessage) {
      const isGif = !!quotedMessage.videoMessage.gifPlayback;
      console.log(isGif ? '🎭 GIF citado detectado, descargando...' : '🎥 Video citado detectado, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4',
          type: isGif ? 'gif' : 'video'
        };
      } catch (err) {
        console.error('❌ Error descargando video/gif citado:', err);
        return null;
      }
    }

    console.log('❌ Tipo de mensaje citado no soportado');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectQuotedMedia:', error);
    return null;
  }
}

/**
 * Intenta convertir buffer (video/gif) a WebP animado usando ffmpeg.
 * Si falla, lanza error y el llamador deberá hacer fallback.
 */
async function ffmpegConvertToAnimatedWebP(inputBuffer, isVideo = true) {
  const inputExt = isVideo ? 'mp4' : 'gif';
  const inputPath = tmpFileName(inputExt);
  const outputPath = tmpFileName('webp');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    // Args: limit duration / fps para evitar stickers enormes en video
    // -t 8 limita a 8 segundos (puedes ajustar)
    // -r 15 reduce fps para menor tamaño
    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease',
      '-vcodec', 'libwebp',
      '-lossless', '0',
      '-qscale', '75',
      '-preset', 'default',
      '-loop', '0',
      '-an',
      '-vsync', '0',
      '-s', '512:512'
    ];

    // Si es video, limitar tiempo y fps
    if (isVideo) {
      // limitar a primeros 8 segundos y 15 fps para que no pese tanto
      baseArgs.push('-t', '8', '-r', '15');
    }

    baseArgs.push(outputPath);

    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });

    const outBuffer = await fs.readFile(outputPath);
    return outBuffer;
  } finally {
    // limpiar
    Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * Extrae primer frame con ffmpeg y devuelve buffer (imagen)
 */
async function ffmpegExtractFirstFrame(inputBuffer) {
  const inputPath = tmpFileName('mp4');
  const framePath = tmpFileName('jpg');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const args = [
      '-y',
      '-i', inputPath,
      '-ss', '0',
      '-vframes', '1',
      framePath
    ];
    await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 15_000 });
    const frameBuffer = await fs.readFile(framePath);
    return frameBuffer;
  } finally {
    Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(framePath).catch(()=>{})]);
  }
}

async function convertToStickerFormat(mediaBuffer, mediaType, mimetype) {
  try {
    console.log(`🔄 Convirtiendo ${mediaType} a formato sticker...`);

    if (mediaType === 'sticker') {
      console.log('⚡ Es un sticker WebP ya - lo reenvío tal cual');
      return mediaBuffer; // ya está en webp
    }

    if (mediaType === 'image') {
      // imagen estática → webp estático
      const webpBuffer = await sharp(mediaBuffer)
        .resize(512, 512, { fit: 'contain', background: { r:255,g:255,b:255,alpha:0 } })
        .webp({ quality: 90, lossless: false, effort: 4 })
        .toBuffer();
      console.log('✅ Imagen convertida a WebP estático');
      return webpBuffer;
    }

    // gif o video: intento crear webp animado con ffmpeg
    if (mediaType === 'gif' || mediaType === 'video') {
      const isVideo = mediaType === 'video';
      try {
        console.log('🔁 Intentando crear WebP animado con ffmpeg (puede tardar un instante)...');
        const animated = await ffmpegConvertToAnimatedWebP(mediaBuffer, isVideo);
        console.log('✅ WebP animado creado con ffmpeg, tamaño:', animated.length);
        return animated;
      } catch (ffErr) {
        console.warn('⚠️ ffmpeg no pudo crear webp animado o no está instalado. Haciendo fallback a primer frame. Error:', ffErr?.message || ffErr);
        // fallback: extraer primer frame y convertir a webp estático
        try {
          const frameBuffer = await ffmpegExtractFirstFrame(mediaBuffer);
          const webpStatic = await sharp(frameBuffer)
            .resize(512, 512, { fit: 'contain', background: { r:255,g:255,b:255,alpha:0 } })
            .webp({ quality: 90, lossless: false, effort: 4 })
            .toBuffer();
          console.log('✅ Fallback: primer frame convertido a WebP estático');
          return webpStatic;
        } catch (fallbackErr) {
          console.error('❌ Fallback también falló:', fallbackErr);
          // último recurso: devolver buffer original (probablemente no aceptado por WA)
          return mediaBuffer;
        }
      }
    }

    // si llega acá, no soportado
    console.log('❌ Tipo no soportado para conversión a sticker:', mediaType);
    return null;
  } catch (error) {
    console.error('❌ Error en convertToStickerFormat:', error);
    return null;
  }
}

async function sendSticker(sock, jid, mediaBuffer, mediaType, options = {}) {
  try {
    console.log('📤 Preparando sticker para envío...');
    const stickerBuffer = await convertToStickerFormat(mediaBuffer, mediaType, options.mimetype);

    if (!stickerBuffer) {
      console.log('❌ No se pudo convertir la media a sticker');
      return false;
    }

    const authorText = 'RobleBOT\n📷 Instagram: @robleuy';

    // Usar wa-sticker-formatter para agregar metadatos correctamente
    const sticker = new Sticker(stickerBuffer, {
      pack: options.packname || '🤖 RobleBOT',
      author: options.author || authorText,
      type: mediaType === 'gif' || mediaType === 'video' ? 'full' : 'default',
      quality: 100
    });

    const finalBuffer = await sticker.toBuffer();
    
    await sock.sendMessage(jid, { sticker: finalBuffer });
    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

// Handler principal exportado
let handler = async (message, { text, args }) => {
  try {
    console.log('🚀 Iniciando comando sticker...');
    const sock = global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // 1. Buscar media en el *mensaje actual* (si el usuario adjuntó la imagen/video con el comando en el caption)
    let quotedMedia = await detectCurrentMedia();

    // 2. Si no hay media en el mensaje actual, buscar media *citada*
    if (!quotedMedia) {
        console.log('📁 Buscando media citado...');
        quotedMedia = await detectQuotedMedia();
    }
    
    if (!quotedMedia) {
      return await message.reply(
        '❌ *Adjunta o Responde a una imagen, video o GIF con el comando /sticker para crear un sticker.*'
      );
    }

    const mediaType = quotedMedia.type;
    console.log(`✅ ${mediaType.toUpperCase()} encontrado, procesando...`);

    const authorText = 'RobleBOT\n📷 Instagram: @robleuy';

    const success = await sendSticker(sock, message.from, quotedMedia.data, mediaType, {
      mimetype: quotedMedia.mimetype,
      packname: '🤖 RobleBOT',
      author: authorText
    });

    if (!success) {
      return await message.reply(`❌ Error al crear/mandar el sticker desde el ${mediaType}.`);
    }

  } catch (error) {
    console.error('❌ Error general en handler:', error);
    await message.reply('❌ Ocurrió un error al crear el sticker.');
  }
};

handler.help = ['sticker', 'stickers', 's'];
handler.tags = ['stickers'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;
