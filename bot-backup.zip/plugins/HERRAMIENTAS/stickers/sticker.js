// stickers.js
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { Sticker } = require('wa-sticker-formatter');
const execFileAsync = promisify(execFile);

// ─── Configuración de límites ────────────────────────────────────────────────
const MAX_STICKER_BYTES   = 850_000;  // 850 KB - Límite estricto y seguro para WhatsApp
const MAX_DURATION_SEC    = 5;        // Duración máxima permitida
const TARGET_FPS          = 10;       // Ideal para stickers animados (evita lag y peso)
const WEBP_QUALITY_START  = 55;       // Calidad inicial balanceada para videos de celular
const WEBP_QUALITY_MIN    = 20;       // Calidad mínima de rescate
// ─────────────────────────────────────────────────────────────────────────────

function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    botJid = botJid.split(':')[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

// ─── Detección de media ───────────────────────────────────────────────────────

async function detectCurrentMedia() {
  try {
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    if (baileyMsg.message?.imageMessage) {
      try {
        const stream = await downloadContentFromMessage(baileyMsg.message.imageMessage, 'image');
        return { data: await streamToBuffer(stream), mimetype: baileyMsg.message.imageMessage.mimetype || 'image/jpeg', type: 'image' };
      } catch { return null; }
    }

    if (baileyMsg.message?.videoMessage) {
      const isGif = !!baileyMsg.message.videoMessage.gifPlayback;
      try {
        const stream = await downloadContentFromMessage(baileyMsg.message.videoMessage, 'video');
        return { data: await streamToBuffer(stream), mimetype: baileyMsg.message.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
      } catch { return null; }
    }

    return null;
  } catch (error) {
    console.error('❌ Error en detectCurrentMedia:', error);
    return null;
  }
}

async function detectQuotedMedia() {
  try {
    const baileyMsg = global.lastBaileyMessage;
    if (!baileyMsg) return null;

    let contextInfo =
      baileyMsg.message?.extendedTextMessage?.contextInfo ||
      baileyMsg.message?.imageMessage?.contextInfo ||
      baileyMsg.message?.videoMessage?.contextInfo ||
      null;

    if (!contextInfo?.quotedMessage) return null;
    const q = contextInfo.quotedMessage;

    if (q.stickerMessage) {
      try {
        const stream = await downloadContentFromMessage(q.stickerMessage, 'sticker');
        return { data: await streamToBuffer(stream), mimetype: q.stickerMessage.mimetype || 'image/webp', type: 'sticker' };
      } catch { return null; }
    }

    if (q.imageMessage) {
      try {
        const stream = await downloadContentFromMessage(q.imageMessage, 'image');
        return { data: await streamToBuffer(stream), mimetype: q.imageMessage.mimetype || 'image/jpeg', type: 'image' };
      } catch { return null; }
    }

    if (q.videoMessage) {
      const isGif = !!q.videoMessage.gifPlayback;
      try {
        const stream = await downloadContentFromMessage(q.videoMessage, 'video');
        return { data: await streamToBuffer(stream), mimetype: q.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
      } catch { return null; }
    }

    return null;
  } catch (error) {
    console.error('❌ Error en detectQuotedMedia:', error);
    return null;
  }
}

// ─── Conversión con ffmpeg ────────────────────────────────────────────────────

async function ffmpegConvertToAnimatedWebP(inputBuffer, isVideo = true) {
  const inputExt = isVideo ? 'mp4' : 'gif';
  const inputPath = tmpFileName(inputExt);
  const outputPath = tmpFileName('webp');

  await fs.writeFile(inputPath, inputBuffer);

  let realDuration = MAX_DURATION_SEC;
  try {
    const { stdout } = await execFileAsync('ffprobe', [
      '-v', 'error',
      '-show_entries', 'format=duration',
      '-of', 'default=noprint_wrappers=1:nokey=1',
      inputPath
    ], { timeout: 10_000 });
    const parsed = parseFloat(stdout.trim());
    if (!isNaN(parsed) && parsed > 0) realDuration = parsed;
  } catch { /* ffprobe no disponible */ }

  const duration = Math.min(realDuration, MAX_DURATION_SEC);
  let quality = WEBP_QUALITY_START;
  let result = null;

  while (quality >= WEBP_QUALITY_MIN) {
    try {
      await fs.unlink(outputPath).catch(() => {});

      // Forzar reducción estricta de FPS, bitrate y escala para videos pesados de 60fps
      const args = [
        '-y',
        '-i', inputPath,
        '-t', String(duration),
        '-vf', `fps=${TARGET_FPS},scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000`,
        '-vcodec', 'libwebp',
        '-lossless', '0',
        '-qscale', String(quality),
        '-b:v', '200k', // Límite de bitrate agresivo para mantener el archivo ligero
        '-compression_level', '6',
        '-preset', 'picture',
        '-loop', '0',
        '-an',
        '-vsync', 'cfr',
        outputPath
      ];

      await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 40_000 });

      const buf = await fs.readFile(outputPath);
      console.log(`🔍 Intentando WebP animado (Calidad ${quality}): ${(buf.length / 1024).toFixed(1)} KB`);

      if (buf.length <= MAX_STICKER_BYTES) {
        result = buf;
        break;
      }

      console.warn(`⚠️ Excede el tamaño (${(buf.length / 1024).toFixed(0)} KB), reduciendo calidad...`);
      quality -= 12; // Bajada más rápida para no eternizar el bucle
    } catch (err) {
      console.error('❌ ffmpeg falló en bucle:', err?.message || err);
      break;
    }
  }

  await Promise.allSettled([fs.unlink(inputPath).catch(() => {}), fs.unlink(outputPath).catch(() => {})]);

  if (!result) {
    throw new Error(`Incapaz de comprimir video por debajo del límite de WhatsApp.`);
  }

  return result;
}

async function ffmpegExtractFirstFrame(inputBuffer) {
  const inputPath = tmpFileName('mp4');
  const framePath = tmpFileName('jpg');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    await execFileAsync('ffmpeg', [
      '-y', '-i', inputPath,
      '-ss', '0', '-vframes', '1',
      framePath
    ], { windowsHide: true, timeout: 15_000 });
    return await fs.readFile(framePath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(() => {}), fs.unlink(framePath).catch(() => {})]);
  }
}

// ─── Conversión principal ─────────────────────────────────────────────────────

async function convertToStickerFormat(mediaBuffer, mediaType) {
  try {
    console.log(`🔄 Convirtiendo ${mediaType} a formato sticker...`);

    if (mediaType === 'sticker') {
      if (mediaBuffer.length > MAX_STICKER_BYTES) {
        return await sharp(mediaBuffer)
          .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .webp({ quality: 75, effort: 5 })
          .toBuffer();
      }
      return mediaBuffer;
    }

    if (mediaType === 'image') {
      for (const quality of [85, 65, 45]) {
        const buf = await sharp(mediaBuffer)
          .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .webp({ quality, lossless: false, effort: 5 })
          .toBuffer();
        if (buf.length <= MAX_STICKER_BYTES) return buf;
      }
      return await sharp(mediaBuffer)
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 25, effort: 6 })
        .toBuffer();
    }

    if (mediaType === 'gif' || mediaType === 'video') {
      try {
        return await ffmpegConvertToAnimatedWebP(mediaBuffer, mediaType === 'video');
      } catch (ffErr) {
        console.warn('⚠️ Fallback al primer frame por exceso de peso o error:', ffErr.message);
        try {
          const frame = await ffmpegExtractFirstFrame(mediaBuffer);
          return await sharp(frame)
            .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp({ quality: 70, effort: 5 })
            .toBuffer();
        } catch (fallbackErr) {
          console.error('❌ Fallback falló:', fallbackErr);
        }
        return null;
      }
    }

    return null;
  } catch (error) {
    console.error('❌ Error en convertToStickerFormat:', error);
    return null;
  }
}

// ─── Envío ────────────────────────────────────────────────────────────────────

async function sendSticker(sock, jid, mediaBuffer, mediaType, options = {}) {
  try {
    console.log('📤 Preparando sticker...');
    const processedBuffer = await convertToStickerFormat(mediaBuffer, mediaType);

    if (!processedBuffer) {
      console.log('❌ Error en la conversión del buffer');
      return false;
    }

    let finalBuffer;

    // CRUCIAL: Si es video/gif, NO usamos wa-sticker-formatter ya que corrompe/infla el archivo final.
    // Le inyectamos los metadatos directamente si es imagen, o enviamos el WebP optimizado de ffmpeg.
    if (mediaType === 'gif' || mediaType === 'video') {
      finalBuffer = processedBuffer; 
    } else {
      const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
      const sticker = new Sticker(processedBuffer, {
        pack: options.packname || 'RobleBOT',
        author: options.author || authorText,
        type: 'default',
        quality: 100
      });
      finalBuffer = await sticker.toBuffer();
    }

    console.log(`📦 Peso definitivo enviado a WhatsApp: ${(finalBuffer.length / 1024).toFixed(1)} KB`);
    
    await sock.sendMessage(jid, { sticker: finalBuffer });
    console.log('✅ Sticker enviado exitosamente');
    return true;
  } catch (error) {
    console.error('❌ Error crítico al enviar sticker:', error);
    return false;
  }
}

// ─── Handler principal ────────────────────────────────────────────────────────

let handler = async (message, { text, args }) => {
  try {
    console.log('🚀 Iniciando comando sticker...');
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: Conexión no disponible.');

    let media = await detectCurrentMedia();
    if (!media) {
      console.log('📁 Sin media en mensaje actual, buscando citado...');
      media = await detectQuotedMedia();
    }

    if (!media) {
      return await message.reply(
        '❌ *Adjunta o responde a una imagen, video o GIF con el comando /sticker para crear un sticker.*'
      );
    }

    console.log(`✅ Media encontrada: ${media.type.toUpperCase()} (${(media.data.length / 1024).toFixed(1)} KB)`);

    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
    const success = await sendSticker(sock, message.from, media.data, media.type, {
      mimetype: media.mimetype,
      packname: 'RobleBOT',
      author: authorText
    });

    if (!success) {
      return await message.reply(`❌ El video es demasiado pesado/complejo para procesarse como animado. Se intentó procesar pero excede los límites de WhatsApp.`);
    }

  } catch (error) {
    console.error('❌ Error general en handler:', error);
    await message.reply('❌ Ocurrió un error al crear el sticker.');
  }
};

handler.help = ['sticker', 'stickers', 's'];
handler.tags = ['stickers'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;