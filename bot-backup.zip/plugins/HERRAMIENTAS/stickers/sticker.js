const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const crypto = require('crypto');

// Utilidad para limpiar archivos temporales de forma segura
const unlinkAsync = promisify(fs.unlink);

/**
 * Recorta un video a un máximo de 10 segundos usando FFmpeg
 */
function trimVideo(inputBuffer) {
  return new Promise((resolve, reject) => {
    // Crear nombres únicos para evitar conflictos entre usuarios
    const tempId = crypto.randomBytes(6).toString('hex');
    const inputPath = path.join(__dirname, `input_${tempId}.mp4`);
    const outputPath = path.join(__dirname, `output_${tempId}.mp4`);

    // Escribir el buffer original a un archivo temporal
    fs.writeFileSync(inputPath, inputBuffer);

    ffmpeg(inputPath)
      .setStartTime(0)
      .setDuration(10) // Límite estricto de máximo 10 segundos
      .output(outputPath)
      .on('end', async () => {
        try {
          const trimmedBuffer = fs.readFileSync(outputPath);
          // Limpieza de archivos temporales de inmediato
          if (fs.existsSync(inputPath)) await unlinkAsync(inputPath);
          if (fs.existsSync(outputPath)) await unlinkAsync(outputPath);
          resolve(trimmedBuffer);
        } catch (err) {
          reject(err);
        }
      })
      .on('error', async (err) => {
        if (fs.existsSync(inputPath)) await unlinkAsync(inputPath).catch(() => {});
        if (fs.existsSync(outputPath)) await unlinkAsync(outputPath).catch(() => {});
        reject(err);
      })
      .run();
  });
}

/**
 * Envía el sticker al chat (Soporta estáticos y animados)
 */
async function sendSticker(sock, jid, mediaBuffer, isAnimated = false, options = {}) {
  try {
    if (!mediaBuffer || !(mediaBuffer instanceof Buffer)) {
      throw new Error('Buffer de medio no válido.');
    }

    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    const sticker = new Sticker(mediaBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: StickerTypes.FULL, 
      // Calidad ultra-comprimida para evitar fallos por falta de espacio en disco
      quality: isAnimated ? 15 : 80, 
      width: 512,  
      height: 512
    });

    const stickerBuffer = await sticker.toBuffer();
    
    if (stickerBuffer.length > 1 * 1024 * 1024) {
      console.warn(`⚠️ El sticker animado supera el límite de WhatsApp: ${(stickerBuffer.length / 1024 / 1024).toFixed(2)} MB`);
    }

    await sock.sendMessage(jid, { sticker: stickerBuffer });
    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { usedPrefix, command }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    const quoted = message.quoted ? message.quoted : message;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image|video/.test(mime)) {
      return await message.reply(
        `📸 *Creador de Stickers* 🎥\n\n` +
        `📌 *Uso:*\n` +
        `• Responde a una *Imagen*, *Video* o *GIF* usando el comando:\n` +
        `👉 *${usedPrefix + command}*`
      );
    }

    await message.reply('⏳ *Procesando multimedia a sticker (Máx 10s)...*');

    let mediaBuffer = await quoted.download();
    if (!mediaBuffer) {
      return await message.reply('❌ No se pudo descargar el archivo multimedia.');
    }

    const isAnimated = mime.includes('video');

    // Si es video, aplicamos el recorte de los primeros 10 segundos
    if (isAnimated) {
      try {
        mediaBuffer = await trimVideo(mediaBuffer);
      } catch (trimError) {
        console.error('❌ Error al recortar video con FFmpeg:', trimError);
        return await message.reply('❌ Tu servidor no tiene espacio en disco (ENOSPC) o no tiene instalado FFmpeg para procesar videos.');
      }
    }

    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
    
    const success = await sendSticker(sock, message.from, mediaBuffer, isAnimated, {
      packname: 'RobleBOT',
      author: authorText
    });

    if (!success) {
      await message.reply('⚠️ Error al enviar: Revisa si el almacenamiento de tu servidor está lleno o si el video es demasiado pesado.');
    }

  } catch (error) {
    console.error('❌ Error general en el plugin de sticker:', error);
    if (error.code === 'ENOSPC') {
      await message.reply('❌ El servidor del bot se ha quedado sin espacio en disco duro. Limpia el almacenamiento.');
    } else {
      await message.reply('❌ Ocurrió un error inesperado al procesar el sticker.');
    }
  }
};

handler.help = ['s', 'sticker', 'stickers'];
handler.tags = ['sticker'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;