const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de la API de video brat
 */
function buildBratVideoApiUrl(text) {
  const baseUrl = 'https://api.delirius.store/canvas/bratvideo';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?text=${encodedText}`;
}

/**
 * Descarga el video desde la API y lo devuelve como buffer
 */
async function downloadBratVideo(videoUrl) {
  try {
    const response = await axios.get(videoUrl, {
      responseType: 'arraybuffer',
      timeout: 30000 // Mayor timeout para videos
    });

    return Buffer.from(response.data);
  } catch (error) {
    if (error.code === 'ENOTFOUND') {
      console.error('❌ Error DNS: No se pudo resolver la API.');
    } else if (axios.isAxiosError(error) && error.code === 'ECONNABORTED') {
      console.error('❌ Timeout: La API tardó demasiado.');
    } else if (error.response) {
      console.error(`❌ Error HTTP ${error.response.status}: ${error.response.statusText}`);
    } else {
      console.error('❌ Error desconocido:', error.message);
    }
    return null;
  }
}

/**
 * Envía el sticker de video al chat
 */
async function sendVideoSticker(sock, jid, videoBuffer, options = {}) {
  try {
    if (!videoBuffer || !(videoBuffer instanceof Buffer)) {
      throw new Error('Buffer de video no válido.');
    }

    const botNumber = getBotNumber(sock);
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    // Configuración optimizada para stickers de video
    const sticker = new Sticker(videoBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'full', // Usar 'full' en lugar de 'video' para mejor compatibilidad
      quality: 50, // Reducir calidad para evitar bugs visuales
      background: 'transparent', // Fondo transparente
      crop: false, // No recortar el video
      fps: 15, // Limitar FPS para mejor rendimiento
      loop: 0 // Loop infinito
    });

    const stickerBuffer = await sticker.toBuffer();
    
    // Enviar con configuraciones específicas para video
    await sock.sendMessage(jid, { 
      sticker: stickerBuffer,
      mimetype: 'image/webp'
    }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker de video enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker de video:', error);
    return false;
  }
}

/**
 * Función alternativa para enviar sticker con diferentes configuraciones
 */
async function sendAlternativeSticker(sock, jid, videoBuffer, options = {}) {
  try {
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    // Configuración alternativa más simple
    const sticker = new Sticker(videoBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'default', // Usar tipo default
      quality: 30, // Calidad más baja
      background: '#00000000', // Fondo transparente explícito
      crop: true // Permitir recorte
    });

    const stickerBuffer = await sticker.toBuffer();
    
    await sock.sendMessage(jid, { 
      sticker: stickerBuffer
    }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker alternativo enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker alternativo:', error);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    // Usar el socket que recibió este mensaje específicamente
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `🎬 *Crea stickers de video estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat2 Hola Mundo\n` +
        `• /bratv Mi texto\n` +
        `• /vbrat Texto aquí\n` +
        `• /videobrat Mi mensaje\n` +
        `• /bratvideo Contenido\n\n` +
        `✨ *Genera stickers animados con efecto brat*`
      );
    }

    await message.reply('⏳ *Generando sticker de video brat...*');

    // Construir URL de la API
    const apiUrl = buildBratVideoApiUrl(text);

    const videoBuffer = await downloadBratVideo(apiUrl);
    if (!videoBuffer) {
      return await message.reply(
        '❌ No se pudo generar el sticker de video.\n' +
        '🔁 Intenta nuevamente o verifica que el texto no sea muy largo.'
      );
    }

    const botNumber = getBotNumber(sock);
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';

    // Intentar enviar con configuración optimizada
    let success = await sendVideoSticker(sock, message.from, videoBuffer, {
      packname: 'RobleBOT Video',
      author: authorText,
      quoted: message._baileyMessage
    });

    // Si falla, intentar con configuración alternativa
    if (!success) {
      console.log('🔄 Intentando con configuración alternativa...');
      success = await sendAlternativeSticker(sock, message.from, videoBuffer, {
        packname: 'RobleBOT Video',
        author: authorText,
        quoted: message._baileyMessage
      });
    }

    if (!success) {
      await message.reply('⚠️ Se generó el video pero no se pudo enviar como sticker.');
    }

  } catch (error) {
    console.error('❌ Error general:', error);
    await message.reply('❌ Error inesperado al procesar el video.');
  }
};

handler.help = ['brat2 <texto>', 'bratv <texto>', 'vbrat <texto>', 'videobrat <texto>', 'bratvideo <texto>'];
handler.tags = ['sticker'];
handler.command = /^(brat2|bratv|vbrat|videobrat|bratvideo)$/i;

module.exports = handler;