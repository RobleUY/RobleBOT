const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

const MAX_CHARS = 100;

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye las URLs de las APIs de video brat
 */
function buildBratVideoApiUrls(text) {
  const encodedText = encodeURIComponent(text);
  return [
    `https://api.delirius.online/canvas/bratvideo?text=${encodedText}`,
    `https://api.delirius.store/canvas/bratvideo?text=${encodedText}`,
    `https://www.sankavollerei.web.id/imagecreator/bratvideo?apikey=planaai&text=${encodedText}`
  ];
}

/**
 * Descarga el video desde una URL y lo devuelve como buffer
 */
async function downloadBratVideo(videoUrl) {
  try {
    const response = await axios.get(videoUrl, {
      responseType: 'arraybuffer',
      timeout: 15000
    });
    const buf = Buffer.from(response.data);
    if (buf.length < 1000) return null;
    return buf;
  } catch (error) {
    console.error('❌ Error descargando video brat:', error.message);
    return null;
  }
}

/**
 * Carrera entre todas las fuentes de video brat — gana la primera que devuelva buffer válido
 */
async function bratVideoEnCarrera(text) {
  const urls = buildBratVideoApiUrls(text);

  return new Promise((resolve) => {
    let resolved = false;
    let pendientes = urls.length;

    for (const url of urls) {
      downloadBratVideo(url).then(buf => {
        if (resolved) return;
        if (buf) { resolved = true; resolve(buf); }
        else { pendientes--; if (pendientes === 0) resolve(null); }
      }).catch(() => {
        if (resolved) return;
        pendientes--;
        if (pendientes === 0) resolve(null);
      });
    }
  });
}

/**
 * Envía el sticker de video al chat
 */
async function sendVideoSticker(sock, jid, videoBuffer, options = {}) {
  try {
    if (!videoBuffer || !(videoBuffer instanceof Buffer)) {
      throw new Error('Buffer de video no válido.');
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const sticker = new Sticker(videoBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'full',
      quality: 50,
      background: 'transparent',
      crop: false,
      fps: 15,
      loop: 0
    });

    const stickerBuffer = await sticker.toBuffer();

    await sock.sendMessage(jid, {
      sticker: stickerBuffer,
      mimetype: 'image/webp'
    }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker de video enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker de video:', error);
    return false;
  }
}

/**
 * Función alternativa para enviar sticker con diferentes configuraciones
 */
async function sendAlternativeSticker(sock, jid, videoBuffer, options = {}) {
  try {
    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const sticker = new Sticker(videoBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 30,
      background: '#00000000',
      crop: true
    });

    const stickerBuffer = await sticker.toBuffer();

    await sock.sendMessage(jid, {
      sticker: stickerBuffer
    }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker alternativo enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker alternativo:', error);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `🎬 *Crea stickers de video estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat2 Hola Mundo\n` +
        `• /bratv Mi texto\n` +
        `• /vbrat Texto aquí\n` +
        `• /videobrat Mi mensaje\n` +
        `• /bratvideo Contenido\n\n` +
        `✨ *Genera stickers animados con efecto brat*\n` +
        `⚠️ *Máximo ${MAX_CHARS} caracteres*`
      );
    }

    if (text.length > MAX_CHARS) {
      return await message.reply(
        `❌ *Texto demasiado largo*\n\n` +
        `📏 Tu texto tiene *${text.length} caracteres*\n` +
        `✅ El máximo permitido es *${MAX_CHARS} caracteres*\n\n` +
        `✂️ Acortá el texto e intentá de nuevo.`
      );
    }

    await message.reply('⏳ *Generando sticker de video brat...*');

    const videoBuffer = await bratVideoEnCarrera(text);

    if (!videoBuffer) {
      return await message.reply(
        '❌ No se pudo generar el sticker de video.\n' +
        '🔁 Intenta nuevamente o verifica que el texto no sea muy largo.'
      );
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    let success = await sendVideoSticker(sock, message.from, videoBuffer, {
      packname: 'RobleBOT Video',
      author: authorText,
      quoted: message._baileyMessage
    });

    if (!success) {
      console.log('🔄 Intentando con configuración alternativa...');
      success = await sendAlternativeSticker(sock, message.from, videoBuffer, {
        packname: 'RobleBOT Video',
        author: authorText,
        quoted: message._baileyMessage
      });
    }

    if (!success) {
      await message.reply('⚠️ Se generó el video pero no se pudo enviar como sticker.');
    }

  } catch (error) {
    console.error('❌ Error general:', error);
    await message.reply('❌ Error inesperado al procesar el video.');
  }
};

handler.help = ['brat2 <texto>', 'bratv <texto>', 'vbrat <texto>', 'videobrat <texto>', 'bratvideo <texto>'];
handler.tags = ['sticker'];
handler.command = /^(brat2|bratv|vbrat|videobrat|bratvideo)$/i;

module.exports = handler;