// emojimix.js
const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    
    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];
    
    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

async function fetchEmojiMix(emoji1, emoji2) {
  try {
    const apiUrl = `https://www.sankavollerei.com/tools/emojimix?apikey=planaai&emoji1=${encodeURIComponent(emoji1)}&emoji2=${encodeURIComponent(emoji2)}`;
    
    console.log('🔗 Consultando API EmojiMix:', apiUrl);
    
    // La API devuelve la imagen directamente
    const response = await axios.get(apiUrl, {
      timeout: 15000,
      responseType: 'arraybuffer'
    });
    
    if (response.status === 200 && response.data) {
      const buffer = Buffer.from(response.data);
      console.log(`✅ Imagen obtenida: ${buffer.length} bytes`);
      
      // Verificar que sea un PNG válido
      if (buffer.length > 0 && buffer[0] === 0x89 && buffer[1] === 0x50) {
        return buffer;
      } else {
        console.error('❌ El buffer no es un PNG válido');
        return null;
      }
    }
    
    return null;
  } catch (error) {
    console.error('❌ Error al obtener EmojiMix:', error.message);
    if (error.response) {
      console.error('📄 Estado de respuesta:', error.response.status);
    }
    return null;
  }
}

function extractEmojis(text) {
  // Regex para detectar emojis (incluyendo emojis compuestos)
  const emojiRegex = /(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/gu;
  const emojis = text.match(emojiRegex);
  return emojis || [];
}

async function sendEmojiMixSticker(sock, jid, imageBuffer, emoji1, emoji2, quotedMsg) {
  try {
    console.log('📤 Convirtiendo EmojiMix a sticker...');
    
    const authorText = '\nInstagram: @robleuy\n\nwww.robleuy.site/roblebot';
    
    const sticker = new Sticker(imageBuffer, {
      pack: '🤖 RobleBOT',
      author: authorText,
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    
    await sock.sendMessage(jid, { sticker: stickerBuffer }, quotedMsg ? { quoted: quotedMsg } : {});
    console.log('✅ Sticker EmojiMix enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker EmojiMix:', error);
    return false;
  }
}

let handler = async (message, { text, args }) => {
  try {
    console.log('🎨 Iniciando comando emojimix...');
    
    const sock = global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // Verificar que se proporcionó texto
    if (!text || text.trim().length === 0) {
      return await message.reply(
        '❌ *Debes proporcionar 2 emojis para mezclar.*\n\n' +
        '📝 *Uso:*\n' +
        '• `/emojimix 😍😎`\n' +
        '• `/emojimix 🔥💀`\n' +
        '• `/emojimix 😂🥺`\n\n' +
        '💡 *Tip:* Algunos emojis pueden no funcionar.'
      );
    }

    // Extraer emojis del texto
    const emojis = extractEmojis(text);
    
    if (emojis.length < 2) {
      return await message.reply(
        '❌ *Necesito exactamente 2 emojis para mezclar.*\n\n' +
        '📝 *Ejemplo correcto:*\n' +
        '• `.emojimix 😍😎`\n\n' +
        `🔍 *Encontré:* ${emojis.length} emoji(s)`
      );
    }

    const emoji1 = emojis[0];
    const emoji2 = emojis[1];
    
    console.log(`🎭 Mezclando: ${emoji1} + ${emoji2}`);

    // Enviar mensaje de espera
    await message.reply(`⏳ Creando sticker ${emoji1} + ${emoji2}...`);

    // Obtener la mezcla de emojis
    const emojiMixBuffer = await fetchEmojiMix(emoji1, emoji2);
    
    if (!emojiMixBuffer || emojiMixBuffer.length === 0) {
      return await message.reply(
        `❌ *No se pudo crear la mezcla de ${emoji1} y ${emoji2}*\n\n` +
        '💡 *Posibles razones:*\n' +
        '• Uno o ambos emojis no están en la base de datos\n' +
        '• Error de conexión con la API\n' +
        '• Combinación no disponible\n\n' +
        '🔄 *Intenta con otros emojis populares como:*\n' +
        '😍, 😎, 🔥, 💀, 😂, 🥺, ❤️, 🎉'
      );
    }

    console.log(`📊 Tamaño del buffer: ${emojiMixBuffer.length} bytes`);

    // Enviar como sticker
    const success = await sendEmojiMixSticker(sock, message.from, emojiMixBuffer, emoji1, emoji2, message._baileyMessage);

    if (!success) {
      return await message.reply(
        '❌ *Error al crear el sticker EmojiMix.*\n\n' +
        '🔄 Por favor intenta nuevamente.'
      );
    }

  } catch (error) {
    console.error('❌ Error general en handler emojimix:', error);
    await message.reply(
      '❌ *Ocurrió un error al crear el EmojiMix.*\n\n' +
      `📋 *Error:* ${error.message}\n\n` +
      '🔄 Por favor intenta nuevamente con otros emojis.'
    );
  }
};

handler.help = ['emojimix'];
handler.tags = ['stickers', 'fun'];
handler.command = /^(emojimix)$/i;

module.exports = handler;