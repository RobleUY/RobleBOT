const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

const MAX_CHARS = 100;

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de tu nueva API (RobleAPI)
 */
function buildBratApiUrl(text) {
  const baseUrl = 'https://robleuy.vercel.app/robleapi/imagen/brat';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?q=${encodedText}`;
}

/**
 * Descarga la imagen desde la API y la devuelve como buffer
 */
async function downloadBratImage(imageUrl) {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 15000
    });

    return Buffer.from(response.data);
  } catch (error) {
    if (error.code === 'ENOTFOUND') {
      console.error('❌ Error DNS: No se pudo resolver tu API.');
    } else if (axios.isAxiosError(error) && error.code === 'ECONNABORTED') {
      console.error('❌ Timeout: Tu API tardó demasiado.');
    } else if (error.response) {
      console.error(`❌ Error HTTP ${error.response.status}: ${error.response.statusText}`);
    } else {
      console.error('❌ Error desconocido:', error.message);
    }
    return null;
  }
}

/**
 * Envía el sticker al chat
 */
async function sendSticker(sock, jid, imageBuffer, options = {}) {
  try {
    if (!imageBuffer || !(imageBuffer instanceof Buffer)) {
      throw new Error('Buffer de imagen no válido.');
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const sticker = new Sticker(imageBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    await sock.sendMessage(jid, { sticker: stickerBuffer }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat Hola Mundo\n\n` +
        `⚠️ *Máximo ${MAX_CHARS} caracteres*`
      );
    }

    if (text.length > MAX_CHARS) {
      return await message.reply(
        `❌ *Texto demasiado largo*\n\n` +
        `📏 Tu texto tiene *${text.length} caracteres*\n` +
        `✅ El máximo permitido es *${MAX_CHARS} caracteres*\n\n` +
        `✂️ Acortá el texto e intentá de nuevo.`
      );
    }

    await message.reply('⏳ *Generando sticker brat...*');

    const apiUrl = buildBratApiUrl(text);

    const imageBuffer = await downloadBratImage(apiUrl);
    if (!imageBuffer) {
      return await message.reply(
        '❌ No se pudo generar el sticker.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const success = await sendSticker(sock, message.from, imageBuffer, {
      packname: 'RobleBOT',
      author: authorText,
      quoted: message._baileyMessage
    });

    if (!success) {
      await message.reply('⚠️ Se generó pero no se pudo enviar.');
    }

  } catch (error) {
    console.error('❌ Error general:', error);
    await message.reply('❌ Error inesperado.');
  }
};

handler.help = ['brat <texto>'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;

module.exports = handler;