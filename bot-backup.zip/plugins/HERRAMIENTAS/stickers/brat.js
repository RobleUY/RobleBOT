const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Construye la URL de la API Brat (Delirius)
 */
function buildBratApiUrl(text) {
  const baseUrl = 'https://delirius-apiofc.vercel.app/canvas/brat';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?text=${encodedText}`;
}

/**
 * Descarga la imagen desde la API y la devuelve como un buffer.
 */
async function downloadBratImage(imageUrl) {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 15000
    });

    return Buffer.from(response.data);
  } catch (error) {
    if (error.code === 'ENOTFOUND') {
      console.error('❌ Error DNS: No se pudo resolver el dominio de la API Delirius.');
    } else if (axios.isAxiosError(error) && error.code === 'ECONNABORTED') {
      console.error('❌ Timeout: La API de Brat tardó demasiado en responder.');
    } else if (error.response) {
      console.error(`❌ Error HTTP ${error.response.status}: ${error.response.statusText}`);
    } else {
      console.error('❌ Error desconocido al descargar la imagen:', error.message);
    }
    return null;
  }
}

/**
 * Envía el sticker al chat
 */
async function sendSticker(sock, jid, imageBuffer, options = {}) {
  try {
    if (!imageBuffer || !(imageBuffer instanceof Buffer)) {
      throw new Error('Buffer de imagen no válido para crear el sticker.');
    }

    const sticker = new Sticker(imageBuffer, {
      pack: options.packname || '🤖 RobleBOT',
      author: options.author || '\n📱 Numero del bot: +59892099606\n📷 Instagram: @robleuy',
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    await sock.sendMessage(jid, { sticker: stickerBuffer });
    console.log('✅ Sticker Brat enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: conexión de socket no disponible.');

    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat Hola Mundo Cruel\n`
      );
    }

    await message.reply('⏳ *Generando tu sticker Brat...*');

    // Construir URL de la API de Delirius
    const apiUrl = buildBratApiUrl(text);

    // Descargar imagen desde la API
    const imageBuffer = await downloadBratImage(apiUrl);

    if (!imageBuffer) {
      return await message.reply(
        '❌ *No se pudo crear el sticker Brat.*\n' +
        '🔁 Intenta nuevamente más tarde.'
      );
    }

    // Enviar el sticker
    const success = await sendSticker(sock, message.from, imageBuffer, {
      packname: '🤖 RobleBOT',
      author: '\n📱 Numero del bot: +59892099606\n📷 Instagram: @robleuy'
    });

    if (!success) {
      await message.reply('⚠️ El sticker fue generado, pero no se pudo enviar correctamente.');
    }

  } catch (error) {
    console.error('❌ Error general en handler-brat:', error);
    await message.reply('❌ Ocurrió un error inesperado al crear el sticker Brat.');
  }
};

handler.help = ['brat <texto>'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;

module.exports = handler;
