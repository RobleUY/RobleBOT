const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    
    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];
    
    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de la API Brat (Delirius)
 */
function buildBratApiUrl(text) {
  const baseUrl = 'https://delirius-apiofc.vercel.app/canvas/brat';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?text=${encodedText}`;
}

/**
 * Descarga la imagen desde la API y la devuelve como un buffer.
 */
async function downloadBratImage(imageUrl) {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 15000
    });
    return Buffer.from(response.data);
  } catch (error) {
    if (error.code === 'ENOTFOUND') {
      console.error('❌ Error DNS: No se pudo resolver el dominio de la API Delirius.');
    } else if (axios.isAxiosError(error) && error.code === 'ECONNABORTED') {
      console.error('❌ Timeout: La API de Brat tardó demasiado en responder.');
    } else if (error.response) {
      console.error(`❌ Error HTTP ${error.response.status}: ${error.response.statusText}`);
    } else {
      console.error('❌ Error desconocido al descargar la imagen:', error.message);
    }
    return null;
  }
}

/**
 * Envía el sticker al chat
 */
async function sendSticker(sock, jid, imageBuffer, options = {}) {
  try {
    if (!imageBuffer || !(imageBuffer instanceof Buffer)) {
      throw new Error('Buffer de imagen no válido para crear el sticker.');
    }
    
    // Obtener el número del bot dinámicamente
    const botNumber = getBotNumber(sock);
    const authorText = botNumber 
      ? `\n📱 Numero del bot: +${botNumber}\n📷 Instagram: @robleuy`
      : '\n📷 Instagram: @robleuy';
    
    const sticker = new Sticker(imageBuffer, {
      pack: options.packname || '🤖 RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 100
    });
    
    const stickerBuffer = await sticker.toBuffer();
    await sock.sendMessage(jid, { sticker: stickerBuffer });
    console.log('✅ Sticker Brat enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: conexión de socket no disponible.');
    
    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat Hola Mundo Cruel\n`
      );
    }
    
    await message.reply('⏳ *Generando tu sticker Brat...*');
    
    // Construir URL de la API de Delirius
    const apiUrl = buildBratApiUrl(text);
    
    // Descargar imagen desde la API
    const imageBuffer = await downloadBratImage(apiUrl);
    if (!imageBuffer) {
      return await message.reply(
        '❌ *No se pudo crear el sticker Brat.*\n' +
        '🔁 Intenta nuevamente más tarde.'
      );
    }
    
    // Obtener número del bot para mostrar en el autor
    const botNumber = getBotNumber(sock);
    const authorText = botNumber 
      ? `\n📱 Numero del bot: +${botNumber}\n📷 Instagram: @robleuy`
      : '\n📷 Instagram: @robleuy';
    
    // Enviar el sticker
    const success = await sendSticker(sock, message.from, imageBuffer, {
      packname: '🤖 RobleBOT',
      author: authorText
    });
    
    if (!success) {
      await message.reply('⚠️ El sticker fue generado, pero no se pudo enviar correctamente.');
    }
  } catch (error) {
    console.error('❌ Error general en handler-brat:', error);
    await message.reply('❌ Ocurrió un error inesperado al crear el sticker Brat.');
  }
};

handler.help = ['brat <texto>'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;

module.exports = handler;