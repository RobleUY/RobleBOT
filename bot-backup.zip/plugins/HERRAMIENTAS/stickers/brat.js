const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const MAX_CHARS = 100;

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Descarga el video de la API de fallback (sankavollerei) y extrae el último frame.
 * Devuelve un buffer de imagen (jpg), o null si falla.
 */
async function getLastFrameFromBratVideo(text) {
  const encodedText = encodeURIComponent(text);
  const videoUrl = `https://www.sankavollerei.web.id/imagecreator/bratvideo?apikey=planaai&text=${encodedText}`;

  let videoBuffer;
  try {
    const response = await axios.get(videoUrl, {
      responseType: 'arraybuffer',
      timeout: 10000
    });
    // Verificar que la respuesta sea realmente un video (no un JSON de error)
    const buf = Buffer.from(response.data);
    const contentType = response.headers['content-type'] || '';
    if (!contentType.includes('video') && !contentType.includes('octet-stream') && buf.length < 1000) {
      console.error('❌ Fallback API devolvió respuesta no válida:', contentType);
      return null;
    }
    videoBuffer = buf;
  } catch (error) {
    console.error('❌ Fallback API (sankavollerei) falló al descargar:', error.message);
    return null;
  }

  // Extrae el último frame con ffmpeg: primero obtiene la duración, luego hace seek
  const inputPath = tmpFileName('mp4');
  const framePath = tmpFileName('jpg');
  try {
    await fs.writeFile(inputPath, videoBuffer);

    // Obtener duración del video
    let duration = null;
    try {
      const probe = await execFileAsync('ffprobe', [
        '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        inputPath
      ], { windowsHide: true, timeout: 5_000 });
      duration = parseFloat(probe.stdout.trim());
    } catch (_) {
      // ffprobe no disponible o falló — usar sseof directamente
    }

    const args = duration && !isNaN(duration)
      ? ['-y', '-ss', String(Math.max(0, duration - 0.5)), '-i', inputPath, '-vframes', '1', framePath]
      : ['-y', '-sseof', '-0.5', '-i', inputPath, '-vframes', '1', framePath];

    await execFileAsync('ffmpeg', args, { windowsHide: true, timeout: 15_000 });
    const frameBuffer = await fs.readFile(framePath);
    console.log('✅ Último frame extraído, tamaño:', frameBuffer.length);
    return frameBuffer;
  } catch (err) {
    console.error('❌ ffmpeg no pudo extraer último frame:', err.message);
    return null;
  } finally {
    await Promise.allSettled([
      fs.unlink(inputPath).catch(() => {}),
      fs.unlink(framePath).catch(() => {})
    ]);
  }
}

/**
 * Construye la URL de tu nueva API (RobleAPI)
 */
function buildBratApiUrl(text) {
  const baseUrl = 'https://robleuy.vercel.app/robleapi/imagen/brat';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?q=${encodedText}`;
}

/**
 * Descarga la imagen desde una URL y la devuelve como buffer.
 * Devuelve null si falla o si la respuesta no es una imagen válida.
 */
async function downloadBratImage(imageUrl) {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 10000
    });

    const contentType = response.headers['content-type'] || '';
    const buf = Buffer.from(response.data);

    if (!contentType.includes('image') && !contentType.includes('octet-stream')) {
      console.error(`❌ API devolvió content-type no válido: ${contentType}`);
      return null;
    }
    if (buf.length < 500) {
      console.error('❌ API devolvió respuesta demasiado pequeña:', buf.length, 'bytes');
      return null;
    }

    return buf;
  } catch (error) {
    console.error('❌ Error descargando imagen brat:', error.message);
    return null;
  }
}

/**
 * Carrera entre todas las fuentes de imagen brat — gana la primera que devuelva buffer válido
 */
async function bratImageEnCarrera(text) {
  const encodedText = encodeURIComponent(text);
  const urls = [
    `https://api.delirius.online/canvas/brat?text=${encodedText}`,
    `https://robleuy.vercel.app/robleapi/imagen/brat?q=${encodedText}`,
  ];

  return new Promise((resolve) => {
    let resolved = false;
    let pendientes = urls.length;

    for (const url of urls) {
      downloadBratImage(url).then(buf => {
        if (resolved) return;
        if (buf) { resolved = true; resolve(buf); }
        else { pendientes--; if (pendientes === 0) resolve(null); }
      }).catch(() => {
        if (resolved) return;
        pendientes--;
        if (pendientes === 0) resolve(null);
      });
    }
  });
}

/**
 * Envía el sticker al chat
 */
async function sendSticker(sock, jid, imageBuffer, options = {}) {
  try {
    if (!imageBuffer || !(imageBuffer instanceof Buffer)) {
      throw new Error('Buffer de imagen no válido.');
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const sticker = new Sticker(imageBuffer, {
      pack: options.packname || 'RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    await sock.sendMessage(jid, { sticker: stickerBuffer }, options.quoted ? { quoted: options.quoted } : {});

    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text, conn }) => {
  try {
    const sock = message._sock || conn || global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat Hola Mundo\n\n` +
        `⚠️ *Máximo ${MAX_CHARS} caracteres*`
      );
    }

    if (text.length > MAX_CHARS) {
      return await message.reply(
        `❌ *Texto demasiado largo*\n\n` +
        `📏 Tu texto tiene *${text.length} caracteres*\n` +
        `✅ El máximo permitido es *${MAX_CHARS} caracteres*\n\n` +
        `✂️ Acortá el texto e intentá de nuevo.`
      );
    }

    await message.reply('⏳ *Generando sticker brat...*');

    let imageBuffer = await bratImageEnCarrera(text);

    // Fallback final: extraer último frame del video de sankavollerei
    if (!imageBuffer) {
      console.log('⚠️ Todas las APIs de imagen fallaron. Intentando fallback con último frame del video...');
      imageBuffer = await getLastFrameFromBratVideo(text);
    }

    if (!imageBuffer) {
      return await message.reply(
        '❌ No se pudo generar el sticker.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const success = await sendSticker(sock, message.from, imageBuffer, {
      packname: 'RobleBOT',
      author: authorText,
      quoted: message._baileyMessage
    });

    if (!success) {
      await message.reply('⚠️ Se generó pero no se pudo enviar.');
    }

  } catch (error) {
    console.error('❌ Error general:', error);
    await message.reply('❌ Error inesperado.');
  }
};

handler.help = ['brat <texto>'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;

module.exports = handler;