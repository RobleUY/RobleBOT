const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;

    botJid = botJid.split(":")[0];
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

/**
 * Construye la URL de tu nueva API (RobleAPI)
 */
function buildBratApiUrl(text) {
  const baseUrl = 'https://www.robleuy.site/robleapi/imagen/brat';
  const encodedText = encodeURIComponent(text);
  return `${baseUrl}?q=${encodedText}`;
}

/**
 * Descarga la imagen desde la API y la devuelve como buffer
 */
async function downloadBratImage(imageUrl) {
  try {
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 15000
    });

    return Buffer.from(response.data);
  } catch (error) {
    if (error.code === 'ENOTFOUND') {
      console.error('❌ Error DNS: No se pudo resolver tu API.');
    } else if (axios.isAxiosError(error) && error.code === 'ECONNABORTED') {
      console.error('❌ Timeout: Tu API tardó demasiado.');
    } else if (error.response) {
      console.error(`❌ Error HTTP ${error.response.status}: ${error.response.statusText}`);
    } else {
      console.error('❌ Error desconocido:', error.message);
    }
    return null;
  }
}

/**
 * Envía el sticker al chat
 */
async function sendSticker(sock, jid, imageBuffer, options = {}) {
  try {
    if (!imageBuffer || !(imageBuffer instanceof Buffer)) {
      throw new Error('Buffer de imagen no válido.');
    }

    const botNumber = getBotNumber(sock);
    const authorText = botNumber 
      ? `\n📱 Numero del bot: +${botNumber}\n📷 Instagram: @robleuy`
      : '\n📷 Instagram: @robleuy';

    const sticker = new Sticker(imageBuffer, {
      pack: options.packname || '🤖 RobleBOT',
      author: options.author || authorText,
      type: 'default',
      quality: 100
    });

    const stickerBuffer = await sticker.toBuffer();
    await sock.sendMessage(jid, { sticker: stickerBuffer });

    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

let handler = async (message, { text }) => {
  try {
    const sock = global.conn;
    if (!sock) return await message.reply('❌ Error: socket no disponible.');

    if (!text) {
      return await message.reply(
        `✍️ *Crea stickers estilo Brat*\n\n` +
        `📌 *Uso:*\n` +
        `• /brat Hola Mundo\n`
      );
    }

    await message.reply('⏳ *Generando sticker brat...*');

    // 👉 NUEVA API
    const apiUrl = buildBratApiUrl(text);

    const imageBuffer = await downloadBratImage(apiUrl);
    if (!imageBuffer) {
      return await message.reply(
        '❌ No se pudo generar el sticker.\n' +
        '🔁 Intenta nuevamente.'
      );
    }

    const botNumber = getBotNumber(sock);
    const authorText = botNumber 
      ? `\n📷 Instagram: @robleuy`
      : '\n📷 Instagram: @robleuy';

    const success = await sendSticker(sock, message.from, imageBuffer, {
      packname: '🤖 RobleBOT',
      author: authorText
    });

    if (!success) {
      await message.reply('⚠️ Se generó pero no se pudo enviar.');
    }

  } catch (error) {
    console.error('❌ Error general:', error);
    await message.reply('❌ Error inesperado.');
  }
};

handler.help = ['brat <texto>'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;

module.exports = handler;