const { Jimp } = require('jimp');
const axios = require('axios');

let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let targetJid;

        // Verificar si se usó "me" o "yo"
        const firstArg = args[0]?.toLowerCase();
        
        if (firstArg === 'me' || firstArg === 'yo') {
            targetJid = message.sender;
        } else if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
        } else if (args[0]) {
            // Número de teléfono: limpiar y convertir a JID
            const numero = args[0].replace(/[^0-9]/g, '')
            if (!numero) return message.reply('⚠️ Número inválido.')
            targetJid = `${numero}@s.whatsapp.net`
        } else {
            return await message.reply('⚠️ Uso:\n• `.puto me`\n• `.puto @usuario`\n• `.puto +59894972196`');
        }

        // Obtener URL de avatar
        let avatarUrl;
        try {
            avatarUrl = await conn.profilePictureUrl(targetJid, 'image');
        } catch {
            return await message.reply('❌ No se pudo obtener la foto de perfil.\n_Posible razón: el usuario no tiene foto de perfil o la tiene privada para el bot._');
        }

        // Descargar imagen como buffer
        const { data } = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
        const image = await Jimp.read(Buffer.from(data));

        // Aplicar filtro arcoíris
        const colors = [
            0xFF0000FF, 0xFF7F00FF, 0xFFFF00FF,
            0x00FF00FF, 0x0000FFFF, 0x4B0082FF, 0x9400D3FF
        ];

        const { width, height } = image.bitmap;
        image.scan(0, 0, width, height, function (x, y, idx) {
            const colorIndex = Math.floor((y / height) * colors.length);
            const overlayColor = colors[colorIndex];

            this.bitmap.data[idx + 0] = ((this.bitmap.data[idx + 0] * 0.7) + ((overlayColor >> 24) & 255) * 0.3) | 0;
            this.bitmap.data[idx + 1] = ((this.bitmap.data[idx + 1] * 0.7) + ((overlayColor >> 16) & 255) * 0.3) | 0;
            this.bitmap.data[idx + 2] = ((this.bitmap.data[idx + 2] * 0.7) + ((overlayColor >> 8) & 255) * 0.3) | 0;
        });

        // Convertir a buffer PNG
        const buffer = await image.getBuffer('image/png');

        // Enviar imagen
        await sock.sendMessage(
            message.from,
            { 
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] Al procesar puto:', error);
        await message.reply('❌ Ocurrió un error al obtener o procesar la foto de perfil.');
    }
};

handler.help = ['puto me', 'puto @usuario', 'puto +numero'];
handler.tags = ['diversion'];
handler.command = /^(puto)$/i;

module.exports = handler;
