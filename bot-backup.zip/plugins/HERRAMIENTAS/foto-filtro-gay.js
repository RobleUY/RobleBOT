const axios = require('axios')

const resolveTargetJid = (message, args) => {
    if (message.mentions && message.mentions.length > 0) {
        const mention = message.mentions[0]
        if (mention.includes('@')) return mention
        const digits = mention.replace(/\D/g, '')
        if (digits) return `${digits}@s.whatsapp.net`
    }

    const fullText = (args || []).join(' ').trim()
    if (!fullText) return null

    const lower = fullText.toLowerCase()
    if (lower === 'me' || lower === 'yo' || lower.startsWith('me ') || lower.startsWith('yo ')) {
        return message.sender
    }

    // Extraer todos los dígitos ignorando +, espacios, guiones y paréntesis
    const digits = fullText.replace(/\D/g, '')
    if (digits.length >= 6) {
        return `${digits}@s.whatsapp.net`
    }

    return null
}

const oneShotTimeout = (promise, timeoutMs) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), timeoutMs)
    promise
        .then((value) => { clearTimeout(timer); resolve(value) })
        .catch((err) => { clearTimeout(timer); reject(err) })
})

let handler = async (message, { conn, args }) => {
    // Conexión activa (subbot o principal)
    const activeSock = message._sock || conn || global.conn
    if (!activeSock || !activeSock.user) {
        return message.reply('❌ No hay conexión activa del bot.')
    }

    const targetJid = resolveTargetJid(message, args)
    if (!targetJid) {
        return message.reply('⚠️ Uso:\n• `.puto me`\n• `.puto @usuario`\n• `.puto 59893900470`\n• `.puto +598 9390 0470`')
    }

    const candidateSocks = [
        activeSock,
        ...(Array.isArray(global.subConns) ? global.subConns : [])
    ].filter(s => s && s.user)

    const uniqueSocks = Array.from(new Set(candidateSocks)).slice(0, 4)

    try {
        await message.reply('⏳ Aplicando filtro...')

        let avatarUrl = null

        // 1. Obtener foto de perfil con la conexión activa del mensaje
        try {
            avatarUrl = await oneShotTimeout(activeSock.profilePictureUrl(targetJid, 'image'), 3500)
        } catch (_) {}

        // 2. Si falla, probar en paralelo en hasta 3 subbots conectados
        if (!avatarUrl && uniqueSocks.length > 1) {
            const fallbackSocks = uniqueSocks.filter(s => s !== activeSock).slice(0, 3)
            try {
                avatarUrl = await Promise.any(
                    fallbackSocks.map(s => oneShotTimeout(s.profilePictureUrl(targetJid, 'image'), 3500))
                )
            } catch (_) {}
        }

        // Fallback a imagen por defecto si el usuario no tiene foto de perfil
        if (!avatarUrl) {
            avatarUrl = 'https://i.imgur.com/8Km9tLL.png'
        }

        // Aplicar filtro gay/arcoíris vía APIs de canvas resilientes
        let imageBuffer = null
        const filterApis = [
            `https://some-random-api.com/canvas/overlay/gay?avatar=${encodeURIComponent(avatarUrl)}`,
            `https://api.popcat.xyz/gay?image=${encodeURIComponent(avatarUrl)}`
        ]

        for (const apiUrl of filterApis) {
            try {
                const res = await axios.get(apiUrl, {
                    responseType: 'arraybuffer',
                    timeout: 10000,
                    validateStatus: s => s >= 200 && s < 400
                })
                if (res.data && res.data.length > 100) {
                    imageBuffer = Buffer.from(res.data)
                    break
                }
            } catch (_) {}
        }

        // Si la API falla, intentar con Jimp local si está disponible
        if (!imageBuffer) {
            try {
                const JimpModule = require('jimp')
                const Jimp = JimpModule.Jimp || JimpModule
                const { data } = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 10000 })
                const image = await Jimp.read(Buffer.from(data))

                const colors = [
                    0xFF0000FF, 0xFF7F00FF, 0xFFFF00FF,
                    0x00FF00FF, 0x0000FFFF, 0x4B0082FF, 0x9400D3FF
                ]
                const { width, height } = image.bitmap
                image.scan(0, 0, width, height, function (x, y, idx) {
                    const colorIndex = Math.floor((y / height) * colors.length)
                    const overlayColor = colors[colorIndex]
                    this.bitmap.data[idx + 0] = ((this.bitmap.data[idx + 0] * 0.7) + ((overlayColor >> 24) & 255) * 0.3) | 0
                    this.bitmap.data[idx + 1] = ((this.bitmap.data[idx + 1] * 0.7) + ((overlayColor >> 16) & 255) * 0.3) | 0
                    this.bitmap.data[idx + 2] = ((this.bitmap.data[idx + 2] * 0.7) + ((overlayColor >> 8) & 255) * 0.3) | 0
                })

                imageBuffer = await image.getBuffer('image/png')
            } catch (e) {
                console.error('[FOTO-GAY] Fallo Jimp fallback:', e.message)
            }
        }

        if (!imageBuffer) {
            return message.reply('❌ No se pudo aplicar el filtro a la foto de perfil.')
        }

        await activeSock.sendMessage(message.from, {
            image: imageBuffer,
            caption: '🌈 *Filtro Gay Aplicado*'
        }, { quoted: message._baileyMessage })

    } catch (err) {
        console.error('[FOTO-GAY]', err.message || err)
        await message.reply('❌ Error al procesar la foto con filtro.')
    }
}

handler.help = ['puto me', 'puto @usuario', 'puto 59893900470', 'fotogay', 'filtrogay']
handler.tags = ['diversion', 'herramientas']
handler.command = /^(puto|fotogay|filtrogay|gayfilter|gayfoto)$/i

module.exports = handler
