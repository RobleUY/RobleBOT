/**
 * Comando: .puto @usuario
 * Descripción: Aplica filtro arcoíris (bandera gay) a la foto de perfil mencionada.
 * Compatible con jimp@1.6.0 y @whiskeysockets/baileys.
 */
const { Jimp } = require('jimp');
const axios = require('axios');

let handler = async (message, { conn, args }) => {
    try {
        let targetJid;

        // Verificar si se usó "me" o "yo"
        const firstArg = args[0]?.toLowerCase();
        
        if (firstArg === 'me' || firstArg === 'yo') {
            // Usar el remitente del mensaje
            targetJid = message.sender;
        } else if (message.mentions && message.mentions.length > 0) {
            // Usar el usuario mencionado
            targetJid = message.mentions[0];
        } else {
            return await message.reply('⚠️ Debes mencionar a un usuario o usar:\n• `.puto me`\n• `.puto @usuario`');
        }

        // Obtener URL de avatar
        let avatarUrl;
        try {
            avatarUrl = await conn.profilePictureUrl(targetJid, 'image');
        } catch {
            avatarUrl = 'https://i.imgur.com/8Km9tLL.png'; // Imagen por defecto
        }

        // Descargar imagen como buffer
        const { data } = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
        const image = await Jimp.read(Buffer.from(data));

        // Aplicar filtro arcoíris
        const colors = [
            0xFF0000FF, 0xFF7F00FF, 0xFFFF00FF,
            0x00FF00FF, 0x0000FFFF, 0x4B0082FF, 0x9400D3FF
        ];

        const { width, height } = image.bitmap;
        image.scan(0, 0, width, height, function (x, y, idx) {
            const colorIndex = Math.floor((y / height) * colors.length);
            const overlayColor = colors[colorIndex];

            this.bitmap.data[idx + 0] = ((this.bitmap.data[idx + 0] * 0.7) + ((overlayColor >> 24) & 255) * 0.3) | 0;
            this.bitmap.data[idx + 1] = ((this.bitmap.data[idx + 1] * 0.7) + ((overlayColor >> 16) & 255) * 0.3) | 0;
            this.bitmap.data[idx + 2] = ((this.bitmap.data[idx + 2] * 0.7) + ((overlayColor >> 8) & 255) * 0.3) | 0;
        });

        // Convertir a buffer PNG
        const buffer = await image.getBuffer('image/png');

        // Enviar imagen
        await conn.sendMessage(
            message.from,
            { 
                image: buffer,
                quoted: message
            }
        );

    } catch (error) {
        console.error('[ERROR] Al procesar puto:', error);
        await message.reply('❌ Ocurrió un error al obtener o procesar la foto de perfil.');
    }
};

handler.help = ['puto me', 'puto @usuario'];
handler.tags = ['diversion'];
handler.command = /^(puto)$/i;

module.exports = handler;