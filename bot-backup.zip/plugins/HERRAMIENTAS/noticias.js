const axios = require('axios');
const countries = require('i18n-iso-countries');
countries.registerLocale(require('i18n-iso-countries/langs/es.json'));
countries.registerLocale(require('i18n-iso-countries/langs/en.json'));

// ⚠️ Poné acá tu API key gratuita (te registrás en https://freenewsapi.io/user/register.php)
const NEWS_API_KEY = process.env.FREENEWSAPI_KEY || 'bc7f6b1e974bf827eca8012f13c11ef4c0749f5ee29a66839cc09a47d2e74757';
const NEWS_API_URL = 'https://api.freenewsapi.io/v1/news';

const CANT_NOTICIAS = 8;

// ── Resolver nombre de país (en español o inglés, o código) a ISO alpha-2 ──
function resolverCodigoPais(input) {
    const texto = input.trim();

    // Si ya vino como código de 2 letras (ej: "uy", "ar")
    if (/^[a-zA-Z]{2}$/.test(texto)) {
        const nombre = countries.getName(texto.toUpperCase(), 'es');
        if (nombre) return texto.toUpperCase();
    }

    // Probar por nombre en español
    let code = countries.getAlpha2Code(texto, 'es');
    if (code) return code;

    // Capitalizar primera letra por si el usuario escribió todo en minúscula
    const capitalizado = texto.charAt(0).toUpperCase() + texto.slice(1).toLowerCase();
    code = countries.getAlpha2Code(capitalizado, 'es');
    if (code) return code;

    // Probar por nombre en inglés (por si el usuario lo escribe así)
    code = countries.getAlpha2Code(texto, 'en') || countries.getAlpha2Code(capitalizado, 'en');
    if (code) return code;

    return null;
}

// ── Formatear fecha ─────────────────────────────────────────
function formatearFecha(iso) {
    try {
        return new Date(iso).toLocaleString('es-ES', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    } catch {
        return iso;
    }
}

// ── Consultar la API de noticias ────────────────────────────
async function buscarNoticias(countryCode, language) {
    const params = {
        country: countryCode,
        order_by: 'archive',
        page_size: CANT_NOTICIAS
    };
    if (language) params.language = language;

    const res = await axios.get(NEWS_API_URL, {
        params,
        headers: { 'x-api-key': NEWS_API_KEY },
        timeout: 12000
    });

    return res.data?.data || [];
}

// ── Construir mensaje ───────────────────────────────────────
function construirMensaje(nombrePais, articulos) {
    let msg = `📰 *Últimas noticias de ${nombrePais}*\n\n`;
    articulos.forEach((a, i) => {
        msg += `${i + 1}. *${a.title}*\n`;
        msg += `   🗞️ ${a.publisher || 'Fuente desconocida'} • 🕒 ${formatearFecha(a.published_at)}\n\n`;
    });
    msg += `_Fuente: FreeNewsApi.io_`;
    return msg;
}

// ── Handler ─────────────────────────────────────────────────
let handler = async (message, { text }) => {
    try {
        if (!text || !text.trim()) {
            return await message.reply(
                '📰 *Uso correcto:*\n.noticias <país>\n\nEjemplo: .noticias uruguay\nTambién podés usar el código: .noticias ar'
            );
        }

        const countryCode = resolverCodigoPais(text);
        if (!countryCode) {
            return await message.reply(
                '❌ No reconocí ese país. Probá con el nombre en español (ej: "argentina") o el código ISO (ej: "ar").'
            );
        }

        await message.reply('🔍 Buscando noticias...');

        // Primero intenta con noticias en español, si no hay, trae en cualquier idioma
        let articulos = await buscarNoticias(countryCode, 'es');
        if (!articulos.length) {
            articulos = await buscarNoticias(countryCode, null);
        }

        if (!articulos.length) {
            return await message.reply('❌ No se encontraron noticias recientes para ese país.');
        }

        const nombrePais = countries.getName(countryCode, 'es') || text.trim();
        await message.reply(construirMensaje(nombrePais, articulos));

    } catch (error) {
        console.error('[noticias] Error:', error.response?.data || error.message);
        if (error.response?.status === 401 || error.response?.status === 403) {
            await message.reply('❌ Error de autenticación con la API de noticias. Revisá tu API key.');
        } else {
            await message.reply('❌ No se pudo obtener las noticias. Intentá de nuevo más tarde.');
        }
    }
};

handler.help = ['noticias <país>', 'news <país>'];
handler.tags = ['herramientas', 'info'];
handler.command = /^(noticias|news)$/i;

module.exports = handler;