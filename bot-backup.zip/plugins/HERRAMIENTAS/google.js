const axios = require('axios');

const COMANDO_ACTIVADO = true;

async function searchGoogle(query) {
    try {
        console.log('[GOOGLE] Buscando:', query);
        const endpoint = `https://www.sankavollerei.com/search/google?apikey=planaai&q=${encodeURIComponent(query)}`;
        const res = await axios.get(endpoint, { timeout: 30000 });

        if (!res.data?.status || !res.data?.result || res.data.result.length === 0) {
            throw new Error('No se encontraron resultados');
        }

        console.log('[GOOGLE] Resultados encontrados:', res.data.result.length);
        return res.data.result;
    } catch (e) {
        console.error('[GOOGLE] Error en búsqueda:', e.message);
        throw new Error('Error al buscar en Google');
    }
}

function cleanText(text) {
    if (!text) return '';
    
    return text
        .replace(/â€™/g, "'")
        .replace(/â€"/g, "-")
        .replace(/â€"/g, "—")
        .replace(/â€¦/g, "...")
        .replace(/ã³/g, "ó")
        .replace(/ã¡/g, "á")
        .replace(/ã©/g, "é")
        .replace(/ã­/g, "í")
        .replace(/ãº/g, "ú")
        .replace(/ã±/g, "ñ")
        .replace(/ã"/g, "Ó")
        .replace(/ã/g, "Á")
        .replace(/ã‰/g, "É")
        .replace(/ã/g, "Í")
        .replace(/ãš/g, "Ú")
        .replace(/ã'/g, "Ñ")
        .replace(/Â/g, "")
        .replace(/Ã/g, "")
        .trim();
}

function formatResults(results, maxResults = 10) {
    let message = '🔍 *RESULTADOS DE BÚSQUEDA*\n\n';
    
    const limitedResults = results.slice(0, maxResults);
    
    limitedResults.forEach((result, index) => {
        const title = cleanText(result.title);
        const url = result.url;
        const description = cleanText(result.description);
        
        message += `*${index + 1}. ${title}*\n`;
        message += `🔗 ${url}\n`;
        
        if (description) {
            let desc = description;
            if (desc.length > 150) {
                desc = desc.substring(0, 150) + '...';
            }
            message += `📄 ${desc}\n`;
        }
        
        message += '\n';
    });
    
    if (results.length > maxResults) {
        message += `_Mostrando ${maxResults} de ${results.length} resultados_\n`;
    }
    
    message += '\n💡 _Haz clic en los enlaces para ver más información_';
    
    return message;
}

let handler = async (message, { text, conn, usedPrefix, command }) => {
    if (!COMANDO_ACTIVADO) {
        return await message.reply(
            '⚠️ *COMANDO TEMPORALMENTE DESHABILITADO*\n\n' +
            '_Este comando está en mantenimiento y volverá pronto._\n\n' +
            '💡 _Disculpa las molestias_'
        );
    }

    if (!text) {
        return await message.reply(
            `❌ Por favor escribe algo para buscar.\n\n` +
            `*Ejemplo:*\n` +
            `• ${usedPrefix + command} cómo hacer pan casero\n` +
            `• ${usedPrefix + command} noticias Uruguay\n` +
            `• ${usedPrefix + command} mejores películas 2024`
        );
    }

    try {
        await message.reply('🔍 Buscando...');

        const results = await searchGoogle(text);
        const formattedMessage = formatResults(results, 10);
        
        await conn.sendMessage(message.from, {
            text: formattedMessage,
            linkPreview: false
        }, { quoted: message._baileyMessage });

        console.log('[GOOGLE] Resultados enviados correctamente');

    } catch (e) {
        console.error('[GOOGLE] Error general:', e?.message || e);
        await message.reply(
            `❌ Ocurrió un error al buscar.\n\n` +
            `💡 *Sugerencias:*\n` +
            `• Verifica tu búsqueda\n` +
            `• Intenta con otros términos\n` +
            `• Espera unos minutos y vuelve a intentar\n\n` +
            `_Error: ${e.message}_`
        );
    }
};

handler.help = ['google <búsqueda>', 'googlesearch <búsqueda>'];
handler.tags = ['busqueda', 'internet', 'herramientas'];
handler.command = /^(google|googlesearch|buscar|search)$/i;

module.exports = handler;