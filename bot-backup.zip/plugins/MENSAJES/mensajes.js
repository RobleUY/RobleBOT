const fs = require('fs')
const path = require('path')

const CHAT_USUARIOS_DIR = path.join(__dirname, '../../data/CHATS-USUARIOS')

function cleanNum(str) {
    return str.split('@')[0].split(':')[0].replace(/\D/g, '')
}

function contarMensajes(numero, groupId) {
    const file = groupId
        ? path.join(CHAT_USUARIOS_DIR, groupId, `${numero}.txt`)
        : path.join(CHAT_USUARIOS_DIR, `${numero}.txt`)
    if (!fs.existsSync(file)) return null

    const contenido = fs.readFileSync(file, 'utf-8').trim()
    if (!contenido) return 0

    return contenido.split('\n').filter(Boolean).length
}

function parseActivity(val) {
    if (!val) return { count: 0 }
    if (typeof val === 'object') return { count: val.count || 0 }
    return { count: 1 }
}

function getPosicion(groupId, targetNum, conn) {
    try {
        const groupActivity = global.db?.data?.groupActivity?.[groupId] || {}

        // Construir ranking con todos los que tienen al menos 1 mensaje
        const lista = []
        for (const [num, val] of Object.entries(groupActivity)) {
            if (num === '__total') continue
            const { count } = parseActivity(val)
            if (count < 1) continue
            lista.push({ number: num, count })
        }

        lista.sort((a, b) => b.count - a.count)

        const idx = lista.findIndex(u => u.number === targetNum)
        return idx >= 0 ? { pos: idx + 1, total: lista.length } : null
    } catch {
        return null
    }
}

let handler = async (message, { args, conn }) => {
    try {
        if (!message.isGroup)
            return message.reply('❌ Este comando solo puede usarse en grupos.')

        const groupId = message.from
        const mentioned = message.mentions?.[0]

        let targetJid, targetNumero, esPropioUsuario

        if (mentioned) {
            targetJid = mentioned
            targetNumero = cleanNum(mentioned)
            esPropioUsuario = false
        } else {
            targetJid = message.sender
            targetNumero = cleanNum(message.sender)
            esPropioUsuario = true
        }

        const total = contarMensajes(targetNumero, groupId)

        if (total === null || total === 0) {
            const msg = esPropioUsuario
                ? '❌ No tengo mensajes tuyos registrados en este grupo.'
                : `❌ No tengo mensajes registrados de @${targetNumero} en este grupo.`
            return message.reply(msg, { mentions: esPropioUsuario ? [] : [targetJid] })
        }

        const ranking = getPosicion(groupId, targetNumero, conn)
        const posTexto = ranking
            ? `🏆 Posición en top: *#${ranking.pos}* de ${ranking.total}`
            : `🏆 Posición en top: *no disponible*`

        const header = esPropioUsuario
            ? `📊 *Tus mensajes en este grupo*`
            : `📊 *Mensajes de @${targetNumero} en este grupo*`

        const texto = `${header}\n${'─'.repeat(28)}\n💬 Total: *${total.toLocaleString()} mensajes*\n${posTexto}`

        return message.reply(texto, { mentions: esPropioUsuario ? [] : [targetJid] })

    } catch (err) {
        console.error('[MENSAJES ERROR]', err?.message || err)
        return message.reply('❌ Error al obtener los mensajes.')
    }
}

handler.help = ['mensajes', 'mensajes @usuario']
handler.tags = ['mensajes']
handler.command = /^mensajes$/i
handler.group = true

module.exports = handler
