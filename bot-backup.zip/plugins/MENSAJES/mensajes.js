const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'mensajes.json');
const MAX_CHARS = 200;

function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[SMS] Error cargando mensajes.json:', e.message);
    }
    return {};
}

function saveData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[SMS] Error guardando mensajes.json:', e.message);
    }
}

function findNumberByApodo(apodo) {
    if (!global.db?.data?.users) return null;
    const target = apodo.trim().toLowerCase();
    for (const [num, userData] of Object.entries(global.db.data.users)) {
        const userApodo = (userData.apodo || '').trim().toLowerCase();
        if (userApodo === target) return num;
    }
    return null;
}

let handler = async (message, { text, args }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo identificar al remitente.');

        const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');
        const senderUser = global.db.getUser(senderNum);
        const senderApodo = (senderUser?.apodo || '').trim() || senderNum;

        const data = loadData();

        // ── Sin argumentos: mostrar bandeja ──────────────────────────────────
        if (!text || !text.trim()) {
            const inbox = data[senderNum] || [];
            if (inbox.length === 0) {
                return await message.reply('📭 No tienes mensajes en tu bandeja.');
            }

            let lista = `📬 *Tu bandeja de mensajes* (${inbox.length})\n\n`;
            inbox.forEach((msg, i) => {
                const fecha = new Date(msg.timestamp).toLocaleString('es-ES', {
                    day: '2-digit', month: '2-digit', year: '2-digit',
                    hour: '2-digit', minute: '2-digit'
                });
                lista += `*[${i + 1}]* 👤 *${msg.fromApodo}*\n📅 ${fecha}\n💬 ${msg.text}\n\n`;
            });

            lista += `_Usa *.sms borrar* para limpiar tu bandeja._`;
            return await message.reply(lista.trim());
        }

        const firstArg = args[0]?.toLowerCase();

        // ── .sms borrar ───────────────────────────────────────────────────────
        if (firstArg === 'borrar' || firstArg === 'clean' || firstArg === 'limpiar') {
            const count = (data[senderNum] || []).length;
            if (count === 0) return await message.reply('📭 Tu bandeja ya está vacía.');
            data[senderNum] = [];
            saveData(data);
            return await message.reply(`🗑️ Se borraron *${count}* mensaje(s) de tu bandeja.`);
        }

        // ── .sms <apodo> <mensaje> ────────────────────────────────────────────
        const targetApodo = args[0];
        const msgText = args.slice(1).join(' ');

        if (!targetApodo || !msgText) {
            return await message.reply(
                '📨 *Comandos de SMS*\n\n' +
                '• *.sms <apodo> <mensaje>* — Enviar mensaje\n' +
                '• *.sms* — Ver tu bandeja\n' +
                '• *.sms borrar* — Limpiar tu bandeja\n\n' +
                `📌 Máximo *${MAX_CHARS}* caracteres por mensaje.`
            );
        }

        if (msgText.length > MAX_CHARS) {
            return await message.reply(
                `❌ El mensaje es demasiado largo.\n` +
                `📏 Tu mensaje: *${msgText.length}* caracteres\n` +
                `✂️ Debes borrar: *${msgText.length - MAX_CHARS}* caracteres\n` +
                `📌 Máximo permitido: *${MAX_CHARS}* caracteres`
            );
        }

        const targetNum = findNumberByApodo(targetApodo);
        if (!targetNum) {
            return await message.reply(`❌ No se encontró ningún usuario con el apodo *${targetApodo}*.`);
        }

        if (targetNum === senderNum) {
            return await message.reply('❌ No puedes enviarte mensajes a ti mismo.');
        }

        if (!data[targetNum]) data[targetNum] = [];
        data[targetNum].push({
            from: senderNum,
            fromApodo: senderApodo,
            text: msgText,
            timestamp: Date.now()
        });
        saveData(data);

        return await message.reply(`✅ Mensaje enviado a *${targetApodo}* de parte de *${senderApodo}*.`);

    } catch (error) {
        console.error('[SMS] Error:', error.message);
        return await message.reply('❌ Ocurrió un error al procesar el comando.');
    }
};

handler.help = ['sms <apodo> <mensaje>', 'sms', 'sms borrar'];
handler.tags = ['mensajes'];
handler.command = /^(sms|mensaje|mensajes)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;
