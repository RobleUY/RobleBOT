// _status.js

let handler = async (message) => {
    try {
        const now = Date.now();
        // Latencia basada en la diferencia del timestamp del mensaje original vs tiempo actual de procesamiento
        const msgTimestamp = (message.messageTimestamp || 0) * 1000;
        const ping = (msgTimestamp > 0 && now >= msgTimestamp) ? (now - msgTimestamp) : 15;

        // Uptime
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);
        const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Mensaje final
        const statusText =
            `*━━━━━━━━━━━━━*\n` +
            `*〔 📊 ESTADO DEL BOT 📊 〕*\n` +
            `*━━━━━━━━━━━━━*\n\n` +
            `*⚡ Latencia (Ping):* ${ping} ms\n` +
            `*⏳ Bot activo hace:* ${uptimeFormatted}\n` +
            `*━━━━━━━━━━━━━*`;

        return await message.reply(statusText);

    } catch (err) {
        console.error(err);
        return await message.reply('❌ Error al obtener estado del bot.');
    }
};

handler.help = ['status', 'estado', 'ping'];
handler.tags = ['info'];
handler.command = /^(status|estado|ping)$/i;

module.exports = handler;
