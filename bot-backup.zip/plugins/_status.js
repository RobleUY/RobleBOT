// _status.js

let handler = async (message) => {
    try {
        // Medición de latencia directa
        const now = Date.now();
        const msgTs = message.timestamp ? (message.timestamp > 1e11 ? message.timestamp : message.timestamp * 1000) : now;
        const ping = Math.max(1, now - msgTs);

        // Uptime
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);
        const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Mensaje final
        const statusText =
            `*━━━━━━━━━━━━━*\n` +
            `*〔 📊 ESTADO DEL BOT 📊 〕*\n` +
            `*━━━━━━━━━━━━━*\n\n` +
            `*⚡ Latencia (Ping):* ${ping} ms\n` +
            `*⏳ Bot activo hace:* ${uptimeFormatted}\n` +
            `*━━━━━━━━━━━━━*`;

        return await message.reply(statusText);

    } catch (err) {
        console.error(err);
        return await message.reply('❌ Error al obtener estado del bot.');
    }
};

handler.help = ['status', 'estado', 'ping'];
handler.tags = ['info'];
handler.command = /^(status|estado|ping)$/i;

module.exports = handler;
