let handler = async (message) => {
    try {
        // Mensaje inicial
        const start = Date.now();

        const sentMessage = await message.reply('⏳ Analizando el estado del bot...');

        // Medimos cuánto tardó el bot en enviar el mensaje
        const ping = Date.now() - start;

        // Uptime
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);

        const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Analisis del estado
        let estado;
        let analisis;

        if (ping < 100) {
            estado = '🟢 Excelente';
            analisis = 'El bot esta respondiendo muy rapido. No se detecta latencia importante.';
        } else if (ping < 300) {
            estado = '🟢 Bueno';
            analisis = 'El bot funciona correctamente y mantiene una respuesta bastante rapida.';
        } else if (ping < 800) {
            estado = '🟡 Regular';
            analisis = 'El bot esta funcionando, aunque se aprecia cierta demora en la respuesta.';
        } else if (ping < 1500) {
            estado = '🟠 Lento';
            analisis = 'El bot presenta una demora considerable. Puede existir carga o problemas de conexion.';
        } else {
            estado = '🔴 Muy lento';
            analisis = 'El bot esta respondiendo con mucha demora. Se recomienda revisar el servidor o la conexion.';
        }

        const statusText =
            `📊 *Estado del Bot*\n\n` +
            `⚡ *Ping:* ${ping} ms\n` +
            `⏳ *Uptime:* ${uptimeFormatted}\n` +
            `📡 *Estado:* ${estado}\n\n` +
            `🔎 *Analisis:*\n${analisis}`;

        // Intentar editar el mensaje anterior
        if (sentMessage?.key) {
            try {
                await message.client.sendMessage(
                    message.key.remoteJid,
                    {
                        text: statusText,
                        edit: sentMessage.key
                    }
                );
            } catch {
                // Si el sistema no permite editar, manda el resultado
                await message.reply(statusText);
            }
        } else {
            await message.reply(statusText);
        }

    } catch (err) {
        console.error(err);
        return await message.reply('❌ Error al obtener el estado del bot.');
    }
};

handler.help = ['status', 'estado', 'ping'];
handler.tags = ['info'];
handler.command = /^(status|estado|ping)$/i;

module.exports = handler;