// _status.js

let handler = async (message) => {
    try {
        // Medición de “ping” aproximado
        const start = Date.now();

        // Ejecutamos reply temporalmente para medir tiempo de ejecución
        await message.reply('⏳ Calculando ping...');

        const ping = Date.now() - start;

        // Uptime
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);
        const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Información de recompensas automáticas
        let rewardInfo = '';
        if (global.autoRewardSystem) {
            const stats = global.autoRewardSystem.getStats();
            const nextRewardMs = stats.nextRewardIn;
            const nextRewardSeconds = Math.floor(nextRewardMs / 1000);
            
            rewardInfo = 
                `\n*💰 Recompensas Automáticas:*\n` +
                `   • Entregadas: ${stats.rewardsGiven}\n` +
                `   • Próxima en: ${nextRewardSeconds}s\n` +
                `   • Monto: ${stats.rewardAmount.toLocaleString()} monedas/min`;
        }

        // Mensaje final
        const statusText =
            `*━━━━━━━━━━━━━*\n` +
            `*〔 📊 ESTADO DEL BOT 📊 〕*\n` +
            `*━━━━━━━━━━━━━*\n\n` +
            `*⚡ Latencia (Ping):* ${ping} ms\n` +
            `*⏳ Tiempo de Actividad (Uptime):* ${uptimeFormatted}${rewardInfo}\n` +
            `*━━━━━━━━━━━━━*`;

        return await message.reply(statusText);

    } catch (err) {
        console.error(err);
        return await message.reply('❌ Error al obtener estado del bot.');
    }
};

handler.help = ['status', 'estado', 'ping'];
handler.tags = ['info'];
handler.command = /^(status|estado|ping)$/i;

module.exports = handler;
