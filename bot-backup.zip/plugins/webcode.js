// Plugin: .webcode
// Usado para iniciar sesión en la web de RobleBOT

let handler = async (message) => {
    try {
        const text = message.text || '';
        const args = text.trim().split(/\s+/).slice(1);
        const code = args[0];

        if (!code) {
            return await message.reply('❌ Debes proporcionar un código. Ejemplo: *.webcode 1234*');
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid || message?.from;
        if (!senderJid) return await message.reply('❌ No se pudo obtener tu número');
        const number = senderJid.split('@')[0];

        // Obtener el apodo del usuario de la base de datos
        const userData = global.db?.data?.users?.[number];
        const apodo = userData?.apodo;

        if (!apodo) {
            return await message.reply('❌ No tienes un apodo registrado. Usa el comando correspondiente para registrarte antes de usar la web.');
        }

        // Llamar a la API local (subbotServer) para verificar el código
        const response = await fetch(`http://127.0.0.1:25196/webauth/verify`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ apodo: apodo, code: code })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            await message.reply(`✅ *¡Sesión iniciada con éxito!*\n\nTu apodo *${apodo}* ha sido verificado. Ya puedes ver tu dashboard en la web.`);
        } else {
            const errorMsg = result.error || 'Código inválido o expirado.';
            await message.reply(`❌ *Error al iniciar sesión:*\n${errorMsg}\n\nAsegúrate de haber generado el código en la web con tu apodo exacto.`);
        }

    } catch (e) {
        console.error('[webcode] Error:', e);
        return await message.reply('❌ Ocurrió un error al verificar el código. Intenta nuevamente más tarde.');
    }
};

handler.help = ['webcode <code>'];
handler.tags = ['herramientas'];
handler.command = /^(webcode)$/i;

module.exports = handler;
