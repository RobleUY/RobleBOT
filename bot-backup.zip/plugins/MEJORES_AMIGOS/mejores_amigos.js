const fs = require('fs');
const path = require('path');

// Ruta del archivo para almacenar los datos de las amistades
const AMIGOS_FILE = path.join(__dirname, 'amigos.json');

// Cargar datos existentes o inicializar estructura
let amigos = {};
try {
    // Si el archivo existe, cargamos los datos. Si no existe, se inicializa como objeto vacío
    amigos = JSON.parse(fs.readFileSync(AMIGOS_FILE, 'utf8'));
} catch (error) {
    // Manejar error si el archivo no existe o está mal formado
    amigos = {};
}

// Función para guardar los datos
function guardarAmigos() {
    fs.writeFileSync(AMIGOS_FILE, JSON.stringify(amigos, null, 2));
}

/**
 * Función para calcular el tiempo transcurrido
 * @param {string} fecha - Fecha de inicio de la amistad (ISO String)
 * @returns {{dias: number, horas: number, minutos: number}} Tiempo transcurrido
 */
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const inicio = new Date(fecha);
    const diferencia = ahora - inicio;

    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));

    return { dias, horas, minutos };
}

/**
 * Función para formatear la fecha
 * @param {string} fecha - Fecha ISO
 * @returns {string} Fecha formateada
 */
function formatearFecha(fecha) {
    const d = new Date(fecha);
    return d.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric'
    });
}

/**
 * Función para obtener los datos de un usuario, inicializándolos si no existen.
 * @param {string} senderNumber - Número de teléfono del usuario
 * @returns {{amigos: Array, peticion_enviada: object | null, peticion_recibida: object | null}} Datos del usuario
 */
function obtenerDatosUsuario(senderNumber) {
    if (!amigos[senderNumber]) {
        amigos[senderNumber] = {
            amigos: [],
            peticion_enviada: null,
            peticion_recibida: null
        };
    }
    return amigos[senderNumber];
}

/**
 * Revisa si un número ya es amigo de otro.
 * @param {string} userA - Número del usuario A
 * @param {string} userB - Número del usuario B
 * @returns {boolean}
 */
function esAmigo(userA, userB) {
    const datosA = obtenerDatosUsuario(userA);
    return datosA.amigos.some(amigo => amigo.numero === userB);
}

let handler = async (message, { text, command }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        const senderDatos = obtenerDatosUsuario(senderNumber);
        
        // El comando usado será /bf o /mja, usamos 'bf' para simplificar los ejemplos en el código.
        const cmd = command.toLowerCase();

        // LÓGICA PRINCIPAL (MOSTRAR ESTADO)
        if (!text) {
            let mensaje = '👥 *ESTADO DE MEJORES AMIGOS* 👥\n' +
                          '━━━━━━━━━━━━━━━\n\n';

            // 1. Mostrar amigos aceptados
            if (senderDatos.amigos.length > 0) {
                const count = senderDatos.amigos.length;
                const label = count === 1 ? 'Mejor Amigo(a)' : 'Mejores Amigos(as)';
                // Se reemplaza [Image of Corazón] por el emoji ❤️
                mensaje += `✅ *Tienes ${count} ${label}* ❤️:\n`;
                
                let mentions = [];
                senderDatos.amigos.forEach((amigo, index) => {
                    const tiempo = tiempoTranscurrido(amigo.fecha);
                    mensaje += `\n*${index + 1}. Amigo:* @${amigo.numero}\n`;
                    mensaje += `   *Desde:* ${formatearFecha(amigo.fecha)}\n`;
                    mensaje += `   *Tiempo:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n`;
                    mentions.push(amigo.jid);
                });
                
                mensaje += '\n_La amistad es un tesoro_ 💎';
                return await message.reply(mensaje, { mentions });
            } else {
                mensaje += '❌ *Aún no tienes Mejores Amigos* 😔\n'; 
            }
            
            // 2. Mostrar petición pendiente enviada
            if (senderDatos.peticion_enviada) {
                const amigo = senderDatos.peticion_enviada;
                mensaje += `\n💌 *PETICIÓN ENVIADA PENDIENTE* 💌\n` +
                           `*A:* @${amigo.numero}\n` +
                           `*Enviada el:* ${formatearFecha(amigo.fecha)}\n` +
                           `_Esperando respuesta..._ ⏳\n` +
                           `_Puedes cancelar con:_ *!${cmd} cancelar*\n`; // Se ajusta el comando a !cmd
                return await message.reply(mensaje, { mentions: [amigo.jid] });
            }

            // 3. Mostrar petición pendiente recibida
            if (senderDatos.peticion_recibida) {
                const amigo = senderDatos.peticion_recibida;
                mensaje += `\n📬 *PETICIÓN RECIBIDA PENDIENTE* 📬\n` +
                           `*De:* @${amigo.numero}\n` +
                           `*Recibida el:* ${formatearFecha(amigo.fecha)}\n` +
                           `_Usa:_\n` +
                           `*!${cmd} aceptar @${amigo.numero}* - _Para aceptar_\n` +
                           `*!${cmd} rechazar @${amigo.numero}* - _Para rechazar_\n`; // Se ajusta el comando a !cmd
                return await message.reply(mensaje, { mentions: [amigo.jid] });
            }

            if (senderDatos.amigos.length === 0 && !senderDatos.peticion_enviada && !senderDatos.peticion_recibida) {
                // Mensaje si no hay amigos ni peticiones
                return await message.reply(`💔 *Aún no tienes Mejores Amigos* 💔\n\n_Usa !${cmd} pedir @usuario para proponer amistad_`);
            }
        }

        // Obtener menciones del objeto message
        const mentionedJids = message?.mentions;

        // --- PROCESAR COMANDOS ---

        // Comando para pedir amistad
        if (text.startsWith('pedir')) {
            // Verificar si ya tiene una petición de amistad enviada pendiente
            if (senderDatos.peticion_enviada) {
                return await message.reply(`❌ *Ya tienes una petición de amistad enviada pendiente* \n\n_Debes esperar una respuesta o cancelar tu petición actual con: *!${cmd} cancelar*_`);
            }

            // Verificar si hay menciones
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Debes mencionar a un usuario. Ejemplo: *!${cmd} pedir @usuario*_`);
            }

            const amigoPropuestoJid = mentionedJids[0];
            const amigoPropuesto = amigoPropuestoJid.split('@')[0];
            const amigoPropuestoDatos = obtenerDatosUsuario(amigoPropuesto);

            // Verificar que no se pida a sí mismo
            if (amigoPropuesto === senderNumber) {
                return await message.reply('❌ *No puedes pedir amistad a ti mismo* 🚫\n\n_Ya eres tu mejor amigo(a) interior_ 🧘');
            }

            // Verificar si ya son amigos
            if (esAmigo(senderNumber, amigoPropuesto)) {
                return await message.reply(`❌ *Ya eres Mejor Amigo(a) de @${amigoPropuesto}* 🫂\n\n_La amistad ya ha florecido_ 🌻`, { mentions: [amigoPropuestoJid] });
            }

            // Verificar si el propuesto ya tiene una petición recibida pendiente
            if (amigoPropuestoDatos.peticion_recibida) {
                return await message.reply('❌ *Esa persona tiene una petición de amistad recibida pendiente* 💭\n\n_Espera a que resuelva su situación actual._');
            }
            
            // Verificar si el propuesto ya tiene una petición enviada pendiente (para evitar bucles raros)
            if (amigoPropuestoDatos.peticion_enviada && amigoPropuestoDatos.peticion_enviada.numero === senderNumber) {
                return await message.reply(`❌ *Ya te enviaron una petición, usa !${cmd} aceptar o !${cmd} rechazar*`);
            }

            // Guardar la propuesta pendiente en ambos usuarios
            const fechaPeticion = new Date().toISOString();
            
            senderDatos.peticion_enviada = {
                numero: amigoPropuesto,
                jid: amigoPropuestoJid,
                fecha: fechaPeticion
            };
            amigoPropuestoDatos.peticion_recibida = {
                numero: senderNumber,
                jid: senderJid,
                fecha: fechaPeticion
            };
            guardarAmigos();

            let mentions = [amigoPropuestoJid, senderJid];
            return await message.reply(
                '🤝 *PETICIÓN DE AMISTAD ENVIADA* 🤝\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `🥳 *¡@${senderNumber}* _te está pidiendo ser tu Mejor Amigo(a)_ *@${amigoPropuesto}!* 🎉\n\n` +
                '_Para responder, la persona debe usar:_\n' +
                `*!${cmd} aceptar @${senderNumber}* - _Para aceptar_\n` +
                `*!${cmd} rechazar @${senderNumber}* - _Para rechazar_\n`,
                { mentions }
            );
        }

        // Procesar aceptación de amistad
        if (text.startsWith('aceptar')) {
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Debes mencionar al usuario que te envió la petición. Ejemplo: *!${cmd} aceptar @usuario*_`);
            }

            const proponenteJid = mentionedJids[0];
            const proponente = proponenteJid.split('@')[0];
            const proponenteDatos = obtenerDatosUsuario(proponente);

            // Verificar si existe la propuesta que me hicieron
            if (!senderDatos.peticion_recibida || senderDatos.peticion_recibida.numero !== proponente) {
                return await message.reply('❌ *No tienes ninguna petición de amistad pendiente de esa persona*');
            }
            
            // Verificar si el proponente realmente envió la petición a este usuario
            if (!proponenteDatos.peticion_enviada || proponenteDatos.peticion_enviada.numero !== senderNumber) {
                // Esto debería ser raro, pero es una buena verificación de seguridad
                return await message.reply('❌ *Algo salió mal en el registro. Esa persona no te ha enviado una petición válida.*');
            }

            const fechaInicio = new Date().toISOString();

            // 1. Agregar a la lista de amigos del proponente
            proponenteDatos.amigos.push({
                numero: senderNumber,
                jid: senderJid,
                fecha: fechaInicio
            });
            // 2. Agregar a la lista de amigos del aceptante
            senderDatos.amigos.push({
                numero: proponente,
                jid: proponenteJid,
                fecha: fechaInicio
            });
            
            // 3. Limpiar las peticiones pendientes de ambos
            proponenteDatos.peticion_enviada = null;
            senderDatos.peticion_recibida = null;
            
            guardarAmigos();

            let mentions = [senderJid, proponenteJid];
            return await message.reply(
                '🥳 *¡OFICIALMENTE MEJORES AMIGOS!* 🥳\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*¡@${senderNumber} y @${proponente} ahora son Mejores Amigos!* ❤️\n\n` +
                '_¡Que viva la amistad!_ 🤝\n' +
                `_Usen !${cmd} para ver su lista de amistades_`,
                { mentions }
            );
        }

        // Procesar rechazo de amistad
        if (text.startsWith('rechazar')) {
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Debes mencionar al usuario que te envió la petición. Ejemplo: *!${cmd} rechazar @usuario*_`);
            }

            const proponenteJid = mentionedJids[0];
            const proponente = proponenteJid.split('@')[0];
            const proponenteDatos = obtenerDatosUsuario(proponente);

            // Verificar si existe la propuesta
            if (!senderDatos.peticion_recibida || senderDatos.peticion_recibida.numero !== proponente) {
                return await message.reply('❌ *No hay ninguna petición de amistad pendiente de esa persona*');
            }
            
            // Limpiar las peticiones pendientes de ambos
            proponenteDatos.peticion_enviada = null;
            senderDatos.peticion_recibida = null;

            guardarAmigos();

            let mentions = [senderJid, proponenteJid];
            return await message.reply(
                '🙁 *PETICIÓN RECHAZADA* 🙁\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha rechazado la petición de amistad de_ *@${proponente}* 💔\n\n` +
                '_Siempre hay más peces en el mar de la amistad_ 🐠',
                { mentions }
            );
        }

        // Procesar cancelación de petición enviada
        if (text.startsWith('cancelar')) {
            // Verificar si tienes una petición pendiente enviada
            if (!senderDatos.peticion_enviada) {
                return await message.reply('❌ *No tienes ninguna petición enviada pendiente* \n\n_No hay nada que cancelar_');
            }

            const amigoCancelado = senderDatos.peticion_enviada.numero;
            const amigoCancelJid = senderDatos.peticion_enviada.jid;
            const amigoCancelDatos = obtenerDatosUsuario(amigoCancelado);

            // Limpiar la petición del remitente
            senderDatos.peticion_enviada = null;
            
            // Limpiar la petición recibida del otro usuario
            amigoCancelDatos.peticion_recibida = null;
            
            guardarAmigos();

            let mentions = [senderJid, amigoCancelJid];
            return await message.reply(
                '👋 *PETICIÓN CANCELADA* 👋\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha cancelado su petición de amistad hacia_ *@${amigoCancelado}* 😌\n\n` +
                '_A veces es mejor esperar el momento perfecto_',
                { mentions }
            );
        }

        // Procesar terminación de amistad
        if (text.startsWith('terminar')) {
             if (!mentionedJids || mentionedJids.length === 0) {
                 return await message.reply(`❌ *Formato inválido*\n\n_Debes mencionar al amigo con el que quieres terminar la amistad. Ejemplo: *!${cmd} terminar @usuario*_`);
             }
            
            const amigoRomperJid = mentionedJids[0];
            const amigoRomper = amigoRomperJid.split('@')[0];
            const amigoRomperDatos = obtenerDatosUsuario(amigoRomper);

            // Verificar si tienes amistad con esa persona
            const indexSender = senderDatos.amigos.findIndex(amigo => amigo.numero === amigoRomper);
            if (indexSender === -1) {
                return await message.reply(`❌ *@${amigoRomper} no es tu Mejor Amigo(a) actualmente.*`, { mentions: [amigoRomperJid] });
            }

            const fechaInicio = senderDatos.amigos[indexSender].fecha;
            const tiempo = tiempoTranscurrido(fechaInicio);

            // 1. Eliminar la amistad del remitente
            senderDatos.amigos.splice(indexSender, 1);
            
            // 2. Eliminar la amistad del amigo
            const indexAmigo = amigoRomperDatos.amigos.findIndex(amigo => amigo.numero === senderNumber);
            if (indexAmigo !== -1) {
                amigoRomperDatos.amigos.splice(indexAmigo, 1);
            }
            
            // Si el amigo ya no tiene más amistades ni peticiones, se puede eliminar su registro para ahorrar espacio
            if (amigoRomperDatos.amigos.length === 0 && !amigoRomperDatos.peticion_enviada && !amigoRomperDatos.peticion_recibida) {
                delete amigos[amigoRomper];
            }
            
            // Si el remitente ya no tiene más amistades ni peticiones, también se elimina su registro
            if (senderDatos.amigos.length === 0 && !senderDatos.peticion_enviada && !senderDatos.peticion_recibida) {
                delete amigos[senderNumber];
            }

            guardarAmigos();

            let mentions = [senderJid, amigoRomperJid];
            return await message.reply(
                '💔 *AMISTAD TERMINADA* 💔\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha terminado su amistad con_ *@${amigoRomper}*\n\n` +
                `*La amistad duró:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n\n` +
                '_Los caminos se separan, pero los recuerdos quedan_ 🫂',
                { mentions }
            );
        }

        // Si el comando no coincide con ninguno de los anteriores
        return await message.reply(
            '🫂 *COMANDOS DE MEJORES AMIGOS* 🫂\n' +
            '━━━━━━━━━━━━━━━\n\n' +
            `*Comandos disponibles:* !bf o !mja\n\n` +
            `*!${cmd}* - _Ver tu estado de amistades (lista y peticiones)_\n` +
            `*!${cmd} pedir @usuario* - _Pedir ser Mejor Amigo(a)_\n` +
            `*!${cmd} aceptar @usuario* - _Aceptar una petición de amistad_\n` +
            `*!${cmd} rechazar @usuario* - _Rechazar una petición de amistad_\n` +
            `*!${cmd} cancelar* - _Cancelar tu petición enviada pendiente_\n` +
            `*!${cmd} terminar @usuario* - _Terminar una amistad existente_`
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de amistades:', error, '\x1b[0m');
        // Asegurarse de que el objeto 'amigos' se guarde incluso en caso de error, si fue modificado
        guardarAmigos();
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud. Revisa la consola._');
    }
};

handler.help = ['bf', 'mja', 'bf pedir @usuario', 'bf aceptar @usuario', 'bf rechazar @usuario', 'bf cancelar', 'bf terminar @usuario'];
handler.tags = ['bestfriends'];
handler.command = /^(bf|mja)$/i;

module.exports = handler;