const sharp = require('sharp');

// ── FUNCIONES AUXILIARES ──
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ── GENERACIÓN DE DATOS FAKE ──
function generateCardData(type) {
    let number, name, expiry, cvv, background, logoSvg, cardType;
    name = "JOHN DOE"; // Nombre genérico
    expiry = `${String(getRandomInt(1, 12)).padStart(2, '0')}/${getRandomInt(26, 33)}`;
    
    const t = (type || '').toLowerCase();
    
    if (t.includes('master')) {
        cardType = 'MasterCard';
        number = `5412 ${getRandomInt(1000,9999)} ${getRandomInt(1000,9999)} ${getRandomInt(1000,9999)}`;
        cvv = String(getRandomInt(100, 999));
        // Tema elegante oscuro
        background = ['#141414', '#323232'];
        logoSvg = `
            <circle cx="350" cy="50" r="22" fill="#EB001B" opacity="0.9"/>
            <circle cx="375" cy="50" r="22" fill="#F79E1B" opacity="0.9"/>
            <text x="362.5" y="85" fill="#fff" font-family="Arial, sans-serif" font-size="10" font-weight="bold" text-anchor="middle">mastercard</text>
        `;
    } else if (t.includes('amex') || t.includes('american')) {
        cardType = 'American Express';
        number = `3782 ${getRandomInt(100000,999999)} ${getRandomInt(10000,99999)}`;
        cvv = String(getRandomInt(1000, 9999));
        // Tema plateado
        background = ['#757F9A', '#D7DDE8'];
        logoSvg = `
            <rect x="330" y="30" width="55" height="55" rx="5" fill="#2671B9"/>
            <text x="357.5" y="62" fill="#fff" font-family="Arial, sans-serif" font-size="12" font-style="italic" font-weight="900" text-anchor="middle">AMEX</text>
        `;
    } else {
        cardType = 'Visa'; // Default
        number = `4123 ${getRandomInt(1000,9999)} ${getRandomInt(1000,9999)} ${getRandomInt(1000,9999)}`;
        cvv = String(getRandomInt(100, 999));
        // Tema azul profundo
        background = ['#141E30', '#243B55'];
        logoSvg = `
            <text x="385" y="65" fill="#fff" font-family="Arial, sans-serif" font-size="28" font-style="italic" font-weight="900" text-anchor="end">VISA</text>
        `;
    }

    return { number, name, expiry, cvv, background, logoSvg, cardType };
}

// ── GENERACIÓN DE IMAGEN SVG CON SHARP ──
async function createCardImage(data) {
    const width = 420;
    const height = 260;
    
    // Cambiar color de texto en fondos claros (ej. Amex plateado)
    const textColor = data.cardType === 'American Express' ? '#333' : '#fff';

    const svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="cardGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="${data.background[0]}"/>
                <stop offset="100%" stop-color="${data.background[1]}"/>
            </linearGradient>
            <filter id="shadow">
                <feDropShadow dx="1" dy="1" stdDeviation="2" flood-color="#000" flood-opacity="0.5"/>
            </filter>
        </defs>
        <rect x="0" y="0" width="${width}" height="${height}" rx="20" fill="url(#cardGrad)" />
        
        <!-- Chip -->
        <g transform="translate(40, 75)">
            <rect width="55" height="42" rx="8" fill="#D4AF37" stroke="#B8860B" stroke-width="1.5"/>
            <path d="M 0 12 L 15 12 M 0 21 L 20 21 M 0 30 L 15 30" stroke="#B8860B" stroke-width="1.5" fill="none"/>
            <path d="M 55 12 L 40 12 M 55 21 L 35 21 M 55 30 L 40 30" stroke="#B8860B" stroke-width="1.5" fill="none"/>
            <rect x="20" y="0" width="15" height="42" stroke="#B8860B" stroke-width="1.5" fill="none"/>
        </g>
        
        <!-- Contactless Icon -->
        <g transform="translate(120, 82)" opacity="0.7">
            <path d="M 0 5 A 12 12 0 0 1 0 25" fill="none" stroke="${textColor}" stroke-width="2.5" stroke-linecap="round"/>
            <path d="M 6 0 A 20 20 0 0 1 6 30" fill="none" stroke="${textColor}" stroke-width="2.5" stroke-linecap="round"/>
            <path d="M 12 -5 A 28 28 0 0 1 12 35" fill="none" stroke="${textColor}" stroke-width="2.5" stroke-linecap="round"/>
        </g>

        <!-- Logo -->
        ${data.logoSvg}

        <!-- Card Number -->
        <text x="40" y="170" fill="${textColor}" font-family="Courier New, monospace" font-size="28" font-weight="bold" letter-spacing="3" filter="url(#shadow)">${data.number}</text>
        
        <!-- Expiry -->
        <text x="40" y="210" fill="${textColor}" font-family="Arial, sans-serif" font-size="9" opacity="0.8" filter="url(#shadow)">VALID THRU</text>
        <text x="40" y="235" fill="${textColor}" font-family="Courier New, monospace" font-size="18" font-weight="bold" filter="url(#shadow)">${data.expiry}</text>
        
        <!-- Cardholder Name -->
        <text x="130" y="235" fill="${textColor}" font-family="Courier New, monospace" font-size="18" font-weight="bold" text-transform="uppercase" filter="url(#shadow)">${data.name}</text>
    </svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
}

// ── HANDLER PRINCIPAL PARA WHATSAPP BOT ──
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        let inputText = text ? text.trim() : '';

        // Valor por defecto si no se ingresa texto
        if (!inputText) {
            inputText = 'Visa'; 
        }

        await message.reply('💳 *Generando tarjeta virtual...* ⏳');

        // 1. Generar datos de la tarjeta 
        const cardData = generateCardData(inputText);
        
        // 2. Generar imagen PNG 
        const imageBuffer = await createCardImage(cardData);

        // 3. Crear formato de texto que acompaña la imagen
        let textSummary = `💳 *TARJETA VIRTUAL GENERADA*

`;
        textSummary += `🏢 *Tipo:* ${cardData.cardType}
`;
        textSummary += `🔢 *Número:* ${cardData.number}
`;
        textSummary += `👤 *Titular:* ${cardData.name}
`;
        textSummary += `📅 *Vencimiento:* ${cardData.expiry}
`;
        textSummary += `🔐 *CVV:* ${cardData.cvv}

`;
        textSummary += `_⚠️ Nota: Estos datos son generados aleatoriamente y no son reales. No sirven para realizar compras._`;

        const chatId = message.from || message.key?.remoteJid;
        const quotedMessage = message._baileyMessage || message.baileyMessage || message;

        await sock.sendMessage(
            chatId,
            { image: imageBuffer, caption: textSummary.trim() },
            { quoted: quotedMessage }
        );

    } catch (error) {
        console.error('[ERROR] .getcard command:', error);
        await message.reply('❌ Ocurrió un error al generar la tarjeta. Por favor intenta de nuevo.');
    }
};

handler.help = ['getcard <tipo>'];
handler.tags = ['herramientas'];
handler.command = /^(getcard|tarjeta|card)$/i;

module.exports = handler;
