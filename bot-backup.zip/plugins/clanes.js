const axios = require('axios');
const FormData = require('form-data');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const db = require('../database.js');

const MAX_MIEMBROS = 30;
const IMGBB_KEYS = [
    '31cd904dc0887888bb4eb0d235b25f1c',
    '811d48ba388bcb86ddf0f06eef21d61d',
    'bb2c58c19a97ea1fa4970622ebbc781c'
];
const MAX_NOMBRE = 30;
const COOLDOWN_30MIN = 30 * 60 * 1000; // 30 minutos en ms

// ==========================================
// HELPERS
// ==========================================

/** Limpia un JID o número a solo dígitos */
function cleanNum(str) {
    return (str || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

/** Formatea milisegundos en formato M min S seg */
function formatTime(ms) {
    if (ms <= 0) return '0s';
    const seconds = Math.ceil(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remSeconds = seconds % 60;
    if (minutes > 0) {
        return `${minutes}m ${remSeconds}s`;
    }
    return `${remSeconds}s`;
}

/** Genera una barra visual de vida (10 bloques) */
function getHealthBar(vida, maxVida = 100) {
    const totalBlocks = 10;
    const filledBlocks = Math.max(0, Math.min(totalBlocks, Math.round((vida / maxVida) * totalBlocks)));
    const emptyBlocks = totalBlocks - filledBlocks;
    return '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);
}

/** Inicializa y migra estructuras por defecto de un clan si no existen */
function ensureClanData(clan) {
    if (!clan) return clan;
    if (clan.vida === undefined) clan.vida = 100;
    if (clan.maxVida === undefined) clan.maxVida = 100;
    if (!clan.depositos) clan.depositos = {};
    if (clan.lastAttackedTime === undefined) clan.lastAttackedTime = 0;
    if (clan.reparaciones === undefined) clan.reparaciones = 0;
    if (clan.logo === undefined) clan.logo = null;
    if (!clan.stats) {
        clan.stats = {
            ataquesRealizados: 0,
            ataquesRecibidos: 0,
            clanesDerrotados: 0
        };
    }
    return clan;
}

async function subirImgBB(buffer) {
    for (const key of IMGBB_KEYS) {
        try {
            const form = new FormData();
            form.append('image', buffer, { filename: 'clan-logo.jpg' });
            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${key}`,
                form,
                { headers: { ...form.getHeaders() }, timeout: 20000 }
            );
            const url = res.data?.data?.url;
            if (url) return url;
        } catch (e) {
            console.warn(`[CLAN-LOGO] ImgBB key ...${key.slice(-6)} falló:`, e.message);
        }
    }
    throw new Error('Todas las keys de ImgBB fallaron para el logo del clan.');
}

async function verificarImagenSegura(imageUrl) {
    const nsfwUrl = `https://api.delirius.online/tools/checknsfw?image=${encodeURIComponent(imageUrl)}`;
    const pornUrl = `https://api.delirius.online/tools/checkporn?image=${encodeURIComponent(imageUrl)}`;

    const [nsfwRes, pornRes] = await Promise.all([
        axios.get(nsfwUrl, { timeout: 20000 }).catch(err => ({
            data: { status: false, data: {}, error: err.message }
        })),
        axios.get(pornUrl, { timeout: 20000 }).catch(err => ({
            data: { status: false, data: {}, error: err.message }
        }))
    ]);

    const nsfwData = nsfwRes?.data?.data || {};
    const pornData = pornRes?.data?.data || {};

    const isTruthy = (value) => {
        if (typeof value === 'boolean') return value;
        if (typeof value === 'number') return value !== 0;
        if (typeof value === 'string') {
            const v = value.trim().toLowerCase();
            if (v === 'true' || v === 'yes' || v === '1' || v === 'y') return true;
            if (v === 'false' || v === 'no' || v === '0' || v === 'n') return false;
        }
        return null;
    };

    const nsfwStatus = nsfwRes?.data?.status === true;
    const pornStatus = pornRes?.data?.status === true;
    const nsfwFlag = !!(
        nsfwStatus && (
            isTruthy(nsfwData.NSFW) === true ||
            isTruthy(nsfwData.safe) === false ||
            String(nsfwData.NSFW ?? '').trim().toLowerCase() === 'true' ||
            String(nsfwData.safe ?? '').trim().toLowerCase() === 'false'
        )
    );
    const pornRaw = String(pornData.isPorn ?? '').trim();
    const pornFlag = pornRaw.toLowerCase() === 'porn';

    if (!nsfwStatus && !pornStatus) {
        console.warn('[CLAN-LOGO] Delirius no respondió bien, se omite la validación por seguridad y se acepta la imagen.');
        return { nsfwData, pornData, skipped: true };
    }

    if (nsfwFlag || pornFlag) {
        const reasons = [];
        if (nsfwFlag) reasons.push('NSFW: detectado');
        if (pornFlag) reasons.push(`Porn: ${pornRaw || 'detectado'}`);
        throw new Error(`La imagen no cumple con los requisitos de seguridad: ${reasons.join(' | ')}`);
    }

    return { nsfwData, pornData, skipped: false };
}

/** Convierte un stream de Baileys a Buffer */
async function streamToBuffer(stream) {
    let buf = Buffer.alloc(0);
    for await (const chunk of stream) {
        buf = Buffer.concat([buf, chunk]);
    }
    return buf;
}

/**
 * Resuelve la imagen del logo desde:
 *  1. URL directa en el texto
 *  2. Imagen adjunta en el mensaje actual (enviada con .clan logo)
 *  3. Imagen citada (respondiendo a una foto)
 * Usa el mismo patrón que sticker.js con downloadContentFromMessage.
 */
async function resolverLogoDesdeMensaje(message, rawUrl) {
    // ── Caso 1: URL en el texto ──────────────────────────────────────────────
    const inputUrl = (rawUrl || '').trim();
    if (inputUrl) {
        if (!/^https?:\/\//i.test(inputUrl)) {
            throw new Error('La URL del logo debe empezar con http:// o https://');
        }
        try {
            const { data } = await axios.get(inputUrl, { responseType: 'arraybuffer', timeout: 20000 });
            return { buffer: Buffer.from(data), sourceUrl: inputUrl };
        } catch (error) {
            throw new Error(`No se pudo descargar la imagen desde la URL: ${error.message}`);
        }
    }

    // ── Caso 2 y 3: imagen en el mensaje actual o citado ─────────────────────
    const baileyMsg = message?._baileyMessage || global.lastBaileyMessage || message;
    if (!baileyMsg) {
        throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
    }

    function unwrap(msg) {
        if (!msg) return null;
        return (
            msg.viewOnceMessage?.message ||
            msg.viewOnceMessageV2?.message ||
            msg.viewOnceMessageV2Extension?.message ||
            msg.ephemeralMessage?.message ||
            msg.documentWithCaptionMessage?.message ||
            msg.buttonReplyMessage?.message ||
            msg.buttonsResponseMessage?.message ||
            msg.templateButtonReplyMessage?.message ||
            msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
            msg
        );
    }

    async function downloadImgMsg(imgMsgObj) {
        try {
            const stream = await downloadContentFromMessage(imgMsgObj, 'image');
            return await streamToBuffer(stream);
        } catch (e) {
            console.error('[CLAN-LOGO] Error descargando imagen:', e.message);
            return null;
        }
    }

    const rawMsg = baileyMsg.message || baileyMsg;
    const inner = unwrap(rawMsg);

    if (inner?.imageMessage) {
        console.log('[CLAN-LOGO] Imagen detectada en el mensaje actual');
        const buf = await downloadImgMsg(inner.imageMessage);
        if (buf) return { buffer: buf, sourceUrl: null };
    }

    const contextInfo =
        inner?.extendedTextMessage?.contextInfo ||
        inner?.imageMessage?.contextInfo ||
        inner?.videoMessage?.contextInfo ||
        inner?.audioMessage?.contextInfo ||
        inner?.stickerMessage?.contextInfo ||
        rawMsg?.extendedTextMessage?.contextInfo ||
        rawMsg?.imageMessage?.contextInfo ||
        rawMsg?.videoMessage?.contextInfo ||
        rawMsg?.stickerMessage?.contextInfo ||
        null;

    const quoted = contextInfo?.quotedMessage;
    if (quoted) {
        const quotedInner = unwrap(quoted) || quoted;
        if (quotedInner?.imageMessage) {
            console.log('[CLAN-LOGO] Imagen detectada en el mensaje citado');
            const buf = await downloadImgMsg(quotedInner.imageMessage);
            if (buf) return { buffer: buf, sourceUrl: null };
        }
    }

    throw new Error('Debes adjuntar una imagen, responder a una imagen o pasar una URL válida.');
}

/** Obtiene el apodo de un usuario o un fallback */
function getApodo(numero) {
    if (!numero) return null;
    const n = cleanNum(numero);
    if (!n) return null;
    const user = db.getUser ? db.getUser(n) : null;
    const apodo = String(user?.apodo || '').trim();
    if (!apodo || apodo.toLowerCase() === 'sin apodo' || apodo === '.' || apodo === '-') return null;
    return apodo;
}

/** Busca un número por apodo */
function findNumByApodo(apodoBuscado) {
    if (!apodoBuscado) return null;
    const buscar = apodoBuscado.trim().toLowerCase();
    const sqliteDb = db.db;
    if (sqliteDb) {
        try {
            const rows = sqliteDb.prepare("SELECT id, data FROM users").all();
            for (const r of rows) {
                try {
                    const u = JSON.parse(r.data);
                    const ap = String(u.apodo || '').trim().toLowerCase();
                    if (ap && ap !== 'sin apodo' && ap !== '.' && ap !== '-' && ap === buscar) {
                        return cleanNum(r.id);
                    }
                } catch (_) {}
            }
        } catch (_) {}
    }
    return null;
}

/**
 * Resuelve un objetivo (mención, apodo o texto) a un número limpio y su JID.
 * Devuelve { num, jid } o null si no se puede resolver.
 */
function resolveTarget(message, rawText) {
    const mentions = message?.mentions || [];
    if (mentions.length > 0) {
        const num = cleanNum(mentions[0]);
        return { num, jid: mentions[0].includes('@') ? mentions[0] : `${num}@s.whatsapp.net` };
    }
    if (rawText) {
        const cleaned = rawText.replace('@', '').trim();
        const byApodo = findNumByApodo(cleaned);
        if (byApodo) return { num: byApodo, jid: `${byApodo}@s.whatsapp.net` };
        const asNum = cleaned.replace(/\D/g, '');
        if (asNum.length >= 6) return { num: asNum, jid: `${asNum}@s.whatsapp.net` };
    }
    return null;
}

/** Calcula el dinero total del clan sumando los depósitos de sus miembros actuales */
function calcularDineroClan(clan) {
    if (!clan) return 0;
    ensureClanData(clan);
    let total = 0;
    const depositos = clan.depositos || {};
    for (const num of (clan.miembros || [])) {
        total += Number(depositos[num]) || 0;
    }
    return total;
}

/** Obtiene la posición global del clan en el top (por dinero depositado total) */
function getPosicionGlobal(nombreClan) {
    const clanes = db.getClanes();
    const lista = Object.entries(clanes).map(([nombre, clan]) => ({
        nombre,
        dinero: calcularDineroClan(clan)
    }));
    lista.sort((a, b) => b.dinero - a.dinero);
    const pos = lista.findIndex(c => c.nombre.toLowerCase() === nombreClan.toLowerCase());
    return pos >= 0 ? pos + 1 : null;
}

/** Encuentra la clave real del clan en la DB (preserva mayúsculas originales) */
function getClanKey(nombreClan) {
    const clanes = db.data?.clanes || {};
    return Object.keys(clanes).find(k => k.toLowerCase() === nombreClan.toLowerCase()) || null;
}

// Mapas temporales de confirmaciones
const pendingDeletes   = new Map(); // { numero: timestamp }
const pendingLeaves    = new Map(); // { numero: timestamp }
const pendingTransfers = new Map(); // { numero: { targetNum, timestamp } }

const CONFIRM_TTL = 60_000; // 60 segundos para confirmar

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { conn, text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

        const senderNumber = cleanNum(senderJid);

        // Parsear args
        const args = (text || '').trim().split(/\s+/).filter(Boolean);
        const sub = (args[0] || '').toLowerCase();         // primer subcomando
        const sub2 = (args[1] || '').toLowerCase();        // segundo subcomando

        // ──────────────────────────────────────
        // .clan top [página]
        // ──────────────────────────────────────
        if (sub === 'top') {
            const clanes = db.getClanes();
            const lista = Object.entries(clanes).map(([nombre, clan]) => {
                ensureClanData(clan);
                const dinero = calcularDineroClan(clan);
                return { nombre, clan, dinero };
            });

            if (lista.length === 0) return await message.reply('📊 Aún no hay clanes registrados.');

            lista.sort((a, b) => b.dinero - a.dinero);

            const itemsPerPage = 10;
            const totalPages = Math.max(1, Math.ceil(lista.length / itemsPerPage));
            let page = parseInt(args[1]) || 1;
            if (isNaN(page) || page < 1) page = 1;
            if (page > totalPages) page = totalPages;

            const start = (page - 1) * itemsPerPage;
            const pageLista = lista.slice(start, start + itemsPerPage);

            let msg = `🏆 *TOP CLANES GLOBAL* 🏆\n`;
            msg += `_Página ${page} de ${totalPages}_\n\n`;

            pageLista.forEach((item, i) => {
                const clan = item.clan;
                const pos = start + i + 1;
                let medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `*#${pos}*`;
                const liderNum = clan.lider;
                const liderApodo = getApodo(liderNum) || `@${liderNum}`;
                msg += `${medal} *${item.nombre}*\n`;
                msg += `👑 Líder: ${liderApodo}\n`;
                msg += `👥 Miembros: ${(clan.miembros || []).length}/${MAX_MIEMBROS}\n`;
                msg += `❤️ Vida: ${clan.vida ?? 100}/100 HP\n`;
                msg += `💰 Dinero Depositado: $${item.dinero.toLocaleString()}\n\n`;
            });

            if (totalPages > 1) {
                const prev = page > 1 ? page - 1 : null;
                const next = page < totalPages ? page + 1 : null;
                if (prev) msg += `⬅️ *.clan top ${prev}* — página anterior\n`;
                if (next) msg += `➡️ *.clan top ${next}* — siguiente página\n`;
            }

            return await message.reply(msg.trim());
        }

        // ──────────────────────────────────────
        // .clan depositar / .clan deposite / .clan dep / .clan d <monto/%/all>
        // ──────────────────────────────────────
        if (sub === 'depositar' || sub === 'deposite' || sub === 'dep' || sub === 'd') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan para depositar dinero.');

            const { nombre, clan } = clanInfo;
            ensureClanData(clan);
            const clanKey = getClanKey(nombre);

            const user = db.getUser(senderNumber);
            if (!user) return await message.reply('❌ No se pudo encontrar tu registro de usuario.');

            const userMoney = Number(user.money) || 0;
            if (userMoney <= 0) return await message.reply('❌ No tienes dinero en tu billetera personal para depositar.');

            const cantArg = (args[1] || '').trim().toLowerCase();
            if (!cantArg) {
                return await message.reply(
                    '❌ Debes especificar cuánto dinero deseas depositar en el clan.\n\n' +
                    '_Ejemplos:_\n' +
                    '💰 *.clan depositar 5000*\n' +
                    '📊 *.clan depositar 50%*\n' +
                    '🔥 *.clan depositar all*'
                );
            }

            let monto = 0;
            if (cantArg === 'all' || cantArg === '100%') {
                monto = userMoney;
            } else if (cantArg.endsWith('%')) {
                const pct = parseFloat(cantArg);
                if (isNaN(pct) || pct <= 0 || pct > 100) {
                    return await message.reply('❌ Porcentaje inválido. Ingresa un porcentaje entre 1% y 100%.');
                }
                monto = Math.floor((userMoney * pct) / 100);
            } else {
                monto = parseInt(cantArg);
                if (isNaN(monto) || monto <= 0) {
                    return await message.reply('❌ Cantidad inválida. Ingresa un número mayor a 0, un porcentaje o "all".');
                }
            }

            if (monto <= 0) return await message.reply('❌ El monto a depositar debe ser mayor a 0.');
            if (monto > userMoney) {
                return await message.reply(`❌ No tienes suficiente dinero. Saldo actual en billetera: *$${userMoney.toLocaleString()}*.`);
            }

            // Descontar de la billetera del usuario
            user.money -= monto;
            db.setUser(senderNumber, user);

            // Acreditar en los depósitos del clan para este usuario
            if (!clan.depositos) clan.depositos = {};
            clan.depositos[senderNumber] = (Number(clan.depositos[senderNumber]) || 0) + monto;
            db.setClan(clanKey, clan);

            const totalUserDep = clan.depositos[senderNumber];

            return await message.reply(
                `💰 *¡DEPÓSITO REALIZADO!* 💰\n\n` +
                `Has depositado *$${monto.toLocaleString()}* al clan *${nombre}*.\n` +
                `💳 Tu dinero depositado acumulado: *$${totalUserDep.toLocaleString()}*\n\n` +
                `⚠️ *Aviso:* El dinero depositado al clan no se puede recuperar de nuevo.`
            );
        }

        // ──────────────────────────────────────
        // .clan atacar / .clan attack <clannombre>
        // ──────────────────────────────────────
        if (sub === 'atacar' || sub === 'attack') {
            const attackerClanInfo = db.getClanDeUsuario(senderNumber);
            if (!attackerClanInfo) return await message.reply('❌ Debes pertenecer a un clan para poder atacar.');

            const { nombre: attackerClanName, clan: attackerClan } = attackerClanInfo;
            ensureClanData(attackerClan);
            const attackerClanKey = getClanKey(attackerClanName);

            const targetNameInput = args.slice(1).join(' ').trim();
            if (!targetNameInput) {
                return await message.reply(
                    '❌ Debes especificar el nombre del clan que deseas atacar.\n' +
                    'Ejemplo: *.clan atacar EmpireClan*'
                );
            }

            if (targetNameInput.toLowerCase() === attackerClanName.toLowerCase()) {
                return await message.reply('❌ No puedes atacar a tu propio clan.');
            }

            const targetClanKey = getClanKey(targetNameInput);
            if (!targetClanKey) return await message.reply(`❌ No existe ningún clan llamado *${targetNameInput}*.`);

            const targetClan = db.getClanByKey(targetClanKey);
            if (!targetClan) return await message.reply(`❌ No se encontró la información del clan *${targetNameInput}*.`);
            ensureClanData(targetClan);

            const user = db.getUser(senderNumber);
            const now = Date.now();

            // 1. Cooldown de atacante (30 minutos)
            const userLastAttack = Number(user?.lastClanAttack) || 0;
            if (now - userLastAttack < COOLDOWN_30MIN) {
                const timeLeft = COOLDOWN_30MIN - (now - userLastAttack);
                return await message.reply(
                    `⏱️ Solo puedes atacar a 1 clan cada 30 minutos.\n` +
                    `Debes esperar *${formatTime(timeLeft)}* para poder atacar nuevamente.`
                );
            }

            // 2. Cooldown de protección del clan defensor (30 minutos)
            const targetLastAttacked = Number(targetClan.lastAttackedTime) || 0;
            if (now - targetLastAttacked < COOLDOWN_30MIN) {
                const timeLeft = COOLDOWN_30MIN - (now - targetLastAttacked);
                return await message.reply(
                    `🛡️ El clan *${targetClanKey}* fue atacado recientemente y no puede recibir más ataques por 30 minutos.\n` +
                    `Tiempo de protección restante: *${formatTime(timeLeft)}*.`
                );
            }

            // Registrar ataque en el usuario atacante
            user.lastClanAttack = now;
            db.setUser(senderNumber, user);

            // Actualizar estadísticas del clan atacante
            if (!attackerClan.stats) attackerClan.stats = { ataquesRealizados: 0, ataquesRecibidos: 0, clanesDerrotados: 0 };
            attackerClan.stats.ataquesRealizados = (Number(attackerClan.stats.ataquesRealizados) || 0) + 1;
            db.setClan(attackerClanKey, attackerClan);

            // Actualizar estado del clan defensor
            if (!targetClan.stats) targetClan.stats = { ataquesRealizados: 0, ataquesRecibidos: 0, clanesDerrotados: 0 };
            targetClan.stats.ataquesRecibidos = (Number(targetClan.stats.ataquesRecibidos) || 0) + 1;
            targetClan.lastAttackedTime = now;
            targetClan.vida = Math.max(0, (Number(targetClan.vida) ?? 100) - 10);

            // ¿Clan defensor destruido? (HP == 0)
            if (targetClan.vida <= 0) {
                // Incrementar derrotados en el atacante
                attackerClan.stats.clanesDerrotados = (Number(attackerClan.stats.clanesDerrotados) || 0) + 1;

                // Sumar todo el dinero depositado del clan eliminado
                const targetDepositos = targetClan.depositos || {};
                let totalDineroBotin = 0;
                for (const mNum of (targetClan.miembros || [])) {
                    totalDineroBotin += Number(targetDepositos[mNum]) || 0;
                }

                // Repartir botín entre miembros del clan atacante como DINERO DEPOSITADO en el clan atacante
                const miembrosAtacantes = attackerClan.miembros || [];
                let botinPorMiembro = 0;
                if (miembrosAtacantes.length > 0 && totalDineroBotin > 0) {
                    botinPorMiembro = Math.floor(totalDineroBotin / miembrosAtacantes.length);
                    if (!attackerClan.depositos) attackerClan.depositos = {};
                    for (const mNum of miembrosAtacantes) {
                        attackerClan.depositos[mNum] = (Number(attackerClan.depositos[mNum]) || 0) + botinPorMiembro;
                    }
                }

                // Guardar clan atacante con estadísticas y depósitos repartidos
                db.setClan(attackerClanKey, attackerClan);

                // Eliminar clan destruido de la base de datos
                db.setClan(targetClanKey, null);

                return await message.reply(
                    `💥 *¡CLAN ENEMIGO DESTRUIDO!* 💥\n\n` +
                    `⚔️ Tu clan *${attackerClanName}* ha asestado el golpe final al clan *${targetClanKey}*.\n` +
                    `💀 *¡El clan ${targetClanKey} ha sido destruido y eliminado por completo!*\n\n` +
                    `💰 *Botín de guerra repartido:*\n` +
                    `💵 Dinero total robado: *$${totalDineroBotin.toLocaleString()}*\n` +
                    `👥 Acreditado a los depósitos del clan (*+$${botinPorMiembro.toLocaleString()}* depositados para cada uno de los ${miembrosAtacantes.length} miembros).`
                );
            } else {
                // El clan objetivo sobrevive el ataque (-10 HP)
                db.setClan(targetClanKey, targetClan);

                const bar = getHealthBar(targetClan.vida);
                return await message.reply(
                    `⚔️ *¡ATAQUE EXITOSO!* ⚔️\n\n` +
                    `💥 Tu clan *${attackerClanName}* atacó a *${targetClanKey}* causándole *10 HP* de daño.\n\n` +
                    `📊 *Estado de ${targetClanKey}:*\n` +
                    `❤️ Vida: *${targetClan.vida}/100 HP* [${bar}]\n` +
                    `🛡️ El clan objetivo entra en protección por los próximos 30 minutos.`
                );
            }
        }

        // ──────────────────────────────────────
        // .clan reparar / .clan repair [cantidad/all]
        // ──────────────────────────────────────
        if (sub === 'reparar' || sub === 'repair') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');

            const { nombre, clan } = clanInfo;
            ensureClanData(clan);
            const clanKey = getClanKey(nombre);

            if (clan.vida >= 100) return await message.reply('❌ El clan ya tiene la vida al máximo (100/100 HP).');
            const hpFaltante = 100 - clan.vida;

            const userDepositado = Number(clan.depositos?.[senderNumber]) || 0;
            if (userDepositado <= 0) {
                return await message.reply(
                    '❌ No tienes dinero depositado en el clan para realizar reparaciones.\n' +
                    '_Usa .clan depositar <cantidad> para depositar fondos._'
                );
            }

            // Costo por HP: empieza en $50,000 y suma +$50,000 por cada reparación previa realizada
            const repCount = Number(clan.reparaciones) || 0;
            const costoPorHP = 50000 + (repCount * 50000);

            const argVal = (args[1] || '').trim().toLowerCase();
            let hpAReparar = 0;

            if (!argVal || argVal === 'all' || argVal === '100%') {
                const hpMaxComprable = Math.floor(userDepositado / costoPorHP);
                hpAReparar = Math.min(hpFaltante, hpMaxComprable);

                if (hpAReparar <= 0) {
                    return await message.reply(
                        `❌ Saldo depositado insuficiente ($${userDepositado.toLocaleString()}) para reparar incluso 1 HP.\n` +
                        `💰 Costo actual por 1 HP: *$${costoPorHP.toLocaleString()}*\n` +
                        `_Usa .clan depositar para añadir más dinero al clan._`
                    );
                }
            } else {
                const numReq = parseInt(argVal);
                if (isNaN(numReq) || numReq <= 0) {
                    return await message.reply('❌ Cantidad de HP inválida. Usa *.clan reparar <cantidad>* o *.clan reparar all*.');
                }
                hpAReparar = Math.min(hpFaltante, numReq);
            }

            const costoTotal = hpAReparar * costoPorHP;
            if (userDepositado < costoTotal) {
                return await message.reply(
                    `❌ Saldo depositado insuficiente.\n` +
                    `Reparar *${hpAReparar} HP* cuesta *$${costoTotal.toLocaleString()}* ($${costoPorHP.toLocaleString()}/HP).\n` +
                    `Tienes *$${userDepositado.toLocaleString()}* depositados.`
                );
            }

            // Descontar del dinero depositado del usuario
            clan.depositos[senderNumber] -= costoTotal;
            clan.vida = Math.min(100, clan.vida + hpAReparar);
            clan.reparaciones = repCount + 1;
            db.setClan(clanKey, clan);

            const proxCostoHP = 50000 + (clan.reparaciones * 50000);
            const bar = getHealthBar(clan.vida);

            return await message.reply(
                `🛠️ *¡CLAN REPARADO!* 🛠️\n\n` +
                `❤️ Se han restaurado *${hpAReparar} HP* al clan *${nombre}*.\n` +
                `📊 Vida actual: *${clan.vida}/100 HP* [${bar}]\n` +
                `💵 Dinero depositado gastado: *$${costoTotal.toLocaleString()}*\n` +
                `💳 Tu dinero depositado restante: *$${clan.depositos[senderNumber].toLocaleString()}*\n\n` +
                `📈 *Próxima reparación:* *$${proxCostoHP.toLocaleString()}* por HP.`
            );
        }

        // ──────────────────────────────────────
        // .clan crear / .clan create <nombre>
        // ──────────────────────────────────────
        if (sub === 'crear' || sub === 'create') {
            const nombre = args[1];
            if (!nombre) return await message.reply('❌ Debes indicar el nombre del clan.\nEjemplo: *.clan crear DarkEmpire*');
            if (nombre.length > MAX_NOMBRE) return await message.reply(`❌ El nombre del clan no puede superar los ${MAX_NOMBRE} caracteres.`);
            if (/\s/.test(nombre)) return await message.reply('❌ El nombre del clan debe escribirse todo junto, sin espacios.');

            const clanActual = db.getClanDeUsuario(senderNumber);
            if (clanActual) return await message.reply(`❌ Ya perteneces al clan *${clanActual.nombre}*. Debes salir antes de crear uno nuevo.`);

            if (db.getClan(nombre)) return await message.reply(`❌ Ya existe un clan con el nombre *${nombre}*.`);

            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

            const nuevoClan = {
                nombre,
                lider: senderNumber,
                decanos: [],
                miembros: [senderNumber],
                invitaciones: [],
                creadoEn: Date.now(),
                vida: 100,
                maxVida: 100,
                depositos: {},
                lastAttackedTime: 0,
                reparaciones: 0,
                stats: {
                    ataquesRealizados: 0,
                    ataquesRecibidos: 0,
                    clanesDerrotados: 0
                }
            };

            db.setClan(nombre, nuevoClan);

            return await message.reply(
                `🎉 *¡Clan creado exitosamente!* 🎉\n\n` +
                `🏴 *${nombre}*\n` +
                `👑 Líder: ${miApodo}\n` +
                `👥 Miembros: 1/${MAX_MIEMBROS}\n` +
                `❤️ Vida: 100/100 HP\n\n` +
                `_Usa .clan invitar @usuario para reclutar miembros._`
            );
        }

        // ──────────────────────────────────────
        // .clan borrar / .clan eliminar / .clan delete [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'borrar' || sub === 'eliminar' || sub === 'delete') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');

            const { nombre, clan } = clanInfo;
            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede eliminar el clan.');

            const isConfirm = sub2 === 'confirmar' || sub2 === 'confirm';

            if (!isConfirm) {
                pendingDeletes.set(senderNumber, Date.now());
                return await message.reply(
                    `⚠️ *¿Estás seguro que deseas eliminar el clan *${nombre}*?*\n\n` +
                    `_Esto expulsará a todos los ${clan.miembros.length} miembros._\n\n` +
                    `Para confirmar escribe:\n*.clan borrar confirmar*\n\n` +
                    `_Tienes 60 segundos para confirmar._`
                );
            }

            const pendingTs = pendingDeletes.get(senderNumber);
            if (!pendingTs || Date.now() - pendingTs > CONFIRM_TTL) {
                pendingDeletes.delete(senderNumber);
                return await message.reply('⚠️ La confirmación expiró. Usa *.clan borrar* primero.');
            }

            pendingDeletes.delete(senderNumber);
            const clanKey = getClanKey(nombre);
            if (clanKey) db.setClan(clanKey, null);

            return await message.reply(`🗑️ El clan *${nombre}* ha sido eliminado. Todos los miembros han sido expulsados.`);
        }

        // ──────────────────────────────────────
        // .clan nombre / .clan name <nuevo_nombre>
        // ──────────────────────────────────────
        if (sub === 'nombre' || sub === 'name') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede cambiar el nombre del clan.');

            const nuevoNombre = args[1];
            if (!nuevoNombre) return await message.reply('❌ Debes indicar el nuevo nombre.\nEjemplo: *.clan nombre NuevoNombre*');
            if (nuevoNombre.length > MAX_NOMBRE) return await message.reply(`❌ El nombre no puede superar los ${MAX_NOMBRE} caracteres.`);
            if (/\s/.test(nuevoNombre)) return await message.reply('❌ El nombre debe escribirse todo junto, sin espacios.');

            const existente = db.getClan(nuevoNombre);
            if (existente && nuevoNombre.toLowerCase() !== nombre.toLowerCase()) {
                return await message.reply(`❌ Ya existe un clan llamado *${nuevoNombre}*.`);
            }

            const clanKey = getClanKey(nombre);
            if (clanKey) {
                const clanData = { ...clan, nombre: nuevoNombre };
                db.setClan(clanKey, null);
                db.setClan(nuevoNombre, clanData);
            }

            return await message.reply(`✅ El clan ha sido renombrado a *${nuevoNombre}* exitosamente.`);
        }

        // ──────────────────────────────────────
        // .clan invitar / .clan invite [cancelar/cancel] @usuario|apodo
        // ──────────────────────────────────────
        if (sub === 'invitar' || sub === 'invite') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            const esLider = clan.lider === senderNumber;
            const esDecano = (clan.decanos || []).includes(senderNumber);

            if (!esLider && !esDecano) return await message.reply('❌ Solo el *líder* o los *decanos* pueden invitar miembros.');

            // .clan invitar cancelar / .clan invite cancel
            if (sub2 === 'cancelar' || sub2 === 'cancel') {
                const rawTarget = args.slice(2).join(' ');
                const resolved = resolveTarget(message, rawTarget);
                if (!resolved) return await message.reply('❌ Debes indicar el usuario cuya invitación quieres cancelar\n_Ejemplo: .clan invitar cancelar @usuario o su apodo_');
                const { num: targetNum, jid: targetJid } = resolved;

                const invitaciones = clan.invitaciones || [];
                const idx = invitaciones.findIndex(inv => inv.objetivo === targetNum);
                if (idx === -1) return await message.reply('❌ No existe una invitación pendiente para ese usuario.');

                clan.invitaciones.splice(idx, 1);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayName = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `✅ La invitación a ${displayName} ha sido cancelada.`,
                    { mentions: [targetJid] }
                );
            }

            if (clan.miembros.length >= MAX_MIEMBROS) return await message.reply(`❌ El clan está lleno (${MAX_MIEMBROS}/${MAX_MIEMBROS} miembros).`);

            const rawTarget = args.slice(1).join(' ');
            const resolved = resolveTarget(message, rawTarget);
            if (!resolved) return await message.reply(
                '❌ Debes mencionar o escribir el apodo del usuario a invitar.\n' +
                '_Ejemplo: .clan invitar @usuario_\n' +
                '_O bien: .clan invitar SuApodo_'
            );
            const { num: targetNum, jid: targetJid } = resolved;
            if (targetNum === senderNumber) return await message.reply('❌ No puedes invitarte a ti mismo.');

            if (clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario ya es miembro del clan.');

            const invitaciones = clan.invitaciones || [];
            const yaInvitado = invitaciones.find(inv => inv.objetivo === targetNum);
            if (yaInvitado) return await message.reply('❌ Ya existe una invitación pendiente para ese usuario.');

            const otroClan = db.getClanDeUsuario(targetNum);
            if (otroClan) return await message.reply(`❌ Ese usuario ya pertenece al clan *${otroClan.nombre}*.`);

            const targetApodo = getApodo(targetNum);
            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;
            const mentionDisplay = targetApodo ? `*${targetApodo}* (@${targetNum})` : `@${targetNum}`;

            if (!clan.invitaciones) clan.invitaciones = [];
            clan.invitaciones.push({ objetivo: targetNum, invitadoPor: senderNumber, timestamp: Date.now() });
            db.setClan(clanKey, clan);

            return await message.reply(
                `📨 *¡Invitación enviada!*\n\n` +
                `${mentionDisplay} ha sido invitado al clan *${nombre}* por *${miApodo}*.\n\n` +
                `_El invitado puede aceptar con:_\n*.clan aceptar ${nombre}*\n` +
                `_O rechazar con:_\n*.clan rechazar ${nombre}*`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan invitaciones / .clan invitations
        // ──────────────────────────────────────
        if (sub === 'invitaciones' || sub === 'invitations') {
            const clanes = db.getClanes();
            const misInvitaciones = [];

            for (const [nombre, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (inv) {
                    misInvitaciones.push({ nombre, clan, inv });
                }
            }

            if (misInvitaciones.length === 0) return await message.reply('📭 No tienes invitaciones pendientes a ningún clan.');

            let msg = `📬 *TUS INVITACIONES PENDIENTES*\n`;
            msg += `━━━━━━━━━━━━━━━\n\n`;

            for (const { nombre, clan, inv } of misInvitaciones) {
                const liderApodo = getApodo(clan.lider) || `@${clan.lider}`;
                const invitadorApodo = getApodo(inv.invitadoPor) || `@${inv.invitadoPor}`;
                const pos = getPosicionGlobal(nombre);
                const miembrosCount = (clan.miembros || []).length;

                msg += `🏴 *${nombre}*\n`;
                msg += `👑 Líder: ${liderApodo}\n`;
                msg += `👥 Miembros: ${miembrosCount}/${MAX_MIEMBROS}\n`;
                msg += `🌍 Top: ${pos ? `#${pos}` : 'Sin posición'}\n`;
                msg += `📨 Invitado por: ${invitadorApodo}\n\n`;
                msg += `_Acepta con:_ *.clan aceptar ${nombre}*\n`;
                msg += `_Rechaza con:_ *.clan rechazar ${nombre}*\n`;
                msg += `━━━━━━━━━━━━━━━\n\n`;
            }

            return await message.reply(msg.trim());
        }

        // ──────────────────────────────────────
        // .clan aceptar / .clan accept <nombre|@usuario|apodo>
        // ──────────────────────────────────────
        if (sub === 'aceptar' || sub === 'accept') {
            const clanActual = db.getClanDeUsuario(senderNumber);
            if (clanActual) return await message.reply(`❌ Ya perteneces al clan *${clanActual.nombre}*. Debes salir antes de aceptar otra invitación.`);

            const rawArg = args.slice(1).join(' ');
            const clanes = db.getClanes();
            let clanEncontrado = null;
            let clanKeyEncontrada = null;

            const invitadorResolved = resolveTarget(message, rawArg);
            const invitadorNum = invitadorResolved ? invitadorResolved.num : null;

            for (const [key, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (!inv) continue;

                if (rawArg && key.toLowerCase() === rawArg.toLowerCase()) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (invitadorNum && inv.invitadoPor === invitadorNum) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (!rawArg) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
            }

            if (!clanEncontrado) return await message.reply('❌ No se encontró ninguna invitación válida.\n_Usa .clan invitaciones para ver tus invitaciones pendientes._');

            if ((clanEncontrado.miembros || []).length >= MAX_MIEMBROS) {
                return await message.reply(`❌ El clan *${clanKeyEncontrada}* está lleno.`);
            }

            clanEncontrado.miembros.push(senderNumber);
            clanEncontrado.invitaciones = (clanEncontrado.invitaciones || []).filter(i => i.objetivo !== senderNumber);
            db.setClan(clanKeyEncontrada, clanEncontrado);

            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;
            return await message.reply(
                `🎉 *¡Bienvenido al clan!*\n\n` +
                `*${miApodo}* ahora es miembro de *${clanKeyEncontrada}*.\n` +
                `👥 Miembros: ${clanEncontrado.miembros.length}/${MAX_MIEMBROS}`
            );
        }

        // ──────────────────────────────────────
        // .clan rechazar / .clan reject <nombre|@usuario|apodo>
        // ──────────────────────────────────────
        if (sub === 'rechazar' || sub === 'reject') {
            const rawArg = args.slice(1).join(' ');
            const clanes = db.getClanes();
            let clanEncontrado = null;
            let clanKeyEncontrada = null;

            const invitadorResolved = resolveTarget(message, rawArg);
            const invitadorNum = invitadorResolved ? invitadorResolved.num : null;

            for (const [key, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (!inv) continue;

                if (rawArg && key.toLowerCase() === rawArg.toLowerCase()) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (invitadorNum && inv.invitadoPor === invitadorNum) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (!rawArg) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
            }

            if (!clanEncontrado) return await message.reply('❌ No se encontró ninguna invitación válida.\n_Usa .clan invitaciones para ver tus invitaciones pendientes._');

            clanEncontrado.invitaciones = (clanEncontrado.invitaciones || []).filter(i => i.objetivo !== senderNumber);
            db.setClan(clanKeyEncontrada, clanEncontrado);

            return await message.reply(`✅ Has rechazado la invitación al clan *${clanKeyEncontrada}*.`);
        }

        // ──────────────────────────────────────
        // .clan expulsar / .clan kick @usuario|apodo
        // ──────────────────────────────────────
        if (sub === 'expulsar' || sub === 'kick') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            const esLider = clan.lider === senderNumber;
            const esDecano = (clan.decanos || []).includes(senderNumber);

            if (!esLider && !esDecano) return await message.reply('❌ Solo el *líder* o los *decanos* pueden expulsar miembros.');

            const rawTarget = args.slice(1).join(' ');
            const resolvedKick = resolveTarget(message, rawTarget);
            if (!resolvedKick) return await message.reply('❌ Debes indicar el usuario a expulsar.');
            const { num: targetNum, jid: targetJid } = resolvedKick;
            if (targetNum === senderNumber) return await message.reply('❌ No puedes expulsarte a ti mismo.');

            if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');
            if (clan.lider === targetNum) return await message.reply('❌ No puedes expulsar al líder del clan.');

            if (!esLider && (clan.decanos || []).includes(targetNum)) {
                return await message.reply('❌ Los decanos no pueden expulsar a otros decanos.');
            }

            clan.miembros = clan.miembros.filter(m => m !== targetNum);
            clan.decanos = (clan.decanos || []).filter(d => d !== targetNum);
            db.setClan(clanKey, clan);

            const targetApodo = getApodo(targetNum);
            const displayKick = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
            return await message.reply(
                `👢 ${displayKick} ha sido expulsado del clan *${nombre}*.`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan decano agregar/add | borrar/delete @usuario
        // ──────────────────────────────────────
        if (sub === 'decano') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede gestionar los decanos.');

            const action = sub2;
            const rawTarget = args.slice(2).join(' ');
            const resolvedDecano = resolveTarget(message, rawTarget);

            if (!resolvedDecano) return await message.reply('❌ Debes indicar el usuario.\nEjemplo: *.clan decano agregar @usuario o su apodo*');
            const { num: targetNum, jid: targetJid } = resolvedDecano;

            if (action === 'agregar' || action === 'add') {
                if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');
                if (targetNum === clan.lider) return await message.reply('❌ El líder ya tiene todos los permisos.');
                if ((clan.decanos || []).includes(targetNum)) return await message.reply('❌ Ese usuario ya es decano.');

                if (!clan.decanos) clan.decanos = [];
                clan.decanos.push(targetNum);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayDecano = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `⭐ ${displayDecano} ahora es *Decano* del clan *${nombre}*.`,
                    { mentions: [targetJid] }
                );
            }

            if (action === 'borrar' || action === 'delete') {
                if (!(clan.decanos || []).includes(targetNum)) return await message.reply('❌ Ese usuario no es decano.');

                clan.decanos = clan.decanos.filter(d => d !== targetNum);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayDecano = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `❌ ${displayDecano} ya no es *Decano* del clan *${nombre}*.`,
                    { mentions: [targetJid] }
                );
            }

            return await message.reply(
                '❓ Subcomandos disponibles:\n' +
                '*.clan decano agregar @usuario* — dar rol de decano\n' +
                '*.clan decano borrar @usuario* — quitar rol de decano'
            );
        }

        // ──────────────────────────────────────
        // .clan lider @usuario|apodo [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'lider') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* actual puede transferir el liderazgo.');

            // .clan lider confirmar
            if (sub2 === 'confirmar' || sub2 === 'confirm') {
                const pending = pendingTransfers.get(senderNumber);
                if (!pending || Date.now() - pending.timestamp > CONFIRM_TTL) {
                    pendingTransfers.delete(senderNumber);
                    return await message.reply('⚠️ La confirmación expiró. Usa *.clan lider @usuario* primero.');
                }

                const nuevoLiderNum = pending.targetNum;
                pendingTransfers.delete(senderNumber);

                if (!clan.miembros.includes(nuevoLiderNum)) {
                    return await message.reply('❌ Ese usuario ya no es miembro del clan.');
                }

                const nuevoLiderApodo = getApodo(nuevoLiderNum) || `@${nuevoLiderNum}`;
                const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

                clan.lider = nuevoLiderNum;
                clan.decanos = (clan.decanos || []).filter(d => d !== nuevoLiderNum);
                db.setClan(clanKey, clan);

                return await message.reply(
                    `👑 *¡Liderazgo transferido!*\n\n` +
                    `*${nuevoLiderApodo}* ahora es el nuevo *Líder* del clan *${nombre}*.\n` +
                    `*${miApodo}* ha pasado a ser miembro común.\n\n` +
                    `_Si quieres salirte ahora usa:_ *.clan salir*`
                );
            }

            const rawTarget = args.slice(1).join(' ');
            const resolvedLider = resolveTarget(message, rawTarget);
            if (!resolvedLider) return await message.reply('❌ Debes indicar el usuario al que transferir el liderazgo.\nEjemplo: *.clan lider @usuario o su apodo*');
            const { num: targetNum, jid: targetJid } = resolvedLider;
            if (targetNum === senderNumber) return await message.reply('❌ Ya eres el líder del clan.');
            if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');

            const targetApodo = getApodo(targetNum);
            const displayTransfer = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
            pendingTransfers.set(senderNumber, { targetNum, timestamp: Date.now() });

            return await message.reply(
                `⚠️ *¿Transferir el liderazgo a ${displayTransfer}?*\n\n` +
                `_Pasarás a ser un miembro común y ${displayTransfer} se convertirá en el nuevo líder._\n\n` +
                `Para confirmar escribe:\n*.clan lider confirmar*\n\n` +
                `_Tienes 60 segundos para confirmar._`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan salir / .clan leave [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'salir' || sub === 'leave') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider === senderNumber) {
                return await message.reply(
                    `❌ *El líder no puede salirse directamente.*\n\n` +
                    `Primero debes transferir el liderazgo a otro miembro:\n` +
                    `*.clan lider @usuario*\n\n` +
                    `_Luego podrás salirte normalmente._`
                );
            }

            const isConfirm = sub2 === 'confirmar' || sub2 === 'confirm';

            if (!isConfirm) {
                pendingLeaves.set(senderNumber, Date.now());
                return await message.reply(
                    `⚠️ *¿Seguro que quieres salirte del clan *${nombre}*?*\n\n` +
                    `Para confirmar escribe:\n*.clan salir confirmar*\n\n` +
                    `_Tienes 60 segundos para confirmar._`
                );
            }

            const pendingTs = pendingLeaves.get(senderNumber);
            if (!pendingTs || Date.now() - pendingTs > CONFIRM_TTL) {
                pendingLeaves.delete(senderNumber);
                return await message.reply('⚠️ La confirmación expiró. Usa *.clan salir* primero.');
            }

            pendingLeaves.delete(senderNumber);
            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

            clan.miembros = clan.miembros.filter(m => m !== senderNumber);
            clan.decanos  = (clan.decanos || []).filter(d => d !== senderNumber);
            db.setClan(clanKey, clan);

            return await message.reply(`🚪 *${miApodo}* ha salido del clan *${nombre}*.`);
        }

        // ──────────────────────────────────────
        // .clan info [nombre] / .clan informacion [nombre]
        // ──────────────────────────────────────
        if (sub === 'info' || sub === 'informacion') {
            const nombreBuscado = args.slice(1).join(' ');

            let clanKey = null;
            let clan = null;
            let nombre = null;

            if (nombreBuscado) {
                clanKey = getClanKey(nombreBuscado);
                if (!clanKey) return await message.reply(`❌ No existe ningún clan llamado *${nombreBuscado}*.`);
                clan = db.getClanByKey(clanKey);
                nombre = clanKey;
            } else {
                const clanInfo = db.getClanDeUsuario(senderNumber);
                if (!clanInfo) {
                    return await message.reply(
                        `❌ No perteneces a ningún clan.\n\n` +
                        `_Usa .clan info <nombre> para ver la info de un clan específico._`
                    );
                }
                nombre = clanInfo.nombre;
                clan = clanInfo.clan;
                clanKey = getClanKey(nombre);
            }

            ensureClanData(clan);

            const liderApodo = getApodo(clan.lider) || `@${clan.lider}`;
            const pos = getPosicionGlobal(nombre);
            const dinero = calcularDineroClan(clan);
            const decanos = (clan.decanos || []).map(d => getApodo(d) || `@${d}`).join(', ') || 'Ninguno';
            const bar = getHealthBar(clan.vida);
            const logoUrl = clan.logo || null;

            const stats = clan.stats || {};
            const ataquesRealizados = Number(stats.ataquesRealizados) || 0;
            const ataquesRecibidos = Number(stats.ataquesRecibidos) || 0;
            const clanesDerrotados = Number(stats.clanesDerrotados) || 0;

            let infoMsg =
                `🏴 *CLAN ${nombre.toUpperCase()}* 🏴\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `👑 *Líder:* ${liderApodo}\n` +
                `⭐ *Decanos:* ${decanos}\n` +
                `👥 *Miembros:* ${clan.miembros.length}/${MAX_MIEMBROS}\n` +
                `❤️ *Vida:* ${clan.vida}/100 HP [${bar}]\n` +
                `💰 *Dinero del clan:* $${dinero.toLocaleString()}\n` +
                `🌍 *Posición global:* ${pos ? `#${pos}` : 'Sin posición'}\n` +
                `${logoUrl ? `🖼️ *Logo:* ✅ Adjunto en esta respuesta\n` : '🖼️ *Logo:* Sin logo aún\n'}\n` +
                `⚔️ *ESTADÍSTICAS DE COMBATE:*\n` +
                `🗡️ Ataques realizados: *${ataquesRealizados}*\n` +
                `🛡️ Ataques recibidos: *${ataquesRecibidos}*\n` +
                `💀 Clanes derrotados: *${clanesDerrotados}*\n\n`;

            // Top 10 Depositantes
            const depositos = clan.depositos || {};
            const topDepositantes = (clan.miembros || [])
                .map(mNum => ({ num: mNum, monto: Number(depositos[mNum]) || 0 }))
                .filter(d => d.monto > 0)
                .sort((a, b) => b.monto - a.monto)
                .slice(0, 10);

            infoMsg += `🏆 *TOP 10 DEPOSITANTES:*\n`;
            if (topDepositantes.length === 0) {
                infoMsg += `_Aún ningún miembro ha depositado dinero._\n`;
            } else {
                topDepositantes.forEach((d, idx) => {
                    const apodo = getApodo(d.num) || `@${d.num}`;
                    const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `*#${idx + 1}*`;
                    infoMsg += `${medal} ${apodo} — *$${d.monto.toLocaleString()}*\n`;
                });
            }

            if (clan.miembros.includes(senderNumber)) {
                const rol = clan.lider === senderNumber ? '👑 Líder' : (clan.decanos || []).includes(senderNumber) ? '⭐ Decano' : '👤 Miembro';
                const miDep = Number(depositos[senderNumber]) || 0;
                infoMsg += `\n📌 *Tu rol:* ${rol}\n💳 *Tu dinero depositado:* $${miDep.toLocaleString()}\n`;
            }

            await message.reply(`⏳ Cargando información del clan *${nombre}*...`);

            const sock = conn || message._sock || global.conn;
            if (logoUrl && sock?.sendMessage) {
                // Enviar la imagen del clan con el texto como caption
                await sock.sendMessage(
                    message.from,
                    { image: { url: logoUrl }, caption: infoMsg.trim() },
                    { quoted: message._baileyMessage || message }
                );
            } else {
                // Sin logo: enviar solo el texto
                await message.reply(infoMsg.trim());
            }
            return;
        }

        // ──────────────────────────────────────
        // .clan logo [url] / responder a una imagen
        // ──────────────────────────────────────
        if (sub === 'logo') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan para cambiar su logo.');

            const { nombre, clan } = clanInfo;
            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* del clan puede cambiar el logo.');

            const rawUrl = args.slice(1).join(' ').trim();

            try {
                const { buffer, sourceUrl } = await resolverLogoDesdeMensaje(message, rawUrl);
                if (!buffer || buffer.length < 1000) {
                    throw new Error('La imagen es demasiado pequeña o no se pudo leer correctamente.');
                }

                await message.reply('📷 Obteniendo la imagen del logo...');
                const imageUrl = await subirImgBB(buffer);

                await message.reply('🔎 Verificando que la imagen sea segura...');
                await verificarImagenSegura(imageUrl);

                clan.logo = imageUrl;
                db.setClan(getClanKey(nombre), clan);

                const sock = conn || message._sock || global.conn;
                const preview = { image: { url: imageUrl }, caption: `✅ *Logo del clan actualizado*\n\n🏴 *${nombre}*` };

                if (sock?.sendMessage) {
                    await sock.sendMessage(message.from, preview, { quoted: message._baileyMessage || message });
                }

                return await message.reply(
                    `✅ *Logo actualizado con éxito.*\n\n` +
                    `🏴 Clan: *${nombre}*\n` +
                    `🖼️ URL permanente: ${imageUrl}\n\n` +
                    `${sourceUrl ? `_Imagen original recibida desde:_ ${sourceUrl}` : '_Se ha guardado la imagen en el almacenamiento permanente del clan._'}`
                );
            } catch (error) {
                console.error('[CLAN-LOGO ERROR]', error.message);
                return await message.reply(
                    `❌ *Error al actualizar el logo:*\n\n${error.message}`
                );
            }
        }

        // ──────────────────────────────────────
        // .clan (sin subcomando) — lista de comandos
        // ──────────────────────────────────────
        if (!sub) {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            const enClan = clanInfo ? `_Estás en el clan *${clanInfo.nombre}*. Usa *.clan info* para ver los detalles._` : `_No perteneces a ningún clan._`;

            return await message.reply(
                `🏴 *SISTEMA DE CLANES* 🏴\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `${enClan}\n\n` +
                `*📋 Comandos generales:*\n` +
                `📊 *.clan top [pág]* — ranking de clanes por riqueza\n` +
                `ℹ️ *.clan info [nombre]* — ver info y stats de tu clan o de otro\n` +
                `📬 *.clan invitaciones* — ver invitaciones pendientes\n` +
                `✅ *.clan aceptar <clan/@user/apodo>* — aceptar invitación\n` +
                `❌ *.clan rechazar <clan/@user/apodo>* — rechazar invitación\n\n` +
                `*⚔️ Combate y Economía:*\n` +
                `⚔️ *.clan atacar <nombre>* — atacar a un clan enemigo (-10 HP)\n` +
                `💰 *.clan depositar <monto/%/all>* — depositar dinero al clan\n` +
                `🛠️ *.clan reparar [cantidad/all]* — reparar vida del clan\n\n` +
                `*🆕 Sin clan:*\n` +
                `🆕 *.clan crear <nombre>* — crear un clan nuevo\n\n` +
                `*👥 Miembro/Decano:*\n` +
                `🚪 *.clan salir* — salir del clan\n\n` +
                `*⭐ Decano + Líder:*\n` +
                `📨 *.clan invitar @user/apodo* — invitar miembro\n` +
                `📨 *.clan invitar cancelar @user/apodo* — cancelar invitación\n` +
                `👢 *.clan expulsar @user/apodo* — expulsar miembro\n\n` +
                `*👑 Solo Líder:*\n` +
                `⭐ *.clan decano agregar @user/apodo* — dar decano\n` +
                `⭐ *.clan decano borrar @user/apodo* — quitar decano\n` +
                `👑 *.clan lider @user/apodo* — transferir liderazgo\n` +
                `✏️ *.clan nombre <nuevo>* — renombrar clan\n` +
                `�️ *.clan logo [url]* — cambiar el logo del clan\n` +
                `�🗑️ *.clan borrar* — eliminar clan\n\n` +
                `💡 _Nota: En todos los comandos donde se requiere un usuario, puedes usar la mención (@usuario) o escribir directamente su apodo._`
            );
        }

        // Subcomando desconocido
        return await message.reply(
            `❓ Subcomando no reconocido: *${sub}*\n\n` +
            `_Usa *.clan* para ver todos los comandos disponibles._`
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de clanes:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema de clanes*\n\n_Ocurrió un error inesperado._');
    }
};

handler.help = [
    'clan',
    'clan info [nombre]',
    'clan top [página]',
    'clan atacar <nombre>',
    'clan depositar <monto/%/all>',
    'clan reparar [cantidad/all]',
    'clan crear <nombre>',
    'clan borrar',
    'clan nombre <nuevo>',
    'clan logo [url]',
    'clan invitar @usuario',
    'clan invitar cancelar @usuario',
    'clan aceptar <clan>',
    'clan rechazar <clan>',
    'clan invitaciones',
    'clan expulsar @usuario',
    'clan salir',
    'clan lider @usuario',
    'clan decano agregar @usuario',
    'clan decano borrar @usuario'
];
handler.tags = ['clanes'];
handler.command = /^(clan)$/i;

module.exports = handler;
