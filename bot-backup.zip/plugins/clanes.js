const db = require('../database.js');

const MAX_MIEMBROS = 30;
const MAX_NOMBRE = 30;

// ==========================================
// HELPERS
// ==========================================

/** Limpia un JID o número a solo dígitos */
function cleanNum(str) {
    return (str || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

/** Obtiene el apodo de un usuario o un fallback */
function getApodo(numero) {
    if (!numero) return null;
    const n = cleanNum(numero);
    const users = db.data?.users || {};
    const user = users[n] || Object.values(users).find((_, i) => Object.keys(users)[i].startsWith(n));
    const apodo = String(user?.apodo || '').trim();
    if (!apodo || apodo.toLowerCase() === 'sin apodo' || apodo === '.' || apodo === '-') return null;
    return apodo;
}

/** Busca un número por apodo */
function findNumByApodo(apodoBuscado) {
    if (!apodoBuscado) return null;
    const buscar = apodoBuscado.trim().toLowerCase();
    const users = db.data?.users || {};
    for (const [id, user] of Object.entries(users)) {
        const ap = String(user?.apodo || '').trim().toLowerCase();
        if (ap && ap !== 'sin apodo' && ap !== '.' && ap !== '-' && ap === buscar) {
            return cleanNum(id);
        }
    }
    return null;
}

/**
 * Resuelve un objetivo (mención, apodo o texto) a un número limpio y su JID.
 * Devuelve { num, jid } o null si no se puede resolver.
 */
function resolveTarget(message, rawText) {
    const mentions = message?.mentions || [];
    if (mentions.length > 0) {
        const num = cleanNum(mentions[0]);
        return { num, jid: mentions[0].includes('@') ? mentions[0] : `${num}@s.whatsapp.net` };
    }
    if (rawText) {
        const cleaned = rawText.replace('@', '').trim();
        const byApodo = findNumByApodo(cleaned);
        if (byApodo) return { num: byApodo, jid: `${byApodo}@s.whatsapp.net` };
        const asNum = cleaned.replace(/\D/g, '');
        if (asNum.length >= 6) return { num: asNum, jid: `${asNum}@s.whatsapp.net` };
    }
    return null;
}

/** Calcula el dinero total del clan sumando dinero+banco de sus miembros */
function calcularDineroClan(miembros) {
    let total = 0;
    for (const num of miembros) {
        const user = db.data?.users?.[num];
        if (user) {
            total += (Number(user.money) || 0) + (Number(user.bank) || 0);
        }
    }
    return total;
}

/** Obtiene la posición global del clan en el top (por riqueza) */
function getPosicionGlobal(nombreClan) {
    const clanes = db.getClanes();
    const lista = Object.entries(clanes).map(([nombre, clan]) => ({
        nombre,
        dinero: calcularDineroClan(clan.miembros || [])
    }));
    lista.sort((a, b) => b.dinero - a.dinero);
    const pos = lista.findIndex(c => c.nombre.toLowerCase() === nombreClan.toLowerCase());
    return pos >= 0 ? pos + 1 : null;
}

/** Encuentra la clave real del clan en la DB (preserva mayúsculas originales) */
function getClanKey(nombreClan) {
    const clanes = db.data?.clanes || {};
    return Object.keys(clanes).find(k => k.toLowerCase() === nombreClan.toLowerCase()) || null;
}

// Mapas temporales de confirmaciones
const pendingDeletes   = new Map(); // { numero: timestamp }
const pendingLeaves    = new Map(); // { numero: timestamp }
const pendingTransfers = new Map(); // { numero: { targetNum, timestamp } }

const CONFIRM_TTL = 60_000; // 60 segundos para confirmar

// ==========================================
// HANDLER PRINCIPAL
// ==========================================

let handler = async (message, { conn, text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

        const senderNumber = cleanNum(senderJid);

        // Parsear args
        const args = (text || '').trim().split(/\s+/).filter(Boolean);
        const sub = (args[0] || '').toLowerCase();         // primer subcomando
        const sub2 = (args[1] || '').toLowerCase();        // segundo subcomando

        // ──────────────────────────────────────
        // .clan top [página]
        // ──────────────────────────────────────
        if (sub === 'top') {
            const clanes = db.getClanes();
            const lista = Object.entries(clanes).map(([nombre, clan]) => {
                const liderNum = clan.lider;
                const liderApodo = getApodo(liderNum) || `@${liderNum}`;
                const dinero = calcularDineroClan(clan.miembros || []);
                return { nombre, liderApodo, miembros: (clan.miembros || []).length, dinero };
            });

            if (lista.length === 0) return await message.reply('📊 Aún no hay clanes registrados.');

            lista.sort((a, b) => b.dinero - a.dinero);

            const itemsPerPage = 10;
            const totalPages = Math.max(1, Math.ceil(lista.length / itemsPerPage));
            let page = parseInt(args[1]) || 1;
            if (isNaN(page) || page < 1) page = 1;
            if (page > totalPages) page = totalPages;

            const start = (page - 1) * itemsPerPage;
            const pageLista = lista.slice(start, start + itemsPerPage);

            let msg = `🏆 *TOP CLANES GLOBAL* 🏆\n`;
            msg += `_Página ${page} de ${totalPages}_\n\n`;

            pageLista.forEach((c, i) => {
                const pos = start + i + 1;
                let medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `*#${pos}*`;
                msg += `${medal} *${c.nombre}*\n`;
                msg += `👑 Líder: ${c.liderApodo}\n`;
                msg += `👥 Miembros: ${c.miembros}/${MAX_MIEMBROS}\n`;
                msg += `💰 Dinero: $${c.dinero.toLocaleString()}\n\n`;
            });

            if (totalPages > 1) {
                const prev = page > 1 ? page - 1 : null;
                const next = page < totalPages ? page + 1 : null;
                if (prev) msg += `⬅️ *.clan top ${prev}* — página anterior\n`;
                if (next) msg += `➡️ *.clan top ${next}* — siguiente página\n`;
            }

            return await message.reply(msg.trim());
        }

        // ──────────────────────────────────────
        // .clan crear / .clan create <nombre>
        // ──────────────────────────────────────
        if (sub === 'crear' || sub === 'create') {
            const nombre = args[1];
            if (!nombre) return await message.reply('❌ Debes indicar el nombre del clan.\nEjemplo: *.clan crear DarkEmpire*');
            if (nombre.length > MAX_NOMBRE) return await message.reply(`❌ El nombre del clan no puede superar los ${MAX_NOMBRE} caracteres.`);
            if (/\s/.test(nombre)) return await message.reply('❌ El nombre del clan debe escribirse todo junto, sin espacios.');

            const clanActual = db.getClanDeUsuario(senderNumber);
            if (clanActual) return await message.reply(`❌ Ya perteneces al clan *${clanActual.nombre}*. Debes salir antes de crear uno nuevo.`);

            if (db.getClan(nombre)) return await message.reply(`❌ Ya existe un clan con el nombre *${nombre}*.`);

            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

            const nuevoClan = {
                nombre,
                lider: senderNumber,
                decanos: [],
                miembros: [senderNumber],
                invitaciones: [],
                creadoEn: Date.now()
            };

            db.setClan(nombre, nuevoClan);

            return await message.reply(
                `🎉 *¡Clan creado exitosamente!* 🎉\n\n` +
                `🏴 *${nombre}*\n` +
                `👑 Líder: ${miApodo}\n` +
                `👥 Miembros: 1/${MAX_MIEMBROS}\n\n` +
                `_Usa .clan invitar @usuario para reclutar miembros._`
            );
        }

        // ──────────────────────────────────────
        // .clan borrar / .clan eliminar / .clan delete [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'borrar' || sub === 'eliminar' || sub === 'delete') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');

            const { nombre, clan } = clanInfo;
            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede eliminar el clan.');

            const isConfirm = sub2 === 'confirmar' || sub2 === 'confirm';

            if (!isConfirm) {
                pendingDeletes.set(senderNumber, Date.now());
                return await message.reply(
                    `⚠️ *¿Estás seguro que deseas eliminar el clan *${nombre}*?*\n\n` +
                    `_Esto expulsará a todos los ${clan.miembros.length} miembros._\n\n` +
                    `Para confirmar escribe:\n*.clan borrar confirmar*\n\n` +
                    `_Tienes 60 segundos para confirmar._`
                );
            }

            const pendingTs = pendingDeletes.get(senderNumber);
            if (!pendingTs || Date.now() - pendingTs > CONFIRM_TTL) {
                pendingDeletes.delete(senderNumber);
                return await message.reply('⚠️ La confirmación expiró. Usa *.clan borrar* primero.');
            }

            pendingDeletes.delete(senderNumber);
            const clanKey = getClanKey(nombre);
            if (clanKey) db.setClan(clanKey, null);

            return await message.reply(`🗑️ El clan *${nombre}* ha sido eliminado. Todos los miembros han sido expulsados.`);
        }

        // ──────────────────────────────────────
        // .clan nombre / .clan name <nuevo_nombre>
        // ──────────────────────────────────────
        if (sub === 'nombre' || sub === 'name') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede cambiar el nombre del clan.');

            const nuevoNombre = args[1];
            if (!nuevoNombre) return await message.reply('❌ Debes indicar el nuevo nombre.\nEjemplo: *.clan nombre NuevoNombre*');
            if (nuevoNombre.length > MAX_NOMBRE) return await message.reply(`❌ El nombre no puede superar los ${MAX_NOMBRE} caracteres.`);
            if (/\s/.test(nuevoNombre)) return await message.reply('❌ El nombre debe escribirse todo junto, sin espacios.');

            const existente = db.getClan(nuevoNombre);
            if (existente && nuevoNombre.toLowerCase() !== nombre.toLowerCase()) {
                return await message.reply(`❌ Ya existe un clan llamado *${nuevoNombre}*.`);
            }

            const clanKey = getClanKey(nombre);
            if (clanKey) {
                const clanData = { ...clan, nombre: nuevoNombre };
                db.setClan(clanKey, null);
                db.setClan(nuevoNombre, clanData);
            }

            return await message.reply(`✅ El clan ha sido renombrado a *${nuevoNombre}* exitosamente.`);
        }

        // ──────────────────────────────────────
        // .clan invitar / .clan invite [cancelar/cancel] @usuario|apodo
        // ──────────────────────────────────────
        if (sub === 'invitar' || sub === 'invite') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            const esLider = clan.lider === senderNumber;
            const esDecano = (clan.decanos || []).includes(senderNumber);

            if (!esLider && !esDecano) return await message.reply('❌ Solo el *líder* o los *decanos* pueden invitar miembros.');

            // .clan invitar cancelar / .clan invite cancel
            if (sub2 === 'cancelar' || sub2 === 'cancel') {
                const rawTarget = args.slice(2).join(' ');
                const resolved = resolveTarget(message, rawTarget);
                if (!resolved) return await message.reply('❌ Debes indicar el usuario cuya invitación quieres cancelar\n_Ejemplo: .clan invitar cancelar @usuario o su apodo_');
                const { num: targetNum, jid: targetJid } = resolved;

                const invitaciones = clan.invitaciones || [];
                const idx = invitaciones.findIndex(inv => inv.objetivo === targetNum);
                if (idx === -1) return await message.reply('❌ No existe una invitación pendiente para ese usuario.');

                clan.invitaciones.splice(idx, 1);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayName = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `✅ La invitación a ${displayName} ha sido cancelada.`,
                    { mentions: [targetJid] }
                );
            }

            if (clan.miembros.length >= MAX_MIEMBROS) return await message.reply(`❌ El clan está lleno (${MAX_MIEMBROS}/${MAX_MIEMBROS} miembros).`);

            const rawTarget = args.slice(1).join(' ');
            const resolved = resolveTarget(message, rawTarget);
            if (!resolved) return await message.reply(
                '❌ Debes mencionar o escribir el apodo del usuario a invitar.\n' +
                '_Ejemplo: .clan invitar @usuario_\n' +
                '_O bien: .clan invitar SuApodo_'
            );
            const { num: targetNum, jid: targetJid } = resolved;
            if (targetNum === senderNumber) return await message.reply('❌ No puedes invitarte a ti mismo.');

            if (clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario ya es miembro del clan.');

            const invitaciones = clan.invitaciones || [];
            const yaInvitado = invitaciones.find(inv => inv.objetivo === targetNum);
            if (yaInvitado) return await message.reply('❌ Ya existe una invitación pendiente para ese usuario.');

            const otroClan = db.getClanDeUsuario(targetNum);
            if (otroClan) return await message.reply(`❌ Ese usuario ya pertenece al clan *${otroClan.nombre}*.`);

            const targetApodo = getApodo(targetNum);
            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;
            // Para la mención en el texto usamos @numero (sin dominio)
            const mentionDisplay = targetApodo ? `*${targetApodo}* (@${targetNum})` : `@${targetNum}`;

            if (!clan.invitaciones) clan.invitaciones = [];
            clan.invitaciones.push({ objetivo: targetNum, invitadoPor: senderNumber, timestamp: Date.now() });
            db.setClan(clanKey, clan);

            return await message.reply(
                `📨 *¡Invitación enviada!*\n\n` +
                `${mentionDisplay} ha sido invitado al clan *${nombre}* por *${miApodo}*.\n\n` +
                `_El invitado puede aceptar con:_\n*.clan aceptar ${nombre}*\n` +
                `_O rechazar con:_\n*.clan rechazar ${nombre}*`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan invitaciones / .clan invitations
        // ──────────────────────────────────────
        if (sub === 'invitaciones' || sub === 'invitations') {
            const clanes = db.getClanes();
            const misInvitaciones = [];

            for (const [nombre, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (inv) {
                    misInvitaciones.push({ nombre, clan, inv });
                }
            }

            if (misInvitaciones.length === 0) return await message.reply('📭 No tienes invitaciones pendientes a ningún clan.');

            let msg = `📬 *TUS INVITACIONES PENDIENTES*\n`;
            msg += `━━━━━━━━━━━━━━━\n\n`;

            for (const { nombre, clan, inv } of misInvitaciones) {
                const liderApodo = getApodo(clan.lider) || `@${clan.lider}`;
                const invitadorApodo = getApodo(inv.invitadoPor) || `@${inv.invitadoPor}`;
                const pos = getPosicionGlobal(nombre);
                const miembrosCount = (clan.miembros || []).length;

                msg += `🏴 *${nombre}*\n`;
                msg += `👑 Líder: ${liderApodo}\n`;
                msg += `👥 Miembros: ${miembrosCount}/${MAX_MIEMBROS}\n`;
                msg += `🌍 Top: ${pos ? `#${pos}` : 'Sin posición'}\n`;
                msg += `📨 Invitado por: ${invitadorApodo}\n\n`;
                msg += `_Acepta con:_ *.clan aceptar ${nombre}*\n`;
                msg += `_Rechaza con:_ *.clan rechazar ${nombre}*\n`;
                msg += `━━━━━━━━━━━━━━━\n\n`;
            }

            return await message.reply(msg.trim());
        }

        // ──────────────────────────────────────
        // .clan aceptar / .clan accept <nombre|@usuario|apodo>
        // ──────────────────────────────────────
        if (sub === 'aceptar' || sub === 'accept') {
            const clanActual = db.getClanDeUsuario(senderNumber);
            if (clanActual) return await message.reply(`❌ Ya perteneces al clan *${clanActual.nombre}*. Debes salir antes de aceptar otra invitación.`);

            const rawArg = args.slice(1).join(' ');
            const clanes = db.getClanes();
            let clanEncontrado = null;
            let clanKeyEncontrada = null;

            const invitadorResolved = resolveTarget(message, rawArg);
            const invitadorNum = invitadorResolved ? invitadorResolved.num : null;

            for (const [key, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (!inv) continue;

                if (rawArg && key.toLowerCase() === rawArg.toLowerCase()) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (invitadorNum && inv.invitadoPor === invitadorNum) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (!rawArg) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
            }

            if (!clanEncontrado) return await message.reply('❌ No se encontró ninguna invitación válida.\n_Usa .clan invitaciones para ver tus invitaciones pendientes._');

            if ((clanEncontrado.miembros || []).length >= MAX_MIEMBROS) {
                return await message.reply(`❌ El clan *${clanKeyEncontrada}* está lleno.`);
            }

            clanEncontrado.miembros.push(senderNumber);
            clanEncontrado.invitaciones = (clanEncontrado.invitaciones || []).filter(i => i.objetivo !== senderNumber);
            db.setClan(clanKeyEncontrada, clanEncontrado);

            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;
            return await message.reply(
                `🎉 *¡Bienvenido al clan!*\n\n` +
                `*${miApodo}* ahora es miembro de *${clanKeyEncontrada}*.\n` +
                `👥 Miembros: ${clanEncontrado.miembros.length}/${MAX_MIEMBROS}`
            );
        }

        // ──────────────────────────────────────
        // .clan rechazar / .clan reject <nombre|@usuario|apodo>
        // ──────────────────────────────────────
        if (sub === 'rechazar' || sub === 'reject') {
            const rawArg = args.slice(1).join(' ');
            const clanes = db.getClanes();
            let clanEncontrado = null;
            let clanKeyEncontrada = null;

            const invitadorResolved = resolveTarget(message, rawArg);
            const invitadorNum = invitadorResolved ? invitadorResolved.num : null;

            for (const [key, clan] of Object.entries(clanes)) {
                if (!clan?.invitaciones) continue;
                const inv = clan.invitaciones.find(i => i.objetivo === senderNumber);
                if (!inv) continue;

                if (rawArg && key.toLowerCase() === rawArg.toLowerCase()) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (invitadorNum && inv.invitadoPor === invitadorNum) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
                if (!rawArg) {
                    clanEncontrado = clan;
                    clanKeyEncontrada = key;
                    break;
                }
            }

            if (!clanEncontrado) return await message.reply('❌ No se encontró ninguna invitación válida.\n_Usa .clan invitaciones para ver tus invitaciones pendientes._');

            clanEncontrado.invitaciones = (clanEncontrado.invitaciones || []).filter(i => i.objetivo !== senderNumber);
            db.setClan(clanKeyEncontrada, clanEncontrado);

            return await message.reply(`✅ Has rechazado la invitación al clan *${clanKeyEncontrada}*.`);
        }

        // ──────────────────────────────────────
        // .clan expulsar / .clan kick @usuario|apodo
        // ──────────────────────────────────────
        if (sub === 'expulsar' || sub === 'kick') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            const esLider = clan.lider === senderNumber;
            const esDecano = (clan.decanos || []).includes(senderNumber);

            if (!esLider && !esDecano) return await message.reply('❌ Solo el *líder* o los *decanos* pueden expulsar miembros.');

            const rawTarget = args.slice(1).join(' ');
            const resolvedKick = resolveTarget(message, rawTarget);
            if (!resolvedKick) return await message.reply('❌ Debes indicar el usuario a expulsar.');
            const { num: targetNum, jid: targetJid } = resolvedKick;
            if (targetNum === senderNumber) return await message.reply('❌ No puedes expulsarte a ti mismo.');

            if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');
            if (clan.lider === targetNum) return await message.reply('❌ No puedes expulsar al líder del clan.');

            if (!esLider && (clan.decanos || []).includes(targetNum)) {
                return await message.reply('❌ Los decanos no pueden expulsar a otros decanos.');
            }

            clan.miembros = clan.miembros.filter(m => m !== targetNum);
            clan.decanos = (clan.decanos || []).filter(d => d !== targetNum);
            db.setClan(clanKey, clan);

            const targetApodo = getApodo(targetNum);
            const displayKick = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
            return await message.reply(
                `👢 ${displayKick} ha sido expulsado del clan *${nombre}*.`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan decano agregar/add | borrar/delete @usuario
        // ──────────────────────────────────────
        if (sub === 'decano') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* puede gestionar los decanos.');

            const action = sub2;
            const rawTarget = args.slice(2).join(' ');
            const resolvedDecano = resolveTarget(message, rawTarget);

            if (!resolvedDecano) return await message.reply('❌ Debes indicar el usuario.\nEjemplo: *.clan decano agregar @usuario o su apodo*');
            const { num: targetNum, jid: targetJid } = resolvedDecano;

            if (action === 'agregar' || action === 'add') {
                if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');
                if (targetNum === clan.lider) return await message.reply('❌ El líder ya tiene todos los permisos.');
                if ((clan.decanos || []).includes(targetNum)) return await message.reply('❌ Ese usuario ya es decano.');

                if (!clan.decanos) clan.decanos = [];
                clan.decanos.push(targetNum);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayDecano = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `⭐ ${displayDecano} ahora es *Decano* del clan *${nombre}*.`,
                    { mentions: [targetJid] }
                );
            }

            if (action === 'borrar' || action === 'delete') {
                if (!(clan.decanos || []).includes(targetNum)) return await message.reply('❌ Ese usuario no es decano.');

                clan.decanos = clan.decanos.filter(d => d !== targetNum);
                db.setClan(clanKey, clan);

                const targetApodo = getApodo(targetNum);
                const displayDecano = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
                return await message.reply(
                    `❌ ${displayDecano} ya no es *Decano* del clan *${nombre}*.`,
                    { mentions: [targetJid] }
                );
            }

            return await message.reply(
                '❓ Subcomandos disponibles:\n' +
                '*.clan decano agregar @usuario* — dar rol de decano\n' +
                '*.clan decano borrar @usuario* — quitar rol de decano'
            );
        }

        // ──────────────────────────────────────
        // .clan lider @usuario|apodo [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'lider') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider !== senderNumber) return await message.reply('❌ Solo el *líder* actual puede transferir el liderazgo.');

            // .clan lider confirmar
            if (sub2 === 'confirmar' || sub2 === 'confirm') {
                const pending = pendingTransfers.get(senderNumber);
                if (!pending || Date.now() - pending.timestamp > CONFIRM_TTL) {
                    pendingTransfers.delete(senderNumber);
                    return await message.reply('⚠️ La confirmación expiró. Usa *.clan lider @usuario* primero.');
                }

                const nuevoLiderNum = pending.targetNum;
                pendingTransfers.delete(senderNumber);

                if (!clan.miembros.includes(nuevoLiderNum)) {
                    return await message.reply('❌ Ese usuario ya no es miembro del clan.');
                }

                const nuevoLiderApodo = getApodo(nuevoLiderNum) || `@${nuevoLiderNum}`;
                const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

                // Transferir liderazgo
                clan.lider = nuevoLiderNum;
                // El antiguo líder pasa a ser miembro común (quitar de decanos si estaba)
                clan.decanos = (clan.decanos || []).filter(d => d !== nuevoLiderNum);
                db.setClan(clanKey, clan);

                return await message.reply(
                    `👑 *¡Liderazgo transferido!*\n\n` +
                    `*${nuevoLiderApodo}* ahora es el nuevo *Líder* del clan *${nombre}*.\n` +
                    `*${miApodo}* ha pasado a ser miembro común.\n\n` +
                    `_Si quieres salirte ahora usa:_ *.clan salir*`
                );
            }

            // Seleccionar nuevo líder
            const rawTarget = args.slice(1).join(' ');
            const resolvedLider = resolveTarget(message, rawTarget);
            if (!resolvedLider) return await message.reply('❌ Debes indicar el usuario al que transferir el liderazgo.\nEjemplo: *.clan lider @usuario o su apodo*');
            const { num: targetNum, jid: targetJid } = resolvedLider;
            if (targetNum === senderNumber) return await message.reply('❌ Ya eres el líder del clan.');
            if (!clan.miembros.includes(targetNum)) return await message.reply('❌ Ese usuario no es miembro del clan.');

            const targetApodo = getApodo(targetNum);
            const displayTransfer = targetApodo ? `*${targetApodo}*` : `@${targetNum}`;
            pendingTransfers.set(senderNumber, { targetNum, timestamp: Date.now() });

            return await message.reply(
                `⚠️ *¿Transferir el liderazgo a ${displayTransfer}?*\n\n` +
                `_Pasárás a ser un miembro común y ${displayTransfer} se convertirá en el nuevo líder._\n\n` +
                `Para confirmar escribe:\n*.clan lider confirmar*\n\n` +
                `_Tienes 60 segundos para confirmar._`,
                { mentions: [targetJid] }
            );
        }

        // ──────────────────────────────────────
        // .clan salir / .clan leave [confirmar/confirm]
        // ──────────────────────────────────────
        if (sub === 'salir' || sub === 'leave') {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            if (!clanInfo) return await message.reply('❌ No perteneces a ningún clan.');
            const { nombre, clan } = clanInfo;
            const clanKey = getClanKey(nombre);

            if (clan.lider === senderNumber) {
                return await message.reply(
                    `❌ *El líder no puede salirse directamente.*\n\n` +
                    `Primero debes transferir el liderazgo a otro miembro:\n` +
                    `*.clan lider @usuario*\n\n` +
                    `_Luego podrás salirte normalmente._`
                );
            }

            const isConfirm = sub2 === 'confirmar' || sub2 === 'confirm';

            if (!isConfirm) {
                pendingLeaves.set(senderNumber, Date.now());
                return await message.reply(
                    `⚠️ *¿Seguro que quieres salirte del clan *${nombre}*?*\n\n` +
                    `Para confirmar escribe:\n*.clan salir confirmar*\n\n` +
                    `_Tienes 60 segundos para confirmar._`
                );
            }

            const pendingTs = pendingLeaves.get(senderNumber);
            if (!pendingTs || Date.now() - pendingTs > CONFIRM_TTL) {
                pendingLeaves.delete(senderNumber);
                return await message.reply('⚠️ La confirmación expiró. Usa *.clan salir* primero.');
            }

            pendingLeaves.delete(senderNumber);
            const miApodo = getApodo(senderNumber) || `@${senderNumber}`;

            clan.miembros = clan.miembros.filter(m => m !== senderNumber);
            clan.decanos  = (clan.decanos || []).filter(d => d !== senderNumber);
            db.setClan(clanKey, clan);

            return await message.reply(`🚪 *${miApodo}* ha salido del clan *${nombre}*.`);
        }

        // ──────────────────────────────────────
        // .clan info [nombre] / .clan informacion [nombre]
        // ──────────────────────────────────────
        if (sub === 'info' || sub === 'informacion') {
            const nombreBuscado = args.slice(1).join(' ');

            let clanKey = null;
            let clan = null;
            let nombre = null;

            if (nombreBuscado) {
                // Ver info de un clan específico por nombre
                clanKey = getClanKey(nombreBuscado);
                if (!clanKey) return await message.reply(`❌ No existe ningún clan llamado *${nombreBuscado}*.`);
                clan = db.getClanByKey(clanKey);
                nombre = clanKey;
            } else {
                // Ver info del clan propio
                const clanInfo = db.getClanDeUsuario(senderNumber);
                if (!clanInfo) {
                    return await message.reply(
                        `❌ No perteneces a ningún clan.\n\n` +
                        `_Usa .clan info <nombre> para ver la info de un clan específico._`
                    );
                }
                nombre = clanInfo.nombre;
                clan = clanInfo.clan;
                clanKey = getClanKey(nombre);
            }

            const liderApodo = getApodo(clan.lider) || `@${clan.lider}`;
            const pos = getPosicionGlobal(nombre);
            const dinero = calcularDineroClan(clan.miembros || []);
            const decanos = (clan.decanos || []).map(d => getApodo(d) || `@${d}`).join(', ') || 'Ninguno';

            let infoMsg =
                `🏴 *${nombre}*\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `👑 *Líder:* ${liderApodo}\n` +
                `⭐ *Decanos:* ${decanos}\n` +
                `👥 *Miembros:* ${clan.miembros.length}/${MAX_MIEMBROS}\n` +
                `💰 *Dinero del clan:* $${dinero.toLocaleString()}\n` +
                `🌍 *Posición global:* ${pos ? `#${pos}` : 'Sin posición'}\n`;

            // Si el usuario es miembro también muestra su rol
            if (clan.miembros.includes(senderNumber)) {
                const rol = clan.lider === senderNumber ? '👑 Líder' : (clan.decanos || []).includes(senderNumber) ? '⭐ Decano' : '👤 Miembro';
                infoMsg += `📌 *Tu rol:* ${rol}\n`;
            }

            return await message.reply(infoMsg);
        }

        // ──────────────────────────────────────
        // .clan (sin subcomando) — lista de comandos
        // ──────────────────────────────────────
        if (!sub) {
            const clanInfo = db.getClanDeUsuario(senderNumber);
            const enClan = clanInfo ? `_Estás en el clan *${clanInfo.nombre}*. Usa *.clan info* para ver los detalles._` : `_No perteneces a ningún clan._`;

            return await message.reply(
                `🏴 *SISTEMA DE CLANES* 🏴\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `${enClan}\n\n` +
                `*📋 Comandos generales:*\n` +
                `📊 *.clan top [pág]* — ranking de clanes\n` +
                `ℹ️ *.clan info [nombre]* — ver info de tu clan o de uno específico\n` +
                `📬 *.clan invitaciones* — ver invitaciones pendientes\n` +
                `✅ *.clan aceptar <clan/@user/apodo>* — aceptar invitación\n` +
                `❌ *.clan rechazar <clan/@user/apodo>* — rechazar invitación\n\n` +
                `*🆕 Sin clan:*\n` +
                `🆕 *.clan crear <nombre>* — crear un clan\n\n` +
                `*👥 Miembro/Decano:*\n` +
                `🚪 *.clan salir* — salir del clan\n\n` +
                `*⭐ Decano + Líder:*\n` +
                `📨 *.clan invitar @user/apodo* — invitar miembro\n` +
                `📨 *.clan invitar cancelar @user/apodo* — cancelar invitación\n` +
                `👢 *.clan expulsar @user/apodo* — expulsar miembro\n\n` +
                `*👑 Solo Líder:*\n` +
                `⭐ *.clan decano agregar @user/apodo* — dar decano\n` +
                `⭐ *.clan decano borrar @user/apodo* — quitar decano\n` +
                `👑 *.clan lider @user/apodo* — transferir liderazgo\n` +
                `✏️ *.clan nombre <nuevo>* — renombrar clan\n` +
                `🗑️ *.clan borrar* — eliminar clan\n\n` +
                `💡 _Nota: En todos los comandos donde se requiere un usuario, puedes usar la mención (@usuario) o escribir directamente su apodo._`
            );
        }

        // Subcomando desconocido
        return await message.reply(
            `❓ Subcomando no reconocido: *${sub}*\n\n` +
            `_Usa *.clan* para ver todos los comandos disponibles._`
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de clanes:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema de clanes*\n\n_Ocurrió un error inesperado._');
    }
};

handler.help = [
    'clan',
    'clan info [nombre]',
    'clan top [página]',
    'clan crear <nombre>',
    'clan borrar',
    'clan nombre <nuevo>',
    'clan invitar @usuario',
    'clan invitar cancelar @usuario',
    'clan aceptar <clan>',
    'clan rechazar <clan>',
    'clan invitaciones',
    'clan expulsar @usuario',
    'clan salir',
    'clan lider @usuario',
    'clan decano agregar @usuario',
    'clan decano borrar @usuario'
];
handler.tags = ['clanes'];
handler.command = /^(clan)$/i;

module.exports = handler;
