/**
 * Comando .mute - Silenciar usuario en grupo
 * Requiere: Sistema MuteSystem global
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar que el sistema de muteo esté disponible
        if (!global.muteSystem) {
            return await message.reply('❌ Sistema de muteo no disponible. Reinicia el bot.');
        }

        // Delegar todo el procesamiento al sistema global
        await global.muteSystem.handleMuteCommand(message);

    } catch (error) {
        console.error('[Plugin Mute] Error:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['mute'];
handler.tags = ['admin'];
handler.command = /^(mute|mutear|silenciar)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;