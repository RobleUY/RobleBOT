/**
 * Comando .sms — Sistema de mensajería privada por apodos
 * Guarda los mensajes en data/sms.json
 *
 * Uso:
 *   .sms                          → muestra ayuda con todos los subcomandos
 *   .sms list / .sms lista        → lista usuarios que te escribieron y mensajes sin leer
 *   .sms ver <apodo>              → leer mensajes de ese apodo (los marca como leídos)
 *   .sms view <apodo>             → igual que "ver"
 *   .sms <apodo> <mensaje>        → enviar mensaje a ese usuario (máx 10 sin leer)
 */

const fs   = require("fs");
const path = require("path");

// ─── Ruta del JSON de SMS ────────────────────────────────────────────────────
const SMS_PATH = path.join(__dirname, "..", "data", "sms.json");

// ─── Helpers de persistencia ─────────────────────────────────────────────────

function loadSMS() {
    try {
        if (fs.existsSync(SMS_PATH)) {
            return JSON.parse(fs.readFileSync(SMS_PATH, "utf8"));
        }
    } catch (e) {
        console.error("[SMS] Error cargando sms.json:", e.message);
    }
    return {};
}

function saveSMS(data) {
    try {
        const dir = path.dirname(SMS_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(SMS_PATH, JSON.stringify(data, null, 2), "utf8");
    } catch (e) {
        console.error("[SMS] Error guardando sms.json:", e.message);
    }
}

// ─── Helper: tiempo relativo ──────────────────────────────────────────────────

function tiempoRelativo(timestamp) {
    const diff = Date.now() - timestamp;
    const seg  = Math.floor(diff / 1000);
    const min  = Math.floor(seg / 60);
    const hora = Math.floor(min / 60);
    const dia  = Math.floor(hora / 24);

    if (dia >= 1)  return dia  === 1 ? "hace 1 día"    : `hace ${dia} días`;
    if (hora >= 1) return hora === 1 ? "hace 1 hora"   : `hace ${hora} horas`;
    if (min >= 1)  return min  === 1 ? "hace 1 minuto" : `hace ${min} minutos`;
    return "hace unos segundos";
}

// ─── Helper: buscar número por apodo (en global.db) ──────────────────────────

function buscarPorApodo(apodoBuscado) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const lower = apodoBuscado.toLowerCase().trim();
    for (const [numero, userData] of Object.entries(global.db.data.users)) {
        if (userData.apodo && userData.apodo.toLowerCase() === lower) {
            return numero;
        }
    }
    return null;
}

// ─── Helper: obtener apodo de un número ──────────────────────────────────────

function getApodo(numero) {
    if (!global.db) return numero;
    const user = global.db.getUser(numero);
    return (user && user.apodo && user.apodo.trim() !== "" && user.apodo !== "sin apodo")
        ? user.apodo
        : numero;
}

// ─── HANDLER PRINCIPAL ───────────────────────────────────────────────────────

let handler = async (message, { text, args }) => {
    try {
        // Obtener número del remitente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply("❌ No se pudo identificar al remitente.");

        const senderNum = senderJid.split("@")[0].replace(/[^0-9]/g, "");

        // Verificar que el usuario tiene apodo registrado
        const senderUser = global.db ? global.db.getUser(senderNum) : null;
        const miApodo = senderUser?.apodo?.trim();
        if (!miApodo || miApodo === "" || miApodo === "sin apodo") {
            return await message.reply(
                "❌ *Necesitas un apodo para usar el sistema de SMS.*\n\n" +
                "💡 Usa `.apodo TuApodo` para registrarte primero."
            );
        }

        // Sin argumentos → ayuda
        if (!text || text.trim() === "") {
            return await message.reply(
                "📱 *SISTEMA DE SMS PRIVADOS*\n" +
                "━━━━━━━━━━━━━━━━━━━━\n\n" +
                "📋 *Subcomandos disponibles:*\n\n" +
                "📬 `.sms list` / `.sms lista`\n" +
                "   _Ver usuarios que te escribieron y mensajes sin leer_\n\n" +
                "👁️ `.sms ver <apodo>`\n" +
                "   _Leer los mensajes de ese usuario (los marca como leídos)_\n\n" +
                "📤 `.sms <apodo> <mensaje>`\n" +
                "   _Enviar un mensaje a ese usuario_\n\n" +
                "━━━━━━━━━━━━━━━━━━━━\n" +
                "⚠️ *Límite:* Máximo 10 mensajes sin leer por usuario.\n" +
                "   El destinatario debe leerlos para que puedas enviar más.\n\n" +
                `👤 *Tu apodo:* ${miApodo}`
            );
        }

        const argsTrimmed = text.trim();
        const partes = argsTrimmed.split(/\s+/);
        const subCmd = partes[0].toLowerCase();

        // ── .sms list / .sms lista ────────────────────────────────────────────
        if (subCmd === "list" || subCmd === "lista") {
            const smsData = loadSMS();
            const buzon   = smsData[senderNum];

            if (!buzon || Object.keys(buzon).length === 0) {
                return await message.reply(
                    "📭 *Tu buzón está vacío.*\n\n" +
                    "💡 Cuando alguien te envíe un SMS lo verás aquí."
                );
            }

            const remitentes = Object.entries(buzon).filter(([, msgs]) => msgs.length > 0);

            if (remitentes.length === 0) {
                return await message.reply("📭 *Tu buzón está vacío.*");
            }

            let lista = "📬 *TU BUZÓN DE SMS*\n━━━━━━━━━━━━━━━━━━━━\n\n";

            for (const [remitenteNum, msgs] of remitentes) {
                const sinLeer = msgs.filter(m => !m.leido).length;
                const total   = msgs.length;
                const apRem   = getApodo(remitenteNum);
                const ultimo  = msgs[msgs.length - 1];
                const cuando  = ultimo ? tiempoRelativo(ultimo.timestamp) : "";

                lista += `👤 *${apRem}*\n`;
                lista += `   📩 ${sinLeer} sin leer / ${total} total\n`;
                if (cuando) lista += `   🕐 Último: _${cuando}_\n`;
                lista += `   💡 Ver: \`.sms ver ${apRem}\`\n\n`;
            }

            lista += "━━━━━━━━━━━━━━━━━━━━";
            return await message.reply(lista);
        }

        // ── .sms ver / .sms view <apodo> ─────────────────────────────────────
        if (subCmd === "ver" || subCmd === "view") {
            if (partes.length < 2) {
                return await message.reply(
                    "❌ *Especifica el apodo del usuario.*\n\n" +
                    "💡 Ejemplo: `.sms ver pepe`"
                );
            }

            const apodoDestino = partes[1];
            const numDestino   = buscarPorApodo(apodoDestino);

            if (!numDestino) {
                return await message.reply(
                    `❌ No se encontró ningún usuario con el apodo *${apodoDestino}*.\n\n` +
                    "💡 Verifica que el apodo sea correcto."
                );
            }

            const smsData  = loadSMS();
            const buzon    = smsData[senderNum];
            const mensajes = buzon && buzon[numDestino] ? buzon[numDestino] : [];

            if (mensajes.length === 0) {
                return await message.reply(`📭 No tienes mensajes de *${apodoDestino}*.`);
            }

            let respuesta = `📩 *MENSAJES DE ${apodoDestino.toUpperCase()}*\n━━━━━━━━━━━━━━━━━━━━\n\n`;

            for (let i = 0; i < mensajes.length; i++) {
                const msg    = mensajes[i];
                const estado = msg.leido ? "✅" : "🔵";
                const cuando = tiempoRelativo(msg.timestamp);
                respuesta += `${estado} *[${i + 1}]* _${cuando}_\n`;
                respuesta += `💬 ${msg.contenido}\n\n`;
            }

            respuesta += "━━━━━━━━━━━━━━━━━━━━";

            // Eliminar los mensajes ya leídos
            if (smsData[senderNum] && smsData[senderNum][numDestino]) {
                delete smsData[senderNum][numDestino];
                // Si el buzón del remitente queda vacío, limpiarlo también
                if (Object.keys(smsData[senderNum]).length === 0) {
                    delete smsData[senderNum];
                }
                saveSMS(smsData);
            }

            return await message.reply(respuesta);
        }

        // ── .sms <apodo> <mensaje> ────────────────────────────────────────────
        if (partes.length < 2) {
            return await message.reply(
                "❌ *Formato incorrecto.*\n\n" +
                "💡 Para enviar un mensaje: `.sms <apodo> <mensaje>`\n" +
                "💡 Para ver ayuda: `.sms`"
            );
        }

        const apodoDestinatario = partes[0];
        const contenido         = partes.slice(1).join(" ").trim();

        if (!contenido) {
            return await message.reply(
                "❌ *El mensaje no puede estar vacío.*\n\n" +
                "💡 Ejemplo: `.sms pepe hola que tal!`"
            );
        }

        const numDestinatario = buscarPorApodo(apodoDestinatario);
        if (!numDestinatario) {
            return await message.reply(
                `❌ No se encontró ningún usuario con el apodo *${apodoDestinatario}*.\n\n` +
                "💡 Verifica que el apodo sea correcto.\n" +
                "💡 Los apodos se registran con `.apodo`"
            );
        }

        if (numDestinatario === senderNum) {
            return await message.reply("❌ No puedes enviarte mensajes a ti mismo. 😄");
        }

        // Cargar datos y verificar límite
        const smsData = loadSMS();

        if (!smsData[numDestinatario])             smsData[numDestinatario] = {};
        if (!smsData[numDestinatario][senderNum])  smsData[numDestinatario][senderNum] = [];

        const bandeja = smsData[numDestinatario][senderNum];
        const sinLeer = bandeja.filter(m => !m.leido).length;

        if (sinLeer >= 10) {
            return await message.reply(
                `❌ *Límite alcanzado.*\n\n` +
                `Ya tienes *10 mensajes sin leer* enviados a *${apodoDestinatario}*.\n\n` +
                `⏳ Espera a que *${apodoDestinatario}* lea tus mensajes antes de enviar más.\n` +
                `💡 ${apodoDestinatario} puede leerlos con: \`.sms ver ${miApodo}\``
            );
        }

        bandeja.push({
            contenido: contenido,
            timestamp: Date.now(),
            leido: false
        });

        saveSMS(smsData);

        const restantes = 10 - (sinLeer + 1);

        return await message.reply(
            `✅ *¡SMS enviado a ${apodoDestinatario}!*\n\n` +
            `💬 _"${contenido}"_\n\n` +
            `📊 Mensajes sin leer enviados: *${sinLeer + 1}/10*\n` +
            `📬 Slots restantes: *${restantes}*\n\n` +
            `_${apodoDestinatario} lo verá cuando use \`.sms ver ${miApodo}\`_`
        );

    } catch (error) {
        console.error("[SMS] Error en comando sms:", error);
        return await message.reply("❌ Ocurrió un error en el sistema de SMS. Intenta de nuevo.");
    }
};

handler.help    = ["sms [list|lista|ver|view] [apodo] [mensaje]"];
handler.tags    = ["herramientas"];
handler.command = /^sms$/i;
handler.group   = false;

module.exports = handler;
