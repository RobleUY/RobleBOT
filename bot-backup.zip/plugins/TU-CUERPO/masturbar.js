// Plugin: masturbar
// Clave en DB: pene_upgrades y vagina_upgrades (ya existentes)
// Comandos: .masturbar, .masturbar @user
// — Da +1 nivel tanto al pene como a la vagina del target (o de uno mismo)
// — Cooldown separado: 1h para masturbarse a sí mismo, 1h para masturbar a otro

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

const PENE_KEY   = 'pene_upgrades';
const VAGINA_KEY = 'vagina_upgrades';
const COOLDOWN_MS = 60 * 60 * 1000; // 1 hora

// ─────────────────────────────────────────────────────────────
// HELPERS DB
// ─────────────────────────────────────────────────────────────
function getOrCreate(userData, key) {
    if (!userData[key]) userData[key] = { level: 0 };
    return userData[key];
}

function peneSize(level)   { return (1 + level * 0.5).toFixed(1); }
function vaginaSize(level) { return (1 + level * 0.5).toFixed(1); }

// Rangos pene (igual que pene-upgrades.js)
const RANGOS_PENE = [
    { min: 0,   nombre: '🌱 Brote'         },
    { min: 2,   nombre: '🥜 Cacahuete'     },
    { min: 3,   nombre: '🐛 Gusanito'      },
    { min: 4,   nombre: '🍄 Champiñón'     },
    { min: 5,   nombre: '🥒 Pepinillo'     },
    { min: 7,   nombre: '🍌 Banano'        },
    { min: 9,   nombre: '🥕 Zanahoria'     },
    { min: 11,  nombre: '🌽 Mazorca'       },
    { min: 13,  nombre: '🍆 Berenjena'     },
    { min: 16,  nombre: '🥦 Brócoli'       },
    { min: 19,  nombre: '🌵 Cactus'        },
    { min: 22,  nombre: '🪵 Tronco'        },
    { min: 26,  nombre: '🗡️ Daga'          },
    { min: 30,  nombre: '⚔️ Espada'        },
    { min: 35,  nombre: '🏛️ Columna'       },
    { min: 40,  nombre: '🌴 Palmera'       },
    { min: 46,  nombre: '🗼 Torre'         },
    { min: 52,  nombre: '🏗️ Grúa'         },
    { min: 59,  nombre: '🚀 Cohete'        },
    { min: 67,  nombre: '⚡ Rayo'          },
    { min: 76,  nombre: '🌊 Tsunami'       },
    { min: 86,  nombre: '🌋 Volcán'        },
    { min: 97,  nombre: '🌪️ Tornado'       },
    { min: 109, nombre: '🛸 OVNI'          },
    { min: 122, nombre: '☄️ Cometa'        },
    { min: 136, nombre: '🌟 Supernova'     },
    { min: 151, nombre: '🪐 Planeta'       },
    { min: 167, nombre: '🌌 Galaxia'       },
    { min: 184, nombre: '🕳️ Agujero Negro' },
    { min: 202, nombre: '∞ El Infinito'    },
];

// Rangos vagina (igual que vagina-upgrades.js)
const RANGOS_VAGINA = [
    { min: 0,   nombre: '🌱 Capullo'          },
    { min: 2,   nombre: '🌸 Florecita'        },
    { min: 3,   nombre: '🌺 Flor'             },
    { min: 4,   nombre: '🍑 Melocotón'        },
    { min: 5,   nombre: '🫐 Mora'             },
    { min: 7,   nombre: '🍒 Cereza'           },
    { min: 9,   nombre: '🍓 Fresa'            },
    { min: 11,  nombre: '🥝 Kiwi'             },
    { min: 13,  nombre: '🍇 Uva'              },
    { min: 16,  nombre: '🌹 Rosa'             },
    { min: 19,  nombre: '🌊 Ola'              },
    { min: 22,  nombre: '🌙 Luna'             },
    { min: 26,  nombre: '💎 Diamante'         },
    { min: 30,  nombre: '🔮 Cristal'          },
    { min: 35,  nombre: '🌈 Arcoíris'         },
    { min: 40,  nombre: '⚡ Rayo'             },
    { min: 46,  nombre: '🌟 Estrella'         },
    { min: 52,  nombre: '🪄 Magia'            },
    { min: 59,  nombre: '🚀 Cohete'           },
    { min: 67,  nombre: '🌋 Volcán'           },
    { min: 76,  nombre: '🌪️ Tornado'          },
    { min: 86,  nombre: '☄️ Cometa'           },
    { min: 97,  nombre: '🌌 Nebulosa'         },
    { min: 109, nombre: '🛸 OVNI'             },
    { min: 122, nombre: '🌟 Supernova'        },
    { min: 136, nombre: '🪐 Planeta'          },
    { min: 151, nombre: '🌌 Galaxia'          },
    { min: 167, nombre: '🕳️ Agujero Negro'    },
    { min: 184, nombre: '✨ Singularidad'     },
    { min: 202, nombre: '∞ El Infinito'       },
];

function getRank(rangos, cmStr) {
    const n = parseFloat(cmStr);
    let rango = rangos[0];
    for (const r of rangos) {
        if (n >= r.min) rango = r;
        else break;
    }
    return rango;
}

// ─────────────────────────────────────────────────────────────
// BUSCAR USUARIO POR MENCIÓN O APODO
// ─────────────────────────────────────────────────────────────
function findUserByMentionOrApodo(message, arg) {
    if (!arg) return null;

    const mentioned = message?.mentions || message?.mentionedJid || [];
    if (mentioned.length > 0) {
        const num = mentioned[0].split('@')[0].split(':')[0];
        const rawData = global.db.data.users?.[num];
        return rawData ? { number: num, data: rawData } : null;
    }

    const query = arg.replace(/^@/, '').trim().toLowerCase();
    if (!query) return null;

    let partial = null;
    for (const [key, u] of Object.entries(global.db.data.users || {})) {
        if (!u?.apodo) continue;
        const apodoLower = u.apodo.toLowerCase();
        if (apodoLower === query)
            return { number: key.split('@')[0].split(':')[0], data: u };
        if (!partial && apodoLower.includes(query))
            partial = { number: key.split('@')[0].split(':')[0], data: u };
    }
    return partial;
}

// ─────────────────────────────────────────────────────────────
// HANDLER
// ─────────────────────────────────────────────────────────────
let handler = async (message, { args, usedPrefix, command }) => {
    try {
        if (!global.db?.data?.users)
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);
        const now          = Date.now();
        const senderRaw    = global.db.data.users?.[senderNumber];
        const senderApodo  = (senderRaw?.apodo || '').trim() || senderNumber;

        const hasMention = (message?.mentions?.length > 0 || message?.mentionedJid?.length > 0) || (args[0] && args[0].trim().length > 0);
        const isSelf     = !hasMention;

        // ── Determinar target ─────────────────────────────────
        let targetNumber, targetApodo, targetData;

        if (isSelf) {
            targetNumber = senderNumber;
            targetData   = senderRaw;
            targetApodo  = senderApodo;
        } else {
            const query  = args.join(' ');
            const target = findUserByMentionOrApodo(message, query);
            if (!target) return await message.reply('❌ No se encontró el usuario. Mencionalo con @usuario.');
            targetNumber = target.number;
            targetData   = target.data;
            targetApodo  = (target.data.apodo || '').trim() || target.number;
        }

        // ── Cooldown (separado: uno para sí mismo, otro para otros) ──
        const senderMasturb   = senderRaw?.masturbar_cd || {};
        const cdKey           = isSelf ? 'lastSelf' : 'lastOther';
        const lastUsed        = senderMasturb[cdKey] || 0;

        if (now - lastUsed < COOLDOWN_MS) {
            const secsLeft = Math.ceil((COOLDOWN_MS - (now - lastUsed)) / 1000);
            const mins     = Math.floor(secsLeft / 60);
            const secs     = secsLeft % 60;
            const msg      = isSelf
                ? `⏳ Ya te masturbaste hace poco.\nPodrás volver a hacerlo en *${mins}m ${secs}s*`
                : `⏳ Ya masturbaste a alguien hace poco.\nPodrás volver a hacerlo en *${mins}m ${secs}s*`;
            return await message.reply(msg);
        }

        // ── Aplicar +1 nivel a pene Y vagina del target ──────
        const targetUser  = global.db.getUser(targetNumber);
        if (!targetUser) return await message.reply('❌ Usuario no encontrado en la base de datos.');

        const pene   = getOrCreate(targetUser, PENE_KEY);
        const vagina = getOrCreate(targetUser, VAGINA_KEY);

        pene.level   = (pene.level   || 0) + 1;
        vagina.level = (vagina.level || 0) + 1;

        // Contador de masturb recibidas
        pene.masturbadoRecibido   = (pene.masturbadoRecibido   || 0) + 1;
        vagina.masturbadoRecibido = (vagina.masturbadoRecibido || 0) + 1;

        targetUser[PENE_KEY]   = pene;
        targetUser[VAGINA_KEY] = vagina;
        global.db.setUser(targetNumber, targetUser);

        // ── Guardar cooldown del sender ───────────────────────
        const senderUser = global.db.getUser(senderNumber);
        if (!senderUser.masturbar_cd) senderUser.masturbar_cd = {};
        senderUser.masturbar_cd[cdKey] = now;

        // Contador de masturb dadas
        senderUser.masturbar_dado = (senderUser.masturbar_dado || 0) + 1;
        global.db.setUser(senderNumber, senderUser);

        // ── Construir respuesta ───────────────────────────────
        const peneCm     = peneSize(pene.level);
        const vaginaCm   = vaginaSize(vagina.level);
        const peneRango  = getRank(RANGOS_PENE,   peneCm);
        const vaginaRango = getRank(RANGOS_VAGINA, vaginaCm);

        if (isSelf) {
            return await message.reply(
                `🍆🌸 *${senderApodo}* se masturbó\n\n` +
                `*Pene:*\n` +
                `  📏 ${peneCm} cm · Nv.${pene.level} · ${peneRango.nombre}\n\n` +
                `*Vagina:*\n` +
                `  ✨ Nv.${vagina.level} · ${vaginaRango.nombre}\n\n` +
                `⏳ _Podrás volver a masturbarte en 1 hora_`
            );
        } else {
            return await message.reply(
                `🍆🌸 *${senderApodo}* masturb(ó) a *${targetApodo}*\n\n` +
                `*Pene:*\n` +
                `  📏 ${peneCm} cm · Nv.${pene.level} · ${peneRango.nombre}\n\n` +
                `*Vagina:*\n` +
                `  ✨ Nv.${vagina.level} · ${vaginaRango.nombre}\n\n` +
                `⏳ _Podrás volver a masturbar a alguien en 1 hora_`
            );
        }

    } catch (error) {
        console.error('[masturbar] Error:', error);
        return await message.reply('❌ Ocurrió un error. Intenta nuevamente.');
    }
};

handler.help = ['masturbar'];
handler.tags = ['fun'];
handler.command = /^masturbar$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;
