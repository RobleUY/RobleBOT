// Plugin: pene-upgrades
// Clave en DB: pene_upgrades (objeto solo creado cuando el usuario usa el comando)
// Comandos: .mipene, .toppenes, .chuparpene

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

// ─────────────────────────────────────────────────────────────
// CLAVE EN DB — separada y clara, nunca inicializada por default
// ─────────────────────────────────────────────────────────────
const DB_KEY = 'pene_upgrades';

function getPeneData(userData) {
    // Solo devuelve datos si el usuario realmente usó el comando
    return userData?.[DB_KEY] || null;
}

function getOrCreatePeneData(userData) {
    if (!userData[DB_KEY]) {
        userData[DB_KEY] = { level: 0 };
    }
    return userData[DB_KEY];
}

// ─────────────────────────────────────────────────────────────
// FÓRMULAS
// ─────────────────────────────────────────────────────────────

// Costo de upgrade: empieza caro y escala exponencialmente
// Nv0→1: $2.000  Nv5: ~$30k  Nv10: ~$250k  Nv20: ~$3M  Nv50: ~$600M  Nv100: ~$200B
function upgradeCost(level) {
    return Math.floor(2000 * Math.pow(1.42, level));
}

// Tamaño: empieza en 1cm, sube 0.5cm por nivel
function peneSize(level) {
    return (1 + level * 0.5).toFixed(1);
}

// ─────────────────────────────────────────────────────────────
// 30 RANGOS por tamaño en cm
// ─────────────────────────────────────────────────────────────
const RANGOS = [
    { min: 0,   nombre: '🌱 Brote'         },
    { min: 2,   nombre: '🥜 Cacahuete'     },
    { min: 3,   nombre: '🐛 Gusanito'      },
    { min: 4,   nombre: '🍄 Champiñón'     },
    { min: 5,   nombre: '🥒 Pepinillo'     },
    { min: 7,   nombre: '🍌 Banano'        },
    { min: 9,   nombre: '🥕 Zanahoria'     },
    { min: 11,  nombre: '🌽 Mazorca'       },
    { min: 13,  nombre: '🍆 Berenjena'     },
    { min: 16,  nombre: '🥦 Brócoli'       },
    { min: 19,  nombre: '🌵 Cactus'        },
    { min: 22,  nombre: '🪵 Tronco'        },
    { min: 26,  nombre: '🗡️ Daga'          },
    { min: 30,  nombre: '⚔️ Espada'        },
    { min: 35,  nombre: '🏛️ Columna'       },
    { min: 40,  nombre: '🌴 Palmera'       },
    { min: 46,  nombre: '🗼 Torre'         },
    { min: 52,  nombre: '🏗️ Grúa'         },
    { min: 59,  nombre: '🚀 Cohete'        },
    { min: 67,  nombre: '⚡ Rayo'          },
    { min: 76,  nombre: '🌊 Tsunami'       },
    { min: 86,  nombre: '🌋 Volcán'        },
    { min: 97,  nombre: '🌪️ Tornado'       },
    { min: 109, nombre: '🛸 OVNI'          },
    { min: 122, nombre: '☄️ Cometa'        },
    { min: 136, nombre: '🌟 Supernova'     },
    { min: 151, nombre: '🪐 Planeta'       },
    { min: 167, nombre: '🌌 Galaxia'       },
    { min: 184, nombre: '🕳️ Agujero Negro' },
    { min: 202, nombre: '∞ El Infinito'    },
];

function peneRank(cmStr) {
    const n = parseFloat(cmStr);
    let rango = RANGOS[0];
    for (const r of RANGOS) {
        if (n >= r.min) rango = r;
        else break;
    }
    return rango;
}
function nextRank(cmStr) {
    const n = parseFloat(cmStr);
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n < RANGOS[i + 1].min) {
            return { nombre: RANGOS[i + 1].nombre, cmNeeded: (RANGOS[i + 1].min - n).toFixed(1) };
        }
    }
    return null;
}

function progressBar(cmStr) {
    const n = parseFloat(cmStr);
    let from = 0, to = RANGOS[RANGOS.length - 1].min;
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n >= RANGOS[i].min && n < RANGOS[i + 1].min) {
            from = RANGOS[i].min;
            to   = RANGOS[i + 1].min;
            break;
        }
    }
    const pct    = Math.min(1, to === from ? 1 : (n - from) / (to - from));
    const filled = Math.round(pct * 12);
    return '[' + '█'.repeat(filled) + '░'.repeat(12 - filled) + ']';
}

// ─────────────────────────────────────────────────────────────
// BUSCAR USUARIO POR MENCIÓN O APODO (sin getUser, sin crear nada)
// ─────────────────────────────────────────────────────────────
function findUserByMentionOrApodo(message, arg) {
    if (!arg) return null;

    // Igual que perfil.js: message?.mentions
    const mentioned = message?.mentions || message?.mentionedJid || [];
    if (mentioned.length > 0) {
        const num = mentioned[0].split('@')[0].split(':')[0];
        const rawData = global.db.data.users?.[num];
        return rawData ? { number: num, data: rawData } : null;
    }

    // Buscar por apodo
    const query = arg.replace(/^@/, '').trim().toLowerCase();
    if (!query) return null;

    let partial = null;
    for (const [key, u] of Object.entries(global.db.data.users || {})) {
        if (!u?.apodo) continue;
        const apodoLower = u.apodo.toLowerCase();
        if (apodoLower === query)
            return { number: key.split('@')[0].split(':')[0], data: u };
        if (!partial && apodoLower.includes(query))
            partial = { number: key.split('@')[0].split(':')[0], data: u };
    }
    return partial;
}

// ─────────────────────────────────────────────────────────────
// HANDLER
// ─────────────────────────────────────────────────────────────
let handler = async (message, { conn, args, usedPrefix, command }) => {
    try {
        if (!global.db?.data?.users)
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);

        // ══════════════════════════════════════════════════════
        // .mipene
        // ══════════════════════════════════════════════════════
        if (/^mipene$/i.test(command)) {

            // ── upgrade all ───────────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0]) && args[1] && /^all$/i.test(args[1])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                const pene = getOrCreatePeneData(user);

                const startLevel = pene.level;
                let level      = startLevel;
                let moneyLeft  = user.money || 0;
                let totalSpent = 0;
                let upgrades   = 0;

                while (true) {
                    const cost = upgradeCost(level);
                    if (moneyLeft < cost) break;
                    moneyLeft -= cost;
                    totalSpent += cost;
                    level++;
                    upgrades++;
                }

                if (upgrades === 0) {
                    const cost = upgradeCost(startLevel);
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${(user.money || 0).toLocaleString()}*`
                    );
                }

                user.money        = moneyLeft;
                pene.level        = level;
                user[DB_KEY]      = pene;
                global.db.setUser(senderNumber, user);

                const cm       = peneSize(level);
                const rango    = peneRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(level);

                let txt =
                    `🚀 *¡UPGRADE MASIVO!*\n\n` +
                    `📈 Niveles: *${startLevel} → ${level}* (+${upgrades})\n` +
                    `📏 Tamaño: *${peneSize(startLevel)} cm → ${cm} cm*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${level}*\n\n` +
                    `💸 Gastado: *$${totalSpent.toLocaleString()}*\n` +
                    `💰 Saldo:   *$${moneyLeft.toLocaleString()}*\n\n`;
                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;
                return await message.reply(txt);
            }

            // ── upgrade (1 nivel) ─────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                const pene = getOrCreatePeneData(user);

                const level = pene.level;
                const cost  = upgradeCost(level);
                const money = user.money || 0;

                if (money < cost) {
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${money.toLocaleString()}*\n\n` +
                        `📏 Actual: *${peneSize(level)} cm* (Nivel ${level})\n` +
                        `📈 Con upgrade: *${peneSize(level + 1)} cm* (Nivel ${level + 1})`
                    );
                }

                user.money   = money - cost;
                pene.level   = level + 1;
                user[DB_KEY] = pene;
                global.db.setUser(senderNumber, user);

                const newLevel = pene.level;
                const cm       = peneSize(newLevel);
                const rango    = peneRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(newLevel);

                let txt =
                    `⬆️ *¡UPGRADE!*\n\n` +
                    `📏 *${cm} cm* (+0.5 cm)\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${newLevel}*\n\n` +
                    `💸 Gastaste: *$${cost.toLocaleString()}*\n` +
                    `💰 Saldo:    *$${user.money.toLocaleString()}*\n\n`;
                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;
                return await message.reply(txt);
            }

            // ── ver info de otro usuario ──────────────────────
            if (args[0] && !/^upgrade$/i.test(args[0])) {
                // Pasar todo el texto después del comando como consulta
                const query = args.join(' ');
                const target = findUserByMentionOrApodo(message, query);
                if (!target) return await message.reply(`❌ No se encontró el usuario *${query}*.`);

                const pene  = getPeneData(target.data);
                const level = pene?.level ?? 0;
                const cm    = peneSize(level);
                const rango = peneRank(cm);
                const apodo = (target.data.apodo || '').trim() || target.number;

                return await message.reply(
                    `🍆 *Pene de ${apodo}*\n\n` +
                    `📏 Tamaño: *${cm} cm*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${level}*\n` +
                    `💦 Te lo han chupado: *${pene?.chupadoRecibido ?? 0}* veces\n` +
                    `� Ha chupado: *${pene?.chupadoDado ?? 0}* veces`
                );
            }

            // ── info propia ───────────────────────────────────
            const rawUser  = global.db.data.users?.[senderNumber];
            const pene     = getPeneData(rawUser);
            const level    = pene?.level ?? 0;
            const cm       = peneSize(level);
            const rango    = peneRank(cm);
            const next     = nextRank(cm);
            const nextCost = upgradeCost(level);
            const apodo    = (rawUser?.apodo || '').trim() || senderNumber;

            let txt =
                `🍆 *Tu Pene — ${apodo}*\n\n` +
                `📏 Tamaño: *${cm} cm*\n` +
                `${progressBar(cm)}\n` +
                `🏆 *${rango.nombre}*\n` +
                `🔢 Nivel: *${level}*\n` +
                `💦 Te lo han chupado: *${pene?.chupadoRecibido ?? 0}* veces\n` +
                `� Has chupado: *${pene?.chupadoDado ?? 0}* veces\n\n`;
            if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;
            txt +=
                `\n💡 *Upgrade* (+0.5 cm): *$${nextCost.toLocaleString()}*\n` +
                `   ↳ *${usedPrefix}mipene upgrade*\n` +
                `   ↳ *${usedPrefix}mipene upgrade all* (máximo posible)`;
            return await message.reply(txt);
        }

        // ══════════════════════════════════════════════════════
        // .toppenes
        // ══════════════════════════════════════════════════════
        if (/^toppenes$/i.test(command)) {
            const isGlobal = args[0] && /^(g|global)$/i.test(args[0]);

            if (!isGlobal && !message.isGroup)
                return await message.reply(`❌ Solo funciona en grupos.\n💡 Usa *${usedPrefix}toppenes global* para el ranking mundial.`);

            const itemsPerPage = 10;
            const allUsers = [];

            if (isGlobal) {
                // Leer directo de la DB cruda — sin getUser para no crear entradas
                for (const [key, u] of Object.entries(global.db.data.users || {})) {
                    const peneData = u?.[DB_KEY];
                    if (!peneData) continue;                    // nunca usó el comando
                    const level = Number(peneData.level) || 0;
                    if (level < 1) continue;                    // nunca hizo upgrade
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((1 + level * 0.5).toFixed(1));
                    allUsers.push({ number: normalizeNumber(key), level, cm, apodo });
                }
            } else {
                const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);
                for (const p of participants) {
                    const num = normalizeNumber(p);
                    const u   = global.db.data.users?.[num];   // leer crudo, sin getUser
                    if (!u) continue;
                    const peneData = u?.[DB_KEY];
                    if (!peneData) continue;                    // nunca usó el comando
                    const level = Number(peneData.level) || 0;
                    if (level < 1) continue;                    // nunca hizo upgrade
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((1 + level * 0.5).toFixed(1));
                    allUsers.push({ number: num, level, cm, apodo });
                }
            }

            if (allUsers.length === 0)
                return await message.reply(`📊 Nadie en el ranking todavía.\n💡 Usa *${usedPrefix}mipene upgrade* para empezar.`);

            allUsers.sort((a, b) => b.level - a.level);

            // Posición global del sender
            const globalAll = [];
            for (const [k, u] of Object.entries(global.db.data.users || {})) {
                const pd = u?.[DB_KEY];
                if (!pd) continue;
                const lv = Number(pd.level) || 0;
                if (lv < 1) continue;
                globalAll.push({ number: normalizeNumber(k), level: lv });
            }
            globalAll.sort((a, b) => b.level - a.level);
            const globalPos      = globalAll.findIndex(u => u.number === senderNumber) + 1;
            const globalTotal    = globalAll.length;
            const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;

            const totalPages = Math.max(1, Math.ceil(allUsers.length / itemsPerPage));
            const userIndex  = allUsers.findIndex(u => u.number === senderNumber);
            const userPos    = userIndex + 1;
            const userPage   = userPos > 0 ? Math.ceil(userPos / itemsPerPage) : 0;

            const pageArg = isGlobal ? args[1] : args[0];
            let page = 1;
            if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
            if (page > totalPages) page = totalPages;

            const start     = (page - 1) * itemsPerPage;
            const pageItems = allUsers.slice(start, start + itemsPerPage);

            let text = isGlobal
                ? `*🌍 TOP PENES GLOBAL 🍆*\n\n`
                : `*🏆 TOP PENES DEL GRUPO 🍆*\n\n`;

            if (!isGlobal) {
                text += `👥 *Grupo:* ${allUsers.length} en el ranking\n`;
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos. grupo:* #${userPos} — *${cu.apodo}* ${cu.cm}cm (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}toppenes ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos. grupo:* No estás en el ranking\n`;
                }
                if (globalPos > 0) {
                    text += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                    text += `   ↳ *${usedPrefix}toppenes global ${globalUserPage}*\n`;
                } else {
                    text += `🌐 *Tu pos. global:* No estás en el ranking\n`;
                }
            } else {
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos.:* #${userPos} — *${cu.apodo}* ${cu.cm}cm (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}toppenes global ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos.:* No estás en el ranking\n`;
                }
            }

            text += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

            if (totalPages > 1) {
                const modeArg = isGlobal ? ' global' : '';
                const prev    = page > 1 ? page - 1 : null;
                const next    = page < totalPages ? page + 1 : null;
                text += `\n`;
                if (prev) text += `⬅️ *${usedPrefix}toppenes${modeArg} ${prev}* anterior\n`;
                if (next) text += `➡️ *${usedPrefix}toppenes${modeArg} ${next}* siguiente\n`;
            }

            text += `\n`;

            for (let i = 0; i < pageItems.length; i++) {
                const u     = pageItems[i];
                const pos   = start + i + 1;
                const medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `${pos}.`;
                const rango = peneRank(u.cm);
                text += `${medal} *${u.apodo}*\n📏 ${u.cm} cm · ${rango.nombre} · Nv.${u.level}\n\n`;
            }

            if (!isGlobal) text += `💡 _Usa *${usedPrefix}toppenes global* para el top mundial_`;

            return await message.reply(text);
        }

        // ══════════════════════════════════════════════════════
        // .chuparpene @user
        // ══════════════════════════════════════════════════════
        if (/^chuparpene$/i.test(command)) {
            if (!message.isGroup)
                return await message.reply('❌ Este comando solo funciona en grupos.');

            // Cooldown: 1 uso cada 5 minutos por usuario
            const COOLDOWN_MS = 5 * 60 * 1000;
            const senderRaw   = global.db.data.users?.[senderNumber];
            const senderPene  = senderRaw?.[DB_KEY] || null;
            const lastChupar  = senderPene?.lastChupar || 0;
            const now         = Date.now();

            if (now - lastChupar < COOLDOWN_MS) {
                const secsLeft = Math.ceil((COOLDOWN_MS - (now - lastChupar)) / 1000);
                const mins     = Math.floor(secsLeft / 60);
                const secs     = secsLeft % 60;
                return await message.reply(
                    `⏳ Tranquilo, déjalo descansar.\n` +
                    `Podrás volver a chupar en *${mins}m ${secs}s*`
                );
            }

            // Buscar target
            const query  = args.join(' ');
            const target = findUserByMentionOrApodo(message, query);
            if (!target) return await message.reply('❌ Debes mencionar a alguien con @usuario.');

            // No puedes chuparte a ti mismo
            if (target.number === senderNumber)
                return await message.reply('🚫 No puedes chupártela tú mismo, eso no vale.');

            // Aplicar +1 nivel al target
            const targetUser = global.db.getUser(target.number);
            if (!targetUser) return await message.reply('❌ Usuario no encontrado en la base de datos.');

            const targetPene = getOrCreatePeneData(targetUser);
            targetPene.level           = (targetPene.level || 0) + 1;
            targetPene.chupadoRecibido = (targetPene.chupadoRecibido || 0) + 1;
            targetUser[DB_KEY]         = targetPene;
            global.db.setUser(target.number, targetUser);

            // Registrar en el sender: cooldown + chupadoDado
            const senderUser = global.db.getUser(senderNumber);
            const senderPeneData = getOrCreatePeneData(senderUser);
            senderPeneData.lastChupar  = now;
            senderPeneData.chupadoDado = (senderPeneData.chupadoDado || 0) + 1;
            senderUser[DB_KEY]         = senderPeneData;
            global.db.setUser(senderNumber, senderUser);

            const targetApodo = (target.data.apodo || '').trim() || target.number;
            const senderApodo = (senderRaw?.apodo || '').trim() || senderNumber;
            const newLevel    = targetPene.level;
            const newCm       = peneSize(newLevel);
            const newRango    = peneRank(newCm);

            return await message.reply(
                `👅 *${senderApodo}* le chupó el pene a *${targetApodo}*\n\n` +
                `📈 *+1 nivel gratis!*\n` +
                `🔢 Nuevo nivel: *${newLevel}*\n` +
                `📏 Nuevo tamaño: *${newCm} cm*\n` +
                `🏆 Rango: *${newRango.nombre}*\n\n` +
                `💦 Total de veces que le han chupado: *${targetPene.chupadoRecibido}*\n` +
                `⏳ _Podrás volver a chupar en 5 minutos_`
            );
        }

    } catch (error) {
        console.error('[pene-upgrades] Error:', error);
        return await message.reply('❌ Ocurrió un error. Intenta nuevamente.');
    }
};

handler.help = ['mipene', 'toppenes', 'chuparpene'];
handler.tags = ['fun'];
handler.command = /^(mipene|toppenes|chuparpene)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;
