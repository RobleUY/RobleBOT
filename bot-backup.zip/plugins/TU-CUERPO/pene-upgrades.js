// Plugin: pene-upgrades
// Comandos: .mipene, .toppenes

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

// ─────────────────────────────────────────────────────────────
// SISTEMA DE COSTOS — curva exponencial agresiva
// Nivel 1:    ~$2.500
// Nivel 5:    ~$25.000
// Nivel 10:   ~$200.000
// Nivel 20:   ~$3.000.000
// Nivel 50:   ~$500.000.000
// Nivel 100:  ~$200.000.000.000
// Sin límite de niveles
// ─────────────────────────────────────────────────────────────
function upgradeCost(level) {
    // Base exponencial: crece ~40% más caro por nivel
    return Math.floor(1500 * Math.pow(1.42, level));
}

// Costo total acumulado para ir del nivel 0 al nivel n
function totalCostToLevel(n) {
    let total = 0;
    for (let i = 0; i < n; i++) total += upgradeCost(i);
    return total;
}

// Tamaño: 3 cm base + 0.5 cm por nivel (crece más lento para que cada cm importe)
function peneSize(level) {
    return (3 + level * 0.5).toFixed(1);
}

// ─────────────────────────────────────────────────────────────
// RANGOS — 30 rangos, cada vez más difícil llegar al siguiente
// ─────────────────────────────────────────────────────────────
const RANGOS = [
    { min: 0,   nombre: '🌱 Brote',          desc: 'Recién germinado' },
    { min: 3,   nombre: '🥜 Cacahuete',       desc: 'Humilde pero presente' },
    { min: 5,   nombre: '🐛 Gusanito',        desc: 'Modesto, tirando' },
    { min: 7,   nombre: '🍄 Champiñón',       desc: 'Gordo pero corto' },
    { min: 10,  nombre: '🥒 Pepinillo',       desc: 'Ya se nota algo' },
    { min: 13,  nombre: '🍌 Banano',          desc: 'Curvo y amarillo' },
    { min: 16,  nombre: '🥕 Zanahoria',       desc: 'Naranja y firme' },
    { min: 19,  nombre: '🌽 Mazorca',         desc: 'Granujiento' },
    { min: 22,  nombre: '🍆 Berenjena',       desc: 'El clásico' },
    { min: 25,  nombre: '🥦 Brócoli',         desc: 'Tiene su textura' },
    { min: 28,  nombre: '� Cactus',          desc: 'Pincha un poco' },
    { min: 32,  nombre: '🪵 Tronco',          desc: 'Robusto' },
    { min: 36,  nombre: '🗡️ Daga',            desc: 'Afilado' },
    { min: 40,  nombre: '⚔️ Espada',          desc: 'Para duelos' },
    { min: 45,  nombre: '🏛️ Columna',         desc: 'Arquitectónico' },
    { min: 50,  nombre: '🌴 Palmera',         desc: 'Tropical' },
    { min: 56,  nombre: '🗼 Torre',           desc: 'París tiembla' },
    { min: 62,  nombre: '🏗️ Grúa',           desc: 'En construcción' },
    { min: 68,  nombre: '🚀 Cohete',          desc: 'En órbita' },
    { min: 75,  nombre: '⚡ Rayo',            desc: 'Electrizante' },
    { min: 83,  nombre: '🌊 Tsunami',         desc: 'Arrasa con todo' },
    { min: 92,  nombre: '🌋 Volcán',          desc: 'En erupción' },
    { min: 102, nombre: '🌪️ Tornado',         desc: 'No para' },
    { min: 113, nombre: '🛸 OVNI',            desc: 'De otro planeta' },
    { min: 125, nombre: '☄️ Cometa',          desc: 'Viene del espacio' },
    { min: 138, nombre: '🌟 Supernova',       desc: 'Explosivo' },
    { min: 152, nombre: '🪐 Planeta',         desc: 'Tiene su propia órbita' },
    { min: 168, nombre: '� Galaxia',         desc: 'Inconmensurable' },
    { min: 185, nombre: '🕳️ Agujero Negro',   desc: 'Todo lo absorbe' },
    { min: 200, nombre: '∞ El Infinito',      desc: 'Más allá de toda comprensión' },
];

function peneRank(cm) {
    const n = parseFloat(cm);
    let rango = RANGOS[0];
    for (const r of RANGOS) {
        if (n >= r.min) rango = r;
        else break;
    }
    return rango;
}

// Siguiente rango
function nextRank(cm) {
    const n = parseFloat(cm);
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n < RANGOS[i + 1].min) {
            const cmNeeded = (RANGOS[i + 1].min - n).toFixed(1);
            return { nombre: RANGOS[i + 1].nombre, cmNeeded };
        }
    }
    return null; // ya en el rango máximo
}

// Barra de progreso hacia el siguiente rango
function progressBar(cm) {
    const n = parseFloat(cm);
    let from = 0, to = RANGOS[RANGOS.length - 1].min;
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n >= RANGOS[i].min && n < RANGOS[i + 1].min) {
            from = RANGOS[i].min;
            to   = RANGOS[i + 1].min;
            break;
        }
    }
    const pct = Math.min(1, (n - from) / (to - from));
    const filled = Math.round(pct * 12);
    return '[' + '█'.repeat(filled) + '░'.repeat(12 - filled) + ']';
}

// Busca un usuario por mención o apodo
function findUserByMentionOrApodo(message, arg) {
    if (!arg) return null;

    const mentioned = message.mentionedJid || [];
    if (mentioned.length > 0) {
        const num = normalizeNumber(mentioned[0]);
        const data = global.db.getUser(num);
        return data ? { number: num, data } : null;
    }

    const query = arg.trim().toLowerCase();
    let partial = null;
    for (const [key, u] of Object.entries(global.db.data.users || {})) {
        if (!u?.apodo) continue;
        if (u.apodo.toLowerCase() === query)
            return { number: normalizeNumber(key), data: u };
        if (!partial && u.apodo.toLowerCase().includes(query))
            partial = { number: normalizeNumber(key), data: u };
    }
    return partial;
}

// ─────────────────────────────────────────────────────────────
// HANDLER
// ─────────────────────────────────────────────────────────────
let handler = async (message, { conn, args, usedPrefix, command }) => {
    try {
        if (!global.db?.data?.users)
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);

        // ══════════════════════════════════════════════════════
        // .mipene
        // ══════════════════════════════════════════════════════
        if (/^mipene$/i.test(command)) {

            // ── upgrade all ───────────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0]) && args[1] && /^all$/i.test(args[1])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                if (!user.pene) user.pene = { level: 0 };

                const startLevel = user.pene.level || 0;
                const startMoney = user.money || 0;
                let level      = startLevel;
                let moneyLeft  = startMoney;
                let totalSpent = 0;
                let upgrades   = 0;

                while (true) {
                    const cost = upgradeCost(level);
                    if (moneyLeft < cost) break;
                    moneyLeft -= cost;
                    totalSpent += cost;
                    level++;
                    upgrades++;
                }

                if (upgrades === 0) {
                    const cost = upgradeCost(startLevel);
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${startMoney.toLocaleString()}*`
                    );
                }

                user.money      = moneyLeft;
                user.pene.level = level;
                global.db.setUser(senderNumber, user);

                const cm       = peneSize(level);
                const rango    = peneRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(level);

                let txt =
                    `🚀 *¡UPGRADE MASIVO!*\n\n` +
                    `📈 Niveles: *${startLevel} → ${level}* (+${upgrades})\n` +
                    `📏 Tamaño: *${peneSize(startLevel)} cm → ${cm} cm*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 Rango: *${rango.nombre}*\n` +
                    `_${rango.desc}_\n\n` +
                    `💸 Gastado: *$${totalSpent.toLocaleString()}*\n` +
                    `💰 Saldo:   *$${moneyLeft.toLocaleString()}*\n\n`;

                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;

                return await message.reply(txt);
            }

            // ── upgrade (1 nivel) ─────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                if (!user.pene) user.pene = { level: 0 };

                const currentLevel = user.pene.level || 0;
                const cost         = upgradeCost(currentLevel);
                const money        = user.money || 0;

                if (money < cost) {
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${money.toLocaleString()}*\n\n` +
                        `📏 Actual: *${peneSize(currentLevel)} cm* (Nivel ${currentLevel})\n` +
                        `📈 Con upgrade: *${peneSize(currentLevel + 1)} cm* (Nivel ${currentLevel + 1})`
                    );
                }

                user.money -= cost;
                user.pene.level = currentLevel + 1;
                global.db.setUser(senderNumber, user);

                const newLevel = user.pene.level;
                const cm       = peneSize(newLevel);
                const rango    = peneRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(newLevel);

                let txt =
                    `⬆️ *¡UPGRADE!*\n\n` +
                    `📏 *${cm} cm* (+0.5 cm)\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}* — _${rango.desc}_\n` +
                    `🔢 Nivel: *${newLevel}*\n\n` +
                    `💸 Gastaste: *$${cost.toLocaleString()}*\n` +
                    `💰 Saldo:    *$${user.money.toLocaleString()}*\n\n`;

                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;

                return await message.reply(txt);
            }

            // ── ver info de otro usuario ──────────────────────
            if (args[0] && !/^upgrade$/i.test(args[0])) {
                const target = findUserByMentionOrApodo(message, args[0]);
                if (!target) return await message.reply(`❌ No se encontró el usuario *${args[0]}*.`);

                const level = target.data.pene?.level || 0;
                const cm    = peneSize(level);
                const rango = peneRank(cm);
                const apodo = target.data.apodo || target.number;

                return await message.reply(
                    `🍆 *Pene de ${apodo}*\n\n` +
                    `📏 Tamaño: *${cm} cm*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}* — _${rango.desc}_\n` +
                    `🔢 Nivel: *${level}*`
                );
            }

            // ── info propia ───────────────────────────────────
            const user = global.db.getUser(senderNumber);
            if (!user) return await message.reply('❌ Usuario no encontrado.');
            if (!user.pene) user.pene = { level: 0 };

            const level    = user.pene.level || 0;
            const cm       = peneSize(level);
            const rango    = peneRank(cm);
            const next     = nextRank(cm);
            const nextCost = upgradeCost(level);
            const apodo    = user.apodo || senderNumber;

            let txt =
                `🍆 *Tu Pene — ${apodo}*\n\n` +
                `📏 Tamaño: *${cm} cm*\n` +
                `${progressBar(cm)}\n` +
                `🏆 *${rango.nombre}* — _${rango.desc}_\n` +
                `🔢 Nivel: *${level}*\n\n`;

            if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded} cm*)\n`;

            txt +=
                `\n💡 *Upgrade* (+0.5 cm): *$${nextCost.toLocaleString()}*\n` +
                `   ↳ *${usedPrefix}mipene upgrade*\n` +
                `   ↳ *${usedPrefix}mipene upgrade all* (máximo posible)`;

            return await message.reply(txt);
        }

        // ══════════════════════════════════════════════════════
        // .toppenes
        // ══════════════════════════════════════════════════════
        if (/^toppenes$/i.test(command)) {
            const isGlobal = args[0] && /^(g|global)$/i.test(args[0]);

            if (!isGlobal && !message.isGroup)
                return await message.reply(`❌ Solo funciona en grupos.\n💡 Usa *${usedPrefix}toppenes global* para el ranking mundial.`);

            const itemsPerPage = 10;
            const allUsers = [];

            if (isGlobal) {
                for (const [key, u] of Object.entries(global.db.data.users || {})) {
                    const level = Number(u?.pene?.level) || 0;
                    if (level < 1) continue;
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((3 + level * 0.5).toFixed(1));
                    allUsers.push({ number: normalizeNumber(key), level, cm, apodo });
                }
            } else {
                const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);
                for (const p of participants) {
                    const num = normalizeNumber(p);
                    const u   = global.db.data.users?.[num];
                    if (!u) continue;
                    const level = Number(u?.pene?.level) || 0;
                    if (level < 1) continue;
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((3 + level * 0.5).toFixed(1));
                    allUsers.push({ number: num, level, cm, apodo });
                }
            }

            // Posición global del sender
            const globalAll = Object.entries(global.db.data.users || {})
                .map(([k, u]) => ({ number: normalizeNumber(k), level: Number(u?.pene?.level) || 0 }))
                .filter(u => u.level >= 1)
                .sort((a, b) => b.level - a.level);
            const globalPos   = globalAll.findIndex(u => u.number === senderNumber) + 1;
            const globalTotal = globalAll.length;
            const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;

            if (allUsers.length === 0)
                return await message.reply(`📊 Nadie en el ranking todavía.\n💡 Usa *${usedPrefix}mipene upgrade* para empezar.`);

            allUsers.sort((a, b) => b.level - a.level);

            // DEBUG temporal — borra esto después de confirmar que funciona
            const debugInfo = allUsers.slice(0, 5).map(u => `${u.apodo}: nv${u.level} (${u.cm}cm)`).join('\n');
            console.log('[toppenes DEBUG]', debugInfo);

            const totalPages = Math.max(1, Math.ceil(allUsers.length / itemsPerPage));
            const userIndex  = allUsers.findIndex(u => u.number === senderNumber);
            const userPos    = userIndex + 1;
            const userPage   = userPos > 0 ? Math.ceil(userPos / itemsPerPage) : 0;

            const pageArg = isGlobal ? args[1] : args[0];
            let page = 1;
            if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
            if (page > totalPages) page = totalPages;

            const start     = (page - 1) * itemsPerPage;
            const pageItems = allUsers.slice(start, start + itemsPerPage);

            let text = isGlobal
                ? `*🌍 TOP PENES GLOBAL 🍆*\n\n`
                : `*🏆 TOP PENES DEL GRUPO 🍆*\n\n`;

            if (!isGlobal) {
                text += `👥 *Grupo:* ${allUsers.length} participantes\n`;
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos. grupo:* #${userPos} — *${cu.apodo}* ${cu.cm}cm (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}toppenes ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos. grupo:* No estás en el ranking\n`;
                }
                if (globalPos > 0) {
                    text += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                    text += `   ↳ *${usedPrefix}toppenes global ${globalUserPage}*\n`;
                } else {
                    text += `🌐 *Tu pos. global:* No estás en el ranking\n`;
                }
            } else {
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos.:* #${userPos} — *${cu.apodo}* ${cu.cm}cm (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}toppenes global ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos.:* No estás en el ranking\n`;
                }
            }

            text += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

            if (totalPages > 1) {
                const modeArg = isGlobal ? ' global' : '';
                const prev    = page > 1 ? page - 1 : null;
                const next    = page < totalPages ? page + 1 : null;
                text += `\n`;
                if (prev) text += `⬅️ *${usedPrefix}toppenes${modeArg} ${prev}* anterior\n`;
                if (next) text += `➡️ *${usedPrefix}toppenes${modeArg} ${next}* siguiente\n`;
            }

            text += `\n`;

            pageItems.forEach((u, i) => {
                const pos   = start + i + 1;
                const medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `${pos}.`;
                const rango = peneRank(u.cm);
                text += `${medal} *${u.apodo}*\n📏 ${u.cm} cm · ${rango.nombre} · Nv.${u.level}\n\n`;
            });

            if (!isGlobal) text += `💡 _Usa *${usedPrefix}toppenes global* para el top mundial_`;

            return await message.reply(text);
        }

    } catch (error) {
        console.error('[pene-upgrades] Error:', error);
        return await message.reply('❌ Ocurrió un error. Intenta nuevamente.');
    }
};

handler.help = ['mipene', 'toppenes'];
handler.tags = ['fun'];
handler.command = /^(mipene|toppenes)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;
