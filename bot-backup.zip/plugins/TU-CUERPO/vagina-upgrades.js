// Plugin: vagina-upgrades
// Clave en DB: vagina_upgrades (objeto solo creado cuando el usuario usa el comando)
// Comandos: .mivagina, .topvaginas, .chuparvagina

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

// ─────────────────────────────────────────────────────────────
// CLAVE EN DB — separada y clara, nunca inicializada por default
// ─────────────────────────────────────────────────────────────
const DB_KEY = 'vagina_upgrades';

function getVaginaData(userData) {
    return userData?.[DB_KEY] || null;
}

function getOrCreateVaginaData(userData) {
    if (!userData[DB_KEY]) {
        userData[DB_KEY] = { level: 0 };
    }
    return userData[DB_KEY];
}

// ─────────────────────────────────────────────────────────────
// FÓRMULAS
// ─────────────────────────────────────────────────────────────

// Costo de upgrade: misma escala que pene
function upgradeCost(level) {
    return Math.floor(2000 * Math.pow(1.42, level));
}

// "Tamaño" medido en apretamiento (escala inversa: empieza estrecha, se expande)
// Se representa como un valor de 1 a N; usamos "nivel de placer" en cm equivalente
function vaginaSize(level) {
    return (1 + level * 0.5).toFixed(1);
}

// ─────────────────────────────────────────────────────────────
// 30 RANGOS
// ─────────────────────────────────────────────────────────────
const RANGOS = [
    { min: 0,   nombre: '🌱 Capullo'          },
    { min: 2,   nombre: '🌸 Florecita'        },
    { min: 3,   nombre: '🌺 Flor'             },
    { min: 4,   nombre: '🍑 Melocotón'        },
    { min: 5,   nombre: '🫐 Mora'             },
    { min: 7,   nombre: '🍒 Cereza'           },
    { min: 9,   nombre: '🍓 Fresa'            },
    { min: 11,  nombre: '🥝 Kiwi'             },
    { min: 13,  nombre: '🍇 Uva'              },
    { min: 16,  nombre: '🌹 Rosa'             },
    { min: 19,  nombre: '🌊 Ola'              },
    { min: 22,  nombre: '🌙 Luna'             },
    { min: 26,  nombre: '💎 Diamante'         },
    { min: 30,  nombre: '🔮 Cristal'          },
    { min: 35,  nombre: '🌈 Arcoíris'         },
    { min: 40,  nombre: '⚡ Rayo'             },
    { min: 46,  nombre: '🌟 Estrella'         },
    { min: 52,  nombre: '🪄 Magia'            },
    { min: 59,  nombre: '🚀 Cohete'           },
    { min: 67,  nombre: '🌋 Volcán'           },
    { min: 76,  nombre: '🌪️ Tornado'          },
    { min: 86,  nombre: '☄️ Cometa'           },
    { min: 97,  nombre: '🌌 Nebulosa'         },
    { min: 109, nombre: '🛸 OVNI'             },
    { min: 122, nombre: '🌟 Supernova'        },
    { min: 136, nombre: '🪐 Planeta'          },
    { min: 151, nombre: '🌌 Galaxia'          },
    { min: 167, nombre: '🕳️ Agujero Negro'    },
    { min: 184, nombre: '✨ Singularidad'     },
    { min: 202, nombre: '∞ El Infinito'       },
];

function vaginaRank(cmStr) {
    const n = parseFloat(cmStr);
    let rango = RANGOS[0];
    for (const r of RANGOS) {
        if (n >= r.min) rango = r;
        else break;
    }
    return rango;
}

function nextRank(cmStr) {
    const n = parseFloat(cmStr);
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n < RANGOS[i + 1].min) {
            return { nombre: RANGOS[i + 1].nombre, cmNeeded: (RANGOS[i + 1].min - n).toFixed(1) };
        }
    }
    return null;
}

function progressBar(cmStr) {
    const n = parseFloat(cmStr);
    let from = 0, to = RANGOS[RANGOS.length - 1].min;
    for (let i = 0; i < RANGOS.length - 1; i++) {
        if (n >= RANGOS[i].min && n < RANGOS[i + 1].min) {
            from = RANGOS[i].min;
            to   = RANGOS[i + 1].min;
            break;
        }
    }
    const pct    = Math.min(1, to === from ? 1 : (n - from) / (to - from));
    const filled = Math.round(pct * 12);
    return '[' + '█'.repeat(filled) + '░'.repeat(12 - filled) + ']';
}

// ─────────────────────────────────────────────────────────────
// BUSCAR USUARIO POR MENCIÓN O APODO
// ─────────────────────────────────────────────────────────────
function findUserByMentionOrApodo(message, arg) {
    if (!arg) return null;

    const mentioned = message?.mentions || message?.mentionedJid || [];
    if (mentioned.length > 0) {
        const num = mentioned[0].split('@')[0].split(':')[0];
        const rawData = global.db.data.users?.[num];
        return rawData ? { number: num, data: rawData } : null;
    }

    const query = arg.replace(/^@/, '').trim().toLowerCase();
    if (!query) return null;

    let partial = null;
    for (const [key, u] of Object.entries(global.db.data.users || {})) {
        if (!u?.apodo) continue;
        const apodoLower = u.apodo.toLowerCase();
        if (apodoLower === query)
            return { number: key.split('@')[0].split(':')[0], data: u };
        if (!partial && apodoLower.includes(query))
            partial = { number: key.split('@')[0].split(':')[0], data: u };
    }
    return partial;
}

// ─────────────────────────────────────────────────────────────
// HANDLER
// ─────────────────────────────────────────────────────────────
let handler = async (message, { conn, args, usedPrefix, command }) => {
    try {
        if (!global.db?.data?.users)
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);

        // ══════════════════════════════════════════════════════
        // .mivagina
        // ══════════════════════════════════════════════════════
        if (/^mivagina$/i.test(command)) {

            // ── upgrade all ───────────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0]) && args[1] && /^all$/i.test(args[1])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                const vagina = getOrCreateVaginaData(user);

                const startLevel = vagina.level;
                let level      = startLevel;
                let moneyLeft  = user.money || 0;
                let totalSpent = 0;
                let upgrades   = 0;

                while (true) {
                    const cost = upgradeCost(level);
                    if (moneyLeft < cost) break;
                    moneyLeft -= cost;
                    totalSpent += cost;
                    level++;
                    upgrades++;
                }

                if (upgrades === 0) {
                    const cost = upgradeCost(startLevel);
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${(user.money || 0).toLocaleString()}*`
                    );
                }

                user.money        = moneyLeft;
                vagina.level      = level;
                user[DB_KEY]      = vagina;
                global.db.setUser(senderNumber, user);

                const cm       = vaginaSize(level);
                const rango    = vaginaRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(level);

                let txt =
                    `🚀 *¡UPGRADE MASIVO!*\n\n` +
                    `📈 Niveles: *${startLevel} → ${level}* (+${upgrades})\n` +
                    `✨ Poder: *${vaginaSize(startLevel)} → ${cm}*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${level}*\n\n` +
                    `💸 Gastado: *$${totalSpent.toLocaleString()}*\n` +
                    `💰 Saldo:   *$${moneyLeft.toLocaleString()}*\n\n`;
                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded}*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;
                return await message.reply(txt);
            }

            // ── upgrade (1 nivel) ─────────────────────────────
            if (args[0] && /^upgrade$/i.test(args[0])) {
                const user = global.db.getUser(senderNumber);
                if (!user) return await message.reply('❌ Usuario no encontrado.');
                const vagina = getOrCreateVaginaData(user);

                const level = vagina.level;
                const cost  = upgradeCost(level);
                const money = user.money || 0;

                if (money < cost) {
                    return await message.reply(
                        `❌ *No tienes suficiente dinero*\n\n` +
                        `💰 Necesitas: *$${cost.toLocaleString()}*\n` +
                        `💸 Tienes:    *$${money.toLocaleString()}*\n\n` +
                        `✨ Actual: *${vaginaSize(level)}* (Nivel ${level})\n` +
                        `📈 Con upgrade: *${vaginaSize(level + 1)}* (Nivel ${level + 1})`
                    );
                }

                user.money     = money - cost;
                vagina.level   = level + 1;
                user[DB_KEY]   = vagina;
                global.db.setUser(senderNumber, user);

                const newLevel = vagina.level;
                const cm       = vaginaSize(newLevel);
                const rango    = vaginaRank(cm);
                const next     = nextRank(cm);
                const nextCost = upgradeCost(newLevel);

                let txt =
                    `⬆️ *¡UPGRADE!*\n\n` +
                    `✨ *Nivel ${newLevel}* (+1)\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${newLevel}*\n\n` +
                    `💸 Gastaste: *$${cost.toLocaleString()}*\n` +
                    `💰 Saldo:    *$${user.money.toLocaleString()}*\n\n`;
                if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded}*)\n`;
                txt += `💡 Próximo upgrade: *$${nextCost.toLocaleString()}*`;
                return await message.reply(txt);
            }

            // ── ver info de otro usuario ──────────────────────
            if (args[0] && !/^upgrade$/i.test(args[0])) {
                const query  = args.join(' ');
                const target = findUserByMentionOrApodo(message, query);
                if (!target) return await message.reply(`❌ No se encontró el usuario *${query}*.`);

                const vagina = getVaginaData(target.data);
                const level  = vagina?.level ?? 0;
                const cm     = vaginaSize(level);
                const rango  = vaginaRank(cm);
                const apodo  = (target.data.apodo || '').trim() || target.number;

                return await message.reply(
                    `🌸 *Vagina de ${apodo}*\n\n` +
                    `✨ Poder: *${cm}*\n` +
                    `${progressBar(cm)}\n` +
                    `🏆 *${rango.nombre}*\n` +
                    `🔢 Nivel: *${level}*\n` +
                    `💦 Se la han chupado: *${vagina?.chupadoRecibido ?? 0}* veces\n` +
                    `👅 Ha chupado: *${vagina?.chupadoDado ?? 0}* veces`
                );
            }

            // ── info propia ───────────────────────────────────
            const rawUser  = global.db.data.users?.[senderNumber];
            const vagina   = getVaginaData(rawUser);
            const level    = vagina?.level ?? 0;
            const cm       = vaginaSize(level);
            const rango    = vaginaRank(cm);
            const next     = nextRank(cm);
            const nextCost = upgradeCost(level);
            const apodo    = (rawUser?.apodo || '').trim() || senderNumber;

            let txt =
                `🌸 *Tu Vagina — ${apodo}*\n\n` +
                `✨ Poder: *${cm}*\n` +
                `${progressBar(cm)}\n` +
                `🏆 *${rango.nombre}*\n` +
                `🔢 Nivel: *${level}*\n` +
                `💦 Te la han chupado: *${vagina?.chupadoRecibido ?? 0}* veces\n` +
                `👅 Has chupado: *${vagina?.chupadoDado ?? 0}* veces\n\n`;
            if (next) txt += `⬆️ Próximo rango: *${next.nombre}* (faltan *${next.cmNeeded}*)\n`;
            txt +=
                `\n💡 *Upgrade* (+1 nivel): *$${nextCost.toLocaleString()}*\n` +
                `   ↳ *${usedPrefix}mivagina upgrade*\n` +
                `   ↳ *${usedPrefix}mivagina upgrade all* (máximo posible)`;
            return await message.reply(txt);
        }

        // ══════════════════════════════════════════════════════
        // .topvaginas
        // ══════════════════════════════════════════════════════
        if (/^topvaginas$/i.test(command)) {
            const isGlobal = args[0] && /^(g|global)$/i.test(args[0]);

            if (!isGlobal && !message.isGroup)
                return await message.reply(`❌ Solo funciona en grupos.\n💡 Usa *${usedPrefix}topvaginas global* para el ranking mundial.`);

            const itemsPerPage = 10;
            const allUsers = [];

            if (isGlobal) {
                for (const [key, u] of Object.entries(global.db.data.users || {})) {
                    const vaginaData = u?.[DB_KEY];
                    if (!vaginaData) continue;
                    const level = Number(vaginaData.level) || 0;
                    if (level < 1) continue;
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((1 + level * 0.5).toFixed(1));
                    allUsers.push({ number: normalizeNumber(key), level, cm, apodo });
                }
            } else {
                const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);
                for (const p of participants) {
                    const num = normalizeNumber(p);
                    const u   = global.db.data.users?.[num];
                    if (!u) continue;
                    const vaginaData = u?.[DB_KEY];
                    if (!vaginaData) continue;
                    const level = Number(vaginaData.level) || 0;
                    if (level < 1) continue;
                    const apodoRaw = String(u.apodo || '').trim();
                    const apodo = (apodoRaw && apodoRaw.toLowerCase() !== 'sin apodo') ? apodoRaw : '👤 Sin Apodo';
                    const cm = parseFloat((1 + level * 0.5).toFixed(1));
                    allUsers.push({ number: num, level, cm, apodo });
                }
            }

            if (allUsers.length === 0)
                return await message.reply(`📊 Nadie en el ranking todavía.\n💡 Usa *${usedPrefix}mivagina upgrade* para empezar.`);

            allUsers.sort((a, b) => b.level - a.level);

            // Posición global del sender
            const globalAll = [];
            for (const [k, u] of Object.entries(global.db.data.users || {})) {
                const vd = u?.[DB_KEY];
                if (!vd) continue;
                const lv = Number(vd.level) || 0;
                if (lv < 1) continue;
                globalAll.push({ number: normalizeNumber(k), level: lv });
            }
            globalAll.sort((a, b) => b.level - a.level);
            const globalPos      = globalAll.findIndex(u => u.number === senderNumber) + 1;
            const globalTotal    = globalAll.length;
            const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;

            const totalPages = Math.max(1, Math.ceil(allUsers.length / itemsPerPage));
            const userIndex  = allUsers.findIndex(u => u.number === senderNumber);
            const userPos    = userIndex + 1;
            const userPage   = userPos > 0 ? Math.ceil(userPos / itemsPerPage) : 0;

            const pageArg = isGlobal ? args[1] : args[0];
            let page = 1;
            if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
            if (page > totalPages) page = totalPages;

            const start     = (page - 1) * itemsPerPage;
            const pageItems = allUsers.slice(start, start + itemsPerPage);

            let text = isGlobal
                ? `*🌍 TOP VAGINAS GLOBAL 🌸*\n\n`
                : `*🏆 TOP VAGINAS DEL GRUPO 🌸*\n\n`;

            if (!isGlobal) {
                text += `👥 *Grupo:* ${allUsers.length} en el ranking\n`;
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos. grupo:* #${userPos} — *${cu.apodo}* Nv.${cu.level} (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}topvaginas ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos. grupo:* No estás en el ranking\n`;
                }
                if (globalPos > 0) {
                    text += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                    text += `   ↳ *${usedPrefix}topvaginas global ${globalUserPage}*\n`;
                } else {
                    text += `🌐 *Tu pos. global:* No estás en el ranking\n`;
                }
            } else {
                text += `🌍 *Global:* ${globalTotal} en el ranking\n\n`;
                if (userPos > 0) {
                    const cu = allUsers[userIndex];
                    text += `📍 *Tu pos.:* #${userPos} — *${cu.apodo}* Nv.${cu.level} (Pág. ${userPage})\n`;
                    if (userPage !== page) text += `   ↳ *${usedPrefix}topvaginas global ${userPage}*\n`;
                } else {
                    text += `📍 *Tu pos.:* No estás en el ranking\n`;
                }
            }

            text += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

            if (totalPages > 1) {
                const modeArg = isGlobal ? ' global' : '';
                const prev    = page > 1 ? page - 1 : null;
                const next    = page < totalPages ? page + 1 : null;
                text += `\n`;
                if (prev) text += `⬅️ *${usedPrefix}topvaginas${modeArg} ${prev}* anterior\n`;
                if (next) text += `➡️ *${usedPrefix}topvaginas${modeArg} ${next}* siguiente\n`;
            }

            text += `\n`;

            for (let i = 0; i < pageItems.length; i++) {
                const u     = pageItems[i];
                const pos   = start + i + 1;
                const medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `${pos}.`;
                const rango = vaginaRank(u.cm);
                text += `${medal} *${u.apodo}*\n🌸 Nv.${u.level} · ${rango.nombre}\n\n`;
            }

            if (!isGlobal) text += `💡 _Usa *${usedPrefix}topvaginas global* para el top mundial_`;

            return await message.reply(text);
        }

        // ══════════════════════════════════════════════════════
        // .chuparvagina @user
        // ══════════════════════════════════════════════════════
        if (/^chuparvagina$/i.test(command)) {
            if (!message.isGroup)
                return await message.reply('❌ Este comando solo funciona en grupos.');

            // Cooldown: 1 uso cada 5 minutos por usuario
            const COOLDOWN_MS = 5 * 60 * 1000;
            const senderRaw   = global.db.data.users?.[senderNumber];
            const senderVag   = senderRaw?.[DB_KEY] || null;
            const lastChupar  = senderVag?.lastChupar || 0;
            const now         = Date.now();

            if (now - lastChupar < COOLDOWN_MS) {
                const secsLeft = Math.ceil((COOLDOWN_MS - (now - lastChupar)) / 1000);
                const mins     = Math.floor(secsLeft / 60);
                const secs     = secsLeft % 60;
                return await message.reply(
                    `⏳ Tranquila, déjala descansar.\n` +
                    `Podrás volver a chupar en *${mins}m ${secs}s*`
                );
            }

            // Buscar target
            const query  = args.join(' ');
            const target = findUserByMentionOrApodo(message, query);
            if (!target) return await message.reply('❌ Debes mencionar a alguien con @usuario.');

            // No puedes chuparte a ti mismo
            if (target.number === senderNumber)
                return await message.reply('🚫 No puedes chupártela tú misma, eso no vale.');

            // Aplicar +1 nivel al target
            const targetUser = global.db.getUser(target.number);
            if (!targetUser) return await message.reply('❌ Usuario no encontrado en la base de datos.');

            const targetVag = getOrCreateVaginaData(targetUser);
            targetVag.level           = (targetVag.level || 0) + 1;
            targetVag.chupadoRecibido = (targetVag.chupadoRecibido || 0) + 1;
            targetUser[DB_KEY]        = targetVag;
            global.db.setUser(target.number, targetUser);

            // Registrar en el sender: cooldown + chupadoDado
            const senderUser = global.db.getUser(senderNumber);
            const senderVagData = getOrCreateVaginaData(senderUser);
            senderVagData.lastChupar  = now;
            senderVagData.chupadoDado = (senderVagData.chupadoDado || 0) + 1;
            senderUser[DB_KEY]        = senderVagData;
            global.db.setUser(senderNumber, senderUser);

            const targetApodo = (target.data.apodo || '').trim() || target.number;
            const senderApodo = (senderRaw?.apodo || '').trim() || senderNumber;
            const newLevel    = targetVag.level;
            const newCm       = vaginaSize(newLevel);
            const newRango    = vaginaRank(newCm);

            return await message.reply(
                `👅 *${senderApodo}* le chupó la vagina a *${targetApodo}*\n\n` +
                `📈 *+1 nivel gratis!*\n` +
                `🔢 Nuevo nivel: *${newLevel}*\n` +
                `🏆 Rango: *${newRango.nombre}*\n\n` +
                `💦 Total de veces que se la han chupado: *${targetVag.chupadoRecibido}*\n` +
                `⏳ _Podrás volver a chupar en 5 minutos_`
            );
        }

    } catch (error) {
        console.error('[vagina-upgrades] Error:', error);
        return await message.reply('❌ Ocurrió un error. Intenta nuevamente.');
    }
};

handler.help = ['mivagina', 'topvaginas', 'chuparvagina'];
handler.tags = ['fun'];
handler.command = /^(mivagina|topvaginas|chuparvagina)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;
