const fs = require('fs')
const path = require('path')
const db = require('../../database.js')

const PAREJAS_FILE = path.join(__dirname, 'parejas.json')

function cargarParejas() {
    try {
        if (fs.existsSync(PAREJAS_FILE)) {
            return JSON.parse(
                fs.readFileSync(PAREJAS_FILE, 'utf8')
            )
        }
    } catch (e) {
        console.error(e)
    }

    return {}
}

let parejas = cargarParejas()

function guardarParejas() {
    fs.writeFileSync(
        PAREJAS_FILE,
        JSON.stringify(parejas, null, 2)
    )
}

// verifica si el usuario existe y tiene apodo válido
function usuarioValido(numero) {

    if (!numero) return false

    const user = db.data?.users?.[numero]

    if (!user) return false

    if (!user.apodo) return false

    if (typeof user.apodo !== 'string') return false

    const apodo = user.apodo.trim()

    if (
        apodo === '' ||
        apodo.toLowerCase() === 'sin apodo'
    ) {
        return false
    }

    return true
}

let handler = async (message) => {

    try {

        // recargar parejas por si cambiaron
        parejas = cargarParejas()

        let eliminadas = 0
        let revisadas = new Set()

        for (const [num, data] of Object.entries(parejas)) {

            if (!data || !data.numero) continue

            // evitar revisar la misma pareja 2 veces
            const pairId = [num, data.numero]
                .sort()
                .join('-')

            if (revisadas.has(pairId)) {
                continue
            }

            revisadas.add(pairId)

            const valido1 = usuarioValido(num)
            const valido2 = usuarioValido(data.numero)

            // si uno de los 2 no tiene apodo válido
            if (!valido1 || !valido2) {

                delete parejas[num]
                delete parejas[data.numero]

                eliminadas++
            }
        }

        guardarParejas()

        await message.reply(
            '🧹 *LIMPIEZA DE PAREJAS COMPLETADA*\n' +
            '━━━━━━━━━━━━━━━\n\n' +
            `💔 Parejas eliminadas: *${eliminadas}*\n\n` +
            '✅ Se eliminaron todas las parejas con usuarios sin apodo válido.'
        )

    } catch (error) {

        console.error('[CLEARPAREJAS ERROR]', error)

        await message.reply(
            '❌ Ocurrió un error al limpiar las parejas.'
        )
    }
}

handler.help = ['clearparejas']
handler.tags = ['owner']
handler.command = /^clearparejas$/i
handler.owner = true;

module.exports = handler