const fs = require('fs');
const path = require('path');
const db = require('../../database.js');
// Ruta del archivo para almacenar los datos de las parejas
const PAREJAS_FILE = path.join(__dirname, 'parejas.json');
let parejas = cargarParejas();

function cargarParejas() {
    try {
        if (fs.existsSync(PAREJAS_FILE)) {
            return JSON.parse(
                fs.readFileSync(PAREJAS_FILE, 'utf8')
            );
        }
    } catch (e) {
        console.error(e);
    }

    return {};
}

// Función para guardar los datos
function guardarParejas() {
    fs.writeFileSync(PAREJAS_FILE, JSON.stringify(parejas, null, 2));
}

// Función para calcular el tiempo transcurrido
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const inicio = new Date(fecha);
    const diferencia = ahora - inicio;

    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));

    return { dias, horas, minutos };
}

// Función para formatear la fecha
function formatearFecha(fecha) {
    const d = new Date(fecha);
    return d.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric'
    });
}

// ==========================================
// FUNCIONES AUXILIARES PARA APODOS
// ==========================================
function getApodo(numero) {
    if (!numero) return null;

    // Intentar con número limpio
    let user =
        db.data?.users?.[numero] ||

        // Intentar con jid completo
        db.data?.users?.[`${numero}@s.whatsapp.net`] ||

        // Intentar buscando manualmente
        Object.entries(db.data?.users || {}).find(([id]) =>
            id.startsWith(numero)
        )?.[1];

    if (!user) return null;

    const apodo = String(user.apodo || '').trim();

    // Filtrar apodos inválidos
    if (
        !apodo ||
        apodo.toLowerCase() === 'sin apodo' ||
        apodo === '.' ||
        apodo === '-'
    ) {
        return null;
    }

    return apodo;
}

function getNumeroPorApodo(apodoBuscado) {
    if (!apodoBuscado) return null;

    const users = db.data?.users || {};
    const buscar = apodoBuscado.trim().toLowerCase();

    for (const [id, user] of Object.entries(users)) {
        const apodo = String(user?.apodo || '').trim().toLowerCase();
        if (
            apodo &&
            apodo !== 'sin apodo' &&
            apodo !== '.' &&
            apodo !== '-' &&
            apodo === buscar
        ) {
            // Devolver solo el número limpio (sin @s.whatsapp.net)
            return id.split('@')[0];
        }
    }

    return null;
}

let handler = async (message, { text, command }) => {
    try {
        // Obtener el JID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        const miApodo = getApodo(senderNumber);

        // Si el usuario usa el comando para ver la lista de parejas (el comando termina en 's')
        if (command.toLowerCase() === 'parejas') {
            let listaUnica = [];
            let seen = new Set();

            // Recopilar parejas activas sin duplicados
            for (let [num, data] of Object.entries(parejas)) {
                if (data.estado === 'aceptado') {
                    // Crear un ID único para la pareja ordenando sus números
                    let pairId = [num, data.numero].sort().join('-');
                    if (!seen.has(pairId)) {
                        seen.add(pairId);
                        listaUnica.push({
                            num1: num,
                            num2: data.numero,
                            fecha: data.fecha
                        });
                    }
                }
            }

            // Ordenar por antigüedad (los más antiguos primero)
            listaUnica.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());

            let listaTexto = '🏆 *RANKING DE PAREJAS* 🏆\n━━━━━━━━━━━━━━━\n\n';
            if (listaUnica.length === 0) {
                listaTexto += '_No hay ninguna pareja registrada actualmente._ 💔';
            } else {
                listaUnica.forEach((p, index) => {
                    const apodo1 = getApodo(p.num1) || "Desconocido";
                    const apodo2 = getApodo(p.num2) || "Desconocido";
                    const tiempo = tiempoTranscurrido(p.fecha);
                    
                    listaTexto += `*${index + 1}.* 💖 *${apodo1}* y *${apodo2}*\n`;
                    listaTexto += `   ⏳ _${tiempo.dias} días, ${tiempo.horas} hs, ${tiempo.minutos} min_\n\n`;
                });
            }
            return await message.reply(listaTexto);
        }

        // Dividir los argumentos (ej: ["pedir", "ElPro"])
        const args = text ? text.trim().split(/\s+/) : [];
        const action = args[0] ? args[0].toLowerCase() : '';
        const targetString = args.slice(1).join(' ').replace('@', ''); // Remover @ por si lo escriben a mano

        // Lógica para detectar si se mencionó o si se escribió un apodo
        let targetNumero = null;
        let targetJid = null;

        if (message?.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
            targetNumero = targetJid.split('@')[0];
        } else if (targetString) {
            targetNumero = getNumeroPorApodo(targetString);
            if (targetNumero) {
                targetJid = `${targetNumero}@s.whatsapp.net`;
            }
        }

        // Acción: Ver mi estado
        if (!action) {
            if (!parejas[senderNumber]) {
                return await message.reply('💔 *No tienes pareja actualmente*\n\n_Usa .pareja pedir [Apodo/@usuario] para pedir noviazgo_\n_O usa .pareja solicitudes para ver peticiones_');
            }

            const pareja = parejas[senderNumber];
            const parejaApodo = getApodo(pareja.numero) || "Desconocido";
            
            // Si hay una petición enviada pendiente
            if (pareja.estado === 'pendiente') {
                return await message.reply(
                    '💌 *PETICIÓN PENDIENTE* 💌\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `*Has enviado una petición de noviazgo a:* ${parejaApodo}\n` +
                    `*Enviada el:* ${formatearFecha(pareja.fecha)}\n\n` +
                    '_Esperando respuesta..._ ⏳\n' +
                    '_Puedes cancelar la petición con:_\n' +
                    `*.pareja cancelar*`
                );
            }

            // Si la relación está establecida
            const tiempo = tiempoTranscurrido(pareja.fecha);
            return await message.reply(
                '❤️ *INFORMACIÓN DE TU PAREJA* ❤️\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*Tu pareja:* ${parejaApodo}\n` +
                `*Fecha de inicio:* ${formatearFecha(pareja.fecha)}\n` +
                `*Tiempo juntos:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n\n` +
                '_El amor está en el aire_ 💕'
            );
        }

        // Acción: Ver solicitudes entrantes
        if (action === 'solicitudes') {
            let misSolicitudes = [];
            for (let [num, data] of Object.entries(parejas)) {
                if (data.numero === senderNumber && data.estado === 'pendiente') {
                    misSolicitudes.push(num);
                }
            }

            if (misSolicitudes.length === 0) {
                return await message.reply('📭 *Buzón vacío*\n\n_No tienes ninguna petición de noviazgo pendiente._');
            }

            let textoSolicitudes = '💌 *TUS SOLICITUDES DE NOVIAZGO* 💌\n━━━━━━━━━━━━━━━\n\n';
            misSolicitudes.forEach(num => {
                const apodoSol = getApodo(num) || "Usuario sin apodo";
                textoSolicitudes += `👉 *${apodoSol}* quiere ser tu pareja.\n`;
            });
            textoSolicitudes += '\n_Para responder usa:_\n*.pareja aceptar [Apodo]* o *.pareja rechazar [Apodo]*';
            
            return await message.reply(textoSolicitudes);
        }

        // ==========================================
        // VALIDACIÓN CRÍTICA DE APODOS PARA INTERACTUAR
        // ==========================================
        if (['pedir', 'aceptar', 'rechazar'].includes(action)) {
            if (!miApodo) {
                return await message.reply('❌ *NECESITAS UN APODO* ❌\n\n_Para usar el sistema de parejas primero debes asignarte un apodo._\n💡 _Usa: .apodo [tu_apodo]_');
            }
            if (!targetNumero) {
                return await message.reply('❌ *Usuario no encontrado*\n\n_Debes mencionar a un usuario o escribir su apodo exacto._\n_Ejemplo: .pareja pedir @usuario O .pareja pedir SuApodo_');
            }
            
            const targetApodo = getApodo(targetNumero);
            if (!targetApodo) {
                return await message.reply('❌ *LA OTRA PERSONA NO TIENE APODO* ❌\n\n_Ambos usuarios deben tener un apodo registrado para ser pareja._');
            }
        }

        // Acción: Pedir noviazgo
        if (action === 'pedir') {
            const targetApodo = getApodo(targetNumero);

            if (parejas[senderNumber]) {
                if (parejas[senderNumber].estado === 'pendiente') {
                    const pendApodo = getApodo(parejas[senderNumber].numero) || "alguien";
                    return await message.reply(
                        '❌ *Ya tienes una petición enviada*\n\n' +
                        `_Tienes una petición pendiente dirigida a *${pendApodo}*_\n` +
                        '_Espera su respuesta o cancélala usando:_ *.pareja cancelar*'
                    );
                } else {
                    return await message.reply('❌ *Ya tienes pareja*\n\n_Debes terminar tu relación actual antes de empezar otra._');
                }
            }

            if (targetNumero === senderNumber) {
                return await message.reply('❌ *No puedes pedirte noviazgo a ti mismo*\n\n_Busca el amor en otros_ 💕');
            }

            // Verificar si la persona objetivo ya tiene pareja aceptada
            if (parejas[targetNumero] && parejas[targetNumero].estado === 'aceptado') {
                return await message.reply('❌ *Esa persona ya tiene pareja*\n\n_No seas rompe hogares_ 💔');
            }

            // Guardar la propuesta pendiente
            parejas[senderNumber] = {
                numero: targetNumero,
                jid: targetJid,
                estado: 'pendiente',
                fecha: new Date().toISOString()
            };
            guardarParejas();

            return await message.reply(
                '💝 *NUEVA PETICIÓN DE NOVIAZGO* 💝\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `😲 *¡${miApodo}* _le está pidiendo noviazgo a_ *${targetApodo}!*\n\n` +
                '_Para responder usa:_\n' +
                `*.pareja aceptar ${miApodo}* - _Para aceptar_\n` +
                `*.pareja rechazar ${miApodo}* - _Para rechazar_\n`
            );
        }

        // Acción: Aceptar noviazgo
        if (action === 'aceptar') {
            const pretendienteApodo = getApodo(targetNumero);

            // Verificar si el remitente ya tiene pareja establecida
            if (parejas[senderNumber] && parejas[senderNumber].estado === 'aceptado') {
                return await message.reply('❌ *Ya tienes pareja*\n\n_Debes terminar tu relación actual antes de aceptar a otra persona._');
            }

            // Verificar si existe la propuesta hacia mí
            if (!parejas[targetNumero] || parejas[targetNumero].numero !== senderNumber || parejas[targetNumero].estado !== 'pendiente') {
                return await message.reply(`❌ *No hay ninguna petición pendiente de ${pretendienteApodo}*`);
            }

            // Actualizar estado de la relación
            const fechaInicio = new Date().toISOString();
            parejas[targetNumero] = {
                numero: senderNumber,
                jid: senderJid,
                estado: 'aceptado',
                fecha: fechaInicio
            };
            parejas[senderNumber] = {
                numero: targetNumero,
                jid: targetJid,
                estado: 'aceptado',
                fecha: fechaInicio
            };
            
            // LIMPIEZA: Eliminar cualquier OTRA solicitud que me hayan enviado
            for (let [k, v] of Object.entries(parejas)) {
                if (v.numero === senderNumber && v.estado === 'pendiente' && k !== targetNumero) {
                    delete parejas[k];
                }
            }

            guardarParejas();

            return await message.reply(
                '💖 *¡NUEVO NOVIAZGO!* 💖\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*¡${miApodo} y ${pretendienteApodo} ahora son pareja!*\n\n` +
                '_Que el amor florezca entre ustedes_ 🌹\n' +
                '_Usen .pareja para ver su información como pareja_'
            );
        }

        // Acción: Rechazar noviazgo
        if (action === 'rechazar') {
            const pretendienteApodo = getApodo(targetNumero);

            // Verificar si existe la propuesta hacia mí
            if (!parejas[targetNumero] || parejas[targetNumero].numero !== senderNumber || parejas[targetNumero].estado !== 'pendiente') {
                return await message.reply(`❌ *No hay ninguna petición pendiente de ${pretendienteApodo}*`);
            }

            // Eliminar la propuesta
            delete parejas[targetNumero];
            guardarParejas();

            return await message.reply(
                '💔 *PETICIÓN RECHAZADA* 💔\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*${miApodo}* _ha rechazado la petición de_ *${pretendienteApodo}*\n\n` +
                '_No te desanimes, hay más personas en el mundo_ 🌟'
            );
        }

        // Acción: Cancelar petición enviada
        if (action === 'cancelar') {
            if (!parejas[senderNumber] || parejas[senderNumber].estado !== 'pendiente') {
                return await message.reply('❌ *No tienes ninguna petición enviada pendiente*\n\n_No hay nada que cancelar._');
            }

            const parejaCanceladoApodo = getApodo(parejas[senderNumber].numero) || "alguien";

            // Eliminar la petición
            delete parejas[senderNumber];
            guardarParejas();

            return await message.reply(
                '💫 *PETICIÓN CANCELADA* 💫\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*${miApodo}* _ha cancelado su petición de noviazgo hacia_ *${parejaCanceladoApodo}*\n\n` +
                '_A veces es mejor pensarlo dos veces_ 🤔'
            );
        }

        // Acción: Romper relación
        if (action === 'romper') {
            if (!parejas[senderNumber] || parejas[senderNumber].estado !== 'aceptado') {
                return await message.reply('❌ *No tienes una relación establecida*\n\n_No puedes terminar una relación que no existe._');
            }

            const parejaRomper = parejas[senderNumber].numero;
            const exApodo = getApodo(parejaRomper) || "Usuario";
            const tiempo = tiempoTranscurrido(parejas[senderNumber].fecha);

            // Eliminar la relación de ambos usuarios
            delete parejas[senderNumber];
            delete parejas[parejaRomper];
            guardarParejas();

            return await message.reply(
                '💔 *FIN DE LA RELACIÓN* 💔\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*${miApodo}* _ha terminado su relación con_ *${exApodo}*\n\n` +
                `*La relación duró:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n\n` +
                '_A veces el amor no es para siempre, pero siempre hay nuevas oportunidades_ 🌟'
            );
        }

        // Menú de ayuda por defecto si se ingresa un comando inválido
        return await message.reply(
            '*❤️ COMANDOS DE PAREJA ❤️*\n' +
            '━━━━━━━━━━━━━━━\n\n' +
            '*.pareja* - _Ver información de tu pareja_\n' +
            '*.parejas* - _Ver ranking top de todas las parejas_\n' +
            '*.pareja solicitudes* - _Ver quién te ha pedido noviazgo_\n' +
            '*.pareja pedir [Apodo/@user]* - _Pedir noviazgo_\n' +
            '*.pareja aceptar [Apodo/@user]* - _Aceptar petición_\n' +
            '*.pareja rechazar [Apodo/@user]* - _Rechazar petición_\n' +
            '*.pareja cancelar* - _Cancelar tu petición pendiente_\n' +
            '*.pareja romper* - _Terminar tu relación actual_\n\n' +
            '⚠️ _Nota: Es obligatorio tener apodo para usar estos comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de parejas:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['pareja', 'parejas', 'pareja pedir [Apodo]', 'pareja aceptar [Apodo]', 'pareja rechazar', 'pareja solicitudes', 'pareja cancelar', 'pareja romper'];
handler.tags = ['parejas'];
handler.command = /^(pareja|parejas)$/i;

module.exports = handler;