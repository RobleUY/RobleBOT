const fs = require('fs');
const path = require('path');

// Ruta del archivo para almacenar los datos de las parejas
const PAREJAS_FILE = path.join(__dirname, 'parejas.json');

// Cargar datos existentes o crear nuevo archivo
let parejas = {};
try {
    parejas = JSON.parse(fs.readFileSync(PAREJAS_FILE, 'utf8'));
} catch (error) {
    // Si el archivo no existe, se creará al guardar
    parejas = {};
}

// Función para guardar los datos
function guardarParejas() {
    fs.writeFileSync(PAREJAS_FILE, JSON.stringify(parejas, null, 2));
}

// Función para calcular el tiempo transcurrido
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const inicio = new Date(fecha);
    const diferencia = ahora - inicio;

    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));

    return { dias, horas, minutos };
}

// Función para formatear la fecha
function formatearFecha(fecha) {
    const d = new Date(fecha);
    return d.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric'
    });
}

let handler = async (message, { text, command }) => {
    try {
        // Obtener el JID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];

        // Si no hay texto, mostrar información de la pareja actual
        if (!text) {
            if (!parejas[senderNumber]) {
                return await message.reply('💔 *No tienes pareja actualmente*\n\n_Usa /pareja pedir @usuario para pedir noviazgo_');
            }

            const pareja = parejas[senderNumber];
            
            // Si hay una petición pendiente, mostrar estado de la petición
            if (pareja.estado === 'pendiente') {
                return await message.reply(
                    '💌 *PETICIÓN PENDIENTE* 💌\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `*Has enviado una petición de noviazgo a:* @${pareja.numero}\n` +
                    `*Enviada el:* ${formatearFecha(pareja.fecha)}\n\n` +
                    '_Esperando respuesta..._ ⏳\n' +
                    '_Puedes cancelar la petición con:_\n' +
                    `*.pareja cancelar*`,
                    { mentions: [pareja.jid] }
                );
            }

            // Si la relación está establecida, mostrar información normal
            const tiempo = tiempoTranscurrido(pareja.fecha);
            return await message.reply(
                '❤️ *INFORMACIÓN DE TU PAREJA* ❤️\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*Tu pareja:* @${pareja.numero}\n` +
                `*Fecha de inicio:* ${formatearFecha(pareja.fecha)}\n` +
                `*Tiempo juntos:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n\n` +
                '_El amor está en el aire_ 💕',
                { mentions: [pareja.jid] }
            );
        }

        // Obtener menciones del objeto message
        const mentionedJids = message?.mentions;

        // Procesar comando para pedir noviazgo
        if (text.startsWith('pedir')) {
            // Verificar si ya tiene pareja o una petición pendiente
            if (parejas[senderNumber]) {
                if (parejas[senderNumber].estado === 'pendiente') {
                    return await message.reply(
                        '❌ *Ya tienes una petición pendiente*\n\n' +
                        `_Tienes una petición pendiente para @${parejas[senderNumber].numero}_\n` +
                        '_Debes esperar una respuesta o cancelar tu petición actual usando:_\n' +
                        `/pareja cancelar`,
                        { mentions: [parejas[senderNumber].jid] }
                    );
                } else {
                    return await message.reply('❌ *Ya tienes pareja*\n\n_Debes terminar tu relación actual antes de empezar otra_');
                }
            }

            // Verificar si hay menciones
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar a un usuario. Ejemplo: .pareja pedir @usuario_');
            }

            const parejaPropuestaJid = mentionedJids[0];
            const parejaPropuesta = parejaPropuestaJid.split('@')[0];

            // Verificar que no se pida a sí mismo
            if (parejaPropuesta === senderNumber) {
                return await message.reply('❌ *No puedes pedirte noviazgo a ti mismo*\n\n_Busca el amor en otros_ 💕');
            }

            // Verificar si la persona ya tiene pareja o tiene una petición pendiente
            if (parejas[parejaPropuesta]) {
                if (parejas[parejaPropuesta].estado === 'aceptado') {
                    return await message.reply('❌ *Esa persona ya tiene pareja*\n\n_No seas rompe hogares_ 💔');
                } else {
                    return await message.reply('❌ *Esa persona tiene una petición pendiente*\n\n_Espera a que resuelva su situación actual_ 💭');
                }
            }

            // Verificar si ya tiene una petición pendiente de otro usuario
            for (let [numero, datos] of Object.entries(parejas)) {
                if (datos.numero === parejaPropuesta && datos.estado === 'pendiente') {
                    return await message.reply('❌ *Esa persona tiene una petición pendiente de otro usuario*\n\n_Espera a que resuelva su situación actual_ 💭');
                }
            }

            // Guardar la propuesta pendiente
            parejas[senderNumber] = {
                numero: parejaPropuesta,
                jid: parejaPropuestaJid,
                estado: 'pendiente',
                fecha: new Date().toISOString()
            };
            guardarParejas();

            let mentions = [
                parejaPropuestaJid,
                senderJid
            ];
            return await message.reply(
                '💝 *PETICIÓN DE NOVIAZGO* 💝\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `😲 *¡@${senderNumber}* _le está pidiendo noviazgo a_ *@${parejaPropuesta}!*\n\n` +
                '_Para responder usa:_\n' +
                `/pareja aceptar @${senderNumber} - _Para aceptar_\n` +
                `/pareja rechazar @${senderNumber} - _Para aceptar_\n` +
                `/pareja cancelar - _Para cancelar_`,
                { mentions }
            );
        }

        // Procesar aceptación de noviazgo
        if (text.startsWith('aceptar')) {
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar a un usuario. Ejemplo: .pareja aceptar @usuario_');
            }

            const pretendienteJid = mentionedJids[0];
            const pretendiente = pretendienteJid.split('@')[0];

            // Verificar si existe la propuesta
            if (!parejas[pretendiente] || parejas[pretendiente].numero !== senderNumber) {
                return await message.reply('❌ *No hay ninguna petición de noviazgo pendiente de esa persona*');
            }

            // Actualizar estado de la relación
            const fechaInicio = new Date().toISOString();
            parejas[pretendiente] = {
                numero: senderNumber,
                jid: senderJid,
                estado: 'aceptado',
                fecha: fechaInicio
            };
            parejas[senderNumber] = {
                numero: pretendiente,
                jid: pretendienteJid,
                estado: 'aceptado',
                fecha: fechaInicio
            };
            guardarParejas();

            let mentions = [
                senderJid,
                pretendienteJid
            ];
            return await message.reply(
                '💖 *¡NUEVO NOVIAZGO!* 💖\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*¡@${senderNumber} y @${pretendiente} ahora son pareja!*\n\n` +
                '_Que el amor florezca entre ustedes_ 🌹\n' +
                '_Usen /pareja para ver su información como pareja_',
                { mentions }
            );
        }

        // Procesar rechazo de noviazgo
        if (text.startsWith('rechazar')) {
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar a un usuario. Ejemplo: .pareja rechazar @usuario_');
            }

            const pretendienteJid = mentionedJids[0];
            const pretendiente = pretendienteJid.split('@')[0];

            // Verificar si existe la propuesta
            if (!parejas[pretendiente] || parejas[pretendiente].numero !== senderNumber) {
                return await message.reply('❌ *No hay ninguna petición de noviazgo pendiente de esa persona*');
            }

            // Eliminar la propuesta
            delete parejas[pretendiente];
            guardarParejas();

            let mentions = [
                senderJid,
                pretendienteJid
            ];
            return await message.reply(
                '💔 *PETICIÓN RECHAZADA* 💔\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha rechazado la petición de_ *@${pretendiente}*\n\n` +
                '_No te desanimes, hay más personas en el mundo_ 🌟',
                { mentions }
            );
        }

        // Procesar cancelación de petición
        if (text.startsWith('cancelar')) {
            // Verificar si tienes una petición pendiente
            if (!parejas[senderNumber] || parejas[senderNumber].estado !== 'pendiente') {
                return await message.reply('❌ *No tienes ninguna petición pendiente*\n\n_No hay nada que cancelar_');
            }

            const parejaCancelado = parejas[senderNumber].numero;
            const parejaCancelJid = parejas[senderNumber].jid;

            // Eliminar la petición
            delete parejas[senderNumber];
            guardarParejas();

            let mentions = [
                senderJid,
                parejaCancelJid
            ];
            return await message.reply(
                '💫 *PETICIÓN CANCELADA* 💫\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha cancelado su petición de noviazgo hacia_ *@${parejaCancelado}*\n\n` +
                '_A veces es mejor pensarlo dos veces_ 🤔',
                { mentions }
            );
        }

        // Procesar ruptura de relación
        if (text.startsWith('romper')) {
            // Verificar si tienes pareja
            if (!parejas[senderNumber]) {
                return await message.reply('❌ *No tienes pareja actualmente*\n\n_No puedes terminar una relación que no existe_');
            }

            // Verificar que sea una relación aceptada
            if (parejas[senderNumber].estado !== 'aceptado') {
                return await message.reply('❌ *No tienes una relación establecida*\n\n_Solo puedes romper relaciones confirmadas_');
            }

            const parejaRomper = parejas[senderNumber].numero;
            const parejaRomperJid = parejas[senderNumber].jid;

            // Calcular el tiempo que duró la relación
            const tiempo = tiempoTranscurrido(parejas[senderNumber].fecha);

            // Eliminar la relación de ambos usuarios
            delete parejas[senderNumber];
            delete parejas[parejaRomper];
            guardarParejas();

            let mentions = [
                senderJid,
                parejaRomperJid
            ];
            return await message.reply(
                '💔 *FIN DE LA RELACIÓN* 💔\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _ha terminado su relación con_ *@${parejaRomper}*\n\n` +
                `*La relación duró:* ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n\n` +
                '_A veces el amor no es para siempre, pero siempre hay nuevas oportunidades_ 🌟',
                { mentions }
            );
        }

        // Si el comando no coincide con ninguno de los anteriores
        return await message.reply(
            '*❤️ COMANDOS DE PAREJA ❤️*\n' +
            '━━━━━━━━━━━━━━━\n\n' +
            '/pareja - _Ver información de tu pareja_\n' +
            '/pareja pedir @usuario - _Pedir noviazgo_\n' +
            '/pareja aceptar @usuario - _Aceptar petición_\n' +
            '/pareja rechazar @usuario - _Rechazar petición_\n' +
            '/pareja cancelar - _Cancelar tu petición pendiente_\n' +
            '/pareja romper - _Terminar tu relación_'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de parejas:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['pareja', 'pareja pedir @usuario', 'pareja aceptar @usuario', 'pareja rechazar @usuario', 'pareja cancelar', 'pareja romper'];
handler.tags = ['parejas'];
handler.command = /^(pareja)$/i;

module.exports = handler;