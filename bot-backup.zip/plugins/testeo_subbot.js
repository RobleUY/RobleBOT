'use strict';
const { 
    default: makeWASocket, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore,
    DisconnectReason 
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./SUBBOTS/singleFileAuthState'); 
const P = require('pino');
const path = require('path');
const fs = require('fs');

let handler = async (message) => {
    try {
        const key = message.key || {};
        const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid;
        const numeroReal = jidReal ? jidReal.split('@')[0] : null;

        if (!numeroReal) return await message.reply('❌ No pude detectar tu número.');

        const SESSIONS_DIR = path.join(__dirname, 'SUBBOTS', 'sesiones');
        if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
        const sessionPath = path.join(SESSIONS_DIR, 'testeo_subbot.db');

        // IMPORTANTE: Si ya existe una sesión, bórrala o el bot no pedirá código nuevo
        if (fs.existsSync(sessionPath)) {
            return await message.reply('⚠️ Ya hay una sesión vinculada. Borra el archivo `SUBBOTS/sesiones/testeo_subbot.db` para generar un código nuevo.');
        }

        await message.reply(`⏳ Iniciando motor para: ${numeroReal}...`);

        const { state, saveCreds } = await useSQLiteAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        const conn = makeWASocket({
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' })),
            },
            version,
            browser: ['Ubuntu', 'Chrome', '20.0.0']
        });

        conn.ev.on('creds.update', saveCreds);

        // AQUÍ ESTÁ LA MAGIA: Reaccionamos al estado de conexión como lo hace tu subbot principal
        conn.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'open') {
                try {
                    const code = await conn.requestPairingCode(numeroReal);
                    await message.reply(`✅ *Código de 8 dígitos:* *${code}*\n\n_Vincúlalo ahora en WhatsApp._`);
                } catch (e) {
                    console.error('Error al solicitar código:', e);
                }
            } else if (connection === 'close') {
                const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
                if (shouldReconnect) {
                    console.log('🔄 Conexión perdida, intentando reconectar...');
                }
            }
        });

    } catch (e) {
        console.error(e);
        await message.reply('❌ Error: ' + e.message);
    }
};

handler.command = /^testcode33$/i;
module.exports = handler;