const command = /^(listsubbots|listasubbots)$/i;
const help = 'Muestra los sub-bots activos con su apodo';
const tags = ['subbots'];

async function handler(message, { conn }) {
    const subConns = Array.isArray(global.subConns) ? global.subConns : [];
    const activeSubbots = subConns.filter(sub => sub && sub.user);

    if (activeSubbots.length === 0) {
        return await message.reply('No hay sub-bots activos en este momento.');
    }

    const rows = activeSubbots
        .sort((a, b) => (a._subNum || 0) - (b._subNum || 0))
        .map(sub => {
            const phoneNumber = sub.user?.id?.split('@')[0]?.split(':')[0] || 'sin-numero';
            const userData = global.db?.getUser?.(phoneNumber);
            
            const apodoRaw = (userData?.apodo || '').trim();
            const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                ? '👤 Sin Apodo'
                : apodoRaw;
            
            return `• ${apodo}\n  📱 wa.me/+${phoneNumber}`;
        });

    const text = `📋 Sub-bots activos:\n\n${rows.join('\n\n')}`;
    await message.reply(text);
}

module.exports = { command, help, tags, handler };
