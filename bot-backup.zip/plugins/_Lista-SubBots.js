const command = /^(listsubbots|listasubbots)$/i;
const help = 'Lista de sub-bots activos';
const tags = ['subbots'];

async function handler(message, { conn }) {
    const subConns = Array.isArray(global.subConns) ? global.subConns : [];
    const activeSubbots = subConns.filter(sub => sub?.user);
    const mainNumber = conn?.user?.id?.split('@')[0]?.split(':')[0] || '?';
    const mainName = conn?.user?.name || 'Bot Principal';

    let text = `*Bot Principal*\n📱 +${mainNumber}\n\n`;
    text += `━━━━━━━━━━━━━━━━━\n`;
    text += `📊 *Sub-bots:* ${activeSubbots.length}\n\n`;

    if (activeSubbots.length > 0) {
        activeSubbots
            .sort((a, b) => (a._subNum || 0) - (b._subNum || 0))
            .forEach(sub => {
                const phoneNumber = sub.user?.id?.split('@')[0]?.split(':')[0] || '?';
                const nombre = sub.user?.name || 'Sin nombre';
                text += `• ${nombre}\n📱 +${phoneNumber}\n\n`;
            });
    } else {
        text += `_Sin sub-bots activos_`;
    }

    await message.reply(text);
}

module.exports = { command, help, tags, handler };
