const fs = require('fs');
const path = require('path');
const botConfig = require('../config');

const dataFilePath = path.join(__dirname, '..', 'data', 'comandos.json');
const PREFIXES = ['.', '/', '❤️', '#', '👅', '😎'];
const RESERVED_COMMANDS = ['addcmd', 'mycmds', 'delcmd', 'cmds'];
const MAX_COMMANDS_PER_USER = 10;

function ensureDataFile() {
    const dir = path.dirname(dataFilePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(dataFilePath)) {
        fs.writeFileSync(dataFilePath, JSON.stringify({ commands: {} }, null, 2));
    }
}

function loadStore() {
    try {
        ensureDataFile();
        const raw = fs.readFileSync(dataFilePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') return { commands: {} };
        if (!parsed.commands || typeof parsed.commands !== 'object') parsed.commands = {};
        return parsed;
    } catch (error) {
        console.error('[comandos-personalizados] Error cargando comandos:', error.message);
        return { commands: {} };
    }
}

function saveStore(store) {
    try {
        ensureDataFile();
        fs.writeFileSync(dataFilePath, JSON.stringify(store, null, 2));
    } catch (error) {
        console.error('[comandos-personalizados] Error guardando comandos:', error.message);
    }
}

function normalizeCommandName(raw) {
    if (!raw || typeof raw !== 'string') return '';
    return raw.trim().replace(/^[^a-zA-Z0-9]+/, '').toLowerCase();
}

function isValidCommandName(name) {
    return /^[a-z0-9_]+$/i.test(name);
}

function normalizeTemplate(template) {
    return (template || '').trim();
}

function templateLengthOk(template) {
    const stripped = template.replace(/@yo|@text|@random|@randomUser/gi, '').trim();
    return stripped.length <= 100;
}

function getCreatorKey(message) {
    const author = message.author || message.sender || message.key?.participant || message.key?.remoteJid;
    if (!author) return null;
    return author.toString().split('@')[0].replace(/\D/g, '');
}

function getSenderJid(message) {
    return message.key?.participant || message.author;
}


function getMentionJids(message) {
    if (!message) return [];
    return message.mentions || message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

function hasOfficialCommand(commandName) {
    const handler = global.commandHandler;
    if (!handler || !handler.commands) return false;

    if (handler.commands.has(commandName)) {
        return true;
    }

    for (const [cmdKey] of handler.commands) {
        if (cmdKey instanceof RegExp && cmdKey.test(commandName)) {
            return true;
        }
    }

    return false;
}

function formatCommandName(name) {
    return name.startsWith('.') ? name : `.${name}`;
}

function getCreatorDisplayName(creator) {
    if (!creator) return 'Sin apodo';
    try {
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(String(creator));
            const apodo = user?.apodo?.toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') {
                return apodo;
            }
        }
    } catch (e) {
        // Ignorar errores de DB y usar el fallback.
    }
    return 'Sin apodo';
}

async function getRandomGroupUser(conn, groupId, senderJid) {
    try {
        const metadata = await conn.groupMetadata(groupId);
        if (!metadata || !metadata.participants || metadata.participants.length === 0) {
            return null;
        }

        const participants = metadata.participants
            .map(p => p.id)
            .filter(jid => jid !== senderJid);

        if (participants.length === 0) {
            return null;
        }

        const randomIndex = Math.floor(Math.random() * participants.length);
        const randomJid = participants[randomIndex];
        const randomNumber = randomJid.split('@')[0].split(':')[0];

        return { jid: randomJid, number: randomNumber };
    } catch (error) {
        console.error('[comandos-personalizados] Error obteniendo usuario random:', error.message);
        return null;
    }
}


async function handleAddCmd(message, { args, text }) {
    if (!args || args.length < 2) {
        return await message.reply(
            '⚠️ Uso correcto:\n.addcmd .nombre delcomando @yo hace algo con @text\n\n' +
            'Variables disponibles:\n' +
            '• @yo = tu mención\n' +
            '• @text = mención o texto que escribes\n' +
            '• @random = número aleatorio 1-100\n' +
            '• @randomUser = usuario aleatorio del grupo\n\n' +
            'Ejemplos:\n' +
            '.addcmd .suerte La suerte de @text es @random%\n' +
            '.addcmd .sorpresa @yo sorprende a @randomUser 🎉'
        );
    }

    const rawCommand = args[0];
    const commandName = normalizeCommandName(rawCommand);
    const template = normalizeTemplate(args.slice(1).join(' '));
    const creator = getCreatorKey(message);
    const creationMentions = getMentionJids(message);

    if (!commandName) {
        return await message.reply('⚠️ Nombre de comando inválido. Debe ser solo letras, números o guion bajo.');
    }

    if (!isValidCommandName(commandName)) {
        return await message.reply('⚠️ El nombre del comando solo puede contener letras, números y guion bajo.');
    }

    if (RESERVED_COMMANDS.includes(commandName)) {
        return await message.reply('⚠️ Ese nombre está reservado. Usa otro nombre para tu comando.');
    }

    if (creationMentions.length > 0) {
        return await message.reply(
            '⚠️ No puedes usar menciones reales al crear el comando. ' +
            'Usa variables como @yo, @text o @randomUser en la plantilla, y menciona a alguien solo cuando ejecutes el comando.'
        );
    }

    if (!template) {
        return await message.reply('⚠️ Debes indicar el mensaje que devolverá el comando.');
    }

    if (!templateLengthOk(template)) {
        return await message.reply('⚠️ El mensaje no puede tener más de 100 caracteres sin contar los parámetros @yo, @text o @random.');
    }

    const store = loadStore();
    const userCommandsCount = Object.values(store.commands).filter(cmd => cmd.creator === creator).length;

    if (userCommandsCount >= MAX_COMMANDS_PER_USER) {
        return await message.reply(
            `⚠️ Has alcanzado el límite de ${MAX_COMMANDS_PER_USER} comandos personalizados. ` +
            `Elimina uno con .delcmd para poder crear uno nuevo.`
        );
    }

    if (store.commands[commandName]) {
        return await message.reply('⚠️ Ese comando ya existe como comando personalizado. Elige otro nombre.');
    }

    if (hasOfficialCommand(commandName)) {
        return await message.reply('⚠️ No puedes crear ese comando porque ya existe como comando oficial del bot.');
    }

    store.commands[commandName] = {
        template,
        creator: creator || 'unknown',
        createdAt: Date.now(),
        uses: 0
    };

    saveStore(store);

    return await message.reply(
        `✅ Comando creado con éxito:\n${formatCommandName(commandName)} ${template}`
    );
}

async function handleMyCmds(message) {
    const creator = getCreatorKey(message);
    const store = loadStore();
    const ownEntries = Object.entries(store.commands)
        .filter(([_, data]) => data.creator === creator)
        .sort(([a], [b]) => a.localeCompare(b));

    if (!ownEntries.length) {
        return await message.reply('📌 No tienes comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    const ownCount = ownEntries.length;
    const lines = ownEntries.map(([name, data]) => {
        const uses = Number(data.uses || 0);
        return `${formatCommandName(name)}\n→ ${data.template}\n   🔥 Usos: ${uses}`;
    });

    const header = `📋 *Tus comandos personalizados* — Página 1/1\n` +
        `📊 Total: ${ownCount} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleCmds(message, { args }) {
    const page = Math.max(1, parseInt(args?.[0] || '1', 10) || 1);
    const store = loadStore();
    const allEntries = Object.entries(store.commands);

    if (!allEntries.length) {
        return await message.reply('📌 No hay comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    const shuffled = allEntries.sort(() => Math.random() - 0.5);
    const pageSize = 10;
    const total = shuffled.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, totalPages);
    const pageEntries = shuffled.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    const lines = pageEntries.map(([name, data]) => {
        const ownerName = getCreatorDisplayName(data.creator) || 'Sin apodo';
        const uses = Number(data.uses || 0);
        return `${formatCommandName(name)} - ${ownerName}\n→ ${data.template}\n   🔥 Usos: ${uses}`;
    });

    const header = `📋 *Comandos personalizados* — Página ${currentPage}/${totalPages}\n` +
        `📊 Total: ${total} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleDelCmd(message, { args }) {
    if (!args || args.length < 1) {
        return await message.reply('⚠️ Uso correcto:\n.delcmd .nombre');
    }

    const commandName = normalizeCommandName(args[0]);
    const creator = getCreatorKey(message);
    const store = loadStore();
    const stored = store.commands[commandName];

    if (!stored) {
        return await message.reply('⚠️ No existe ningún comando personalizado con ese nombre.');
    }

    const isOwner = creator && botConfig.isOwner(creator);
    if (stored.creator !== creator && !isOwner) {
        return await message.reply('⚠️ Solo el creador del comando o el owner del bot puede eliminarlo.');
    }

    delete store.commands[commandName];
    saveStore(store);

    return await message.reply(`✅ Comando ${formatCommandName(commandName)} eliminado.`);
}

async function runCustomCommand(message, commandName, argsText, conn) {
    const store = loadStore();
    const stored = store.commands[commandName];
    if (!stored) return false;

    if (hasOfficialCommand(commandName)) {
        delete store.commands[commandName];
        saveStore(store);

        return await message.reply(
            '⚠️ Este comando fue eliminado porque causaba interferencia con un comando oficial del bot.\n' +
            `Puedes crear uno nuevo con otro nombre:\n.addcmd ${formatCommandName(commandName)} ${stored.template}`
        );
    }

    const senderNumber = getCreatorKey(message);
    const senderJid = getSenderJid(message);
    const chatId = message.from || message.key?.remoteJid;
    const isGroup = chatId?.endsWith('@g.us');
    const mentionJids = getMentionJids(message) || [];
    const randomValue = Math.floor(Math.random() * 100) + 1;

    let output = stored.template;

    // PRIMERO: Manejar @randomUser (antes de @random)
    let randomUserJid = null;
    if (/(@randomUser|@randomuser|@RANDOMUSER)/i.test(output)) {
        if (isGroup && conn) {
            const randomUser = await getRandomGroupUser(conn, chatId, senderJid);
            if (randomUser) {
                randomUserJid = randomUser.jid;
                output = output.replace(/@randomUser/gi, `@${randomUser.number}`);
            } else {
                output = output.replace(/@randomUser/gi, '(sin usuario disponible)');
            }
        } else {
            output = output.replace(/@randomUser/gi, '(solo en grupos)');
        }
    }

    // DESPUÉS: Reemplazar otras variables
    output = output
        .replace(/@yo/gi, senderNumber ? `@${senderNumber}` : '@yo')
        .replace(/@random/gi, String(randomValue))
        .replace(/@text/gi, argsText || '');

    // Construir lista de mentions: primero sender, luego random user, luego targets mencionados
    const mentions = [];
    if (senderJid) mentions.push(senderJid);
    if (randomUserJid && !mentions.includes(randomUserJid)) mentions.push(randomUserJid);
    if (Array.isArray(mentionJids)) {
        for (const jid of mentionJids) {
            if (jid && !mentions.includes(jid)) {
                mentions.push(jid);
            }
        }
    }

    await message.reply(output, mentions.length ? { mentions } : undefined);

    if (store.commands[commandName]) {
        store.commands[commandName].uses = Number(store.commands[commandName].uses || 0) + 1;
        saveStore(store);
    }

    return true;
}




async function textReplyHandler(message) {
    if (!message || typeof message.body !== 'string') return;
    const text = message.body.trim();
    if (!text) return;

    const usedPrefix = PREFIXES.find((prefix) => text.startsWith(prefix));
    if (!usedPrefix) return;

    const commandText = text.slice(usedPrefix.length).trim();
    if (!commandText) return;

    const [rawCommandName, ...args] = commandText.split(' ');
    const commandName = normalizeCommandName(rawCommandName);
    if (!commandName) return;

    const store = loadStore();
    if (!store.commands[commandName]) return;

    const conn = message._sock || global.conn;
    await runCustomCommand(message, commandName, args.join(' '), conn);
}

let handler = async (message, { args, command }) => {
    if (/^addcmd$/i.test(command)) {
        return await handleAddCmd(message, { args });
    }

    if (/^mycmds$/i.test(command)) {
        return await handleMyCmds(message);
    }

    if (/^cmds$/i.test(command)) {
        return await handleCmds(message, { args });
    }

    if (/^delcmd$/i.test(command)) {
        return await handleDelCmd(message, { args });
    }

    return await message.reply('⚠️ Comando no reconocido. Usa .addcmd, .mycmds, .cmds o .delcmd.');
};

handler.help = ['addcmd .nombre mensaje', 'mycmds', 'cmds [página]', 'delcmd .nombre'];
handler.tags = ['fun', 'creador'];
handler.command = /^(addcmd|mycmds|cmds|delcmd)$/i;
handler.textReplyHandler = textReplyHandler;

module.exports = handler;
