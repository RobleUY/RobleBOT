const fs = require('fs');
const path = require('path');
const botConfig = require('../config');

const dataFilePath = path.join(__dirname, '..', 'data', 'comandos.json');
const PREFIXES = ['.', '/', '❤️', '#', '👅', '😎'];
const RESERVED_COMMANDS = ['addcmd', 'mycmds', 'delcmd', 'cmds'];
const MAX_COMMANDS_PER_USER = 50;

function ensureDataFile() {
    const dir = path.dirname(dataFilePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(dataFilePath)) {
        fs.writeFileSync(dataFilePath, JSON.stringify({ commands: {} }, null, 2));
    }
}

function loadStore() {
    try {
        ensureDataFile();
        const raw = fs.readFileSync(dataFilePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') return { commands: {} };
        if (!parsed.commands || typeof parsed.commands !== 'object') parsed.commands = {};
        return parsed;
    } catch (error) {
        console.error('[comandos-personalizados] Error cargando comandos:', error.message);
        return { commands: {} };
    }
}

function saveStore(store) {
    try {
        ensureDataFile();
        fs.writeFileSync(dataFilePath, JSON.stringify(store, null, 2));
    } catch (error) {
        console.error('[comandos-personalizados] Error guardando comandos:', error.message);
    }
}

function normalizeCommandName(raw) {
    if (!raw || typeof raw !== 'string') return '';
    return raw.trim().replace(/^[^a-zA-Z0-9]+/, '').toLowerCase();
}

function isValidCommandName(name) {
    return /^[a-z0-9_]+$/i.test(name);
}

function normalizeTemplate(template) {
    return (template || '').trim();
}

/**
 * Extrae la URL de imagen del template si existe @img=URL
 * Retorna { imageUrl: string|null, cleanTemplate: string }
 */
function extractImageFromTemplate(template) {
    // Busca @img=VALOR (captura cualquier texto sin espacios)
    const imgRegex = /@img=(\S+)/i;
    const match = template.match(imgRegex);

    if (!match) {
        return { imageUrl: null, cleanTemplate: template };
    }

    const imageUrl = match[1];
    // Elimina el @img=URL del template para que no aparezca en el texto
    const cleanTemplate = template.replace(imgRegex, '').trim();

    return { imageUrl, cleanTemplate };
}

/**
 * Detecta si el template contiene una imagen en base64 (data:image/...)
 */
function templateHasBase64Image(template) {
    return /@img=data:[^;]+;base64,/i.test(template);
}

/**
 * Valida que una URL de imagen sea una URL http/https válida (no base64)
 */
function isValidImageUrl(url) {
    try {
        new URL(url);
        return /^https?:\/\/.+/i.test(url);
    } catch {
        return false;
    }
}

function templateLengthOk(template) {
    // Elimina variables y la parte @img=... completa para calcular longitud real del texto
    const stripped = template
        .replace(/@yo|@text|@random|@randomUser/gi, '')
        .replace(/@img=\S+/gi, '')
        .trim();
    return stripped.length <= 100;
}

function getCreatorKey(message) {
    const author = message.author || message.sender || message.key?.participant || message.key?.remoteJid;
    if (!author) return null;
    // Importante: cortar el sufijo de dispositivo (":13", ":7", etc.) ANTES de
    // limpiar caracteres no numéricos. Si no, sus dígitos quedan pegados al
    // número real y el mismo usuario "cambia de identidad" cada vez que
    // reconecta o usa otro dispositivo, rompiendo el conteo de usuarios únicos.
    return author.toString().split('@')[0].split(':')[0].replace(/\D/g, '');
}

function getSenderJid(message) {
    return message.key?.participant || message.author;
}

function getMentionJids(message) {
    if (!message) return [];
    return message.mentions || message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

function hasOfficialCommand(commandName) {
    const handler = global.commandHandler;
    if (!handler || !handler.commands) return false;

    if (handler.commands.has(commandName)) {
        return true;
    }

    for (const [cmdKey] of handler.commands) {
        if (cmdKey instanceof RegExp && cmdKey.test(commandName)) {
            return true;
        }
    }

    return false;
}

function formatCommandName(name) {
    return name.startsWith('.') ? name : `.${name}`;
}

function getCreatorDisplayName(creator) {
    if (!creator) return 'Sin apodo';
    try {
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(String(creator));
            const apodo = user?.apodo?.toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') {
                return apodo;
            }
        }
    } catch (e) {
        // Ignorar errores de DB y usar el fallback.
    }
    return 'Sin apodo';
}

/**
 * Calcula la cantidad de usuarios ÚNICOS que usaron un comando, que es lo
 * que se muestra en las listas (.cmds y .mycmds). Ya no se usa el viejo
 * contador `uses` para mostrar nada: si el comando todavía no tiene
 * `usedBy` (nadie lo usó desde este cambio), se muestra 0.
 */
function getUniqueUsageCount(data) {
    return Array.isArray(data.usedBy) ? data.usedBy.length : 0;
}

async function getRandomGroupUser(conn, groupId, senderJid) {
    try {
        const metadata = await conn.groupMetadata(groupId);
        if (!metadata || !metadata.participants || metadata.participants.length === 0) {
            return null;
        }

        const participants = metadata.participants
            .map(p => p.id)
            .filter(jid => jid !== senderJid);

        if (participants.length === 0) {
            return null;
        }

        const randomIndex = Math.floor(Math.random() * participants.length);
        const randomJid = participants[randomIndex];
        const randomNumber = randomJid.split('@')[0].split(':')[0];

        return { jid: randomJid, number: randomNumber };
    } catch (error) {
        console.error('[comandos-personalizados] Error obteniendo usuario random:', error.message);
        return null;
    }
}

async function handleAddCmd(message, { args, text }) {
    if (!args || args.length < 2) {
        return await message.reply(
            '⚠️ Uso correcto:\n.addcmd .nombre delcomando @yo hace algo con @text\n\n' +
            'Variables disponibles:\n' +
            '• @yo = tu mención\n' +
            '• @text = mención o texto que escribes\n' +
            '• @random = número aleatorio 1-100\n' +
            '• @randomUser = usuario aleatorio del grupo\n' +
            '• @img=URL = imagen a enviar con el mensaje\n\n' +
            'Ejemplos:\n' +
            '.addcmd .suerte La suerte de @text es @random%\n' +
            '.addcmd .sorpresa @yo sorprende a @randomUser 🎉\n' +
            '.addcmd .meme Mirá este meme @yo @img=https://i.imgur.com/ejemplo.jpg'
        );
    }

    const rawCommand = args[0];
    const commandName = normalizeCommandName(rawCommand);
    const template = normalizeTemplate(args.slice(1).join(' '));
    const creator = getCreatorKey(message);
    const creationMentions = getMentionJids(message);

    if (!commandName) {
        return await message.reply('⚠️ Nombre de comando inválido. Debe ser solo letras, números o guion bajo.');
    }

    if (!isValidCommandName(commandName)) {
        return await message.reply('⚠️ El nombre del comando solo puede contener letras, números y guion bajo.');
    }

    if (RESERVED_COMMANDS.includes(commandName)) {
        return await message.reply('⚠️ Ese nombre está reservado. Usa otro nombre para tu comando.');
    }

    if (creationMentions.length > 0) {
        return await message.reply(
            '⚠️ No puedes usar menciones reales al crear el comando. ' +
            'Usa variables como @yo, @text o @randomUser en la plantilla, y menciona a alguien solo cuando ejecutes el comando.'
        );
    }

    if (!template) {
        return await message.reply('⚠️ Debes indicar el mensaje que devolverá el comando.');
    }

    // Rechazar imágenes en base64 (pesan demasiado para guardar en el JSON)
    if (templateHasBase64Image(template)) {
        return await message.reply(
            '⚠️ No se puede usar una imagen en base64 con @img=.\n\n' +
            '📌 Subí la imagen a un hosting gratuito y usá el link directo:\n' +
            '• https://imgbb.com\n' +
            '• https://imgur.com\n\n' +
            'Ejemplo: `.addcmd .meme texto @img=https://i.imgur.com/ejemplo.jpg`'
        );
    }

    // Validar la URL de imagen si se incluye @img=
    const { imageUrl } = extractImageFromTemplate(template);
    if (imageUrl !== null && !isValidImageUrl(imageUrl)) {
        return await message.reply('⚠️ La URL de imagen en @img= no es válida. Debe comenzar con http:// o https://');
    }

    if (!templateLengthOk(template)) {
        return await message.reply('⚠️ El mensaje no puede tener más de 100 caracteres sin contar los parámetros @yo, @text, @random o @img=URL.');
    }

    const store = loadStore();
    const userCommandsCount = Object.values(store.commands).filter(cmd => cmd.creator === creator).length;

    if (userCommandsCount >= MAX_COMMANDS_PER_USER) {
        return await message.reply(
            `⚠️ Has alcanzado el límite de ${MAX_COMMANDS_PER_USER} comandos personalizados. ` +
            `Elimina uno con .delcmd para poder crear uno nuevo.`
        );
    }

    if (store.commands[commandName]) {
        return await message.reply('⚠️ Ese comando ya existe como comando personalizado. Elige otro nombre.');
    }

    if (hasOfficialCommand(commandName)) {
        return await message.reply('⚠️ No puedes crear ese comando porque ya existe como comando oficial del bot.');
    }

    store.commands[commandName] = {
        template,
        creator: creator || 'unknown',
        createdAt: Date.now(),
        uses: 0,
        usedBy: []
    };

    saveStore(store);

    const { cleanTemplate: templateSinImg } = extractImageFromTemplate(template);
    const confirmacion = imageUrl
        ? `✅ Comando creado con éxito:\n${formatCommandName(commandName)} ${templateSinImg}\n🖼️ _Incluye imagen._`
        : `✅ Comando creado con éxito:\n${formatCommandName(commandName)} ${template}`;

    return await message.reply(confirmacion);
}

async function handleMyCmds(message) {
    const creator = getCreatorKey(message);
    const store = loadStore();
    const ownEntries = Object.entries(store.commands)
        .filter(([_, data]) => data.creator === creator)
        .sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));

    if (!ownEntries.length) {
        return await message.reply('📌 No tienes comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    const ownCount = ownEntries.length;
    const lines = ownEntries.map(([name, data]) => {
        const usageCount = getUniqueUsageCount(data);
        const { imageUrl, cleanTemplate: tplLimpio } = extractImageFromTemplate(data.template);
        const imgTag = imageUrl ? ' 🖼️' : '';
        return `${formatCommandName(name)}${imgTag}\n→ ${tplLimpio || data.template}\n   🔥 Usuarios: ${usageCount}`;
    });

    const header = `📋 *Tus comandos personalizados* — Página 1/1\n` +
        `📊 Total: ${ownCount} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleCmds(message, { args }) {
    const page = Math.max(1, parseInt(args?.[0] || '1', 10) || 1);
    const store = loadStore();
    const allEntries = Object.entries(store.commands);

    if (!allEntries.length) {
        return await message.reply('📌 No hay comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    // Top ordenado por cantidad de usuarios únicos que usaron el comando (de mayor a menor)
    const ranked = allEntries.sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));
    const pageSize = 10;
    const total = ranked.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, totalPages);
    const startIndex = (currentPage - 1) * pageSize;
    const pageEntries = ranked.slice(startIndex, startIndex + pageSize);

    const lines = pageEntries.map(([name, data], idx) => {
        const rank = startIndex + idx + 1;
        const ownerName = getCreatorDisplayName(data.creator) || 'Sin apodo';
        const usageCount = getUniqueUsageCount(data);
        const { imageUrl, cleanTemplate: tplLimpio2 } = extractImageFromTemplate(data.template);
        const imgTag = imageUrl ? ' 🖼️' : '';
        return `${rank}. ${formatCommandName(name)}${imgTag} - ${ownerName}\n→ ${tplLimpio2 || data.template}\n   🔥 Usuarios: ${usageCount}`;
    });

    const header = `🏆 *Top comandos personalizados* — Página ${currentPage}/${totalPages}\n` +
        `📊 Total: ${total} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleDelCmd(message, { args }) {
    if (!args || args.length < 1) {
        return await message.reply(
            '⚠️ Uso correcto:\n.delcmd .nombre\n\n' +
            'También podés borrar varios de una:\n.delcmd .nombre1 .nombre2 .nombre3\n\n' +
            'O borrar todos tus comandos:\n.delcmd all'
        );
    }

    const creator = getCreatorKey(message);
    const store = loadStore();

    // Nueva lógica: Verificar si quiere borrar TODOS sus comandos
    const firstArg = args[0].toLowerCase();
    if (['all', 'todo', 'todos'].includes(firstArg)) {
        let deletedCount = 0;

        for (const [cmdName, cmdData] of Object.entries(store.commands)) {
            if (cmdData.creator === creator) {
                delete store.commands[cmdName];
                deletedCount++;
            }
        }

        if (deletedCount > 0) {
            saveStore(store);
            return await message.reply(`✅ Se eliminaron todos tus comandos personalizados (${deletedCount} en total).`);
        } else {
            return await message.reply('⚠️ No tienes comandos personalizados para eliminar.');
        }
    }

    // Lógica normal para eliminar comandos específicos
    const isOwner = creator && botConfig.isOwner(creator);
    const deleted = [];
    const noPermission = [];
    const notFound = [];
    const seen = new Set();

    for (const rawArg of args) {
        const commandName = normalizeCommandName(rawArg);
        if (!commandName || seen.has(commandName)) continue;
        seen.add(commandName);

        const stored = store.commands[commandName];

        if (!stored) {
            notFound.push(commandName);
            continue;
        }

        if (stored.creator !== creator && !isOwner) {
            noPermission.push(commandName);
            continue;
        }

        delete store.commands[commandName];
        deleted.push(commandName);
    }

    if (deleted.length) {
        saveStore(store);
    }

    const lines = [];
    if (deleted.length) {
        lines.push(`✅ Eliminados: ${deleted.map(formatCommandName).join(', ')}`);
    }
    if (noPermission.length) {
        lines.push(`⚠️ Sin permiso (no sos el creador ni el owner): ${noPermission.map(formatCommandName).join(', ')}`);
    }
    if (notFound.length) {
        lines.push(`⚠️ No existen: ${notFound.map(formatCommandName).join(', ')}`);
    }
    if (!lines.length) {
        lines.push('⚠️ No se indicó ningún nombre de comando válido.');
    }

    return await message.reply(lines.join('\n'));
}

async function runCustomCommand(message, commandName, argsText, conn) {
    const store = loadStore();
    const stored = store.commands[commandName];
    if (!stored) return false;

    if (hasOfficialCommand(commandName)) {
        delete store.commands[commandName];
        saveStore(store);

        return await message.reply(
            '⚠️ Este comando fue eliminado porque causaba interferencia con un comando oficial del bot.\n' +
            `Puedes crear uno nuevo con otro nombre:\n.addcmd ${formatCommandName(commandName)} ${stored.template}`
        );
    }

    const senderNumber = getCreatorKey(message);
    const senderJid = getSenderJid(message);
    const chatId = message.from || message.key?.remoteJid;
    const isGroup = chatId?.endsWith('@g.us');
    const mentionJids = getMentionJids(message) || [];

    // Extraer imagen del template ANTES de procesar variables
    const { imageUrl, cleanTemplate } = extractImageFromTemplate(stored.template);
    let output = cleanTemplate;

    // PRIMERO: Manejar @randomUser (antes de @random para evitar conflicto de regex)
    let randomUserJid = null;
    if (/(@randomUser|@randomuser|@RANDOMUSER)/i.test(output)) {
        if (isGroup && conn) {
            const randomUser = await getRandomGroupUser(conn, chatId, senderJid);
            if (randomUser) {
                randomUserJid = randomUser.jid;
                output = output.replace(/@randomUser/gi, `@${randomUser.number}`);
            } else {
                output = output.replace(/@randomUser/gi, '(sin usuario disponible)');
            }
        } else {
            output = output.replace(/@randomUser/gi, '(solo en grupos)');
        }
    }

    // DESPUÉS: Reemplazar otras variables.
    // @random usa una función de reemplazo para generar un número distinto
    // por cada ocurrencia en el template.
    output = output
        .replace(/@yo/gi, senderNumber ? `@${senderNumber}` : '@yo')
        .replace(/@random/gi, () => String(Math.floor(Math.random() * 100) + 1))
        .replace(/@text/gi, argsText || '');

    // Construir lista de mentions: primero sender, luego random user, luego targets mencionados
    const mentions = [];
    if (senderJid) mentions.push(senderJid);
    if (randomUserJid && !mentions.includes(randomUserJid)) mentions.push(randomUserJid);
    if (Array.isArray(mentionJids)) {
        for (const jid of mentionJids) {
            if (jid && !mentions.includes(jid)) {
                mentions.push(jid);
            }
        }
    }

    // Enviar con imagen si hay @img=URL, o solo texto si no
    if (imageUrl) {
        const sock = conn || message._sock || global.conn;
        if (sock) {
            try {
                await sock.sendMessage(chatId, {
                    image: { url: imageUrl },
                    caption: output,
                    mentions: mentions.length ? mentions : undefined
                });
            } catch (imgError) {
                console.error('[comandos-personalizados] Error enviando imagen:', imgError.message);
                // Fallback: enviar solo texto si la imagen falla
                await message.reply(
                    output + '\n\n⚠️ _No se pudo cargar la imagen._',
                    mentions.length ? { mentions } : undefined
                );
            }
        } else {
            // Sin conexión disponible, enviar solo texto
            await message.reply(
                output,
                mentions.length ? { mentions } : undefined
            );
        }
    } else {
        await message.reply(output, mentions.length ? { mentions } : undefined);
    }

    // Registrar el uso. `uses` sigue siendo el contador histórico total,
    // pero `usedBy` trackea usuarios únicos (un mismo usuario spameando el
    // comando no suma más de una vez al ranking/estadística mostrada).
    if (store.commands[commandName]) {
        store.commands[commandName].uses = Number(store.commands[commandName].uses || 0) + 1;

        if (!Array.isArray(store.commands[commandName].usedBy)) {
            store.commands[commandName].usedBy = [];
        }
        if (senderNumber && !store.commands[commandName].usedBy.includes(senderNumber)) {
            store.commands[commandName].usedBy.push(senderNumber);
        }

        saveStore(store);
    }

    return true;
}

async function textReplyHandler(message) {
    if (!message || typeof message.body !== 'string') return;
    const text = message.body.trim();
    if (!text) return;

    const usedPrefix = PREFIXES.find((prefix) => text.startsWith(prefix));
    if (!usedPrefix) return;

    const commandText = text.slice(usedPrefix.length).trim();
    if (!commandText) return;

    const [rawCommandName, ...args] = commandText.split(' ');
    const commandName = normalizeCommandName(rawCommandName);
    if (!commandName) return;

    const store = loadStore();
    if (!store.commands[commandName]) return;

    const conn = message._sock || global.conn;
    await runCustomCommand(message, commandName, args.join(' '), conn);
}

let handler = async (message, { args, command }) => {
    if (/^addcmd$/i.test(command)) {
        return await handleAddCmd(message, { args });
    }

    if (/^mycmds$/i.test(command)) {
        return await handleMyCmds(message);
    }

    if (/^cmds$/i.test(command)) {
        return await handleCmds(message, { args });
    }

    if (/^delcmd$/i.test(command)) {
        return await handleDelCmd(message, { args });
    }

    return await message.reply('⚠️ Comando no reconocido. Usa .addcmd, .mycmds, .cmds o .delcmd.');
};

handler.help = ['addcmd .nombre mensaje', 'mycmds', 'cmds [página]', 'delcmd .nombre', 'delcmd all'];
handler.tags = ['fun', 'creador'];
handler.command = /^(addcmd|mycmds|cmds|delcmd)$/i;
handler.textReplyHandler = textReplyHandler;

module.exports = handler;