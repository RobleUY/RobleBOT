const fs = require('fs');
const path = require('path');

const AUTHORIZED_NUMBERS = [
    '59892099606',
    '59893900470',
];

// Ruta del archivo de baneados
const BANNED_FILE = path.join(__dirname, '..', 'usuarios-baneados.json');
const JID_MAPPING_FILE = path.join(__dirname, '..', 'jid-mapping.json');

// 🟢 FUNCIÓN PARA NORMALIZAR NÚMEROS (solo dígitos)
function normalizeNumber(number) {
    if (!number) return '';
    let clean = number.replace(/[^\d]/g, '').trim();
    return clean;
}

// 🟢 FUNCIÓN PARA EXTRAER EL NÚMERO REAL DEL JID
function extractRealNumber(userId) {
    if (!userId) return '';
    // Extrae los dígitos del inicio: "59893900470@s.whatsapp.net" -> "59893900470"
    const match = userId.match(/^(\d+)/);
    return match ? match[1] : userId;
}

// 🟢 FUNCIÓN PARA GUARDAR MAPEO DE JID
// realNumber debe ser el número normalizado (solo dígitos).
// jidInGroup es el JID completo (LID o real).
function saveJidMapping(realNumber, jidInGroup) {
    try {
        let mapping = {};
        if (fs.existsSync(JID_MAPPING_FILE)) {
            const data = fs.readFileSync(JID_MAPPING_FILE, 'utf8');
            mapping = JSON.parse(data);
        }
        // Mapear el JID del grupo (LID) al número real normalizado.
        mapping[jidInGroup] = normalizeNumber(realNumber);
        fs.writeFileSync(JID_MAPPING_FILE, JSON.stringify(mapping, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando mapeo JID:', error);
    }
}

// 🟢 FUNCIÓN PARA OBTENER NÚMERO REAL DESDE JID
function getRealNumberFromJid(jid) {
    try {
        if (fs.existsSync(JID_MAPPING_FILE)) {
            const data = fs.readFileSync(JID_MAPPING_FILE, 'utf8');
            const mapping = JSON.parse(data);
            return mapping[jid] || null; // Devuelve el número normalizado si existe mapeo
        }
    } catch (error) {
        console.error('Error leyendo mapeo JID:', error);
    }
    return null;
}

function getBannedUsers() {
    try {
        if (fs.existsSync(BANNED_FILE)) {
            const data = fs.readFileSync(BANNED_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error leyendo baneados:', error);
    }
    return {};
}

// 🟢 FUNCIÓN PARA GUARDAR BANEADOS
function saveBannedUsers(bannedUsers) {
    try {
        fs.writeFileSync(BANNED_FILE, JSON.stringify(bannedUsers, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando baneados:', error);
    }
}

// 🟢 FUNCIÓN PARA VERIFICAR SI ESTÁ BANEADO
function isUserBanned(userId) {
    // Recibe el número real (o LID si index.js no lo mapeó antes), pero siempre normalizamos
    const normalized = normalizeNumber(userId); 
    const bannedUsers = getBannedUsers();
    
    // Solo verifica el número normalizado. El mapeo JID->Number ocurre en index.js.
    return bannedUsers.hasOwnProperty(normalized);
}

// 🟢 FUNCIÓN PARA OBTENER RAZÓN DEL BAN
function getBanReason(userId) {
    const normalized = normalizeNumber(userId);
    const bannedUsers = getBannedUsers();
    
    return bannedUsers[normalized] || 'Desconocida';
}

// 🟢 COMANDO BAN
let banHandler = async (message, { text, args, usedPrefix }) => {
    try {
        // Verificar si es autorizado
        const senderId = message.author || message.from; // Es el número normalizado desde index.js
        const normalizedSender = normalizeNumber(senderId);
        
        if (!AUTHORIZED_NUMBERS.includes(normalizedSender)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        // Verificar si hay argumentos
        if (!text || args.length < 2) {
            return await message.reply(`❌ Uso: ${usedPrefix}ban @usuario <razón>\n❌ Ejemplo: ${usedPrefix}ban @pepe Molestar`);
        }

        let targetNumber = null;
        let reason = args.slice(1).join(' ');

        // Si hay mención
        if (message.mentions && message.mentions.length > 0) {
            // Extrae el número del JID mencionado
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            // Si es un número directo
            targetNumber = normalizeNumber(args[0]);
        } else {
            // El primer argumento no es mención ni número, probablemente falló
            return await message.reply(`❌ Debes mencionar un usuario o proporcionar un número válido.\n❌ Ejemplo: ${usedPrefix}ban @pepe Razón`);
        }

        if (!targetNumber) {
            return await message.reply(`❌ No se pudo identificar el número de usuario a banear.`);
        }

        const normalized = normalizeNumber(targetNumber);
        const bannedUsers = getBannedUsers();

        // Verificar si ya está baneado
        if (bannedUsers.hasOwnProperty(normalized)) {
            return await message.reply(`⚠️ El usuario ${normalized} ya está baneado.\nRazón: ${bannedUsers[normalized]}`);
        }

        // Banear usuario - SOLO GUARDAR NÚMERO NORMALIZADO
        bannedUsers[normalized] = reason || 'Sin especificar';
        
        saveBannedUsers(bannedUsers);

        console.log(`🚫 Usuario baneado: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario ${normalized} baneado correctamente.\n📝 Razón: ${reason || 'Sin especificar'}`);

    } catch (error) {
        console.error('Error en comando ban:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banHandler.command = /^ban$/i;
banHandler.help = ['ban'];
banHandler.tags = ['admin'];

// 🟢 COMANDO UNBAN
let unbanHandler = async (message, { text, args, usedPrefix }) => {
    try {
        // Verificar si es autorizado
        const senderId = message.author || message.from;
        const normalizedSender = normalizeNumber(senderId);
        
        if (!AUTHORIZED_NUMBERS.includes(normalizedSender)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        if (!text && (!args || args.length === 0)) {
            return await message.reply(`❌ Uso: ${usedPrefix}unban @usuario\n❌ Ejemplo: ${usedPrefix}unban @pepe`);
        }

        let targetNumber = null;

        // Si hay mención
        if (message.mentions && message.mentions.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0] && (args[0].startsWith('+') || /^\d+$/.test(args[0]))) {
            // Si es un número directo
            targetNumber = normalizeNumber(args[0]);
        }

        if (!targetNumber) {
            return await message.reply(`❌ Debes mencionar un usuario o proporcionar un número.\n❌ Ejemplo: ${usedPrefix}unban @pepe`);
        }

        const normalized = normalizeNumber(targetNumber);
        const bannedUsers = getBannedUsers();

        // Verificar si está baneado
        if (!bannedUsers.hasOwnProperty(normalized)) {
            return await message.reply(`⚠️ El usuario ${normalized} no está baneado.`);
        }

        // Desbanear usuario
        delete bannedUsers[normalized];
        saveBannedUsers(bannedUsers);

        console.log(`✅ Usuario desbaneado: ${normalized}`);
        return await message.reply(`✅ Usuario ${normalized} desbaneado correctamente.`);

    } catch (error) {
        console.error('Error en comando unban:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanHandler.command = /^unban$/i;
unbanHandler.help = ['unban'];
unbanHandler.tags = ['admin'];

// 🟢 COMANDO LISTBAN (ver baneados)
let listbanHandler = async (message, { usedPrefix }) => {
    try {
        // Verificar si es autorizado
        const senderId = message.author || message.from;
        const normalizedSender = normalizeNumber(senderId);
        
        if (!AUTHORIZED_NUMBERS.includes(normalizedSender)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        const bannedUsers = getBannedUsers();
        const userCount = Object.keys(bannedUsers).length;

        if (userCount === 0) {
            return await message.reply('✅ No hay usuarios baneados.');
        }

        let list = `*📋 LISTA DE USUARIOS BANEADOS (${userCount})*\n\n`;
        // Recorremos solo los números normalizados que son las keys del JSON
        for (const [number, reason] of Object.entries(bannedUsers)) {
            list += `📌 *${number}*\n   Razón: ${reason}\n\n`;
        }

        return await message.reply(list);

    } catch (error) {
        console.error('Error en comando listban:', error);
        return await message.reply('❌ Ocurrió un error.');
    }
};

listbanHandler.command = /^listban|bannedlist$/i;
listbanHandler.help = ['listban'];
listbanHandler.tags = ['admin'];

module.exports = banHandler;
module.exports.unbanHandler = unbanHandler;
module.exports.listbanHandler = listbanHandler;
module.exports.isUserBanned = isUserBanned;
module.exports.getBanReason = getBanReason;
module.exports.normalizeNumber = normalizeNumber;
module.exports.extractRealNumber = extractRealNumber;
module.exports.saveJidMapping = saveJidMapping;
module.exports.getRealNumberFromJid = getRealNumberFromJid;