const fs = require('fs');
const path = require('path');
const config = require('../config');

const DATA_DIR = path.join(__dirname, '..', 'data');
const BANNED_FILE = path.join(DATA_DIR, 'usuarios-baneados.json');

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(BANNED_FILE)) {
    fs.writeFileSync(BANNED_FILE, JSON.stringify({ global: {}, groups: {} }, null, 2), 'utf8');
}

const ACCESS_DENIED_BOT_ADMIN = 
    '⛔ *Acceso denegado*\n\n' +
    'Este comando solo puede ser usado por administradores autorizados del bot.\n' +
    'Si crees que esto es un error, contacta al propietario del bot.';

const ACCESS_DENIED_GROUP_ADMIN = '❌ Solo los administradores del grupo pueden usar este comando.';

function normalizeNumber(number) {
    if (!number) return '';
    return number.replace(/[^\d]/g, '').trim();
}

function extractRealNumber(userId) {
    if (!userId) return '';
    const match = userId.match(/^(\d+)/);
    return match ? match[1] : userId;
}

function isOwner(senderId) {
    const num = normalizeNumber(senderId);
    const cfg = global.botConfig || config;
    const owners = cfg.owners || [];
    const ownerNums = owners.map(o => normalizeNumber(o));
    return ownerNums.includes(num) || (typeof cfg.isOwner === 'function' && cfg.isOwner(senderId));
}

function checkIsAdminBot(message, senderId) {
    const sender = senderId || message?.sender || message?.author || message?.key?.participant || message?.key?.remoteJid || message?.from || '';
    const cleanNumber = sender.split('@')[0].split(':')[0].replace(/\D/g, '');
    const cfg = global.botConfig || config;
    const admins = Array.isArray(cfg.adminsbot) ? cfg.adminsbot : [];
    
    return admins.includes(cleanNumber) || admins.includes(sender) || isOwner(sender) || isOwner(cleanNumber);
}

async function checkIsGroupAdmin(message, groupId, conn) {
    try {
        const activeConn = conn || message._sock || global.conn;
        if (!activeConn) return false;
        
        let groupMetadata = null;
        try {
            const { getGroupMetadataCached } = require('../lib/groupCache');
            if (typeof getGroupMetadataCached === 'function') {
                groupMetadata = await getGroupMetadataCached(activeConn, groupId);
            }
        } catch (_) {}
        
        if (!groupMetadata && typeof activeConn.groupMetadata === 'function') {
            groupMetadata = await activeConn.groupMetadata(groupId).catch(() => null);
        }
        
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) return false;
        
        const sender = message.author || message.sender || message.key?.participant || message.key?.remoteJid || message.from || '';
        const cleanNumber = sender.split('@')[0].split(':')[0].replace(/\D/g, '');
        
        const participant = groupMetadata.participants.find(p => {
            if (p.id === sender) return true;
            const pNum = (p.id || '').split('@')[0].split(':')[0].replace(/\D/g, '');
            return pNum && pNum === cleanNumber;
        });
        
        return participant?.admin === 'admin' || participant?.admin === 'superadmin';
    } catch (e) {
        console.error('Error verificando admin de grupo:', e);
        return false;
    }
}

let _bannedCache = null;
let _bannedCacheTime = 0;
const BANNED_CACHE_TTL = 5000;

function getBannedData() {
    const now = Date.now();
    if (_bannedCache && (now - _bannedCacheTime < BANNED_CACHE_TTL)) {
        return _bannedCache;
    }
    try {
        if (fs.existsSync(BANNED_FILE)) {
            _bannedCache = JSON.parse(fs.readFileSync(BANNED_FILE, 'utf8'));
            _bannedCacheTime = now;
            return _bannedCache;
        }
    } catch (error) {
        console.error('Error leyendo baneados:', error);
    }
    _bannedCache = { global: {}, groups: {} };
    _bannedCacheTime = now;
    return _bannedCache;
}

function saveBannedData(data) {
    try {
        _bannedCache = data;
        _bannedCacheTime = Date.now();
        fs.writeFileSync(BANNED_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando baneados:', error);
    }
}

function getUserByNickname(nickname) {
    if (!nickname) return null;
    const nickLower = nickname.toLowerCase();
    try {
        if (global.db && typeof global.db._stmts?.getAllUsers?.all === 'function') {
            const rows = global.db._stmts.getAllUsers.all();
            for (const row of rows) {
                try {
                    const u = JSON.parse(row.data);
                    if (u.apodo && u.apodo.toLowerCase() === nickLower) {
                        return row.id;
                    }
                } catch (_) {}
            }
        }
    } catch (_) {}
    return null;
}

function isUserBanned(userId, groupId = null) {
    const data = getBannedData();
    const num = normalizeNumber(userId);
    
    // Verificar ban global
    if (data.global && data.global[num]) return true;
    
    // Verificar ban de grupo si se proporciona groupId
    if (groupId && data.groups && data.groups[groupId] && data.groups[groupId][num]) {
        return true;
    }
    
    return false;
}

function getBanInfo(userId, groupId = null) {
    const data = getBannedData();
    const num = normalizeNumber(userId);
    
    if (data.global && data.global[num]) {
        return { type: 'global', reason: data.global[num] };
    }
    
    if (groupId && data.groups && data.groups[groupId] && data.groups[groupId][num]) {
        return { type: 'group', reason: data.groups[groupId][num] };
    }
    
    return null;
}

// 🟢 COMANDO BAN (POR GRUPO)
let banHandler = async (message, { args, usedPrefix, isGroup, conn }) => {
    try {
        if (!isGroup) {
            return await message.reply('❌ Este comando solo funciona en grupos.');
        }

        const senderId = message.author || message.sender || message.key?.participant || message.from;
        const groupId = message.from;
        
        const isGrpAdmin = await checkIsGroupAdmin(message, groupId, conn);
        if (!isGrpAdmin && !checkIsAdminBot(message, senderId)) {
            return await message.reply(ACCESS_DENIED_GROUP_ADMIN);
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}ban @usuario <razón>\n${usedPrefix}ban apodo <razón>\n${usedPrefix}ban +número <razón>`);
        }

        let targetNumber, reason;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
            reason = args.slice(1).join(' ') || 'Sin especificar';
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.groups) data.groups = {};
        if (!data.groups[groupId]) data.groups[groupId] = {};

        if (data.groups[groupId][normalized]) {
            return await message.reply(`⚠️ El usuario ya está baneado en este grupo.\nRazón: ${data.groups[groupId][normalized]}`);
        }

        data.groups[groupId][normalized] = reason;
        saveBannedData(data);

        console.log(`🚫 Usuario baneado en grupo ${groupId}: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario baneado del grupo.\n📝 Razón: ${reason}`);

    } catch (error) {
        console.error('Error en comando ban:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banHandler.command = /^ban$/i;
banHandler.help = ['ban'];
banHandler.tags = ['admin'];
banHandler.group = true;

// 🟢 COMANDO UNBAN (POR GRUPO, ALL Y ALL G)
let unbanHandler = async (message, { args, usedPrefix, isGroup, conn }) => {
    try {
        const senderId = message.author || message.sender || message.key?.participant || message.from;
        const groupId = message.from;

        if (!args || args.length === 0) {
            return await message.reply(
                `❌ *Uso del comando:*\n\n` +
                `• *${usedPrefix}unban @usuario* → Desbanear a un usuario de este grupo\n` +
                `• *${usedPrefix}unban apodo* → Desbanear por apodo en este grupo\n` +
                `• *${usedPrefix}unban +número* → Desbanear por número en este grupo\n` +
                `• *${usedPrefix}unban all* → Desbanear a todos en este grupo (admins del grupo)\n` +
                `• *${usedPrefix}unban all g* → Desbanear a todos los baneados globalmente (admins del bot)`
            );
        }

        // Caso: .unban all [...]
        if (args[0].toLowerCase() === 'all') {
            const isGlobalTarget = args[1] && /^(g|global)$/i.test(args[1]);

            if (isGlobalTarget) {
                // .unban all g -> Solo admins del bot
                if (!checkIsAdminBot(message, senderId)) {
                    return await message.reply(ACCESS_DENIED_BOT_ADMIN);
                }

                const data = getBannedData();
                const globalCount = Object.keys(data.global || {}).length;

                if (globalCount === 0) {
                    return await message.reply('✅ No hay usuarios baneados globalmente actualmente.');
                }

                data.global = {};
                saveBannedData(data);

                console.log(`✅ Baneos globales eliminados por ${senderId} (${globalCount} usuarios)`);
                return await message.reply(
                    `✅ *Baneos globales eliminados*\n\n` +
                    `Se ha retirado el baneo global a todos los usuarios (${globalCount} usuarios desbaneados globalmente).\n\n` +
                    `ℹ️ *Nota:* Si algún usuario cuenta con un baneo en un grupo específico, este se mantiene activo.`
                );
            } else {
                // .unban all -> Solo en grupo y para admins del grupo (o admins del bot)
                if (!isGroup) {
                    return await message.reply(
                        `❌ Este comando solo funciona dentro de un grupo.\n` +
                        `💡 Para desbanear a los usuarios con baneo global usa: *${usedPrefix}unban all g*`
                    );
                }

                const isGrpAdmin = await checkIsGroupAdmin(message, groupId, conn);
                if (!isGrpAdmin && !checkIsAdminBot(message, senderId)) {
                    return await message.reply(ACCESS_DENIED_GROUP_ADMIN);
                }

                const data = getBannedData();
                const groupBans = data.groups?.[groupId] || {};
                const groupCount = Object.keys(groupBans).length;

                if (groupCount === 0) {
                    return await message.reply('✅ No hay usuarios baneados en este grupo.');
                }

                delete data.groups[groupId];
                saveBannedData(data);

                console.log(`✅ Baneos de grupo ${groupId} eliminados por ${senderId} (${groupCount} usuarios)`);
                return await message.reply(
                    `✅ *Baneos del grupo eliminados*\n\n` +
                    `Se han desbaneado a todos los usuarios de este grupo (${groupCount} usuarios desbaneados).\n\n` +
                    `ℹ️ *Nota:* Si algún usuario cuenta con un baneo global, dicho baneo seguirá activo.`
                );
            }
        }

        // Caso: .unban individual en grupo
        if (!isGroup) {
            return await message.reply('❌ Este comando solo funciona en grupos.');
        }

        const isGrpAdmin = await checkIsGroupAdmin(message, groupId, conn);
        if (!isGrpAdmin && !checkIsAdminBot(message, senderId)) {
            return await message.reply(ACCESS_DENIED_GROUP_ADMIN);
        }

        let targetNumber;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.groups || !data.groups[groupId] || !data.groups[groupId][normalized]) {
            return await message.reply(`⚠️ El usuario no está baneado en este grupo.`);
        }

        delete data.groups[groupId][normalized];
        saveBannedData(data);

        console.log(`✅ Usuario desbaneado en grupo ${groupId}: ${normalized}`);
        return await message.reply(`✅ Usuario desbaneado del grupo.`);

    } catch (error) {
        console.error('Error en comando unban:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanHandler.command = /^unban$/i;
unbanHandler.help = ['unban', 'unban all', 'unban all g'];
unbanHandler.tags = ['admin'];

// 🟢 COMANDO UNBANALL (RESET TOTAL DE BANEOS - SOLO ADMINS DEL BOT)
let unbanAllHandler = async (message, { usedPrefix }) => {
    try {
        const senderId = message.author || message.sender || message.key?.participant || message.from;

        if (!checkIsAdminBot(message, senderId)) {
            return await message.reply(ACCESS_DENIED_BOT_ADMIN);
        }

        const data = getBannedData();
        const globalCount = Object.keys(data.global || {}).length;
        let groupBansCount = 0;
        let totalGroups = 0;

        if (data.groups) {
            for (const gid of Object.keys(data.groups)) {
                const cnt = Object.keys(data.groups[gid] || {}).length;
                if (cnt > 0) {
                    totalGroups++;
                    groupBansCount += cnt;
                }
            }
        }

        if (globalCount === 0 && groupBansCount === 0) {
            return await message.reply('✅ No hay ningún usuario baneado (ni en grupos ni globalmente).');
        }

        data.global = {};
        data.groups = {};
        saveBannedData(data);

        console.log(`♻️ Unbanall ejecutado por ${senderId}. Globales: ${globalCount}, Grupos: ${groupBansCount}`);
        return await message.reply(
            `♻️ *DESBANEO TOTAL REALIZADO*\n\n` +
            `Se han eliminado absolutamente todos los baneos registrados en el bot:\n` +
            `• 🌐 *Baneos globales removidos:* ${globalCount}\n` +
            `• 👥 *Baneos de grupos removidos:* ${groupBansCount} (en ${totalGroups} grupos)\n\n` +
            `✅ Todos los usuarios han sido desbaneados en su totalidad.`
        );

    } catch (error) {
        console.error('Error en comando unbanall:', error);
        return await message.reply('❌ Ocurrió un error al realizar el desbaneo total.');
    }
};

unbanAllHandler.command = /^unbanall$/i;
unbanAllHandler.help = ['unbanall'];
unbanAllHandler.tags = ['owner'];

// 🟢 COMANDO BANGLOBAL (SOLO ADMINS DEL BOT)
let banglobalHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.sender || message.key?.participant || message.from;
        
        if (!checkIsAdminBot(message, senderId)) {
            return await message.reply(ACCESS_DENIED_BOT_ADMIN);
        }

        if (!args || args.length === 0) {
            return await message.reply(
                `❌ *Uso del comando:*\n` +
                `• *${usedPrefix}bang @usuario <razón>*\n` +
                `• *${usedPrefix}bang apodo <razón>*\n` +
                `• *${usedPrefix}bang +número <razón>*`
            );
        }

        let targetNumber, reason;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
            reason = args.slice(1).join(' ') || 'Sin especificar';
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.global) data.global = {};

        if (data.global[normalized]) {
            return await message.reply(`⚠️ El usuario ya está baneado globalmente.\nRazón: ${data.global[normalized]}`);
        }

        data.global[normalized] = reason;
        saveBannedData(data);

        console.log(`🚫 Usuario baneado GLOBALMENTE por ${senderId}: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario baneado GLOBALMENTE.\n📝 Razón: ${reason}\n⚠️ No podrá usar el bot en ningún lugar.`);

    } catch (error) {
        console.error('Error en comando banglobal:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banglobalHandler.command = /^(banglobal|bang)$/i;
banglobalHandler.help = ['banglobal', 'bang'];
banglobalHandler.tags = ['owner'];

// 🟢 COMANDO UNBANGLOBAL (SOLO ADMINS DEL BOT)
let unbanglobalHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.sender || message.key?.participant || message.from;
        
        if (!checkIsAdminBot(message, senderId)) {
            return await message.reply(ACCESS_DENIED_BOT_ADMIN);
        }

        if (!args || args.length === 0) {
            return await message.reply(
                `❌ *Uso del comando:*\n` +
                `• *${usedPrefix}unbang @usuario*\n` +
                `• *${usedPrefix}unbang apodo*\n` +
                `• *${usedPrefix}unbang +número*\n` +
                `• *${usedPrefix}unbang all* (desbanear a todos globalmente)`
            );
        }

        // Si usan .unbang all o .unbanglobal all
        if (args[0].toLowerCase() === 'all') {
            const data = getBannedData();
            const count = Object.keys(data.global || {}).length;

            if (count === 0) {
                return await message.reply('✅ No hay usuarios baneados globalmente actualmente.');
            }

            data.global = {};
            saveBannedData(data);

            console.log(`✅ Todos los baneos globales eliminados por ${senderId}`);
            return await message.reply(
                `✅ *Baneos globales eliminados*\n\n` +
                `Se ha retirado el baneo global a todos los usuarios (${count} usuarios desbaneados globalmente).\n\n` +
                `ℹ️ *Nota:* Si algún usuario cuenta con un baneo en un grupo específico, este se mantiene activo.`
            );
        }

        let targetNumber;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.global || !data.global[normalized]) {
            return await message.reply(`⚠️ El usuario no está baneado globalmente.`);
        }

        delete data.global[normalized];
        saveBannedData(data);

        console.log(`✅ Usuario desbaneado GLOBALMENTE por ${senderId}: ${normalized}`);
        return await message.reply(`✅ Usuario desbaneado globalmente.\nℹ️ Si tiene baneos de grupo, seguirán activos.`);

    } catch (error) {
        console.error('Error en comando unbanglobal:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanglobalHandler.command = /^(unbanglobal|unbang)$/i;
unbanglobalHandler.help = ['unbanglobal', 'unbang'];
unbanglobalHandler.tags = ['owner'];

// 🟢 COMANDO BANS / LISTBAN
let listbanHandler = async (message, { args, usedPrefix, isGroup, conn }) => {
    try {
        const senderId = message.author || message.sender || message.key?.participant || message.from;
        const groupId = message.from;
        const isGlobal = args && args.length > 0 && /^(g|global)$/i.test(args[0]);

        const data = getBannedData();

        if (isGlobal) {
            // Mostrar baneados globales (admins del bot)
            if (!checkIsAdminBot(message, senderId)) {
                return await message.reply(ACCESS_DENIED_BOT_ADMIN);
            }

            const globalBans = data.global || {};
            const count = Object.keys(globalBans).length;

            if (count === 0) {
                return await message.reply('✅ No hay usuarios baneados globalmente.');
            }

            let list = `🌐 *USUARIOS BANEADOS GLOBALMENTE (${count})*\n\n`;
            let i = 1;
            for (const [number, reason] of Object.entries(globalBans)) {
                list += `${i}. 📌 *+${number}*\n   📝 *Razón:* ${reason}\n\n`;
                i++;
            }
            list += `💡 _Para desbanear a todos usa: ${usedPrefix}unban all g_`;
            return await message.reply(list.trim());
        } else {
            // Mostrar baneados del grupo
            if (!isGroup) {
                return await message.reply(
                    `❌ Este comando muestra los usuarios baneados en un grupo.\n\n` +
                    `💡 Para ver los baneados globalmente usa: *${usedPrefix}bans g*`
                );
            }

            const isGrpAdmin = await checkIsGroupAdmin(message, groupId, conn);
            if (!isGrpAdmin && !checkIsAdminBot(message, senderId)) {
                return await message.reply(ACCESS_DENIED_GROUP_ADMIN);
            }

            const groupBans = data.groups?.[groupId] || {};
            const count = Object.keys(groupBans).length;

            if (count === 0) {
                return await message.reply('✅ No hay usuarios baneados en este grupo.');
            }

            let list = `👥 *USUARIOS BANEADOS EN ESTE GRUPO (${count})*\n\n`;
            let i = 1;
            for (const [number, reason] of Object.entries(groupBans)) {
                list += `${i}. 📌 *+${number}*\n   📝 *Razón:* ${reason}\n\n`;
                i++;
            }
            list += `💡 _Para desbanear a todos usa: ${usedPrefix}unban all_`;
            return await message.reply(list.trim());
        }

    } catch (error) {
        console.error('Error en comando bans:', error);
        return await message.reply('❌ Ocurrió un error al obtener la lista de baneados.');
    }
};

listbanHandler.command = /^(bans|listban|bannedlist)$/i;
listbanHandler.help = ['bans', 'bans g', 'listban'];
listbanHandler.tags = ['admin'];

module.exports = banHandler;
module.exports.banHandler = banHandler;
module.exports.unbanHandler = unbanHandler;
module.exports.banglobalHandler = banglobalHandler;
module.exports.unbanglobalHandler = unbanglobalHandler;
module.exports.listbanHandler = listbanHandler;
module.exports.unbanAllHandler = unbanAllHandler;
module.exports.isUserBanned = isUserBanned;
module.exports.getBanInfo = getBanInfo;
module.exports.normalizeNumber = normalizeNumber;
module.exports.extractRealNumber = extractRealNumber;
