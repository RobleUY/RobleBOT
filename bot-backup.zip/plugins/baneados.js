const fs = require('fs');
const path = require('path');
const config = require('../config');

const BANNED_FILE = path.join(__dirname, '..', 'usuarios-baneados.json');

function normalizeNumber(number) {
    if (!number) return '';
    return number.replace(/[^\d]/g, '').trim();
}

function extractRealNumber(userId) {
    if (!userId) return '';
    const match = userId.match(/^(\d+)/);
    return match ? match[1] : userId;
}

function isOwner(senderId) {
    const num = normalizeNumber(senderId);
    const cfg = global.botConfig || config;
    const owners = cfg.owners || [];
    const ownerNums = owners.map(o => normalizeNumber(o));
    return ownerNums.includes(num) || cfg.isOwner(senderId);
}

function getBannedData() {
    try {
        if (fs.existsSync(BANNED_FILE)) {
            return JSON.parse(fs.readFileSync(BANNED_FILE, 'utf8'));
        }
    } catch (error) {
        console.error('Error leyendo baneados:', error);
    }
    return { global: {}, groups: {} };
}

function saveBannedData(data) {
    try {
        fs.writeFileSync(BANNED_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando baneados:', error);
    }
}

function getUserByNickname(nickname) {
    if (!global.db?.data?.users) return null;
    const nickLower = nickname.toLowerCase();
    for (const [userId, userData] of Object.entries(global.db.data.users)) {
        if (userData.apodo && userData.apodo.toLowerCase() === nickLower) {
            return userId;
        }
    }
    return null;
}

function isUserBanned(userId, groupId = null) {
    const data = getBannedData();
    const num = normalizeNumber(userId);
    
    // Verificar ban global
    if (data.global && data.global[num]) return true;
    
    // Verificar ban de grupo si se proporciona groupId
    if (groupId && data.groups && data.groups[groupId] && data.groups[groupId][num]) {
        return true;
    }
    
    return false;
}

function getBanInfo(userId, groupId = null) {
    const data = getBannedData();
    const num = normalizeNumber(userId);
    
    if (data.global && data.global[num]) {
        return { type: 'global', reason: data.global[num] };
    }
    
    if (groupId && data.groups && data.groups[groupId] && data.groups[groupId][num]) {
        return { type: 'group', reason: data.groups[groupId][num] };
    }
    
    return null;
}

// 🟢 COMANDO BAN (POR GRUPO)
let banHandler = async (message, { args, usedPrefix, isGroup }) => {
    try {
        if (!isGroup) {
            return await message.reply('❌ Este comando solo funciona en grupos.');
        }

        const senderId = message.author || message.from;
        const groupId = message.from;
        
        // Verificar si es admin del grupo
        const groupMetadata = await global.conn.groupMetadata(groupId);
        const isAdmin = groupMetadata.participants.some(p => 
            p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')
        );

        if (!isAdmin && !isOwner(senderId)) {
            return await message.reply('❌ Solo los admins del grupo pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}ban @usuario <razón>\n${usedPrefix}ban apodo <razón>\n${usedPrefix}ban +número <razón>`);
        }

        let targetNumber, reason;

        // Buscar por mención
        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } 
        // Buscar por número
        else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } 
        // Buscar por apodo
        else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
            reason = args.slice(1).join(' ') || 'Sin especificar';
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.groups) data.groups = {};
        if (!data.groups[groupId]) data.groups[groupId] = {};

        if (data.groups[groupId][normalized]) {
            return await message.reply(`⚠️ El usuario ya está baneado en este grupo.\nRazón: ${data.groups[groupId][normalized]}`);
        }

        data.groups[groupId][normalized] = reason;
        saveBannedData(data);

        console.log(`🚫 Usuario baneado en grupo ${groupId}: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario baneado del grupo.\n📝 Razón: ${reason}`);

    } catch (error) {
        console.error('Error en comando ban:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banHandler.command = /^ban$/i;
banHandler.help = ['ban'];
banHandler.tags = ['admin'];
banHandler.group = true;

// 🟢 COMANDO UNBAN (POR GRUPO)
let unbanHandler = async (message, { args, usedPrefix, isGroup }) => {
    try {
        if (!isGroup) {
            return await message.reply('❌ Este comando solo funciona en grupos.');
        }

        const senderId = message.author || message.from;
        const groupId = message.from;
        
        const groupMetadata = await global.conn.groupMetadata(groupId);
        const isAdmin = groupMetadata.participants.some(p => 
            p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')
        );

        if (!isAdmin && !isOwner(senderId)) {
            return await message.reply('❌ Solo los admins del grupo pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}unban @usuario\n${usedPrefix}unban apodo\n${usedPrefix}unban +número`);
        }

        let targetNumber;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.groups || !data.groups[groupId] || !data.groups[groupId][normalized]) {
            return await message.reply(`⚠️ El usuario no está baneado en este grupo.`);
        }

        delete data.groups[groupId][normalized];
        saveBannedData(data);

        console.log(`✅ Usuario desbaneado en grupo ${groupId}: ${normalized}`);
        return await message.reply(`✅ Usuario desbaneado del grupo.`);

    } catch (error) {
        console.error('Error en comando unban:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanHandler.command = /^unban$/i;
unbanHandler.help = ['unban'];
unbanHandler.tags = ['admin'];
unbanHandler.group = true;

// 🟢 COMANDO BANGLOBAL (SOLO OWNERS)
let banglobalHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.from;
        
        if (!isOwner(senderId)) {
            return await message.reply('❌ Solo los owners pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}banglobal @usuario <razón>\n${usedPrefix}banglobal apodo <razón>\n${usedPrefix}banglobal +número <razón>`);
        }

        let targetNumber, reason;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
            reason = args.slice(1).join(' ') || 'Sin especificar';
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.global) data.global = {};

        if (data.global[normalized]) {
            return await message.reply(`⚠️ El usuario ya está baneado globalmente.\nRazón: ${data.global[normalized]}`);
        }

        data.global[normalized] = reason;
        saveBannedData(data);

        console.log(`🚫 Usuario baneado GLOBALMENTE: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario baneado GLOBALMENTE.\n📝 Razón: ${reason}\n⚠️ No podrá usar el bot en ningún lugar.`);

    } catch (error) {
        console.error('Error en comando banglobal:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banglobalHandler.command = /^(banglobal|bang)$/i;
banglobalHandler.help = ['banglobal', 'bang'];
banglobalHandler.tags = ['owner'];
banglobalHandler.owner = true;

// 🟢 COMANDO UNBANGLOBAL (SOLO OWNERS)
let unbanglobalHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.from;
        
        if (!isOwner(senderId)) {
            return await message.reply('❌ Solo los owners pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}unbanglobal @usuario\n${usedPrefix}unbanglobal apodo\n${usedPrefix}unbanglobal +número`);
        }

        let targetNumber;

        if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
        } else {
            const nickname = args[0];
            targetNumber = getUserByNickname(nickname);
            if (!targetNumber) {
                return await message.reply(`❌ No se encontró usuario con apodo "${nickname}"`);
            }
        }

        const normalized = normalizeNumber(targetNumber);
        const data = getBannedData();

        if (!data.global || !data.global[normalized]) {
            return await message.reply(`⚠️ El usuario no está baneado globalmente.`);
        }

        delete data.global[normalized];
        saveBannedData(data);

        console.log(`✅ Usuario desbaneado GLOBALMENTE: ${normalized}`);
        return await message.reply(`✅ Usuario desbaneado globalmente.\n⚠️ Si tiene baneos de grupo, seguirán activos.`);

    } catch (error) {
        console.error('Error en comando unbanglobal:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanglobalHandler.command = /^(unbanglobal|unbang)$/i;
unbanglobalHandler.help = ['unbanglobal', 'unbang'];
unbanglobalHandler.tags = ['owner'];
unbanglobalHandler.owner = true;

// 🟢 COMANDO LISTBAN
let listbanHandler = async (message, { isGroup }) => {
    try {
        const senderId = message.author || message.from;
        const groupId = message.from;
        
        const data = getBannedData();
        
        if (isGroup) {
            // Mostrar baneados del grupo
            const groupMetadata = await global.conn.groupMetadata(groupId);
            const isAdmin = groupMetadata.participants.some(p => 
                p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')
            );

            if (!isAdmin && !isOwner(senderId)) {
                return await message.reply('❌ Solo los admins pueden ver la lista.');
            }

            const groupBans = data.groups?.[groupId] || {};
            const count = Object.keys(groupBans).length;

            if (count === 0) {
                return await message.reply('✅ No hay usuarios baneados en este grupo.');
            }

            let list = `*📋 BANEADOS EN ESTE GRUPO (${count})*\n\n`;
            for (const [number, reason] of Object.entries(groupBans)) {
                list += `📌 *${number}*\n   Razón: ${reason}\n\n`;
            }

            return await message.reply(list);
        } else {
            // Mostrar baneados globales (solo owners)
            if (!isOwner(senderId)) {
                return await message.reply('❌ Solo los owners pueden ver la lista global.');
            }

            const globalBans = data.global || {};
            const count = Object.keys(globalBans).length;

            if (count === 0) {
                return await message.reply('✅ No hay usuarios baneados globalmente.');
            }

            let list = `*📋 BANEADOS GLOBALMENTE (${count})*\n\n`;
            for (const [number, reason] of Object.entries(globalBans)) {
                list += `📌 *${number}*\n   Razón: ${reason}\n\n`;
            }

            return await message.reply(list);
        }

    } catch (error) {
        console.error('Error en comando listban:', error);
        return await message.reply('❌ Ocurrió un error.');
    }
};

listbanHandler.command = /^listban|bannedlist$/i;
listbanHandler.help = ['listban'];
listbanHandler.tags = ['admin'];

module.exports = banHandler;
module.exports.unbanHandler = unbanHandler;
module.exports.banglobalHandler = banglobalHandler;
module.exports.unbanglobalHandler = unbanglobalHandler;
module.exports.listbanHandler = listbanHandler;
module.exports.isUserBanned = isUserBanned;
module.exports.getBanInfo = getBanInfo;
module.exports.normalizeNumber = normalizeNumber;
module.exports.extractRealNumber = extractRealNumber;
