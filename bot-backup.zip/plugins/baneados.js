const fs = require('fs');
const path = require('path');
const config = require('../config');

const BANNED_FILE = path.join(__dirname, '..', 'usuarios-baneados.json');
const JID_MAPPING_FILE = path.join(__dirname, '..', 'jid-mapping.json');

function normalizeNumber(number) {
    if (!number) return '';
    return number.replace(/[^\d]/g, '').trim();
}

function extractRealNumber(userId) {
    if (!userId) return '';
    const match = userId.match(/^(\d+)/);
    return match ? match[1] : userId;
}

function isAuthorized(senderId) {
    const num = normalizeNumber(senderId);
    const cfg = global.botConfig || config;
    const owners = cfg.owners || [];
    const ownerNums = owners.map(o => normalizeNumber(o));
    const match = ownerNums.includes(num) || cfg.isOwner(senderId);
    if (!match) {
        console.log(`[ban] isAuthorized falló — senderId="${senderId}" num="${num}" owners=${JSON.stringify(ownerNums)}`);
    }
    return match;
}

function saveJidMapping(realNumber, jidInGroup) {
    try {
        let mapping = {};
        if (fs.existsSync(JID_MAPPING_FILE)) {
            mapping = JSON.parse(fs.readFileSync(JID_MAPPING_FILE, 'utf8'));
        }
        mapping[jidInGroup] = normalizeNumber(realNumber);
        fs.writeFileSync(JID_MAPPING_FILE, JSON.stringify(mapping, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando mapeo JID:', error);
    }
}

function getRealNumberFromJid(jid) {
    try {
        if (fs.existsSync(JID_MAPPING_FILE)) {
            const mapping = JSON.parse(fs.readFileSync(JID_MAPPING_FILE, 'utf8'));
            return mapping[jid] || null;
        }
    } catch (error) {
        console.error('Error leyendo mapeo JID:', error);
    }
    return null;
}

function getBannedUsers() {
    try {
        if (fs.existsSync(BANNED_FILE)) {
            return JSON.parse(fs.readFileSync(BANNED_FILE, 'utf8'));
        }
    } catch (error) {
        console.error('Error leyendo baneados:', error);
    }
    return {};
}

function saveBannedUsers(bannedUsers) {
    try {
        fs.writeFileSync(BANNED_FILE, JSON.stringify(bannedUsers, null, 2), 'utf8');
    } catch (error) {
        console.error('Error guardando baneados:', error);
    }
}

function isUserBanned(userId) {
    return getBannedUsers().hasOwnProperty(normalizeNumber(userId));
}

function getBanReason(userId) {
    return getBannedUsers()[normalizeNumber(userId)] || 'Desconocida';
}

// 🟢 COMANDO BAN
let banHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.from;
        if (!isAuthorized(senderId)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}ban @usuario <razón> o ${usedPrefix}ban me <razón>`);
        }

        let targetNumber, reason;

        if (args[0]?.toLowerCase() === 'me') {
            targetNumber = normalizeNumber(senderId);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
            reason = args.slice(1).join(' ') || 'Sin especificar';
        } else {
            return await message.reply(`❌ Uso: ${usedPrefix}ban @usuario <razón> o ${usedPrefix}ban me <razón>`);
        }

        const normalized = normalizeNumber(targetNumber);
        const bannedUsers = getBannedUsers();

        if (bannedUsers.hasOwnProperty(normalized)) {
            return await message.reply(`⚠️ El usuario ${normalized} ya está baneado.\nRazón: ${bannedUsers[normalized]}`);
        }

        bannedUsers[normalized] = reason;
        saveBannedUsers(bannedUsers);

        console.log(`🚫 Usuario baneado: ${normalized} - Razón: ${reason}`);
        return await message.reply(`✅ Usuario ${normalized} baneado.\n📝 Razón: ${reason}`);

    } catch (error) {
        console.error('Error en comando ban:', error);
        return await message.reply('❌ Ocurrió un error al banear al usuario.');
    }
};

banHandler.command = /^ban$/i;
banHandler.help = ['ban'];
banHandler.tags = ['admin'];

// 🟢 COMANDO UNBAN
let unbanHandler = async (message, { args, usedPrefix }) => {
    try {
        const senderId = message.author || message.from;
        if (!isAuthorized(senderId)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return await message.reply(`❌ Uso: ${usedPrefix}unban @usuario o ${usedPrefix}unban me`);
        }

        let targetNumber;

        if (args[0]?.toLowerCase() === 'me') {
            targetNumber = normalizeNumber(senderId);
        } else if (message.mentions?.length > 0) {
            targetNumber = extractRealNumber(message.mentions[0]);
        } else if (args[0].startsWith('+') || /^\d+$/.test(args[0])) {
            targetNumber = normalizeNumber(args[0]);
        } else {
            return await message.reply(`❌ Uso: ${usedPrefix}unban @usuario o ${usedPrefix}unban me`);
        }

        const normalized = normalizeNumber(targetNumber);
        const bannedUsers = getBannedUsers();

        if (!bannedUsers.hasOwnProperty(normalized)) {
            return await message.reply(`⚠️ El usuario ${normalized} no está baneado.`);
        }

        delete bannedUsers[normalized];
        saveBannedUsers(bannedUsers);

        console.log(`✅ Usuario desbaneado: ${normalized}`);
        return await message.reply(`✅ Usuario ${normalized} desbaneado correctamente.`);

    } catch (error) {
        console.error('Error en comando unban:', error);
        return await message.reply('❌ Ocurrió un error al desbanear al usuario.');
    }
};

unbanHandler.command = /^unban$/i;
unbanHandler.help = ['unban'];
unbanHandler.tags = ['admin'];

// 🟢 COMANDO LISTBAN
let listbanHandler = async (message) => {
    try {
        const senderId = message.author || message.from;
        if (!isAuthorized(senderId)) {
            return await message.reply('❌ Solo los administradores pueden usar este comando.');
        }

        const bannedUsers = getBannedUsers();
        const userCount = Object.keys(bannedUsers).length;

        if (userCount === 0) return await message.reply('✅ No hay usuarios baneados.');

        let list = `*📋 LISTA DE USUARIOS BANEADOS (${userCount})*\n\n`;
        for (const [number, reason] of Object.entries(bannedUsers)) {
            list += `📌 *${number}*\n   Razón: ${reason}\n\n`;
        }

        return await message.reply(list);

    } catch (error) {
        console.error('Error en comando listban:', error);
        return await message.reply('❌ Ocurrió un error.');
    }
};

listbanHandler.command = /^listban|bannedlist$/i;
listbanHandler.help = ['listban'];
listbanHandler.tags = ['admin'];

module.exports = banHandler;
module.exports.unbanHandler = unbanHandler;
module.exports.listbanHandler = listbanHandler;
module.exports.isUserBanned = isUserBanned;
module.exports.getBanReason = getBanReason;
module.exports.normalizeNumber = normalizeNumber;
module.exports.extractRealNumber = extractRealNumber;
module.exports.saveJidMapping = saveJidMapping;
module.exports.getRealNumberFromJid = getRealNumberFromJid;
