/**
 * Comandos: votar / votos
 * Descripción: Sistema de votación para calificar el bot del 1 al 5 estrellas
 * Uso: 
 *   - /votar <1-5> : Votar o cambiar tu voto
 *   - /votos : Ver estadísticas de votación
 */

const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON donde se guardan los votos (mismo directorio)
const VOTOS_FILE = path.join(__dirname, 'votos_usuarios.json');

// 🔹 VOTOS INICIALES SIMULADOS (no se guardan en el JSON)
const VOTOS_BASE = {
    5: 80,  // 80 votos de 5 estrellas
    4: 15,  // 15 votos de 4 estrellas
    3: 2,   // 2 votos de 3 estrellas
    2: 1,   // 1 voto de 2 estrellas
    1: 2    // 2 votos de 1 estrella
};

// 🔹 FUNCIÓN PARA CARGAR VOTOS DESDE EL ARCHIVO JSON
function cargarVotos() {
    try {
        // Si el archivo no existe, crear uno vacío
        if (!fs.existsSync(VOTOS_FILE)) {
            const votosIniciales = {
                votos: {},
                timestamp: new Date().toISOString()
            };
            fs.writeFileSync(VOTOS_FILE, JSON.stringify(votosIniciales, null, 2), 'utf8');
            return votosIniciales;
        }

        // Leer y parsear el archivo
        const data = fs.readFileSync(VOTOS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('[ERROR] Error al cargar votos:', error);
        return { votos: {}, timestamp: new Date().toISOString() };
    }
}

// 🔹 FUNCIÓN PARA GUARDAR VOTOS EN EL ARCHIVO JSON
function guardarVotos(votosData) {
    try {
        votosData.timestamp = new Date().toISOString();
        fs.writeFileSync(VOTOS_FILE, JSON.stringify(votosData, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('[ERROR] Error al guardar votos:', error);
        return false;
    }
}

// 🔹 FUNCIÓN PARA CALCULAR ESTADÍSTICAS (incluye votos base simulados)
function calcularEstadisticas(votosReales) {
    // Distribución combinada: votos base + votos reales
    const distribucion = { 1: VOTOS_BASE[1], 2: VOTOS_BASE[2], 3: VOTOS_BASE[3], 4: VOTOS_BASE[4], 5: VOTOS_BASE[5] };
    
    // Agregar votos reales del JSON
    Object.values(votosReales).forEach(voto => {
        distribucion[voto.estrellas]++;
    });

    // Calcular total y promedio
    const totalVotos = distribucion[1] + distribucion[2] + distribucion[3] + distribucion[4] + distribucion[5];
    const suma = (distribucion[1] * 1) + (distribucion[2] * 2) + (distribucion[3] * 3) + (distribucion[4] * 4) + (distribucion[5] * 5);
    const promedio = suma / totalVotos;
    const promedioFormateado = promedio.toFixed(1);

    return {
        totalVotos,
        promedio,
        promedioFormateado,
        distribucion
    };
}

// 🔹 FUNCIÓN PARA OBTENER ESTADÍSTICAS (EXPORTABLE)
function obtenerEstadisticasVotos() {
    const votosData = cargarVotos();
    const stats = calcularEstadisticas(votosData.votos);
    return {
        totalVotos: stats.totalVotos,
        promedio: stats.promedio,
        promedioFormateado: stats.promedioFormateado
    };
}

// 🔹 FUNCIÓN PARA OBTENER MENSAJE SEGÚN LA CALIFICACIÓN
function obtenerMensajeSegunEstrellas(estrellas) {
    const mensajes = {
        5: [
            '🌟 ¡Increíble! ¡Gracias por las 5 estrellas!',
            '⭐ ¡Wow! ¡Eres el mejor! Gracias por el apoyo',
            '🎉 ¡Perfecto! Nos alegra que te encante el bot',
            '💎 ¡Excelente! Tu voto de 5 estrellas nos motiva',
            '🚀 ¡Brutal! Gracias por confiar en nosotros'
        ],
        4: [
            '😊 ¡Muy bien! Gracias por las 4 estrellas',
            '👍 ¡Genial! Seguiremos mejorando para ti',
            '💙 ¡Gracias! Tu apoyo es importante',
            '✨ ¡Excelente! Trabajamos para ser aún mejores',
            '🎯 ¡Buenísimo! Gracias por tu voto'
        ],
        3: [
            '🤔 Gracias por tu voto. ¿Qué podemos mejorar?',
            '📝 Entendido. Trabajaremos para ser mejores',
            '💪 Gracias. ¡Nos esforzaremos más!',
            '🔧 Tu opinión cuenta. ¡Mejoraremos!',
            '⚡ Ok, tomaremos nota para mejorar'
        ],
        2: [
            '😕 Lamentamos no cumplir tus expectativas',
            '💔 Sentimos que no te guste. ¿Qué falló?',
            '🛠️ Trabajaremos para mejorar tu experiencia',
            '😞 Perdón por decepcionarte. ¡Mejoraremos!',
            '📉 Tu feedback es importante. ¡Cambiaremos!'
        ],
        1: [
            '😢 Lo sentimos mucho. ¿Qué salió mal?',
            '💔 Perdón por la mala experiencia',
            '🙏 Disculpas. Haremos todo por mejorar',
            '😔 Lo lamentamos. Tu opinión nos ayudará',
            '⚠️ Sentimos no estar a la altura'
        ]
    };

    const opciones = mensajes[estrellas];
    return opciones[Math.floor(Math.random() * opciones.length)];
}

// 🔹 COMANDO: /votar
let handlerVotar = async (message, { conn, text }) => {
    try {
        // Verificar que sea un grupo
        if (!message.key.remoteJid.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede usarse en grupos.');
        }

        // Obtener el número del usuario
        const userId = message.key.participant || message.key.remoteJid;

        // Validar que se haya ingresado un número
        if (!text || text.trim() === '') {
            return await message.reply('❌ Debes ingresar una calificación del 1 al 5.\n\n*Ejemplo:* /votar 5');
        }

        // Validar que sea un número del 1 al 5
        const calificacion = parseInt(text.trim());
        if (isNaN(calificacion) || calificacion < 1 || calificacion > 5) {
            return await message.reply('❌ La calificación debe ser un número del *1 al 5*.\n\n*Ejemplo:* /votar 5');
        }

        // Cargar votos actuales
        const votosData = cargarVotos();
        const votoAnterior = votosData.votos[userId];

        // Registrar o actualizar el voto
        votosData.votos[userId] = {
            estrellas: calificacion,
            fecha: new Date().toISOString(),
            grupoId: message.key.remoteJid
        };

        // Guardar en el archivo
        if (!guardarVotos(votosData)) {
            return await message.reply('❌ Error al guardar tu voto. Intenta nuevamente.');
        }

        // Calcular nuevas estadísticas
        const stats = calcularEstadisticas(votosData.votos);

        // Mensaje personalizado según las estrellas
        const mensajePersonalizado = obtenerMensajeSegunEstrellas(calificacion);

        // Mensaje de respuesta
        let respuesta = '';
        if (votoAnterior) {
            respuesta = `✅ *Voto actualizado*\n\n`;
            respuesta += `${mensajePersonalizado}\n\n`;
            respuesta += `Voto anterior: ${'★'.repeat(votoAnterior.estrellas)}${'☆'.repeat(5 - votoAnterior.estrellas)}\n`;
            respuesta += `Nuevo voto: ${'★'.repeat(calificacion)}${'☆'.repeat(5 - calificacion)}\n\n`;
        } else {
            respuesta = `✅ *¡Gracias por votar!*\n\n`;
            respuesta += `${mensajePersonalizado}\n\n`;
            respuesta += `Tu voto: ${'★'.repeat(calificacion)}${'☆'.repeat(5 - calificacion)}\n\n`;
        }

        respuesta += `📊 Calificación general: ${stats.promedioFormateado}/5.0\n`;
        respuesta += `🗳️ Total de votos: ${stats.totalVotos}\n\n`;
        respuesta += `💡 Usa */votos* para ver estadísticas completas`;

        await message.reply(respuesta);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando votar:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al procesar tu voto.');
    }
};

handlerVotar.help = ['votar'];
handlerVotar.tags = ['info'];
handlerVotar.command = /^(votar)$/i;

// 🔹 COMANDO: /votos
let handlerVotos = async (message, { conn }) => {
    try {
        // Verificar que sea un grupo
        if (!message.key.remoteJid.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede usarse en grupos.');
        }

        // Obtener el número del usuario
        const userId = message.key.participant || message.key.remoteJid;

        // Cargar votos
        const votosData = cargarVotos();
        const stats = calcularEstadisticas(votosData.votos);

        // Obtener el voto del usuario actual
        const miVoto = votosData.votos[userId];

        // Crear mensaje con estadísticas
        let respuesta = '┏━━━━━━━━━━━━┓\n';
        respuesta += '┃  📊 *VOTACIÓN DEL BOT* ┃\n';
        respuesta += '┗━━━━━━━━━━━━┛\n\n';
        
        // Calificación general
        respuesta += `*Calificación:* ${stats.promedioFormateado}/5.0\n\n`;
        
        // Total de votos
        respuesta += `🗳️ *Total de votos:* ${stats.totalVotos}\n\n`;
        
        // Distribución de votos
        respuesta += `┈┈┈┈┈┈┈┈┈┈┈\n`;
        respuesta += `*Distribución:*\n\n`;
        for (let i = 5; i >= 1; i--) {
            const cantidad = stats.distribucion[i];
            const porcentaje = ((cantidad / stats.totalVotos) * 100).toFixed(0);
            respuesta += `${'★'.repeat(i)}${'☆'.repeat(5 - i)} • ${cantidad} votos (${porcentaje}%)\n`;
        }

        // Mi voto
        respuesta += `\n┈┈┈┈┈┈┈┈┈┈┈\n`;
        if (miVoto) {
            respuesta += `✨ *Tu voto:* ${'★'.repeat(miVoto.estrellas)}${'☆'.repeat(5 - miVoto.estrellas)}`;
        } else {
            respuesta += `❌ *No has votado aún*\n💡 Usa */votar <1-5>* para calificar`;
        }

        await message.reply(respuesta);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando votos:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al mostrar las estadísticas.');
    }
};

handlerVotos.help = ['votos'];
handlerVotos.tags = ['info'];
handlerVotos.command = /^(votos)$/i;

// 🔹 EXPORTAR HANDLERS Y FUNCIÓN DE ESTADÍSTICAS
module.exports = {
    votar: handlerVotar,
    votos: handlerVotos,
    obtenerEstadisticasVotos // Función exportable para usar en otros archivos
};