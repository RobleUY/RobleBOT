const { loadStats } = require('../botStatsRecorder');

/**
 * Parsea un string de tiempo como "1h", "30m", "2d", "24h" a milisegundos.
 * Soporta: m (minutos), h (horas), d (días)
 */
function parseTime(str) {
    if (!str || typeof str !== 'string') return null;
    const match = str.trim().match(/^(\d+)(m|h|d)$/i);
    if (!match) return null;

    const value = parseInt(match[1], 10);
    const unit = match[2].toLowerCase();

    if (unit === 'm') return value * 60 * 1000;
    if (unit === 'h') return value * 60 * 60 * 1000;
    if (unit === 'd') return value * 24 * 60 * 60 * 1000;
    return null;
}

/**
 * Formatea milisegundos a texto legible: "1 hora", "30 minutos", etc.
 */
function formatTime(ms) {
    const minutes = Math.floor(ms / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} día${days !== 1 ? 's' : ''}`;
    if (hours > 0) return `${hours} hora${hours !== 1 ? 's' : ''}`;
    return `${minutes} minuto${minutes !== 1 ? 's' : ''}`;
}

let handler = async (message) => {
    const text = (message.body || '').trim();
    const args = text.split(/\s+/).slice(1); // quitar el comando
    const timeArg = args[0];

    if (!timeArg) {
        return await message.reply(
            `⏱️ *Uso:* .usersbot <tiempo>\n\n` +
            `*Ejemplos:*\n` +
            `› .usersbot 1h → última 1 hora\n` +
            `› .usersbot 30m → últimos 30 minutos\n` +
            `› .usersbot 24h → últimas 24 horas\n` +
            `› .usersbot 7d → últimos 7 días`
        );
    }

    const ms = parseTime(timeArg);
    if (!ms) {
        return await message.reply(
            `❌ Tiempo inválido: *${timeArg}*\n\n` +
            `Usa un formato válido: *30m*, *1h*, *24h*, *7d*`
        );
    }

    try {
        const stats = loadStats();
        const users = stats.users || {};
        const cutoff = Date.now() - ms;

        const activeCount = Object.values(users).filter(u => u.lastSeen >= cutoff).length;
        const timeLabel = formatTime(ms);

        await message.reply(
            `👥 *Usuarios activos — últim${ms < 3600000 ? 'os' : 'as'} ${timeLabel}*\n\n` +
            `› *${activeCount}* usuario${activeCount !== 1 ? 's' : ''} usaron el bot en ese período.`
        );
    } catch (error) {
        console.error('[usuarios-bot] Error:', error.message);
        await message.reply('❌ Error al obtener los datos.');
    }
};

handler.help = ['usersbot'];
handler.tags = ['info'];
handler.command = /^usersbot$/i;

module.exports = handler;
