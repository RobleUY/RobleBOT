const fs = require('fs');
const path = require('path');

const FIRMAS_FILE = path.join(__dirname, '../data/firmas-usuarios.json');

/**
 * Carga las firmas desde el archivo JSON
 */
function loadFirmas() {
    try {
        if (!fs.existsSync(FIRMAS_FILE)) {
            return {};
        }
        const data = fs.readFileSync(FIRMAS_FILE, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('[Firmas] Error cargando firmas:', error.message);
        return {};
    }
}

/**
 * Guarda las firmas en el archivo JSON
 */
function saveFirmas(data) {
    try {
        const dir = path.dirname(FIRMAS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(FIRMAS_FILE, JSON.stringify(data, null, 2), 'utf-8');
        return true;
    } catch (error) {
        console.error('[Firmas] Error guardando firmas:', error.message);
        return false;
    }
}

/**
 * Limpia un número de JID
 */
function cleanNumber(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0].replace(/\D/g, '');
}

/**
 * Obtiene el apodo de un usuario
 */
function getApodo(numero) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const cleanNum = cleanNumber(numero);
    const user = global.db.data.users[cleanNum] || global.db.data.users[`${cleanNum}@s.whatsapp.net`];
    if (!user || !user.apodo || user.apodo.trim() === '' || user.apodo.toLowerCase() === 'sin apodo') {
        return null;
    }
    return user.apodo.trim();
}

/**
 * Busca un usuario por apodo
 */
function findUserByApodo(apodo) {
    if (!global.db || !global.db.data || !global.db.data.users) return null;
    const searchApodo = apodo.toLowerCase().trim();
    
    for (const [userId, userData] of Object.entries(global.db.data.users)) {
        const userApodo = userData.apodo;
        if (userApodo && userApodo.toLowerCase().trim() === searchApodo) {
            return cleanNumber(userId);
        }
    }
    return null;
}

/**
 * Formatea una fecha a formato legible
 */
function formatDate(timestamp) {
    const date = new Date(timestamp);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

// ============================================================================
// COMANDO: .firmar
// ============================================================================
async function comandoFirmar(message, { text, conn }) {
    const sock = conn || message._sock || global.conn;
    const senderNumber = cleanNumber(message.sender);
    const senderApodo = getApodo(senderNumber);
    
    if (!senderApodo) {
        return await message.reply('❌ Necesitas tener un apodo configurado para firmar.\nUsa *.apodo tu_apodo* para configurar uno.');
    }
    
    // Validar que haya texto
    if (!text || text.trim() === '') {
        return await message.reply(
            `📝 *FIRMAR USUARIOS*\n\n` +
            `Deja tu firma (tu apodo) en el perfil de otro usuario.\n\n` +
            `*Uso:*\n` +
            `• .firmar @usuario\n` +
            `• .firmar apodo\n\n` +
            `*Ejemplo:*\n` +
            `.firmar @${senderNumber}\n` +
            `.firmar Juan`
        );
    }
    
    // Parsear el comando - solo necesitamos identificar al usuario objetivo
    let targetNumber = null;
    
    // Caso 1: Mencionó a alguien (@usuario)
    if (message.mentions && message.mentions.length > 0) {
        targetNumber = cleanNumber(message.mentions[0]);
    } 
    // Caso 2: Pasó un apodo o número
    else {
        const apodoOrNumber = text.trim();
        
        // Intentar buscar por apodo
        targetNumber = findUserByApodo(apodoOrNumber);
        
        // Si no encontró por apodo, intentar como número directo
        if (!targetNumber) {
            const cleanNum = cleanNumber(apodoOrNumber);
            if (cleanNum && cleanNum.length > 5) {
                targetNumber = cleanNum;
            }
        }
    }
    
    // Validaciones
    if (!targetNumber) {
        return await message.reply('❌ No se encontró ese usuario. Verifica el apodo o menciónalo.');
    }
    
    if (targetNumber === senderNumber) {
        return await message.reply('❌ No puedes firmarte a ti mismo.');
    }
    
    // Verificar que el usuario objetivo exista
    const targetApodo = getApodo(targetNumber);
    if (!targetApodo) {
        return await message.reply('❌ Ese usuario no tiene un apodo configurado y no puede recibir firmas.');
    }
    
    // Cargar firmas
    const firmasData = loadFirmas();
    
    // Inicializar estructura si no existe
    if (!firmasData[targetNumber]) {
        firmasData[targetNumber] = {
            apodo: targetApodo,
            firmas: []
        };
    }
    
    // Verificar si ya firmó este usuario
    const yaFirmo = firmasData[targetNumber].firmas.some(f => f.de === senderNumber);
    if (yaFirmo) {
        return await message.reply(`❌ Ya le dejaste una firma a *${targetApodo}*.\nSolo puedes dejar una firma por usuario.`);
    }
    
    // Agregar la firma (solo guardamos quién firmó, el apodo se obtiene dinámicamente)
    firmasData[targetNumber].firmas.push({
        de: senderNumber,
        fecha: Date.now()
    });
    
    // Actualizar apodo por si cambió
    firmasData[targetNumber].apodo = targetApodo;
    
    // Guardar
    if (!saveFirmas(firmasData)) {
        return await message.reply('❌ Error al guardar la firma. Intenta de nuevo.');
    }
    
    await message.reply(
        `✅ *Firma dejada exitosamente*\n\n` +
        `📝 Para: *${targetApodo}*\n` +
        `✍️ Firma de: *${senderApodo}*\n\n` +
        `_${targetApodo} ahora tiene ${firmasData[targetNumber].firmas.length} firma(s)_`
    );
}

// ============================================================================
// COMANDO: .firmas
// ============================================================================
async function comandoFirmas(message, { text, conn }) {
    const sock = conn || message._sock || global.conn;
    const senderNumber = cleanNumber(message.sender);
    
    // Cargar firmas
    const firmasData = loadFirmas();
    
    let targetNumber = null;
    let targetApodo = null;
    
    // Caso 1: Sin argumentos - ver firmas propias
    if (!text || text.trim() === '') {
        targetNumber = senderNumber;
        targetApodo = getApodo(senderNumber);
        
        if (!targetApodo) {
            return await message.reply('❌ No tienes un apodo configurado.\nUsa *.apodo tu_apodo* para configurar uno.');
        }
    }
    // Caso 2: Mencionó a alguien
    else if (message.mentions && message.mentions.length > 0) {
        targetNumber = cleanNumber(message.mentions[0]);
        targetApodo = getApodo(targetNumber);
        
        if (!targetApodo) {
            return await message.reply('❌ Ese usuario no tiene un apodo configurado.');
        }
    }
    // Caso 3: Pasó un apodo
    else {
        const apodoSearch = text.trim();
        targetNumber = findUserByApodo(apodoSearch);
        
        if (!targetNumber) {
            // Intentar como número directo
            const cleanNum = cleanNumber(apodoSearch);
            if (cleanNum && cleanNum.length > 5) {
                targetNumber = cleanNum;
            }
        }
        
        if (!targetNumber) {
            return await message.reply('❌ No se encontró ese usuario. Verifica el apodo o menciónalo.');
        }
        
        targetApodo = getApodo(targetNumber);
        if (!targetApodo) {
            return await message.reply('❌ Ese usuario no tiene un apodo configurado.');
        }
    }
    
    // Obtener firmas del usuario objetivo
    const userFirmas = firmasData[targetNumber];
    
    if (!userFirmas || !userFirmas.firmas || userFirmas.firmas.length === 0) {
        const esPropioUsuario = targetNumber === senderNumber;
        return await message.reply(
            esPropioUsuario 
                ? '📝 *TUS FIRMAS*\n\nAún no tienes firmas.\n\n_Los demás usuarios pueden dejarte firmas usando:_\n*.firmar tu_apodo Su mensaje aquí*'
                : `📝 *FIRMAS DE ${targetApodo}*\n\nEste usuario aún no tiene firmas.\n\n_Puedes dejarle una firma usando:_\n*.firmar ${targetApodo} Tu mensaje aquí*`
        );
    }
    
    // Construir mensaje con las firmas
    const esPropioUsuario = targetNumber === senderNumber;
    let mensaje = `📝 *${esPropioUsuario ? 'TUS FIRMAS' : `FIRMAS DE ${targetApodo.toUpperCase()}`}*\n\n`;
    mensaje += `👤 Usuario: *${targetApodo}*\n`;
    mensaje += `📊 Total de firmas: *${userFirmas.firmas.length}*\n\n`;
    
    // Ordenar firmas por fecha (más reciente primero)
    const firmasOrdenadas = [...userFirmas.firmas].sort((a, b) => b.fecha - a.fecha);
    
    // Mostrar las firmas
    firmasOrdenadas.forEach((firma, index) => {
        const apodoFirmante = getApodo(firma.de) || 'Usuario';
        const fecha = formatDate(firma.fecha);
        
        mensaje += `${index + 1}. ✍️ *${apodoFirmante}*\n`;
        mensaje += `   📅 ${fecha}\n\n`;
    });
    
    mensaje += `_Deja tu firma a otros usuarios con:_\n*.firmar @usuario Tu mensaje*`;
    
    await message.reply(mensaje);
}

// ============================================================================
// EXPORTAR HANDLERS
// ============================================================================
module.exports = {
    // Handler para .firmar
    firmar: {
        handler: comandoFirmar,
        help: ['firmar @usuario/apodo <texto>'],
        tags: ['social'],
        command: /^(firmar|sign)$/i,
        group: false
    },
    
    // Handler para .firmas
    firmas: {
        handler: comandoFirmas,
        help: ['firmas', 'firmas @usuario', 'firmas apodo'],
        tags: ['social'],
        command: /^(firmas|signatures|misfirmas)$/i,
        group: false
    }
};
