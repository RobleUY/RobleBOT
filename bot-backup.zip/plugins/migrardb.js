/**
 * Comando de administrador para migrar y fusionar datos duplicados
 */

let handler = async (message, { conn, isOwner }) => {
    try {
        // Verificar owner usando configuración centralizada
        const senderJid = message.author || message.sender;
        const groupId = message.isGroup ? message.from : null;
        
        // Cargar config si no está disponible
        if (!global.botConfig) {
            global.botConfig = require('./config.js');
        }
        
        const isRealOwner = isOwner || await global.botConfig.isOwnerJid(senderJid, groupId);
        
        if (!isRealOwner) {
            return await message.reply('❌ Este comando es solo para el propietario del bot.');
        }

        await message.reply('🔄 *INICIANDO MIGRACIÓN DE DATOS*\n\nEsto puede tardar unos segundos...');

        // Obtener estadísticas antes
        const statsBefore = global.db.getStats();
        
        console.log('📊 Estadísticas ANTES de la migración:');
        console.log(`   - Total usuarios: ${statsBefore.totalUsers}`);
        console.log(`   - Usuarios reales: ${statsBefore.realUsers}`);
        console.log(`   - IDs duplicados: ${statsBefore.idUsers}`);

        // Ejecutar migración
        const result = await global.db.migrateAndMergeData();

        // Obtener estadísticas después
        const statsAfter = global.db.getStats();

        let response = 
            `✅ *MIGRACIÓN COMPLETADA*\n\n` +
            `📊 *Resultados:*\n` +
            `━━━━━━━━━━━━━━\n\n` +
            `✨ Usuarios fusionados: *${result.merged}*\n` +
            `⚠️ IDs sin fusionar: *${result.remaining}*\n\n` +
            `📈 *Estadísticas:*\n` +
            `━━━━━━━━━━━━━━\n\n` +
            `*Antes:*\n` +
            `   • Total: ${statsBefore.totalUsers}\n` +
            `   • Reales: ${statsBefore.realUsers}\n` +
            `   • IDs: ${statsBefore.idUsers}\n\n` +
            `*Después:*\n` +
            `   • Total: ${statsAfter.totalUsers}\n` +
            `   • Reales: ${statsAfter.realUsers}\n` +
            `   • IDs: ${statsAfter.idUsers}\n\n` +
            `🔗 Mapeos creados: *${statsAfter.mappings}*\n\n`;

        if (result.remaining > 0) {
            response += `⚠️ *Nota:* Quedan ${result.remaining} IDs sin fusionar (no se encontró coincidencia por apodo).\n\n`;
            response += `Puedes usar */cleanids* para eliminarlos manualmente.`;
        }

        await message.reply(response);

    } catch (error) {
        console.error('❌ Error en migración:', error);
        await message.reply(`❌ *ERROR EN MIGRACIÓN*\n\n\`\`\`${error.message}\`\`\``);
    }
};

handler.help = ['migrate'];
handler.tags = ['owner'];
handler.command = /^(migrate|migrar|fusionar)$/i;
handler.owner = true;

module.exports = handler;