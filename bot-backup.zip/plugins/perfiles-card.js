const axios = require('axios');

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        await message.reply('Generando tu perfil... ⏳');

        // URL de tu API (que ahora sí responde con una imagen directa gracias al cambio en Vercel)
        const apiUrl = 'https://robleprofiles.vercel.app/api/userprofiledl?apodo=RobleUY&image=https://telegra.ph/file/a2ae6cbfa40f6eeea0cf1.jpg';

        // Descargamos el flujo de datos de la imagen directamente
        const imageResponse = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // Enviamos el Buffer original. WhatsApp lo recibirá limpio y listo para descargar en la galería.
        await sock.sendMessage(message.from, {
            image: imageBuffer,
            mimetype: 'image/png',
            caption: '¡Aquí tienes tu perfil editado! 🎬'
        }, { quoted: message._baileyMessage || message });

    } catch (error) {
        console.error('Error en el comando xddd:', error?.message || error);
        return await message.reply('Ocurrió un error al obtener la imagen de la API.');
    }
};

handler.help = ['xddd'];
handler.tags = ['imagenes', 'utilidades'];
handler.command = /^(xddd)$/i;

module.exports = handler;