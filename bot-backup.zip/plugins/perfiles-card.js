const sharp = require('sharp');
const fs = require('fs').promises; 
const path = require('path');
const db = require('../database.js');
const achievements = require('../achievements');

// --- CACHES EN MEMORIA PARA MÁXIMO RENDIMIENTO ---
let cachedPortrait = null;
let rankingCache = {
    lastUpdated: 0,
    list: []
};
const CACHE_DURATION = 3 * 60 * 1000; 

function escapeXml(unsafe) {
    if (!unsafe) return '';
    return unsafe.replace(/[<>&'"]/g, (c) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
            default: return c;
        }
    });
}

function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

function findUserByApodo(apodo) {
    const normalizedApodo = normalizeText(apodo);
    const allUsers = global.db.data.users || {};
    let partialMatch = null;
    
    for (const [jidOrKey, userData] of Object.entries(allUsers)) {
        if (userData?.apodo?.trim()) {
            const normalizedUserApodo = normalizeText(userData.apodo);
            if (normalizedUserApodo === normalizedApodo) {
                return { jid: jidOrKey, userData }; 
            }
            if (!partialMatch && (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo))) {
                partialMatch = { jid: jidOrKey, userData }; 
            }
        }
    }
    return partialMatch;
}

const formatNumber = (val) => {
    if (val === undefined || val === null) return '0';
    let str = String(val).trim();
    if (str.toLowerCase().includes('e')) {
        let parts = str.toLowerCase().split('e');
        let base = parseFloat(parts[0]);
        return !isNaN(base) ? base.toFixed(2) + 'e' + parts[1] : str;
    }
    if (/^\d+$/.test(str) && str.length > 15) {
        return `${str[0]},${str.slice(1, 3)}e+${str.length - 1}`;
    }
    let num = parseFloat(str);
    if (isNaN(num)) return str;
    if (num >= 1000000) {
        return new Intl.NumberFormat('es-ES', { notation: 'compact', compactDisplay: 'short', maximumFractionDigits: 1 }).format(num);
    }
    return num.toLocaleString('es-ES');
};

const cleanRankText = (rango) => {
    if (!rango) return 'NOVATO';
    return rango
        .replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F000}-\u{1F9FF}]/gu, '')
        .replace(/[^\x20-\x7E]/g, '') 
        .trim();
};

// Funciones auxiliares para pareja
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const inicio = new Date(fecha);
    const diferencia = ahora - inicio;
    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
    return { dias, horas, minutos };
}

function formatearFecha(fecha) {
    const d = new Date(fecha);
    return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
}

async function getPortraitBase64() {
    if (cachedPortrait !== null) return cachedPortrait;
    const localImagePath = path.join(__dirname, 'bot.jpeg');
    try {
        await fs.access(localImagePath); 
        const imageBuffer = await fs.readFile(localImagePath);
        cachedPortrait = `data:image/jpeg;base64,${imageBuffer.toString('base64')}`;
    } catch {
        cachedPortrait = ''; 
    }
    return cachedPortrait;
}

function getGlobalRanking(allUsers) {
    const now = Date.now();
    if (now - rankingCache.lastUpdated < CACHE_DURATION && rankingCache.list.length > 0) {
        return rankingCache.list;
    }
    
    const list = Object.entries(allUsers)
        .map(([key, u]) => {
            if (!u) return null;
            const num = key.split('@')[0].split(':')[0];
            return { key, num, total: (u.money || 0) + (u.bank || 0) };
        })
        .filter(u => u && u.total > 0)
        .sort((a, b) => b.total - a.total);
        
    rankingCache = { lastUpdated: now, list };
    return list;
}

let handler = async (message, { text, args, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const senderJid = message?.author || message?.sender || message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        
        let targetJid = senderJid;
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
        } else if (text?.trim() || args?.length > 0) {
            const apodoQuery = args?.length > 0 ? args.join(' ') : text.trim();
            const foundUser = findUserByApodo(apodoQuery);
            if (foundUser) {
                targetJid = foundUser.jid;
            } else {
                return await message.reply(`❌ No se encontró ningún usuario con el apodo "${apodoQuery}".`);
            }
        }
        
        if (!targetJid.includes('@')) {
            targetJid = targetJid + '@s.whatsapp.net';
        }

        let userData = db.getUser(targetJid);
        if (!userData) {
            const rawNumber = targetJid.split('@')[0].split(':')[0];
            userData = db.getUser(rawNumber);
        }
        
        if (!userData) {
            return await message.reply('❌ No se pudieron localizar los datos del usuario especificado en la Base de Datos.');
        }

        const apodo = userData.apodo?.trim() ? userData.apodo : 'Sin apodo';
        await message.reply(`*🔍 Generando tarjeta de perfil de ${apodo}...* ⏳`);

        const levelInfo = achievements.calculateLevel(userData.exp || 0);
        const dinero = userData.money || 0;
        const banco = userData.bank || 0;
        const totalMoney = dinero + banco;
        const respeto = userData.respeto || 0;
        const rangoLimpio = cleanRankText(userData.rango || 'Novato').toUpperCase();
        const genero = userData.genero || 'No definido';
        const deuda = (userData.prestamo?.activo && userData.prestamo?.deuda > 0) ? userData.prestamo.deuda : 0;
        const vecesTrabajadas = userData.totalWorkedTimes || 0;
        const comandosUsados = userData.ComandosEjecutados || 0;

        const allUsers = global.db.data.users || {};
        const targetRawNumber = targetJid.split('@')[0].split(':')[0];
        const globalRanking = getGlobalRanking(allUsers);
        
        const globalPos = globalRanking.findIndex(u => u.key === targetJid || u.num === targetRawNumber) + 1;
        const globalTotal = globalRanking.length;

        const portraitBase64 = await getPortraitBase64();
        const xpTotalSafe = levelInfo.xpTotal > 0 ? levelInfo.xpTotal : 1;
        const xpPercent = Math.max(0, Math.min(100, (levelInfo.xpActual / xpTotalSafe) * 100));
        const barWidth = 540;
        const fillWidth = (barWidth * xpPercent) / 100;

        const safeApodo = escapeXml(apodo);
        const safeRango = escapeXml(rangoLimpio);
        const displayGenero = (genero === 'No definido' || !genero) ? 'Género: No definido' : genero;
        const safeGenero = escapeXml(displayGenero);

        // Información de pareja (estado civil)
        let estadoCivilText = 'Soltero(a)';
        let parejaApodoSafe = '';
        let parejaTiempoText = '';
        try {
            const pareja = db.getPareja(targetRawNumber);
            if (pareja && pareja.estado === 'aceptado') {
                const partner = db.getUser(pareja.numero) || {};
                const partnerApodo = partner.apodo || 'Desconocido';
                const tiempo = tiempoTranscurrido(pareja.fecha);
                estadoCivilText = 'Casado(a)';
                parejaApodoSafe = escapeXml(partnerApodo);
                parejaTiempoText = `${tiempo.dias}d ${tiempo.horas}h ${tiempo.minutos}m`;
            }
        } catch (_) {}

        let avatarSvgElement = `
            <circle cx="205" cy="190" r="85" fill="#141938" stroke="url(#accentLine)" stroke-width="2"/>
            <text x="205" y="208" text-anchor="middle" fill="url(#accentLine)" font-family="system-ui, -apple-system, sans-serif" font-size="54" font-weight="800">${escapeXml(apodo.charAt(0).toUpperCase())}</text>
        `;
        if (portraitBase64) {
            avatarSvgElement = `
                <clipPath id="avatarClip"><circle cx="205" cy="190" r="85" /></clipPath>
                <circle cx="205" cy="190" r="91" fill="none" stroke="url(#accentLine)" stroke-width="2" filter="url(#glow)" opacity="0.6"/>
                <circle cx="205" cy="190" r="85" fill="#0B0E22" stroke="#FFFFFF" stroke-width="1.5" opacity="0.2"/>
                <image x="120" y="105" width="170" height="170" clip-path="url(#avatarClip)" href="${portraitBase64}" preserveAspectRatio="xMidYMid slice"/>
            `;
        }

        const svgTemplate = `
        <svg width="1060" height="660" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#060814"/>
              <stop offset="50%" stop-color="#0B0F26"/>
              <stop offset="100%" stop-color="#13183A"/>
            </linearGradient>
            <linearGradient id="sidebarGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#0D1233"/>
              <stop offset="100%" stop-color="#080B21"/>
            </linearGradient>
            <linearGradient id="accentLine" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#00F2FE"/>
              <stop offset="100%" stop-color="#4FACFE"/>
            </linearGradient>
            <linearGradient id="progressGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#00F2FE"/>
              <stop offset="50%" stop-color="#3B82F6"/>
              <stop offset="100%" stop-color="#9333EA"/>
            </linearGradient>
            <linearGradient id="cardGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#111640" stop-opacity="0.8"/>
              <stop offset="100%" stop-color="#171E54" stop-opacity="0.5"/>
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="1060" height="660" rx="28" fill="url(#bgGrad)" stroke="#1E265C" stroke-width="1.5"/>
          <circle cx="1060" cy="0" r="320" fill="none" stroke="#00F2FE" stroke-width="1" stroke-dasharray="5 10" opacity="0.1"/>
          <circle cx="0" cy="660" r="240" fill="none" stroke="#9333EA" stroke-width="1" opacity="0.15"/>
          <rect x="40" y="40" width="330" height="580" rx="20" fill="url(#sidebarGrad)" stroke="#1A2359" stroke-width="1.5"/>
          <path d="M40,70 L70,40 M340,40 L370,70 M40,590 L70,620 M340,620 L370,590" stroke="#00F2FE" stroke-width="1.5" opacity="0.4"/> 
          ${avatarSvgElement}
          <text x="205" y="320" text-anchor="middle" fill="#FFFFFF" font-family="system-ui, -apple-system, sans-serif" font-size="28" font-weight="800" letter-spacing="0.5">${safeApodo}</text>
          <text x="205" y="350" text-anchor="middle" fill="#A7B3C6" font-family="system-ui, -apple-system, sans-serif" font-size="14" font-weight="600">Estado: ${escapeXml(estadoCivilText)}</text>
          <text x="205" y="367" text-anchor="middle" fill="#8AA0C6" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="600">${parejaApodoSafe ? `Pareja: ${parejaApodoSafe} • ${parejaTiempoText}` : 'Sin pareja'}</text>
          <rect x="75" y="390" width="260" height="40" rx="12" fill="#18225C" stroke="url(#accentLine)" stroke-width="1" />
          <text x="205" y="420" text-anchor="middle" fill="#00F2FE" font-family="system-ui, -apple-system, sans-serif" font-size="13" font-weight="800" letter-spacing="2" filter="url(#glow)">${safeRango}</text>
          <rect x="115" y="435" width="180" height="32" rx="16" fill="#0B0F26" stroke="#1E296B" stroke-width="1"/>
          <text x="205" y="455" text-anchor="middle" fill="#8A99AD" font-family="system-ui, -apple-system, sans-serif" font-size="13" font-weight="600">${safeGenero}</text>
          <text x="205" y="550" text-anchor="middle" fill="#3B4F8C" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" letter-spacing="3">ROBLEBOT</text>
          <text x="205" y="570" text-anchor="middle" fill="#3B4F8C" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" letter-spacing="3">ESTADÍSTICAS DE USUARIO</text>
          <rect x="410" y="40" width="610" height="155" rx="20" fill="url(#cardGrad)" stroke="#1E265C" stroke-width="1"/>
          <text x="440" y="85" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="800" letter-spacing="1.5">RANGO DE EXPERIENCIA</text>
          <text x="440" y="145" fill="url(#accentLine)" font-family="system-ui, -apple-system, sans-serif" font-size="56" font-weight="900" filter="url(#glow)">LVL ${levelInfo.level}</text>
          <text x="980" y="85" text-anchor="end" fill="#E2E8F0" font-family="monospace" font-size="14" font-weight="700">${formatNumber(levelInfo.xpActual)} <tspan fill="#475569">/ ${formatNumber(levelInfo.xpTotal)} XP</tspan></text>
          <text x="980" y="135" text-anchor="end" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="600">Siguiente nivel en: ${formatNumber(levelInfo.xpFaltante)} XP</text>
          <rect x="440" y="160" width="540" height="12" rx="6" fill="#090D24" />
          <rect x="440" y="160" width="${fillWidth}" height="12" rx="6" fill="url(#progressGrad)" filter="url(#glow)"/>
          
          <g transform="translate(410, 215)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">DINERO EFECTIVO</text>
            <text x="60" y="72" fill="#FBBF24" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">$${formatNumber(dinero)}</text>
          </g>
          <g transform="translate(725, 215)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">RESERVAS BANCARIAS</text>
            <text x="60" y="72" fill="#60A5FA" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">$${formatNumber(banco)}</text>
          </g>
          <g transform="translate(410, 330)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">VALOR NETO TOTAL</text>
            <text x="60" y="72" fill="#34D399" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">$${formatNumber(totalMoney)}</text>
          </g>
          <g transform="translate(725, 330)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">DEUDA PENDIENTE</text>
            <text x="60" y="72" fill="#F87171" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">$${formatNumber(deuda)}</text>
          </g>
          <g transform="translate(410, 445)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">PUNTOS DE RESPETO</text>
            <text x="60" y="72" fill="#A78BFA" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">${formatNumber(respeto)}</text>
          </g>
          <g transform="translate(725, 445)">
            <rect width="295" height="95" rx="16" fill="url(#cardGrad)" stroke="#222D67" stroke-width="1"/>
            <text x="60" y="40" fill="#64748B" font-family="system-ui, -apple-system, sans-serif" font-size="11" font-weight="800" letter-spacing="1">TRABAJOS COMPLETADOS</text>
            <text x="60" y="72" fill="#FB923C" font-family="system-ui, -apple-system, sans-serif" font-size="24" font-weight="800">${formatNumber(vecesTrabajadas)}</text>
          </g>
          
          <rect x="410" y="565" width="610" height="55" rx="14" fill="#090D26" stroke="#1F285A" stroke-width="1.5"/>
          <circle cx="435" cy="592" r="4" fill="#22D3EE" filter="url(#glow)"/>
          <text x="450" y="597" fill="#22D3EE" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="800" letter-spacing="1">COMANDOS EJECUTADOS: <tspan fill="#FFFFFF" font-family="monospace" font-size="13">${formatNumber(comandosUsados)}</tspan></text>
          
          <rect x="715" y="577" width="1" height="30" fill="#1F285A" />
          <text x="990" y="597" text-anchor="end" fill="#FBBF24" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="800" letter-spacing="1">
            RANKING GLOBAL: 
            <tspan fill="#FFFFFF" font-family="monospace" font-size="13">#${globalPos > 0 ? formatNumber(globalPos) : '---'}</tspan> 
            <tspan fill="#E2E8F0" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="600"> DE ${formatNumber(globalTotal)}</tspan>
          </text>
        </svg>`;

        const imageBuffer = await sharp(Buffer.from(svgTemplate))
            .png()
            .toBuffer();

        const chatId = message.from || message.key?.remoteJid;
        const quotedMessage = message._baileyMessage || message.baileyMessage || message;
        const caption = `⚔️ *Tarjeta de Perfil de:* _${apodo}_`;

        await sock.sendMessage(
            chatId,
            { image: imageBuffer, caption: caption },
            { quoted: quotedMessage, mentions: [targetJid] }
        );

    } catch (error) {
        console.error('[ERROR] perfiles-card:', error);
        await message.reply('❌ Ocurrió un error inesperado al generar la tarjeta de perfil.');
    }
};

handler.help = ['perfil2', 'perfil2 @usuario', 'perfil2 <apodo>'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(perfil2|profile2|card2)$/i;

module.exports = handler;