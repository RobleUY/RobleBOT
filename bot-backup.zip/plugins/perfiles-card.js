const axios = require('axios');
const db = require('../database.js'); // Ajusta la ruta según tu estructura de carpetas

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    
    try {
        let apodoBuscar = '';

        // 1. Determinar qué apodo buscar basado en la entrada de texto o menciones
        if (message.mentionedJid && message.mentionedJid.length > 0) {
            // Si el usuario etiquetó a alguien (@user)
            const targetJid = message.mentionedJid[0];
            const targetId = targetJid.split('@')[0];
            const targetUser = db.getUser(targetId);

            if (!targetUser || !targetUser.apodo || targetUser.apodo === 'sin apodo') {
                return await message.reply('❌ El usuario mencionado no tiene un apodo registrado.');
            }
            apodoBuscar = targetUser.apodo;

        } else if (text && text.trim() !== '') {
            // Si el usuario escribió un apodo directamente (ej: .profile2 RobleBOT)
            apodoBuscar = text.trim();

        } else {
            // Si no escribió nada, intentamos buscar el apodo de quien ejecuta el comando
            const senderJid = message?.key?.participant || message?.key?.remoteJid;
            const senderId = senderJid.split('@')[0];
            const currentUser = db.getUser(senderId);

            if (!currentUser || !currentUser.apodo || currentUser.apodo === 'sin apodo') {
                return await message.reply('❌ No tienes un apodo registrado. Usa `.apodo TuApodo` primero o busca el de otra persona.');
            }
            apodoBuscar = currentUser.apodo;
        }

        // 2. Verificar de manera estricta (case-insensitive) si el apodo existe en la DB
        let apodoExiste = false;
        if (db.data && db.data.users) {
            const apodoLowerCase = apodoBuscar.toLowerCase();
            for (const [_, userData] of Object.entries(db.data.users)) {
                if (userData.apodo && userData.apodo.toLowerCase() === apodoLowerCase && userData.apodo !== 'sin apodo') {
                    apodoExiste = true;
                    // Aseguramos usar el apodo con sus mayúsculas/minúsculas correctas guardadas en DB
                    apodoBuscar = userData.apodo; 
                    break;
                }
            }
        }

        if (!apodoExiste) {
            return await message.reply(`❌ El apodo *${apodoBuscar}* no está registrado en el bot.`);
        }

        // 3. El apodo existe. Avisamos al usuario que se está procesando
        await message.reply('Generando tu tarjeta de perfil... ⏳');

        // 4. Construir la URL codificada correctamente para Microlink
        // encodeURIComponent se asegura de que caracteres especiales o espacios no rompan la URL de Microlink
        const encodedApodo = encodeURIComponent(apodoBuscar);
        const targetUrl = `https://robleprofiles.vercel.app/?apodo=${encodedApodo}&cardOnly=true&image=https://i.pinimg.com/originals/f2/6a/78/f26a78ebe5be61778dca3696faf05b28.jpg`;
        const microlinkUrl = `https://api.microlink.io/?url=${encodeURIComponent(targetUrl)}&screenshot=true&embed=screenshot.url`;

        // 5. Descargar la captura desde Microlink
        const imageResponse = await axios.get(microlinkUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // 6. Enviar la imagen limpia por WhatsApp
        await sock.sendMessage(message.from, {
            image: imageBuffer,
            mimetype: 'image/png',
            caption: `🎭 ¡Aquí tienes el perfil de *${apodoBuscar}*!`
        }, { quoted: message._baileyMessage || message });

    } catch (error) {
        console.error('Error en el comando profile2:', error?.message || error);
        return await message.reply('Ocurrió un error al obtener la imagen de la API de Microlink.');
    }
};

handler.help = ['profile2 [arroba / apodo]'];
handler.tags = ['imagenes', 'utilidades'];
handler.command = /^(profile2)$/i;

module.exports = handler;