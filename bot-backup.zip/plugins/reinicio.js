// plugins/reinicio.js
const moment = require('moment-timezone');

let handler = async (message) => {
    const RESTART_INTERVAL_MS = 2 * 60 * 60 * 1000; // 2 horas
    const now = Date.now();
    let targetTime = global._nextRestartTime;

    if (!targetTime || targetTime <= now) {
        // Fallback: calcular en base a process.uptime()
        const uptimeMs = process.uptime() * 1000;
        const elapsedInCycle = uptimeMs % RESTART_INTERVAL_MS;
        const remainingMs = RESTART_INTERVAL_MS - elapsedInCycle;
        targetTime = now + remainingMs;
    }

    const diffMs = Math.max(0, targetTime - now);
    const totalSeconds = Math.floor(diffMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const timeParts = [];
    if (hours > 0) timeParts.push(`${hours}h`);
    if (minutes > 0 || hours > 0) timeParts.push(`${minutes}m`);
    timeParts.push(`${seconds}s`);
    const countdownStr = timeParts.join(' ');

    const nextMoment = moment.tz(targetTime, 'America/Montevideo');
    const timeFormatted = nextMoment.format('HH:mm:ss');

    const responseText = 
        `🔄 *PRÓXIMO REINICIO AUTOMÁTICO*\n\n` +
        `⏱️ *Tiempo restante:* _${countdownStr}_\n` +
        `🔁 *Frecuencia:* _Cada 2 horas_`;

    await message.reply(responseText);
};

handler.help = ['reinicio', 'proximoreinicio'];
handler.tags = ['info'];
handler.command = /^(reinicio|proximoreinicio)$/i;

module.exports = handler;
