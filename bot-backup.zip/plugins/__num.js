'use strict';
/**
 * Plugin .getnum
 * Muestra al usuario su número de WhatsApp en formato internacional.
 * Solo funciona en chat privado.
 * Maneja JIDs @lid (IDs internos de Meta) resolviéndolos al número real.
 */

/**
 * Intenta resolver un JID @lid al número real de WhatsApp.
 * Busca en los contactos/chats cacheados por Baileys.
 */
function resolveRealNumber(jid, sock) {
    try {
        // Si ya es un JID normal con número, extraer directo
        if (jid.endsWith('@s.whatsapp.net')) {
            return jid.split('@')[0].split(':')[0];
        }

        // Si es @lid, intentar resolverlo
        if (jid.includes('@lid')) {
            console.log(`[getnum] JID es @lid, intentando resolver...`);

            // Método 1: buscar en sock.store si existe
            if (sock?.store?.contacts) {
                const contacts = sock.store.contacts;
                for (const [contactJid, contact] of Object.entries(contacts)) {
                    if (contact?.lid === jid || contactJid === jid) {
                        if (contactJid.endsWith('@s.whatsapp.net')) {
                            const num = contactJid.split('@')[0].split(':')[0];
                            console.log(`[getnum] Resuelto via sock.store.contacts: ${jid} → ${num}`);
                            return num;
                        }
                    }
                }
            }

            // Método 2: buscar en global.db si tenés base de datos con contactos
            if (global.db?.data?.users) {
                for (const [userJid, userData] of Object.entries(global.db.data.users)) {
                    if (userData?.lid === jid) {
                        const num = userJid.split('@')[0].split(':')[0];
                        console.log(`[getnum] Resuelto via db.users: ${jid} → ${num}`);
                        return num;
                    }
                }
            }

            // Método 3: buscar en contactos del conn principal
            if (global.conn?.store?.contacts) {
                const contacts = global.conn.store.contacts;
                for (const [contactJid, contact] of Object.entries(contacts)) {
                    if (contact?.lid === jid || contactJid === jid) {
                        if (contactJid.endsWith('@s.whatsapp.net')) {
                            const num = contactJid.split('@')[0].split(':')[0];
                            console.log(`[getnum] Resuelto via conn.store.contacts: ${jid} → ${num}`);
                            return num;
                        }
                    }
                }
            }

            console.log(`[getnum] No se pudo resolver @lid: ${jid}`);
            return null;
        }

        // Otro formato desconocido
        console.log(`[getnum] Formato de JID desconocido: ${jid}`);
        return null;

    } catch (e) {
        console.error(`[getnum] Error en resolveRealNumber:`, e.message);
        return null;
    }
}

const getnumHandler = {
    command: /^getnum$/i,
    help: 'Obtener tu número en formato internacional. Uso: .getnum (solo en privado)',
    tags: ['utilidades'],
    handler: async (message) => {
        const conn = global.conn;

        // Solo en chat privado
        if (message.isGroup) {
            console.log(`[getnum] Intento de uso en grupo: ${message.from}`);
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        try {
            const senderJid = message.author || message.sender || message.from;
            console.log(`[getnum] senderJid raw: ${senderJid}`);
            console.log(`[getnum] message.from: ${message.from}`);
            console.log(`[getnum] message.sender: ${message.sender}`);
            console.log(`[getnum] message.author: ${message.author}`);

            if (!senderJid) {
                console.log(`[getnum] Error: no se obtuvo ningún JID`);
                return conn.sendMessage(message.from, {
                    text: '❌ No se pudo obtener tu JID. Intenta de nuevo.'
                }, { quoted: message._baileyMessage });
            }

            // Intentar obtener el número real
            const sock = message._sock || global.conn;
            let rawNumber = resolveRealNumber(senderJid, sock);

            // Fallback: en chat privado, el message.from ES el JID del usuario
            if (!rawNumber && message.from && message.from.endsWith('@s.whatsapp.net')) {
                rawNumber = message.from.split('@')[0].split(':')[0];
                console.log(`[getnum] Fallback via message.from: ${rawNumber}`);
            }

            if (!rawNumber) {
                console.log(`[getnum] No se pudo resolver el número para JID: ${senderJid}`);
                return conn.sendMessage(message.from, {
                    text: '⚠️ No se pudo obtener tu número automáticamente.\n\n' +
                          'Podés encontrarlo en WhatsApp:\n' +
                          '*Configuración → Perfil → tu número aparece arriba*'
                }, { quoted: message._baileyMessage });
            }

            const waLink = `wa.me/+${rawNumber}`;
            console.log(`[getnum] ✅ Número resuelto: +${rawNumber} para JID: ${senderJid}`);

            await conn.sendMessage(message.from, {
                text: `📱 *Tu número de WhatsApp*\n\n` +
                      `Número: *+${rawNumber}*\n` +
                      `Formato sin +: *${rawNumber}*\n` +
                      `Link directo: ${waLink}`
            }, { quoted: message._baileyMessage });

        } catch (e) {
            console.error(`[getnum] Error inesperado:`, e.message, e.stack);
            conn.sendMessage(message.from, {
                text: '❌ Ocurrió un error al obtener tu número. Intenta de nuevo.'
            }, { quoted: message._baileyMessage }).catch(() => {});
        }
    }
};

module.exports = {
    command: getnumHandler.command,
    help:    getnumHandler.help,
    tags:    getnumHandler.tags,
    handler: getnumHandler.handler,
};