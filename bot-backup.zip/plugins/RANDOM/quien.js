// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    // Solo toma la parte del número y quita todo lo que no sea dígito
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

// Función para obtener un número de elementos al azar de un array (solo necesitamos 1)
const getRandomElement = (arr) => {
    if (arr.length === 0) return null;
    const rand = Math.floor(Math.random() * arr.length);
    return arr[rand];
};

let handler = async (message, { text }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        if (!global.conn) {
            return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
        }

        // 1. Obtener el texto que sigue al comando (la pregunta o el rol)
        if (!text) {
             return await message.reply('⚠️ Por favor, escribe un texto luego del comando. Ejemplo: `.quien es el más feo`');
        }
        
        // El texto es lo que se le "asigna" al usuario
        const roleText = text.trim();

        // 2. Obtener metadatos del grupo
        const groupMetadata = await global.conn.groupMetadata(message.from);
        
        // Obtener participantes, excluyendo al bot
        const allParticipants = groupMetadata.participants
            .map(p => p.id)
            .filter(jid => normalizeNumber(jid) !== normalizeNumber(global.conn.user.id)); 

        if (allParticipants.length === 0) {
             return await message.reply(`⚠️ No hay otros usuarios en el grupo para seleccionar.`);
        }

        // 3. Seleccionar 1 usuario al azar
        const chosenJid = getRandomElement(allParticipants);
        const chosenNumber = normalizeNumber(chosenJid);

        // 4. Crear el mensaje dinámico
        
        // La pregunta se usa en el mensaje
        let responseText = `*QUIEN ${roleText.toUpperCase()}?*\n\n`;
        responseText += `👉 Respuesta: *@${chosenNumber}*`;

        // Enviar el mensaje con la mención
        await message.reply(responseText, { mentions: [chosenJid] });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando .quien:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al intentar responder la pregunta.');
    }
};

// --- Configuración del Handler ---

handler.help = ['quien'];
handler.tags = ['fun']; 
handler.command = /^(quien)$/i; // Comando fijo: 'quien'
handler.group = true;

module.exports = handler;