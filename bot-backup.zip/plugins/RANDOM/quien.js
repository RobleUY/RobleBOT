const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

const getRandomElement = (arr) => {
    if (arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
};

let handler = async (message, { text }) => {
    try {
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        if (!text) {
            return await message.reply('⚠️ Por favor, escribe un texto luego del comando. Ejemplo: `.quien es el más feo`');
        }

        // Usar el socket del mensaje (subbot o principal), con fallback a cualquier conn activa
        const activeSock = message._sock || global.conn
            || (global.subConns || []).find(c => c?.user) || null;

        if (!activeSock) {
            return await message.reply('❌ No hay ningún bot conectado disponible.');
        }

        const roleText = text.trim();

        // groupMetadata usando el bot que recibió el mensaje
        const groupMetadata = await activeSock.groupMetadata(message.from);

        // Excluir al bot que está respondiendo (si tiene user)
        const myNumber = activeSock.user?.id ? normalizeNumber(activeSock.user.id) : null;

        const allParticipants = groupMetadata.participants
            .map(p => p.id)
            .filter(jid => !myNumber || normalizeNumber(jid) !== myNumber);

        if (allParticipants.length === 0) {
            return await message.reply('⚠️ No hay otros usuarios en el grupo para seleccionar.');
        }

        const chosenJid    = getRandomElement(allParticipants);
        const chosenNumber = normalizeNumber(chosenJid);

        let responseText = `*QUIEN ${roleText.toUpperCase()}?*\n\n`;
        responseText += `👉 Respuesta: *@${chosenNumber}*`;

        await message.reply(responseText, { mentions: [chosenJid] });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando .quien:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al intentar responder la pregunta.');
    }
};

handler.help  = ['quien'];
handler.tags  = ['fun'];
handler.command = /^(qui[eé]n)$/i;
handler.group = true;

module.exports = handler;
