// drama.js
let handler = async (message, { text }) => {
    try {
        const dramaLevel = (Math.random() * 100).toFixed(2);

        let result = "";
        if (dramaLevel < 10) result = "😐 Frío como un témpano. Nada te altera.";
        else if (dramaLevel < 25) result = "🙂 Ligeramente dramático, pero aún funcional.";
        else if (dramaLevel < 50) result = "😅 Sabes hacer una escena, pero con moderación.";
        else if (dramaLevel < 70) result = "🎭 Nivel telenovela básica. Puedes llorar con estilo.";
        else if (dramaLevel < 85) result = "🔥 Drama en sangre. Cada día es un capítulo nuevo.";
        else if (dramaLevel < 95) result = "💋 Drama Queen/King oficial. Nadie te supera.";
        else result = "💀 Nivel Shakesperiano: si no mueres al final, no es tu historia.";

        await message.reply(`🎭 *Nivel de Drama:* ${dramaLevel}%\n${result}`);
    } catch (error) {
        console.error('Error en comando drama:', error);
        await message.reply('❌ No se pudo calcular tu nivel de drama.');
    }
};

handler.help = ['drama'];
handler.tags = ['fun'];
handler.command = /^(drama)$/i;

module.exports = handler;
