let handler = async (message, { conn }) => {
    try {
        const frames = [
            '8====👊===D',
            '8==👊=====D',
            '8====👊===D',
            '8==👊=====D',
            '8=====👊==D',
            '8==👊=====D',
            '8======👊=D',
            '8==👊=====D',
            '8=======👊D💨🥵'
        ];
        
        // Enviar el mensaje inicial con el primer frame
        const sentMsg = await conn.sendMessage(message.from, { 
            text: frames[0]
        });
        
        // Esperar un momento antes de empezar a editar
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Editar el mensaje para cada frame restante
        for (let i = 1; i < frames.length; i++) {
            await conn.sendMessage(message.from, {
                text: frames[i],
                edit: sentMsg.key
            });
            
            // Esperar 500ms entre cada frame para la animación
            await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        console.log('\x1b[32m[SUCCESS] Animación completada\x1b[0m');
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando test:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al ejecutar el test.');
    }
};

handler.help = ['paja'];
handler.tags = ['paja'];
handler.command = /^(paja)$/i;

module.exports = handler;