let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const frames = [
            '8====👊===D',
            '8==👊=====D',
            '8======👊=D',
            '8=======👊D💨',
            '8=======👊D  💨'
        ];

        // 👤 Obtener JID del emisor
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');
        const senderNumber = senderJid.split('@')[0];

        // 🔍 Detectar mención o texto libre
        const mentionedJids = message?.mentions;
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, '').trim();
        }

        // 🏷️ Armar header y lista de menciones para el mensaje de animación
        // IMPORTANTE: @número debe ir sin asteriscos alrededor para que Baileys lo linkee
        let header = '';
        let mentions = [senderJid];

        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            header = `@${senderNumber} le está haciendo una paja a @${targetNumber} 🤭\n\n`;
            mentions = [senderJid, targetJid];
        } else if (extraText) {
            header = `@${senderNumber} le está haciendo una paja a ${extraText} 🤭\n\n`;
        } else {
            header = `@${senderNumber} se está haciendo una paja 🤭\n\n`;
        }

        // 📤 Primer frame
        const sentMsg = await sock.sendMessage(
            message.from,
            { text: header + frames[0], mentions },
            { quoted: message._baileyMessage || message }
        );

        // 🎞️ Animar frames editando el mismo mensaje
        for (let i = 1; i < frames.length; i++) {
            await new Promise(r => setTimeout(r, 1200));
            try {
                await sock.sendMessage(message.from, {
                    text: header + frames[i],
                    edit: sentMsg.key,
                    mentions
                });
            } catch (err) {
                console.warn('[PAJA] Error editando frame (animación cancelada):', err?.message || err);
                break;
            }
        }

        // 💬 Mensaje final solo si se la hicieron a alguien
        if (targetJid || extraText) {
            await new Promise(r => setTimeout(r, 1000));

            let finishMsg = '';
            let finishMentions = [senderJid];

            if (targetJid) {
                const targetNumber = targetJid.split('@')[0];
                finishMsg = `@${targetNumber} ¿disfrutaste la paja que te hizo @${senderNumber}? 😏`;
                finishMentions = [targetJid, senderJid];
            } else {
                finishMsg = `${extraText} ¿disfrutaste la paja que te hizo @${senderNumber}? 😏`;
            }

            try {
                await sock.sendMessage(
                    message.from,
                    { text: finishMsg, mentions: finishMentions },
                    { quoted: message._baileyMessage || message }
                );
            } catch (_) {}
        }

        console.log('\x1b[32m[SUCCESS] Animación de paja completada\x1b[0m');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando paja:', error?.message || error, '\x1b[0m');
        if (!error?.message?.includes('Rate limit') && !error?.message?.includes('rate-overlimit')) {
            await message.reply('❌ Ocurrió un error al ejecutar el comando.').catch(() => {});
        }
    }
};

handler.help = ['paja'];
handler.tags = ['paja'];
handler.command = /^(paja)$/i;

module.exports = handler;