// quiero.js — versión ultra simple, sin adornos ni menciones extra
let handler = async (message, { text }) => {
    try {
        const desire = text?.trim();
        if (!desire) {
            return await message.reply('💭 Debes decir qué quieres.\nEjemplo: */quiero ser feliz*');
        }

        // Probabilidad aleatoria (0–100%)
        const chance = (Math.random() * 100).toFixed(2);

        // Respuesta directa
        const reply = `💭 ${desire}\n📊 Probabilidad: ${chance}%`;

        await message.reply(reply, { mentions: message?.mentions || [] });
    } catch (error) {
        console.error('[ERROR en comando quiero]:', error);
        await message.reply('❌ Ocurrió un error al procesar tu deseo.');
    }
};

handler.help = ['quiero <texto>'];
handler.tags = ['fun'];
handler.command = /^(quiero)$/i;

module.exports = handler;
