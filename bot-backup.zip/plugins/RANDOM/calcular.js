// calcular.js
let handler = async (message, { command, text }) => {
    try {
        const input = (text || '').trim();

        if (!input) {
            return await message.reply(`✳️ Debes ingresar un texto para calcular.\n\nEjemplo:\n/${command} inteligencia`);
        }

        // Número aleatorio del 1 al 100
        const valor = Math.floor(Math.random() * 100) + 1;

        let respuesta = '';
        if (command === 'calcular1') {
            respuesta = `*Resultado del cálculo:* ${valor}%`;
        } else if (command === 'calcular2') {
            respuesta = `*Resultado del cálculo:* ${valor} CM`;
        } else if (command === 'calcular3') {
            respuesta = `*Resultado del cálculo:* ${valor}/100`;
        }

        await message.reply(respuesta);

    } catch (error) {
        console.error('\x1b[31m[ERROR] en comando calcular:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al calcular.');
    }
};

handler.help = ['calcular1 <texto>', 'calcular2 <texto>', 'calcular3 <texto>'];
handler.tags = ['fun'];
handler.command = /^(calcular1|calcular2|calcular3)$/i;

module.exports = handler;
