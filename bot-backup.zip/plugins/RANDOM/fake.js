/**
 * fake.js
 * Comando: fake / fakereply / fitnah
 * Envía un mensaje "falso" como si lo hubiera escrito otro usuario y luego borra el comando.
 */

let handler = async (message, { conn, text, usedPrefix, command }) => {
    // util
    const sleep = ms => new Promise(res => setTimeout(res, ms));

    try {
        // 0. Validaciones básicas
        if (!message.isGroup) return await message.reply('❌ Este comando solo funciona en grupos.');
        if (!text) return await message.reply(`❌ Uso: ${usedPrefix || '.'}${command} hola @<numero> texto\nEjemplo: ${usedPrefix || '.'}${command} oye @5989... qué tal?`);

        // 1. Detectar la mención objetivo (who)
        const mentionedJids = message.mentions || [];
        let who = (mentionedJids.length > 0 ? mentionedJids[0] : null);
        if (!who) {
            const m = text.match(/@(\d{5,16})/);
            if (m) who = `${m[1]}@s.whatsapp.net`;
        }
        if (!who) return await message.reply('❌ Debes mencionar a un usuario (ej: @5989...)');

        // 2. Separar texto antes y después de la mención
        const sp = '@' + who.split('@')[0];
        const [fakePart, ...realParts] = text.split(sp);
        const fakeText = (fakePart || '').trim();
        const realText = (realParts.join(sp) || '').trim();

        // 3. parseMention fallback
        const parseMention = typeof conn.parseMention === 'function'
            ? conn.parseMention
            : (t = '') => [...t.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net');

        // 4. Enviar fakeReply (usar conn.fakeReply si existe)
        let sentFakeResult = null;
        try {
            if (typeof conn.fakeReply === 'function') {
                // -> método recomendado (tu setup lo tenía antes y funcionaba)
                sentFakeResult = await conn.fakeReply(
                    message.from,
                    realText || '(sin texto)',
                    who,
                    fakeText || '(sin texto)',
                    message.isGroup ? message.from : false,
                    { contextInfo: { mentionedJid: realText ? parseMention(realText) : [] } }
                );
            } else {
                // fallback: enviar como mensaje "reenviado" si fakeReply no existe
                sentFakeResult = await conn.sendMessage(message.from, {
                    text: realText || fakeText || '(sin texto)',
                    contextInfo: { mentionedJid: realText ? parseMention(realText) : [], forwardingScore: 999, isForwarded: true }
                });
            }
            console.log('[SUCCESS] Fake enviado correctamente (await). Resultado:', !!sentFakeResult);
        } catch (eSend) {
            console.error('[ERROR] Falló conn.fakeReply / fallback:', eSend);
            // intentar enviar al menos un texto simple para no romper el flujo
            try {
                sentFakeResult = await conn.sendMessage(message.from, {
                    text: realText || fakeText || '(sin texto)',
                    contextInfo: { mentionedJid: realText ? parseMention(realText) : [] }
                });
                console.log('[SUCCESS] Fallback: texto enviado.');
            } catch (e2) {
                console.error('[ERROR] Fallback también falló:', e2);
                return await message.reply('❌ No pude enviar el fake. Revisa logs del bot.');
            }
        }

        // 5. Esperar un momento para asegurarnos que el mensaje fue "procesado" por el servidor
        await sleep(150); // 0.45s, ajustar si hace falta

        // 6. Lógica robusta para detectar si el BOT es admin (copiada y mejorada de tu .borrar)
        async function findBotParticipant(groupMetadata, conn) {
            const botJid = conn.user?.id || conn.user?.jid || '';
            // posibles formas del número base del bot
            const possibleBotNumbers = [
                botJid.split(':')[0].split('@')[0],
                botJid.split('@')[0].split(':')[0]
            ].filter(Boolean);

            console.log('[DEBUG] conn.user.id/jid:', botJid, '-> posibles:', possibleBotNumbers);

            // primera pasada: comparar número base exacto
            let botParticipant = groupMetadata.participants.find(p => {
                const participantNumber = (p.id || '').split('@')[0].split(':')[0];
                return possibleBotNumbers.includes(participantNumber);
            });

            // segunda pasada: includes parcial
            if (!botParticipant) {
                botParticipant = groupMetadata.participants.find(p => {
                    return possibleBotNumbers.some(nb => (p.id || '').includes(nb));
                });
            }

            // tercera pasada (fallback): buscar cualquier @lid admin (multi-device sessions suelen usar @lid)
            if (!botParticipant) {
                botParticipant = groupMetadata.participants.find(p => {
                    return (p.id || '').includes('@lid') && (!!p.admin || !!p.isAdmin);
                });
            }

            // Determinar admin de forma amplia
            const botIsAdmin = !!botParticipant && (
                botParticipant.admin === 'admin' ||
                botParticipant.admin === 'superadmin' ||
                botParticipant.isAdmin === true ||
                botParticipant.role === 'admin' // por si alguna versión usa role
            );

            console.log('[DEBUG] Bot participant encontrado:', botParticipant?.id || 'N/A', ' admin?:', botIsAdmin);
            return { botParticipant, botIsAdmin, possibleBotNumbers };
        }

        // obtener metadata y chequear admin
        const groupMetadata = await conn.groupMetadata(message.from);
        const { botIsAdmin, botParticipant, possibleBotNumbers } = await findBotParticipant(groupMetadata, conn);

        if (!botIsAdmin) {
            // No somos admin -> no podemos borrar mensajes de otros. Pero ya enviamos el fake.
            console.log('[INFO] Bot no es admin, omitiendo borrado del activador.');
            return; // termina aquí (no intentar borrar)
        }

        // 7. Intentar borrar el mensaje activador (comando)
        try {
            // primer intento directo
            await conn.sendMessage(message.from, { delete: message.key });
            console.log('[SUCCESS] Mensaje activador eliminado (directo).');
            return;
        } catch (errDelete) {
            console.warn('[WARN] Eliminación directa falló:', errDelete && errDelete.message ? errDelete.message : errDelete);
            // intentar con key alternativa (reconstruida)
            try {
                const altKey = {
                    remoteJid: message.from,
                    id: message.key?.id || message.key?.key?.id || (message.key && message.key.id) || '',
                    participant: message.key?.participant || message.sender || (message.key && message.key.participant) || undefined,
                    fromMe: message.key?.fromMe || false
                };
                console.log('[DEBUG] Intentando eliminar con altKey:', JSON.stringify(altKey));
                await conn.sendMessage(message.from, { delete: altKey });
                console.log('[SUCCESS] Mensaje activador eliminado (altKey).');
                return;
            } catch (altErr) {
                console.error('[ERROR] Alt deletion falló:', altErr);
                // último recurso: reconstruir usando la info del mensaje enviado por el bot (por si hay IDs disponibles)
                try {
                    // si el mensaje de comando tiene key.id, usarlo; si no, no hay mucho más que podamos hacer.
                    const finalAlt = {
                        remoteJid: message.from,
                        id: message.key?.id || message.key?.key?.id || '',
                        participant: message.sender || undefined,
                        fromMe: false
                    };
                    await conn.sendMessage(message.from, { delete: finalAlt });
                    console.log('[SUCCESS] Mensaje activador eliminado (finalAlt).');
                    return;
                } catch (finalErr) {
                    console.error('[ERROR] No se pudo eliminar el mensaje activador con ninguna técnica:', finalErr);
                    // No devolvemos mensaje al chat para no spamear; se ve en logs.
                    return;
                }
            }
        }

    } catch (err) {
        console.error('[FATAL] Error en handler .fake:', err);
        try { await message.reply('❌ Ocurrió un error al ejecutar el comando `.fake`. Revisa logs.'); } catch {}
    }
};

// handler config
handler.help = ['fake <texto> @usuario <texto2>'];
handler.tags = ['herramientas'];
handler.command = /^(fake|z|fakereply|fitnah|falso)$/i;
handler.group = true;
// NO forzamos handler.admin = true aquí; si querés restringir a admins ponlo en true
module.exports = handler;
