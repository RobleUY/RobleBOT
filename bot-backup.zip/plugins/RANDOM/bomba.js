let handler = async (message, { conn, args, text }) => {
    const bombardero_jid = message.key.participant || message.key.remoteJid;
    const bombardero_numero = bombardero_jid.split('@')[0];

    const texto_objetivo = text.trim();
    if (!texto_objetivo) {
        return message.reply('❌ Debes especificar el texto o usuario a bombardear. Ejemplo: */bombardear este lugar* o */bombardear @usuario*');
    }

    const mentionedJids = message.mentions || []; 
    const menciones_finales = [bombardero_jid, ...mentionedJids];

    let texto_mostrado = texto_objetivo;
    if (mentionedJids.length > 0) {
        for (let jid of mentionedJids) {
            const numero = jid.split('@')[0];
            texto_mostrado = texto_mostrado.replace(/@\d+/, `@${numero}`);
        }
    }

    const mensaje_explosion_final = `💥🔥 *${texto_mostrado}* fue **completamente destruido** por *@${bombardero_numero}* 🔥💥`;

    try {
        const frames = [
            `✈️💨\n\nApuntando a *${texto_mostrado}*...`,
            `🚀💨\n\nEl misil está en camino hacia *${texto_mostrado}*...`,
            `💣\n\nBajando...\n\n${texto_mostrado}`,
            `💣\n💨\n\nMás cerca...\n\n${texto_mostrado}`,
            `💣\n🔥\n\n¡IMPACTO INMINENTE!\n\n${texto_mostrado}`,
            `☁️☁️☁️\n💥 BOOOM 💥\n☁️☁️☁️\n\n${texto_mostrado}`
        ];

        // Primer frame
        const sentMsg = await conn.sendMessage(message.from, { 
            text: frames[0],
            mentions: menciones_finales
        });
        const msgKey = sentMsg.key;

        // Animación
        for (let i = 1; i < frames.length; i++) {
            await new Promise(r => setTimeout(r, 800)); 
            await conn.sendMessage(message.from, {
                text: frames[i],
                edit: msgKey,
                mentions: menciones_finales
            });
        }

        // Esperar un poco para el mensaje final
        await new Promise(r => setTimeout(r, 1200));

        await message.reply(mensaje_explosion_final, { 
            mentions: menciones_finales
        });

        console.log(`[SUCCESS] Bombardeo completado sobre: ${texto_objetivo} por @${bombardero_numero}`);

    } catch (error) {
        console.error('[ERROR] en comando bombardear:', error);
        await message.reply('❌ Ocurrió un error al ejecutar la animación. Intenta de nuevo.');
    }
};

handler.help = ['bombardear <texto/mención>'];
handler.tags = ['diversion'];
handler.command = /^(bombardear)$/i;

module.exports = handler;
