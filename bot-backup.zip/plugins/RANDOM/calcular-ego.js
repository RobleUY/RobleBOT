// ego.js
let handler = async (message, { text }) => {
    try {
        const egoLevel = (Math.random() * 100).toFixed(2);

        let result = "";
        if (egoLevel < 15) result = "🫥 Casi sin ego. Nivel monje tibetano.";
        else if (egoLevel < 30) result = "🙂 Humilde, pero sabes lo que vales.";
        else if (egoLevel < 50) result = "😌 Equilibrado: te quieres lo justo.";
        else if (egoLevel < 70) result = "😏 Te gustas bastante, y se nota.";
        else if (egoLevel < 85) result = "😎 Alto ego detectado, pero te queda bien.";
        else if (egoLevel < 95) result = "🤴 Egocénico profesional, probablemente con selfie abierta.";
        else result = "🪞 Narcisismo legendario. El espejo te aplaude.";

        await message.reply(`🧠 *Nivel de Ego:* ${egoLevel}%\n${result}`);
    } catch (error) {
        console.error('Error en comando ego:', error);
        await message.reply('❌ No se pudo calcular tu nivel de ego.');
    }
};

handler.help = ['ego'];
handler.tags = ['fun'];
handler.command = /^(ego)$/i;

module.exports = handler;
