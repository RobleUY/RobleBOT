let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const frames = [
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄',    
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
        ];
        
        // Enviar el mensaje inicial con el primer frame
        const sentMsg = await sock.sendMessage(message.from, { 
            text: frames[0]
        });
        
        // Esperar un momento breve antes de empezar a editar (reduje a 300ms para que sea más rápida)
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Editar el mensaje para cada frame restante
        for (let i = 1; i < frames.length; i++) {
            await sock.sendMessage(message.from, {
                text: frames[i],
                edit: sentMsg.key
            });
            
            // Esperar solo 200ms entre cada frame para que la animación sea más rápida
            await new Promise(resolve => setTimeout(resolve, 200));
        }
        
        console.log('\x1b[32m[SUCCESS] Animación completada\x1b[0m');
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando oral:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al ejecutar el comando oral.');
    }
};

handler.help = ['oral'];
handler.tags = ['oral'];
handler.command = /^(oral)$/i;

module.exports = handler;
