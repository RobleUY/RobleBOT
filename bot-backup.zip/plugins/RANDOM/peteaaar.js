let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const frames = [
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄',    
            '8==========D  👄',  
            '8=====Dㅤㅤㅤㅤ👄', 
            '8==========D  👄💦'
        ];
        
        // Enviar el mensaje inicial con el primer frame
        const sentMsg = await sock.sendMessage(message.from, { 
            text: frames[0]
        });
        
        // Editar el mensaje para cada frame restante
        for (let i = 1; i < frames.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 1200));
            try {
                await sock.sendMessage(message.from, {
                    text: frames[i],
                    edit: sentMsg.key
                });
            } catch (err) {
                console.warn('[ORAL] Error editando frame (animación cancelada):', err?.message || err);
                break;
            }
        }
        
        console.log('\x1b[32m[SUCCESS] Animación completada\x1b[0m');
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando oral:', error?.message || error, '\x1b[0m');
        if (!error?.message?.includes('Rate limit') && !error?.message?.includes('rate-overlimit')) {
            await message.reply('❌ Ocurrió un error al ejecutar el comando oral.').catch(() => {});
        }
    }
};

handler.help = ['oral'];
handler.tags = ['oral'];
handler.command = /^(oral)$/i;

module.exports = handler;
