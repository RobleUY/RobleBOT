// plugins/temporada.js

let handler = async (message) => {
    try {
        const now = new Date();

        // Hora actual en Uruguay (UTC-3)
        const uruguayOffsetMs = -3 * 60 * 60 * 1000;
        const utcTimeMs = now.getTime() + (now.getTimezoneOffset() * 60000);
        const uruguayNow = new Date(utcTimeMs + uruguayOffsetMs);

        const currentYear = uruguayNow.getUTCFullYear();
        const currentMonth = uruguayNow.getUTCMonth();

        // Próximo reset de temporada: Día 1 de cada mes a las 00:05:00 (Uruguay UTC-3)
        let nextResetUruguay = new Date(Date.UTC(currentYear, currentMonth, 1, 0, 5, 0));

        // Si ya pasó las 00:05 del día 1 del mes actual:
        if (uruguayNow.getTime() >= nextResetUruguay.getTime()) {
            nextResetUruguay = new Date(Date.UTC(currentYear, currentMonth + 1, 1, 0, 5, 0));
        }

        // Timestamp del próximo reset en tiempo real
        const nextResetRealTimeMs = nextResetUruguay.getTime() - uruguayOffsetMs;

        const diffMs = Math.max(0, nextResetRealTimeMs - now.getTime());
        const totalSeconds = Math.floor(diffMs / 1000);

        const days = Math.floor(totalSeconds / (3600 * 24));
        const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        const timeParts = [];
        if (days > 0) timeParts.push(`*${days}* día${days !== 1 ? 's' : ''}`);
        if (hours > 0 || days > 0) timeParts.push(`*${hours}* hora${hours !== 1 ? 's' : ''}`);
        if (minutes > 0 || hours > 0 || days > 0) timeParts.push(`*${minutes}* minuto${minutes !== 1 ? 's' : ''}`);
        timeParts.push(`*${seconds}* segundo${seconds !== 1 ? 's' : ''}`);

        const countdownStr = timeParts.join(', ');

        const targetDateObj = new Date(nextResetRealTimeMs);
        const dateFormatted = targetDateObj.toLocaleString('es-UY', {
            timeZone: 'America/Montevideo',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        const responseText = 
            `🏆 *RESET DE TEMPORADA*\n\n` +
            `⏱️ *Tiempo restante:*\n${countdownStr}\n\n` +
            `📅 *Fecha de reinicio:*\n_${dateFormatted} (Hora Uruguay)_`;

        await message.reply(responseText);
    } catch (error) {
        console.error('[ERROR] Error en plugin temporada:', error);
        await message.reply('❌ Ocurrió un error al calcular el tiempo para el reset de temporada.');
    }
};

handler.help = ['temporada', 'season'];
handler.tags = ['info'];
handler.command = /^(temporada|season|tiempotemporada)$/i;

module.exports = handler;
