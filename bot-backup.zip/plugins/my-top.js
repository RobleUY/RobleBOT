const normalizeNumber = (jidPart) => (jidPart || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!message.isGroup)
            return await message.reply('❌ Este comando solo puede usarse en grupos.');

        // Obtener texto del comando
        const body = message.body?.trim() || '';
        const args = body.split(/\s+/);
        args.shift(); // quitar el comando
        const topTitle = args.join(' ').trim();

        if (!topTitle)
            return await message.reply('⚠️ Usa el formato: *mytop <texto>*\nEjemplo: *mytop infieles del grupo*');

        const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];

        // Obtener los participantes del grupo
        const metadata = await conn.groupMetadata(message.from);
        const participants = metadata.participants.map(p => p.id);

        if (participants.length === 0)
            return await message.reply('⚠️ No hay participantes en este grupo.');

        // Mezclar aleatoriamente los jugadores y tomar 10
        const shuffled = participants
            .map(id => ({ id, sort: Math.random() }))
            .sort((a, b) => a.sort - b.sort)
            .slice(0, 10)
            .map(p => p.id);

        // Crear el texto del top
        let text = `*🏆 TOP ${topTitle.toUpperCase()} 🏆*\n\n`;

        shuffled.forEach((jid, i) => {
            const number = normalizeNumber(jid);
            const medal = medals[i] || `${i + 1}️⃣`;
            text += `${medal} @${number}\n`;
        });

        // Enviar mensaje con menciones
        await message.reply(text, { mentions: shuffled });

    } catch (err) {
        console.error('[ERROR EN MYTOP RANDOM]:', err);
        await message.reply('⚠️ Error al generar el top aleatorio.');
    }
};

handler.help = ['mytop <texto>'];
handler.tags = ['fun', 'group'];
handler.command = /^mytop|mitop$/i;
handler.group = true;

module.exports = handler;
