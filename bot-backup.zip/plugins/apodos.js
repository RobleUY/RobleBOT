const db = require('../database.js'); // Ajusta la ruta según tu estructura

// Handler principal
let handler = async (message, { text, args }) => {
    try {
        // Obtener el sender correctamente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const sender = senderJid.split('@')[0];
        const user = db.getUser(sender);
        
        if (!user) {
            return await message.reply('❌ Error al acceder a la base de datos.');
        }
        
        console.log('Usuario obtenido:', sender);
        console.log('Apodo actual en DB:', user.apodo);
        
        // Si el usuario no proporcionó texto, mostrar apodo actual o instrucciones
        if (!text || text.trim() === '') {
            if (user.apodo && user.apodo.trim() !== '') {
                return await message.reply(`🎭 Tu apodo actual es: *${user.apodo}*\n\n💡 Para cambiarlo usa: \`.apodo Tu Nuevo Apodo\`\n📏 Máximo 30 caracteres`);
            } else {
                return await message.reply(`🎭 Aún no tienes apodo.\n\n💡 Usa: \`.apodo Tu Apodo Aquí\`\n📏 Máximo 30 caracteres\n✨ Puedes usar emojis y lo que quieras`);
            }
        }
        
        // El usuario proporcionó un apodo personalizado
        const apodoPersonalizado = text.trim();
        
        // Validar longitud máxima de 30 caracteres
        if (apodoPersonalizado.length > 30) {
            return await message.reply(`❌ El apodo es muy largo (${apodoPersonalizado.length} caracteres)\n\n📏 Máximo: 30 caracteres\n💡 Intenta con algo más corto`);
        }
        
        console.log('Apodo personalizado:', apodoPersonalizado);
        
        // Actualizar en la base de datos
        user.apodo = apodoPersonalizado;
        const success = db.setUser(sender, user);
        
        if (!success) {
            console.error('Error al guardar en la base de datos');
            return await message.reply('❌ Error al guardar el apodo en la base de datos.');
        }
        
        // Verificar que se guardó correctamente
        const verificacion = db.getUser(sender);
        console.log('Apodo después de guardar:', verificacion.apodo);
        
        if (!verificacion.apodo || verificacion.apodo !== apodoPersonalizado) {
            console.error('El apodo no se guardó correctamente');
            return await message.reply('❌ Error: El apodo no se guardó correctamente. Intenta de nuevo.');
        }
        
        // Respuestas épicas aleatorias
        const respuestas = [
            `🎊 *¡PERFECTO!* 🎊\n\n🎭 Tu nuevo apodo es:\n*${apodoPersonalizado}*`,
            `⚡ *¡APODO GUARDADO!* ⚡\n\n🎭 Ahora eres:\n*${apodoPersonalizado}*`,
            `🔮 *¡HECHO!* 🔮\n\n🎭 Tu identidad es:\n*${apodoPersonalizado}*`,
            `🎯 *¡CONFIRMADO!* 🎯\n\n🎭 De ahora en adelante serás:\n*${apodoPersonalizado}*`,
            `✅ *¡ACTUALIZADO!* ✅\n\n🎭 Tu apodo oficial es:\n*${apodoPersonalizado}*`
        ];
        
        const respuestaAleatoria = respuestas[Math.floor(Math.random() * respuestas.length)];
        
        return await message.reply(respuestaAleatoria);
        
    } catch (error) {
        console.error('Error en comando apodo:', error);
        return await message.reply('❌ Ocurrió un error al procesar tu apodo. ¡Inténtalo de nuevo!');
    }
};

handler.help = ['apodo [tu apodo]'];
handler.tags = ['fun', 'juegos'];
handler.command = /^(apodo|nickname|alias)$/i;

module.exports = handler;