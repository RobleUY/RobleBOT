const db = require('../database.js'); // Ajusta la ruta según tu estructura

// Handler principal
let handler = async (message, { text, args }) => {
    try {
        // ========== VALIDACIÓN CRÍTICA DE LONGITUD AL INICIO ==========
        // ESTA VALIDACIÓN SE EJECUTA ANTES QUE CUALQUIER OTRA COSA
        // APLICA PARA TODOS: USUARIOS, ADMINS, OWNERS - SIN EXCEPCIONES
        if (text && text.trim().length > 30) {
            const longitudActual = text.trim().length;
            return await message.reply(`❌ *APODO RECHAZADO* ❌\n\n📏 Longitud: *${longitudActual} caracteres*\n📏 Máximo: *30 caracteres*\n\n⚠️ Esta regla aplica para TODOS sin excepción.\n💡 Intenta con algo más corto.`);
        }
        // ================================================================
        
        // Obtener el sender correctamente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const sender = senderJid.split('@')[0];
        const user = db.getUser(sender);
        
        if (!user) {
            return await message.reply('❌ Error al acceder a la base de datos.');
        }
        
        // Si no hay texto, mostrar apodo actual o instrucciones
        if (!text || text.trim() === '') {
            if (user.apodo && user.apodo.trim() !== '' && user.apodo !== 'sin apodo') {
                return await message.reply(`🎭 Tu apodo actual es: *${user.apodo}*\n\n💡 Para cambiarlo usa: \`.apodo TuNuevoApodo\`\n📏 Máximo 30 caracteres\n🚫 No se permiten espacios.`);
            } else {
                return await message.reply(`🎭 Aún no tienes apodo.\n\n💡 Usa: \`.apodo TuApodoAqui\`\n📏 Máximo 30 caracteres\n🚫 No se permiten espacios.`);
            }
        }
        
        const apodoPersonalizado = text.trim();
        
        // ========== VALIDACIÓN DE LONGITUD (MÁXIMO 30 CARACTERES) ==========
        // ESTA VALIDACIÓN ES OBLIGATORIA PARA TODOS (ADMINS, OWNERS, USUARIOS)
        if (apodoPersonalizado.length > 30) {
            return await message.reply(`❌ *APODO DEMASIADO LARGO* ❌\n\n📏 Longitud actual: *${apodoPersonalizado.length} caracteres*\n📏 Máximo permitido: *30 caracteres*\n\n💡 Intenta con algo más corto.`);
        }
        
        // Verificar que no tenga espacios
        if (/\s/.test(apodoPersonalizado)) {
            return await message.reply(`🚫 El apodo no puede contener espacios.\n\nEjemplo válido: \`.apodo El_Pro_123\`\nEjemplo inválido: ❌ \`.apodo El Pro 123\``);
        }
        
        // ========== VALIDACIÓN DE APODO ÚNICO ==========
        // Acceder directamente a db.data.users para verificar duplicados
        if (db.data && db.data.users) {
            const apodoLowerCase = apodoPersonalizado.toLowerCase();
            
            for (const [userId, userData] of Object.entries(db.data.users)) {
                // Ignorar el usuario actual
                if (userId === sender) continue;
                
                // Verificar si otro usuario tiene el mismo apodo (case-insensitive)
                if (userData.apodo && 
                    userData.apodo.toLowerCase() === apodoLowerCase &&
                    userData.apodo !== 'sin apodo') {
                    return await message.reply(`❌ *¡APODO NO DISPONIBLE!* ❌\n\n🚫 El apodo *${apodoPersonalizado}* ya está siendo usado por otro usuario.\n\n💡 Por favor elige otro apodo único.`);
                }
            }
        }
        // ================================================
        
        // Actualizar en la base de datos
        user.apodo = apodoPersonalizado;
        const success = db.setUser(sender, user);
        
        if (!success) {
            console.error('Error al guardar en la base de datos');
            return await message.reply('❌ Error al guardar el apodo en la base de datos.');
        }
        
        const verificacion = db.getUser(sender);
        
        if (!verificacion.apodo || verificacion.apodo !== apodoPersonalizado) {
            console.error('El apodo no se guardó correctamente');
            return await message.reply('❌ Error: El apodo no se guardó correctamente. Intenta de nuevo.');
        }
        
        // Respuestas aleatorias
        const respuestas = [
            `🎊 *¡PERFECTO!* 🎊\n\n🎭 Tu nuevo apodo es:\n*${apodoPersonalizado}*\n\n✨ ¡Es único y solo tuyo!`,
            `⚡ *¡APODO GUARDADO!* ⚡\n\n🎭 Ahora eres:\n*${apodoPersonalizado}*\n\n🌟 Nadie más puede usar este apodo`,
            `🔮 *¡HECHO!* 🔮\n\n🎭 Tu identidad es:\n*${apodoPersonalizado}*\n\n🎯 Apodo único registrado`,
            `🎯 *¡CONFIRMADO!* 🎯\n\n🎭 De ahora en adelante serás:\n*${apodoPersonalizado}*\n\n� Exclusivo para ti`,
            `✅ *¡ACTUALIZADO!* ✅\n\n🎭 Tu apodo oficial es:\n*${apodoPersonalizado}*\n\n🏆 Registrado exitosamente`
        ];
        
        const respuestaAleatoria = respuestas[Math.floor(Math.random() * respuestas.length)];
        
        return await message.reply(respuestaAleatoria);
        
    } catch (error) {
        console.error('Error en comando apodo:', error);
        return await message.reply('❌ Ocurrió un error al procesar tu apodo. ¡Inténtalo de nuevo!');
    }
};

handler.help = ['apodo [tu apodo]'];
handler.tags = ['fun', 'juegos'];
handler.command = /^(apodo|nickname|alias)$/i;
handler.group = true;

module.exports = handler;