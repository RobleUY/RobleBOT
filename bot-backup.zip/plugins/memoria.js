// plugins/memoria.js
// Comando para verificar el uso de memoria RAM del bot

const { getMonitorStatus } = require('../memoryMonitor');

let handler = async (message) => {
    try {
        const status = getMonitorStatus();
        const memory = status.currentMemory;
        
        const responseText = 
            `📊 *ESTADO DE MEMORIA RAM*\n\n` +
            `🔹 *Uso actual:* ${memory.rssGB} GB\n` +
            `🎯 *Umbral de reinicio:* ${status.thresholdGB} GB\n` +
            `📈 *Porcentaje usado:* ${status.percentageUsed}%\n\n` +
            `📦 *Detalles técnicos:*\n` +
            `   • RSS Total: ${memory.rssGB} GB\n` +
            `   • Heap Used: ${memory.heapUsedGB} GB\n` +
            `   • Heap Total: ${memory.heapTotalGB} GB\n\n` +
            `🛡️ *Monitor:* ${status.isActive ? '✅ Activo' : '❌ Inactivo'}\n` +
            `${status.isRestarting ? '⚠️ *Reinicio en progreso...*' : ''}` +
            `\n💡 *Nota:* El bot se reiniciará automáticamente al superar ${status.thresholdGB} GB`;

        await message.reply(responseText);
    } catch (error) {
        await message.reply('❌ Error al obtener información de memoria: ' + error.message);
    }
};

handler.help = ['memoria', 'ram', 'memstatus'];
handler.tags = ['info'];
handler.command = /^(memoria|ram|memstatus)$/i;

module.exports = handler;
