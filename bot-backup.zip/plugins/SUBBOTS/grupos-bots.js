/**
 * Plugin para listar todos los grupos donde están los bots
 * Comando: .gruposbots / .botsgrupos
 */

const gruposBotsHandler = {
    command: /^(gruposbots|botsgrupos)$/i,
    help: ['gruposbots', 'botsgrupos'],
    tags: ['subbots', 'info'],
    handler: async (message, _p) => {
        const conn = global.conn;
        
        await message.reply('⏳ *Obteniendo lista de grupos...*');

        const allGroups = [];

        // Obtener grupos del bot principal
        if (conn?.user) {
            const mainPhoneNum = conn.user.id.split('@')[0].split(':')[0];
            try {
                const chats = await conn.groupFetchAllParticipating();
                const groups = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                });

                for (const group of groups) {
                    allGroups.push({
                        bot: 'Principal',
                        botNumber: mainPhoneNum,
                        name: group.subject || 'Sin nombre',
                        jid: group.id,
                        participants: group.participants?.length || 0
                    });
                }
            } catch (e) {
                console.error('[gruposbots] Error obteniendo grupos del bot principal:', e.message);
            }
        }

        // Obtener grupos de los subbots
        const activeSubBots = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        
        for (const subBot of activeSubBots) {
            const phoneNum = subBot.user.id.split('@')[0].split(':')[0];
            try {
                const chats = await subBot.groupFetchAllParticipating();
                const groups = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                });

                for (const group of groups) {
                    allGroups.push({
                        bot: `SubBot #${subBot._subNum}`,
                        botNumber: phoneNum,
                        name: group.subject || 'Sin nombre',
                        jid: group.id,
                        participants: group.participants?.length || 0
                    });
                }
            } catch (e) {
                console.error(`[gruposbots] Error obteniendo grupos del subbot #${subBot._subNum}:`, e.message);
            }
        }

        if (allGroups.length === 0) {
            return await message.reply('📭 *No hay grupos registrados.*');
        }

        // Agrupar por bot
        const groupedByBot = {};
        for (const group of allGroups) {
            if (!groupedByBot[group.bot]) {
                groupedByBot[group.bot] = {
                    botNumber: group.botNumber,
                    groups: []
                };
            }
            groupedByBot[group.bot].groups.push(group);
        }

        // Construir mensaje
        let mensaje = `📊 *GRUPOS DE LOS BOTS* 📊\n`;
        mensaje += `━━━━━━━━━━━━━━━━━━━━\n\n`;
        mensaje += `🤖 *Total de bots:* ${Object.keys(groupedByBot).length}\n`;
        mensaje += `👥 *Total de grupos:* ${allGroups.length}\n\n`;
        mensaje += `━━━━━━━━━━━━━━━━━━━━\n\n`;

        for (const [botName, data] of Object.entries(groupedByBot)) {
            mensaje += `🟢 *${botName}*\n`;
            mensaje += `📱 wa.me/+${data.botNumber}\n`;
            mensaje += `👥 *${data.groups.length} grupo(s)*\n\n`;
        }

        mensaje += `━━━━━━━━━━━━━━━━━━━━\n`;
        mensaje += `_Usa .bots para ver solo la lista de bots_`;

        await message.reply(mensaje);
    }
};

module.exports = {
    command: gruposBotsHandler.command,
    help: gruposBotsHandler.help,
    tags: gruposBotsHandler.tags,
    handler: gruposBotsHandler.handler
};
