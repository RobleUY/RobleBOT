'use strict';

/**
 * Comando .gofcbots
 * Hace que todos los subbots conectados envíen un mensaje al grupo.
 * Dedup por messageId evita ejecución doble si varios bots reciben el comando.
 * Solo owners.
 */

const executedMessages = new Set();

const handler = async (message) => {
    try {
        // ── Dedup: solo el primer bot que llega lo ejecuta ────────────────────
        const msgId = message.id || message.key?.id;
        if (msgId && executedMessages.has(msgId)) return;
        if (msgId) {
            executedMessages.add(msgId);
            setTimeout(() => executedMessages.delete(msgId), 30000);
        }

        const botConfig = global.botConfig || require('../../config');
        const chatId = message.from;

        // ── Solo owners ───────────────────────────────────────────────────────
        const senderNum = (message.author || message.sender || '')
            .split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Solo los primeros 3 subbots conectados ────────────────────────────
        const subConns = (global.subConns || []).filter(c => c?.user && c._subNum != null).slice(0, 3);

        if (subConns.length === 0) {
            return await message.reply('⚠️ No hay subbots conectados.');
        }

        // ── Cada subbot manda su mensaje al grupo ─────────────────────────────
        let ok = 0;
        for (const subSock of subConns) {
            try {
                const num   = subSock._subNum;
                const phone = subSock.user?.id?.split('@')[0]?.split(':')[0] || '???';
                await subSock.sendMessage(chatId, {
                    text: `🤖 *Bot #${num}* — estoy aquí ✅\n📱 _${phone}_`
                });
                ok++;
                await new Promise(r => setTimeout(r, 600));
            } catch (e) {
                console.error(`[gofcbots] Error subbot #${subSock._subNum}:`, e.message);
            }
        }

        await message.reply(`✅ *${ok}* subbot${ok !== 1 ? 's' : ''} respondieron.`);

    } catch (error) {
        console.error('[gofcbots] Error general:', error.message);
        await message.reply('❌ Error interno.');
    }
};

handler.help    = ['gofcbots'];
handler.tags    = ['owner', 'subbots'];
handler.command = /^gofcbots$/i;
handler.owner   = true;

module.exports = handler;
