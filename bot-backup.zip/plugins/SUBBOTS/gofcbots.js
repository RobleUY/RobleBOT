'use strict';

/**
 * Comando .gofcbots
 * ─────────────────────────────────────────────────────────────────────────────
 * Cuando se usa en el grupo oficial, TODOS los subbots conectados en ese grupo
 * responden identificándose, independientemente de si están en la lista blanca.
 *
 * El resto de comandos sigue con el comportamiento normal (solo responden los
 * de la lista blanca). Este comando es la única excepción.
 *
 * Solo ejecutable por owners.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const handler = async (message) => {
    try {
        const botConfig = global.botConfig || require('../../config');
        const sock = message._sock || global.conn;

        // ── Solo owners ───────────────────────────────────────────────────────
        const senderNum = (message.author || message.sender || '')
            .split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Cada subbot (o el bot principal) responde con su identidad ────────
        const isSubbot = !!message._subNum;

        if (isSubbot) {
            const num   = message._subNum;
            const phone = sock?.user?.id?.split('@')[0]?.split(':')[0] || '???';
            return await message.reply(`🤖 *Bot #${num}* — estoy aquí ✅\n📱 _${phone}_`);
        } else {
            // Es el bot principal — responde también
            const phone = sock?.user?.id?.split('@')[0]?.split(':')[0] || '???';
            return await message.reply(`🤖 *Bot principal* — estoy aquí ✅\n📱 _${phone}_`);
        }

    } catch (error) {
        console.error('[gofcbots] Error:', error.message);
    }
};

handler.help    = ['gofcbots'];
handler.tags    = ['owner', 'subbots'];
handler.command = /^gofcbots$/i;
handler.owner   = true;

module.exports = handler;
