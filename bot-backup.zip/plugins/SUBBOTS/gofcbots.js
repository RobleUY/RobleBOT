'use strict';

/**
 * Comando .gofcbots
 * Hace que hasta 3 subbots conectados presentes en este chat envíen un mensaje de confirmación.
 * Recorre todos los subbots conectados y prueba enviar hasta que un máximo de 3 tengan éxito.
 * Dedup por messageId evita ejecución doble si varios bots reciben el comando.
 * Solo owners.
 */

const executedMessages = new Set();

const handler = async (message) => {
    try {
        // ── Dedup: solo la primera instancia del bot que llega lo ejecuta ─────
        const msgId = message.id || message.key?.id;
        if (msgId && executedMessages.has(msgId)) return;
        if (msgId) {
            executedMessages.add(msgId);
            setTimeout(() => executedMessages.delete(msgId), 30000);
        }

        const botConfig = global.botConfig || require('../../config');
        const chatId = message.from || message.key?.remoteJid;
        if (!chatId) return;

        // ── Solo owners ───────────────────────────────────────────────────────
        const senderNum = (message.author || message.sender || message.from || '')
            .split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Filtrar todos los subbots conectados ──────────────────────────────
        const activeSubConns = (global.subConns || []).filter(c => c && c.user && c._subNum != null);

        if (activeSubConns.length === 0) {
            return await message.reply('⚠️ No hay subbots conectados.');
        }

        // ── Recorrer subbots conectados hasta que respondan hasta 3 en este chat ──
        let ok = 0;
        const maxBots = 3;

        for (const subSock of activeSubConns) {
            if (ok >= maxBots) break;

            try {
                const num   = subSock._subNum;
                const phone = subSock.user?.id?.split('@')[0]?.split(':')[0] || '???';

                await subSock.sendMessage(chatId, {
                    text: `🤖 *Bot #${num}* — estoy aquí ✅\n📱 _+${phone}_`
                });

                ok++;
                await new Promise(r => setTimeout(r, 600));
            } catch (e) {
                // Si el subbot no pertenece al grupo o falla el envío, continua probando con el siguiente subbot
            }
        }

        if (ok === 0) {
            return await message.reply('⚠️ Hay subbots conectados, pero ninguno de ellos está presente en este chat/grupo para responder.');
        }

        await message.reply(`✅ *${ok}* subbot${ok !== 1 ? 's' : ''} respondieron.`);

    } catch (error) {
        console.error('[gofcbots] Error general:', error.message);
        await message.reply('❌ Error interno.');
    }
};

handler.help    = ['gofcbots'];
handler.tags    = ['owner', 'subbots'];
handler.command = /^gofcbots$/i;
handler.owner   = true;

module.exports = handler;
