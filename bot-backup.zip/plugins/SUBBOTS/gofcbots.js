'use strict';

/**
 * Comando .gofcbots
 * ─────────────────────────────────────────────────────────────────────────────
 * Solo ejecutable por el bot principal (subbots lo ignoran para evitar dobles).
 * Busca qué subbots de global.subConns están en el grupo donde se ejecutó,
 * y los hace enviar un mensaje identificándose.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { getGroupMetadataCached } = require('../../lib/groupCache');

const handler = async (message) => {
    try {
        // ── Si lo recibe un subbot, ignorar — solo el principal lo ejecuta ───
        if (message._subNum) return;

        const botConfig = global.botConfig || require('../../config');
        const chatId = message.from;

        // ── Solo owners ───────────────────────────────────────────────────────
        const senderNum = (message.author || message.sender || '')
            .split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Obtener participantes del grupo ───────────────────────────────────
        const sock = message._sock || global.conn;
        let participants = [];
        try {
            const meta = await getGroupMetadataCached(sock, chatId, 0); // 0 = forzar refresco
            participants = meta?.participants || [];
        } catch (e) {
            console.error('[gofcbots] Error obteniendo participantes:', e.message);
            return await message.reply('❌ No pude obtener la lista de participantes del grupo.');
        }

        // Números de los participantes (limpios, solo dígitos)
        const participantNums = new Set(
            participants.map(p => p.id.split('@')[0].split(':')[0].replace(/\D/g, ''))
        );

        // ── Filtrar subbots conectados que estén en el grupo ──────────────────
        const subConns = (global.subConns || []).filter(c => {
            if (!c?.user || c._subNum == null) return false;
            const phone = c.user.id?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '') || '';
            return participantNums.has(phone);
        });

        if (subConns.length === 0) {
            return await message.reply('⚠️ No hay subbots conectados en este grupo.');
        }

        await message.reply(`🔔 Haciendo que *${subConns.length}* subbot${subConns.length > 1 ? 's' : ''} respondan...`);

        // ── Cada subbot envía su mensaje directamente al grupo ────────────────
        let ok = 0;
        for (const subSock of subConns) {
            try {
                const num   = subSock._subNum;
                const phone = subSock.user?.id?.split('@')[0]?.split(':')[0] || '???';
                await subSock.sendMessage(chatId, {
                    text: `🤖 *Bot #${num}* — estoy aquí ✅\n📱 _${phone}_`
                });
                ok++;
                await new Promise(r => setTimeout(r, 600));
            } catch (e) {
                console.error(`[gofcbots] Error subbot #${subSock._subNum}:`, e.message);
            }
        }

        await message.reply(`✅ *${ok}/${subConns.length}* subbots respondieron.`);

    } catch (error) {
        console.error('[gofcbots] Error general:', error.message);
        await message.reply('❌ Error interno.');
    }
};

handler.help    = ['gofcbots'];
handler.tags    = ['owner', 'subbots'];
handler.command = /^gofcbots$/i;
handler.owner   = true;

module.exports = handler;
