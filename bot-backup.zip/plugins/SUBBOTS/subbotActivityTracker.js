'use strict';

const fs   = require('fs');
const path = require('path');

// ── Directorio y archivo de datos ────────────────────────────────────────────
const DATA_DIR       = path.join(__dirname, 'data');
const ACTIVITY_FILE  = path.join(DATA_DIR, 'subbots-actividad.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Caché en memoria para evitar lecturas constantes ─────────────────────────
let _activityCache = null;
let _activityMtime = 0;

/**
 * Carga el archivo de actividad de subbots
 * Formato: { "num": { "lastUsed": timestamp, "commandCount": number } }
 */
function loadActivity() {
    try {
        if (fs.existsSync(ACTIVITY_FILE)) {
            const mtime = fs.statSync(ACTIVITY_FILE).mtimeMs;
            if (_activityCache !== null && mtime === _activityMtime) {
                return _activityCache;
            }
            _activityCache = JSON.parse(fs.readFileSync(ACTIVITY_FILE, 'utf8'));
            _activityMtime = mtime;
            return _activityCache;
        }
    } catch (e) {
        console.error('[SubBot Activity] Error cargando actividad.json:', e.message);
    }
    _activityCache = {};
    return _activityCache;
}

let _saveActivityTimeout = null;

function saveActivity(data, immediate = false) {
    _activityCache = data;
    if (immediate) {
        if (_saveActivityTimeout) {
            clearTimeout(_saveActivityTimeout);
            _saveActivityTimeout = null;
        }
        try {
            fs.writeFileSync(ACTIVITY_FILE, JSON.stringify(data, null, 2), 'utf8');
            if (fs.existsSync(ACTIVITY_FILE)) _activityMtime = fs.statSync(ACTIVITY_FILE).mtimeMs;
            return true;
        } catch (e) {
            console.error('[SubBot Activity] Error guardando actividad.json:', e.message);
            return false;
        }
    }

    if (_saveActivityTimeout) return true;

    _saveActivityTimeout = setTimeout(() => {
        _saveActivityTimeout = null;
        try {
            if (_activityCache) {
                fs.writeFileSync(ACTIVITY_FILE, JSON.stringify(_activityCache, null, 2), 'utf8');
                if (fs.existsSync(ACTIVITY_FILE)) _activityMtime = fs.statSync(ACTIVITY_FILE).mtimeMs;
            }
        } catch (e) {
            console.error('[SubBot Activity] Error guardando actividad.json:', e.message);
        }
    }, 15000);

    return true;
}

/**
 * Registra el uso de un comando en un subbot
 */
function recordActivity(subbotNum) {
    if (!subbotNum) return;
    
    const data = loadActivity();
    const key  = String(subbotNum);
    
    if (!data[key]) {
        data[key] = {
            lastUsed: Date.now(),
            commandCount: 1
        };
    } else {
        data[key].lastUsed = Date.now();
        data[key].commandCount = (data[key].commandCount || 0) + 1;
    }
    
    saveActivity(data, false);
}

/**
 * Obtiene la lista de subbots ordenados por total de usos (más usado primero).
 * En caso de empate, prioriza el más recientemente activo.
 * Los subbots sin historial van al final.
 * @param {number[]} subbotNums - Array de números de subbots disponibles
 * @returns {number[]} - Array ordenado por cantidad de usos totales
 */
function getSortedByActivity(subbotNums) {
    const data = loadActivity();

    return [...subbotNums].sort((a, b) => {
        const aData = data[String(a)] || { commandCount: 0, lastUsed: 0 };
        const bData = data[String(b)] || { commandCount: 0, lastUsed: 0 };

        const aCount = aData.commandCount || 0;
        const bCount = bData.commandCount || 0;

        // Primero: más comandos ejecutados en total (más activo primero)
        if (bCount !== aCount) return bCount - aCount;

        // Segundo criterio (desempate): más recientemente usado
        return (bData.lastUsed || 0) - (aData.lastUsed || 0);
    });
}

/**
 * Obtiene estadísticas de actividad de un subbot específico
 */
function getActivityStats(subbotNum) {
    const data = loadActivity();
    const key  = String(subbotNum);
    
    if (!data[key]) {
        return {
            lastUsed: null,
            commandCount: 0,
            daysSinceLastUse: null
        };
    }
    
    const lastUsed = data[key].lastUsed;
    const now = Date.now();
    const daysSinceLastUse = lastUsed ? Math.floor((now - lastUsed) / (1000 * 60 * 60 * 24)) : null;
    
    return {
        lastUsed: new Date(lastUsed),
        commandCount: data[key].commandCount || 0,
        daysSinceLastUse
    };
}

/**
 * Limpia registros de subbots que ya no existen
 * @param {number[]} validSubbotNums - Array de números de subbots válidos
 */
function cleanupInvalidRecords(validSubbotNums) {
    const data = loadActivity();
    const validKeys = new Set(validSubbotNums.map(n => String(n)));
    let cleaned = false;
    
    for (const key of Object.keys(data)) {
        if (!validKeys.has(key)) {
            delete data[key];
            cleaned = true;
            console.log(`[SubBot Activity] 🗑️ Limpiado registro de subbot #${key} (ya no existe)`);
        }
    }
    
    if (cleaned) {
        saveActivity(data);
    }
    
    return cleaned;
}

function cleanupSubbotActivity(subbotNum) {
    const data = loadActivity();
    const key = String(subbotNum);

    if (data[key] !== undefined) {
        delete data[key];
        saveActivity(data);
        console.log(`[SubBot Activity] 🗑️ Limpiado registro de actividad del subbot #${subbotNum}`);
        return true;
    }

    return false;
}

module.exports = {
    recordActivity,
    getSortedByActivity,
    getActivityStats,
    cleanupInvalidRecords,
    cleanupSubbotActivity,
    loadActivity,
    saveActivity
};
