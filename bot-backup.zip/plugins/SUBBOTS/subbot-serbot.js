'use strict';
/**
 * Plugin de Sub-Bots (numerados automáticamente)
 *
 * .serbot              → Crear sub-bot con QR
 * .serbot 59891234567  → Crear sub-bot con código de emparejamiento
 * .bots / .subbots / .listbots → Ver sub-bots activos
 * .bcbot               → Difundir mensaje (owner)
 *
 * Para eliminar: ir a Dispositivos Vinculados en WhatsApp y cerrar sesión.
 * Bot oficial = prioridad 0. Subbots = 1, 2, 3... (menor número = mayor prioridad)
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Grupo oficial donde todos los subbots deben estar
const OFFICIAL_GROUP = '120363426476029684@g.us';

const retryMap    = new Map();
const activeSocks = new Map();
const pendingQR   = new Set(); // JIDs con QR/código pendiente
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Intenta unir un bot (oficial o subbot) al grupo oficial
 */
async function joinOfficialGroup(sock, botLabel = 'Bot') {
    try {
        const groupJid = OFFICIAL_GROUP;
        try {
            const groupMeta = await sock.groupMetadata(groupJid);
            if (groupMeta) {
                console.log(`[${botLabel}] Ya está en el grupo oficial`);
                return true;
            }
        } catch (e) {
            // No está en el grupo, intentar unirse
        }
        await sock.groupAcceptInvite('KwDx3Mgt1FM7heUXKVtFvA');
        console.log(`[${botLabel}] ✅ Unido al grupo oficial`);
        return true;
    } catch (error) {
        console.error(`[${botLabel}] Error uniéndose al grupo:`, error.message);
        return false;
    }
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, String(num));
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
    let n = 1;
    while (existing.includes(n)) n++;
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const folders = fs.readdirSync(SESSIONS_DIR).filter(f => !isNaN(parseInt(f)));
    for (const folder of folders) {
        const ownerFile = path.join(SESSIONS_DIR, folder, 'owner.json');
        if (!fs.existsSync(ownerFile)) continue;
        try {
            const data = JSON.parse(fs.readFileSync(ownerFile, 'utf-8'));
            const storedNum = (data.ownerJid || '').split('@')[0].split(':')[0];
            if (storedNum === ownerNum) return parseInt(folder);
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    const name      = String(num);
    const sessDir   = sessionPath(num);
    const credsFile = path.join(sessDir, 'creds.json');
    const ownerFile = path.join(sessDir, 'owner.json');

    if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });

    let ownerJid = chatJid;
    if (!ownerJid && fs.existsSync(ownerFile)) {
        try { ownerJid = JSON.parse(fs.readFileSync(ownerFile, 'utf-8')).ownerJid; } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            fs.writeFileSync(credsFile, JSON.stringify(decoded, null, '\t'));
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessDir);
    const version              = await getBaileysVersion();

    const socketConfig = {
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        // Pairing code requiere browser tipo desktop (Chrome), QR puede usar Safari
        browser: usePairingCode && phoneNumber
            ? ['Ubuntu', 'Chrome', '20.0.04']
            : ['RobleBOT SubBot #' + num, 'Safari', '17.0'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 500,
        maxMsgRetryCount: 2,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        markOnlineOnConnect: true,
        syncFullHistory: false,
        getMessage: async () => undefined
    };

    const sock = makeWASocket(socketConfig);

    // 🛡️ Wrapper seguro para groupMetadata
    const originalGroupMetadata = sock.groupMetadata.bind(sock);
    const failedGroupsCache = new Map();
    const CACHE_DURATION = 5 * 60 * 1000;

    sock.groupMetadata = async (jid) => {
        const cachedError = failedGroupsCache.get(jid);
        if (cachedError && (Date.now() - cachedError.timestamp) < CACHE_DURATION) {
            const error = new Error('Bot sin permisos en este grupo');
            error.data = 403;
            error.isBoom = true;
            throw error;
        }
        try {
            const result = await originalGroupMetadata(jid);
            failedGroupsCache.delete(jid);
            return result;
        } catch (error) {
            const isForbidden = error?.data === 403 ||
                               error?.output?.statusCode === 403 ||
                               error?.message?.includes('forbidden') ||
                               error?.toString()?.includes('forbidden');
            if (isForbidden) {
                console.log(`[SubBot #${num}] [Bot expulsado del grupo] ${jid}`);
                failedGroupsCache.set(jid, { timestamp: Date.now() });
                if (global.db?.data?.chats?.[jid]) delete global.db.data.chats[jid];
                const friendlyError = new Error('Bot sin permisos en este grupo');
                friendlyError.data = 403;
                friendlyError.isBoom = true;
                friendlyError.isGroupPermissionError = true;
                throw friendlyError;
            }
            throw error;
        }
    };

    const cacheCleanupInterval = setInterval(() => {
        const now = Date.now();
        for (const [jid, data] of failedGroupsCache.entries()) {
            if (now - data.timestamp > CACHE_DURATION) failedGroupsCache.delete(jid);
        }
    }, 60000);

    sock._cacheCleanupInterval = cacheCleanupInterval;
    sock._subName  = name;
    sock._subNum   = num;
    sock._sessDir  = sessDir;
    sock._ownerJid = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber = phoneNumber;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrSent              = false;
    let qrTimeout           = null;
    let connected           = false;
    let codeSent            = false;
    let pairingCodeRequested = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // ── Flujo PAIRING CODE ──────────────────────────────────────────────
        // El primer evento QR indica que el socket está listo para pedir el código.
        // Lo usamos como señal, NO lo mostramos al usuario.
        if (usePairingCode && phoneNumber && qr && !pairingCodeRequested && !connected && !state.creds.registered) {
            pairingCodeRequested = true;
            console.log(`[SubBot] Socket listo, solicitando código de emparejamiento para #${num} (${phoneNumber})...`);

            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);

                codeSent = true;
                console.log(`[SubBot] ✅ Código para #${num}: ${code}`);

                // Enviar al usuario por WhatsApp si vino por comando
                if (chatJid) {
                    await conn.sendMessage(chatJid, {
                        text: `🔐 *Código de emparejamiento para sub-bot #${num}*\n\n` +
                              `Código: *${code}*\n\n` +
                              `_Ingresa este código en:_\n` +
                              `WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n` +
                              `⏱️ Tienes 90 segundos para ingresarlo.`
                    });
                }

                // Entregar código al servidor web si hay alguien esperando
                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, code);
                } catch (e) {
                    console.error('[SubBot] Error enviando código al servidor web:', e.message);
                }

                // Timeout de 90 segundos esperando que el usuario vincule
                qrTimeout = setTimeout(() => {
                    if (!connected) {
                        console.log(`[SubBot] Timeout esperando vinculación con código para bot #${num}`);
                        activeSocks.delete(name);
                        try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                        if (fs.existsSync(sessDir) && !fs.existsSync(path.join(sessDir, 'creds.json'))) {
                            fs.rmSync(sessDir, { recursive: true, force: true });
                        }
                        if (chatJid) {
                            conn.sendMessage(chatJid, { text: `⏰ Código expirado. Genera uno nuevo con \`.serbot ${phoneNumber}\`.` }).catch(() => {});
                        }
                    }
                }, 90000);

            } catch (e) {
                console.error('[SubBot] Error solicitando código de emparejamiento:', e.message);
                if (chatJid) {
                    conn.sendMessage(chatJid, { text: '❌ Error generando código: ' + e.message }).catch(() => {});
                }
                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, null);
                } catch {}
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }

            // No procesar el QR como QR normal
            return;
        }

        // Ignorar QRs posteriores cuando ya se pidió el código
        if (usePairingCode && qr && pairingCodeRequested) return;

        // ── Flujo QR normal ─────────────────────────────────────────────────
        if (qr) {
            if (connected) return;
            if (qrSent) {
                // Segundo QR = el primero expiró sin escanear
                console.log(`[SubBot] QR expirado para bot #${num}`);
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                if (!connected && fs.existsSync(sessDir) && !fs.existsSync(path.join(sessDir, 'creds.json'))) {
                    fs.rmSync(sessDir, { recursive: true, force: true });
                }
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    await conn.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot #${num}*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                    qrSent = true;
                }
                // Entregar QR al servidor web si hay alguien esperando
                try {
                    const { resolveWebQR } = require('../../subbotServer');
                    const dataUrl = await qrcode.toDataURL(qr);
                    resolveWebQR(num, dataUrl);
                } catch {}
                // Timeout de seguridad por si el segundo QR no llega
                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    if (fs.existsSync(sessDir) && !fs.existsSync(ownerFile)) {
                        fs.rmSync(sessDir, { recursive: true, force: true });
                    }
                    if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                }, 35000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        // ── Conexión exitosa ─────────────────────────────────────────────────
        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);
            fs.writeFileSync(ownerFile, JSON.stringify({ ownerJid, num }));
            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            if (ownerJid) {
                conn.sendMessage(ownerJid, {
                    text: `✅ *Sub-bot #${num} conectado*\n\nPara eliminarlo, ve a *Dispositivos Vinculados* en WhatsApp y cierra la sesión desde ahí.`
                }).catch(() => {});
            }
            setTimeout(() => joinOfficialGroup(sock, `SubBot #${num}`), 3000);
            sock._presenceInterval = setInterval(async () => {
                try { if (sock.user) await sock.sendPresenceUpdate('available'); } catch {}
            }, 60000);
        }

        // ── Desconexión ──────────────────────────────────────────────────────
        if (connection === 'close') {
            const code     = lastDisconnect?.error?.output?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || 'desconocido';
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}, error: ${errorMsg}`);
            console.log(`[SubBot] usePairingCode: ${usePairingCode}, codeSent: ${codeSent}, connected: ${connected}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            if (sock._presenceInterval)    { clearInterval(sock._presenceInterval);    sock._presenceInterval    = null; }
            if (sock._cacheCleanupInterval){ clearInterval(sock._cacheCleanupInterval); sock._cacheCleanupInterval = null; }
            try { sock.ev.removeAllListeners(); } catch {}

            // Restart requerido
            if (code === 515) {
                console.log(`[SubBot] Reconectando bot #${num} (código 515)...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), 2000);
                return;
            }

            // 401/428 después de enviar código = proceso normal de Baileys, reconectar sin pairing
            if (usePairingCode && codeSent && !connected && (code === 401 || code === 428)) {
                console.log(`[SubBot] Bot #${num} recibió ${code} post-código, reconectando para completar vinculación...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn, usePairingCode: false }), 3000);
                return;
            }

            if (code === 401 || code === 403 || code === 405) {
                if (usePairingCode && codeSent && !connected) {
                    console.log(`[SubBot] Bot #${num} esperando vinculación con código...`);
                    return;
                }
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada. Usa \`.serbot\` para reconectar.` }).catch(() => {});
                return;
            }

            if (code === DisconnectReason.loggedOut) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `📴 Sub-bot #${num} cerró sesión. Usa \`.serbot\` si quieres volver a conectarlo.` }).catch(() => {});
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 8000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot #${num} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⛔ Sub-bot #${num} agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;
            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) if (ts < cutoff) processedIds.delete(id);
            }

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            if (isFromMe && !hasPrefix) continue;
            if (!msgText && !hasPrefix) continue;

            if (hasPrefix) {
                const _cmd = msgText.slice(1).split(' ')[0].toLowerCase();
                if (['serbot','jadibot'].includes(_cmd)) {
                    const _mainNum = global.mainBotNumber;
                    const _reply = _mainNum
                        ? `Para poder ser sub-bot debes usar el comando con el bot oficial:\nwa.me/+${_mainNum}`
                        : `Para poder ser sub-bot debes usar el comando con el bot oficial.`;
                    try { await sock.sendMessage(baileyMessage.key.remoteJid, { text: _reply }); } catch {}
                    continue;
                }
                if (['bcbot','broadcastbot'].includes(_cmd)) continue;

                if (['botsonline','subbotsonline'].includes(_cmd)) {
                    const chatJid = baileyMessage.key.remoteJid;
                    if (chatJid === OFFICIAL_GROUP) {
                        await sleep(1000 + (num * 800));
                        try {
                            await sock.sendMessage(chatJid, { text: `🤖 *SubBot #${num}* está activo ✅` });
                        } catch (e) {
                            console.error(`[SubBot] Error botsonline #${num}:`, e.message);
                        }
                    }
                    continue;
                }
            }

            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            if (sock.user) {
                try {
                    const { shouldBotProcessMessage } = require('../../botPrioritySystem');
                    const priorityCheck = await shouldBotProcessMessage(sock, num, msgChatJid, isGroupMsg);
                    if (!priorityCheck.shouldProcess) continue;
                } catch (e) {
                    console.error(`[SubBot] Error prioridad:`, e.message);
                }
            }

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock  = sock;

                const prevConn           = global.conn;
                const prevLastMsg        = global.lastBaileyMessage;

                if (!sock.user && prevConn?.user) sock.user = prevConn.user;

                global.conn              = sock;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.conn              = prevConn;
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
function reorderSubBotSessions() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    const alreadyOrdered = folders.every((n, i) => n === i + 1);
    if (alreadyOrdered) return;

    console.log(`[SubBot] Reordenando sesiones: [${folders.join(', ')}] → [${folders.map((_, i) => i + 1).join(', ')}]`);

    const tempNames = [];
    for (const num of folders) {
        const tempName = `_tmp_${num}_${Date.now()}`;
        const src = path.join(SESSIONS_DIR, String(num));
        const tmp = path.join(SESSIONS_DIR, tempName);
        fs.renameSync(src, tmp);
        tempNames.push(tempName);
    }

    for (let i = 0; i < tempNames.length; i++) {
        const tmp = path.join(SESSIONS_DIR, tempNames[i]);
        const dst = path.join(SESSIONS_DIR, String(i + 1));
        fs.renameSync(tmp, dst);
    }

    console.log(`[SubBot] Sesiones reordenadas correctamente.`);
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    reorderSubBotSessions();

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    for (const num of folders) {
        const credsFile = path.join(SESSIONS_DIR, String(num), 'creds.json');
        if (!fs.existsSync(credsFile)) continue;
        if (global.subConns.find(c => c._subNum === num && c.user)) continue;
        console.log(`[SubBot] Auto-reconectando bot #${num}...`);
        await sleep(2000);
        await connectSubBot({ num, chatJid: null, conn })
            .catch(e => console.error(`[SubBot] Error auto-reconexión #${num}:`, e.message));
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr (QR) | .serbot code 59891234567 (código de emparejamiento)',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const conn = global.conn;

        if (message.isGroup) {
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // Subcomandos: .serbot qr | .serbot code <numero>
        const arg0 = (args?.[0] || '').trim().toLowerCase();
        const arg1 = (args?.[1] || '').trim();

        let usePairingCode = false;
        let phoneNumber    = null;
        let token          = null;

        if (arg0 === 'qr') {
            // .serbot qr → forzar QR
            usePairingCode = false;
        } else if (arg0 === 'code') {
            // .serbot code <numero>
            if (!arg1 || !/^\+?[0-9]{7,15}$/.test(arg1)) {
                return conn.sendMessage(message.from, {
                    text: '❌ Debes indicar el número. Ejemplo: `.serbot code 59891234567`'
                }, { quoted: message._baileyMessage });
            }
            usePairingCode = true;
            phoneNumber    = arg1.replace(/[^0-9]/g, '');
        } else {
            // Compatibilidad hacia atrás: .serbot | .serbot <numero>
            const isPhoneNumber = /^\+?[0-9]{7,15}$/.test(arg0);
            usePairingCode = isPhoneNumber;
            phoneNumber    = isPhoneNumber ? arg0.replace(/[^0-9]/g, '') : null;
            token          = (!isPhoneNumber && arg0.length > 20) ? arg0 : null;
        }

        if (pendingQR.has(senderJid)) {
            return conn.sendMessage(message.from, {
                text: `⏳ Ya tienes un proceso pendiente. Espera a que expire para generar uno nuevo.`
            }, { quoted: message._baileyMessage });
        }

        const existingNum = getSubBotNumberByOwner(senderJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (alreadyActive) {
                return conn.sendMessage(message.from, {
                    text: `ℹ️ Ya eres el Sub-Bot #${existingNum}.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                }, { quoted: message._baileyMessage });
            }
            pendingQR.add(senderJid);
            conn.sendMessage(message.from, {
                text: usePairingCode
                    ? `⏳ Generando código para reconectar sub-bot #${existingNum} con el número *${phoneNumber}*...`
                    : `⏳ Reconectando tu sub-bot #${existingNum} con QR...`
            }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
        }

        const num = nextSubBotNumber();

        pendingQR.add(senderJid);
        conn.sendMessage(message.from, {
            text: usePairingCode
                ? `⏳ Generando código de emparejamiento para el número *${phoneNumber}* (sub-bot #${num})...\n\n_En unos segundos recibirás el código de 8 dígitos._`
                : token
                    ? `⏳ Restaurando sesión como sub-bot #${num}...`
                    : `⏳ Generando QR para sub-bot #${num}...`
        }, { quoted: message._baileyMessage });

        await connectSubBot({ num, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn   = global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (conn?.user) {
            const mainPhoneNum = conn.user.id.split('@')[0].split(':')[0];
            let mainGroupCount = '?';
            try {
                const chats = await conn.groupFetchAllParticipating();
                mainGroupCount = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                }).length;
            } catch (e) {
                console.error(`[listBots] Error contando grupos bot principal:`, e.message);
            }
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}\n👥 Grupos: ${mainGroupCount}`);
        }

        if (active.length > 0) {
            const subBotLines = await Promise.all(active.map(async c => {
                const phoneNum = c.user.id.split('@')[0].split(':')[0];
                let groupCount = '?';
                try {
                    const chats = await c.groupFetchAllParticipating();
                    groupCount = Object.values(chats).filter(g => {
                        const jid = g.id;
                        if (jid.includes('@newsletter')) return false;
                        if (g.announce === true) return false;
                        return jid.endsWith('@g.us');
                    }).length;
                } catch (e) {
                    console.error(`[listBots] Error contando grupos subbot #${c._subNum}:`, e.message);
                }
                return `🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}\n👥 Grupos: ${groupCount}`;
            }));
            lines.push(...subBotLines);
        }

        if (lines.length === 0) {
            return conn.sendMessage(message.from, { text: '📭 No hay bots conectados.' }, { quoted: message._baileyMessage });
        }

        const totalBots = (conn?.user ? 1 : 0) + active.length;
        conn.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${totalBots}*\n\n${lines.join('\n\n')}`
        }, { quoted: message._baileyMessage });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    help: 'Ver qué bots están activos (solo en el grupo oficial)',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const officialGroupJid = OFFICIAL_GROUP;
        if (message.from !== officialGroupJid) return;

        const conn = global.conn;
        await conn.sendMessage(officialGroupJid, {
            text: '🟢 *Bot principal activo* ✅'
        }, { quoted: message._baileyMessage });

        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        for (const subSock of active) {
            await sleep(800);
            try {
                await subSock.sendMessage(officialGroupJid, {
                    text: `🤖 *SubBot #${subSock._subNum}* está activo ✅`
                });
            } catch (e) {
                console.error(`[SubBot] Error respuesta botsonline #${subSock._subNum}:`, e.message);
            }
        }
    }
};

/** Versión para el servidor web: genera QR */
async function connectSubBotWeb({ num, conn }) {
    return connectSubBot({ num, chatJid: null, conn });
}

/** Versión para el servidor web: genera código de emparejamiento */
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) {
    return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber });
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    listBots:            listBotsHandler,
};