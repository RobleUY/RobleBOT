'use strict';
/**
 * Plugin de Sub-Bots (con IDs únicos de 4 dígitos)
 * Refactorizado: Sin memory leaks, con Pairing Code reparado y Bienvenidas conectadas.
 * Optimizado para Alta Carga: Sistema Anti-Bucle (440), auto-limpieza de archivos fantasma (12KB),
 * y arranque escalonado lento para evitar caídas por saturación de CPU/IP.
 */

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

// ── IMPORTAR MÓDULO DE BIENVENIDAS ──
const welcomeGoodbyeModule = require('../../plugins/HERRAMIENTAS/bienvenida-despedida');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

const OFFICIAL_GROUP = '120363203689229697@g.us';
const activeSocks = new Map();
const pendingQR = new Set();
const reconnectTimers = new Map(); // Gestor de timeouts para evitar bucles
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Caché de grupos donde está el bot principal ───────────────────────────────
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000;

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) {
                    mainBotGroupsCache.add(jid);
                }
            }
        } catch (e) {}
    }
    return mainBotGroupsCache.has(groupJid);
}

async function followPublicChannel(sock, botLabel = 'Bot') {
    await sleep(4000);
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        if (inviteCode) {
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            if (metadata?.id) {
                await sock.newsletterFollow(metadata.id);
                console.log(`[${botLabel}] ✅ Bot siguiendo el canal exitosamente.`);
            }
        }
    } catch (error) {
        if (!error.message?.includes('unexpected response structure')) {
            console.error(`[${botLabel}] ❌ Error al seguir canal:`, error.message);
        }
    }
    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do {
        n = Math.floor(1000 + Math.random() * 9000);
    } while (existing.includes(n));
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            // Ignorar archivos fantasma corruptos o vacíos de 12kb
            if (fs.statSync(dbPath).size <= 13000) continue;

            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            
            // Optimizaciones SQLite para lectura
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 3000');
            
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    // Cancelar reconexiones duplicadas agendadas en segundo plano
    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;

    if (fs.existsSync(dbFile)) {
        try {
            if (fs.statSync(dbFile).size > 13000) {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile, { readonly: true });
                
                // Optimizaciones SQLite para lectura
                _db.pragma('cache_size = 5000');
                _db.pragma('busy_timeout = 3000');
                
                const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                _db.close();
                if (row) {
                    const data = JSON.parse(row.value);
                    if (!ownerJid) ownerJid = data.ownerJid;
                    if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                }
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    // Ajustes de red optimizados para evitar desconexiones continuas por lag en el hosting
    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        browser: ['RobleBOT', 'Chrome', '120.0.0'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false,
        connectTimeoutMs: 60000,       // Darle 60 segundos antes de tirar timeout
        defaultQueryTimeoutMs: 0,      // Previene caídas por consultas lentas
        retryRequestDelayMs: 5000      // Reintentar peticiones fallidas de forma prudente
    });

    sock._subName    = name;
    sock._subNum     = num;
    sock._sessDb     = dbFile;
    sock._ownerJid   = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime      = Date.now();
    activeSocks.set(name, sock);

    // ── INICIALIZAR BIENVENIDAS PARA EL SUB-BOT ──
    if (welcomeGoodbyeModule?.init) {
        try {
            welcomeGoodbyeModule.init(sock);
            console.log(`[SubBot #${num}] ✓ Módulo Bienvenida/Despedida conectado.`);
        } catch (error) {
            console.error(`[SubBot #${num}] ❌ Error iniciando Bienvenida/Despedida:`, error.message);
        }
    }

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false; 
    let codeSent             = false;
    let pairingCodeRequested = false;

    const sendToOwner = async (content) => {
        if (!ownerJid) return;
        const sender = (connected ? sock : (conn || global.conn));
        try {
            await sender.sendMessage(ownerJid, content);
        } catch (e) {
            try {
                const fallback = sender === sock ? (conn || global.conn) : sock;
                await fallback.sendMessage(ownerJid, content);
            } catch {}
        }
    };

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (
            usePairingCode && 
            phoneNumber && 
            !pairingCodeRequested && 
            !connected && 
            !state.creds.registered && 
            (connection === 'connecting' || !!qr)
        ) {
            pairingCodeRequested = true;
            await sleep(connection === 'connecting' ? 3000 : 500);
            if (connected) return;

            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);
                codeSent = true;
                
                await sendToOwner({
                    text: `🔐 *Código para sub-bot #${num}*\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                });
                await sendToOwner({ text: code });

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                qrTimeout = setTimeout(() => {
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ Código expirado. Genera uno nuevo con \`.code\`.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `❌ Error generando código: ${e.message}` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }
            return;
        }

        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwner({
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                });
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 35000);
            } catch (e) {}
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                
                // ── OPTIMIZACIONES DE RENDIMIENTO SQLite ──────────────────────────────
                _db.pragma('journal_mode = WAL');
                _db.pragma('synchronous = NORMAL');
                _db.pragma('cache_size = 10000');
                _db.pragma('busy_timeout = 5000');
                // ─────────────────────────────────────────────────────────────────────
                
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch {}

            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);

            if (ownerJid) {
                const phoneNum = sock.user?.id?.split('@')[0]?.split(':')[0] || '?';
                await sendToOwner({ text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` });
            }

            setTimeout(() => {
                if (sock.ws?.readyState === 1) {
                    followPublicChannel(sock, `SubBot #${num}`);
                }
            }, 6000);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);

            if (code === DisconnectReason.loggedOut || code === 401 || code === 403 || code === 405) {
                try { if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile); } catch {}
                sendToOwner({ text: `⚠️ Sesión del sub-bot #${num} cerrada o inválida. Usa \`.serbot qr\` o \`.serbot code\` para reconectar.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // SISTEMA ANTI-BUCLES (Rompe el conflicto por código 440)
            if (code === 440) {
                console.log(`[SubBot] ⚠️ Bot #${num} reemplazado (440). NO reconectará para evitar bucle de sobreescritura.`);
                return;
            }

            // Margen de retraso dinámico escalonado para no ahogar la red
            const reconnectDelay = 12000 + (Math.abs(num % 15) * 2000); 
            
            if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));
            
            const tid = setTimeout(() => {
                reconnectTimers.delete(name);
                console.log(`[SubBot] Reconectando bot #${num}...`);
                connectSubBot({ num, chatJid: ownerJid, conn });
            }, reconnectDelay);
            
            reconnectTimers.set(name, tid);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Set();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.add(messageId);

            if (processedIds.size > 500) {
                const arr = Array.from(processedIds).slice(-200);
                processedIds.clear();
                arr.forEach(id => processedIds.add(id));
            }

            const msgText = getMessageText(baileyMessage);
            const hasPrefix = ['.', '/', '❤️', '#'].some(p => msgText.startsWith(p));
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            if (baileyMessage.key.fromMe && !hasPrefix) continue;
            if (!msgText && !hasPrefix) continue;
            if (msgChatJid === OFFICIAL_GROUP) continue;

            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock  = sock;
                compatibleMessage._subNum = num;

                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .code',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message)) return;

        if (isSubBotMessage(message)) {
            const mainNumClean = getMainBotNumber();
            const mainContact = mainNumClean ? `+${mainNumClean}` : 'el bot principal';
            return sock.sendMessage(message.from, {
                text: `ℹ️ Para crear un sub-bot escribile directamente al *bot principal*.\n📱 *Número:* ${mainContact}`
            }, { quoted: message._baileyMessage });
        }

        const rawCmd = (message.text || message.body || '').trim().slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        if (message.isGroup) {
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');

        let arg0 = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        let codeRaw;
        
        if (isDirectCode) {
            const fullText = (message.text || message.body || '').trim();
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const key = message.key || {};
                const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid || senderJid;
                const autoNumber = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                
                if (!autoNumber || autoNumber.length < 7) {
                    return sock.sendMessage(message.from, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` });
                }
                usePairingCode = true;
                phoneNumber    = autoNumber;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(message.from, { text: '📌 Opciones: \`.serbot qr\` o \`.code\`' });
        }

        if (pendingQR.has(senderJid)) {
            return sock.sendMessage(message.from, { text: `⏳ Ya tenés un proceso pendiente.` });
        }

        const targetJid = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);
        
        if (existingNum !== null) {
            if (global.subConns.find(c => c._subNum === existingNum && c.user)) {
                return sock.sendMessage(message.from, { text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.` });
            }
            pendingQR.add(senderJid);
            sock.sendMessage(message.from, { text: `⏳ Reconectando tu sub-bot #${existingNum}...` });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber });
        }

        const num = nextSubBotNumber();
        pendingQR.add(senderJid);
        sock.sendMessage(message.from, { text: `⏳ Generando acceso para sub-bot #${num}...` });
        connectSubBot({ num, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message) => {
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message)) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0) return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, { text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}` });
    }
};

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    console.log(`[SubBot Monitor] Analizando bases de datos de sub-bots...`);

    for (const num of nums) {
        const dbFile = sessionPath(num);
        
        // --- LIMPIADOR AUTOMÁTICO DE SESIONES FANTASMA (12KB) ---
        try {
            if (fs.existsSync(dbFile)) {
                const stats = fs.statSync(dbFile);
                if (stats.size <= 13000) { 
                    console.log(`[SubBot Garbage Collector] 🗑️ Eliminando automáticamente registro vacío muerto #${num} (${stats.size} bytes)`);
                    fs.unlinkSync(dbFile);
                    continue; // Pasa al siguiente archivo, este fantasma ya fue borrado
                }
            }
        } catch (err) {
            console.error(`Error limpiando archivo #${num}:`, err.message);
        }

        if (activeSocks.has(String(num))) continue;
        
        try {
            // Conexión escalonada lenta (6 a 12 segundos por bot) para no asfixiar los recursos del VPS/Hosting
            const StaggeredDelay = 6000 + (Math.random() * 6000);
            await sleep(StaggeredDelay);
            
            await connectSubBot({ num, chatJid: null, conn });
        } catch (e) {}
    }
}

async function connectSubBotWeb({ num, conn }) { return connectSubBot({ num, chatJid: null, conn }); }
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) { return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber }); }

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    listBots:            listBotsHandler,
};