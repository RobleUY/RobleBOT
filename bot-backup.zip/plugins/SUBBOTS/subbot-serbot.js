'use strict';
/**
 * Plugin de Sub-Bots (numerados automáticamente)
 *
 * Uso (solo desde chat privado con el bot):
 *   .serbot          → Crear/conectar tu sub-bot (número asignado automático)
 *   .stopbot         → Eliminar tu sub-bot (solo si eres dueño de uno)
 *   .subbots        → Ver sub-bots activos
 *
 * Numeración: bot oficial = 0 (prioridad máxima), subbots = 1, 2, 3...
 * En grupos sin bot oficial, responde el subbot con número más bajo.
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

const retryMap    = new Map();
const activeSocks = new Map();
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, String(num));
}

/** Devuelve el siguiente número disponible (1, 2, 3...) */
function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
    let n = 1;
    while (existing.includes(n)) n++;
    return n;
}

/** Devuelve el número de subbot que le pertenece a un JID, o null */
function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const folders = fs.readdirSync(SESSIONS_DIR).filter(f => !isNaN(parseInt(f)));
    for (const folder of folders) {
        const ownerFile = path.join(SESSIONS_DIR, folder, 'owner.json');
        if (!fs.existsSync(ownerFile)) continue;
        try {
            const data = JSON.parse(fs.readFileSync(ownerFile, 'utf-8'));
            const storedNum = (data.ownerJid || '').split('@')[0].split(':')[0];
            if (storedNum === ownerNum) return parseInt(folder);
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null }) {
    const name      = String(num);
    const sessDir   = sessionPath(num);
    const credsFile = path.join(sessDir, 'creds.json');
    const ownerFile = path.join(sessDir, 'owner.json');

    if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });

    // Guardar owner si se provee (primera vez o reconexión manual)
    if (chatJid) {
        fs.writeFileSync(ownerFile, JSON.stringify({ ownerJid: chatJid, num }));
    }

    // Leer owner guardado (para auto-reconexión donde chatJid es null)
    let ownerJid = chatJid;
    if (!ownerJid && fs.existsSync(ownerFile)) {
        try { ownerJid = JSON.parse(fs.readFileSync(ownerFile, 'utf-8')).ownerJid; } catch {}
    }

    // Limpiar socket anterior
    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            fs.writeFileSync(credsFile, JSON.stringify(decoded, null, '\t'));
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessDir);
    const version              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        browser: Browsers.baileys('Desktop'),
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 500,
        maxMsgRetryCount: 2,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        markOnlineOnConnect: true,
        syncFullHistory: false,
        getMessage: async () => undefined
    });

    sock._subName  = name;   // número como string: "1", "2", "3"...
    sock._subNum   = num;    // número como int: 1, 2, 3...
    sock._sessDir  = sessDir;
    sock._ownerJid = ownerJid;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrMsg;
    let qrTimeout = null;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            if (qrMsg) {
                console.log(`[SubBot] QR expirado para bot #${num}, cerrando socket`);
                try { sock.ws.close(); } catch {}
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    qrMsg = await conn.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot #${num}*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                }
                qrTimeout = setTimeout(() => {
                    if (!sock.user) {
                        console.log(`[SubBot] QR no escaneado para bot #${num}, cerrando`);
                        activeSocks.delete(name);
                        try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                        if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                    }
                    qrTimeout = null;
                }, 32000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        if (connection === 'open') {
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            qrMsg = null; // resetear para futuras reconexiones
            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            if (ownerJid) {
                conn.sendMessage(ownerJid, {
                    text: `✅ *Sub-bot #${num} conectado*\n\n> \`.stopbot\` — eliminar tu sub-bot`
                }).catch(() => {});
            }
            sock._presenceInterval = setInterval(async () => {
                try { if (sock.user) await sock.sendPresenceUpdate('available'); } catch {}
            }, 20000);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            if (sock._presenceInterval) { clearInterval(sock._presenceInterval); sock._presenceInterval = null; }
            try { sock.ev.removeAllListeners(); } catch {}

            if (code === 515) {
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), 2000);
                return;
            }
            if (code === 401 || code === 403 || code === 405) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada (${code}). Usa \`.serbot\` para reconectar.` }).catch(() => {});
                return;
            }
            if (code === DisconnectReason.loggedOut) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 8000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot #${num} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⛔ Sub-bot #${num} agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;
            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) if (ts < cutoff) processedIds.delete(id);
            }

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            if (isFromMe && !hasPrefix) continue;
            if (!msgText && !hasPrefix) continue;

            // Comandos de gestión exclusivos del owner, no los procesa el subbot

            // ── Prioridad: bot oficial = 0, subbots por número ascendente ───
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');
            if (sock.user) {
                try {
                    const mainBotNum = global.mainBotNumber;

                    if (isGroupMsg) {
                        const groupMeta = await sock.groupMetadata(msgChatJid).catch(() => null);
                        if (groupMeta?.participants) {
                            const participantNums = groupMeta.participants
                                .map(p => p.id.split('@')[0].split(':')[0]);

                            // Bot oficial presente → subbot cede siempre
                            if (mainBotNum && participantNums.includes(mainBotNum)) continue;

                            // Múltiples subbots → responde el de número más bajo
                            const subbotsInGroup = global.subConns
                                .filter(c => c.user && c._subNum != null)
                                .filter(c => participantNums.includes(c.user.id.split('@')[0].split(':')[0]))
                                .sort((a, b) => a._subNum - b._subNum);

                            if (subbotsInGroup.length > 1 && subbotsInGroup[0]._subNum !== num) continue;
                        }
                    } else {
                        // Chat privado con el bot oficial → no responder
                        const chatNum = typeof msgChatJid === 'string' ? msgChatJid.split('@')[0].split(':')[0] : null;
                        if (mainBotNum && chatNum === mainBotNum) continue;
                    }
                } catch (e) {
                    console.error(`[SubBot] Error prioridad:`, e.message);
                }
            }
            // ────────────────────────────────────────────────────────────────

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock  = sock;

                const prevConn           = global.conn;
                const prevLastMsg        = global.lastBaileyMessage;

                if (!sock.user && prevConn?.user) sock.user = prevConn.user;

                global.conn              = sock;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.conn              = prevConn;
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;
    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    for (const num of folders) {
        const credsFile = path.join(SESSIONS_DIR, String(num), 'creds.json');
        if (!fs.existsSync(credsFile)) continue;
        if (global.subConns.find(c => c._subNum === num && c.user)) continue;
        console.log(`[SubBot] Auto-reconectando bot #${num}...`);
        await sleep(2000);
        await connectSubBot({ num, chatJid: null, conn })
            .catch(e => console.error(`[SubBot] Error auto-reconexión #${num}:`, e.message));
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot|subbot)$/i,
    help: 'Crear tu sub-bot. Uso: .serbot',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const conn = global.conn;

        if (message.isGroup) {
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // Verificar si ya tiene un subbot
        const existingNum = getSubBotNumberByOwner(senderJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (alreadyActive) {
                return conn.sendMessage(message.from, {
                    text: `⚠️ Ya tienes el sub-bot #${existingNum} activo. Usa \`.stopbot\` para eliminarlo primero.`
                }, { quoted: message._baileyMessage });
            }
            // Tiene sesión guardada pero no está activo → reconectar
            const arg0  = (args?.[0] || '').trim();
            const token = arg0.length > 20 ? arg0 : null;
            conn.sendMessage(message.from, {
                text: `⏳ Reconectando tu sub-bot #${existingNum}...`
            }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn, token });
        }

        // Asignar número nuevo
        const num   = nextSubBotNumber();
        const arg0  = (args?.[0] || '').trim();
        const token = arg0.length > 20 ? arg0 : null;

        conn.sendMessage(message.from, {
            text: token ? `⏳ Restaurando sesión como sub-bot #${num}...` : `⏳ Generando QR para sub-bot #${num}...`
        }, { quoted: message._baileyMessage });

        await connectSubBot({ num, chatJid: senderJid, conn, token });
    }
};

const stopbotHandler = {
    command: /^(stopbot|pausarbot)$/i,
    help: 'Eliminar tu sub-bot. Uso: .stopbot',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn = global.conn;
        if (message.isGroup) return conn.sendMessage(message.from, { text: '❌ Solo en chat privado.' }, { quoted: message._baileyMessage });

        const senderJid = message.author || message.sender || message.from;
        const senderNum = senderJid.split('@')[0].split(':')[0];

        // Verificar que el sender sea dueño de algún subbot
        const idx = global.subConns.findIndex(c => {
            if (!c._ownerJid) return false;
            return c._ownerJid.split('@')[0].split(':')[0] === senderNum;
        });

        if (idx < 0) return conn.sendMessage(message.from, { text: `❌ No tienes ningún sub-bot activo.` }, { quoted: message._baileyMessage });

        const subNum  = global.subConns[idx]._subNum;
        const sessDir = global.subConns[idx]._sessDir;

        if (global.subConns[idx]._presenceInterval) clearInterval(global.subConns[idx]._presenceInterval);
        try { global.subConns[idx].ev.removeAllListeners(); global.subConns[idx].ws.close(); } catch {}
        global.subConns.splice(idx, 1);
        activeSocks.delete(String(subNum));

        if (sessDir && fs.existsSync(sessDir)) {
            fs.rmSync(sessDir, { recursive: true, force: true });
        }

        conn.sendMessage(message.from, { text: `🗑️ Sub-bot #${subNum} eliminado. Usa \`.serbot\` para crear uno nuevo.` }, { quoted: message._baileyMessage });
    }
};

const listBotsHandler = {
    command: /^(listbots|listjadibots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn   = global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        if (active.length === 0) return conn.sendMessage(message.from, { text: '📭 No hay sub-bots conectados.' }, { quoted: message._baileyMessage });

        const list = active.map(c => {
            const num = c.user.id.split('@')[0].split(':')[0];
            return `SubBot #${c._subNum}\nwa.me/+${num}`;
        }).join('\n');

        conn.sendMessage(message.from, { text: `🤖 *Sub-bots activos: ${active.length}*\n\n${list}` }, { quoted: message._baileyMessage });
    }
};

const broadcastHandler = {
    command: /^(bcbot|broadcastbot)$/i,
    help: 'Difundir mensaje a sub-bots (owner)',
    tags: ['subbots'],
    owner: true,
    handler: async (message, { text } = {}) => {
        const conn = global.conn;
        if (!text?.trim()) return conn.sendMessage(message.from, { text: '❌ Escribe el mensaje. Ej: `.bcbot Hola a todos`' }, { quoted: message._baileyMessage });

        const active = global.subConns.filter(c => c.user);
        if (active.length === 0) return conn.sendMessage(message.from, { text: '📭 No hay sub-bots activos.' }, { quoted: message._baileyMessage });

        for (const s of active) {
            await sleep(1500);
            await s.sendMessage(s.user.id, { text: `📢 *DIFUSIÓN*\n\n${text}` }).catch(() => {});
        }
        conn.sendMessage(message.from, { text: `✅ Difusión enviada a ${active.length} sub-bot(s).` }, { quoted: message._baileyMessage });
    }
};

function formatUptime(ms) {
    const s = Math.floor(ms / 1000) % 60;
    const m = Math.floor(ms / 60000) % 60;
    const h = Math.floor(ms / 3600000) % 24;
    const d = Math.floor(ms / 86400000);
    return [d > 0 ? `${d}d` : '', `${h}h`, `${m}m`, `${s}s`].filter(Boolean).join(' ');
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    stopbot:             stopbotHandler,
    listBots:            listBotsHandler,
    broadcast:           broadcastHandler,
};
