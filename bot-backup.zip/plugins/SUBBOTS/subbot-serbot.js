'use strict';
/**
 * Plugin de Sub-Bots (numerados automáticamente)
 *
 * .serbot              → Crear sub-bot con QR
 * .serbot 59891234567  → Crear sub-bot con código de emparejamiento
 * .bots / .subbots / .listbots → Ver sub-bots activos
 * .bcbot               → Difundir mensaje (owner)
 *
 * Para eliminar: ir a Dispositivos Vinculados en WhatsApp y cerrar sesión.
 * ✅ SIN SISTEMA DE PRIORIDAD: Todos los bots responden libremente en grupos
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Grupo oficial donde todos los subbots deben estar
const OFFICIAL_GROUP = '120363203689229697@g.us';

const retryMap    = new Map();
const activeSocks = new Map();

// ── Caché de grupos donde está el bot principal ───────────────────────────────
// Los subbots NO responden en grupos donde el bot principal también está presente.
// Se actualiza cada 5 minutos para no hacer llamadas en cada mensaje.
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000; // 5 minutos

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) {
                    mainBotGroupsCache.add(jid);
                }
            }
        } catch (e) {
            // Si falla, usar la caché anterior
        }
    }
    return mainBotGroupsCache.has(groupJid);
}
const pendingQR   = new Set(); // JIDs con QR/código pendiente
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Intenta unir un bot (oficial o subbot) al grupo oficial
 */
async function joinOfficialGroup(sock, botLabel = 'Bot') {
    try {
        const groupJid = OFFICIAL_GROUP;
        try {
            const groupMeta = await sock.groupMetadata(groupJid);
            if (groupMeta) {
                console.log(`[${botLabel}] Ya está en el grupo oficial`);
                return true;
            }
        } catch (e) {
            // No está en el grupo, intentar unirse
        }
        await sock.groupAcceptInvite('HaDX5l2tQCz9KJ7lyw7VHv');
        console.log(`[${botLabel}] ✅ Unido al grupo oficial`);
        return true;
    } catch (error) {
        console.error(`[${botLabel}] Error uniéndose al grupo:`, error.message);
        return false;
    }
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) { 
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, String(num));
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
    let n = 1;
    while (existing.includes(n)) n++;
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const folders = fs.readdirSync(SESSIONS_DIR).filter(f => !isNaN(parseInt(f)));
    for (const folder of folders) {
        const ownerFile = path.join(SESSIONS_DIR, folder, 'owner.json');
        if (!fs.existsSync(ownerFile)) continue;
        try {
            const data = JSON.parse(fs.readFileSync(ownerFile, 'utf-8'));
            const storedNum = (data.ownerJid || '').split('@')[0].split(':')[0];
            if (storedNum === ownerNum) return parseInt(folder);
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    const name      = String(num);
    const sessDir   = sessionPath(num);
    const credsFile = path.join(sessDir, 'creds.json');
    const ownerFile = path.join(sessDir, 'owner.json');

    if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });

    let ownerJid = chatJid;
    if (!ownerJid && fs.existsSync(ownerFile)) {
        try { ownerJid = JSON.parse(fs.readFileSync(ownerFile, 'utf-8')).ownerJid; } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            fs.writeFileSync(credsFile, JSON.stringify(decoded, null, '\t'));
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessDir);
    const version              = await getBaileysVersion();

    const socketConfig = {
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        browser: ['Ubuntu', 'Chrome', '22.04'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        maxMsgRetryCount: 3,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 30000,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        fireInitQueries: true,
        emitOwnEvents: false,
        getMessage: async () => undefined
    };

    const sock = makeWASocket(socketConfig);

    // 🛡️ Wrapper seguro para groupMetadata con retry
    const originalGroupMetadata = sock.groupMetadata.bind(sock);
    const MAX_RETRIES = 2;

    sock.groupMetadata = async (jid, retryCount = 0) => {
        try {
            return await originalGroupMetadata(jid);
        } catch (error) {
            const errorCode = error?.data || error?.output?.statusCode;
            if (errorCode !== 403) throw error;

            if (retryCount < MAX_RETRIES) {
                await new Promise(r => setTimeout(r, 1000 * (retryCount + 1)));
                return sock.groupMetadata(jid, retryCount + 1);
            }

            throw error;
        }
    };

    sock._subName  = name;
    sock._subNum   = num;
    sock._sessDir  = sessDir;
    sock._ownerJid = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber = phoneNumber;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrSent              = false;
    let qrTimeout           = null;
    let connected           = false;
    let codeSent            = false;
    let pairingCodeRequested = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // ── Flujo PAIRING CODE ──────────────────────────────────────────────
        // Esperar el evento QR — indica que el WS completó el handshake y está
        // listo para recibir requestPairingCode. "connecting" es demasiado temprano.
        if (usePairingCode && phoneNumber && !!qr && !pairingCodeRequested && !connected && !state.creds.registered) {
            pairingCodeRequested = true;
            console.log(`[SubBot] Solicitando código para #${num} (${phoneNumber})...`);

            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);

                codeSent = true;
                console.log(`[SubBot] ✅ Código para #${num}: ${code}`);

                if (chatJid) {
                    await conn.sendMessage(chatJid, {
                        text: `🔐 *Código de emparejamiento para sub-bot #${num}*\n\n` +
                              `_Ingresa este código en:_\n` +
                              `WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n` +
                              `⏱️ Tienes 90 segundos para ingresarlo.`
                    });
                    await conn.sendMessage(chatJid, { text: code });
                }

                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, code);
                } catch (e) {
                    console.error('[SubBot] Error enviando código al servidor web:', e.message);
                }

                qrTimeout = setTimeout(() => {
                    if (!connected) {
                        console.log(`[SubBot] Timeout esperando vinculación con código para bot #${num}`);
                        activeSocks.delete(name);
                        try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                        if (fs.existsSync(sessDir) && !fs.existsSync(path.join(sessDir, 'creds.json'))) {
                            fs.rmSync(sessDir, { recursive: true, force: true });
                        }
                        if (chatJid) {
                            conn.sendMessage(chatJid, { text: `⏰ Código expirado. Genera uno nuevo con \`.serbot code ${phoneNumber}\`.` }).catch(() => {});
                        }
                    }
                }, 90000);

            } catch (e) {
                console.error('[SubBot] Error solicitando código de emparejamiento:', e.message);
                if (chatJid) {
                    conn.sendMessage(chatJid, { text: '❌ Error generando código: ' + e.message }).catch(() => {});
                }
                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, null);
                } catch {}
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }

            // No mostrar el QR visualmente cuando estamos en modo pairing code
            return;
        }

        // ── Flujo QR normal ─────────────────────────────────────────────────
        if (qr) {
            if (connected) return;
            if (qrSent) {
                // Segundo QR = el primero expiró sin escanear
                console.log(`[SubBot] QR expirado para bot #${num}`);
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                if (!connected && fs.existsSync(sessDir) && !fs.existsSync(path.join(sessDir, 'creds.json'))) {
                    fs.rmSync(sessDir, { recursive: true, force: true });
                }
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    await conn.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot #${num}*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                    qrSent = true;
                }
                // Entregar QR al servidor web si hay alguien esperando
                try {
                    const { resolveWebQR } = require('../../subbotServer');
                    const dataUrl = await qrcode.toDataURL(qr);
                    resolveWebQR(num, dataUrl);
                } catch {}
                // Timeout de seguridad por si el segundo QR no llega
                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    if (fs.existsSync(sessDir) && !fs.existsSync(ownerFile)) {
                        fs.rmSync(sessDir, { recursive: true, force: true });
                    }
                    if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                }, 35000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        // ── Conexión exitosa ─────────────────────────────────────────────────
        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);
            fs.writeFileSync(ownerFile, JSON.stringify({ ownerJid, num }));
            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            setTimeout(() => joinOfficialGroup(sock, `SubBot #${num}`), 3000);
            // sendPresenceUpdate eliminado: Baileys ya mantiene la presencia
            // activa internamente via keepAliveIntervalMs (30s). Llamarlo
            // manualmente cada 60s generaba peticiones extra innecesarias a WA.
        }

        // ── Desconexión ──────────────────────────────────────────────────────
        if (connection === 'close') {
            const code     = lastDisconnect?.error?.output?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || 'desconocido';
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}, error: ${errorMsg}`);
            console.log(`[SubBot] usePairingCode: ${usePairingCode}, codeSent: ${codeSent}, connected: ${connected}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            
            // 🧹 Limpiar intervalos para evitar memory leaks
            if (sock._cacheCleanupInterval) {
                clearInterval(sock._cacheCleanupInterval);
                sock._cacheCleanupInterval = null;
            }
            // 🧹 Limpiar todos los event listeners
            try { sock.ev.removeAllListeners(); } catch {}

            // Restart requerido
            if (code === 515) {
                console.log(`[SubBot] Reconectando bot #${num} (código 515)...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), 2000);
                return;
            }

            // 401/428 después de enviar código = proceso normal de Baileys, reconectar sin pairing
            if (usePairingCode && codeSent && !connected && (code === 401 || code === 428)) {
                console.log(`[SubBot] Bot #${num} recibió ${code} post-código, reconectando para completar vinculación...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn, usePairingCode: false }), 3000);
                return;
            }

            if (code === 401 || code === 403 || code === 405) {
                if (usePairingCode && codeSent && !connected) {
                    console.log(`[SubBot] Bot #${num} esperando vinculación con código...`);
                    return;
                }
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada. Usa \`.serbot\` para reconectar.` }).catch(() => {});
                return;
            }

            if (code === DisconnectReason.loggedOut) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `📴 Sub-bot #${num} cerró sesión. Usa \`.serbot\` si quieres volver a conectarlo.` }).catch(() => {});
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 8000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot #${num} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⛔ Sub-bot #${num} agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            // Ignorar mensajes anteriores al inicio del bot
            const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
            if (msgTs && global._botStartTime && msgTs < global._botStartTime) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            
            // 🧹 Limpieza periódica de IDs procesados
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) {
                    if (ts < cutoff) processedIds.delete(id);
                }
            }

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            const msgChatJidEarly = baileyMessage.key.remoteJid;
            const isGroupMsgEarly = typeof msgChatJidEarly === 'string' && msgChatJidEarly.endsWith('@g.us');

            // Si fromMe=true, puede ser:
            //   A) Un mensaje que el subbot envió (remoteJid es el destinatario, participant vacío)
            //   B) Un mensaje que el DUEÑO del subbot envió desde su teléfono (sincronizado)
            // Solo ignorar caso A (mensajes que el propio bot envió sin prefijo).
            // Caso B (dueño usando comandos) debe procesarse normalmente.
            if (isFromMe) {
                // Sin prefijo → nunca es un comando, ignorar siempre
                if (!hasPrefix) continue;
                // Con prefijo en privado: solo ignorar si el chat es con el propio número del bot
                // (el bot se habló a sí mismo), no si es el dueño hablando con otro chat
                if (!isGroupMsgEarly) {
                    const botNum = sock.user?.id?.split('@')[0]?.split(':')[0];
                    const chatNum = msgChatJidEarly?.split('@')[0]?.split(':')[0];
                    // Si el chat remoto ES el propio bot → mensaje que el bot se envió a sí mismo, ignorar
                    if (botNum && chatNum && botNum === chatNum) continue;
                    // Si no, es el dueño enviando un comando desde su teléfono → procesar
                }
            }
            if (!msgText && !hasPrefix) continue;

            if (hasPrefix) {
                const _cmd = msgText.slice(1).split(' ')[0].toLowerCase();
                if (['bcbot','broadcastbot'].includes(_cmd)) continue;

                if (['botsonline','subbotsonline'].includes(_cmd)) {
                    console.log(`[Heartbeat] 🤖 SubBot #${num} activo (respuesta a botsonline)`);
                    continue;
                }
            }

            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            // Si es un grupo donde el bot principal también está, el subbot cede
            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            // ✅ Todos los bots responden libremente en cualquier grupo

            // ── Guardado de historial de chat (solo grupos sin bot principal) ──
            if (!isFromMe && msgText && isGroupMsg) {
                const prefixesCheck = ['.', '/', '❤️', '#'];
                const isCmd = prefixesCheck.some(p => msgText.startsWith(p));
                if (!isCmd) {
                    try {
                        const senderJidChat = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                        const cleanSender = senderJidChat.split('@')[0].split(':')[0].replace(/\D/g, '');
                        if (cleanSender && cleanSender.length >= 5) {
                            const chatDir = path.join(__dirname, '../../data/CHATS-USUARIOS', msgChatJid);
                            if (!fs.existsSync(chatDir)) fs.mkdirSync(chatDir, { recursive: true });
                            const chatFile = path.join(chatDir, `${cleanSender}.txt`);
                            const linea = msgText.replace(/\n/g, ' ').trim();
                            if (linea) fs.appendFileSync(chatFile, linea + '\n', 'utf-8');
                        }
                    } catch (_) {}
                }
            }
            // ────────────────────────────────────────────────────────────────

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                // Guardar el socket en el mensaje para que los plugins puedan usarlo
                // directamente sin depender de global.conn (que puede ser pisado por
                // otro subbot concurrente mientras este await está en vuelo).
                compatibleMessage._sock  = sock;
                compatibleMessage._subNum = num;

                // NO mutar global.conn — causa condiciones de carrera cuando múltiples
                // subbots procesan mensajes en paralelo. Cada plugin debe usar
                // message._sock o message.reply() en lugar de global.conn.
                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
function reorderSubBotSessions() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    const alreadyOrdered = folders.every((n, i) => n === i + 1);
    if (alreadyOrdered) return;

    console.log(`[SubBot] Reordenando sesiones: [${folders.join(', ')}] → [${folders.map((_, i) => i + 1).join(', ')}]`);

    const tempNames = [];
    for (const num of folders) {
        const tempName = `_tmp_${num}_${Date.now()}`;
        const src = path.join(SESSIONS_DIR, String(num));
        const tmp = path.join(SESSIONS_DIR, tempName);
        fs.renameSync(src, tmp);
        tempNames.push(tempName);
    }

    for (let i = 0; i < tempNames.length; i++) {
        const tmp = path.join(SESSIONS_DIR, tempNames[i]);
        const dst = path.join(SESSIONS_DIR, String(i + 1));
        fs.renameSync(tmp, dst);
    }

    console.log(`[SubBot] Sesiones reordenadas correctamente.`);
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    reorderSubBotSessions();

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    for (const num of folders) {
        const credsFile = path.join(SESSIONS_DIR, String(num), 'creds.json');
        if (!fs.existsSync(credsFile)) continue;
        if (global.subConns.find(c => c._subNum === num && c.user)) continue;
        console.log(`[SubBot] Auto-reconectando bot #${num}...`);
        await sleep(2000);
        await connectSubBot({ num, chatJid: null, conn })
            .catch(e => console.error(`[SubBot] Error auto-reconexión #${num}:`, e.message));
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .serbot code <numero_internacional>',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const conn = global.conn;

        const helpText =
            `📌 *Cómo usar .serbot*\n\n` +
            `✅ *Opción 1 (QR):*\n` +
            `- Usa: \`.serbot qr\`\n` +
            `- *Necesitas otro dispositivo* (o una PC) donde se muestre el QR para poder escanearlo.\n` +
            `- En WhatsApp: *Dispositivos vinculados* → *Vincular un dispositivo* → escanea el QR.\n\n` +
            `✅ *Opción 2 (CODE):*\n` +
            `- Usa: \`.serbot code <numero>\`\n` +
            `- *No necesitas otro dispositivo*.\n` +
            `- El número debe ir en *formato internacional*\n` +
            `  Ejemplos:\n` +
            `  - \`.serbot code 59893900470\`\n` +
            `  - \`.serbot code +598 93 900 470\` (también sirve)\n\n` +
            `ℹ️ *¿No sabés tu número en formato internacional?*\n` +
            `Usa \`.numwa <país> <tu número>\` y el bot te lo devuelve listo para copiar.\n` +
            `Ejemplos:\n` +
            `- \`.numwa uruguay 093900470\`\n` +
            `- \`.numwa argentina 01123456789\`\n` +
            `- \`.numwa mexico 5512345678\`\n` +
            `- \`.numwa españa 612345678\`\n`;

        if (message.isGroup) {
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // Subcomandos: .serbot qr | .serbot code <numero>
        // Unir todos los args y limpiar para manejar espacios extras
        const allArgs = (args || []).filter(a => a.trim() !== '');
        const arg0 = (allArgs[0] || '').trim().toLowerCase();

        let usePairingCode = false;
        let phoneNumber    = null;
        let token          = null;

        if (arg0 === 'qr') {
            // .serbot qr → forzar QR
            usePairingCode = false;
        } else if (arg0 === 'code') {
            // .serbot code <numero> — acepta +598 939 004 70, 598-939-004-70, etc.
            const rawNumber = allArgs.slice(1).join(''); // unir todo lo que sigue, ignorando espacios
            const cleanedNumber = rawNumber.replace(/[^0-9]/g, '');
            if (!cleanedNumber || cleanedNumber.length < 7 || cleanedNumber.length > 15) {
                return conn.sendMessage(message.from, {
                    text: `❌ Debes indicar el número en formato internacional.\n\n${helpText}`
                }, { quoted: message._baileyMessage });
            }
            usePairingCode = true;
            phoneNumber    = cleanedNumber;
        } else {
            // NO aceptar: .serbot | .serbot <numero> | cualquier cosa distinta de "qr" o "code <numero>"
            return conn.sendMessage(message.from, { text: helpText }, { quoted: message._baileyMessage });
        }

        if (pendingQR.has(senderJid)) {
            return conn.sendMessage(message.from, {
                text: `⏳ Ya tienes un proceso pendiente. Espera a que expire para generar uno nuevo.`
            }, { quoted: message._baileyMessage });
        }

        const existingNum = getSubBotNumberByOwner(senderJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (alreadyActive) {
                return conn.sendMessage(message.from, {
                    text: `ℹ️ Ya eres el Sub-Bot #${existingNum}.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                }, { quoted: message._baileyMessage });
            }
            pendingQR.add(senderJid);
            conn.sendMessage(message.from, {
                text: usePairingCode
                    ? `⏳ Generando código para reconectar sub-bot #${existingNum} con el número *${phoneNumber}*...`
                    : `⏳ Reconectando tu sub-bot #${existingNum} con QR...`
            }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
        }

        const num = nextSubBotNumber();

        pendingQR.add(senderJid);
        conn.sendMessage(message.from, {
            text: usePairingCode
                ? `⏳ Generando código de emparejamiento para el número *${phoneNumber}* (sub-bot #${num})...\n\n_En unos segundos recibirás el código de 8 dígitos._`
                : token
                    ? `⏳ Restaurando sesión como sub-bot #${num}...`
                    : `⏳ Generando QR para sub-bot #${num}...`
        }, { quoted: message._baileyMessage });

        await connectSubBot({ num, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn   = global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (conn?.user) {
            const mainPhoneNum = conn.user.id.split('@')[0].split(':')[0];
            let mainGroupCount = '?';
            try {
                const chats = await conn.groupFetchAllParticipating();
                mainGroupCount = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                }).length;
            } catch (e) {
                console.error(`[listBots] Error contando grupos bot principal:`, e.message);
            }
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}\n👥 Grupos: ${mainGroupCount}`);
        }

        if (active.length > 0) {
            const subBotLines = await Promise.all(active.map(async c => {
                const phoneNum = c.user.id.split('@')[0].split(':')[0];
                let groupCount = '?';
                try {
                    const chats = await c.groupFetchAllParticipating();
                    groupCount = Object.values(chats).filter(g => {
                        const jid = g.id;
                        if (jid.includes('@newsletter')) return false;
                        if (g.announce === true) return false;
                        return jid.endsWith('@g.us');
                    }).length;
                } catch (e) {
                    console.error(`[listBots] Error contando grupos subbot #${c._subNum}:`, e.message);
                }
                return `🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}\n👥 Grupos: ${groupCount}`;
            }));
            lines.push(...subBotLines);
        }

        if (lines.length === 0) {
            return conn.sendMessage(message.from, { text: '📭 No hay bots conectados.' }, { quoted: message._baileyMessage });
        }

        const totalBots = (conn?.user ? 1 : 0) + active.length;
        conn.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${totalBots}*\n\n${lines.join('\n\n')}`
        }, { quoted: message._baileyMessage });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    help: 'Ver qué bots están activos (solo en el grupo oficial)',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const officialGroupJid = OFFICIAL_GROUP;
        if (message.from !== officialGroupJid) return;

        const conn = global.conn;
        await conn.sendMessage(officialGroupJid, {
            text: '🟢 *Bot principal activo* ✅'
        }, { quoted: message._baileyMessage });

        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        for (const subSock of active) {
            await sleep(800);
            try {
                await subSock.sendMessage(officialGroupJid, {
                    text: `🤖 *SubBot #${subSock._subNum}* está activo ✅`
                });
            } catch (e) {
                console.error(`[SubBot] Error respuesta botsonline #${subSock._subNum}:`, e.message);
            }
        }
    }
};

/** Versión para el servidor web: genera QR */
async function connectSubBotWeb({ num, conn }) {
    return connectSubBot({ num, chatJid: null, conn });
}

/** Versión para el servidor web: genera código de emparejamiento */
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) {
    return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber });
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    listBots:            listBotsHandler,
};