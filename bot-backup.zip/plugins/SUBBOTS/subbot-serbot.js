'use strict';
/**
 * Plugin de Sub-Bots (con IDs únicos de 4 dígitos)
 * Refactorizado: Sistema de reconexión simplificado, sin wrappers pesados ni fugas de memoria.
 */

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Identificador del grupo oficial usado para comandos específicos.
const OFFICIAL_GROUP = '120363203689229697@g.us';

const activeSocks = new Map();
const pendingQR = new Set();
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Caché de grupos donde está el bot principal ───────────────────────────────
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000;

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) {
                    mainBotGroupsCache.add(jid);
                }
            }
        } catch (e) {}
    }
    return mainBotGroupsCache.has(groupJid);
}

/**
 * Sigue el canal público de WhatsApp.
 */
async function followPublicChannel(sock, botLabel = 'Bot') {
    await sleep(3000);
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        if (inviteCode) {
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            if (metadata?.id) {
                await sock.newsletterFollow(metadata.id);
                console.log(`[${botLabel}] ✅ Bot siguiendo el canal exitosamente.`);
            }
        }
    } catch (error) {
        if (!error.message?.includes('unexpected response structure')) {
            console.error(`[${botLabel}] ❌ Error real al seguir el canal:`, error.message);
        }
    }
    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

// Genera un ID único aleatorio de 4 dígitos (1000-9999)
function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do {
        n = Math.floor(1000 + Math.random() * 9000);
    } while (existing.includes(n));
    return n;
}

// Renombrar sesiones antiguas a formato de 4 dígitos estático (solo una vez)
function renameOldSessions() {
    if (!fs.existsSync(SESSIONS_DIR)) return;
    
    const files = fs.readdirSync(SESSIONS_DIR);
    let renamed = 0;
    
    const existing = new Set(
        files.map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
             .filter(n => !isNaN(n))
    );

    for (const file of files) {
        const match = file.match(/^(\d+)\.db$/);
        if (!match) continue;
        
        const numStr = match[1];
        if (numStr.length >= 4) continue;
        
        let newNum;
        do {
            newNum = Math.floor(1000 + Math.random() * 9000);
        } while (existing.has(newNum));
        existing.add(newNum);

        const oldPath = path.join(SESSIONS_DIR, file);
        const newName = `${newNum}.db`;
        const newPath = path.join(SESSIONS_DIR, newName);
        
        try {
            try {
                const Database = require('better-sqlite3');
                const db = new Database(oldPath);
                const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                if (row) {
                    const data = JSON.parse(row.value);
                    data.num = newNum;
                    db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(data));
                }
                db.close();
            } catch (e) { /* Ignorar errores de DB */ }

            fs.renameSync(oldPath, newPath);
            console.log(`[SubBot] ✅ Renombrado permanente: ${file} → ${newName}`);
            renamed++;
        } catch (e) {
            console.error(`[SubBot] ❌ Error renombrando ${file}:`, e.message);
        }
    }
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ── Helper: enviar mensaje al dueño de forma segura
async function sendToOwnerSafe(ownerJid, content, sock, globalConn) {
    if (!ownerJid) return;
    try {
        await sock.sendMessage(ownerJid, content);
    } catch {
        try {
            await globalConn.sendMessage(ownerJid, content);
        } catch {}
    }
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;

    if (fs.existsSync(dbFile)) {
        try {
            const Database = require('better-sqlite3');
            const _db = new Database(dbFile, { readonly: true });
            const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            _db.close();
            if (row) {
                const data = JSON.parse(row.value);
                if (!ownerJid) ownerJid = data.ownerJid;
                if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            const Database = require('better-sqlite3');
            const { BufferJSON } = require('@whiskeysockets/baileys');
            const _db = new Database(dbFile);
            _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('creds', JSON.stringify(decoded, BufferJSON.replacer));
            _db.close();
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        browser: ['Ubuntu', 'Chrome', '22.04'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false
    });

    sock._subName    = name;
    sock._subNum     = num;
    sock._sessDb     = dbFile;
    sock._ownerJid   = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime      = Date.now();
    activeSocks.set(name, sock);

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false;
    let codeSent             = false;
    let pairingCodeRequested = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // Flujo Pairing Code
        if (usePairingCode && phoneNumber && !pairingCodeRequested && !connected && !state.creds.registered && (connection === 'connecting' || !!qr)) {
            pairingCodeRequested = true;
            await sleep(connection === 'connecting' ? 3000 : 500);
            if (connected) return;

            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);
                codeSent = true;
                
                await sendToOwnerSafe(ownerJid, {
                    text: `🔐 *Código para sub-bot #${num}*\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                }, sock, conn || global.conn);
                await sendToOwnerSafe(ownerJid, { text: code }, sock, conn || global.conn);

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                qrTimeout = setTimeout(() => {
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwnerSafe(ownerJid, { text: `⏰ Código expirado. Genera uno nuevo.` }, sock, conn || global.conn);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwnerSafe(ownerJid, { text: `❌ Error generando código: ${e.message}` }, sock, conn || global.conn);
            }
            return;
        }

        // Flujo QR
        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwnerSafe(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` }, sock, conn || global.conn);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwnerSafe(ownerJid, {
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                }, sock, conn || global.conn);
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwnerSafe(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` }, sock, conn || global.conn);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 35000);
            } catch (e) {}
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch {}

            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);

            if (ownerJid) {
                const phoneNum = sock.user?.id?.split('@')[0]?.split(':')[0] || '?';
                await sendToOwnerSafe(ownerJid, { text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` }, sock, conn || global.conn);
            }

            setTimeout(() => followPublicChannel(sock, `SubBot #${num}`), 3000);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);

            // LoggedOut o Baneado/Expulsado
            if (code === DisconnectReason.loggedOut || code === 401 || code === 403 || code === 405) {
                try { if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile); } catch {}
                sendToOwnerSafe(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada o inválida. Usa \`.serbot qr\` o \`.serbot code\` para reconectar.` }, sock, conn || global.conn);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // Fallas de red o stream, reconexión simple
            setTimeout(() => {
                console.log(`[SubBot] Reconectando bot #${num}...`);
                connectSubBot({ num, chatJid: ownerJid, conn });
            }, 8000); // 8 segundos fijo para no sobrecargar
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // ── Procesar mensajes (Minimalista) ──────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Set();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.add(messageId);

            // Limpieza básica y barata del Set
            if (processedIds.size > 500) {
                const arr = Array.from(processedIds).slice(-200);
                processedIds.clear();
                arr.forEach(id => processedIds.add(id));
            }

            const msgText = getMessageText(baileyMessage);
            const hasPrefix = ['.', '/', '❤️', '#'].some(p => msgText.startsWith(p));
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            if (baileyMessage.key.fromMe && !hasPrefix) continue;
            if (!msgText && !hasPrefix) continue;
            if (msgChatJid === OFFICIAL_GROUP) continue;

            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock  = sock;
                compatibleMessage._subNum = num;

                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Migración automática: carpetas viejas → .db ─────────────────────────────
async function migrarSesionesLegacy() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    let Database, BufferJSON;
    try {
        Database  = require('better-sqlite3');
        ({ BufferJSON } = require('@whiskeysockets/baileys'));
    } catch (e) { return; }

    const KNOWN_TYPES = [
        'app-state-sync-key', 'app-state-sync-version',
        'sender-key-memory', 'sender-key', 'pre-key', 'session',
    ];

    const carpetas = fs.readdirSync(SESSIONS_DIR)
        .filter(e => !isNaN(parseInt(e)) && fs.statSync(path.join(SESSIONS_DIR, e)).isDirectory())
        .map(e => parseInt(e));

    for (const num of carpetas) {
        const folderPath = path.join(SESSIONS_DIR, String(num));
        const destFile   = path.join(SESSIONS_DIR, `${num}.db`);
        const credsFile  = path.join(folderPath, 'creds.json');

        if (fs.existsSync(destFile) || !fs.existsSync(credsFile)) {
            try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch {}
            continue;
        }

        try {
            const db = new Database(destFile);
            db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            const stmtSet = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');

            const allFiles = fs.readdirSync(folderPath);
            db.transaction(() => {
                for (const file of allFiles) {
                    if (!file.endsWith('.json')) continue;
                    try {
                        const content = JSON.parse(fs.readFileSync(path.join(folderPath, file), 'utf-8'), BufferJSON.reviver);
                        const nameNoExt = file.replace(/\.json$/, '');

                        if (nameNoExt === 'creds') { stmtSet.run('creds', JSON.stringify(content, BufferJSON.replacer)); continue; }
                        if (nameNoExt === 'owner') { stmtSet.run('_owner', JSON.stringify(content)); continue; }

                        let matched = false;
                        for (const type of KNOWN_TYPES) {
                            if (nameNoExt.startsWith(type + '-')) {
                                stmtSet.run(`${type}-${nameNoExt.slice(type.length + 1)}`, JSON.stringify(content, BufferJSON.replacer));
                                matched = true; break;
                            }
                        }
                        if (!matched) stmtSet.run(nameNoExt, JSON.stringify(content, BufferJSON.replacer));
                    } catch {}
                }
            })();
            db.close();
            fs.rmSync(folderPath, { recursive: true, force: true });
        } catch (err) {
            try { if (fs.existsSync(destFile)) fs.unlinkSync(destFile); } catch {}
        }
    }
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    await migrarSesionesLegacy();
    renameOldSessions();

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    console.log(`[SubBot] Auto-reconexión — ${nums.length} sesiones detectadas`);

    for (const num of nums) {
        if (activeSocks.has(String(num))) continue;
        console.log(`[SubBot] Levantando sesión #${num}...`);
        try {
            await connectSubBot({ num, chatJid: null, conn });
            await sleep(3000); // Evitar bloqueos de WhatsApp al levantar múltiples sesiones
        } catch (e) {
            console.error(`[SubBot] Error al levantar #${num}:`, e.message);
        }
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .serbot code | .qr | .code [numero]',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message)) return;

        if (isSubBotMessage(message)) {
            const mainNumClean = getMainBotNumber();
            const mainContact = mainNumClean ? `+${mainNumClean}` : 'el bot principal';
            return sock.sendMessage(message.from, {
                text: `ℹ️ Para crear un sub-bot escribile directamente al *bot principal*.\n📱 *Número:* ${mainContact}\n_Los sub-bots no generan nuevas sesiones._`
            }, { quoted: message._baileyMessage });
        }

        const rawCmd = (message.text || message.body || '').trim().slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        if (message.isGroup) {
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');

        let arg0 = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        
        let codeRaw;
        if (isDirectCode) {
            const fullText = (message.text || message.body || '').trim();
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const jidReal = message.key?.participantAlt || message.key?.remoteJid || senderJid;
                const autoNumber = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                if (!autoNumber) return sock.sendMessage(message.from, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` });
                usePairingCode = true;
                phoneNumber    = autoNumber;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(message.from, { text: '📌 Opciones: \`.serbot qr\` o \`.serbot code\`' });
        }

        if (pendingQR.has(senderJid)) {
            return sock.sendMessage(message.from, { text: `⏳ Ya tenés un proceso pendiente.` });
        }

        const targetJid = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);
        
        if (existingNum !== null) {
            if (global.subConns.find(c => c._subNum === existingNum && c.user)) {
                return sock.sendMessage(message.from, { text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.` });
            }
            pendingQR.add(senderJid);
            sock.sendMessage(message.from, { text: `⏳ Reconectando tu sub-bot #${existingNum}...` });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber });
        }

        const num = nextSubBotNumber();
        pendingQR.add(senderJid);
        sock.sendMessage(message.from, { text: `⏳ Generando acceso para sub-bot #${num}...` });
        connectSubBot({ num, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message)) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0) return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, { text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}` });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    tags: ['subbots'],
    handler: async (message) => {
        if (message.from !== OFFICIAL_GROUP) return;
        const sock = message._sock || global.conn;
        await sock.sendMessage(OFFICIAL_GROUP, { text: '🟢 *Bot principal activo* ✅' });
        for (const subSock of global.subConns.filter(c => c.user)) {
            await sleep(800);
            try { await subSock.sendMessage(OFFICIAL_GROUP, { text: `🤖 *SubBot #${subSock._subNum}* está activo ✅` }); } catch {}
        }
    }
};

async function connectSubBotWeb({ num, conn }) { return connectSubBot({ num, chatJid: null, conn }); }
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) { return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber }); }

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    listBots:            listBotsHandler,
};