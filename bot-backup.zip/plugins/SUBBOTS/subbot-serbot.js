'use strict';

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');
const { isBorradosEnabled } = require(path.join(__dirname, '..', 'HERRAMIENTAS', 'GRUPOS', 'borrados'));

// ── IMPORTAR MÓDULO DE BIENVENIDAS ──
const welcomeGoodbyeModule = require('../../plugins/HERRAMIENTAS/bienvenida-despedida');

// ── IMPORTAR SISTEMA DE TRACKING DE ACTIVIDAD ──
const activityTracker = require('./subbotActivityTracker');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
// Limpiar archivos huérfanos de sesiones al arrancar
try { cleanOrphanSessionFiles(); } catch (e) { console.error('[SubBot] Error limpieza inicial sesiones:', e.message); }

if (!global.subConns) global.subConns = [];

const OFFICIAL_GROUP       = '120363203689229697@g.us';
const GOFC_SUBBOTS_FILE    = path.join(__dirname, 'data', 'gofc-subbots.json');

/**
 * Devuelve true si el subbot (por su _subNum) está en la lista blanca
 * de subbots permitidos para responder en el grupo oficial.
 */
function isSubbotAllowedInOfficial(subNum) {
    try {
        if (!fs.existsSync(GOFC_SUBBOTS_FILE)) return false;
        const data = JSON.parse(fs.readFileSync(GOFC_SUBBOTS_FILE, 'utf8'));
        const list = Array.isArray(data.allowedSubbots) ? data.allowedSubbots : [];
        return list.includes(subNum);
    } catch (e) {
        console.error('[SubBot] Error leyendo gofc-subbots.json:', e.message);
        return false;
    }
}
const activeSocks = new Map();
const pendingQR = new Set();
const reconnectTimers = new Map();
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Caché de grupos donde está el bot principal ───────────────────────────────
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000;

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) mainBotGroupsCache.add(jid);
            }
        } catch (e) {}
    }
    return mainBotGroupsCache.has(groupJid);
}

function hasFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return false;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = 2000');
        db.pragma('busy_timeout = 2000');
        const row = db.prepare("SELECT value FROM auth WHERE key = 'hasFollowedChannel'").get();
        db.close();
        return !!row;
    } catch (e) {
        return false;
    }
}

function setFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile);
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('busy_timeout = 5000');
        db.prepare("INSERT OR REPLACE INTO auth (key, value) VALUES ('hasFollowedChannel', 'true')").run();
        db.close();
    } catch (e) {
        console.error('[SubBot Db] Error guardando estado de canal seguido:', e.message);
    }
}

async function followPublicChannel(sock, botLabel = 'Bot') {
    await sleep(4000);
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        
        if (inviteCode) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            
            // Obtiene los metadatos reales usando el código del enlace
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            
            if (metadata && metadata.id) {
                const channelJid = metadata.id;

                // El bot sigue al canal de WhatsApp
                await sock.newsletterFollow(channelJid);
                console.log(`[Canal ${botLabel}] Unido exitosamente`);
            }
        }
    } catch (error) {
        // Filtra el falso error de Baileys v7 si la suscripción ya está activa
        if (error.message?.includes('unexpected response structure')) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            console.log(`[Canal ${botLabel}] Ya siguiendo al canal, intentando confirmar...`);
            console.log(`[Canal ${botLabel}] Ya sigue al canal. CONFIRMADO`);
        } else {
            // Muestra en rojo si es un error real diferente
            console.error(`[Canal ${botLabel}] ❌ Error real al seguir el canal:`, error.message);
            return false;
        }
    }
    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function sessionFiles(num) {
    const base = path.join(SESSIONS_DIR, String(num));
    return [
        `${base}.db`,
        `${base}.db-wal`,
        `${base}.db-shm`
    ];
}

function removeSessionFiles(num) {
    const files = sessionFiles(num);
    for (const f of files) {
        try {
            if (fs.existsSync(f)) {
                fs.unlinkSync(f);
                console.log(`[SubBot] 🗑️ Eliminado archivo de sesión: ${path.basename(f)}`);
            }
        } catch (e) {
            console.error(`[SubBot] Error eliminando ${f}:`, e.message);
        }
    }
}

function cleanOrphanSessionFiles() {
    try {
        if (!fs.existsSync(SESSIONS_DIR)) return;
        const files = fs.readdirSync(SESSIONS_DIR);
        const grouped = {};
        for (const f of files) {
            const m = f.match(/^(\d+)(?:\.db|\.db-wal|\.db-shm)$/);
            if (!m) continue;
            const n = parseInt(m[1]);
            if (!grouped[n]) grouped[n] = new Set();
            grouped[n].add(f);
        }

        for (const nStr of Object.keys(grouped)) {
            const n = parseInt(nStr);
            const names = Array.from(grouped[n]);
            // Si no existe el .db pero hay wal/shm, limpiar todos los archivos asociados
            const hasDb = names.some(x => x.endsWith('.db'));
            if (!hasDb) {
                console.log(`[SubBot Garbage Collector] 🗑️ Archivo .db faltante para #${n}, limpiando restos: ${names.join(', ')}`);
                removeSessionFiles(n);
            }
        }
    } catch (e) {
        console.error('[SubBot Garbage Collector] Error escaneando sesiones:', e.message);
    }
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do { n = Math.floor(1000 + Math.random() * 9000); } while (existing.includes(n));
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            if (fs.statSync(dbPath).size <= 13000) continue;
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 3000');
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null, isNewLinking = false }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;

    if (fs.existsSync(dbFile)) {
        try {
            if (fs.statSync(dbFile).size > 13000) {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile, { readonly: true });
                _db.pragma('cache_size = 5000');
                _db.pragma('busy_timeout = 3000');
                const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                _db.close();
                if (row) {
                    const data = JSON.parse(row.value);
                    if (!ownerJid) ownerJid = data.ownerJid;
                    if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                }
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        browser: ['Windows', 'Chrome', '110.0.5585.95'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 5000,
        keepAliveIntervalMs: 30000
    });

    // Exponer la función de guardado para reinicios limpios
    try { sock._saveCreds = saveCreds; } catch (e) {}

    sock._subName        = name;
    sock._subNum         = num;
    sock._sessDb         = dbFile;
    sock._ownerJid       = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime          = Date.now();
    activeSocks.set(name, sock);

    if (welcomeGoodbyeModule?.init) {
        try {
            welcomeGoodbyeModule.init(sock);
            console.log(`[SubBot #${num}] ✓ Módulo Bienvenida/Despedida conectado.`);
        } catch (error) {
            console.error(`[SubBot #${num}] ❌ Error iniciando Bienvenida/Despedida:`, error.message);
        }
    }

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false;
    let codeSent             = false;
    let pairingCodeRequested = false;

    const sendToOwner = async (content) => {
        if (!ownerJid) return;
        const sender = (connected ? sock : (conn || global.conn));
        if (!sender) return; // bot principal aún no conectado, no se puede notificar
        try {
            await sender.sendMessage(ownerJid, content);
        } catch (e) {
            try {
                const fallback = sender === sock ? (conn || global.conn) : sock;
                if (fallback) await fallback.sendMessage(ownerJid, content);
            } catch {}
        }
    };

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (
            usePairingCode &&
            phoneNumber &&
            !pairingCodeRequested &&
            !connected &&
            !state.creds.registered &&
            (connection === 'connecting' || !!qr)
        ) {
            pairingCodeRequested = true;
            await sleep(connection === 'connecting' ? 3000 : 500);
            if (connected) return;

            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);
                codeSent = true;

                await sendToOwner({
                    text: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                });
                await sendToOwner({ text: code });

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                qrTimeout = setTimeout(() => {
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ Código expirado. Genera uno nuevo con \`.code\`.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `❌ Error generando código: ${e.message}` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }
            return;
        }

        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwner({
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                });
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 35000);
            } catch (e) {}
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.pragma('journal_mode = WAL');
                _db.pragma('synchronous = NORMAL');
                _db.pragma('cache_size = 10000');
                _db.pragma('busy_timeout = 5000');
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch {}

            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);

            if (ownerJid) {
                const phoneNum = sock.user?.id?.split('@')[0]?.split(':')[0] || '?';
                await sendToOwner({ text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` });
            }

            // ── Unirse al canal 60 segundos después de vincularse ──
            const dbFile = sessionPath(num);
            if (isNewLinking) {
                if (!hasFollowedChannelDb(dbFile)) {
                    const delay = 60000; // 60 segundos
                    console.log(`[Canal SubBot #${num}] Nuevo sub-bot vinculado. Programado unirse al canal en 60 segundos...`);
                    setTimeout(async () => {
                        try {
                            const success = await followPublicChannel(sock, `SubBot #${num}`);
                            if (success) {
                                setFollowedChannelDb(dbFile);
                            }
                        } catch (e) {
                            console.error(`[Canal SubBot #${num}] Error en followPublicChannel:`, e.message);
                        }
                    }, delay);
                } else {
                    console.log(`[Canal SubBot #${num}] El sub-bot ya sigue al canal en esta sesión (omitido)`);
                }
            } else {
                console.log(`[Canal SubBot #${num}] Conexión/Reconexión establecida. No se une al canal (omitido)`);
            }
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);

            const isLoggedOut = code === DisconnectReason.loggedOut;

            // 515 = puede ser conflicto de dispositivo O ruido del handshake inicial
            // Si el bot nunca llegó a conectarse (connected = false), reconectar sin borrar sesión
            if (code === 515) {
                if (!connected) {
                    console.log(`[SubBot] ⚠️ Bot #${num} error 515 durante vinculación (aún no conectado). Reconectando...`);
                    const tid515 = setTimeout(() => {
                        reconnectTimers.delete(name);
                        connectSubBot({ num, chatJid: ownerJid, conn });
                    }, 3000);
                    reconnectTimers.set(name, tid515);
                    return;
                }
                // Si ya había estado conectado, sí es conflicto real
                console.log(`[SubBot] ⚠️ Bot #${num} error 515 (sesión reemplazada por otro dispositivo).`);
                try { removeSessionFiles(num); } catch {}
                sendToOwner({
                    text: `⚠️ *Sub-bot #${num} desconectado (515)*\n\nEl número vinculado ya tiene sesión activa en otro teléfono o app.\n\n📌 *Solución:* Cerrá sesión de WhatsApp en el otro dispositivo y usá \`.code\` de nuevo.`
                });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // 401 = sesión inválida/expirada → borrar y avisar, NO reconectar
            if (code === 401) {
                console.log(`[SubBot] ❌ Bot #${num} recibió error 401 (sesión inválida). Borrando sesión.`);
                try { removeSessionFiles(num); } catch {}
                sendToOwner({
                    text: `❌ *Sub-bot #${num} sesión inválida (401)*\n\nLa sesión expiró o fue revocada.\n\n💡 Usá \`.code\` o \`.serbot qr\` para crear una nueva.`
                });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            if (isLoggedOut || code === 440) {
                if (isLoggedOut) {
                    try { removeSessionFiles(num); } catch {}
                }
                if (code === 440) {
                    console.log(`[SubBot] ⚠️ Bot #${num} reemplazado (440). NO reconectará para evitar bucle.`);
                    return;
                }
                sendToOwner({ text: `⚠️ Sesión del sub-bot #${num} cerrada o inválida. Usá \`.serbot qr\` o \`.code\` para reconectar.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // Error 403 (Forbidden) - la sesión está baneada o inválida y no puede repararse
            if (code === 403) {
                console.log(`[SubBot] ❌ Sub-bot #${num} recibió error 403 (Forbidden). La sesión está inválida/baneada.`);
                console.log(`[SubBot] 🗑️ Eliminando sesión corrupta del sub-bot #${num}...`);
                try { removeSessionFiles(num); } catch (e) {
                    console.error(`[SubBot] Error eliminando sesión #${num}:`, e.message);
                }
                sendToOwner({ text: `❌ Sub-bot #${num} error 403 (Forbidden).\n\n⚠️ Sesión eliminada por inválida o baneada.\n\n💡 Usá \`.serbot qr\` o \`.code\` para crear una nueva.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // Otros errores de autenticación (405)
            if (code === 405) {
                console.log(`[SubBot] ⚠️ Sub-bot #${num} recibió un error de auth (${code}). Intentando reconectar sin borrar la sesión.`);
                sendToOwner({ text: `⚠️ Sub-bot #${num} tuvo un error de auth (${code}). Se reintentará reconexión automática.` });
            }

            // ── Reconexión con delay optimizado para recursos del servidor ──
            const reconnectDelay = 5000 + (Math.abs(num % 10) * 500);

            if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));

            const tid = setTimeout(() => {
                reconnectTimers.delete(name);
                console.log(`[SubBot] Reconectando bot #${num}...`);
                connectSubBot({ num, chatJid: ownerJid, conn });
            }, reconnectDelay);

            reconnectTimers.set(name, tid);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // ── Anunciar cambios de admin en grupos (promote/demote externos) ────────
    sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
        if (action !== 'promote' && action !== 'demote') return;
        try {
            for (const participantJid of participants) {
                const targetNum = participantJid.split('@')[0].split(':')[0];
                const msg = action === 'promote'
                    ? `👑 *@${targetNum} ahora es administrador del grupo*`
                    : `👤 *@${targetNum} ya no es administrador del grupo*`;
                await sock.sendMessage(id, { text: msg, mentions: [participantJid] });
            }
        } catch {}
    });

        const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
        const processedIds = new Set();
        const recentGroupMessages = new Map();
        const RECENT_MESSAGE_TTL = 5 * 60 * 1000; // 5 minutos
        sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.add(messageId);

            if (processedIds.size > 500) {
                const arr = Array.from(processedIds).slice(-200);
                processedIds.clear();
                arr.forEach(id => processedIds.add(id));
            }

            // ── Limpiar cache de mensajes recientes de grupo ────────────────
            const now = Date.now();
            for (const [groupId, groupMap] of recentGroupMessages.entries()) {
                for (const [msgId, msg] of groupMap.entries()) {
                    const ts = (msg.messageTimestamp || 0) * 1000;
                    if (!ts || now - ts > RECENT_MESSAGE_TTL) {
                        groupMap.delete(msgId);
                    }
                }
                if (groupMap.size === 0) recentGroupMessages.delete(groupId);
            }

            // ── Verificar y eliminar mensajes de usuarios muteados ────────────
            // Se hace ANTES de cualquier otro filtro para garantizar la eliminación
            if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                if (baileyMessage.message.protocolMessage?.type === 0 && baileyMessage.message.protocolMessage?.key) {
                    const deletedKey = baileyMessage.message.protocolMessage.key;
                    const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid);
                    const original = groupMap?.get(deletedKey.id);

                    if (original && isBorradosEnabled(baileyMessage.key.remoteJid)) {
                        const deletedText = original.message.conversation || original.message.extendedTextMessage?.text || '';
                        const hasLink = /(https?:\/\/|www\.)/i.test(deletedText);

                        if (deletedText.trim().length > 0 && !hasLink) {
                            const userNum = (original.key.participant || original.key.remoteJid || '').split('@')[0].split(':')[0];
                            await sock.sendMessage(baileyMessage.key.remoteJid, {
                                text: `📌 El usuario @${userNum} eliminó este mensaje:\n\n${deletedText}`,
                                mentions: [original.key.participant || original.key.remoteJid]
                            });
                        }
                    }
                    continue;
                }

                const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid) || new Map();
                groupMap.set(messageId, baileyMessage);
                recentGroupMessages.set(baileyMessage.key.remoteJid, groupMap);
            }

            if (global.muteSystem && baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                try {
                    const wasDeleted = await global.muteSystem.checkAndDeleteMutedMessage(baileyMessage, sock);
                    if (wasDeleted) continue;
                } catch (e) { /* silencioso */ }
            }
            // ─────────────────────────────────────────────────────────────────

            // ── Respuestas automáticas (subbot): misma lógica que mute ────────
            if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                try {
                    const fs = require('fs');
                    const path = require('path');
                    const respFile = path.join(__dirname, '..', '..', 'data', 'respuestas-usuarios.json');
                    if (fs.existsSync(respFile)) {
                        const respData = JSON.parse(fs.readFileSync(respFile, 'utf8'));
                        const remoteJid = baileyMessage.key.remoteJid;
                        const senderNum = (baileyMessage.key.participant || remoteJid).split('@')[0].split(':')[0];
                        const isMuted = global.muteSystem?.isUserMuted(remoteJid, senderNum);
                        if (!isMuted && respData[remoteJid]?.[senderNum]?.length) {
                            const lista = respData[remoteJid][senderNum];
                            const texto = lista[Math.floor(Math.random() * lista.length)];
                            await sock.sendMessage(remoteJid, { text: texto }, { quoted: baileyMessage });
                        }
                    }
                } catch (e) { /* silencioso */ }
            }
            // ─────────────────────────────────────────────────────────────────

            const msgText    = getMessageText(baileyMessage);
            const hasPrefix  = ['.', '/', '❤️', '#'].some(p => msgText.startsWith(p));
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            // ── Registro de actividad de usuario (SIEMPRE, antes de cualquier skip) ──
            if (!baileyMessage.key.fromMe && isGroupMsg) {
                try {
                    const senderJidRec = baileyMessage.key.participant || msgChatJid;
                    const cleanSenderRec = senderJidRec.split('@')[0].split(':')[0].replace(/\D/g, '');

                    // Registrar en chatHistory SQLite — esta es la fuente única
                    try {
                        const chatHistory = require('../../chatHistory');
                        const msgTimestamp = (baileyMessage.messageTimestamp || 0) * 1000;
                        if (chatHistory.isReady) {
                            chatHistory.recordMessage(msgChatJid, cleanSenderRec, msgText, msgTimestamp);
                        }
                    } catch (chErr) { /* silencioso */ }
                } catch (actErr) { /* silencioso */ }
            }
            // ──────────────────────────────────────────────────────────────────────────

            const hasQuotedContext = (msg) => {
                const ctx = msg?.contextInfo
                         || msg?.extendedTextMessage?.contextInfo
                         || msg?.extendedTextMessageV2?.contextInfo
                         || msg?.buttonsResponseMessage?.contextInfo
                         || msg?.listResponseMessage?.contextInfo
                         || msg?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
                         || msg?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
                         || msg?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
                         || msg?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
                         || null;
                return !!(ctx?.quotedMessage || ctx?.stanzaId || ctx?.participant);
            };

            const isQuotedReply = hasQuotedContext(baileyMessage.message);

            if (baileyMessage.key.fromMe && !hasPrefix && !isQuotedReply) continue;
            if (!msgText && !hasPrefix) continue;
            // Bloquear el grupo oficial excepto si el subbot está en la lista blanca
            if (msgChatJid === OFFICIAL_GROUP && !isSubbotAllowedInOfficial(num)) continue;

            if (isGroupMsg && global.conn?.user) {
                // Si el subbot está en la lista blanca del grupo oficial, puede responder
                // aunque el bot principal también esté en ese grupo
                const isAllowedOverride = msgChatJid === OFFICIAL_GROUP && isSubbotAllowedInOfficial(num);
                if (!isAllowedOverride) {
                    const mainInGroup = await isMainBotInGroup(msgChatJid);
                    if (mainInGroup) continue;
                }
            }

            try {
                if (!global.db?.data) continue;
                const compatibleMessage   = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock   = sock;
                compatibleMessage._subNum = num;

                // ── Registrar actividad del subbot cuando procesa un comando ──
                if (hasPrefix) {
                    activityTracker.recordActivity(num);
                }

                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage)
                        await global.commandHandler.handleMessage(compatibleMessage);
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Helpers ────────────────────────────────────────────────────────────────
function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

// ─── Fuerza cierre limpio de un subbot y lo reconecta ───────────────────────
async function forceReconnectSubBot({ num, chatJid, conn }) {
    const name     = String(num);
    const prevSock = activeSocks.get(name);

    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws?.terminate?.(); prevSock.ws?.close?.(); } catch {}
        activeSocks.delete(name);
    }

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    if (global.subConns) {
        const ci = global.subConns.findIndex(c => c._subNum === num);
        if (ci >= 0) global.subConns.splice(ci, 1);
    }

    await sleep(1500);
    return connectSubBot({ num, chatJid: chatJid || null, conn: conn || global.conn });
}

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .serbot | .qr | .code
// ════════════════════════════════════════════════════════════════════════════
const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .code',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        // Los subbots SÍ pueden procesar .serbot/.qr/.code — simplemente usan su propio socket

        const rawCmd       = (message.text || message.body || '').trim().slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');

        // El QR/código se manda siempre en el mismo chat donde se usó el comando
        const replyDest = message.from;

        let arg0    = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        let codeRaw = '';

        if (isDirectCode) {
            const fullText = (message.text || message.body || '').trim();
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const key      = message.key || {};
                // En grupos el sender real está en participant, no en remoteJid
                const jidReal  = key.participantAlt || key.remoteJidAlt || key.participant || senderJid;
                const autoNum  = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                if (!autoNum || autoNum.length < 7)
                    return sock.sendMessage(replyDest, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` }, { quoted: message._baileyMessage });
                usePairingCode = true;
                phoneNumber    = autoNum;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(replyDest, { text: '📌 Opciones: \`.serbot qr\` o \`.code\`' }, { quoted: message._baileyMessage });
        }

        if (pendingQR.has(senderJid))
            return sock.sendMessage(replyDest, { text: `⏳ Ya tenés un proceso pendiente.` }, { quoted: message._baileyMessage });

        const targetJid  = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);

        if (existingNum !== null) {
            const existingBot = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (existingBot) {
                if (existingBot.ws?.readyState === 1) {
                    return sock.sendMessage(replyDest, {
                        text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.\n💡 _Si no te está contestando, mandá *.reconnect* para reiniciar su sistema._`
                    }, { quoted: message._baileyMessage });
                } else {
                    try { existingBot.ev.removeAllListeners(); existingBot.ws.close(); } catch {}
                    activeSocks.delete(String(existingNum));
                    const ci = global.subConns.indexOf(existingBot);
                    if (ci >= 0) global.subConns.splice(ci, 1);
                }
            }

            try {
                removeSessionFiles(existingNum);
                console.log(`[SubBot] 🗑️ Sesión anterior borrada a petición del owner para bot #${existingNum}`);
            } catch (e) {}

            pendingQR.add(senderJid);
            sock.sendMessage(replyDest, { text: `⏳ Generando nueva sesión para tu sub-bot #${existingNum}...` }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true });
        }

        const num = nextSubBotNumber();
        pendingQR.add(senderJid);
        sock.sendMessage(replyDest, { text: `⏳ Generando acceso para sub-bot #${num}...` }, { quoted: message._baileyMessage });
        connectSubBot({ num, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .reconnect | .codebot
//  → Lo puede usar el owner del subbot O el propio subbot
//  → Desconecta y reconecta al 100% aunque esté "activo"
// ════════════════════════════════════════════════════════════════════════════
const reconnectHandler = {
    command: /^(reconnect|codebot)$/i,
    help: 'Reconectar tu sub-bot al 100%. Solo el owner o el propio sub-bot pueden usarlo.',
    tags: ['subbots'],
    handler: async (message) => {
        const sock      = message._sock || global.conn;
        const senderJid = message.author || message.sender || message.from;

        if (message.isGroup)
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });

        // Si lo manda el propio subbot, usamos ese número directamente
        let numToReconnect = message._subNum || null;

        // Si no, buscamos si el sender es owner de algún subbot
        if (!numToReconnect) numToReconnect = getSubBotNumberByOwner(senderJid);

        if (!numToReconnect) {
            return sock.sendMessage(message.from, {
                text: `❌ No tenés ningún sub-bot registrado para reconectar.`
            }, { quoted: message._baileyMessage });
        }

        await sock.sendMessage(message.from, {
            text: `🔄 Forzando reconexión completa del sub-bot #${numToReconnect}...\n⚠️ _Puede tardar unos segundos._`
        }, { quoted: message._baileyMessage });

        try {
            await forceReconnectSubBot({ num: numToReconnect, chatJid: senderJid, conn: global.conn || sock });
        } catch (e) {
            console.error(`[reconnect] Error reconectando subbot #${numToReconnect}:`, e.message);
            sock.sendMessage(message.from, { text: `⚠️ Error al reconectar: ${e.message}` });
        }
    }
};


// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .listbots | .bots | .subbots
// ════════════════════════════════════════════════════════════════════════════
const listBotsHandler = {
    command: /^(listbots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message) => {
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0)
            return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}\n\n💡 _Si tu sub-bot se tranca, mandá *.reconnect* para destrabarlo._`
        });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  Auto-reconexión al iniciar el bot - OPTIMIZADO CON PRIORIZACIÓN Y PARALELISMO
// ════════════════════════════════════════════════════════════════════════════
async function autoReconnectSubBots(conn) {
    // conn puede ser null si el bot principal aún no se conectó/escaneó.
    // Los subbots tienen sus propias sesiones y se conectan de forma independiente.
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    console.log(`[SubBot Monitor] Analizando bases de datos de sub-bots...`);
    console.log(`[SubBot Monitor] Encontrados ${nums.length} subbots registrados`);

    // ── Filtrar y limpiar sesiones fantasma ──────────────────────────────────
    const validNums = [];
    for (const num of nums) {
        const dbFile = sessionPath(num);

        try {
            if (fs.existsSync(dbFile)) {
                const stats = fs.statSync(dbFile);
                if (stats.size <= 13000) {
                    console.log(`[SubBot Garbage Collector] 🗑️ Eliminando registro fantasma #${num} (${stats.size} bytes)`);
                    try { removeSessionFiles(num); } catch (e) {}
                    continue;
                }
            }
        } catch (err) {
            console.error(`Error limpiando archivo #${num}:`, err.message);
        }

        if (activeSocks.has(String(num))) continue;
        validNums.push(num);
    }

    // ── Limpiar registros de actividad de subbots eliminados ─────────────────
    activityTracker.cleanupInvalidRecords([...validNums, ...nums]);

    if (validNums.length === 0) {
        console.log(`[SubBot Monitor] ✅ No hay subbots para reconectar`);
        return;
    }

    // ── Ordenar por último uso (más reciente primero) ────────────────────────
    const sortedNums = activityTracker.getSortedByActivity(validNums);
    
    console.log(`[SubBot Monitor] 🔄 Reconectando ${sortedNums.length} subbots en orden de prioridad...`);
    
    // Mostrar los primeros 5 más activos
    const top5 = sortedNums.slice(0, 5);
    for (const num of top5) {
        const stats = activityTracker.getActivityStats(num);
        if (stats.lastUsed) {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: ${stats.commandCount} comandos, último uso hace ${stats.daysSinceLastUse} días`);
        } else {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: Sin historial de uso`);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONFIGURACIÓN DE RECURSOS
    // ════════════════════════════════════════════════════════════════════════
    // Con 2 CPU cores y 3GB RAM, conectamos de a 2 simultáneamente
    // Delay reducido para aprovechar 10Gbps de red
    const PARALLEL_CONNECTIONS = 2;      // Conectar de a 2 (1 por core)
    const DELAY_BETWEEN_BATCHES = 2500;  // 2.5 segundos entre lotes (reducido de 6-12s)
    const DELAY_BETWEEN_BOTS = 800;      // 800ms entre bots del mismo lote

    // ── Procesar en lotes paralelos ──────────────────────────────────────────
    for (let i = 0; i < sortedNums.length; i += PARALLEL_CONNECTIONS) {
        const batch = sortedNums.slice(i, i + PARALLEL_CONNECTIONS);
        const batchNum = Math.floor(i / PARALLEL_CONNECTIONS) + 1;
        const totalBatches = Math.ceil(sortedNums.length / PARALLEL_CONNECTIONS);
        
        console.log(`[SubBot Monitor] 🔄 Lote ${batchNum}/${totalBatches}: Conectando subbots ${batch.join(', ')}`);
        
        // Conectar todos los bots del lote en paralelo
        const promises = batch.map((num, index) => {
            return (async () => {
                try {
                    // Pequeño delay escalonado dentro del lote para evitar picos
                    if (index > 0) {
                        await sleep(DELAY_BETWEEN_BOTS * index);
                    }
                    
                    const startTime = Date.now();
                    await connectSubBot({ num, chatJid: null, conn });
                    const duration = Date.now() - startTime;
                    
                    console.log(`[SubBot Monitor] ✅ SubBot #${num} conectado en ${duration}ms`);
                } catch (e) {
                    console.error(`[SubBot Monitor] ❌ Error conectando subbot #${num}:`, e.message);
                }
            })();
        });
        
        // Esperar a que todos los bots del lote se conecten
        await Promise.all(promises);
        
        // Delay entre lotes (excepto después del último)
        if (i + PARALLEL_CONNECTIONS < sortedNums.length) {
            console.log(`[SubBot Monitor] ⏳ Esperando ${DELAY_BETWEEN_BATCHES}ms antes del siguiente lote...`);
            await sleep(DELAY_BETWEEN_BATCHES);
        }
    }
    
    console.log(`[SubBot Monitor] ✅ Proceso de reconexión completado. ${sortedNums.length} subbots procesados.`);
    
    // No unir subbots al canal automáticamente en la reconexión al iniciar
}

async function connectSubBotWeb({ num, conn }) { return connectSubBot({ num, chatJid: null, conn, isNewLinking: true }); }
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) { return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber, isNewLinking: true }); }

// ════════════════════════════════════════════════════════════════════════════
//  EXPORTS — todos los handlers en un solo archivo
// ════════════════════════════════════════════════════════════════════════════
module.exports = {
    // Handler principal (.serbot / .qr / .code)
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,

    // Sub-handlers extras exportados como objetos separados
    // El loader de plugins los registra si los encontrás en module.exports
    reconnect:           reconnectHandler,
    listBots:            listBotsHandler,

    // Funciones internas usadas por otros módulos
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    connectSubBot,        // exportado para uso externo si hiciera falta
    activeSocks,
    getSubBotNumberByOwner,
};