'use strict';

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');
const { isBorradosEnabled } = require(path.join(__dirname, '..', 'HERRAMIENTAS', 'GRUPOS', 'borrados'));
const { shouldIgnoreFromMePrivateMessage } = require('../../messageUtils');
const { attachGroupCacheToSocket } = require('../../lib/groupCache');

// ── IMPORTAR MÓDULO DE BIENVENIDAS ──
const welcomeGoodbyeModule = require('../../plugins/HERRAMIENTAS/bienvenida-despedida');

// ── IMPORTAR SISTEMA DE TRACKING DE ACTIVIDAD ──
const activityTracker = require('./subbotActivityTracker');
const { cleanupSubBot } = require('./subbots-onoff');
const { cleanupSubbotActivity } = activityTracker;

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
// Limpiar archivos huérfanos de sesiones al arrancar
try { cleanOrphanSessionFiles(); } catch (e) { console.error('[SubBot] Error limpieza inicial sesiones:', e.message); }

if (!global.subConns) global.subConns = [];

const OFFICIAL_GROUP       = '120363203689229697@g.us';
const GOFC_SUBBOTS_FILE    = path.join(__dirname, 'data', 'gofc-subbots.json');

/**
 * Devuelve true si el subbot (por su _subNum) está en la lista blanca
 * de subbots permitidos para responder en el grupo oficial.
 */
const { isSubbotAllowedInOfficial } = require('./gofc');

// ── Deduplicación Atómica de Mensajes en Grupos Compartidos ──────────────────
const claimedGroupMessages = new Map();

/**
 * Intenta reclamar el procesamiento de un mensaje en un grupo.
 * Si 2 o más subbots están en el mismo grupo y reciben el mismo mensaje,
 * el primer subbot lo reclama en memoria atómicamente y los demás lo ignoran.
 * Si el subbot está solo en el grupo, siempre lo reclama al instante.
 * Funciona garantizadamente en 1 o 1000 grupos distintos sin interferencia.
 */
function claimGroupMessage(chatJid, messageId, subNum) {
    if (!chatJid || !messageId) return true;
    const key = `${chatJid}:${messageId}`;
    if (claimedGroupMessages.has(key)) {
        return false; // Ya fue reclamado por otro subbot
    }
    claimedGroupMessages.set(key, subNum);
    return true; // Este subbot fue el primero en reclamarlo
}

setInterval(() => {
    if (claimedGroupMessages.size > 3000) {
        claimedGroupMessages.clear();
    }
}, 30 * 1000);

let _respUsuariosSubbotCache = null, _respUsuariosSubbotTime = 0;
function getRespuestasUsuariosSubbotData() {
    const now = Date.now();
    if (_respUsuariosSubbotCache && (now - _respUsuariosSubbotTime < 5000)) {
        return _respUsuariosSubbotCache;
    }
    try {
        const respFile = path.join(__dirname, '..', '..', 'data', 'respuestas-usuarios.json');
        if (fs.existsSync(respFile)) {
            _respUsuariosSubbotCache = JSON.parse(fs.readFileSync(respFile, 'utf8'));
            _respUsuariosSubbotTime = now;
            return _respUsuariosSubbotCache;
        }
    } catch (e) {}
    _respUsuariosSubbotCache = {};
    _respUsuariosSubbotTime = now;
    return _respUsuariosSubbotCache;
}
const activeSocks = new Map();
// pendingQR guarda { expiresAt: timestamp } para poder mostrar countdown y auto-expirar entradas
const pendingQR = new Map();
const reconnectTimers = new Map();
const reconnectAttempts = new Map();

/** Limpia entradas expiradas del mapa de pending */
function cleanExpiredPending() {
    const now = Date.now();
    for (const [key, val] of pendingQR.entries()) {
        if (val.expiresAt <= now) pendingQR.delete(key);
    }
}

/** Registra un pending con su tiempo de expiración en ms desde ahora */
function pendingQRAdd(key, ttlMs) {
    pendingQR.set(key, { expiresAt: Date.now() + ttlMs });
}

/** Retorna true si el pending existe Y todavía no expiró (limpiando si ya expiró) */
function pendingQRHas(key) {
    const entry = pendingQR.get(key);
    if (!entry) return false;
    if (entry.expiresAt <= Date.now()) { pendingQR.delete(key); return false; }
    return true;
}

/** Segundos restantes para que expire el pending (0 si no existe o ya expiró) */
function pendingQRSecondsLeft(key) {
    const entry = pendingQR.get(key);
    if (!entry) return 0;
    const left = Math.ceil((entry.expiresAt - Date.now()) / 1000);
    return left > 0 ? left : 0;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Destruye y libera por completo un socket de SubBot de la memoria RAM.
 * Cancela temporizadores, listeners de Baileys, conexiones WebSocket y mapas globales.
 * NOTA DE SEGURIDAD: NO borra la sesión (.db) en disco. El subbot volverá a conectar automáticamente.
 */
function destroySubBotSocket(sock) {
    if (!sock) return;
    try {
        if (sock._cacheCleanupInterval) {
            clearInterval(sock._cacheCleanupInterval);
            sock._cacheCleanupInterval = null;
        }
        if (typeof sock._closeDb === 'function') {
            try { sock._closeDb(); } catch {}
            sock._closeDb = null;
        }
        if (sock.ev) {
            try { sock.ev.removeAllListeners(); } catch {}
        }
        if (sock.ws) {
            try { sock.ws.close(); } catch {}
            try { sock.ws.terminate(); } catch {}
        }
        if (typeof sock.end === 'function') {
            try { sock.end(undefined); } catch {}
        }
    } catch (e) {
        console.error('[SubBot] Error liberando socket de RAM:', e.message);
    }

    const name = sock._subName;
    if (name) {
        if (activeSocks.get(name) === sock) {
            activeSocks.delete(name);
        }
        if (global.subConns) {
            const idx = global.subConns.indexOf(sock);
            if (idx >= 0) global.subConns.splice(idx, 1);
        }
    }
}

// ── SISTEMA DE COLA Y PROTECCIÓN DE RED DE SUBBOTS ─────────────────────────
const reconnectQueue = [];
const activeReconnections = new Set();
const MAX_CONCURRENT_RECONNECTS = 2; // Máximo 2 reconexiones simultáneas
let lastDisconnectionTime = 0;
let disconnectionCountInWindow = 0;
let isNetworkPaused = false;
let networkPauseTimer = null;

function registerDisconnection(num, ownerJid, conn) {
    const now = Date.now();
    if (now - lastDisconnectionTime < 10000) {
        disconnectionCountInWindow++;
    } else {
        disconnectionCountInWindow = 1;
        lastDisconnectionTime = now;
    }

    // Si caen 4 o más subbots en menos de 10s, activar Pausa por Caída Masiva de Red
    if (disconnectionCountInWindow >= 4 && !isNetworkPaused) {
        isNetworkPaused = true;
        console.warn(`[SubBot Queue] ⚠️ CAÍDA MASIVA DE RED DETECTADA (${disconnectionCountInWindow} subbots cayeron). Pausando reconexiones 15s para estabilizar red...`);
        if (networkPauseTimer) clearTimeout(networkPauseTimer);
        networkPauseTimer = setTimeout(() => {
            isNetworkPaused = false;
            console.log(`[SubBot Queue] 🟢 Red estabilizada. Reanudando cola de reconexiones (${reconnectQueue.length} pendientes)...`);
            processReconnectQueue();
        }, 15000);
    }

    enqueueSubBotReconnect(num, ownerJid, conn);
}

function enqueueSubBotReconnect(num, ownerJid, conn) {
    const name = String(num);
    const attempts = (reconnectAttempts.get(name) || 0) + 1;
    reconnectAttempts.set(name, attempts);

    // Circuit Breaker: si ha fallado más de 8 veces seguidas, pausar reintentos agresivos (enfriamiento 5 min)
    if (attempts > 8) {
        console.warn(`[SubBot] 🛑 Bot #${num} superó 8 intentos fallidos. Entrando en enfriamiento (5 min)...`);
        if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));
        const tid = setTimeout(() => {
            reconnectTimers.delete(name);
            reconnectAttempts.set(name, 1);
            enqueueSubBotReconnect(num, ownerJid, conn);
        }, 5 * 60 * 1000);
        reconnectTimers.set(name, tid);
        return;
    }

    // Backoff exponencial + Jitter aleatorio
    const baseBackoff = Math.min(45000, Math.floor(4000 * Math.pow(1.3, attempts - 1)));
    const randomJitter = Math.floor(Math.random() * 6000); // 0 a 6000 ms aleatorio
    const delay = baseBackoff + randomJitter;

    console.log(`[SubBot] ⏳ Bot #${num} programado para reconectar en ${(delay / 1000).toFixed(1)}s (intento ${attempts})...`);

    if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));

    const tid = setTimeout(() => {
        reconnectTimers.delete(name);
        if (!reconnectQueue.some(item => item.num === num)) {
            reconnectQueue.push({ num, ownerJid, conn });
        }
        processReconnectQueue();
    }, delay);

    reconnectTimers.set(name, tid);
}

async function processReconnectQueue() {
    if (isNetworkPaused) return;
    if (reconnectQueue.length === 0) return;
    if (activeReconnections.size >= MAX_CONCURRENT_RECONNECTS) return;

    const item = reconnectQueue.shift();
    if (!item) return;

    const { num, ownerJid, conn } = item;
    const name = String(num);

    activeReconnections.add(name);
    console.log(`[SubBot Queue] 🔄 Procesando reconexión de Bot #${num} (${activeReconnections.size}/${MAX_CONCURRENT_RECONNECTS} simultáneas, ${reconnectQueue.length} en cola)...`);

    try {
        await connectSubBot({ num, chatJid: ownerJid, conn });
    } catch (e) {
        console.error(`[SubBot Queue] Error reconectando #${num}:`, e.message);
    } finally {
        activeReconnections.delete(name);
        setTimeout(() => processReconnectQueue(), 1200);
    }
}

// ── RAM Watchdog (Modo Pasivo) ─────────────────────────────────────────────
setInterval(() => {
    try {
        const mem = process.memoryUsage();
        const heapMb = Math.round(mem.heapUsed / 1024 / 1024);
        const rssMb = Math.round(mem.rss / 1024 / 1024);

        if (rssMb > 1300 || heapMb > 900) {
            console.warn(`[RAM Watchdog] ⚠️ Memoria elevada (RSS: ${rssMb}MB, Heap: ${heapMb}MB). Ejecutando recolección de basura...`);
            if (global.gc) { try { global.gc(); } catch {} }
        }
    } catch {}
}, 60 * 1000);

// (isMainBotInGroup eliminado: el bot principal no tiene sesión activa,
//  la lógica de groupFetchAllParticipating generaba picos de red innecesarios)

function hasFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return false;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = 2000');
        db.pragma('busy_timeout = 2000');
        const row = db.prepare("SELECT value FROM auth WHERE key = 'hasFollowedChannel'").get();
        db.close();
        return !!row;
    } catch (e) {
        return false;
    }
}

function setFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile);
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('busy_timeout = 5000');
        db.prepare("INSERT OR REPLACE INTO auth (key, value) VALUES ('hasFollowedChannel', 'true')").run();
        db.close();
    } catch (e) {
        console.error('[SubBot Db] Error guardando estado de canal seguido:', e.message);
    }
}

async function followPublicChannel(sock, botLabel = 'Bot') {
    // Delay eliminado: no afecta la respuesta de comandos
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        
        if (inviteCode) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            
            // Obtiene los metadatos reales usando el código del enlace
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            
            if (metadata && metadata.id) {
                const channelJid = metadata.id;

                // El bot sigue al canal de WhatsApp
                await sock.newsletterFollow(channelJid);
                console.log(`[Canal ${botLabel}] Unido exitosamente`);
            }
        }
    } catch (error) {
        // Filtra el falso error de Baileys v7 si la suscripción ya está activa
        if (error.message?.includes('unexpected response structure')) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            console.log(`[Canal ${botLabel}] Ya siguiendo al canal, intentando confirmar...`);
            console.log(`[Canal ${botLabel}] Ya sigue al canal. CONFIRMADO`);
        } else {
            // Muestra en rojo si es un error real diferente
            console.error(`[Canal ${botLabel}] ❌ Error real al seguir el canal:`, error.message);
            return false;
        }
    }
    return true;
}

// FIX 405 (2026-07, actualizado): WhatsApp rota la versión de protocolo aceptada
// con mucha frecuencia. Misma estrategia que en index.js — ver comentario extenso
// ahí. Resumen: env var WA_BAILEYS_VERSION > valor por defecto de abajo > fallback
// a fetchLatestBaileysVersion() si el fijo es rechazado con 405.
// Hilos activos: https://github.com/WhiskeySockets/Baileys/issues/2370
//                https://github.com/WhiskeySockets/Baileys/issues/2485
const DEFAULT_BAILEYS_VERSION = [2, 3000, 1043857760];

let _baileysVersion = null;
let _subbotUsedFallback = false;

function parseEnvVersionSubbot() {
    const raw = process.env.WA_BAILEYS_VERSION;
    if (!raw) return null;
    const parts = raw.split(',').map(n => parseInt(n.trim(), 10));
    if (parts.length !== 3 || parts.some(n => Number.isNaN(n))) return null;
    return parts;
}

async function getBaileysVersion() {
    if (_baileysVersion) return _baileysVersion;
    const envVersion = parseEnvVersionSubbot();
    _baileysVersion = envVersion || DEFAULT_BAILEYS_VERSION;
    return _baileysVersion;
}

// Invalida la versión cacheada tras un 405 para que el próximo intento use
// fetchLatestBaileysVersion() en vez de repetir la misma versión rota.
async function invalidateBaileysVersionOnAuthFailure() {
    if (_subbotUsedFallback) return;
    _subbotUsedFallback = true;
    try {
        const { version } = await fetchLatestBaileysVersion();
        console.log(`[SubBot][Baileys] Versión fija rechazada (405). Probando fetchLatestBaileysVersion(): ${version.join('.')}`);
        _baileysVersion = version;
    } catch (e) {
        console.error('[SubBot][Baileys] fetchLatestBaileysVersion() también falló:', e.message);
    }
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function sessionFiles(num) {
    const base = path.join(SESSIONS_DIR, String(num));
    return [
        `${base}.db`,
        `${base}.db-wal`,
        `${base}.db-shm`
    ];
}

function removeSessionFiles(num) {
    const files = sessionFiles(num);
    let deletedAny = false;
    for (const f of files) {
        try {
            if (fs.existsSync(f)) {
                fs.unlinkSync(f);
                deletedAny = true;
                console.log(`[SubBot] 🗑️ Eliminado archivo de sesión: ${path.basename(f)}`);
            }
        } catch (e) {
            console.error(`[SubBot] Error eliminando ${f}:`, e.message);
        }
    }

    if (deletedAny) {
        try {
            cleanupSubBot(num);
        } catch (e) {
            console.error(`[SubBot] Error limpiando configuración de #${num}:`, e.message);
        }

        try {
            cleanupSubbotActivity(num);
        } catch (e) {
            console.error(`[SubBot] Error limpiando actividad de #${num}:`, e.message);
        }
    }
}

function cleanOrphanSessionFiles() {
    try {
        if (!fs.existsSync(SESSIONS_DIR)) return;
        const files = fs.readdirSync(SESSIONS_DIR);
        const grouped = {};
        for (const f of files) {
            const m = f.match(/^(\d+)(?:\.db|\.db-wal|\.db-shm)$/);
            if (!m) continue;
            const n = parseInt(m[1]);
            if (!grouped[n]) grouped[n] = new Set();
            grouped[n].add(f);
        }

        for (const nStr of Object.keys(grouped)) {
            const n = parseInt(nStr);
            const names = Array.from(grouped[n]);
            // Si no existe el .db pero hay wal/shm, limpiar todos los archivos asociados
            const hasDb = names.some(x => x.endsWith('.db'));
            if (!hasDb) {
                console.log(`[SubBot Garbage Collector] 🗑️ Archivo .db faltante para #${n}, limpiando restos: ${names.join(', ')}`);
                removeSessionFiles(n);
            }
        }
    } catch (e) {
        console.error('[SubBot Garbage Collector] Error escaneando sesiones:', e.message);
    }
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do { n = Math.floor(1000 + Math.random() * 9000); } while (existing.includes(n));
    return n;
}

function isValidSessionDb(dbFile) {
    if (!fs.existsSync(dbFile)) return false;
    try {
        const stats = fs.statSync(dbFile);
        if (stats.size < 100) return false;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = 2000');
        db.pragma('busy_timeout = 2000');
        const hasAuthTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='auth'").get();
        if (!hasAuthTable) {
            db.close();
            return false;
        }
        const rowCreds = db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
        db.close();
        return !!(rowCreds && rowCreds.value);
    } catch {
        return false;
    }
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            if (!isValidSessionDb(dbPath)) continue;
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 3000');
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ─── Helper: manejar mensajes borrados (texto, imagen, video, sticker, audio) ─
async function _handleBorradoMessage(sock, remoteJid, original) {
    try {
        const msg = original.message || {};
        const senderJid = original.key.participant || original.key.remoteJid || '';
        const userNum = senderJid.split('@')[0].split(':')[0];
        const mentionJid = original.key.participant || original.key.remoteJid;

        // ── Texto / Texto extendido ──────────────────────────────────────
        const textContent = msg.conversation || msg.extendedTextMessage?.text || '';
        if (textContent.trim().length > 0) {
            const hasLink = /(https?:\/\/|www\.)/i.test(textContent);
            if (!hasLink) {
                await sock.sendMessage(remoteJid, {
                    text: `📌 El usuario @${userNum} eliminó este mensaje:\n\n${textContent}`,
                    mentions: [mentionJid]
                });
            }
            return;
        }

        // ── Imagen ───────────────────────────────────────────────────────
        if (msg.imageMessage) {
            const caption = msg.imageMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una imagen${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Video ─────────────────────────────────────────────────────────
        if (msg.videoMessage) {
            const caption = msg.videoMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un video${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Sticker ───────────────────────────────────────────────────────
        if (msg.stickerMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un sticker:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el sticker eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Audio / Nota de voz ───────────────────────────────────────────
        if (msg.audioMessage) {
            const isPtt = msg.audioMessage.ptt === true;
            const tipo = isPtt ? 'nota de voz' : 'audio';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ${tipo}:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el ${tipo} eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Documento ─────────────────────────────────────────────────────
        if (msg.documentMessage) {
            const fileName = msg.documentMessage.fileName || 'archivo';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un documento: *${fileName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── GIF ───────────────────────────────────────────────────────────
        if (msg.gifMessage || (msg.videoMessage && msg.videoMessage.gifPlayback)) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un GIF.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Contacto ──────────────────────────────────────────────────────
        if (msg.contactMessage) {
            const contactName = msg.contactMessage.displayName || 'contacto';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un contacto: *${contactName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Ubicación ─────────────────────────────────────────────────────
        if (msg.locationMessage || msg.liveLocationMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ubicación.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

    } catch (err) {
        console.error('[borrados] Error al manejar mensaje borrado:', err.message);
    }
}
// ─────────────────────────────────────────────────────────────────────────────

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null, isNewLinking = false, replyQuote = null, pendingKey = null }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;
    const pendingLockKey = pendingKey || ownerJid || null;

    if (fs.existsSync(dbFile)) {
        try {
            if (isValidSessionDb(dbFile)) {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile, { readonly: true });
                _db.pragma('cache_size = 5000');
                _db.pragma('busy_timeout = 3000');
                const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                _db.close();
                if (row) {
                    const data = JSON.parse(row.value);
                    if (!ownerJid) ownerJid = data.ownerJid;
                    if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                }
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        destroySubBotSocket(prevSock);
    }

    const { state, saveCreds, close: closeDb } = await useSQLiteAuthState(dbFile);
    const version                              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        // Anti-suspensión: Browsers.windows('Chrome') es obligatorio para que el pairing code
        // no falle con "No se pudo vincular el dispositivo" (error 408).
        browser: Browsers.windows('Chrome'),
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 3000,
        maxMsgRetryCount: 3,
        // Anti-suspensión: 25s de keepAlive estándar (previene desconexión 408 de WhatsApp)
        keepAliveIntervalMs: 25000
    });

    // Exponer la función de guardado para reinicios limpios
    try { sock._saveCreds = saveCreds; } catch (e) {}
    sock._closeDb        = closeDb;

    sock._subName        = name;
    sock._subNum         = num;
    sock._sessDb         = dbFile;
    sock._ownerJid       = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime          = Date.now();
    activeSocks.set(name, sock);

    // ── Anti-suspensión: Rate Limit 429 wrapper ───────────────────────────────
    // El Bot Principal ya tenía este control; ahora los Subbots también lo tienen.
    // Si WhatsApp devuelve error 429 (demasiados mensajes en poco tiempo), el Subbot
    // pausa automáticamente en lugar de seguir intentando y arriesgarse a un baneo.
    const _originalSendMessage = sock.sendMessage.bind(sock);
    let _rateLimitCount = 0;

    sock.sendMessage = async (jid, content, options = {}) => {
        try {
            const result = await _originalSendMessage(jid, content, options);
            _rateLimitCount = 0;
            return result;
        } catch (error) {
            const errorCode = error?.data || error?.output?.statusCode;
            const errorMsg = error?.message || '';

            if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                _rateLimitCount++;
                const waitMs = _rateLimitCount > 5 ? 5000 : 1500;
                if (_rateLimitCount === 1 || _rateLimitCount % 5 === 0) {
                    console.log(`[SubBot #${num}] ⏱️ Rate limit alcanzado (${_rateLimitCount}x) — pausando ${waitMs}ms...`);
                }
                await new Promise(r => setTimeout(r, waitMs));
                return Promise.reject(new Error('Rate limit exceeded'));
            }

            return Promise.reject(error);
        }
    };
    // ─────────────────────────────────────────────────────────────────────────

    // ── Caché de groupMetadata centralizada: parchea sock.groupMetadata para que
    // todos los plugins usen automáticamente la caché sin modificaciones individuales.
    attachGroupCacheToSocket(sock);

    if (welcomeGoodbyeModule?.init) {
        try {
            welcomeGoodbyeModule.init(sock);
            console.log(`[SubBot #${num}] ✓ Módulo Bienvenida/Despedida conectado.`);
        } catch (error) {
            console.error(`[SubBot #${num}] ❌ Error iniciando Bienvenida/Despedida:`, error.message);
        }
    }

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false;
    let codeSent             = false;
    let pairingCodeRequested = false;

    const sendToOwner = async (content, options = {}) => {
        if (!ownerJid) return;
        const sender = (connected ? sock : (conn || global.conn));
        if (!sender) return; // bot principal aún no conectado, no se puede notificar
        const sendOptions = { ...(options || {}) };
        if (!sendOptions.quoted && replyQuote) {
            sendOptions.quoted = replyQuote;
        }
        try {
            await sender.sendMessage(ownerJid, content, sendOptions);
        } catch (e) {
            try {
                const fallback = sender === sock ? (conn || global.conn) : sock;
                if (fallback) await fallback.sendMessage(ownerJid, content, sendOptions);
            } catch {}
        }
    };

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (
            usePairingCode &&
            phoneNumber &&
            !pairingCodeRequested &&
            !connected &&
            !state.creds.registered &&
            (connection === 'connecting' || !!qr)
        ) {
            pairingCodeRequested = true;
            await sleep(connection === 'connecting' ? 3000 : 500);
            if (connected) return;

            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                let code = null;
                let lastErr = null;
                for (let attempt = 1; attempt <= 3; attempt++) {
                    try {
                        code = await sock.requestPairingCode(cleanPhone);
                        if (code) break;
                    } catch (errAttempt) {
                        lastErr = errAttempt;
                        console.warn(`[SubBot #${num}] Intento ${attempt}/3 de solicitar código falló: ${errAttempt.message}`);
                        if (attempt < 3) await sleep(2000);
                    }
                }
                if (!code) throw (lastErr || new Error('No se pudo obtener código de emparejamiento'));

                codeSent = true;

                // Enviar el mensaje con el número + video tutorial adjunto
                const tutorialPath = path.join(__dirname, 'tutorial-code.mp4');
                let sentWithVideo = false;
                if (fs.existsSync(tutorialPath)) {
                    try {
                        const videoBuffer = fs.readFileSync(tutorialPath);
                        await sendToOwner({
                            video: videoBuffer,
                            caption: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                        });
                        sentWithVideo = true;
                    } catch (videoErr) {
                        console.warn(`[SubBot #${num}] No se pudo enviar video tutorial: ${videoErr.message}`);
                    }
                }
                if (!sentWithVideo) {
                    await sendToOwner({
                        text: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                    });
                }
                await sendToOwner({ text: code });

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                qrTimeout = setTimeout(() => {
                    if (connected) return;
                    pendingQR.delete(pendingLockKey);
                    try { activeSocks.delete(name); } catch {}
                    try { if (sock?.ev) sock.ev.removeAllListeners(); } catch {}
                    try { if (sock?.ws) sock.ws.close(); } catch {}
                    sendToOwner({ text: `⏰ Código expirado. Si ya pudiste vincular el sub-bot, no hace falta volver a pedir uno nuevo. Si todavía no lo hiciste, generá otro con \`.code\`.` });
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (pendingLockKey) pendingQR.delete(pendingLockKey);
                else if (ownerJid)  pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `❌ Error generando código: ${e.message}` });
                try { require('../../subbotServer').resolveWebCode(num, null); } catch {}
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }
            return;
        }

        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                pendingQR.delete(pendingLockKey);
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwner({
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                });
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    pendingQR.delete(pendingLockKey);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ QR expirado. Usa \`.qr\` de nuevo.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 35000);
            } catch (e) {
                console.error(`[SubBot #${num}] Error procesando QR:`, e);
                try { require('../../subbotServer').resolveWebQR(num, null); } catch {}
            }
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            pendingQR.delete(pendingLockKey);
            reconnectAttempts.delete(name);

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.pragma('journal_mode = WAL');
                _db.pragma('synchronous = NORMAL');
                _db.pragma('cache_size = 10000');
                _db.pragma('busy_timeout = 5000');
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch {}

            if (sock.user?.lid) {
                sock._lid = sock.user.lid;
                const cleanL = String(sock.user.lid).split('@')[0].split(':')[0].replace(/\D/g, '');
                if (cleanL) {
                    if (!global.subbotLidMap) global.subbotLidMap = new Map();
                    global.subbotLidMap.set(cleanL, sock);
                }
                if (sock.user?.id && global.db?.linkUserAlias) {
                    global.db.linkUserAlias(sock.user.id, sock.user.lid);
                }
            }
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);

            if (ownerJid) {
                const phoneNum = sock.user?.id?.split('@')[0]?.split(':')[0] || '?';
                await sendToOwner({ text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` });
            }

            // ── Unirse al canal 60 segundos después de vincularse ──
            const dbFile = sessionPath(num);
            if (isNewLinking) {
                if (!hasFollowedChannelDb(dbFile)) {
                    const delay = 60000; // 60 segundos
                    console.log(`[Canal SubBot #${num}] Nuevo sub-bot vinculado. Programado unirse al canal en 60 segundos...`);
                    setTimeout(async () => {
                        try {
                            const success = await followPublicChannel(sock, `SubBot #${num}`);
                            if (success) {
                                setFollowedChannelDb(dbFile);
                            }
                        } catch (e) {
                            console.error(`[Canal SubBot #${num}] Error en followPublicChannel:`, e.message);
                        }
                    }, delay);
                } else {
                    console.log(`[Canal SubBot #${num}] El sub-bot ya sigue al canal en esta sesión (omitido)`);
                }
            } else {
                console.log(`[Canal SubBot #${num}] Conexión/Reconexión establecida. No se une al canal (omitido)`);
            }
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            const errMsg = String(lastDisconnect?.error?.message || '');
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}, msg: ${errMsg}`);

            // Destruir limpiamente el socket anterior de la memoria RAM
            destroySubBotSocket(sock);

            // Si estábamos en proceso de vinculación (nunca llegamos a 'open') y
            // el timeout ya limpió el pending (pendingLockKey ya no está en el Set),
            // significa que el timeout ya manejó el cierre — no reconectar ni avisar.
            if (!connected && isNewLinking && pendingLockKey && !pendingQRHas(pendingLockKey)) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                return;
            }

            const isLoggedOut = code === DisconnectReason.loggedOut;

            // 515 = reinicio de stream / reconexión requerida por Baileys
            // NO borrar la sesión en disco; reconectar el socket.
            if (code === 515) {
                console.log(`[SubBot] ⚠️ Bot #${num} reconectando tras reinicio de stream (515)...`);
                const tid515 = setTimeout(() => {
                    reconnectTimers.delete(name);
                    connectSubBot({ num, chatJid: ownerJid, conn });
                }, 3000);
                reconnectTimers.set(name, tid515);
                return;
            }

            // 401 = sesión explícitamente cerrada o no autorizada
            if (code === 401) {
                if (isLoggedOut) {
                    console.log(`[SubBot] ❌ Bot #${num} recibió error 401/loggedOut (sesión cerrada). Borrando sesión.`);
                    try { removeSessionFiles(num); } catch {}
                    if (pendingLockKey) pendingQR.delete(pendingLockKey);
                    if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                    if (connected) {
                        sendToOwner({
                            text: `❌ *Sub-bot #${num} sesión inválida (401)*\n\nLa sesión fue revocada o cerrada desde otro dispositivo.\n\n💡 Usá \`.code\` o \`.qr\` para crear una nueva.`
                        });
                    }
                    return;
                } else {
                    console.log(`[SubBot] ⚠️ Bot #${num} recibió 401 temporal. Encolando reintento de reconexión...`);
                    registerDisconnection(num, ownerJid, conn);
                    return;
                }
            }

            if (isLoggedOut || code === 440) {
                if (isLoggedOut) {
                    try { removeSessionFiles(num); } catch {}
                }
                if (code === 440) {
                    console.log(`[SubBot] ⚠️ Bot #${num} reemplazado (440). NO reconectará para evitar bucle.`);
                    return;
                }
                sendToOwner({ text: `⚠️ Sesión del sub-bot #${num} cerrada o inválida. Usá \`.qr\` o \`.code\` para reconectar.` });
                return;
            }

            // Error 403 (Forbidden) - la sesión está baneada o inválida y no puede repararse
            if (code === 403) {
                console.log(`[SubBot] ❌ Sub-bot #${num} recibió error 403 (Forbidden). La sesión está inválida/baneada.`);
                console.log(`[SubBot] 🗑️ Eliminando sesión corrupta del sub-bot #${num}...`);
                try { removeSessionFiles(num); } catch (e) {
                    console.error(`[SubBot] Error eliminando sesión #${num}:`, e.message);
                }
                sendToOwner({ text: `❌ Sub-bot #${num} error 403 (Forbidden).\n\n⚠️ Sesión eliminada por inválida o baneada.\n\n💡 Usá \`.qr\` o \`.code\` para crear una nueva.` });
                return;
            }

            // Otros errores de autenticación (405)
            if (code === 405) {
                console.log(`[SubBot] ⚠️ Sub-bot #${num} recibió un error de auth (${code}). Intentando reconectar sin borrar la sesión.`);
                sendToOwner({ text: `⚠️ Sub-bot #${num} tuvo un error de auth (${code}). Se reintentará reconexión automática.` });
                try { invalidateBaileysVersionOnAuthFailure(); } catch (_) {}
            }

            // ── Encolar reconexión con control de cola, concurrencia y detección de caída masiva ──
            registerDisconnection(num, ownerJid, conn);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // ── Anunciar cambios de admin en grupos (promote/demote externos) ────────
    sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
        if (action !== 'promote' && action !== 'demote') return;
        try {
            for (const participantJid of participants) {
                const targetNum = participantJid.split('@')[0].split(':')[0];
                const msg = action === 'promote'
                    ? `👑 *@${targetNum} ahora es administrador del grupo*`
                    : `👤 *@${targetNum} ya no es administrador del grupo*`;
                await sock.sendMessage(id, { text: msg, mentions: [participantJid] });
            }
        } catch {}
    });

        const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
        const processedIds = new Set();
        const recentGroupMessages = new Map();
        const RECENT_MESSAGE_TTL = 2 * 60 * 1000; // 2 minutos

        const cleanupTimer = setInterval(() => {
            const now = Date.now();
            for (const [groupId, groupMap] of recentGroupMessages.entries()) {
                for (const [msgId, msg] of groupMap.entries()) {
                    const ts = (msg.messageTimestamp || 0) * 1000;
                    if (!ts || now - ts > RECENT_MESSAGE_TTL) {
                        groupMap.delete(msgId);
                    }
                }
                if (groupMap.size === 0) recentGroupMessages.delete(groupId);
            }
        }, 30000);
        sock._cacheCleanupInterval = cleanupTimer;

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;

                const messageId = baileyMessage.key.id;
                const remoteJid = baileyMessage.key.remoteJid;

                if (processedIds.has(messageId)) continue;
                processedIds.add(messageId);

                if (processedIds.size > 500) {
                    const arr = Array.from(processedIds).slice(-200);
                    processedIds.clear();
                    arr.forEach(id => processedIds.add(id));
                }

                // Procesar cada mensaje de forma concurrente no bloqueante
                (async () => {
                    const isOfficialGroup = remoteJid === OFFICIAL_GROUP;
                    const isGroupMsg = typeof remoteJid === 'string' && remoteJid.endsWith('@g.us');

                    // 1. Regla ultrarrápida para Grupo Oficial:
                    // Si el subbot NO está en la lista blanca del grupo oficial, descartar de inmediato (<0.001ms)
                    // a menos que sea un comando de gestión (.gofc / .gofcbots).
                    let isGofcCmd = false;
                    if (isOfficialGroup && !isSubbotAllowedInOfficial(num)) {
                        const rawMsgText = getMessageText(baileyMessage);
                        const trimmedText = typeof rawMsgText === 'string' ? rawMsgText.trim() : '';
                        isGofcCmd = /^[./❤️#👅😎]?(gofc|gofcbots)\b/i.test(trimmedText);
                        if (!isGofcCmd) return;
                    }

                    // 2. Regla de Subbot Único por Mensaje de Grupo:
                    // Si 2 o más subbots están en el mismo grupo y reciben el mismo mensaje, solo el primero lo reclama.
                    if (isGroupMsg && !isGofcCmd && !baileyMessage.key.fromMe) {
                        if (!claimGroupMessage(remoteJid, messageId, num)) {
                            return; // Ignorar silenciosamente: otro subbot ya lo reclamó
                        }
                    }

                    // ── Verificar y eliminar mensajes de usuarios muteados ────────────
                    if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        if (baileyMessage.message.protocolMessage?.type === 0 && baileyMessage.message.protocolMessage?.key) {
                            const deletedKey = baileyMessage.message.protocolMessage.key;
                            const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid);
                            const original = groupMap?.get(deletedKey.id);

                            if (original && isBorradosEnabled(baileyMessage.key.remoteJid)) {
                                await _handleBorradoMessage(sock, baileyMessage.key.remoteJid, original);
                            }
                            return;
                        }

                        const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid) || new Map();
                        groupMap.set(messageId, baileyMessage);
                        recentGroupMessages.set(baileyMessage.key.remoteJid, groupMap);
                    }

                    if (global.muteSystem && baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const wasDeleted = await global.muteSystem.checkAndDeleteMutedMessage(baileyMessage, sock);
                            if (wasDeleted) return;
                        } catch (e) { /* silencioso */ }
                    }

                    // ── Verificación de estado on/off del subbot (CRÍTICO: debe ir ANTES de procesar comandos) ──
                    // Esta verificación temprana evita que el subbot procese mensajes cuando está apagado.
                    // Se requiere aquí porque el handler.js verifica DESPUÉS de que el mensaje llegó,
                    // pero necesitamos bloquearlo ANTES en el subbot para evitar procesamiento innecesario.
                    let subbotOnOffModule = null;
                    let botsAdminsModule = null;
                    try {
                        // IMPORTANTE: NO cachear estos módulos, siempre recargarlos desde el cache de require
                        // (Node.js cachea los módulos, pero las funciones dentro leen el JSON fresco cada vez)
                        subbotOnOffModule = require('./subbots-onoff');
                        botsAdminsModule = require('./subbots-admins');
                    } catch (e) { /* silencioso */ }

                    // ── Respuestas automáticas con caché de TTL ──
                    if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const isGroupEnabled = typeof botsAdminsModule?.isBotEnabled === 'function' ? botsAdminsModule.isBotEnabled(remoteJid) !== false : true;
                            const isSubEnabled = typeof subbotOnOffModule?.isSubBotEnabled === 'function' ? subbotOnOffModule.isSubBotEnabled(remoteJid, num) : true;

                            if (isGroupEnabled && isSubEnabled) {
                                const respData = getRespuestasUsuariosSubbotData();
                                const senderNum = (baileyMessage.key.participant || remoteJid).split('@')[0].split(':')[0];
                                const isMuted = global.muteSystem?.isUserMuted(remoteJid, senderNum);
                                if (!isMuted && respData[remoteJid]?.[senderNum]?.length) {
                                    const lista = respData[remoteJid][senderNum];
                                    const texto = lista[Math.floor(Math.random() * lista.length)];
                                    await sock.sendMessage(remoteJid, { text: texto }, { quoted: baileyMessage });
                                }
                            }
                        } catch (e) { /* silencioso */ }
                    }

                    const msgText    = getMessageText(baileyMessage);
                    const hasPrefix  = ['.', '/', '❤️', '#', '👅', '😎'].some(p => msgText.startsWith(p));
                    const msgChatJid = baileyMessage.key.remoteJid;

                    // ── VERIFICACIÓN CRÍTICA: Estado on/off del subbot ANTES de procesar comandos ──
                    // Esta verificación intercepta los mensajes con comando ANTES de enviarlos al handler.
                    // Si el subbot está apagado (.bot off) o el grupo está apagado (.bots off),
                    // bloquea todos los comandos EXCEPTO .bot, .bots, .onmybot, .offmybot (que deben pasar siempre).
                    if (hasPrefix && subbotOnOffModule && botsAdminsModule) {
                        try {
                            const isGroupMsg = msgChatJid?.endsWith('@g.us');
                            const isPrivMsg = msgChatJid?.endsWith('@s.whatsapp.net');

                            // Verificar respuestas en privados/grupos
                            if (isPrivMsg && typeof subbotOnOffModule.isSubBotRespondsInPriv === 'function') {
                                if (!subbotOnOffModule.isSubBotRespondsInPriv(num)) {
                                    // Extraer comando
                                    const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                    const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                    const [commandName] = commandText.split(/\s+/);
                                    // Permitir solo comandos de gestión
                                    if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                        return; // Bloquear silenciosamente
                                    }
                                }
                            }

                            if (isGroupMsg && typeof subbotOnOffModule.isSubBotRespondsInGrupos === 'function') {
                                if (!subbotOnOffModule.isSubBotRespondsInGrupos(num)) {
                                    const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                    const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                    const [commandName] = commandText.split(/\s+/);
                                    if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                        return; // Bloquear silenciosamente
                                    }
                                }
                            }

                            // ═══════════════════════════════════════════════════════════════════
                            // JERARQUÍA DE PRIORIDAD (de mayor a menor):
                            // 1. .bots off → BLOQUEA TODOS LOS SUBBOTS (sin excepciones)
                            // 2. .bots admins → Solo admins pueden usar comandos
                            // 3. .bot off → Bloquea este subbot específico
                            // 4. .bot on (explícito) → Excepción para bypass global off
                            // ═══════════════════════════════════════════════════════════════════

                            // Verificar estado del grupo PRIMERO (máxima prioridad)
                            const groupBotStatus = isGroupMsg && typeof botsAdminsModule.isBotEnabled === 'function'
                                ? botsAdminsModule.isBotEnabled(msgChatJid)
                                : true;

                            // PRIORIDAD 1: Si .bots off está activo, BLOQUEAR INMEDIATAMENTE (sin excepciones)
                            if (isGroupMsg && groupBotStatus === false) {
                                const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                const [commandName] = commandText.split(/\s+/);

                                // Solo permitir comandos de gestión (.bot, .bots, etc)
                                if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                    return; // 🚫 BLOQUEADO por .bots off (prioridad máxima)
                                }
                            }

                            // PRIORIDAD 2: Modo solo admins (.bots admins)
                            if (isGroupMsg && groupBotStatus === 'admins') {
                                try {
                                    const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                                    const senderNum = senderJid.split('@')[0].split(':')[0];

                                    // Cargar metadata del grupo para verificar si es admin
                                    const { getGroupMetadataCached } = require('../../lib/groupCache');
                                    const groupMetadata = await getGroupMetadataCached(sock, msgChatJid);
                                    const participants = groupMetadata?.participants || [];
                                    
                                    const senderParticipant = participants.find(p => 
                                        p.id.split('@')[0].split(':')[0] === senderNum
                                    );
                                    const isAdmin = senderParticipant && 
                                        (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

                                    if (!isAdmin) {
                                        // No es admin: solo permitir comandos de gestión
                                        const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                        const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                        const [commandName] = commandText.split(/\s+/);
                                        if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                            return; // 🚫 BLOQUEADO por .bots admins (no eres admin)
                                        }
                                    }
                                } catch (e) { /* silencioso */ }
                            }

                            // PRIORIDAD 3 y 4: Verificar estado individual del subbot (.bot on/off)
                            // Solo aplica si .bots off no está activo (ya fue verificado arriba)
                            const isSubEnabled = typeof subbotOnOffModule.isSubBotEnabled === 'function' 
                                ? subbotOnOffModule.isSubBotEnabled(msgChatJid, num) 
                                : true;

                            // Si el subbot está apagado individualmente (.bot off)
                            if (isSubEnabled === false) {
                                const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                const [commandName] = commandText.split(/\s+/);

                                // Permitir SIEMPRE los comandos de gestión
                                if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                    return; // 🚫 BLOQUEADO por .bot off (subbot individual)
                                }
                            }

                            // Si llegamos aquí: el mensaje está permitido (continuar procesamiento normal)

                        } catch (verifyError) {
                            console.error('[SubBot] Error verificando estado on/off:', verifyError.message);
                            // En caso de error en la verificación, permitir el comando (fail-open)
                        }
                    }

                    // ── Registro de actividad de usuario (Asíncrono no bloqueante) ──
                    if (!baileyMessage.key.fromMe && isGroupMsg) {
                        setImmediate(() => {
                            try {
                                const senderJidRec = baileyMessage.key.participant || msgChatJid;
                                const cleanSenderRec = senderJidRec.split('@')[0].split(':')[0].replace(/\D/g, '');

                                try {
                                    const chatHistory = require('../../chatHistory');
                                    const msgTimestamp = (baileyMessage.messageTimestamp || 0) * 1000;
                                    if (chatHistory.isReady) {
                                        chatHistory.recordMessage(msgChatJid, cleanSenderRec, msgText, msgTimestamp);
                                    }
                                } catch (chErr) { /* silencioso */ }
                            } catch (actErr) { /* silencioso */ }
                        });
                    }
                                } catch (chErr) { /* silencioso */ }
                            } catch (actErr) { /* silencioso */ }
                        });
                    }

                    const hasQuotedContext = (msg) => {
                        const ctx = msg?.contextInfo
                                 || msg?.extendedTextMessage?.contextInfo
                                 || msg?.extendedTextMessageV2?.contextInfo
                                 || msg?.buttonsResponseMessage?.contextInfo
                                 || msg?.listResponseMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || null;
                        return !!(ctx?.quotedMessage || ctx?.stanzaId || ctx?.participant);
                    };

                    const isQuotedReply = hasQuotedContext(baileyMessage.message);

                    if (baileyMessage.key.fromMe && !hasPrefix && !isQuotedReply) return;
                    if (shouldIgnoreFromMePrivateMessage(baileyMessage, sock)) return;
                    if (!msgText && !hasPrefix) return;
                    if (msgChatJid === OFFICIAL_GROUP && !isSubbotAllowedInOfficial(num)) return;

                    try {
                        if (!global.db?.data) return;
                        const compatibleMessage   = createCompatibleMessage(baileyMessage, sock);
                        compatibleMessage._sock   = sock;
                        compatibleMessage._subNum = num;

                        if (hasPrefix) {
                            activityTracker.recordActivity(num);
                        }

                        const prevLastMsg = global.lastBaileyMessage;
                        global.lastBaileyMessage = baileyMessage;

                        try {
                            if (global.commandHandler?.handleMessage)
                                await global.commandHandler.handleMessage(compatibleMessage);
                        } finally {
                            global.lastBaileyMessage = prevLastMsg;
                        }
                    } catch (e) {
                        if (!e.message?.includes('Connection Closed'))
                            console.error(`[SubBot] Error procesando mensaje:`, e.message);
                    }
                })().catch(e => console.error('[SubBot] Error no capturado en mensaje:', e.message));
            }
        });
}

// ─── Helpers ────────────────────────────────────────────────────────────────
function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

// ─── Fuerza cierre limpio de un subbot y lo reconecta ───────────────────────
async function forceReconnectSubBot({ num, chatJid, conn }) {
    const name     = String(num);
    const prevSock = activeSocks.get(name);

    if (prevSock) {
        destroySubBotSocket(prevSock);
    }

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    await sleep(300);
    return connectSubBot({ num, chatJid: chatJid || null, conn: conn || global.conn });
}

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .serbot | .qr | .code
// ════════════════════════════════════════════════════════════════════════════
const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .qr | .code',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        // Los subbots SÍ pueden procesar .serbot/.qr/.code — simplemente usan su propio socket

        const rawCmd       = (message.text || message.body || '').trim().replace(/^([.\/❤️#👅😎])\s+/, '$1').slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');

        // El QR/código se manda siempre en el mismo chat donde se usó el comando
        const replyDest = message.from;

        let arg0    = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        let codeRaw = '';

        if (isDirectCode) {
            // Normalizar el texto para que ". code 1234" y ".code 1234" se traten igual
            const fullText = (message.text || message.body || '').trim().replace(/^([.\/❤️#👅😎])\s+/, '$1');
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const key      = message.key || {};
                // En grupos el sender real está en participant, no en remoteJid
                const jidReal  = key.participantAlt || key.remoteJidAlt || key.participant || senderJid;
                const autoNum  = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                if (!autoNum || autoNum.length < 7)
                    return sock.sendMessage(replyDest, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` }, { quoted: message._baileyMessage });
                usePairingCode = true;
                phoneNumber    = autoNum;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(replyDest, { text: '📌 Opciones: \`.qr\` o \`.code\`' }, { quoted: message._baileyMessage });
        }

        cleanExpiredPending();
        if (pendingQRHas(senderJid)) {
            const secsLeft = pendingQRSecondsLeft(senderJid);
            const pendingMessage = secsLeft > 0
                ? `⏳ Ya tenés un proceso en curso. Podés pedir un nuevo código en *${secsLeft} segundo${secsLeft !== 1 ? 's' : ''}*.`
                : `⏳ Ya tenés un proceso pendiente. Si el anterior expiró o falló, espera unos segundos y volvé a intentarlo.`;
            return sock.sendMessage(replyDest, { text: pendingMessage }, { quoted: message._baileyMessage });
        }

        // ── Verificar que el número existe en WhatsApp (solo para .code) ────
        if (usePairingCode && phoneNumber) {
            const connForCheck = sock?.user ? sock : (global.conn?.user ? global.conn : (global.subConns || []).find(c => c?.user) || null);
            if (connForCheck && typeof connForCheck.onWhatsApp === 'function') {
                try {
                    const results = await connForCheck.onWhatsApp(`${phoneNumber}@s.whatsapp.net`);
                    const result  = Array.isArray(results) ? results[0] : null;
                    const exists  = !!(result && (result.exists === true || result.jid));
                    if (!exists) {
                        return sock.sendMessage(replyDest, {
                            text:
                                `❌ El número de teléfono no pertenece a una cuenta de WhatsApp activa.\n` +
                                `📱 *Número:* +${phoneNumber}\n\n` +
                                `⚠️ Si estás usando la opción de WhatsApp para *ocultar tu número de teléfono*, deberás desactivarla.\n\n` +
                                `De lo contrario podés usar:\n` +
                                `▸ \`.code <tu número>\` — ingresá tu número en formato internacional\n\n` +
                                `Si no sabés cuál es tu número en formato internacional podés usar:\n` +
                                `▸ \`.numwa <país> <número local>\` — para obtenerlo`
                        }, { quoted: message._baileyMessage });
                    }
                } catch (e) {
                    // Si la verificación falla por error de red u otro motivo, continuamos
                    // igual — no bloqueamos al usuario por un error de la API.
                    console.warn(`[SubBot] ⚠️ No se pudo verificar el número +${phoneNumber}: ${e.message}`);
                }
            }
        }

        const targetJid  = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);

        if (existingNum !== null) {
            const existingBot = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (existingBot) {
                if (existingBot.ws?.readyState === 1) {
                    return sock.sendMessage(replyDest, {
                        text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.\n💡 _Si no te está contestando, mandá *.reconnect* para reiniciar su sistema._`
                    }, { quoted: message._baileyMessage });
                } else {
                    try { existingBot.ev.removeAllListeners(); existingBot.ws.close(); } catch {}
                    activeSocks.delete(String(existingNum));
                    const ci = global.subConns.indexOf(existingBot);
                    if (ci >= 0) global.subConns.splice(ci, 1);
                }
            }

            try {
                removeSessionFiles(existingNum);
                console.log(`[SubBot] 🗑️ Sesión anterior borrada a petición del owner para bot #${existingNum}`);
            } catch (e) {}

            pendingQRAdd(senderJid, usePairingCode ? 95000 : 40000);
            sock.sendMessage(replyDest, { text: `⏳ Generando nueva sesión para tu sub-bot #${existingNum}...` }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true, replyQuote: message._baileyMessage, pendingKey: senderJid });
        }

        const num = nextSubBotNumber();
        pendingQRAdd(senderJid, usePairingCode ? 95000 : 40000);
        sock.sendMessage(replyDest, { text: `⏳ Generando acceso para sub-bot #${num}...` }, { quoted: message._baileyMessage });
        connectSubBot({ num, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true, replyQuote: message._baileyMessage, pendingKey: senderJid });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .reconnect | .codebot
//  → Lo puede usar el owner del subbot O el propio subbot
//  → Desconecta y reconecta al 100% aunque esté "activo"
// ════════════════════════════════════════════════════════════════════════════
const reconnectHandler = {
    command: /^(reconnect|codebot)$/i,
    help: 'Reconectar tu sub-bot al 100%. Solo el owner o el propio sub-bot pueden usarlo.',
    tags: ['subbots'],
    handler: async (message) => {
        const sock      = message._sock || global.conn;
        const senderJid = message.author || message.sender || message.from;

        if (message.isGroup)
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });

        // Si lo manda el propio subbot, usamos ese número directamente
        let numToReconnect = message._subNum || null;

        // Si no, buscamos si el sender es owner de algún subbot
        if (!numToReconnect) numToReconnect = getSubBotNumberByOwner(senderJid);

        if (!numToReconnect) {
            return sock.sendMessage(message.from, {
                text: `❌ No tenés ningún sub-bot registrado para reconectar.`
            }, { quoted: message._baileyMessage });
        }

        await sock.sendMessage(message.from, {
            text: `🔄 Forzando reconexión completa del sub-bot #${numToReconnect}...\n⚠️ _Puede tardar unos segundos._`
        }, { quoted: message._baileyMessage });

        try {
            await forceReconnectSubBot({ num: numToReconnect, chatJid: senderJid, conn: global.conn || sock });
        } catch (e) {
            console.error(`[reconnect] Error reconectando subbot #${numToReconnect}:`, e.message);
            sock.sendMessage(message.from, { text: `⚠️ Error al reconectar: ${e.message}` });
        }
    }
};


// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .listbots | .bots | .subbots
// ════════════════════════════════════════════════════════════════════════════
const listBotsHandler = {
    command: /^(listbots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message) => {
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0)
            return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}\n\n💡 _Si tu sub-bot se tranca, mandá *.reconnect* para destrabarlo._`
        });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  Auto-reconexión al iniciar el bot - OPTIMIZADO CON PRIORIZACIÓN Y PARALELISMO
// ════════════════════════════════════════════════════════════════════════════
async function autoReconnectSubBots(conn) {
    // conn puede ser null si el bot principal aún no se conectó/escaneó.
    // Los subbots tienen sus propias sesiones y se conectan de forma independiente.
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    console.log(`[SubBot Monitor] Analizando bases de datos de sub-bots...`);
    console.log(`[SubBot Monitor] Encontrados ${nums.length} subbots registrados`);

    // ── Filtrar y limpiar sesiones fantasma / corruptas ──────────────────────
    const validNums = [];
    for (const num of nums) {
        const dbFile = sessionPath(num);

        try {
            if (fs.existsSync(dbFile)) {
                const stats = fs.statSync(dbFile);
                if (stats.size === 0) {
                    console.log(`[SubBot Garbage Collector] 🗑️ Eliminando archivo vacío de sesión #${num}`);
                    try { removeSessionFiles(num); } catch (e) {}
                    continue;
                }
                if (!isValidSessionDb(dbFile)) {
                    console.log(`[SubBot Garbage Collector] ⚠️ Archivo .db corrupto/sin llaves para #${num}`);
                    try { removeSessionFiles(num); } catch (e) {}
                    continue;
                }
            }
        } catch (err) {
            console.error(`Error limpiando archivo #${num}:`, err.message);
        }

        if (activeSocks.has(String(num))) continue;
        validNums.push(num);
    }

    // ── Limpiar registros de actividad de subbots eliminados ─────────────────
    activityTracker.cleanupInvalidRecords([...validNums, ...nums]);

    if (validNums.length === 0) {
        console.log(`[SubBot Monitor] ✅ No hay subbots para reconectar`);
        return;
    }

    // ── Ordenar por último uso (más reciente primero) ────────────────────────
    const sortedNums = activityTracker.getSortedByActivity(validNums);
    
    console.log(`[SubBot Monitor] 🔄 Reconectando ${sortedNums.length} subbots en orden de prioridad...`);
    
    // Mostrar los primeros 5 más activos
    const top5 = sortedNums.slice(0, 5);
    for (const num of top5) {
        const stats = activityTracker.getActivityStats(num);
        if (stats.lastUsed) {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: ${stats.commandCount} comandos, último uso hace ${stats.daysSinceLastUse} días`);
        } else {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: Sin historial de uso`);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONFIGURACIÓN DE RECURSOS - OPTIMIZADO PARA VELOCIDAD
    // ════════════════════════════════════════════════════════════════════════
    // Conectamos de a 8 simultáneamente para reconexión más rápida (duplicado de 4)
    // Delays mínimos: los subbots ya tienen rate limiting interno, estos delays solo ralentizan
    const PARALLEL_CONNECTIONS = 4;      // Conectar de a 4 para estabilidad
    const DELAY_BETWEEN_BATCHES = 1500;   // 1.5s entre lotes para no saturar memoria/red
    const DELAY_BETWEEN_BOTS = 300;      // 300ms entre bots

    // ── Procesar en lotes paralelos ──────────────────────────────────────────
    for (let i = 0; i < sortedNums.length; i += PARALLEL_CONNECTIONS) {
        const batch = sortedNums.slice(i, i + PARALLEL_CONNECTIONS);
        const batchNum = Math.floor(i / PARALLEL_CONNECTIONS) + 1;
        const totalBatches = Math.ceil(sortedNums.length / PARALLEL_CONNECTIONS);
        
        console.log(`[SubBot Monitor] 🔄 Lote ${batchNum}/${totalBatches}: Conectando subbots ${batch.join(', ')}`);
        
        // Conectar todos los bots del lote en paralelo
        const promises = batch.map((num, index) => {
            return (async () => {
                try {
                    // Pequeño delay escalonado dentro del lote para evitar picos
                    if (index > 0) {
                        await sleep(DELAY_BETWEEN_BOTS * index);
                    }
                    
                    const startTime = Date.now();
                    await connectSubBot({ num, chatJid: null, conn });
                    const duration = Date.now() - startTime;
                    
                    console.log(`[SubBot Monitor] ✅ SubBot #${num} conectado en ${duration}ms`);
                } catch (e) {
                    console.error(`[SubBot Monitor] ❌ Error conectando subbot #${num}:`, e.message);
                }
            })();
        });
        
        // Esperar a que todos los bots del lote se conecten
        await Promise.all(promises);
        
        // Delay entre lotes (excepto después del último)
        if (i + PARALLEL_CONNECTIONS < sortedNums.length) {
            console.log(`[SubBot Monitor] ⏳ Esperando ${DELAY_BETWEEN_BATCHES}ms antes del siguiente lote...`);
            await sleep(DELAY_BETWEEN_BATCHES);
        }
    }
    
    console.log(`[SubBot Monitor] ✅ Proceso de reconexión completado. ${sortedNums.length} subbots procesados.`);
    
    // No unir subbots al canal automáticamente en la reconexión al iniciar
}

async function connectSubBotWeb({ num, conn }) { return connectSubBot({ num, chatJid: null, conn, isNewLinking: true }); }
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) { return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber, isNewLinking: true }); }

// ════════════════════════════════════════════════════════════════════════════
//  EXPORTS — todos los handlers en un solo archivo
// ════════════════════════════════════════════════════════════════════════════
module.exports = {
    // Handler principal (.serbot / .qr / .code)
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,

    // Sub-handlers extras exportados como objetos separados
    // El loader de plugins los registra si los encontrás en module.exports
    reconnect:           reconnectHandler,
    listBots:            listBotsHandler,

    // Funciones internas usadas por otros módulos
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    connectSubBot,        // exportado para uso externo si hiciera falta
    activeSocks,
    getSubBotNumberByOwner,
    removeSessionFiles,
    destroySubBotSocket,
};