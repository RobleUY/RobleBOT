'use strict';

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

// ── IMPORTAR MÓDULO DE BIENVENIDAS ──
const welcomeGoodbyeModule = require('../../plugins/HERRAMIENTAS/bienvenida-despedida');

// ── IMPORTAR SISTEMA DE TRACKING DE ACTIVIDAD ──
const activityTracker = require('./subbotActivityTracker');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
// Limpiar archivos huérfanos de sesiones al arrancar
try { cleanOrphanSessionFiles(); } catch (e) { console.error('[SubBot] Error limpieza inicial sesiones:', e.message); }

if (!global.subConns) global.subConns = [];

const OFFICIAL_GROUP = '120363203689229697@g.us';
const activeSocks = new Map();
const pendingQR = new Set();
const reconnectTimers = new Map();
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── Caché de grupos donde está el bot principal ───────────────────────────────
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000;

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) mainBotGroupsCache.add(jid);
            }
        } catch (e) {}
    }
    return mainBotGroupsCache.has(groupJid);
}

function hasFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return false;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = 2000');
        db.pragma('busy_timeout = 2000');
        const row = db.prepare("SELECT value FROM auth WHERE key = 'hasFollowedChannel'").get();
        db.close();
        return !!row;
    } catch (e) {
        return false;
    }
}

function setFollowedChannelDb(dbFile) {
    try {
        if (!fs.existsSync(dbFile)) return;
        const Database = require('better-sqlite3');
        const db = new Database(dbFile);
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('busy_timeout = 5000');
        db.prepare("INSERT OR REPLACE INTO auth (key, value) VALUES ('hasFollowedChannel', 'true')").run();
        db.close();
    } catch (e) {
        console.error('[SubBot Db] Error guardando estado de canal seguido:', e.message);
    }
}

async function followPublicChannel(sock, botLabel = 'Bot') {
    await sleep(4000);
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        
        if (inviteCode) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            
            // Obtiene los metadatos reales usando el código del enlace
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            
            if (metadata && metadata.id) {
                const channelJid = metadata.id;

                // El bot sigue al canal de WhatsApp
                await sock.newsletterFollow(channelJid);
                console.log(`[Canal ${botLabel}] Unido exitosamente`);
            }
        }
    } catch (error) {
        // Filtra el falso error de Baileys v7 si la suscripción ya está activa
        if (error.message?.includes('unexpected response structure')) {
            console.log(`[Canal ${botLabel}] Intentando unirme...`);
            console.log(`[Canal ${botLabel}] Ya siguiendo al canal, intentando confirmar...`);
            console.log(`[Canal ${botLabel}] Ya sigue al canal. CONFIRMADO`);
        } else {
            // Muestra en rojo si es un error real diferente
            console.error(`[Canal ${botLabel}] ❌ Error real al seguir el canal:`, error.message);
            return false;
        }
    }
    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function sessionFiles(num) {
    const base = path.join(SESSIONS_DIR, String(num));
    return [
        `${base}.db`,
        `${base}.db-wal`,
        `${base}.db-shm`
    ];
}

function removeSessionFiles(num) {
    const files = sessionFiles(num);
    for (const f of files) {
        try {
            if (fs.existsSync(f)) {
                fs.unlinkSync(f);
                console.log(`[SubBot] 🗑️ Eliminado archivo de sesión: ${path.basename(f)}`);
            }
        } catch (e) {
            console.error(`[SubBot] Error eliminando ${f}:`, e.message);
        }
    }
}

function cleanOrphanSessionFiles() {
    try {
        if (!fs.existsSync(SESSIONS_DIR)) return;
        const files = fs.readdirSync(SESSIONS_DIR);
        const grouped = {};
        for (const f of files) {
            const m = f.match(/^(\d+)(?:\.db|\.db-wal|\.db-shm)$/);
            if (!m) continue;
            const n = parseInt(m[1]);
            if (!grouped[n]) grouped[n] = new Set();
            grouped[n].add(f);
        }

        for (const nStr of Object.keys(grouped)) {
            const n = parseInt(nStr);
            const names = Array.from(grouped[n]);
            // Si no existe el .db pero hay wal/shm, limpiar todos los archivos asociados
            const hasDb = names.some(x => x.endsWith('.db'));
            if (!hasDb) {
                console.log(`[SubBot Garbage Collector] 🗑️ Archivo .db faltante para #${n}, limpiando restos: ${names.join(', ')}`);
                removeSessionFiles(n);
            }
        }
    } catch (e) {
        console.error('[SubBot Garbage Collector] Error escaneando sesiones:', e.message);
    }
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do { n = Math.floor(1000 + Math.random() * 9000); } while (existing.includes(n));
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            if (fs.statSync(dbPath).size <= 13000) continue;
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 3000');
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null, isNewLinking = false }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;

    if (fs.existsSync(dbFile)) {
        try {
            if (fs.statSync(dbFile).size > 13000) {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile, { readonly: true });
                _db.pragma('cache_size = 5000');
                _db.pragma('busy_timeout = 3000');
                const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                _db.close();
                if (row) {
                    const data = JSON.parse(row.value);
                    if (!ownerJid) ownerJid = data.ownerJid;
                    if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                }
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        browser: ['Ubuntu', 'Chrome', '22.04'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 5000,
        keepAliveIntervalMs: 30000
    });

    // Exponer la función de guardado para reinicios limpios
    try { sock._saveCreds = saveCreds; } catch (e) {}

    sock._subName        = name;
    sock._subNum         = num;
    sock._sessDb         = dbFile;
    sock._ownerJid       = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime          = Date.now();
    activeSocks.set(name, sock);

    if (welcomeGoodbyeModule?.init) {
        try {
            welcomeGoodbyeModule.init(sock);
            console.log(`[SubBot #${num}] ✓ Módulo Bienvenida/Despedida conectado.`);
        } catch (error) {
            console.error(`[SubBot #${num}] ❌ Error iniciando Bienvenida/Despedida:`, error.message);
        }
    }

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false;
    let codeSent             = false;
    let pairingCodeRequested = false;

    const sendToOwner = async (content) => {
        if (!ownerJid) return;
        const sender = (connected ? sock : (conn || global.conn));
        try {
            await sender.sendMessage(ownerJid, content);
        } catch (e) {
            try {
                const fallback = sender === sock ? (conn || global.conn) : sock;
                await fallback.sendMessage(ownerJid, content);
            } catch {}
        }
    };

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (
            usePairingCode &&
            phoneNumber &&
            !pairingCodeRequested &&
            !connected &&
            !state.creds.registered &&
            (connection === 'connecting' || !!qr)
        ) {
            pairingCodeRequested = true;
            await sleep(connection === 'connecting' ? 3000 : 500);
            if (connected) return;

            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);
                codeSent = true;

                await sendToOwner({
                    text: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                });
                await sendToOwner({ text: code });

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                qrTimeout = setTimeout(() => {
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ Código expirado. Genera uno nuevo con \`.code\`.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `❌ Error generando código: ${e.message}` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }
            return;
        }

        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwner({
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                });
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    sendToOwner({ text: `⏰ QR expirado. Usa \`.serbot qr\` de nuevo.` });
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                }, 35000);
            } catch (e) {}
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.pragma('journal_mode = WAL');
                _db.pragma('synchronous = NORMAL');
                _db.pragma('cache_size = 10000');
                _db.pragma('busy_timeout = 5000');
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch {}

            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);

            if (ownerJid) {
                const phoneNum = sock.user?.id?.split('@')[0]?.split(':')[0] || '?';
                await sendToOwner({ text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` });
            }

            // ── Unirse al canal 60 segundos después de vincularse ──
            const dbFile = sessionPath(num);
            if (isNewLinking) {
                if (!hasFollowedChannelDb(dbFile)) {
                    const delay = 60000; // 60 segundos
                    console.log(`[Canal SubBot #${num}] Nuevo sub-bot vinculado. Programado unirse al canal en 60 segundos...`);
                    setTimeout(async () => {
                        try {
                            const success = await followPublicChannel(sock, `SubBot #${num}`);
                            if (success) {
                                setFollowedChannelDb(dbFile);
                            }
                        } catch (e) {
                            console.error(`[Canal SubBot #${num}] Error en followPublicChannel:`, e.message);
                        }
                    }, delay);
                } else {
                    console.log(`[Canal SubBot #${num}] El sub-bot ya sigue al canal en esta sesión (omitido)`);
                }
            } else {
                console.log(`[Canal SubBot #${num}] Conexión/Reconexión establecida. No se une al canal (omitido)`);
            }
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);

            const isLoggedOut = code === DisconnectReason.loggedOut;
            const isAuthIssue = [401, 403, 405].includes(code);

            if (isLoggedOut || code === 440) {
                if (isLoggedOut) {
                    try { removeSessionFiles(num); } catch {}
                    // Limpiar todos los datos persistidos del subbot eliminado
                    cleanupSubBotData(num);
                }
                if (code === 440) {
                    console.log(`[SubBot] ⚠️ Bot #${num} reemplazado (440). NO reconectará para evitar bucle.`);
                    return;
                }
                sendToOwner({ text: `⚠️ Sesión del sub-bot #${num} cerrada o inválida. Usa \.serbot qr\` o \.serbot code\` para reconectar.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // Error 403 (Forbidden) - la sesión está baneada o inválida y no puede repararse
            if (code === 403) {
                console.log(`[SubBot] ❌ Sub-bot #${num} recibió error 403 (Forbidden). La sesión está inválida/baneada.`);
                console.log(`[SubBot] 🗑️ Eliminando sesión corrupta del sub-bot #${num}...`);
                try { removeSessionFiles(num); } catch (e) {
                    console.error(`[SubBot] Error eliminando sesión #${num}:`, e.message);
                }
                // Limpiar todos los datos persistidos del subbot eliminado
                cleanupSubBotData(num);
                sendToOwner({ text: `❌ Sub-bot #${num} recibió error 403 (Forbidden).\n\n⚠️ La sesión ha sido eliminada porque estaba inválida o baneada.\n\n💡 Usa \`.serbot qr\` o \`.serbot code\` para crear una nueva sesión.` });
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                return;
            }

            // Otros errores de autenticación (401, 405)
            if (isAuthIssue) {
                console.log(`[SubBot] ⚠️ Sub-bot #${num} recibió un error de auth (${code}). Intentando reconectar sin borrar la sesión.`);
                sendToOwner({ text: `⚠️ Sub-bot #${num} tuvo un error de auth (${code}). Se reintentará reconexión automática.` });
            }

            // ── Reconexión con delay optimizado para recursos del servidor ──
            const reconnectDelay = 5000 + (Math.abs(num % 10) * 500);

            if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));

            const tid = setTimeout(() => {
                reconnectTimers.delete(name);
                console.log(`[SubBot] Reconectando bot #${num}...`);
                connectSubBot({ num, chatJid: ownerJid, conn });
            }, reconnectDelay);

            reconnectTimers.set(name, tid);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Set();

    // Número puro de este subbot (para ignorar mensajes enviados por sí mismo)
    function getOwnNumber() {
        const id = sock.user?.id || '';
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    }

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.add(messageId);

            if (processedIds.size > 500) {
                const arr = Array.from(processedIds).slice(-200);
                processedIds.clear();
                arr.forEach(id => processedIds.add(id));
            }

            const msgText    = getMessageText(baileyMessage);
            const hasPrefix  = ['.', '/', '❤️', '#'].some(p => msgText.startsWith(p));
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            // Comportamiento estándar: ignorar mensajes propios sin prefijo
            if (baileyMessage.key.fromMe && !hasPrefix) continue;

            // ── Bloquear comandos de vinculación enviados por el propio número ──
            // Solo los comandos .serbot/.qr/.code se ignoran si los manda el propio
            // subbot, para evitar que se responda a sí mismo al vincularse.
            // El resto de comandos (.menu, .saldo, etc.) funcionan normalmente.
            const senderRaw = (baileyMessage.key.participant || baileyMessage.key.remoteJid || '');
            const senderNum = senderRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
            const ownNum    = getOwnNumber();
            if (ownNum && senderNum && senderNum === ownNum && hasPrefix) {
                const cmdText = msgText.trim().slice(1).split(/\s+/)[0].toLowerCase();
                const LINK_CMDS = ['serbot', 'jadibot', 'qr', 'code'];
                if (LINK_CMDS.includes(cmdText)) continue;
            }
            // ─────────────────────────────────────────────────────────────────

            if (!msgText && !hasPrefix) continue;

            // ── Grupo principal: lógica de qué subbot puede responder ────────────
            // Casos:
            //  0) Comando .gofc subbots on/off → SIEMPRE lo procesa el fallback
            //     (subbot con _subNum más bajo) sin importar el modo ni si el
            //     principal está activo. Garantiza que el comando siempre funcione.
            //  1) .gofc subbots ON  → solo el subbot asignado responde (+ bot principal).
            //     Si el asignado se cayó, se reasigna automáticamente uno activo.
            //  2) .gofc subbots OFF → comportamiento original:
            //     - Bot principal activo  → subbots NO responden.
            //     - Bot principal caído   → solo el subbot fallback (menor _subNum).
            if (msgChatJid === OFFICIAL_GROUP) {
                // Detectar si es el comando .gofc (con cualquier prefijo)
                const isGofcCmd = /^[.\/❤️#👅😎]gofc(\s|$)/i.test(msgText);

                if (isGofcCmd) {
                    // El comando .gofc siempre lo ejecuta el fallback (menor _subNum),
                    // tanto para que responda aunque el principal esté caído,
                    // como para evitar que varios subbots respondan a la vez.
                    const activeSubs = (global.subConns || []).filter(c => c?.user && c._subNum != null);
                    const fallbackNum = activeSubs.length > 0
                        ? Math.min(...activeSubs.map(c => c._subNum))
                        : num;
                    if (num !== fallbackNum) continue;
                    // Este es el fallback → procesa el comando .gofc

                } else {
                    try {
                        const gofcModule = require('./gofc-subbots');
                        if (gofcModule.isGofcEnabled()) {
                            // Modo .gofc subbots ON
                            let assigned = gofcModule.getAssignedSubbot();

                            // Si el asignado ya no está vivo, elegir otro y reasignar
                            if (!gofcModule.isAssignedSubbotAlive(assigned)) {
                                const newPick = gofcModule.pickActiveSubbot();
                                if (!newPick) {
                                    // No hay subbots disponibles → este no responde
                                    continue;
                                }
                                gofcModule.assignSubbot(newPick);
                                assigned = newPick;
                                console.log(`[GOFC] Subbot #${assigned} asignado automáticamente al grupo oficial (el anterior se desconectó)`);
                            }

                            // Solo el subbot asignado responde
                            if (num !== assigned) continue;
                            // Este ES el asignado → continúa y procesa el mensaje

                        } else {
                            // Modo .gofc subbots OFF → comportamiento original
                            const mainActive = !!(global.conn?.user);
                            if (mainActive) {
                                continue; // Bot principal activo → subbots no responden
                            } else {
                                // Bot principal caído → solo el fallback (menor _subNum)
                                const activeSubs = (global.subConns || []).filter(c => c?.user && c._subNum != null);
                                const fallbackNum = activeSubs.length > 0
                                    ? Math.min(...activeSubs.map(c => c._subNum))
                                    : num;
                                if (num !== fallbackNum) continue;
                            }
                        }
                    } catch (e) {
                        // Si falla cargar el módulo gofc, usar comportamiento original
                        const mainActive = !!(global.conn?.user);
                        if (mainActive) continue;
                    }
                }
            }
            // ─────────────────────────────────────────────────────────────────

            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            try {
                if (!global.db?.data) continue;
                const compatibleMessage   = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock   = sock;
                compatibleMessage._subNum = num;

                // ── Registrar actividad del subbot cuando procesa un comando ──
                if (hasPrefix) {
                    activityTracker.recordActivity(num);
                }

                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage)
                        await global.commandHandler.handleMessage(compatibleMessage);
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Helpers ────────────────────────────────────────────────────────────────
function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

/**
 * Limpia TODOS los datos persistidos de un subbot eliminado:
 *  - subbots-actividad.json  (activityTracker)
 *  - subbot-onoff.json       (on/off global y por chat)
 *  - subbot-responder.json   (responder en privados/grupos)
 *
 * Se llama siempre que la sesión del subbot es borrada definitivamente.
 */
function cleanupSubBotData(num) {
    // Calcular los IDs que siguen válidos (todos menos el que se elimina)
    const remainingNums = (global.subConns || [])
        .filter(c => c._subNum != null && c._subNum !== num)
        .map(c => c._subNum);

    try { activityTracker.cleanupInvalidRecords(remainingNums); } catch (e) {
        console.error(`[SubBot] Error limpiando actividad de #${num}:`, e.message);
    }
    try {
        const onoffModule = require('./subbots-onoff.js');
        if (typeof onoffModule.cleanupSubBot === 'function') onoffModule.cleanupSubBot(num);
    } catch (e) {
        console.error(`[SubBot] Error limpiando onoff/responder de #${num}:`, e.message);
    }
}

// ─── Fuerza cierre limpio de un subbot y lo reconecta ───────────────────────
async function forceReconnectSubBot({ num, chatJid, conn }) {
    const name     = String(num);
    const prevSock = activeSocks.get(name);

    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws?.terminate?.(); prevSock.ws?.close?.(); } catch {}
        activeSocks.delete(name);
    }

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    if (global.subConns) {
        const ci = global.subConns.findIndex(c => c._subNum === num);
        if (ci >= 0) global.subConns.splice(ci, 1);
    }

    await sleep(1500);
    return connectSubBot({ num, chatJid: chatJid || null, conn: conn || global.conn });
}

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .serbot | .qr | .code
// ════════════════════════════════════════════════════════════════════════════
const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .code',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        // En el grupo oficial solo bloquear el comando si el bot principal está activo
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && global.conn?.user) return;

        // Si este mensaje lo está procesando un subbot, verificar si el sender
        // es el propio número del subbot. Si es así, ignorarlo silenciosamente
        // (un subbot no se responde a sí mismo).
        // Si el sender es OTRA persona, el subbot sí procesa el comando normalmente.
        if (isSubBotMessage(message)) {
            const processingSubNum = message._subNum;
            const processingSock   = (global.subConns || []).find(c => c._subNum === processingSubNum) || sock;
            const subOwnId         = processingSock?.user?.id || '';
            const subOwnNum        = subOwnId.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

            const senderJidRaw = message.author || message.sender || message.from || '';
            const senderNum    = senderJidRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

            // Es el propio subbot enviándose un mensaje → ignorar sin responder
            if (subOwnNum && senderNum && senderNum === subOwnNum) return;

            // Es otra persona usando el subbot → continuar con el flujo normal
            // (no redirigir al bot principal, dejar que este subbot maneje el comando)
        }

        const rawCmd       = (message.text || message.body || '').trim().slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        if (message.isGroup)
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');

        let arg0    = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        let codeRaw = '';

        if (isDirectCode) {
            const fullText = (message.text || message.body || '').trim();
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const key      = message.key || {};
                const jidReal  = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid || senderJid;
                const autoNum  = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                if (!autoNum || autoNum.length < 7)
                    return sock.sendMessage(message.from, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` });
                usePairingCode = true;
                phoneNumber    = autoNum;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(message.from, { text: '📌 Opciones: \`.serbot qr\` o \`.code\`' });
        }

        if (pendingQR.has(senderJid))
            return sock.sendMessage(message.from, { text: `⏳ Ya tenés un proceso pendiente.` });

        const targetJid  = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);

        if (existingNum !== null) {
            const existingBot = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (existingBot) {
                if (existingBot.ws?.readyState === 1) {
                    return sock.sendMessage(message.from, {
                        text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.\n💡 _Si no te está contestando, mandá *.reconnect* para reiniciar su sistema._`
                    });
                } else {
                    try { existingBot.ev.removeAllListeners(); existingBot.ws.close(); } catch {}
                    activeSocks.delete(String(existingNum));
                    const ci = global.subConns.indexOf(existingBot);
                    if (ci >= 0) global.subConns.splice(ci, 1);
                }
            }

            const dbPath = sessionPath(existingNum);
            try {
                removeSessionFiles(existingNum);
                console.log(`[SubBot] 🗑️ Sesión anterior borrada a petición del owner para bot #${existingNum}`);
            } catch (e) {}

            pendingQR.add(senderJid);
            sock.sendMessage(message.from, { text: `⏳ Generando nueva sesión para tu sub-bot #${existingNum}...` });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber, isNewLinking: true });
        }

        const num = nextSubBotNumber();
        pendingQR.add(senderJid);
        sock.sendMessage(message.from, { text: `⏳ Generando acceso para sub-bot #${num}...` });
        connectSubBot({ num, chatJid: senderJid, conn: sock, usePairingCode, phoneNumber, isNewLinking: true });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .reconnect | .codebot
//  → Lo puede usar el owner del subbot O el propio subbot
//  → Desconecta y reconecta al 100% aunque esté "activo"
// ════════════════════════════════════════════════════════════════════════════
const reconnectHandler = {
    command: /^(reconnect|codebot)$/i,
    help: 'Reconectar tu sub-bot al 100%. Solo el owner o el propio sub-bot pueden usarlo.',
    tags: ['subbots'],
    handler: async (message) => {
        const sock      = message._sock || global.conn;
        const senderJid = message.author || message.sender || message.from;

        if (message.isGroup)
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });

        // Si lo manda el propio subbot, usamos ese número directamente
        let numToReconnect = message._subNum || null;

        // Si no, buscamos si el sender es owner de algún subbot
        if (!numToReconnect) numToReconnect = getSubBotNumberByOwner(senderJid);

        if (!numToReconnect) {
            return sock.sendMessage(message.from, {
                text: `❌ No tenés ningún sub-bot registrado para reconectar.`
            }, { quoted: message._baileyMessage });
        }

        await sock.sendMessage(message.from, {
            text: `🔄 Forzando reconexión completa del sub-bot #${numToReconnect}...\n⚠️ _Puede tardar unos segundos._`
        }, { quoted: message._baileyMessage });

        try {
            await forceReconnectSubBot({ num: numToReconnect, chatJid: senderJid, conn: global.conn || sock });
        } catch (e) {
            console.error(`[reconnect] Error reconectando subbot #${numToReconnect}:`, e.message);
            sock.sendMessage(message.from, { text: `⚠️ Error al reconectar: ${e.message}` });
        }
    }
};


// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .listbots | .bots | .subbots
// ════════════════════════════════════════════════════════════════════════════
const listBotsHandler = {
    command: /^(listbots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message) => {
        // En el grupo oficial solo bloquear si el bot principal está activo
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && global.conn?.user) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0)
            return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}\n\n💡 _Si tu sub-bot se tranca, mandá *.reconnect* para destrabarlo._`
        });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  Auto-reconexión al iniciar el bot - OPTIMIZADO CON PRIORIZACIÓN Y PARALELISMO
// ════════════════════════════════════════════════════════════════════════════
async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    console.log(`[SubBot Monitor] Analizando bases de datos de sub-bots...`);
    console.log(`[SubBot Monitor] Encontrados ${nums.length} subbots registrados`);

    // ── Filtrar y limpiar sesiones fantasma ──────────────────────────────────
    const validNums = [];
    for (const num of nums) {
        const dbFile = sessionPath(num);

        try {
            if (fs.existsSync(dbFile)) {
                const stats = fs.statSync(dbFile);
                if (stats.size <= 13000) {
                    console.log(`[SubBot Garbage Collector] 🗑️ Eliminando registro fantasma #${num} (${stats.size} bytes)`);
                    try { removeSessionFiles(num); } catch (e) {}
                    continue;
                }
            }
        } catch (err) {
            console.error(`Error limpiando archivo #${num}:`, err.message);
        }

        if (activeSocks.has(String(num))) continue;
        validNums.push(num);
    }

    // ── Limpiar datos de subbots con sesión fantasma ─────────────────────────
    activityTracker.cleanupInvalidRecords(validNums);
    try {
        const onoffModule = require('./subbots-onoff.js');
        if (typeof onoffModule.cleanupSubBot === 'function') {
            const invalidNums = nums.filter(n => !validNums.includes(n));
            for (const n of invalidNums) onoffModule.cleanupSubBot(n);
        }
    } catch (e) {
        console.error('[SubBot Monitor] Error limpiando onoff de fantasmas:', e.message);
    }

    if (validNums.length === 0) {
        console.log(`[SubBot Monitor] ✅ No hay subbots para reconectar`);
        return;
    }

    // ── Ordenar por último uso (más reciente primero) ────────────────────────
    const sortedNums = activityTracker.getSortedByActivity(validNums);
    
    console.log(`[SubBot Monitor] 🔄 Reconectando ${sortedNums.length} subbots en orden de prioridad...`);
    
    // Mostrar los primeros 5 más activos
    const top5 = sortedNums.slice(0, 5);
    for (const num of top5) {
        const stats = activityTracker.getActivityStats(num);
        if (stats.lastUsed) {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: ${stats.commandCount} comandos, último uso hace ${stats.daysSinceLastUse} días`);
        } else {
            console.log(`[SubBot Monitor] 📊 SubBot #${num}: Sin historial de uso`);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONFIGURACIÓN DE RECURSOS
    // ════════════════════════════════════════════════════════════════════════
    // Con 2 CPU cores y 3GB RAM, conectamos de a 2 simultáneamente
    // Delay reducido para aprovechar 10Gbps de red
    const PARALLEL_CONNECTIONS = 2;      // Conectar de a 2 (1 por core)
    const DELAY_BETWEEN_BATCHES = 2500;  // 2.5 segundos entre lotes (reducido de 6-12s)
    const DELAY_BETWEEN_BOTS = 800;      // 800ms entre bots del mismo lote

    // ── Procesar en lotes paralelos ──────────────────────────────────────────
    for (let i = 0; i < sortedNums.length; i += PARALLEL_CONNECTIONS) {
        const batch = sortedNums.slice(i, i + PARALLEL_CONNECTIONS);
        const batchNum = Math.floor(i / PARALLEL_CONNECTIONS) + 1;
        const totalBatches = Math.ceil(sortedNums.length / PARALLEL_CONNECTIONS);
        
        console.log(`[SubBot Monitor] 🔄 Lote ${batchNum}/${totalBatches}: Conectando subbots ${batch.join(', ')}`);
        
        // Conectar todos los bots del lote en paralelo
        const promises = batch.map((num, index) => {
            return (async () => {
                try {
                    // Pequeño delay escalonado dentro del lote para evitar picos
                    if (index > 0) {
                        await sleep(DELAY_BETWEEN_BOTS * index);
                    }
                    
                    const startTime = Date.now();
                    await connectSubBot({ num, chatJid: null, conn });
                    const duration = Date.now() - startTime;
                    
                    console.log(`[SubBot Monitor] ✅ SubBot #${num} conectado en ${duration}ms`);
                } catch (e) {
                    console.error(`[SubBot Monitor] ❌ Error conectando subbot #${num}:`, e.message);
                }
            })();
        });
        
        // Esperar a que todos los bots del lote se conecten
        await Promise.all(promises);
        
        // Delay entre lotes (excepto después del último)
        if (i + PARALLEL_CONNECTIONS < sortedNums.length) {
            console.log(`[SubBot Monitor] ⏳ Esperando ${DELAY_BETWEEN_BATCHES}ms antes del siguiente lote...`);
            await sleep(DELAY_BETWEEN_BATCHES);
        }
    }
    
    console.log(`[SubBot Monitor] ✅ Proceso de reconexión completado. ${sortedNums.length} subbots procesados.`);
    
    // No unir subbots al canal automáticamente en la reconexión al iniciar
}

async function connectSubBotWeb({ num, conn }) { return connectSubBot({ num, chatJid: null, conn, isNewLinking: true }); }
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) { return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber, isNewLinking: true }); }

// ════════════════════════════════════════════════════════════════════════════
//  Arranque INDEPENDIENTE de subbots — sin necesitar el bot principal
//  Se llama apenas arranca el proceso (antes de escanear QR).
//  Si el bot principal luego se conecta, autoReconnectSubBots lo omite porque
//  activeSocks ya contiene los subbots activos.
// ════════════════════════════════════════════════════════════════════════════
let _independentStartDone = false;

async function startSubBotsIndependent() {
    // Ejecutar solo una vez por proceso
    if (_independentStartDone) return;
    _independentStartDone = true;

    if (!fs.existsSync(SESSIONS_DIR)) {
        console.log('[SubBot Independent] No hay carpeta de sesiones — nada que iniciar.');
        return;
    }

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));

    if (nums.length === 0) {
        console.log('[SubBot Independent] No hay subbots guardados.');
        return;
    }

    // Filtrar sesiones fantasma (archivos muy pequeños = no autenticados)
    const validNums = [];
    for (const num of nums) {
        const dbFile = sessionPath(num);
        try {
            const stats = fs.statSync(dbFile);
            if (stats.size <= 13000) {
                console.log(`[SubBot Independent] 🗑️ Sesión fantasma #${num} (${stats.size} bytes) — omitida`);
                continue;
            }
        } catch { continue; }

        // No reconectar los que ya están en activeSocks
        if (activeSocks.has(String(num))) continue;
        validNums.push(num);
    }

    if (validNums.length === 0) {
        console.log('[SubBot Independent] Todos los subbots ya están activos o no hay sesiones válidas.');
        return;
    }

    console.log(`[SubBot Independent] 🚀 Arrancando ${validNums.length} subbot(s) SIN esperar bot principal...`);

    // Ordenar por actividad si está disponible
    const sortedNums = activityTracker.getSortedByActivity(validNums);

    const PARALLEL = 2;
    const BATCH_DELAY = 2500;
    const BOT_DELAY = 800;

    for (let i = 0; i < sortedNums.length; i += PARALLEL) {
        const batch = sortedNums.slice(i, i + PARALLEL);
        const batchNum = Math.floor(i / PARALLEL) + 1;
        const totalBatches = Math.ceil(sortedNums.length / PARALLEL);

        console.log(`[SubBot Independent] Lote ${batchNum}/${totalBatches}: subbots ${batch.join(', ')}`);

        await Promise.all(batch.map(async (num, idx) => {
            if (idx > 0) await sleep(BOT_DELAY * idx);
            try {
                await connectSubBot({ num, chatJid: null, conn: null });
                console.log(`[SubBot Independent] ✅ SubBot #${num} iniciado`);
            } catch (e) {
                console.error(`[SubBot Independent] ❌ Error iniciando #${num}:`, e.message);
            }
        }));

        if (i + PARALLEL < sortedNums.length) await sleep(BATCH_DELAY);
    }

    console.log(`[SubBot Independent] ✅ Arranque independiente completado (${sortedNums.length} subbots).`);
}

// ════════════════════════════════════════════════════════════════════════════
//  EXPORTS — todos los handlers en un solo archivo
// ════════════════════════════════════════════════════════════════════════════
module.exports = {
    // Handler principal (.serbot / .qr / .code)
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,

    // Sub-handlers extras exportados como objetos separados
    // El loader de plugins los registra si los encontrás en module.exports
    reconnect:           reconnectHandler,
    listBots:            listBotsHandler,

    // Funciones internas usadas por otros módulos
    autoReconnectSubBots,
    startSubBotsIndependent,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    connectSubBot,        // exportado para uso externo si hiciera falta
    activeSocks,
    getSubBotNumberByOwner,
};