'use strict';


const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Identificador del grupo oficial usado para comandos específicos.
const OFFICIAL_GROUP = '120363203689229697@g.us';

const retryMap    = new Map();
const activeSocks = new Map();

// ── Caché de grupos donde está el bot principal ───────────────────────────────
// Los subbots NO responden en grupos donde el bot principal también está presente.
// Se actualiza cada 5 minutos para no hacer llamadas en cada mensaje.
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000; // 5 minutos

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) {
                    mainBotGroupsCache.add(jid);
                }
            }
        } catch (e) {
            // Si falla, usar la caché anterior
        }
    }
    return mainBotGroupsCache.has(groupJid);
}
const pendingQR   = new Set(); // JIDs con QR/código pendiente
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Sigue el canal público de WhatsApp sin unir el bot al grupo oficial.
 */
async function followPublicChannel(sock, botLabel = 'Bot') {
    // Solo seguir el canal público de WhatsApp; no unirse al grupo oficial.
    await sleep(3000);

    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        
        if (inviteCode) {
            console.log(`[${botLabel}] 🔍 Buscando ID para el canal público...`);
            
            // Obtiene los metadatos usando el código de invitación
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            
            if (metadata && metadata.id) {
                const channelJid = metadata.id;
                console.log(`[${botLabel}] 🆔 ID detectado: ${channelJid}`);

                // El subbot sigue al canal de WhatsApp
                await sock.newsletterFollow(channelJid);
                console.log(`[${botLabel}] ✅ Bot siguiendo el canal exitosamente.`);
            }
        }
    } catch (error) {
        if (error.message?.includes('unexpected response structure')) {
            console.log(`[${botLabel}] ✅ Bot ya sigue el canal (confirmado).`);
        } else {
            console.error(`[${botLabel}] ❌ Error real al seguir el canal:`, error.message);
        }
    }

    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) { 
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}


function sessionPath(phoneOrNum) {
    // Si ya es un número de teléfono largo (>6 dígitos), usarlo directamente
    // Si es un número secuencial corto (<= 6), buscar el .db correspondiente
    return path.join(SESSIONS_DIR, `${phoneOrNum}.db`);
}

// Ya no se usa número secuencial: el nombre del .db es el número de teléfono.
// Esta función queda por compatibilidad pero ahora devuelve el phoneNumber limpio.
function nextSubBotNumber() {
    // Se reemplaza por phoneNumber en connectSubBot; retorna null para indicar
    // que hay que esperar el número real del celular al momento de conectar.
    return null;
}

// Devuelve el phoneNumber (nombre del .db sin extensión) del subbot de ese owner
function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];

    // Primero: buscar si ya existe un .db con ese mismo número de teléfono como nombre
    const directDb = path.join(SESSIONS_DIR, `${ownerNum}.db`);
    if (fs.existsSync(directDb)) return ownerNum;

    // Fallback: buscar en todos los .db con nombre numérico (legacy) o nombre de teléfono
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return storedNum || file.replace('.db', '');
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    // `num` puede ser:
    //   - Un número de teléfono real (ej: "59893900470")  → lo usamos como nombre del .db
    //   - null/undefined                                   → usamos phoneNumber, o temp hasta conectar
    // El nombre canónico del .db siempre es el número de teléfono real del bot.

    // Determinar nombre y archivo .db a usar
    // Si ya conocemos el phone (pairing code), úsalo como nombre desde el inicio
    let name   = phoneNumber ? String(phoneNumber).replace(/[^0-9]/g, '') : (num ? String(num) : null);
    let dbFile = name ? sessionPath(name) : null;

    // Leer ownerJid y phoneNumber desde el .db si existe
    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;
    if (dbFile && fs.existsSync(dbFile)) {
        try {
            const Database = require('better-sqlite3');
            const _db = new Database(dbFile, { readonly: true });
            const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            _db.close();
            if (row) {
                const data = JSON.parse(row.value);
                if (!ownerJid) ownerJid = data.ownerJid;
                if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                // Si el nombre actual no coincide con el phoneNumber guardado, corregir
                if (data.phoneNumber) {
                    const correctName = String(data.phoneNumber).replace(/[^0-9]/g, '');
                    if (correctName && correctName !== name) {
                        const correctDb = sessionPath(correctName);
                        if (!fs.existsSync(correctDb)) {
                            try { fs.renameSync(dbFile, correctDb); } catch {}
                        }
                        name   = correctName;
                        dbFile = correctDb;
                    }
                }
            }
        } catch {}
    }

    // Si aún no tenemos nombre (QR sin phone conocido), usar un placeholder temporal
    // que se renombrará al conectar con el número real
    if (!name) {
        // Usar timestamp para evitar colisiones entre sesiones simultáneas
        name   = `_tmp_${Date.now()}`;
        dbFile = sessionPath(name);
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    // Si se pasa token (creds en base64), inicializar el .db con esas creds
    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            const Database = require('better-sqlite3');
            const { BufferJSON } = require('@whiskeysockets/baileys');
            const _db = new Database(dbFile);
            _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('creds', JSON.stringify(decoded, BufferJSON.replacer));
            _db.close();
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    const socketConfig = {
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        browser: ['Ubuntu', 'Chrome', '22.04'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        maxMsgRetryCount: 3,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 30000,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        fireInitQueries: true,
        emitOwnEvents: false,
        getMessage: async () => undefined
    };

    const sock = makeWASocket(socketConfig);

    // 🛡️ Wrapper seguro para groupMetadata con retry
    const originalGroupMetadata = sock.groupMetadata.bind(sock);
    const MAX_RETRIES = 2;

    sock.groupMetadata = async (jid, retryCount = 0) => {
        try {
            return await originalGroupMetadata(jid);
        } catch (error) {
            const errorCode = error?.data || error?.output?.statusCode;
            if (errorCode !== 403) throw error;

            if (retryCount < MAX_RETRIES) {
                await new Promise(r => setTimeout(r, 1000 * (retryCount + 1)));
                return sock.groupMetadata(jid, retryCount + 1);
            }

            throw error;
        }
    };

    sock._subName  = name;
    sock._subNum   = name;   // el "número" ahora es el teléfono (string)
    sock._sessDb   = dbFile;
    sock._ownerJid = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber = phoneNumber;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrSent              = false;
    let qrTimeout           = null;
    let connected           = false;
    let codeSent            = false;
    let pairingCodeRequested = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // ── Flujo PAIRING CODE ──────────────────────────────────────────────
        // Esperar el evento QR — indica que el WS completó el handshake y está
        // listo para recibir requestPairingCode. "connecting" es demasiado temprano.
        if (usePairingCode && phoneNumber && !!qr && !pairingCodeRequested && !connected && !state.creds.registered) {
            pairingCodeRequested = true;
            console.log(`[SubBot] Solicitando código para ${name} (${phoneNumber})...`);

            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);

                if (!code) {
                    throw new Error('No se recibió código de emparejamiento');
                }

                codeSent = true;
                console.log(`[SubBot] ✅ Código para ${name}: ${code}`);

                if (chatJid) {
                    await sock.sendMessage(chatJid, {
                        text: `🔐 *Código de emparejamiento para el sub-bot*\n\n` +
                              `_Ingresa este código en:_\n` +
                              `WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n` +
                              `⏱️ Tienes 90 segundos para ingresarlo.`
                    });
                    await sock.sendMessage(chatJid, { text: code });
                }

                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, code);
                } catch (e) {
                    console.error('[SubBot] Error enviando código al servidor web:', e.message);
                }

                qrTimeout = setTimeout(() => {
                    if (!connected) {
                        console.log(`[SubBot] Timeout esperando vinculación con código para bot ${name}`);
                        if (ownerJid) pendingQR.delete(ownerJid);
                        activeSocks.delete(name);
                        try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                        // Borrar .db solo si la sesión no quedó registrada (sin creds válidas)
                        if (fs.existsSync(dbFile)) {
                            try {
                                const Database = require('better-sqlite3');
                                const _db = new Database(dbFile, { readonly: true });
                                const row = _db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
                                _db.close();
                                if (!row) fs.unlinkSync(dbFile);
                            } catch { try { fs.unlinkSync(dbFile); } catch {} }
                        }
                        if (chatJid) {
                            sock.sendMessage(chatJid, { text: `⏰ Código expirado. Genera uno nuevo con \`.serbot code ${phoneNumber}\`.` }).catch(() => {});
                        }
                    }
                }, 90000);

            } catch (e) {
                console.error('[SubBot] Error solicitando código de emparejamiento:', e.message);
                if (ownerJid) pendingQR.delete(ownerJid);
                if (chatJid) {
                    sock.sendMessage(chatJid, { text: '❌ Error generando código: ' + e.message }).catch(() => {});
                }
                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, null);
                } catch {}
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }

            // No mostrar el QR visualmente cuando estamos en modo pairing code
            return;
        }

        // ── Flujo QR normal ─────────────────────────────────────────────────
        if (qr) {
            if (connected) return;
            if (qrSent) {
                // Segundo QR = el primero expiró sin escanear
                console.log(`[SubBot] QR expirado para bot ${name}`);
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                if (!connected && fs.existsSync(dbFile)) {
                    try {
                        const Database = require('better-sqlite3');
                        const _db = new Database(dbFile, { readonly: true });
                        const row = _db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
                        _db.close();
                        if (!row) fs.unlinkSync(dbFile);
                    } catch { try { fs.unlinkSync(dbFile); } catch {} }
                }
                if (ownerJid) sock.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    await sock.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                    qrSent = true;
                }
                // Entregar QR al servidor web si hay alguien esperando
                try {
                    const { resolveWebQR } = require('../../subbotServer');
                    const dataUrl = await qrcode.toDataURL(qr);
                    resolveWebQR(num, dataUrl);
                } catch {}
                // Timeout de seguridad por si el segundo QR no llega
                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    // Borrar .db solo si no tiene owner guardado (sesión incompleta)
                    if (fs.existsSync(dbFile)) {
                        try {
                            const Database = require('better-sqlite3');
                            const _db = new Database(dbFile, { readonly: true });
                            const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                            _db.close();
                            if (!row) fs.unlinkSync(dbFile);
                        } catch { try { fs.unlinkSync(dbFile); } catch {} }
                    }
                    if (ownerJid) sock.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                }, 35000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        // ── Conexión exitosa ─────────────────────────────────────────────────
        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);

            // Obtener el número de teléfono real del bot recién conectado
            const realPhone = sock.user?.id?.split('@')[0]?.split(':')[0] || null;
            const finalPhoneNum = (storedPhoneNumber || realPhone || '').replace(/[^0-9]/g, '');

            // Renombrar .db al número real si el nombre actual es un placeholder o distinto
            if (finalPhoneNum && finalPhoneNum !== name) {
                const finalDb = sessionPath(finalPhoneNum);
                if (!fs.existsSync(finalDb)) {
                    try { fs.renameSync(dbFile, finalDb); } catch (e) {
                        console.error(`[SubBot] Error renombrando .db a ${finalPhoneNum}.db:`, e.message);
                    }
                }
                // Actualizar variables locales y propiedades del socket
                activeSocks.delete(name);
                name   = finalPhoneNum;   // ← nuevo nombre canónico
                sock._subName = name;
                sock._subNum  = name;
                sock._sessDb  = finalDb;
            }
            activeSocks.set(name, sock);

            // Guardar owner Y phoneNumber dentro del .db (con nombre ya correcto)
            const currentDbFile = sock._sessDb || sessionPath(name);
            try {
                const Database = require('better-sqlite3');
                const _db = new Database(currentDbFile);
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    phoneNumber: finalPhoneNum || realPhone
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch (e) { console.error(`[SubBot] Error guardando owner en .db:`, e.message); }

            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot ${finalPhoneNum || name} conectado`);
            setTimeout(() => followPublicChannel(sock, `SubBot ${finalPhoneNum || name}`), 3000);
        }

        // ── Desconexión ──────────────────────────────────────────────────────
        if (connection === 'close') {
            const currentSock = activeSocks.get(name);
            if (currentSock && currentSock !== sock) {
                console.log(`[SubBot] Ignorando cierre de socket obsoleto para bot ${name}`);
                return;
            }

            const code     = lastDisconnect?.error?.output?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || 'desconocido';
            console.log(`[SubBot] Bot ${name} desconectado, código: ${code}, error: ${errorMsg}`);
            console.log(`[SubBot] usePairingCode: ${usePairingCode}, codeSent: ${codeSent}, connected: ${connected}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            
            // 🧹 Limpiar intervalos para evitar memory leaks
            if (sock._cacheCleanupInterval) {
                clearInterval(sock._cacheCleanupInterval);
                sock._cacheCleanupInterval = null;
            }
            // 🧹 Limpiar todos los event listeners
            try { sock.ev.removeAllListeners(); } catch {}

            // Restart requerido
            if (code === 515) {
                console.log(`[SubBot] Reconectando bot ${name} (código 515)...`);
                setTimeout(() => connectSubBot({ num: name, chatJid: ownerJid, conn }), 2000);
                return;
            }

            // 401/428 después de enviar código = proceso normal de Baileys, reconectar sin pairing
            if (usePairingCode && codeSent && !connected && (code === 401 || code === 428)) {
                console.log(`[SubBot] Bot ${name} recibió ${code} post-código, reconectando para completar vinculación...`);
                setTimeout(() => connectSubBot({ num: name, chatJid: ownerJid, conn, usePairingCode: false }), 3000);
                return;
            }

            if (code === 401 || code === 403 || code === 405) {
                if (usePairingCode && codeSent && !connected) {
                    console.log(`[SubBot] Bot ${name} esperando vinculación con código...`);
                    return;
                }
                try { 
                    const currentDb = sock._sessDb || sessionPath(name);
                    if (fs.existsSync(currentDb)) {
                        fs.unlinkSync(currentDb);
                    }
                } catch {}
                if (ownerJid) sock.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot cerrada. Usa \.serbot para reconectar.` }).catch(() => {});
                return;
            }

            if (code === DisconnectReason.loggedOut) {
                try { 
                    const currentDb = sock._sessDb || sessionPath(name);
                    if (fs.existsSync(currentDb)) {
                        fs.unlinkSync(currentDb);
                    }
                } catch {}
                if (ownerJid) sock.sendMessage(ownerJid, { text: `📴 Sub-bot cerró sesión. Usa \.serbot si quieres volver a conectarlo.` }).catch(() => {});
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 2000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot ${name} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num: name, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) sock.sendMessage(ownerJid, { text: `⛔ Sub-bot agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            // Ignorar mensajes anteriores al inicio del bot
            const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
            if (msgTs && global._botStartTime && msgTs < global._botStartTime) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            
            // 🧹 Limpieza periódica de IDs procesados
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) {
                    if (ts < cutoff) processedIds.delete(id);
                }
            }

            // ── Guardar mensaje en chat logger (grupos) ──────────────────────────
            // Chat logging removido

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            const msgChatJidEarly = baileyMessage.key.remoteJid;
            const isGroupMsgEarly = typeof msgChatJidEarly === 'string' && msgChatJidEarly.endsWith('@g.us');

            // Si fromMe=true, puede ser:
            //   A) Un mensaje que el subbot envió (remoteJid es el destinatario, participant vacío)
            //   B) Un mensaje que el DUEÑO del subbot envió desde su teléfono (sincronizado)
            // Solo ignorar caso A (mensajes que el propio bot envió sin prefijo).
            // Caso B (dueño usando comandos) debe procesarse normalmente.
            if (isFromMe) {
                // Sin prefijo → nunca es un comando, ignorar siempre
                if (!hasPrefix) continue;
                // Con prefijo en privado: solo ignorar si el chat es con el propio número del bot
                // (el bot se habló a sí mismo), no si es el dueño hablando con otro chat
                if (!isGroupMsgEarly) {
                    const botNum = sock.user?.id?.split('@')[0]?.split(':')[0];
                    const chatNum = msgChatJidEarly?.split('@')[0]?.split(':')[0];
                    // Si el chat remoto ES el propio bot → mensaje que el bot se envió a sí mismo, ignorar
                    if (botNum && chatNum && botNum === chatNum) continue;
                    // Si no, es el dueño enviando un comando desde su teléfono → procesar
                }
            }
            if (!msgText && !hasPrefix) continue;

            if (hasPrefix) {
                const _cmd = msgText.slice(1).split(' ')[0].toLowerCase();
                if (['bcbot','broadcastbot'].includes(_cmd)) continue;

                if (['botsonline','subbotsonline'].includes(_cmd)) {
                    console.log(`[Heartbeat] 🤖 SubBot ${name} activo (respuesta a botsonline)`);
                    continue;
                }
            }

            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            // Si es un grupo donde el bot principal también está, el subbot cede
            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            // ✅ Todos los bots responden libremente en cualquier grupo

            // ── Transcripción automática de audios/notas de voz ─────────────
            // Transcripción automática removida
            // ────────────────────────────────────────────────────────────────

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                // Guardar el socket en el mensaje para que los plugins puedan usarlo
                // directamente sin depender de global.conn (que puede ser pisado por
                // otro subbot concurrente mientras este await está en vuelo).
                compatibleMessage._sock  = sock;
                compatibleMessage._subNum = name;

                // NO mutar global.conn — causa condiciones de carrera cuando múltiples
                // subbots procesan mensajes en paralelo. Cada plugin debe usar
                // message._sock o message.reply() en lugar de global.conn.
                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
// ─── Migración automática: carpetas viejas → .db ─────────────────────────────
// Se ejecuta una sola vez al iniciar. Si encuentra carpetas numéricas (sesiones
// del formato viejo) las convierte a .db y borra la carpeta original.
async function migrarSesionesLegacy() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    let Database, BufferJSON;
    try {
        Database  = require('better-sqlite3');
        ({ BufferJSON } = require('@whiskeysockets/baileys'));
    } catch (e) {
        console.error('[SubBot] migrarSesiones: dependencia faltante:', e.message);
        return;
    }

    const KNOWN_TYPES = [
        'app-state-sync-key',
        'app-state-sync-version',
        'sender-key-memory',
        'sender-key',
        'pre-key',
        'session',
    ];

    // Carpetas numéricas = sesiones del formato viejo
    const carpetas = fs.readdirSync(SESSIONS_DIR)
        .filter(e => {
            const n = parseInt(e);
            if (isNaN(n) || String(n) !== e) return false;
            return fs.statSync(path.join(SESSIONS_DIR, e)).isDirectory();
        })
        .map(e => parseInt(e))
        .sort((a, b) => a - b);

    if (carpetas.length === 0) return;

    console.log(`[SubBot] 🔄 Migrando ${carpetas.length} sesión(es) legacy a .db: [${carpetas.join(', ')}]`);

    for (const num of carpetas) {
        const folderPath = path.join(SESSIONS_DIR, String(num));
        const destFile   = path.join(SESSIONS_DIR, `${num}.db`);
        const credsFile  = path.join(folderPath, 'creds.json');

        // Si ya existe el .db, solo borrar la carpeta vieja
        if (fs.existsSync(destFile)) {
            console.log(`[SubBot] [${num}] .db ya existe, borrando carpeta legacy...`);
            try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch {}
            continue;
        }

        if (!fs.existsSync(credsFile)) {
            console.log(`[SubBot] [${num}] Sin creds.json, borrando carpeta vacía...`);
            try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch {}
            continue;
        }

        try {
            const db      = new Database(destFile);
            db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            const stmtSet = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');

            const allFiles = fs.readdirSync(folderPath);
            let insertados = 0;

            const insertAll = db.transaction(() => {
                for (const file of allFiles) {
                    if (!file.endsWith('.json')) continue;
                    const filePath = path.join(folderPath, file);
                    if (!fs.statSync(filePath).isFile()) continue;

                    let content;
                    try {
                        content = JSON.parse(fs.readFileSync(filePath, 'utf-8'), BufferJSON.reviver);
                    } catch { continue; }

                    const nameNoExt = file.replace(/\.json$/, '');

                    if (nameNoExt === 'creds') {
                        stmtSet.run('creds', JSON.stringify(content, BufferJSON.replacer));
                        insertados++;
                        continue;
                    }
                    if (nameNoExt === 'owner') {
                        stmtSet.run('_owner', JSON.stringify(content));
                        insertados++;
                        continue;
                    }

                    let matched = false;
                    for (const type of KNOWN_TYPES) {
                        if (nameNoExt.startsWith(type + '-')) {
                            const id = nameNoExt.slice(type.length + 1);
                            stmtSet.run(`${type}-${id}`, JSON.stringify(content, BufferJSON.replacer));
                            insertados++;
                            matched = true;
                            break;
                        }
                    }
                    if (!matched) {
                        stmtSet.run(nameNoExt, JSON.stringify(content, BufferJSON.replacer));
                        insertados++;
                    }
                }
            });

            insertAll();
            db.close();

            // Borrar carpeta original solo si el .db se creó correctamente
            fs.rmSync(folderPath, { recursive: true, force: true });
            console.log(`[SubBot] ✅ [${num}] Migrado (${insertados} entradas → ${num}.db)`);

        } catch (err) {
            console.error(`[SubBot] ❌ [${num}] Error migrando:`, err.message);
            // Si el .db quedó a medias, borrarlo para no dejar basura
            try { if (fs.existsSync(destFile)) fs.unlinkSync(destFile); } catch {}
        }
    }
}

// ─── Renombrar .db secuenciales al número de teléfono real ───────────────────
// Busca archivos como 1.db, 2.db, 3.db que tengan phoneNumber guardado en _owner
// y los renombra a <phoneNumber>.db. Se ejecuta al inicio, antes de reconectar.
async function renameSeqDbsToPhone() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    let Database;
    try { Database = require('better-sqlite3'); } catch { return; }

    const files = fs.readdirSync(SESSIONS_DIR);
    for (const file of files) {
        // Solo archivos con nombre corto (1-6 dígitos) → son los secuenciales
        const m = file.match(/^(\d{1,6})\.db$/);
        if (!m) continue;

        const seqPath = path.join(SESSIONS_DIR, file);
        let phoneNumber = null;

        try {
            const db = new Database(seqPath, { readonly: true });
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (row) {
                const data = JSON.parse(row.value);
                phoneNumber = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            }
        } catch { continue; }

        if (!phoneNumber || phoneNumber.length < 7) continue;

        const newPath = path.join(SESSIONS_DIR, `${phoneNumber}.db`);
        if (fs.existsSync(newPath)) {
            // Ya existe el .db con nombre de teléfono; borrar el secuencial duplicado
            console.log(`[SubBot] 🗑️ Eliminando secuencial duplicado: ${file} (ya existe ${phoneNumber}.db)`);
            try { fs.unlinkSync(seqPath); } catch {}
        } else {
            try {
                fs.renameSync(seqPath, newPath);
                console.log(`[SubBot] ✅ Renombrado ${file} → ${phoneNumber}.db`);
            } catch (e) {
                console.error(`[SubBot] ❌ Error renombrando ${file} → ${phoneNumber}.db:`, e.message);
            }
        }
    }
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    // Migrar sesiones legacy (carpetas → .db) antes de reconectar
    await migrarSesionesLegacy();

    // Renombrar .db secuenciales (1.db, 2.db…) al número de teléfono real
    await renameSeqDbsToPhone();

    // Leer todos los .db con nombre numérico (incluye los de teléfono como 59893900470.db)
    const dbNames = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? m[1] : null; })
        .filter(n => n !== null)
        .sort();

    const maxPasses = 2;
    const failed = [];

    for (let pass = 1; pass <= maxPasses; pass++) {
        for (const dbName of dbNames) {
            const dbFile = path.join(SESSIONS_DIR, `${dbName}.db`);
            if (!fs.existsSync(dbFile)) continue;
            if (activeSocks.has(dbName)) continue;
            if (global.subConns.find(c => c._subName === dbName && c.user)) continue;

            console.log(`[SubBot] Auto-reconectando bot ${dbName} (pasada ${pass}/${maxPasses})...`);
            await sleep(2000);
            await connectSubBot({ num: dbName, chatJid: null, conn })
                .catch(e => {
                    console.error(`[SubBot] Error auto-reconexión ${dbName}:`, e.message);
                });
        }

        if (pass < maxPasses) {
            await sleep(5000);
        }
    }

    for (const dbName of dbNames) {
        if (!activeSocks.has(dbName) && !global.subConns.find(c => c._subName === dbName && c.user)) {
            failed.push(dbName);
        }
    }

    if (failed.length > 0) {
        console.warn(`[SubBot] No se pudieron reconectar automáticamente los subbots: ${failed.join(', ')}`);
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .serbot code <numero_internacional>',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        const helpText =
            `📌 *Cómo usar .serbot*\n\n` +
            `✅ *Opción 1 (QR):*\n` +
            `- Usa: \`.serbot qr\`\n` +
            `- *Necesitas otro dispositivo* (o una PC) donde se muestre el QR para poder escanearlo.\n` +
            `- En WhatsApp: *Dispositivos vinculados* → *Vincular un dispositivo* → escanea el QR.\n\n` +
            `✅ *Opción 2 (CODE):*\n` +
            `- Usa: \`.serbot code <numero>\`\n` +
            `- *No necesitas otro dispositivo*.\n` +
            `- El número debe ir en *formato internacional*\n` +
            `  Ejemplos:\n` +
            `  - \`.serbot code 59893900470\`\n` +
            `  - \`.serbot code +598 93 900 470\` (también sirve)\n\n` +
            `ℹ️ *¿No sabés tu número en formato internacional?*\n` +
            `Usa \`.numwa <país> <tu número>\` y el bot te lo devuelve listo para copiar.\n` +
            `Ejemplos:\n` +
            `- \`.numwa uruguay 093900470\`\n` +
            `- \`.numwa argentina 01123456789\`\n` +
            `- \`.numwa mexico 5512345678\`\n` +
            `- \`.numwa españa 612345678\`\n`;

        if (message.isGroup) {
            return sock.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // Subcomandos: .serbot qr | .serbot code <numero>
        // Unir todos los args y limpiar para manejar espacios extras
        const allArgs = (args || []).filter(a => a.trim() !== '');
        const arg0 = (allArgs[0] || '').trim().toLowerCase();

        let usePairingCode = false;
        let phoneNumber    = null;
        let token          = null;

        if (arg0 === 'qr') {
            // .serbot qr → forzar QR
            usePairingCode = false;
        } else if (arg0 === 'code') {
            // .serbot code <numero> — acepta +598 939 004 70, 598-939-004-70, etc.
            const rawNumber = allArgs.slice(1).join(''); // unir todo lo que sigue, ignorando espacios
            const cleanedNumber = rawNumber.replace(/[^0-9]/g, '');
            if (!cleanedNumber || cleanedNumber.length < 7 || cleanedNumber.length > 15) {
                return sock.sendMessage(message.from, {
                    text: `❌ Debes indicar el número en formato internacional.\n\n${helpText}`
                }, { quoted: message._baileyMessage });
            }
            usePairingCode = true;
            phoneNumber    = cleanedNumber;
        } else {
            // NO aceptar: .serbot | .serbot <numero> | cualquier cosa distinta de "qr" o "code <numero>"
            return sock.sendMessage(message.from, { text: helpText }, { quoted: message._baileyMessage });
        }

        if (pendingQR.has(senderJid)) {
            return sock.sendMessage(message.from, {
                text: `⏳ Ya tienes un proceso pendiente. Espera a que expire para generar uno nuevo.`
            }, { quoted: message._baileyMessage });
        }

        // Verificar si el NÚMERO que se va a vincular ya tiene un subbot activo
        // (no el JID de quien ejecuta el comando)
        const targetNumber = usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0];
        const targetJid = `${targetNumber}@s.whatsapp.net`;
        
        const existingNum = getSubBotNumberByOwner(targetJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subName === existingNum && c.user);
            if (alreadyActive) {
                return sock.sendMessage(message.from, {
                    text: usePairingCode
                        ? `ℹ️ El número *${phoneNumber}* ya tiene un sub-bot activo.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                        : `ℹ️ Ya tienes un sub-bot activo.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                }, { quoted: message._baileyMessage });
            }
            pendingQR.add(senderJid);
            sock.sendMessage(message.from, {
                text: usePairingCode
                    ? `⏳ Generando código para reconectar el sub-bot con el número *${phoneNumber}*...`
                    : `⏳ Reconectando tu sub-bot con QR...`
            }, { quoted: message._baileyMessage });
            try {
                await connectSubBot({ num: existingNum, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
            } catch (e) {
                pendingQR.delete(senderJid);
                console.error('[SubBot] Error reconectando sub-bot existente:', e.message || e);
                return sock.sendMessage(message.from, {
                    text: `❌ Error reconectando sub-bot: ${e.message || 'Error desconocido'}`
                }, { quoted: message._baileyMessage });
            }
            return;
        }

        // Para QR sin número conocido, usar null; se nombrará al conectar
        const num = usePairingCode ? phoneNumber : null;

        pendingQR.add(senderJid);
        sock.sendMessage(message.from, {
            text: usePairingCode
                ? `⏳ Generando código de emparejamiento para el número *${phoneNumber}*...\n\n_En unos segundos recibirás el código de 8 dígitos._`
                : token
                    ? `⏳ Restaurando sesión como sub-bot...`
                    : `⏳ Generando QR para conectar tu sub-bot...`
        }, { quoted: message._baileyMessage });

        try {
            await connectSubBot({ num, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
        } catch (e) {
            pendingQR.delete(senderJid);
            console.error('[SubBot] Error iniciando sub-bot:', e.message || e);
            return sock.sendMessage(message.from, {
                text: `❌ Error iniciando sub-bot: ${e.message || 'Error desconocido'}`
            }, { quoted: message._baileyMessage });
        }
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const sock = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => String(a._subName).localeCompare(String(b._subName)));
        const lines  = [];

        if (conn?.user) {
            const mainPhoneNum = conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        if (active.length > 0) {
            lines.push(`🤖 *SubBots Activos: ${active.length}*`);
            for (const c of active) {
                const phoneNum = c.user.id.split('@')[0].split(':')[0];
                lines.push(`📱 wa.me/+${phoneNum}`);
            }
        }

        if (lines.length === 0) {
            return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' }, { quoted: message._baileyMessage });
        }

        sock.sendMessage(message.from, {
            text: `${lines.join('\n\n')}\n\n━━━━━━━━━━━━━━━━━━━━\n_Usa .gruposbots para ver los grupos_`
        }, { quoted: message._baileyMessage });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    help: 'Ver qué bots están activos (solo en el grupo oficial)',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const officialGroupJid = OFFICIAL_GROUP;
        if (message.from !== officialGroupJid) return;

        const sock = message._sock || global.conn;
        await sock.sendMessage(officialGroupJid, {
            text: '🟢 *Bot principal activo* ✅'
        }, { quoted: message._baileyMessage });

        const active = global.subConns.filter(c => c.user).sort((a, b) => String(a._subName).localeCompare(String(b._subName)));
        for (const subSock of active) {
            await sleep(800);
            try {
                const phoneNum = subSock.user?.id?.split('@')[0]?.split(':')[0] || subSock._subName;
                await subSock.sendMessage(officialGroupJid, {
                    text: `🤖 *SubBot ${phoneNum}* está activo ✅`
                });
            } catch (e) {
                console.error(`[SubBot] Error respuesta botsonline ${subSock._subName}:`, e.message);
            }
        }
    }
};

/** Versión para el servidor web: genera QR */
async function connectSubBotWeb({ num, conn }) {
    // num puede ser un nombre de .db ya existente (phone) o null para nuevo
    return connectSubBot({ num: num || null, chatJid: null, conn });
}

/** Versión para el servidor web: genera código de emparejamiento */
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) {
    return connectSubBot({ num: phoneNumber || num || null, chatJid: null, conn, usePairingCode: true, phoneNumber });
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    listBots:            listBotsHandler,
};