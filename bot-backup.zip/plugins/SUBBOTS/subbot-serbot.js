'use strict';
/**
 * Plugin de Sub-Bots (numerados automáticamente)
 *
 * .serbot              → Crear sub-bot con QR
 * .serbot 59891234567  → Crear sub-bot con código de emparejamiento
 * .bots / .subbots / .listbots → Ver sub-bots activos
 * .bcbot               → Difundir mensaje (owner)
 *
 * Para eliminar: ir a Dispositivos Vinculados en WhatsApp y cerrar sesión.
 * ✅ SIN SISTEMA DE PRIORIDAD: Todos los bots responden libremente en grupos
 */

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Grupo oficial donde todos los subbots deben estar
const OFFICIAL_GROUP = '120363203689229697@g.us';

const retryMap    = new Map();
const activeSocks = new Map();

// ── Caché de grupos donde está el bot principal ───────────────────────────────
// Los subbots NO responden en grupos donde el bot principal también está presente.
// Se actualiza cada 5 minutos para no hacer llamadas en cada mensaje.
const mainBotGroupsCache = new Set();
let mainBotGroupsCacheTime = 0;
const MAIN_BOT_GROUPS_TTL = 5 * 60 * 1000; // 5 minutos

async function isMainBotInGroup(groupJid) {
    const now = Date.now();
    if (now - mainBotGroupsCacheTime > MAIN_BOT_GROUPS_TTL) {
        mainBotGroupsCacheTime = now;
        try {
            if (global.conn?.user) {
                const chats = await global.conn.groupFetchAllParticipating();
                mainBotGroupsCache.clear();
                for (const jid of Object.keys(chats)) {
                    mainBotGroupsCache.add(jid);
                }
            }
        } catch (e) {
            // Si falla, usar la caché anterior
        }
    }
    return mainBotGroupsCache.has(groupJid);
}
const pendingQR   = new Set(); // JIDs con QR/código pendiente
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Intenta unir un bot (oficial o subbot) al grupo oficial y al canal
 */
async function joinOfficialGroup(sock, botLabel = 'Bot') {
    let yaEnGrupo = false;

    // 1. INTENTAR UNIR AL GRUPO OFICIAL
    try {
        const groupJid = OFFICIAL_GROUP;
        try {
            const groupMeta = await sock.groupMetadata(groupJid);
            if (groupMeta) {
                console.log(`[${botLabel}] Ya está en el grupo oficial`);
                yaEnGrupo = true;
            }
        } catch (e) {
            // No está en el grupo, continúa el flujo para unirse
        }

        if (!yaEnGrupo) {
            await sock.groupAcceptInvite('HaDX5l2tQCz9KJ7lyw7VHv');
            console.log(`[${botLabel}] ✅ Unido al grupo oficial`);
        }
    } catch (error) {
        console.error(`[${botLabel}] Error uniéndose al grupo:`, error.message);
    }

    // ESPERAR 3 SEGUNDOS ANTES DE PASAR AL CANAL
    await sleep(3000);

    // 2. INTENTAR SEGUIR EL CANAL DE WHATSAPP
    try {
        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
        const inviteCode = channelUrl.split('/').pop();
        
        if (inviteCode) {
            console.log(`[${botLabel}] 🔍 Buscando ID para el canal público...`);
            
            // Obtiene los metadatos usando el código de invitación
            const metadata = await sock.newsletterMetadata('invite', inviteCode);
            
            if (metadata && metadata.id) {
                const channelJid = metadata.id;
                console.log(`[${botLabel}] 🆔 ID detectado: ${channelJid}`);

                // El subbot sigue al canal de WhatsApp
                await sock.newsletterFollow(channelJid);
                console.log(`[${botLabel}] ✅ Bot siguiendo el canal exitosamente.`);
            }
        }
    } catch (error) {
        // Filtrar el falso error de Baileys v7 si la suscripción ya existe o es exitosa
        if (error.message?.includes('unexpected response structure')) {
            console.log(`[${botLabel}] ✅ Bot ya sigue el canal (confirmado).`);
        } else {
            // Mostrar en la terminal si se trata de un problema real diferente
            console.error(`[${botLabel}] ❌ Error real al seguir el canal:`, error.message);
        }
    }

    return true;
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) { 
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}


function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
    let n = 1;
    while (existing.includes(n)) n++;
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            // Comparar por el phoneNumber guardado (el número que se vinculó)
            // NO por ownerJid (quien ejecutó el comando)
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null }) {
    const name    = String(num);
    const dbFile  = sessionPath(num);  // sesiones/1.db

    // Leer ownerJid y phoneNumber desde el .db si existe
    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;
    if (fs.existsSync(dbFile)) {
        try {
            const Database = require('better-sqlite3');
            const _db = new Database(dbFile, { readonly: true });
            const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            _db.close();
            if (row) {
                const data = JSON.parse(row.value);
                if (!ownerJid) ownerJid = data.ownerJid;
                if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    // Si se pasa token (creds en base64), inicializar el .db con esas creds
    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            const Database = require('better-sqlite3');
            const { BufferJSON } = require('@whiskeysockets/baileys');
            const _db = new Database(dbFile);
            _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('creds', JSON.stringify(decoded, BufferJSON.replacer));
            _db.close();
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useSQLiteAuthState(dbFile);
    const version              = await getBaileysVersion();

    const socketConfig = {
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        browser: ['Ubuntu', 'Chrome', '22.04'],
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        maxMsgRetryCount: 3,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 30000,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        fireInitQueries: true,
        emitOwnEvents: false,
        getMessage: async () => undefined
    };

    const sock = makeWASocket(socketConfig);

    // 🛡️ Wrapper seguro para groupMetadata con retry
    const originalGroupMetadata = sock.groupMetadata.bind(sock);
    const MAX_RETRIES = 2;

    sock.groupMetadata = async (jid, retryCount = 0) => {
        try {
            return await originalGroupMetadata(jid);
        } catch (error) {
            const errorCode = error?.data || error?.output?.statusCode;
            if (errorCode !== 403) throw error;

            if (retryCount < MAX_RETRIES) {
                await new Promise(r => setTimeout(r, 1000 * (retryCount + 1)));
                return sock.groupMetadata(jid, retryCount + 1);
            }

            throw error;
        }
    };

    sock._subName  = name;
    sock._subNum   = num;
    sock._sessDb   = dbFile;
    sock._ownerJid = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber = phoneNumber;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrSent              = false;
    let qrTimeout           = null;
    let connected           = false;
    let codeSent            = false;
    let pairingCodeRequested = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // ── Flujo PAIRING CODE ──────────────────────────────────────────────
        // Esperar el evento QR — indica que el WS completó el handshake y está
        // listo para recibir requestPairingCode. "connecting" es demasiado temprano.
        if (usePairingCode && phoneNumber && !!qr && !pairingCodeRequested && !connected && !state.creds.registered) {
            pairingCodeRequested = true;
            console.log(`[SubBot] Solicitando código para #${num} (${phoneNumber})...`);

            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(cleanPhone);

                codeSent = true;
                console.log(`[SubBot] ✅ Código para #${num}: ${code}`);

                if (chatJid) {
                    await conn.sendMessage(chatJid, {
                        text: `🔐 *Código de emparejamiento para sub-bot #${num}*\n\n` +
                              `_Ingresa este código en:_\n` +
                              `WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n` +
                              `⏱️ Tienes 90 segundos para ingresarlo.`
                    });
                    await conn.sendMessage(chatJid, { text: code });
                }

                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, code);
                } catch (e) {
                    console.error('[SubBot] Error enviando código al servidor web:', e.message);
                }

                qrTimeout = setTimeout(() => {
                    if (!connected) {
                        console.log(`[SubBot] Timeout esperando vinculación con código para bot #${num}`);
                        if (ownerJid) pendingQR.delete(ownerJid);
                        activeSocks.delete(name);
                        try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                        // Borrar .db solo si la sesión no quedó registrada (sin creds válidas)
                        if (fs.existsSync(dbFile)) {
                            try {
                                const Database = require('better-sqlite3');
                                const _db = new Database(dbFile, { readonly: true });
                                const row = _db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
                                _db.close();
                                if (!row) fs.unlinkSync(dbFile);
                            } catch { try { fs.unlinkSync(dbFile); } catch {} }
                        }
                        if (chatJid) {
                            conn.sendMessage(chatJid, { text: `⏰ Código expirado. Genera uno nuevo con \`.serbot code ${phoneNumber}\`.` }).catch(() => {});
                        }
                    }
                }, 90000);

            } catch (e) {
                console.error('[SubBot] Error solicitando código de emparejamiento:', e.message);
                if (ownerJid) pendingQR.delete(ownerJid);
                if (chatJid) {
                    conn.sendMessage(chatJid, { text: '❌ Error generando código: ' + e.message }).catch(() => {});
                }
                try {
                    const { resolveWebCode } = require('../../subbotServer');
                    resolveWebCode(num, null);
                } catch {}
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
            }

            // No mostrar el QR visualmente cuando estamos en modo pairing code
            return;
        }

        // ── Flujo QR normal ─────────────────────────────────────────────────
        if (qr) {
            if (connected) return;
            if (qrSent) {
                // Segundo QR = el primero expiró sin escanear
                console.log(`[SubBot] QR expirado para bot #${num}`);
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                if (!connected && fs.existsSync(dbFile)) {
                    try {
                        const Database = require('better-sqlite3');
                        const _db = new Database(dbFile, { readonly: true });
                        const row = _db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
                        _db.close();
                        if (!row) fs.unlinkSync(dbFile);
                    } catch { try { fs.unlinkSync(dbFile); } catch {} }
                }
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    await conn.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot #${num}*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                    qrSent = true;
                }
                // Entregar QR al servidor web si hay alguien esperando
                try {
                    const { resolveWebQR } = require('../../subbotServer');
                    const dataUrl = await qrcode.toDataURL(qr);
                    resolveWebQR(num, dataUrl);
                } catch {}
                // Timeout de seguridad por si el segundo QR no llega
                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    // Borrar .db solo si no tiene owner guardado (sesión incompleta)
                    if (fs.existsSync(dbFile)) {
                        try {
                            const Database = require('better-sqlite3');
                            const _db = new Database(dbFile, { readonly: true });
                            const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                            _db.close();
                            if (!row) fs.unlinkSync(dbFile);
                        } catch { try { fs.unlinkSync(dbFile); } catch {} }
                    }
                    if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                }, 35000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        // ── Conexión exitosa ─────────────────────────────────────────────────
        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);
            // Guardar owner Y phoneNumber dentro del .db
            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                _db.close();
            } catch (e) { console.error(`[SubBot] Error guardando owner en .db:`, e.message); }
            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            setTimeout(() => joinOfficialGroup(sock, `SubBot #${num}`), 3000);
            // sendPresenceUpdate eliminado: Baileys ya mantiene la presencia
            // activa internamente via keepAliveIntervalMs (30s). Llamarlo
            // manualmente cada 60s generaba peticiones extra innecesarias a WA.
        }

        // ── Desconexión ──────────────────────────────────────────────────────
        if (connection === 'close') {
            const code     = lastDisconnect?.error?.output?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || 'desconocido';
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}, error: ${errorMsg}`);
            console.log(`[SubBot] usePairingCode: ${usePairingCode}, codeSent: ${codeSent}, connected: ${connected}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            
            // 🧹 Limpiar intervalos para evitar memory leaks
            if (sock._cacheCleanupInterval) {
                clearInterval(sock._cacheCleanupInterval);
                sock._cacheCleanupInterval = null;
            }
            // 🧹 Limpiar todos los event listeners
            try { sock.ev.removeAllListeners(); } catch {}

            // Restart requerido
            if (code === 515) {
                console.log(`[SubBot] Reconectando bot #${num} (código 515)...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), 2000);
                return;
            }

            // 401/428 después de enviar código = proceso normal de Baileys, reconectar sin pairing
            if (usePairingCode && codeSent && !connected && (code === 401 || code === 428)) {
                console.log(`[SubBot] Bot #${num} recibió ${code} post-código, reconectando para completar vinculación...`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn, usePairingCode: false }), 3000);
                return;
            }

            if (code === 401 || code === 403 || code === 405) {
                if (usePairingCode && codeSent && !connected) {
                    console.log(`[SubBot] Bot #${num} esperando vinculación con código...`);
                    return;
                }
                try { 
                    if (fs.existsSync(dbFile)) {
                        fs.unlinkSync(dbFile);
                        // Reordenar sesiones después de borrar para eliminar huecos
                        setTimeout(() => reorderSubBotSessions(), 2000);
                    }
                } catch {}
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada. Usa \`.serbot\` para reconectar.` }).catch(() => {});
                return;
            }

            if (code === DisconnectReason.loggedOut) {
                try { 
                    if (fs.existsSync(dbFile)) {
                        fs.unlinkSync(dbFile);
                        // Reordenar sesiones después de borrar para eliminar huecos
                        setTimeout(() => reorderSubBotSessions(), 2000);
                    }
                } catch {}
                if (ownerJid) conn.sendMessage(ownerJid, { text: `📴 Sub-bot #${num} cerró sesión. Usa \`.serbot\` si quieres volver a conectarlo.` }).catch(() => {});
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 8000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot #${num} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⛔ Sub-bot #${num} agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;

            // Ignorar mensajes anteriores al inicio del bot
            const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
            if (msgTs && global._botStartTime && msgTs < global._botStartTime) continue;

            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            
            // 🧹 Limpieza periódica de IDs procesados
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) {
                    if (ts < cutoff) processedIds.delete(id);
                }
            }

            // ── Guardar mensaje en chat logger (grupos) ──────────────────────────
            try {
                const { logMessage } = require('../../chatLogger');
                logMessage(baileyMessage, sock).catch(() => {});
            } catch {}

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            const msgChatJidEarly = baileyMessage.key.remoteJid;
            const isGroupMsgEarly = typeof msgChatJidEarly === 'string' && msgChatJidEarly.endsWith('@g.us');

            // Si fromMe=true, puede ser:
            //   A) Un mensaje que el subbot envió (remoteJid es el destinatario, participant vacío)
            //   B) Un mensaje que el DUEÑO del subbot envió desde su teléfono (sincronizado)
            // Solo ignorar caso A (mensajes que el propio bot envió sin prefijo).
            // Caso B (dueño usando comandos) debe procesarse normalmente.
            if (isFromMe) {
                // Sin prefijo → nunca es un comando, ignorar siempre
                if (!hasPrefix) continue;
                // Con prefijo en privado: solo ignorar si el chat es con el propio número del bot
                // (el bot se habló a sí mismo), no si es el dueño hablando con otro chat
                if (!isGroupMsgEarly) {
                    const botNum = sock.user?.id?.split('@')[0]?.split(':')[0];
                    const chatNum = msgChatJidEarly?.split('@')[0]?.split(':')[0];
                    // Si el chat remoto ES el propio bot → mensaje que el bot se envió a sí mismo, ignorar
                    if (botNum && chatNum && botNum === chatNum) continue;
                    // Si no, es el dueño enviando un comando desde su teléfono → procesar
                }
            }
            if (!msgText && !hasPrefix) continue;

            if (hasPrefix) {
                const _cmd = msgText.slice(1).split(' ')[0].toLowerCase();
                if (['bcbot','broadcastbot'].includes(_cmd)) continue;

                if (['botsonline','subbotsonline'].includes(_cmd)) {
                    console.log(`[Heartbeat] 🤖 SubBot #${num} activo (respuesta a botsonline)`);
                    continue;
                }
            }

            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');

            // Si es un grupo donde el bot principal también está, el subbot cede
            if (isGroupMsg && global.conn?.user) {
                const mainInGroup = await isMainBotInGroup(msgChatJid);
                if (mainInGroup) continue;
            }

            // ✅ Todos los bots responden libremente en cualquier grupo

            // ── Transcripción automática de audios/notas de voz ─────────────
            if (!isFromMe && isGroupMsg) {
                try {
                    const { tryTranscribeAndSave } = require('../../chatAudioTranscriber');
                    tryTranscribeAndSave(baileyMessage).catch(() => {});
                } catch (_) {}
            }
            // ────────────────────────────────────────────────────────────────

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                // Guardar el socket en el mensaje para que los plugins puedan usarlo
                // directamente sin depender de global.conn (que puede ser pisado por
                // otro subbot concurrente mientras este await está en vuelo).
                compatibleMessage._sock  = sock;
                compatibleMessage._subNum = num;

                // NO mutar global.conn — causa condiciones de carrera cuando múltiples
                // subbots procesan mensajes en paralelo. Cada plugin debe usar
                // message._sock o message.reply() en lugar de global.conn.
                const prevLastMsg = global.lastBaileyMessage;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
function reorderSubBotSessions() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    const alreadyOrdered = nums.every((n, i) => n === i + 1);
    if (alreadyOrdered) return;

    console.log(`[SubBot] 🔄 Reordenando sesiones: [${nums.join(', ')}] → [${nums.map((_, i) => i + 1).join(', ')}]`);

    // Desconectar todos los subbots afectados antes de renombrar
    for (const num of nums) {
        const sock = activeSocks.get(String(num));
        if (sock) {
            try { 
                sock.ev.removeAllListeners(); 
                sock.ws.close(); 
            } catch {}
            activeSocks.delete(String(num));
            const idx = global.subConns.findIndex(c => c._subNum === num);
            if (idx >= 0) global.subConns.splice(idx, 1);
        }
    }

    // Renombrar a temporales primero para evitar colisiones
    const tempNames = [];
    for (const num of nums) {
        const tempName = `_tmp_${num}_${Date.now()}.db`;
        try {
            fs.renameSync(path.join(SESSIONS_DIR, `${num}.db`), path.join(SESSIONS_DIR, tempName));
            tempNames.push(tempName);
        } catch (e) {
            console.error(`[SubBot] Error renombrando ${num}.db:`, e.message);
        }
    }
    
    // Renombrar de temporal a número final
    for (let i = 0; i < tempNames.length; i++) {
        try {
            fs.renameSync(path.join(SESSIONS_DIR, tempNames[i]), path.join(SESSIONS_DIR, `${i + 1}.db`));
        } catch (e) {
            console.error(`[SubBot] Error renombrando temporal ${i}:`, e.message);
        }
    }

    console.log(`[SubBot] ✅ Sesiones reordenadas. Reconectando...`);

    // Reconectar los subbots con sus nuevos números
    setTimeout(async () => {
        for (let i = 1; i <= tempNames.length; i++) {
            const dbFile = path.join(SESSIONS_DIR, `${i}.db`);
            if (!fs.existsSync(dbFile)) continue;
            console.log(`[SubBot] Reconectando bot #${i}...`);
            await sleep(1500);
            await connectSubBot({ num: i, chatJid: null, conn: global.conn })
                .catch(e => console.error(`[SubBot] Error reconectando #${i}:`, e.message));
        }
    }, 3000);
}

// ─── Migración automática: carpetas viejas → .db ─────────────────────────────
// Se ejecuta una sola vez al iniciar. Si encuentra carpetas numéricas (sesiones
// del formato viejo) las convierte a .db y borra la carpeta original.
async function migrarSesionesLegacy() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    let Database, BufferJSON;
    try {
        Database  = require('better-sqlite3');
        ({ BufferJSON } = require('@whiskeysockets/baileys'));
    } catch (e) {
        console.error('[SubBot] migrarSesiones: dependencia faltante:', e.message);
        return;
    }

    const KNOWN_TYPES = [
        'app-state-sync-key',
        'app-state-sync-version',
        'sender-key-memory',
        'sender-key',
        'pre-key',
        'session',
    ];

    // Carpetas numéricas = sesiones del formato viejo
    const carpetas = fs.readdirSync(SESSIONS_DIR)
        .filter(e => {
            const n = parseInt(e);
            if (isNaN(n) || String(n) !== e) return false;
            return fs.statSync(path.join(SESSIONS_DIR, e)).isDirectory();
        })
        .map(e => parseInt(e))
        .sort((a, b) => a - b);

    if (carpetas.length === 0) return;

    console.log(`[SubBot] 🔄 Migrando ${carpetas.length} sesión(es) legacy a .db: [${carpetas.join(', ')}]`);

    for (const num of carpetas) {
        const folderPath = path.join(SESSIONS_DIR, String(num));
        const destFile   = path.join(SESSIONS_DIR, `${num}.db`);
        const credsFile  = path.join(folderPath, 'creds.json');

        // Si ya existe el .db, solo borrar la carpeta vieja
        if (fs.existsSync(destFile)) {
            console.log(`[SubBot] [${num}] .db ya existe, borrando carpeta legacy...`);
            try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch {}
            continue;
        }

        if (!fs.existsSync(credsFile)) {
            console.log(`[SubBot] [${num}] Sin creds.json, borrando carpeta vacía...`);
            try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch {}
            continue;
        }

        try {
            const db      = new Database(destFile);
            db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
            const stmtSet = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');

            const allFiles = fs.readdirSync(folderPath);
            let insertados = 0;

            const insertAll = db.transaction(() => {
                for (const file of allFiles) {
                    if (!file.endsWith('.json')) continue;
                    const filePath = path.join(folderPath, file);
                    if (!fs.statSync(filePath).isFile()) continue;

                    let content;
                    try {
                        content = JSON.parse(fs.readFileSync(filePath, 'utf-8'), BufferJSON.reviver);
                    } catch { continue; }

                    const nameNoExt = file.replace(/\.json$/, '');

                    if (nameNoExt === 'creds') {
                        stmtSet.run('creds', JSON.stringify(content, BufferJSON.replacer));
                        insertados++;
                        continue;
                    }
                    if (nameNoExt === 'owner') {
                        stmtSet.run('_owner', JSON.stringify(content));
                        insertados++;
                        continue;
                    }

                    let matched = false;
                    for (const type of KNOWN_TYPES) {
                        if (nameNoExt.startsWith(type + '-')) {
                            const id = nameNoExt.slice(type.length + 1);
                            stmtSet.run(`${type}-${id}`, JSON.stringify(content, BufferJSON.replacer));
                            insertados++;
                            matched = true;
                            break;
                        }
                    }
                    if (!matched) {
                        stmtSet.run(nameNoExt, JSON.stringify(content, BufferJSON.replacer));
                        insertados++;
                    }
                }
            });

            insertAll();
            db.close();

            // Borrar carpeta original solo si el .db se creó correctamente
            fs.rmSync(folderPath, { recursive: true, force: true });
            console.log(`[SubBot] ✅ [${num}] Migrado (${insertados} entradas → ${num}.db)`);

        } catch (err) {
            console.error(`[SubBot] ❌ [${num}] Error migrando:`, err.message);
            // Si el .db quedó a medias, borrarlo para no dejar basura
            try { if (fs.existsSync(destFile)) fs.unlinkSync(destFile); } catch {}
        }
    }
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    // Migrar sesiones legacy (carpetas → .db) antes de reconectar
    await migrarSesionesLegacy();

    reorderSubBotSessions();

    const nums = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    for (const num of nums) {
        const dbFile = path.join(SESSIONS_DIR, `${num}.db`);
        if (!fs.existsSync(dbFile)) continue;
        if (global.subConns.find(c => c._subNum === num && c.user)) continue;
        console.log(`[SubBot] Auto-reconectando bot #${num}...`);
        await sleep(2000);
        await connectSubBot({ num, chatJid: null, conn })
            .catch(e => console.error(`[SubBot] Error auto-reconexión #${num}:`, e.message));
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot)$/i,
    help: 'Crear sub-bot. Uso: .serbot qr | .serbot code <numero_internacional>',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const conn = global.conn;

        const helpText =
            `📌 *Cómo usar .serbot*\n\n` +
            `✅ *Opción 1 (QR):*\n` +
            `- Usa: \`.serbot qr\`\n` +
            `- *Necesitas otro dispositivo* (o una PC) donde se muestre el QR para poder escanearlo.\n` +
            `- En WhatsApp: *Dispositivos vinculados* → *Vincular un dispositivo* → escanea el QR.\n\n` +
            `✅ *Opción 2 (CODE):*\n` +
            `- Usa: \`.serbot code <numero>\`\n` +
            `- *No necesitas otro dispositivo*.\n` +
            `- El número debe ir en *formato internacional*\n` +
            `  Ejemplos:\n` +
            `  - \`.serbot code 59893900470\`\n` +
            `  - \`.serbot code +598 93 900 470\` (también sirve)\n\n` +
            `ℹ️ *¿No sabés tu número en formato internacional?*\n` +
            `Usa \`.numwa <país> <tu número>\` y el bot te lo devuelve listo para copiar.\n` +
            `Ejemplos:\n` +
            `- \`.numwa uruguay 093900470\`\n` +
            `- \`.numwa argentina 01123456789\`\n` +
            `- \`.numwa mexico 5512345678\`\n` +
            `- \`.numwa españa 612345678\`\n`;

        if (message.isGroup) {
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // Subcomandos: .serbot qr | .serbot code <numero>
        // Unir todos los args y limpiar para manejar espacios extras
        const allArgs = (args || []).filter(a => a.trim() !== '');
        const arg0 = (allArgs[0] || '').trim().toLowerCase();

        let usePairingCode = false;
        let phoneNumber    = null;
        let token          = null;

        if (arg0 === 'qr') {
            // .serbot qr → forzar QR
            usePairingCode = false;
        } else if (arg0 === 'code') {
            // .serbot code <numero> — acepta +598 939 004 70, 598-939-004-70, etc.
            const rawNumber = allArgs.slice(1).join(''); // unir todo lo que sigue, ignorando espacios
            const cleanedNumber = rawNumber.replace(/[^0-9]/g, '');
            if (!cleanedNumber || cleanedNumber.length < 7 || cleanedNumber.length > 15) {
                return conn.sendMessage(message.from, {
                    text: `❌ Debes indicar el número en formato internacional.\n\n${helpText}`
                }, { quoted: message._baileyMessage });
            }
            usePairingCode = true;
            phoneNumber    = cleanedNumber;
        } else {
            // NO aceptar: .serbot | .serbot <numero> | cualquier cosa distinta de "qr" o "code <numero>"
            return conn.sendMessage(message.from, { text: helpText }, { quoted: message._baileyMessage });
        }

        if (pendingQR.has(senderJid)) {
            return conn.sendMessage(message.from, {
                text: `⏳ Ya tienes un proceso pendiente. Espera a que expire para generar uno nuevo.`
            }, { quoted: message._baileyMessage });
        }

        // Verificar si el NÚMERO que se va a vincular ya tiene un subbot activo
        // (no el JID de quien ejecuta el comando)
        const targetNumber = usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0];
        const targetJid = `${targetNumber}@s.whatsapp.net`;
        
        const existingNum = getSubBotNumberByOwner(targetJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (alreadyActive) {
                return conn.sendMessage(message.from, {
                    text: usePairingCode
                        ? `ℹ️ El número *${phoneNumber}* ya es el Sub-Bot #${existingNum}.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                        : `ℹ️ Ya eres el Sub-Bot #${existingNum}.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                }, { quoted: message._baileyMessage });
            }
            pendingQR.add(senderJid);
            conn.sendMessage(message.from, {
                text: usePairingCode
                    ? `⏳ Generando código para reconectar sub-bot #${existingNum} con el número *${phoneNumber}*...`
                    : `⏳ Reconectando tu sub-bot #${existingNum} con QR...`
            }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
        }

        const num = nextSubBotNumber();

        pendingQR.add(senderJid);
        conn.sendMessage(message.from, {
            text: usePairingCode
                ? `⏳ Generando código de emparejamiento para el número *${phoneNumber}* (sub-bot #${num})...\n\n_En unos segundos recibirás el código de 8 dígitos._`
                : token
                    ? `⏳ Restaurando sesión como sub-bot #${num}...`
                    : `⏳ Generando QR para sub-bot #${num}...`
        }, { quoted: message._baileyMessage });

        await connectSubBot({ num, chatJid: senderJid, conn, token, usePairingCode, phoneNumber });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn   = global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (conn?.user) {
            const mainPhoneNum = conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        if (active.length > 0) {
            const subBotLines = active.map(c => {
                const phoneNum = c.user.id.split('@')[0].split(':')[0];
                return `🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`;
            });
            lines.push(...subBotLines);
        }

        if (lines.length === 0) {
            return conn.sendMessage(message.from, { text: '📭 No hay bots conectados.' }, { quoted: message._baileyMessage });
        }

        const totalBots = (conn?.user ? 1 : 0) + active.length;
        conn.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${totalBots}*\n\n${lines.join('\n\n')}\n\n━━━━━━━━━━━━━━━━━━━━\n_Usa .gruposbots para ver los grupos_`
        }, { quoted: message._baileyMessage });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    help: 'Ver qué bots están activos (solo en el grupo oficial)',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const officialGroupJid = OFFICIAL_GROUP;
        if (message.from !== officialGroupJid) return;

        const conn = global.conn;
        await conn.sendMessage(officialGroupJid, {
            text: '🟢 *Bot principal activo* ✅'
        }, { quoted: message._baileyMessage });

        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        for (const subSock of active) {
            await sleep(800);
            try {
                await subSock.sendMessage(officialGroupJid, {
                    text: `🤖 *SubBot #${subSock._subNum}* está activo ✅`
                });
            } catch (e) {
                console.error(`[SubBot] Error respuesta botsonline #${subSock._subNum}:`, e.message);
            }
        }
    }
};

/** Versión para el servidor web: genera QR */
async function connectSubBotWeb({ num, conn }) {
    return connectSubBot({ num, chatJid: null, conn });
}

/** Versión para el servidor web: genera código de emparejamiento */
async function connectSubBotWebWithCode({ num, conn, phoneNumber }) {
    return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber });
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    listBots:            listBotsHandler,
};