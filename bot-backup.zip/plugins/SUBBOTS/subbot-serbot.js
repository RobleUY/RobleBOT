'use strict';
/**
 * Plugin de Sub-Bots (numerados automáticamente)
 *
 * .serbot    → Crear tu sub-bot (número asignado automático)
 * .bots / .subbots / .listbots → Ver sub-bots activos
 * .bcbot     → Difundir mensaje (owner)
 *
 * Para eliminar: ir a Dispositivos Vinculados en WhatsApp y cerrar sesión.
 * Bot oficial = prioridad 0. Subbots = 1, 2, 3... (menor número = mayor prioridad)
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

// Grupo oficial donde todos los subbots deben estar
const OFFICIAL_GROUP = '120363426476029684@g.us';

const retryMap    = new Map();
const activeSocks = new Map();
const pendingQR   = new Set(); // JIDs con QR pendiente de escanear
const MAX_RETRY   = 3;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Intenta unir un bot (oficial o subbot) al grupo oficial
 */
async function joinOfficialGroup(sock, botLabel = 'Bot') {
    try {
        const groupJid = OFFICIAL_GROUP;
        
        // Verificar si ya está en el grupo
        try {
            const groupMeta = await sock.groupMetadata(groupJid);
            if (groupMeta) {
                console.log(`[${botLabel}] Ya está en el grupo oficial`);
                return true;
            }
        } catch (e) {
            // No está en el grupo, intentar unirse
        }

        // Intentar unirse usando el código de invitación
        await sock.groupAcceptInvite('KwDx3Mgt1FM7heUXKVtFvA');
        console.log(`[${botLabel}] ✅ Unido al grupo oficial`);
        return true;
    } catch (error) {
        console.error(`[${botLabel}] Error uniéndose al grupo:`, error.message);
        return false;
    }
}

let _baileysVersion = null;
async function getBaileysVersion() {
    if (!_baileysVersion) {
        const { version } = await fetchLatestBaileysVersion();
        _baileysVersion = version;
    }
    return _baileysVersion;
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, String(num));
}

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
    let n = 1;
    while (existing.includes(n)) n++;
    return n;
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const folders = fs.readdirSync(SESSIONS_DIR).filter(f => !isNaN(parseInt(f)));
    for (const folder of folders) {
        const ownerFile = path.join(SESSIONS_DIR, folder, 'owner.json');
        if (!fs.existsSync(ownerFile)) continue;
        try {
            const data = JSON.parse(fs.readFileSync(ownerFile, 'utf-8'));
            const storedNum = (data.ownerJid || '').split('@')[0].split(':')[0];
            if (storedNum === ownerNum) return parseInt(folder);
        } catch {}
    }
    return null;
}

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null }) {
    const name      = String(num);
    const sessDir   = sessionPath(num);
    const credsFile = path.join(sessDir, 'creds.json');
    const ownerFile = path.join(sessDir, 'owner.json');

    // Siempre crear carpeta (necesaria para auth state)
    if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });

    // owner.json se escribe solo cuando conecta exitosamente (en connection === 'open')
    // Aquí solo leemos si ya existe (auto-reconexión)
    let ownerJid = chatJid;
    if (!ownerJid && fs.existsSync(ownerFile)) {
        try { ownerJid = JSON.parse(fs.readFileSync(ownerFile, 'utf-8')).ownerJid; } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { prevSock.ev.removeAllListeners(); prevSock.ws.close(); } catch {}
        activeSocks.delete(name);
        const pi = global.subConns.findIndex(c => c._subName === name);
        if (pi >= 0) global.subConns.splice(pi, 1);
    }

    if (token) {
        try {
            const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
            fs.writeFileSync(credsFile, JSON.stringify(decoded, null, '\t'));
        } catch {
            if (ownerJid) conn.sendMessage(ownerJid, { text: '❌ Token inválido.' }).catch(() => {});
            return;
        }
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessDir);
    const version              = await getBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        browser: ['RobleBOT SubBot #' + num, 'Safari', '17.0'],
        generateHighQualityLinkPreview: false,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 500,
        maxMsgRetryCount: 2,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        markOnlineOnConnect: true,
        syncFullHistory: false,
        getMessage: async () => undefined
    });

    sock._subName  = name;
    sock._subNum   = num;
    sock._sessDir  = sessDir;
    sock._ownerJid = ownerJid;
    sock.uptime    = Date.now();
    activeSocks.set(name, sock);

    let qrSent    = false;
    let qrTimeout = null;
    let connected = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            if (connected) return;
            if (qrSent) {
                // segundo QR = el primero expiró sin escanear, cerrar
                console.log(`[SubBot] QR expirado para bot #${num}`);
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                // Limpiar carpeta si no hay creds reales (nunca conectó)
                if (!connected && fs.existsSync(sessDir) && !fs.existsSync(path.join(sessDir, 'creds.json'))) {
                    fs.rmSync(sessDir, { recursive: true, force: true });
                }
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                return;
            }
            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                if (ownerJid) {
                    await conn.sendMessage(ownerJid, {
                        image: imgBuf,
                        caption: `📱 *Escanea el QR para conectar tu sub-bot #${num}*\n_Tienes 30 segundos. Si expira usa \`.serbot\` de nuevo._`
                    });
                    qrSent = true;
                }
                // Entregar QR al servidor web si hay alguien esperando
                try {
                    const { resolveWebQR } = require('../../subbotServer');
                    const dataUrl = await qrcode.toDataURL(qr);
                    resolveWebQR(num, dataUrl);
                } catch {}
                // timeout de seguridad por si el segundo QR no llega
                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    if (ownerJid) pendingQR.delete(ownerJid);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    // Limpiar carpeta si nunca conectó
                    if (fs.existsSync(sessDir) && !fs.existsSync(ownerFile)) {
                        fs.rmSync(sessDir, { recursive: true, force: true });
                    }
                    if (ownerJid) conn.sendMessage(ownerJid, { text: `⏰ QR expirado. Usa \`.serbot\` para generar uno nuevo.` }).catch(() => {});
                }, 35000);
            } catch (e) { console.error('[SubBot] Error QR:', e.message); }
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            if (ownerJid) pendingQR.delete(ownerJid);
            // Guardar owner ahora que la conexión es real
            fs.writeFileSync(ownerFile, JSON.stringify({ ownerJid, num }));
            retryMap.delete(name);
            sock.uptime = Date.now();
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            if (ownerJid) {
                conn.sendMessage(ownerJid, {
                    text: `✅ *Sub-bot #${num} conectado*\n\nPara eliminarlo, ve a *Dispositivos Vinculados* en WhatsApp y cierra la sesión desde ahí.`
                }).catch(() => {});
            }
            // Unirse al grupo oficial
            setTimeout(() => joinOfficialGroup(sock, `SubBot #${num}`), 3000);
            sock._presenceInterval = setInterval(async () => {
                try { if (sock.user) await sock.sendPresenceUpdate('available'); } catch {}
            }, 20000);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}`);

            activeSocks.delete(name);
            const ci = global.subConns.findIndex(c => c._subName === name);
            if (ci >= 0) global.subConns.splice(ci, 1);
            if (sock._presenceInterval) { clearInterval(sock._presenceInterval); sock._presenceInterval = null; }
            try { sock.ev.removeAllListeners(); } catch {}

            if (code === 515) {
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), 2000);
                return;
            }
            if (code === 401 || code === 403 || code === 405) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⚠️ Sesión del sub-bot #${num} cerrada. Usa \`.serbot\` para reconectar.` }).catch(() => {});
                return;
            }
            if (code === DisconnectReason.loggedOut) {
                fs.rmSync(sessDir, { recursive: true, force: true });
                if (ownerJid) conn.sendMessage(ownerJid, { text: `📴 Sub-bot #${num} cerró sesión desde dispositivos vinculados. Usa \`.serbot\` si quieres volver a conectarlo.` }).catch(() => {});
                return;
            }

            const attempts = retryMap.get(name) || 0;
            if (attempts < MAX_RETRY) {
                retryMap.set(name, attempts + 1);
                const delay = 8000 * (attempts + 1);
                console.log(`[SubBot] Reconectando bot #${num} en ${delay / 1000}s (${attempts + 1}/${MAX_RETRY})`);
                setTimeout(() => connectSubBot({ num, chatJid: ownerJid, conn }), delay);
            } else {
                retryMap.delete(name);
                if (ownerJid) conn.sendMessage(ownerJid, { text: `⛔ Sub-bot #${num} agotó reconexiones. Usa \`.serbot\` para intentar de nuevo.` }).catch(() => {});
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('messaging-history.set', () => {});
    sock.ev.on('messages.set',          () => {});
    sock.ev.on('contacts.set',          () => {});
    sock.ev.on('chats.set',             () => {});
    sock.ev.on('presence.update',       () => {});

    // ── Procesar mensajes ────────────────────────────────────────────────────
    const { getMessageText, createCompatibleMessage } = require('../../messageUtils');
    const processedIds = new Map();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;
            const messageId = baileyMessage.key.id;
            if (processedIds.has(messageId)) continue;
            processedIds.set(messageId, Date.now());
            if (processedIds.size > 200) {
                const cutoff = Date.now() - 60000;
                for (const [id, ts] of processedIds) if (ts < cutoff) processedIds.delete(id);
            }

            const isFromMe  = baileyMessage.key.fromMe;
            const msgText   = getMessageText(baileyMessage);
            const prefixes  = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => msgText.startsWith(p));
            if (isFromMe && !hasPrefix) continue;
            if (!msgText && !hasPrefix) continue;

            // Comandos de gestión de subbots: solo los procesa el bot oficial
            if (hasPrefix) {
                const _cmd = msgText.slice(1).split(' ')[0].toLowerCase();
                // serbot/jadibot → el subbot responde con redirección al oficial
                if (['serbot','jadibot'].includes(_cmd)) {
                    const _mainNum = global.mainBotNumber;
                    const _reply = _mainNum
                        ? `Para poder ser sub-bot debes usar el comando con el bot oficial:\nwa.me/+${_mainNum}`
                        : `Para poder ser sub-bot debes usar el comando con el bot oficial.`;
                    try {
                        const _sock = sock;
                        await _sock.sendMessage(baileyMessage.key.remoteJid, { text: _reply });
                    } catch {}
                    continue;
                }
                // estos solo los maneja el oficial, subbots los ignoran
                if (['bcbot','broadcastbot'].includes(_cmd)) continue;
                // listbots/bots/subbots → los subbots SÍ pueden responder (no se bloquean)

                // botsonline/subbotsonline → cada subbot responde por su cuenta (bypass de prioridad)
                if (['botsonline','subbotsonline'].includes(_cmd)) {
                    const chatJid = baileyMessage.key.remoteJid;
                    if (chatJid === OFFICIAL_GROUP) {
                        // Delay escalonado según número de subbot para no saturar
                        await sleep(1000 + (num * 800));
                        try {
                            await sock.sendMessage(chatJid, {
                                text: `🤖 *SubBot #${num}* está activo ✅`
                            });
                        } catch (e) {
                            console.error(`[SubBot] Error botsonline #${num}:`, e.message);
                        }
                    }
                    continue; // No pasar a la lógica de prioridad ni al commandHandler
                }
            }

            // ── Prioridad: bot oficial = 0, subbots por número ascendente ───
            const msgChatJid = baileyMessage.key.remoteJid;
            const isGroupMsg = typeof msgChatJid === 'string' && msgChatJid.endsWith('@g.us');
            if (sock.user) {
                try {
                    const mainBotNum = global.mainBotNumber;
                    if (isGroupMsg) {
                        const groupMeta = await sock.groupMetadata(msgChatJid).catch(() => null);
                        if (groupMeta?.participants) {
                            const participantNums = groupMeta.participants
                                .map(p => p.id.split('@')[0].split(':')[0]);

                            if (mainBotNum && participantNums.includes(mainBotNum)) continue;

                            const subbotsInGroup = global.subConns
                                .filter(c => c.user && c._subNum != null)
                                .filter(c => participantNums.includes(c.user.id.split('@')[0].split(':')[0]))
                                .sort((a, b) => a._subNum - b._subNum);

                            if (subbotsInGroup.length > 1 && subbotsInGroup[0]._subNum !== num) continue;
                        }
                    } else {
                        const chatNum   = typeof msgChatJid === 'string' ? msgChatJid.split('@')[0].split(':')[0] : null;
                        const senderNum = (baileyMessage.key.participant || baileyMessage.key.remoteJid || '')
                            .split('@')[0].split(':')[0];
                        if (mainBotNum && (chatNum === mainBotNum || senderNum === mainBotNum)) continue;
                    }
                } catch (e) {
                    console.error(`[SubBot] Error prioridad:`, e.message);
                }
            }
            // ────────────────────────────────────────────────────────────────

            try {
                if (!global.db?.data) continue;
                const compatibleMessage  = createCompatibleMessage(baileyMessage, sock);
                compatibleMessage._sock  = sock;

                const prevConn           = global.conn;
                const prevLastMsg        = global.lastBaileyMessage;

                if (!sock.user && prevConn?.user) sock.user = prevConn.user;

                global.conn              = sock;
                global.lastBaileyMessage = baileyMessage;

                try {
                    if (global.commandHandler?.handleMessage) {
                        await global.commandHandler.handleMessage(compatibleMessage);
                    }
                } finally {
                    global.conn              = prevConn;
                    global.lastBaileyMessage = prevLastMsg;
                }
            } catch (e) {
                if (!e.message?.includes('Connection Closed'))
                    console.error(`[SubBot] Error procesando mensaje:`, e.message);
            }
        }
    });
}

// ─── Auto-reconexión al iniciar ──────────────────────────────────────────────
/**
 * Renombra las carpetas de sesiones para que sigan el orden 1, 2, 3...
 * sin huecos. Ej: si existen [2, 6] → pasan a ser [1, 2].
 * Se llama al inicio del servidor, antes de conectar los subbots.
 */
function reorderSubBotSessions() {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    // Si ya están en orden correcto (1, 2, 3...) no hacer nada
    const alreadyOrdered = folders.every((n, i) => n === i + 1);
    if (alreadyOrdered) return;

    console.log(`[SubBot] Reordenando sesiones: [${folders.join(', ')}] → [${folders.map((_, i) => i + 1).join(', ')}]`);

    // Primero mover todo a nombres temporales para evitar colisiones (ej: 2→1 cuando 1 ya existe)
    const tempNames = [];
    for (const num of folders) {
        const tempName = `_tmp_${num}_${Date.now()}`;
        const src = path.join(SESSIONS_DIR, String(num));
        const tmp = path.join(SESSIONS_DIR, tempName);
        fs.renameSync(src, tmp);
        tempNames.push(tempName);
    }

    // Luego renombrar de temporal al número correcto (1, 2, 3...)
    for (let i = 0; i < tempNames.length; i++) {
        const tmp = path.join(SESSIONS_DIR, tempNames[i]);
        const dst = path.join(SESSIONS_DIR, String(i + 1));
        fs.renameSync(tmp, dst);
    }

    console.log(`[SubBot] Sesiones reordenadas correctamente.`);
}

async function autoReconnectSubBots(conn) {
    if (!fs.existsSync(SESSIONS_DIR)) return;

    // Reordenar carpetas antes de conectar
    reorderSubBotSessions();

    const folders = fs.readdirSync(SESSIONS_DIR)
        .map(f => parseInt(f))
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);

    for (const num of folders) {
        const credsFile = path.join(SESSIONS_DIR, String(num), 'creds.json');
        if (!fs.existsSync(credsFile)) continue;
        if (global.subConns.find(c => c._subNum === num && c.user)) continue;
        console.log(`[SubBot] Auto-reconectando bot #${num}...`);
        await sleep(2000);
        await connectSubBot({ num, chatJid: null, conn })
            .catch(e => console.error(`[SubBot] Error auto-reconexión #${num}:`, e.message));
    }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

const serbotHandler = {
    command: /^(serbot|jadibot)$/i,
    help: 'Crear tu sub-bot. Uso: .serbot',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const conn = global.conn;

        if (message.isGroup) {
            return conn.sendMessage(message.from, {
                text: '❌ Este comando solo puede usarse en chat privado con el bot.'
            }, { quoted: message._baileyMessage });
        }

        const senderJid = message.author || message.sender || message.from;

        // ¿Ya tiene QR pendiente?
        if (pendingQR.has(senderJid)) {
            return conn.sendMessage(message.from, {
                text: `⏳ Ya tienes un QR pendiente de escanear. Espera a que expire para generar uno nuevo.`
            }, { quoted: message._baileyMessage });
        }

        // ¿Ya es sub-bot?
        const existingNum = getSubBotNumberByOwner(senderJid);
        if (existingNum !== null) {
            const alreadyActive = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (alreadyActive) {
                return conn.sendMessage(message.from, {
                    text: `ℹ️ Ya eres el Sub-Bot #${existingNum}.\n\nPara eliminar la sesión, ve a *Dispositivos Vinculados* en WhatsApp y ciérrala desde ahí.`
                }, { quoted: message._baileyMessage });
            }
            // Sesión guardada pero inactiva → reconectar
            const arg0  = (args?.[0] || '').trim();
            const token = arg0.length > 20 ? arg0 : null;
            pendingQR.add(senderJid);
            conn.sendMessage(message.from, {
                text: `⏳ Reconectando tu sub-bot #${existingNum}...`
            }, { quoted: message._baileyMessage });
            return connectSubBot({ num: existingNum, chatJid: senderJid, conn, token });
        }

        // Nuevo sub-bot
        const num  = nextSubBotNumber();
        const arg0 = (args?.[0] || '').trim();
        const token = arg0.length > 20 ? arg0 : null;

        pendingQR.add(senderJid);
        conn.sendMessage(message.from, {
            text: token ? `⏳ Restaurando sesión como sub-bot #${num}...` : `⏳ Generando QR para sub-bot #${num}...`
        }, { quoted: message._baileyMessage });

        await connectSubBot({ num, chatJid: senderJid, conn, token });
    }
};

const listBotsHandler = {
    command: /^(listbots|bots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const conn   = global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        if (active.length === 0) return conn.sendMessage(message.from, { text: '📭 No hay sub-bots conectados.' }, { quoted: message._baileyMessage });

        const list = active.map(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            return `SubBot #${c._subNum}\nwa.me/+${phoneNum}`;
        }).join('\n');

        conn.sendMessage(message.from, { text: `🤖 *Sub-bots activos: ${active.length}*\n\n${list}` }, { quoted: message._baileyMessage });
    }
};

const botsOnlineHandler = {
    command: /^(botsonline|subbotsonline)$/i,
    help: 'Ver qué bots están activos (solo en el grupo oficial)',
    tags: ['subbots'],
    handler: async (message, _p) => {
        const officialGroupJid = OFFICIAL_GROUP;

        // Solo funciona en el grupo oficial
        if (message.from !== officialGroupJid) return;

        const conn = global.conn;

        // Bot principal responde primero
        await conn.sendMessage(officialGroupJid, {
            text: '🟢 *Bot principal activo* ✅'
        }, { quoted: message._baileyMessage });

        // Cada subbot responde con un pequeño delay para no saturar
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        for (const subSock of active) {
            await sleep(800);
            try {
                await subSock.sendMessage(officialGroupJid, {
                    text: `🤖 *SubBot #${subSock._subNum}* está activo ✅`
                });
            } catch (e) {
                console.error(`[SubBot] Error respuesta botsonline #${subSock._subNum}:`, e.message);
            }
        }
    }
};

/** Versión para el servidor web: sin ownerJid, solo genera el QR */
async function connectSubBotWeb({ num, conn }) {
    return connectSubBot({ num, chatJid: null, conn });
}

module.exports = {
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    autoReconnectSubBots,
    connectSubBotWeb,
    listBots:            listBotsHandler,
};
