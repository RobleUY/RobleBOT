'use strict';

// ── chat-clean-scheduler.js ───────────────────────────────────────────────
// Programador de limpieza automática de chats por bot/subbot.
// Permite eliminar periódicamente todos los chats o un chat específico de un subbot.
// Tiempo mínimo: 10 minutos (600,000 ms).
// Guarda su configuración en plugins/SUBBOTS/data/subbot-chatclean.json.

const fs = require('fs');
const path = require('path');
const chatTracker = require('./chat-tracker');

const DATA_DIR = path.join(__dirname, 'data');
const CLEAN_FILE = path.join(DATA_DIR, 'subbot-chatclean.json');
const MIN_INTERVAL_MS = 10 * 60 * 1000; // 10 minutos
const CHECK_INTERVAL_MS = 30 * 1000;    // revisar programas cada 30s

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let cache = null;
let dirty = false;

function loadConfig() {
    if (cache) return cache;
    try {
        if (fs.existsSync(CLEAN_FILE)) {
            cache = JSON.parse(fs.readFileSync(CLEAN_FILE, 'utf8'));
            return cache;
        }
    } catch (e) {
        console.error('[chat-clean-scheduler] Error cargando subbot-chatclean.json:', e.message);
    }
    cache = {};
    return cache;
}

function saveConfig() {
    if (!dirty || !cache) return;
    try {
        fs.writeFileSync(CLEAN_FILE, JSON.stringify(cache, null, 2), 'utf8');
        dirty = false;
    } catch (e) {
        console.error('[chat-clean-scheduler] Error guardando subbot-chatclean.json:', e.message);
    }
}

function getCleanBotNum(botNum) {
    if (botNum === null || botNum === undefined) return 'main';
    const str = String(botNum).trim();
    if (str.toLowerCase() === 'main' || str === '') return 'main';
    const digits = str.replace(/\D/g, '');
    return digits || str;
}

/**
 * Parsea un string de tiempo como '10m', '30m', '1h', '2d' o minutos numéricos '10'.
 * Retorna { ok: boolean, ms: number, formatted: string, error?: string }
 */
function parseInterval(str) {
    if (!str || typeof str !== 'string') {
        return { ok: false, error: 'Formato de tiempo inválido. Ejemplo: 10m, 1h, 30m.' };
    }
    const cleanStr = str.trim().toLowerCase();
    const match = cleanStr.match(/^(\d+)([mhd])?$/);
    if (!match) {
        return { ok: false, error: 'Formato de tiempo inválido. Usa números seguidos de m (minutos), h (horas) o d (días). Ejemplos: 10m, 1h.' };
    }

    const val = parseInt(match[1], 10);
    const unit = match[2] || 'm';

    let mult = 60 * 1000;
    let label = 'm';
    if (unit === 'h') {
        mult = 60 * 60 * 1000;
        label = 'h';
    } else if (unit === 'd') {
        mult = 24 * 60 * 60 * 1000;
        label = 'd';
    }

    const ms = val * mult;
    if (ms < MIN_INTERVAL_MS) {
        return { ok: false, error: '⚠️ El tiempo mínimo permitido para la limpieza automática es de 10 minutos (10m).' };
    }

    return {
        ok: true,
        ms,
        formatted: `${val}${label}`
    };
}

/**
 * Establece o actualiza la limpieza programada para un bot/subbot.
 */
function setChatClean(botNum, chatJid, intervalStr, isAll) {
    const parsed = parseInterval(intervalStr);
    if (!parsed.ok) return parsed;

    const bn = getCleanBotNum(botNum);
    const data = loadConfig();
    if (!data[bn]) data[bn] = {};

    const now = Date.now();

    if (isAll) {
        data[bn].all = {
            intervalMs: parsed.ms,
            intervalStr: parsed.formatted,
            lastCleaned: now
        };
    } else {
        if (!data[bn].chats) data[bn].chats = {};
        data[bn].chats[chatJid] = {
            intervalMs: parsed.ms,
            intervalStr: parsed.formatted,
            lastCleaned: now
        };
    }

    dirty = true;
    saveConfig();

    return {
        ok: true,
        botNum: bn,
        intervalStr: parsed.formatted,
        intervalMs: parsed.ms,
        isAll
    };
}

/**
 * Desactiva la limpieza programada para un bot/subbot (todos los chats o este chat).
 */
function disableChatClean(botNum, chatJid, isAll) {
    const bn = getCleanBotNum(botNum);
    const data = loadConfig();
    if (!data[bn]) return { disabled: false };

    let disabled = false;

    if (isAll) {
        if (data[bn].all) {
            delete data[bn].all;
            disabled = true;
        }
    } else {
        if (data[bn].chats && data[bn].chats[chatJid]) {
            delete data[bn].chats[chatJid];
            if (Object.keys(data[bn].chats).length === 0) delete data[bn].chats;
            disabled = true;
        }
    }

    if (Object.keys(data[bn]).length === 0) {
        delete data[bn];
    }

    if (disabled) {
        dirty = true;
        saveConfig();
    }

    return { disabled, botNum: bn, isAll };
}

/**
 * Obtiene el estado actual de la limpieza programada para un bot/subbot y chat.
 */
function getChatCleanStatus(botNum, chatJid) {
    const bn = getCleanBotNum(botNum);
    const data = loadConfig();
    const botConf = data[bn] || {};

    return {
        botNum: bn,
        all: botConf.all || null,
        chat: (botConf.chats && botConf.chats[chatJid]) || null
    };
}

/**
 * Elimina toda la configuración de limpieza de un subbot (al desconectarlo/borrarlo).
 */
function clearSubBotChatClean(botNum) {
    const bn = getCleanBotNum(botNum);
    const data = loadConfig();
    if (data[bn] !== undefined) {
        delete data[bn];
        dirty = true;
        saveConfig();
        console.log(`[chat-clean-scheduler] 🗑️ Configuración de chatclean eliminada para subbot #${botNum}`);
        return true;
    }
    return false;
}

/**
 * Busca el socket activo correspondiente a un botNum.
 */
function getActiveSocket(botNum) {
    const bn = getCleanBotNum(botNum);
    if (bn === 'main') return global.conn;

    if (Array.isArray(global.subConns)) {
        return global.subConns.find(c => c && c.user && getCleanBotNum(c._subNum) === bn) || null;
    }
    return null;
}

/**
 * Revisa periódicamente las programaciones de limpieza y ejecuta la eliminación de chats según corresponda.
 */
async function processScheduledCleanups() {
    const data = loadConfig();
    const botNums = Object.keys(data);
    if (botNums.length === 0) return;

    const now = Date.now();

    for (const bn of botNums) {
        const botConf = data[bn];
        if (!botConf) continue;

        const sock = getActiveSocket(bn);
        if (!sock || typeof sock.chatModify !== 'function') {
            // El subbot no está conectado activamente en este momento
            continue;
        }

        // 1. Procesar limpieza masiva ('all')
        if (botConf.all && typeof botConf.all.intervalMs === 'number') {
            const { intervalMs, lastCleaned = 0 } = botConf.all;
            if (now - lastCleaned >= intervalMs) {
                try {
                    const tracked = chatTracker.getTrackedChats(bn);
                    const chatsToDelete = new Map();

                    for (const item of tracked) {
                        if (item.chatJid && item.key) {
                            chatsToDelete.set(item.chatJid, {
                                key: item.key,
                                messageTimestamp: typeof item.messageTimestamp === 'number' ? item.messageTimestamp : Math.floor(now / 1000)
                            });
                        }
                    }

                    for (const [chatId, lastMsg] of chatsToDelete.entries()) {
                        try {
                            await sock.chatModify(
                                { delete: true, lastMessages: [lastMsg] },
                                chatId
                            );
                        } catch (err) {
                            // Ignorar errores individuales para no interrumpir el resto
                        }
                    }

                    chatTracker.clearTrackedChats(bn);
                    botConf.all.lastCleaned = now;
                    dirty = true;
                    console.log(`[chat-clean-scheduler] 🧹 Limpieza automática 'all' ejecutada para bot #${bn} (${chatsToDelete.size} chats borrados).`);
                } catch (e) {
                    console.error(`[chat-clean-scheduler] Error en limpieza programada 'all' para bot #${bn}:`, e.message);
                }
            }
        }

        // 2. Procesar limpiezas individuales de chats
        if (botConf.chats && typeof botConf.chats === 'object') {
            for (const [chatId, chatConf] of Object.entries(botConf.chats)) {
                if (!chatConf || typeof chatConf.intervalMs !== 'number') continue;
                if (now - (chatConf.lastCleaned || 0) >= chatConf.intervalMs) {
                    try {
                        const trackedList = chatTracker.getTrackedChats(bn);
                        const found = trackedList.find(c => c.chatJid === chatId);
                        const lastMsg = {
                            key: found?.key || { remoteJid: chatId, id: 'CLEAN_' + now, fromMe: true },
                            messageTimestamp: found?.messageTimestamp || Math.floor(now / 1000)
                        };

                        await sock.chatModify(
                            { delete: true, lastMessages: [lastMsg] },
                            chatId
                        );

                        chatTracker.removeTrackedChat(bn, chatId);
                        chatConf.lastCleaned = now;
                        dirty = true;
                        console.log(`[chat-clean-scheduler] 🧹 Limpieza automática ejecutada para chat ${chatId} en bot #${bn}.`);
                    } catch (e) {
                        console.error(`[chat-clean-scheduler] Error en limpieza programada para chat ${chatId} en bot #${bn}:`, e.message);
                    }
                }
            }
        }
    }

    if (dirty) {
        saveConfig();
    }
}

// Iniciar el interval de fondo
const timer = setInterval(() => {
    processScheduledCleanups().catch(err => {
        console.error('[chat-clean-scheduler] Error no manejado en processScheduledCleanups:', err.message);
    });
}, CHECK_INTERVAL_MS);

if (typeof timer.unref === 'function') timer.unref();

module.exports = {
    parseInterval,
    setChatClean,
    disableChatClean,
    getChatCleanStatus,
    clearSubBotChatClean,
    processScheduledCleanups
};
