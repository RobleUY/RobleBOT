'use strict';
/**
 * Plugin: .testcode
 * Genera un código de emparejamiento de 8 dígitos sin necesidad de ingresar el número
 * Funciona en chats privados únicamente
 *
 * Uso: .testcode
 * Uso (WA Business si falla): .testcode 59812345678
 */

const {
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    makeWASocket,
    initAuthCreds
} = require('@whiskeysockets/baileys');
const P = require('pino');

let handler = async (m, { conn = global.conn } = {}) => {
    const sock = m._sock || conn;

    try {
        // Solo en chat privado
        if (m.isGroup || m.chat?.includes('@g.us')) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ Este comando solo funciona en *chat privado*.\n\nEscribeme privado y ejecuta: `.testcode`'
            }, { quoted: m._baileyMessage || m.message });
        }

        let sender = m.sender || m.from || m.author || null;
        let userNumber = null;

        // Si el usuario pasó su número explícitamente (.testcode 59812345678), usarlo
        const textArg = (m.text || m.body || '').trim().split(/\s+/)[1];
        if (textArg && /^\d{7,20}$/.test(textArg)) {
            userNumber = textArg;
        } else if (sender) {
            userNumber = String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        }

        console.log('\n[TestCode] sender:', sender);
        console.log('[TestCode] userNumber:', userNumber);

        if (!userNumber || userNumber.length === 0) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ No se pudo obtener tu número.\n\nIntentá: `.testcode <tu_número>`\nEjemplo: `.testcode 59812345678`'
            }, { quoted: m._baileyMessage || m.message });
        }

        // Resolver LID al número real usando global.mainAuthState
        if (userNumber.length >= 15) {
            try {
                const mapped = global.mainAuthState.keys.get('lid-mapping', [`${userNumber}_reverse`]);
                const realNumber = mapped?.[`${userNumber}_reverse`];
                if (realNumber) {
                    console.log(`[TestCode] LID ${userNumber} resuelto a: ${realNumber}`);
                    userNumber = String(realNumber).replace(/[^0-9]/g, '');
                } else {
                    console.log('[TestCode] LID no encontrado en mapping, usando LID directo');
                }
            } catch (e) {
                console.log('[TestCode] Error resolviendo LID:', e.message);
            }
        }

        // Enviar mensaje de carga
        const loadMsg = await sock.sendMessage(m.from || m.chat, {
            text: '⏳ Generando código de emparejamiento para ti...'
        }, { quoted: m._baileyMessage || m.message });

        const deleteLoadMsg = async () => {
            if (loadMsg?.key) {
                try { await sock.sendMessage(m.from || m.chat, { delete: loadMsg.key }); } catch {}
            }
        };

        // Socket temporal con creds vacías — ahora que tenemos el número real funciona
        const { version } = await fetchLatestBaileysVersion();
        const tempCreds = initAuthCreds();

        // Keys vacías — no necesitamos contexto LID acá porque ya resolvimos el número
        const emptyKeys = {
            get: () => ({}),
            set: () => {}
        };

        const tempSock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['Windows', 'Chrome', '110.0.5585.95'],
            auth: {
                creds: tempCreds,
                keys: makeCacheableSignalKeyStore(emptyKeys, P({ level: 'silent' }))
            },
            msgRetryCounterCache: new Map(),
            retryRequestDelayMs: 100,
            maxMsgRetryCount: 0
        });

        let qrReceived = false;
        let codeGenerated = false;
        let pairingCode = null;
        let timeoutHandle = null;
        let cleanupTimer = null;
        let connected = false;

        const cleanup = () => {
            try {
                if (timeoutHandle) clearTimeout(timeoutHandle);
                if (cleanupTimer) clearTimeout(cleanupTimer);
                tempSock.ev.removeAllListeners();
                if (tempSock.ws) tempSock.ws.close();
            } catch {}
        };

        tempSock.ev.on('connection.update', async (update) => {
            const { qr, connection, lastDisconnect } = update;

            if (connection === 'open') {
                connected = true;
                console.log('[TestCode] Socket temporal conectado correctamente.');
                if (codeGenerated) {
                    await sock.sendMessage(m.from || m.chat, {
                        text: '✅ *Emparejamiento completado*.' +
                              '\n\nTu dispositivo debería quedar vinculado correctamente. Si no, genera un nuevo código con `.testcode`.'
                    }, { quoted: m._baileyMessage || m.message }).catch(() => {});
                }
                return;
            }

            if (connection === 'close' && !connected) {
                const code = lastDisconnect?.error?.output?.statusCode;
                const message = lastDisconnect?.error?.message || 'desconocido';
                console.log(`[TestCode] Conexión temporal cerrada con código ${code}: ${message}`);
                if (code === 401 || code === 428) {
                    console.log('[TestCode] Cierre post-código esperado. Esperando reconexión de Baileys.');
                    return;
                }
            }

            if (qr && !codeGenerated && !qrReceived) {
                qrReceived = true;
                try {
                    console.log(`[TestCode] Solicitando código para ${userNumber}...`);
                    pairingCode = await tempSock.requestPairingCode(userNumber);

                    // Formatear como XXXX-XXXX
                    if (pairingCode && !pairingCode.includes('-')) {
                        pairingCode = pairingCode.match(/.{1,4}/g)?.join('-') || pairingCode;
                    }

                    codeGenerated = true;
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    await deleteLoadMsg();

                    await sock.sendMessage(m.from || m.chat, {
                        text: `✅ *Tu código de emparejamiento es:*\n\n\`\`\`\n${pairingCode}\n\`\`\`\n\n📱 *Cómo usarlo:*\nWhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos para ingresarlo.`
                    }, { quoted: m._baileyMessage || m.message });

                    await sock.sendMessage(m.from || m.chat, {
                        text: pairingCode
                    });

                    cleanupTimer = setTimeout(() => {
                        console.log('[TestCode] Timeout de emparejamiento alcanzado, cerrando socket temporal.');
                        cleanup();
                    }, 120000);

                } catch (e) {
                    console.error('[TestCode] Error solicitando código:', e.message);
                    codeGenerated = true;
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    await deleteLoadMsg();
                    await sock.sendMessage(m.from || m.chat, {
                        text: `❌ Error generando código: ${e.message || 'intenta de nuevo'}`
                    }, { quoted: m._baileyMessage || m.message });
                    cleanup();
                }
            }
        });

        // Timeout de seguridad: 20 segundos
        timeoutHandle = setTimeout(async () => {
            if (!codeGenerated) {
                codeGenerated = true;
                await deleteLoadMsg();
                sock.sendMessage(m.from || m.chat, {
                    text: '⏰ Timeout generando código. Intenta de nuevo.'
                }).catch(() => {});
                cleanup();
            }
        }, 20000);

    } catch (e) {
        console.error('[TestCode] Error general:', e.message);
        await sock.sendMessage(m.from || m.chat, {
            text: `❌ Error: ${e.message || 'intenta de nuevo'}`
        }, { quoted: m._baileyMessage || m.message }).catch(() => {});
    }
};

handler.command = /^testcode$/i;
handler.help = 'Generar código de emparejamiento (8 dígitos) - Solo para probar subbots';
handler.tags = ['subbots', 'testing'];

module.exports = handler;