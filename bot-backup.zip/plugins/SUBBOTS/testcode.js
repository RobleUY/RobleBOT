'use strict';
/**
 * Plugin: .testcode
 * Genera un código de emparejamiento de 8 dígitos sin necesidad de ingresar el número
 * Funciona en chats privados Y en grupos
 * 
 * Uso: .testcode
 */

const {
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    makeWASocket
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs = require('fs');
const path = require('path');
const P = require('pino');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

let handler = async (m, { conn = global.conn } = {}) => {
    const sock = m._sock || conn;
    
    try {
        // Extraer el número del usuario que ejecuta el comando
        let userNumber = null;
        
        // Obtener el sender y limpiarlo correctamente
        let sender = m.sender || m.from || m.author || null;
        if (sender) {
            // Limpiar: extraer solo números (igual que numOnly en GataBot)
            userNumber = String(sender).split('@')[0].replace(/[^0-9]/g, '');
        }
        
        // Validar que sea un número de teléfono válido (7-15 dígitos)
        if (!userNumber || userNumber.length < 7 || userNumber.length > 15) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ Error: No se pudo obtener tu número de teléfono válido.\n\n_Si estás en un grupo, intenta usar el comando en privado._'
            }, { quoted: m._baileyMessage || m.message });
        }

        // Enviar mensaje de carga
        const loadMsg = await sock.sendMessage(m.from || m.chat, {
            text: '⏳ Generando código de emparejamiento para ti...'
        }, { quoted: m._baileyMessage || m.message });

        // Crear socket temporal para solicitar el código
        const { version } = await fetchLatestBaileysVersion();
        
        const authState = await useSQLiteAuthState(
            path.join(SESSIONS_DIR, 'temp_testcode.db')
        );
        
        const tempSock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['Chrome', 'Chrome', '120'],
            auth: {
                creds: authState.state.creds,
                keys: makeCacheableSignalKeyStore(
                    authState.state.keys,
                    P({ level: 'silent' })
                )
            },
            msgRetryCounterCache: new Map(),
            retryRequestDelayMs: 100,
            maxMsgRetryCount: 0
        });

        // Variables para rastrear el proceso
        let qrReceived = false;
        let codeGenerated = false;
        let pairingCode = null;
        let timeoutHandle = null;

        // Escuchar actualizaciones de conexión
        tempSock.ev.on('connection.update', async (update) => {
            const { connection, qr } = update;

            // Cuando llegue el QR, solicitar el código de emparejamiento
            if (qr && !codeGenerated && !qrReceived) {
                qrReceived = true;
                try {
                    console.log(`[TestCode] Solicitando código para ${userNumber}...`);
                    pairingCode = await tempSock.requestPairingCode(userNumber);

                    if (pairingCode && pairingCode.length === 8) {
                        codeGenerated = true;
                        
                        if (timeoutHandle) clearTimeout(timeoutHandle);
                        
                        // Eliminar el mensaje de carga
                        if (loadMsg?.key) {
                            try {
                                await sock.sendMessage(m.from || m.chat, {
                                    delete: loadMsg.key
                                });
                            } catch {}
                        }

                        // Enviar el código en mensaje
                        await sock.sendMessage(m.from || m.chat, {
                            text: `✅ *Tu código de emparejamiento es:*\n\n\`\`\`\n${pairingCode}\n\`\`\`\n\n📱 *Cómo usarlo:*\nWhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos para ingresarlo.`
                        }, { quoted: m._baileyMessage || m.message });

                        // Cerrar socket después de enviar
                        setTimeout(() => {
                            try {
                                tempSock.ev.removeAllListeners();
                                tempSock.ws.close();
                            } catch {}
                        }, 1000);
                    }
                } catch (e) {
                    console.error('[TestCode] Error solicitando código:', e.message);
                    codeGenerated = true;
                    
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    
                    // Eliminar mensaje de carga
                    if (loadMsg?.key) {
                        try {
                            await sock.sendMessage(m.from || m.chat, {
                                delete: loadMsg.key
                            });
                        } catch {}
                    }
                    
                    await sock.sendMessage(m.from || m.chat, {
                        text: `❌ Error generando código: ${e.message || 'intenta de nuevo'}`
                    }, { quoted: m._baileyMessage || m.message });
                    
                    try {
                        tempSock.ev.removeAllListeners();
                        tempSock.ws.close();
                    } catch {}
                }
            }
        });

        // Timeout de seguridad: 20 segundos
        timeoutHandle = setTimeout(() => {
            if (!codeGenerated) {
                codeGenerated = true;
                if (loadMsg?.key) {
                    sock.sendMessage(m.from || m.chat, {
                        delete: loadMsg.key
                    }).catch(() => {});
                }
                sock.sendMessage(m.from || m.chat, {
                    text: '⏰ Timeout generando código. Intenta de nuevo.'
                }).catch(() => {});
                try {
                    tempSock.ev.removeAllListeners();
                    tempSock.ws.close();
                } catch {}
            }
        }, 20000);

    } catch (e) {
        console.error('[TestCode] Error general:', e.message);
        await sock.sendMessage(m.from || m.chat, {
            text: `❌ Error: ${e.message || 'intenta de nuevo'}`
        }, { quoted: m._baileyMessage || m.message }).catch(() => {});
    }
};

handler.command = /^testcode$/i;
handler.help = 'Generar código de emparejamiento (8 dígitos) - Solo para probar subbots';
handler.tags = ['subbots', 'testing'];

module.exports = handler;
