'use strict';
/**
 * Plugin: .testcode
 * Genera un código de emparejamiento de 8 dígitos sin necesidad de ingresar el número
 * Funciona en chats privados Y en grupos
 * 
 * Uso: .testcode
 */

const {
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    makeWASocket
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs = require('fs');
const path = require('path');
const P = require('pino');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

let handler = async (m, { conn = global.conn } = {}) => {
    const sock = m._sock || conn;
    
    try {
        // ✅ SOLO en chat privado (como .serbot qr)
        if (m.isGroup || m.chat?.includes('@g.us')) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ Este comando solo funciona en *chat privado*.\n\nEscribeme privado y ejecuta: `.testcode`'
            }, { quoted: m._baileyMessage || m.message });
        }

        // DEBUG: Mostrar exactamente qué se está recibiendo
        console.log('\n[TestCode] DEBUG:');
        console.log('m.sender:', m.sender);
        console.log('m.from:', m.from);
        console.log('m.author:', m.author);
        console.log('m.chat:', m.chat);
        console.log('m.isGroup:', m.isGroup);
        
        // Extraer el número correcto del usuario en privado
        let userNumber = null;
        let sender = m.sender || m.from || m.author || null;
        
        if (sender) {
            // En privado: el formato es senderJid.split('@')[0].split(':')[0]
            // Esto maneja formatos como "5218xxxxxxxx:26@s.whatsapp.net"
            userNumber = String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        }
        
        console.log('sender extraído:', sender);
        console.log('userNumber extraído:', userNumber);
        console.log('userNumber length:', userNumber?.length);
        
        // Validar que sea un número de teléfono válido (7-15 dígitos)
        if (!userNumber || userNumber.length < 7 || userNumber.length > 15) {
            const debugMsg = 
                `❌ Error obteniendo tu número.\n\n` +
                `📊 *Debug Info:*\n` +
                `• sender: \`${sender}\`\n` +
                `• userNumber: \`${userNumber}\`\n` +
                `• length: ${userNumber?.length}\n\n` +
                `El número debe tener entre 7 y 15 dígitos.\n\n` +
                `Intenta con: \`.serbot code <tu_numero>\``;
            
            return sock.sendMessage(m.from || m.chat, {
                text: debugMsg
            }, { quoted: m._baileyMessage || m.message });
        }

        // Enviar mensaje de carga
        const loadMsg = await sock.sendMessage(m.from || m.chat, {
            text: '⏳ Generando código de emparejamiento para ti...'
        }, { quoted: m._baileyMessage || m.message });

        // Crear socket temporal para solicitar el código
        const { version } = await fetchLatestBaileysVersion();
        
        const authState = await useSQLiteAuthState(
            path.join(SESSIONS_DIR, 'temp_testcode.db')
        );
        
        const tempSock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['Chrome', 'Chrome', '120'],
            auth: {
                creds: authState.state.creds,
                keys: makeCacheableSignalKeyStore(
                    authState.state.keys,
                    P({ level: 'silent' })
                )
            },
            msgRetryCounterCache: new Map(),
            retryRequestDelayMs: 100,
            maxMsgRetryCount: 0
        });

        // Variables para rastrear el proceso
        let qrReceived = false;
        let codeGenerated = false;
        let pairingCode = null;
        let timeoutHandle = null;

        // Escuchar actualizaciones de conexión
        tempSock.ev.on('connection.update', async (update) => {
            const { connection, qr } = update;

            // Cuando llegue el QR, solicitar el código de emparejamiento
            if (qr && !codeGenerated && !qrReceived) {
                qrReceived = true;
                try {
                    console.log(`[TestCode] Solicitando código para ${userNumber}...`);
                    pairingCode = await tempSock.requestPairingCode(userNumber);

                    if (pairingCode && pairingCode.length === 8) {
                        codeGenerated = true;
                        
                        if (timeoutHandle) clearTimeout(timeoutHandle);
                        
                        // Eliminar el mensaje de carga
                        if (loadMsg?.key) {
                            try {
                                await sock.sendMessage(m.from || m.chat, {
                                    delete: loadMsg.key
                                });
                            } catch {}
                        }

                        // Enviar el código en mensaje
                        await sock.sendMessage(m.from || m.chat, {
                            text: `✅ *Tu código de emparejamiento es:*\n\n\`\`\`\n${pairingCode}\n\`\`\`\n\n📱 *Cómo usarlo:*\nWhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos para ingresarlo.`
                        }, { quoted: m._baileyMessage || m.message });

                        // Cerrar socket después de enviar
                        setTimeout(() => {
                            try {
                                tempSock.ev.removeAllListeners();
                                tempSock.ws.close();
                            } catch {}
                        }, 1000);
                    }
                } catch (e) {
                    console.error('[TestCode] Error solicitando código:', e.message);
                    codeGenerated = true;
                    
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    
                    // Eliminar mensaje de carga
                    if (loadMsg?.key) {
                        try {
                            await sock.sendMessage(m.from || m.chat, {
                                delete: loadMsg.key
                            });
                        } catch {}
                    }
                    
                    await sock.sendMessage(m.from || m.chat, {
                        text: `❌ Error generando código: ${e.message || 'intenta de nuevo'}`
                    }, { quoted: m._baileyMessage || m.message });
                    
                    try {
                        tempSock.ev.removeAllListeners();
                        tempSock.ws.close();
                    } catch {}
                }
            }
        });

        // Timeout de seguridad: 20 segundos
        timeoutHandle = setTimeout(() => {
            if (!codeGenerated) {
                codeGenerated = true;
                if (loadMsg?.key) {
                    sock.sendMessage(m.from || m.chat, {
                        delete: loadMsg.key
                    }).catch(() => {});
                }
                sock.sendMessage(m.from || m.chat, {
                    text: '⏰ Timeout generando código. Intenta de nuevo.'
                }).catch(() => {});
                try {
                    tempSock.ev.removeAllListeners();
                    tempSock.ws.close();
                } catch {}
            }
        }, 20000);

    } catch (e) {
        console.error('[TestCode] Error general:', e.message);
        await sock.sendMessage(m.from || m.chat, {
            text: `❌ Error: ${e.message || 'intenta de nuevo'}`
        }, { quoted: m._baileyMessage || m.message }).catch(() => {});
    }
};

handler.command = /^testcode$/i;
handler.help = 'Generar código de emparejamiento (8 dígitos) - Solo para probar subbots';
handler.tags = ['subbots', 'testing'];

module.exports = handler;
