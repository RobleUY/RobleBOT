'use strict';
/**
 * Plugin: .testcode
 * Genera un código de emparejamiento de 8 dígitos sin necesidad de ingresar el número
 * Funciona en chats privados únicamente
 * 
 * Uso: .testcode
 * Uso (WA Business si falla): .testcode 59812345678
 */

const {
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    makeWASocket
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState');
const fs = require('fs');
const path = require('path');
const P = require('pino');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

let handler = async (m, { conn = global.conn } = {}) => {
    const sock = m._sock || conn;
    
    try {
        // Solo en chat privado
        if (m.isGroup || m.chat?.includes('@g.us')) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ Este comando solo funciona en *chat privado*.\n\nEscribeme privado y ejecuta: `.testcode`'
            }, { quoted: m._baileyMessage || m.message });
        }

        let sender = m.sender || m.from || m.author || null;

        // Extraer userNumber igual que jadibot-serbot:
        // Tomar todo lo que haya antes del @ y antes de ":", solo dígitos.
        // Funciona tanto para @s.whatsapp.net como para @lid (ID largo de Meta).
        let userNumber = null;

        // Si el usuario pasó su número explícitamente (.testcode 59812345678), usarlo
        const textArg = (m.text || m.body || '').trim().split(/\s+/)[1];
        if (textArg && /^\d{7,20}$/.test(textArg)) {
            userNumber = textArg;
        } else if (sender) {
            // Extraer igual que jadibot-serbot: split('@')[0] sin validar longitud
            userNumber = String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        }

        console.log('\n[TestCode] sender:', sender);
        console.log('[TestCode] userNumber:', userNumber);

        if (!userNumber || userNumber.length === 0) {
            return sock.sendMessage(m.from || m.chat, {
                text: '❌ No se pudo obtener tu número.\n\nIntentá: `.testcode <tu_número>`\nEjemplo: `.testcode 59812345678`'
            }, { quoted: m._baileyMessage || m.message });
        }

        // Enviar mensaje de carga
        const loadMsg = await sock.sendMessage(m.from || m.chat, {
            text: '⏳ Generando código de emparejamiento para ti...'
        }, { quoted: m._baileyMessage || m.message });

        // Crear socket temporal para solicitar el código
        const { version } = await fetchLatestBaileysVersion();

        // Copiar main-session.db a un archivo temporal para que el socket temporal
        // tenga el mapeo LID↔número real que ya tiene el bot principal.
        // Sin esto, sesiones @lid no se pueden resolver y el pairing code falla.
        const mainDbPath = path.resolve(__dirname, '../../main-session.db');
        const tempDbPath = path.join(SESSIONS_DIR, `temp_testcode_${Date.now()}.db`);
        if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
        if (fs.existsSync(mainDbPath)) {
            fs.copyFileSync(mainDbPath, tempDbPath);
        }

        const authState = await useSQLiteAuthState(tempDbPath);
        
        const tempSock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['Windows', 'Chrome', '110.0.5585.95'],
            auth: {
                creds: authState.state.creds,
                keys: makeCacheableSignalKeyStore(
                    authState.state.keys,
                    P({ level: 'silent' })
                )
            },
            msgRetryCounterCache: new Map(),
            retryRequestDelayMs: 100,
            maxMsgRetryCount: 0
        });

        let qrReceived = false;
        let codeGenerated = false;
        let pairingCode = null;
        let timeoutHandle = null;

        const cleanup = () => {
            try {
                tempSock.ev.removeAllListeners();
                tempSock.ws.close();
            } catch {}
            // Borrar el .db temporal
            try { if (fs.existsSync(tempDbPath)) fs.unlinkSync(tempDbPath); } catch {}
        };

        const deleteLoadMsg = async () => {
            if (loadMsg?.key) {
                try {
                    await sock.sendMessage(m.from || m.chat, { delete: loadMsg.key });
                } catch {}
            }
        };

        tempSock.ev.on('connection.update', async (update) => {
            const { qr } = update;

            if (qr && !codeGenerated && !qrReceived) {
                qrReceived = true;
                try {
                    console.log(`[TestCode] Solicitando código para ${userNumber}...`);

                    // Pasamos userNumber directo sin validar longitud,
                    // igual que jadibot-serbot con fixTe — WA acepta el LID igual
                    pairingCode = await tempSock.requestPairingCode(userNumber);

                    // Formatear como XXXX-XXXX si viene sin guión
                    if (pairingCode && !pairingCode.includes('-')) {
                        pairingCode = pairingCode.match(/.{1,4}/g)?.join('-') || pairingCode;
                    }

                    codeGenerated = true;
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    await deleteLoadMsg();

                    await sock.sendMessage(m.from || m.chat, {
                        text: `✅ *Tu código de emparejamiento es:*\n\n\`\`\`\n${pairingCode}\n\`\`\`\n\n📱 *Cómo usarlo:*\nWhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos para ingresarlo.`
                    }, { quoted: m._baileyMessage || m.message });

                    setTimeout(cleanup, 1000);

                } catch (e) {
                    console.error('[TestCode] Error solicitando código:', e.message);
                    codeGenerated = true;
                    if (timeoutHandle) clearTimeout(timeoutHandle);
                    await deleteLoadMsg();
                    await sock.sendMessage(m.from || m.chat, {
                        text: `❌ Error generando código: ${e.message || 'intenta de nuevo'}`
                    }, { quoted: m._baileyMessage || m.message });
                    cleanup();
                }
            }
        });

        // Timeout de seguridad: 20 segundos
        timeoutHandle = setTimeout(async () => {
            if (!codeGenerated) {
                codeGenerated = true;
                await deleteLoadMsg();
                sock.sendMessage(m.from || m.chat, {
                    text: '⏰ Timeout generando código. Intenta de nuevo.'
                }).catch(() => {});
                cleanup();
            }
        }, 20000);

    } catch (e) {
        console.error('[TestCode] Error general:', e.message);
        await sock.sendMessage(m.from || m.chat, {
            text: `❌ Error: ${e.message || 'intenta de nuevo'}`
        }, { quoted: m._baileyMessage || m.message }).catch(() => {});
    }
};

handler.command = /^testcode$/i;
handler.help = 'Generar código de emparejamiento (8 dígitos) - Solo para probar subbots';
handler.tags = ['subbots', 'testing'];

module.exports = handler;