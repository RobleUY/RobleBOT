'use strict';

const activityTracker = require('./subbotActivityTracker');

const topBotsHandler = {
    command: /^(topbots|topb|topsubbot|topsubbots)$/i,
    help: ['topbots - Ver ranking de subbots por comandos ejecutados'],
    tags: ['subbots'],
    handler: async (message) => {
        const sock = message._sock || global.conn;

        // ── Recopilar datos de todos los subbots con sesión registrada ───────
        // Incluye conectados y desconectados (para que el ranking sea completo)
        const fs   = require('fs');
        const path = require('path');
        const SESSIONS_DIR = path.join(__dirname, 'sesiones');

        // IDs con sesión guardada en disco
        let registeredNums = [];
        try {
            if (fs.existsSync(SESSIONS_DIR)) {
                registeredNums = fs.readdirSync(SESSIONS_DIR)
                    .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
                    .filter(n => !isNaN(n));
            }
        } catch (_) {}

        if (registeredNums.length === 0)
            return sock.sendMessage(message.from, { text: '📭 No hay sub-bots registrados.' }, { quoted: message._baileyMessage });

        // IDs actualmente conectados (para marcar estado)
        const connectedNums = new Set(
            (global.subConns || []).filter(c => c?.user && c._subNum != null).map(c => c._subNum)
        );

        // Construir lista con stats
        const bots = registeredNums.map(n => {
            const stats   = activityTracker.getActivityStats(n);
            const online  = connectedNums.has(n);
            // Buscar número de teléfono si está conectado
            const subConn = (global.subConns || []).find(c => c._subNum === n);
            const phone   = subConn?.user?.id?.split('@')[0]?.split(':')[0] || null;
            return {
                num:          n,
                commandCount: stats.commandCount || 0,
                online,
                phone
            };
        });

        // Ordenar: primero por comandos desc, luego por num asc como desempate
        bots.sort((a, b) => b.commandCount - a.commandCount || a.num - b.num);

        const totalCmds = bots.reduce((sum, b) => sum + b.commandCount, 0);

        // ── Construir mensaje ─────────────────────────────────────────────────
        const medals = ['🥇', '🥈', '🥉'];

        const lines = bots.map((bot, i) => {
            const medal    = medals[i] || `${i + 1}.`;
            const status   = bot.online ? '🟢' : '🔴';
            const pct      = totalCmds > 0 ? ((bot.commandCount / totalCmds) * 100).toFixed(1) : '0.0';
            const phoneLine = bot.phone ? `\n   📱 wa.me/+${bot.phone}` : '';
            return `${medal} ${status} *SubBot #${bot.num}*${phoneLine}\n   ⚡ Comandos: *${bot.commandCount.toLocaleString()}* _(${pct}%)_`;
        });

        const text = [
            `*🏆 TOP SUBBOTS — COMANDOS EJECUTADOS*`,
            ``,
            lines.join('\n\n'),
            ``,
            `━━━━━━━━━━━━━━━━━━━━`,
            `📊 *Total ejecutados:* ${totalCmds.toLocaleString()} comandos`,
            `🤖 *Subbots registrados:* ${bots.length}`
        ].join('\n');

        sock.sendMessage(message.from, { text }, { quoted: message._baileyMessage });
    }
};

module.exports = topBotsHandler;
