'use strict';

// ── Comando .borrarchat ───────────────────────────────────────────────────
// Borra el chat actual O todos los chats (.borrarchat all) de la lista del bot (o subbot).
// NO borra mensajes "para todos", NO afecta lo que ve la otra persona.

const chatTracker = require('./chat-tracker');

// ── Helper: verificar owner del subbot o owner principal ────────────────────
function isBotOwner(message, sock) {
    if (message.key?.fromMe) return true;
    const senderNum = (message.sender || message.author || message.from || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const ownerNum  = (sock?._ownerJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return Boolean(senderNum && ownerNum && senderNum === ownerNum);
}

const borrarChatHandler = async (message, { conn, text, args } = {}) => {
    try {
        const sock = message._sock || conn;
        if (!sock || typeof sock.chatModify !== 'function') {
            return message.reply('❌ No tengo acceso a la conexión del bot ahora mismo.').catch(() => {});
        }

        // Solo el dueño del bot/subbot puede usar este comando
        if (!isBotOwner(message, sock)) {
            return message.reply('🚫 Este comando es solo para el dueño del bot.').catch(() => {});
        }

        const param = (args?.[0] || text || '').trim().toLowerCase();
        const isAll = param === 'all' || param === 'todos';
        const botNum = message._subNum || sock?._subNum || 'main';

        if (isAll) {
            const tracked = chatTracker.getTrackedChats(botNum);
            const chatsToDelete = new Map();

            for (const item of tracked) {
                if (item.chatJid && item.key) {
                    chatsToDelete.set(item.chatJid, {
                        key: item.key,
                        messageTimestamp: typeof item.messageTimestamp === 'number' ? item.messageTimestamp : Math.floor(Date.now() / 1000)
                    });
                }
            }

            const currentChatId = message.from || message.key?.remoteJid;
            if (currentChatId && !chatsToDelete.has(currentChatId)) {
                const raw = message._baileyMessage || {};
                chatsToDelete.set(currentChatId, {
                    key: raw.key || message.key,
                    messageTimestamp: raw.messageTimestamp || Math.floor(Date.now() / 1000)
                });
            }

            if (chatsToDelete.size === 0) {
                return message.reply('⚠️ No hay chats registrados para eliminar.').catch(() => {});
            }

            let successCount = 0;
            let failCount = 0;

            for (const [chatId, lastMsg] of chatsToDelete.entries()) {
                try {
                    await sock.chatModify(
                        {
                            delete: true,
                            lastMessages: [lastMsg]
                        },
                        chatId
                    );
                    successCount++;
                } catch (err) {
                    failCount++;
                    console.error(`[borrarchat] Error al borrar chat ${chatId}:`, err.message);
                }
            }

            chatTracker.clearTrackedChats(botNum);
            console.log(`[borrarchat] Eliminación masiva finalizada para bot ${botNum}: ${successCount} chats borrados, ${failCount} fallidos.`);

        } else {
            const chatId = message.from || message.key?.remoteJid;
            if (!chatId) return;

            const raw = message._baileyMessage || {};
            const lastMsg = {
                key: raw.key || message.key,
                messageTimestamp: raw.messageTimestamp || Math.floor(Date.now() / 1000)
            };

            if (!lastMsg.key) {
                return message.reply('❌ No pude identificar el último mensaje de este chat.').catch(() => {});
            }

            await sock.chatModify(
                {
                    delete: true,
                    lastMessages: [lastMsg]
                },
                chatId
            );

            chatTracker.removeTrackedChat(botNum, chatId);
            console.log(`[borrarchat] Chat ${chatId} eliminado de la lista del bot (${botNum}).`);
        }

    } catch (error) {
        console.error('[borrarchat] Error:', error.message);
        try {
            await message.reply('❌ No pude borrar el/los chat(s) (puede que WhatsApp lo haya rechazado).');
        } catch (_) {}
    }
};

borrarChatHandler.help    = ['borrarchat', 'borrarchat all'];
borrarChatHandler.tags    = ['owner', 'subbots'];
borrarChatHandler.command = /^(borrarchat|delchat|eliminarchat)$/i;

module.exports = borrarChatHandler;