'use strict';

// ── Comando .borrarchat / .borrarchat all ────────────────────────────────
// .borrarchat      → borra SOLO el chat actual de la lista del bot (o subbot).
// .borrarchat all  → borra TODOS los chats que el bot conoce (ver chat-tracker.js).
// En ambos casos: NO borra mensajes "para todos", NO afecta lo que ve la
// otra persona. Es el equivalente a que el bot le dé "Eliminar chat" desde
// su propia app de WhatsApp, uno por uno.
//
// Requiere chat-tracker.js en la misma carpeta (plugins/chat-tracker.js) y
// que esté "alimentado" desde index.js / subbot-serbot.js (ver snippet al
// final de este archivo / del mensaje).
//
// Ubicación: plugins/SUBBOTS/borrar-chat.js
// (si lo movés a otra carpeta, ajustá el require('../../config') de abajo
//  según cuántos niveles subas hasta la raíz del proyecto)

let chatTracker = null;
try { chatTracker = require('./chat-tracker'); } catch (e) { /* opcional para .borrarchat simple */ }

// ── Helper: verificar owner del subbot o owner principal ────────────────────
function isBotOwner(message, sock) {
    if (message.key?.fromMe) return true;
    const senderNum = (message.sender || message.author || '').split('@')[0].split(':')[0];
    const ownerNum  = (sock?._ownerJid || '').split('@')[0].split(':')[0];
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return Boolean(senderNum && ownerNum && senderNum === ownerNum);
}

function buildLastMsg(message) {
    const raw = message._baileyMessage || {};
    return {
        key: raw.key || message.key,
        messageTimestamp: raw.messageTimestamp || Math.floor(Date.now() / 1000)
    };
}

const borrarChatHandler = async (message, { conn, args = [] } = {}) => {
    try {
        const sock = message._sock || conn;
        if (!sock || typeof sock.chatModify !== 'function') {
            return message.reply('❌ No tengo acceso a la conexión del bot ahora mismo.').catch(() => {});
        }

        // Solo el dueño del bot/subbot puede usar este comando
        if (!isBotOwner(message, sock)) {
            return message.reply('🚫 Este comando es solo para el dueño del bot.').catch(() => {});
        }

        const wantsAll = ['all', 'todos'].includes((args[0] || '').toLowerCase());
        const botNum   = message._subNum || sock._subNum || 'main';

        // ── Modo simple: solo este chat ─────────────────────────────────
        if (!wantsAll) {
            const chatId = message.from || message.key?.remoteJid;
            if (!chatId) return;

            const lastMsg = buildLastMsg(message);
            if (!lastMsg.key) {
                return message.reply('❌ No pude identificar el último mensaje de este chat.').catch(() => {});
            }

            await sock.chatModify({ delete: true, lastMessages: [lastMsg] }, chatId);
            if (chatTracker) chatTracker.removeTrackedChat(botNum, chatId);

            console.log(`[borrarchat] Chat ${chatId} eliminado de la lista del bot.`);
            await message.reply('✅ Chat eliminado por completo.').catch(() => {});
            return;
        }

        // ── Modo "all": borrar todos los chats conocidos ────────────────
        if (!chatTracker) {
            return message.reply('❌ Falta chat-tracker.js (o no está integrado). No puedo listar todos los chats.').catch(() => {});
        }

        const chatId = message.from || message.key?.remoteJid;
        const tracked = chatTracker.getTrackedChats(botNum);
        const map = new Map(tracked.map(c => [c.chatJid, c]));
        if (chatId) {
            map.set(chatId, { chatJid: chatId, ...buildLastMsg(message) });
        }
        const targets = Array.from(map.values());

        if (targets.length === 0) {
            return message.reply('ℹ️ Todavía no tengo chats registrados para borrar.').catch(() => {});
        }

        let ok = 0, fail = 0;
        for (const t of targets) {
            try {
                await sock.chatModify(
                    { delete: true, lastMessages: [{ key: t.key, messageTimestamp: t.messageTimestamp }] },
                    t.chatJid
                );
                chatTracker.removeTrackedChat(botNum, t.chatJid);
                ok++;
            } catch (e) {
                fail++;
                console.error(`[borrarchat all] Error borrando ${t.chatJid}:`, e.message);
            }
            // Pausa chica entre borrados para no floodear a WhatsApp
            await new Promise(r => setTimeout(r, 350));
        }

        // Avisamos en el chat donde se pidió el comando (si sobrevivió al loop,
        // ya se recreó con este único mensaje; si no, igual va a intentar mandarlo).
        await message.reply(`✅ Listo. Se eliminaron ${ok} chats${fail ? ` (${fail} fallaron, revisá la consola)` : ''}.`).catch(() => {});

    } catch (error) {
        console.error('[borrarchat] Error:', error.message);
        try {
            await message.reply('❌ No pude borrar el/los chat(s) (puede que WhatsApp lo haya rechazado).');
        } catch (_) {}
    }
};

borrarChatHandler.help    = ['borrarchat', 'borrarchat all'];
borrarChatHandler.tags    = ['owner', 'subbots'];
borrarChatHandler.command = /^(borrarchat|delchat|eliminarchat)$/i;

module.exports = borrarChatHandler;