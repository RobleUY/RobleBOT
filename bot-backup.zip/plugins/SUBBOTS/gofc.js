'use strict';

/**
 * Comando .gofc subbots on/off
 * ─────────────────────────────────────────────────────────────────────────────
 * Permite a los owners (config.js) activar o desactivar que UN subbot
 * pueda responder en el grupo oficial (OFFICIAL_GROUP).
 *
 * Cuando está ON:  un solo subbot (el de _subNum más bajo que esté conectado
 *                  y funcional) responde junto al bot principal.
 * Cuando está OFF: los subbots NO responden en el grupo oficial (comportamiento
 *                  por defecto).
 *
 * Uso:
 *   .gofc subbots on
 *   .gofc subbots off
 *   .gofc (muestra estado actual)
 *
 * Solo ejecutable por owners del config.js. Puede usarse desde cualquier chat.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const fs   = require('fs');
const path = require('path');

// ── Archivo de estado ─────────────────────────────────────────────────────────
const DATA_DIR   = path.join(__dirname, 'data');
const GOFC_FILE  = path.join(DATA_DIR, 'gofc-state.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Caché en memoria ──────────────────────────────────────────────────────────
let _cache = null;
let _mtime = 0;

function loadState() {
    try {
        if (fs.existsSync(GOFC_FILE)) {
            const mtime = fs.statSync(GOFC_FILE).mtimeMs;
            if (_cache !== null && mtime === _mtime) return _cache;
            _cache = JSON.parse(fs.readFileSync(GOFC_FILE, 'utf8'));
            _mtime = mtime;
            return _cache;
        }
    } catch (e) {
        console.error('[gofc] Error cargando estado:', e.message);
    }
    _cache = { enabled: false };
    return _cache;
}

function saveState(data) {
    try {
        fs.writeFileSync(GOFC_FILE, JSON.stringify(data, null, 2), 'utf8');
        _cache = data;
        _mtime = fs.statSync(GOFC_FILE).mtimeMs;
        return true;
    } catch (e) {
        console.error('[gofc] Error guardando estado:', e.message);
        return false;
    }
}

/**
 * Devuelve true si los subbots están habilitados para responder en el grupo oficial.
 * Función pública usada por subbot-serbot.js
 */
function isGofcEnabled() {
    return loadState().enabled === true;
}

// ── Handler principal ─────────────────────────────────────────────────────────
const gofcHandler = async (message) => {
    try {
        const botConfig = global.botConfig || require('../../config');

        // ── Verificar que el usuario es owner del config.js ──────────────────
        const senderRaw = message.author || message.sender || message.from || '';
        const senderNum = senderRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Parsear argumentos ────────────────────────────────────────────────
        const rawBody = (message.body || message.text || '').trim();
        const parts   = rawBody.split(/\s+/).slice(1); // quitar el prefijo+comando
        const sub1    = (parts[0] || '').toLowerCase(); // "subbots"
        const sub2    = (parts[1] || '').toLowerCase(); // "on" / "off"

        const state = loadState();

        // ── Sin argumentos: mostrar estado ───────────────────────────────────
        if (!sub1) {
            const estadoTxt = state.enabled ? '✅ *ON* — Un subbot puede responder en el grupo oficial' : '❌ *OFF* — Los subbots NO responden en el grupo oficial';
            let txt  = `🏠 *Estado GOFC (Grupo Oficial)*\n\n`;
            txt += `${estadoTxt}\n\n`;
            txt += `💡 *Comandos:*\n`;
            txt += `  • *.gofc subbots on* → Activar subbot en grupo oficial\n`;
            txt += `  • *.gofc subbots off* → Desactivar subbot en grupo oficial`;
            return await message.reply(txt);
        }

        // ── Validar argumento ─────────────────────────────────────────────────
        if (sub1 !== 'subbots') {
            return await message.reply('⚠️ Uso correcto:\n  *.gofc subbots on*\n  *.gofc subbots off*');
        }

        const isOn  = ['on', 'si', 'sí', 'activar', 'encender'].includes(sub2);
        const isOff = ['off', 'no', 'desactivar', 'apagar'].includes(sub2);

        if (!isOn && !isOff) {
            return await message.reply('⚠️ Uso correcto:\n  *.gofc subbots on*\n  *.gofc subbots off*');
        }

        // ── Aplicar cambio ────────────────────────────────────────────────────
        state.enabled = isOn;

        if (!saveState(state)) {
            return await message.reply('❌ Error al guardar la configuración.');
        }

        if (isOn) {
            // Determinar qué subbot va a responder (el de _subNum más bajo conectado)
            const activeSubs = (global.subConns || []).filter(c => c?.user && c._subNum != null);
            let subbotInfo   = '';
            if (activeSubs.length > 0) {
                const lowestNum = Math.min(...activeSubs.map(c => c._subNum));
                const sub       = activeSubs.find(c => c._subNum === lowestNum);
                const subPhone  = sub?.user?.id?.split('@')[0]?.split(':')[0] || '?';
                subbotInfo = `\n📱 *Sub-bot activo:* #${lowestNum} (wa.me/+${subPhone})`;
            } else {
                subbotInfo = '\n⚠️ _No hay subbots conectados actualmente. Cuando se conecte uno, el de menor número responderá._';
            }

            let msg  = `✅ *GOFC activado*\n\n`;
            msg += `Un subbot ahora puede responder en el *grupo oficial*.${subbotInfo}\n\n`;
            msg += `ℹ️ Solo responde UN subbot (el de número más bajo) para evitar conflictos.\n`;
            msg += `💡 Para desactivar: *.gofc subbots off*`;
            return await message.reply(msg);
        } else {
            let msg  = `❌ *GOFC desactivado*\n\n`;
            msg += `Los subbots ya *no responden* en el grupo oficial.\n\n`;
            msg += `💡 Para activar: *.gofc subbots on*`;
            return await message.reply(msg);
        }

    } catch (error) {
        console.error('[gofc] Error en comando:', error.message);
        await message.reply('❌ Error interno al ejecutar el comando.');
    }
};

gofcHandler.help    = ['gofc'];
gofcHandler.tags    = ['owner', 'subbots'];
gofcHandler.command = /^gofc$/i;
gofcHandler.owner   = false; // La verificación la hacemos manualmente (config.js owners)

// ── Exports ───────────────────────────────────────────────────────────────────
module.exports         = gofcHandler;
module.exports.isGofcEnabled = isGofcEnabled;
