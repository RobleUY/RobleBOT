'use strict';

/**
 * Comando .gofc — Gestión de subbots permitidos en el Grupo Oficial
 * ─────────────────────────────────────────────────────────────────────────────
 * Los subbots que estén en la lista blanca (gofc-subbots.json) pueden
 * responder en el grupo oficial (OFFICIAL_GROUP). Los que NO estén en la
 * lista, no responden ahí (comportamiento por defecto).
 *
 * Uso:
 *   .gofc                        → Muestra la lista actual
 *   .gofc add <número>           → Agrega un subbot a la lista blanca
 *   .gofc remove <número>        → Quita un subbot de la lista blanca
 *   .gofc list                   → Lista los subbots permitidos
 *
 * Solo ejecutable por owners del config.js. Puede usarse desde cualquier chat.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const fs   = require('fs');
const path = require('path');

// ── Archivo de lista blanca ───────────────────────────────────────────────────
const DATA_DIR        = path.join(__dirname, 'data');
const GOFC_FILE       = path.join(DATA_DIR, 'gofc-subbots.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Helpers de lectura/escritura ──────────────────────────────────────────────
let _cachedAllowedList = null;

function loadList() {
    if (_cachedAllowedList !== null) return _cachedAllowedList;
    try {
        if (fs.existsSync(GOFC_FILE)) {
            const data = JSON.parse(fs.readFileSync(GOFC_FILE, 'utf8'));
            if (Array.isArray(data.allowedSubbots)) {
                _cachedAllowedList = data.allowedSubbots.map(Number);
                return _cachedAllowedList;
            }
        }
    } catch (e) {
        console.error('[gofc] Error cargando lista:', e.message);
    }
    _cachedAllowedList = [];
    return _cachedAllowedList;
}

function saveList(list) {
    try {
        fs.writeFileSync(GOFC_FILE, JSON.stringify({ allowedSubbots: list }, null, 2), 'utf8');
        _cachedAllowedList = list.map(Number);
        return true;
    } catch (e) {
        console.error('[gofc] Error guardando lista:', e.message);
        return false;
    }
}

/**
 * Devuelve true si el subbot (por su _subNum) está en la lista blanca.
 * Función pública — puede ser importada desde otros módulos si se necesita.
 */
function isSubbotAllowedInOfficial(subNum) {
    const num = Number(subNum);
    return loadList().includes(num);
}

// ── Handler principal ─────────────────────────────────────────────────────────
const gofcHandler = async (message) => {
    try {
        const botConfig = global.botConfig || require('../../config');

        // ── Verificar que el usuario es owner del config.js ──────────────────
        const senderRaw = message.author || message.sender || message.from || '';
        const senderNum = senderRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Parsear argumentos ────────────────────────────────────────────────
        const rawBody = (message.body || message.text || '').trim();
        const parts   = rawBody.split(/\s+/).slice(1); // quitar el prefijo+comando
        const sub1    = (parts[0] || '').toLowerCase(); // "add" / "remove" / "list"
        const sub2    = (parts[1] || '').trim();        // número del subbot

        const list = loadList();

        // ── Sin argumentos o "list": mostrar estado ───────────────────────────
        if (!sub1 || sub1 === 'list') {
            let txt = `🏠 *GOFC — Subbots permitidos en el Grupo Oficial*\n\n`;
            if (list.length === 0) {
                txt += `📭 _No hay subbots en la lista blanca._\n`;
                txt += `Ningún subbot responderá en el grupo oficial.\n`;
            } else {
                // Mostrar cuáles están conectados ahora mismo
                const activeSubs = (global.subConns || []).filter(c => c?.user && c._subNum != null);
                const activeNums = new Set(activeSubs.map(c => c._subNum));

                txt += `*Subbots habilitados:*\n`;
                list.forEach(n => {
                    const status = activeNums.has(n) ? '🟢 conectado' : '🔴 desconectado';
                    txt += `  • SubBot #${n} — ${status}\n`;
                });
            }
            txt += `\n💡 *Comandos:*\n`;
            txt += `  • *.gofc add <número>* → Agregar a la lista\n`;
            txt += `  • *.gofc remove <número>* → Quitar de la lista\n`;
            txt += `  • *.gofc list* → Ver la lista`;
            return await message.reply(txt);
        }

        // ── Agregar subbot ────────────────────────────────────────────────────
        if (sub1 === 'add') {
            const num = parseInt(sub2, 10);
            if (isNaN(num) || num <= 0) {
                return await message.reply('⚠️ Uso: *.gofc add <número>*\nEjemplo: `.gofc add 5742`');
            }
            if (list.includes(num)) {
                return await message.reply(`ℹ️ El SubBot #${num} ya está en la lista blanca.`);
            }
            list.push(num);
            list.sort((a, b) => a - b);
            if (!saveList(list)) {
                return await message.reply('❌ Error al guardar la lista.');
            }
            return await message.reply(`✅ *SubBot #${num} agregado* a la lista blanca.\nAhora podrá responder en el grupo oficial (si está conectado).`);
        }

        // ── Quitar subbot ─────────────────────────────────────────────────────
        if (sub1 === 'remove' || sub1 === 'del' || sub1 === 'delete' || sub1 === 'rm') {
            const num = parseInt(sub2, 10);
            if (isNaN(num) || num <= 0) {
                return await message.reply('⚠️ Uso: *.gofc remove <número>*\nEjemplo: `.gofc remove 5742`');
            }
            const idx = list.indexOf(num);
            if (idx === -1) {
                return await message.reply(`ℹ️ El SubBot #${num} no estaba en la lista blanca.`);
            }
            list.splice(idx, 1);
            if (!saveList(list)) {
                return await message.reply('❌ Error al guardar la lista.');
            }
            return await message.reply(`❌ *SubBot #${num} quitado* de la lista blanca.\nYa no responderá en el grupo oficial.`);
        }

        // ── Argumento desconocido ─────────────────────────────────────────────
        return await message.reply(
            '⚠️ Subcomando no reconocido.\n\n' +
            '💡 *Uso:*\n' +
            '  • *.gofc* → Ver lista\n' +
            '  • *.gofc add <número>* → Agregar subbot\n' +
            '  • *.gofc remove <número>* → Quitar subbot'
        );

    } catch (error) {
        console.error('[gofc] Error en comando:', error.message);
        await message.reply('❌ Error interno al ejecutar el comando.');
    }
};

gofcHandler.help    = ['gofc'];
gofcHandler.tags    = ['owner', 'subbots'];
gofcHandler.command = /^gofc$/i;
gofcHandler.owner   = false; // La verificación la hacemos manualmente (config.js owners)

// ── Exports ───────────────────────────────────────────────────────────────────
module.exports                          = gofcHandler;
module.exports.isSubbotAllowedInOfficial = isSubbotAllowedInOfficial;
// Compatibilidad hacia atrás por si algo importaba isGofcEnabled
module.exports.isGofcEnabled            = () => loadList().length > 0;
