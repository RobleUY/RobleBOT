'use strict';

const path = require('path');
const fs = require('fs');

// ── Ruta de sesiones de subbots ──
const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

// ── Función auxiliar adaptada a tu sistema de credenciales real ──
function getSubBotNumberByOwner(numeroReal) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    
    // Limpiamos el número de teléfono que ejecuta el comando
    const targetNum = String(numeroReal).replace(/[^0-9]/g, '');
    if (!targetNum) return null;

    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            if (fs.statSync(dbPath).size <= 0) continue; 
            
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true, fileMustExist: true, timeout: 5000 });
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 5000');
            db.pragma('journal_mode = WAL'); 
            
            // Buscamos la llave 'creds' que es donde tu sistema guarda todo
            const row = db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
            db.close();
            if (!row) continue;
            
            const data = JSON.parse(row.value);
            
            // Baileys guarda los datos del bot en data.me
            if (!data.me) continue;
            
            // Extraemos el número puro del bot (ya sea desde el ID o JID del me)
            const botJid = data.me.id || data.me.jid || '';
            const botNumClean = String(botJid).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

            // Si el número del subbot en esta DB coincide con tu número real, ¡lo encontramos!
            if (botNumClean && botNumClean === targetNum) {
                console.log(`[reconnect-subbots] ✅ ¡Encontrado! El archivo de sesión #${num} pertenece a tu número ${targetNum}`);
                return num;
            }
        } catch (e) {
            console.error(`[reconnect-subbots] ❌ Error leyendo archivo #${num}:`, e.message);
        }
    }
    return null;
}

// ── Función auxiliar para forzar reconexión de un subbot ──
async function forceReconnectSubBot({ num, conn }) {
    const { connectSubBot, activeSocks } = require('./subbot-serbot');
    const name = String(num);
    
    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { 
            prevSock.ev.removeAllListeners(); 
            prevSock.ws?.terminate?.(); 
            prevSock.ws?.close?.(); 
        } catch {}
        activeSocks.delete(name);
    }

    if (global.subConns) {
        const ci = global.subConns.findIndex(c => c._subNum === num);
        if (ci >= 0) global.subConns.splice(ci, 1);
    }

    await new Promise(r => setTimeout(r, 1500));
    return connectSubBot({ num, chatJid: null, conn: conn || global.conn });
}

// ── HANDLER DEL COMANDO ──
let handler = async (message) => {
    const sock = message._sock || global.conn;
    const key = message.key || {};
    
    // Captura inteligente usando campos alternativos de Baileys para saltar el @lid
    const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid || message.author || message.sender || message.from;
    
    let numeroReal = '';
    if (jidReal) {
        numeroReal = String(jidReal).replace(/[^0-9]/g, '');
    }

    console.log(`[reconnect-subbots] Comando ejecutado por JID: ${message.sender || message.from}`);

    // Extracción dinámica y segura del número del bot principal para usarlo en los avisos
    const mainBotJid = global.conn?.user?.id || sock?.user?.id || '';
    const mainBotNum = mainBotJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    const linkMainBot = mainBotNum ? `wa.me/${mainBotNum}` : 'al administrador';

    // Verificar que sea privado
    if (message.isGroup) {
        return sock.sendMessage(message.from, {
            text: `❌ Este comando solo funciona por privado.\n📱 Por favor, escribe directamente al *bot principal* aquí: *${linkMainBot}*`
        }, { quoted: message._baileyMessage });
    }

    // Verificar si es subbot y redirigir al bot principal
    if (message._subNum) {
        return sock.sendMessage(message.from, {
            text: `❌ Este comando solo funciona en el *bot principal*.\n📱 Contacta directamente al bot principal para reconectar tu sesión aquí: *${linkMainBot}*`
        }, { quoted: message._baileyMessage });
    }

    const userSubNum = getSubBotNumberByOwner(numeroReal);

    if (!userSubNum) {
        return sock.sendMessage(message.from, {
            text: `❌ No tienes ningún SubBot registrado.\n💡 El sistema te detectó con el número: *${numeroReal}*.\nSi es incorrecto, usa \`.code\` para vincularte nuevamente.`
        }, { quoted: message._baileyMessage });
    }

    await sock.sendMessage(message.from, {
        text: `⏳ Reconectando tu SubBot #${userSubNum}...\n_Esto puede tardar unos segundos._`
    }, { quoted: message._baileyMessage });

    try {
        await forceReconnectSubBot({ num: userSubNum, conn: sock });
        
        await sock.sendMessage(message.from, {
            text: `✅ *SubBot #${userSubNum} reconectado exitosamente.*\n🟢 Ya está listo para usar.`
        }, { quoted: message._baileyMessage });
    } catch (error) {
        console.error(`[reconnect-subbots] Error reconectando subbot #${userSubNum}:`, error.message);
        await sock.sendMessage(message.from, {
            text: `⚠️ Error durante la reconexión: ${error.message}\n💡 Intenta de nuevo en unos segundos.`
        }, { quoted: message._baileyMessage });
    }
};

handler.help = ['reconnect', 'reconect', 'reconectar', 'conectar', 'conect', 'connect'];
handler.tags = ['subbots'];
handler.command = /^(reconnect|reconect|reconectar|conectar|conect|connect)$/i;

module.exports = handler;
