'use strict';

const path = require('path');
const fs = require('fs');

// ── Ruta de sesiones de subbots ──
const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

// ── Función auxiliar para obtener el número del subbot de un usuario ──
function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = ownerJid.split('@')[0].split(':')[0];
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    
    for (const file of dbFiles) {
        const num = parseInt(file);
        const dbPath = path.join(SESSIONS_DIR, file);
        try {
            if (fs.statSync(dbPath).size <= 13000) continue;
            const Database = require('better-sqlite3');
            const db = new Database(dbPath, { readonly: true });
            db.pragma('cache_size = 5000');
            db.pragma('busy_timeout = 3000');
            const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
            db.close();
            if (!row) continue;
            const data = JSON.parse(row.value);
            const storedNum = (data.phoneNumber || '').replace(/[^0-9]/g, '');
            if (storedNum && storedNum === ownerNum) return num;
        } catch {}
    }
    return null;
}

// ── Función auxiliar para forzar reconexión de un subbot ──
async function forceReconnectSubBot({ num, conn }) {
    const { connectSubBot, activeSocks } = require('./subbot-serbot');
    const name = String(num);
    
    // Cerrar socket anterior si existe
    const prevSock = activeSocks.get(name);
    if (prevSock) {
        try { 
            prevSock.ev.removeAllListeners(); 
            prevSock.ws?.terminate?.(); 
            prevSock.ws?.close?.(); 
        } catch {}
        activeSocks.delete(name);
    }

    // Limpiar de global.subConns si existe
    if (global.subConns) {
        const ci = global.subConns.findIndex(c => c._subNum === num);
        if (ci >= 0) global.subConns.splice(ci, 1);
    }

    // Esperar antes de reconectar
    await new Promise(r => setTimeout(r, 1500));
    
    // Reconectar
    return connectSubBot({ num, chatJid: null, conn: conn || global.conn });
}

// ── HANDLER DEL COMANDO ──
let handler = async (message) => {
    const sock = message._sock || global.conn;
    const senderJid = message.author || message.sender || message.from;

    // Verificar que sea privado
    if (message.isGroup) {
        return sock.sendMessage(message.from, {
            text: '❌ Este comando solo funciona por privado.'
        }, { quoted: message._baileyMessage });
    }

    // Verificar que NO sea subbot
    if (message._subNum) {
        return sock.sendMessage(message.from, {
            text: '❌ Este comando solo funciona en el *bot principal*.\n📱 Contacta directamente al bot principal para reconectar tu sesión.'
        }, { quoted: message._baileyMessage });
    }

    // Buscar subbot del usuario automáticamente
    const userSubNum = getSubBotNumberByOwner(senderJid);

    if (!userSubNum) {
        return sock.sendMessage(message.from, {
            text: '❌ No tienes ningún SubBot registrado.\n💡 Usa `.code` o `.qr` para crear uno.'
        }, { quoted: message._baileyMessage });
    }

    // Avisar que está procesando
    await sock.sendMessage(message.from, {
        text: `⏳ Reconectando tu SubBot #${userSubNum}...\n_Esto puede tardar unos segundos._`
    }, { quoted: message._baileyMessage });

    try {
        await forceReconnectSubBot({ num: userSubNum, conn: sock });
        
        // Confirmación de éxito
        await sock.sendMessage(message.from, {
            text: `✅ *SubBot #${userSubNum} reconectado exitosamente.*\n🟢 Ya está listo para usar.`
        }, { quoted: message._baileyMessage });
    } catch (error) {
        console.error(`[reconnect-subbots] Error reconectando subbot #${userSubNum}:`, error.message);
        await sock.sendMessage(message.from, {
            text: `⚠️ Error durante la reconexión: ${error.message}\n💡 Intenta de nuevo en unos segundos.`
        }, { quoted: message._baileyMessage });
    }
};

handler.help = ['reconnect', 'reconect', 'reconectar', 'conectar', 'conect', 'connect'];
handler.tags = ['subbots'];
handler.command = /^(reconnect|reconect|reconectar|conectar|conect|connect)$/i;
handler.owner = true;

module.exports = handler;
