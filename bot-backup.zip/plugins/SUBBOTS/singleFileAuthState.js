'use strict';
const path    = require('path');
const fs      = require('fs');
const Database = require('better-sqlite3');
const { initAuthCreds, BufferJSON, proto } = require('@whiskeysockets/baileys');

async function useSQLiteAuthState(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const db = new Database(filePath);
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = NORMAL');
    db.pragma('cache_size = -256'); // 256 KB por base de datos de autenticación (evita saturación en 160+ subbots)
    db.pragma('busy_timeout = 5000');

    db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);

    const stmtGet    = db.prepare('SELECT value FROM auth WHERE key = ?');
    const stmtSet    = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');
    const stmtDelete = db.prepare('DELETE FROM auth WHERE key = ?');

    function readData(key) {
        const row = stmtGet.get(key);
        if (!row) return null;
        try { return JSON.parse(row.value, BufferJSON.reviver); } 
        catch { return null; }
    }

    let creds = readData('creds');
    if (!creds) {
        creds = initAuthCreds();
        stmtSet.run('creds', JSON.stringify(creds, BufferJSON.replacer));
    }

    let isClosed = false;

    function ensureOpen() {
        return !isClosed && db && db.open;
    }

    // --- SISTEMA ANTI-CONGELAMIENTO (Lotes de escritura) ---
    let writeQueue = {};
    let writeTimeout = null;

    function flushWriteQueue() {
        if (!ensureOpen()) return;

        const keysToFlush = Object.keys(writeQueue);
        if (keysToFlush.length === 0) return;
        
        const currentQueue = { ...writeQueue };
        
        try {
            const transaction = db.transaction(() => {
                for (const [key, val] of Object.entries(currentQueue)) {
                    if (val === null || val === undefined) {
                        stmtDelete.run(key);
                    } else {
                        stmtSet.run(key, JSON.stringify(val, BufferJSON.replacer));
                    }
                }
            });
            transaction();
            // Solo eliminamos de la cola de escritura las claves escritas con éxito
            for (const key of keysToFlush) {
                if (writeQueue[key] === currentQueue[key]) {
                    delete writeQueue[key];
                }
            }
        } catch (error) {
            if (!isClosed) {
                console.error(`[SQLite Error en ${path.basename(filePath)}]:`, error.message);
            }
        }
    }
    // -------------------------------------------------------

    // --- CACHÉ EN MEMORIA PARA LECTURAS RÁPIDAS CON LÍMITE LRU ---
    const MAX_READ_CACHE = 250; // Máximo 250 claves por subbot (evita fuga de memoria en 160+ subbots)
    const readCache = new Map();

    function cacheSet(key, val) {
        if (readCache.has(key)) {
            readCache.delete(key);
        } else if (readCache.size >= MAX_READ_CACHE) {
            const firstKey = readCache.keys().next().value;
            if (firstKey) readCache.delete(firstKey);
        }
        readCache.set(key, val);
    }

    function getCachedData(key) {
        if (writeQueue[key] !== undefined) return writeQueue[key];
        if (readCache.has(key)) {
            const val = readCache.get(key);
            readCache.delete(key);
            readCache.set(key, val);
            return val;
        }
        const val = readData(key);
        if (val !== null && val !== undefined) {
            cacheSet(key, val);
        }
        return val;
    }

    const state = {
        creds,
        keys: {
            get(type, ids) {
                const result = {};
                for (const id of ids) {
                    const key = `${type}-${id}`;
                    // Leer de la cola de escritura o la caché en memoria antes de SQLite
                    let val = getCachedData(key);
                    
                    if (val !== null && val !== undefined) {
                        if (type === 'app-state-sync-key') {
                            result[id] = proto.Message.AppStateSyncKeyData.fromObject(val);
                        } else {
                            result[id] = val;
                        }
                    }
                }
                return result;
            },
            set(data_update) {
                if (!ensureOpen()) return;

                // Enviar a la cola de escritura y actualizar la caché en memoria al instante
                for (const [type, typeData] of Object.entries(data_update)) {
                    for (const [id, val] of Object.entries(typeData)) {
                        const key = `${type}-${id}`;
                        writeQueue[key] = val;
                        if (val === null || val === undefined) {
                            readCache.delete(key);
                        } else {
                            cacheSet(key, val);
                        }
                    }
                }
                
                // Ejecutar la escritura a los 150ms para mantener el cifrado de Signal sincronizado
                if (!writeTimeout) {
                    writeTimeout = setTimeout(() => {
                        writeTimeout = null;
                        flushWriteQueue();
                    }, 150);
                }
            }
        }
    };

    const saveCreds = () => {
        if (!ensureOpen()) return;

        // Guardar credenciales e imediar la cola de escritura para evitar pérdida de sesión
        try {
            stmtSet.run('creds', JSON.stringify(state.creds, BufferJSON.replacer));
        } catch (error) {
            if (!isClosed) {
                console.error(`[SQLite saveCreds Error en ${path.basename(filePath)}]:`, error.message);
            }
        }
        writeQueue['creds'] = state.creds;
        flushNow();
    };

    // Forzar escritura inmediata de todo lo pendiente (usar antes de apagar el proceso)
    const flushNow = () => {
        if (!ensureOpen()) return;

        if (writeTimeout) {
            clearTimeout(writeTimeout);
            writeTimeout = null;
        }
        flushWriteQueue();
    };

    const close = () => {
        try {
            isClosed = true;
            openAuthStates.delete(authObj);
            if (writeTimeout) {
                clearTimeout(writeTimeout);
                writeTimeout = null;
            }
            readCache.clear();
            writeQueue = {};
            if (db && db.open) {
                db.close();
            }
        } catch (e) {
            if (!isClosed) {
                console.error(`[SQLite Close Error en ${path.basename(filePath)}]:`, e.message);
            }
        }
    };

    const authObj = { state, saveCreds, flushNow, close, db };
    openAuthStates.add(authObj);
    registerGlobalExitHandlers();

    return authObj;
}

const openAuthStates = new Set();
let processListenersRegistered = false;

function registerGlobalExitHandlers() {
    if (processListenersRegistered) return;
    processListenersRegistered = true;
    const exitHandler = () => {
        for (const authState of openAuthStates) {
            try { authState.flushNow(); } catch (_) {}
        }
    };
    process.once('SIGINT', exitHandler);
    process.once('SIGTERM', exitHandler);
}

module.exports = { useSQLiteAuthState };