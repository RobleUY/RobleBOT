'use strict';
const path    = require('path');
const fs      = require('fs');
const Database = require('better-sqlite3');
const { initAuthCreds, BufferJSON, proto } = require('@whiskeysockets/baileys');

async function useSQLiteAuthState(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const db = new Database(filePath);
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = NORMAL');
    db.pragma('cache_size = 10000');
    db.pragma('busy_timeout = 5000');

    db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);

    const stmtGet    = db.prepare('SELECT value FROM auth WHERE key = ?');
    const stmtSet    = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');
    const stmtDelete = db.prepare('DELETE FROM auth WHERE key = ?');

    function readData(key) {
        const row = stmtGet.get(key);
        if (!row) return null;
        try { return JSON.parse(row.value, BufferJSON.reviver); } 
        catch { return null; }
    }

    let creds = readData('creds');
    if (!creds) {
        creds = initAuthCreds();
        stmtSet.run('creds', JSON.stringify(creds, BufferJSON.replacer));
    }

    // --- SISTEMA ANTI-CONGELAMIENTO (Lotes de escritura) ---
    let writeQueue = {};
    let writeTimeout = null;

    function flushWriteQueue() {
        if (Object.keys(writeQueue).length === 0) return;
        
        const currentQueue = { ...writeQueue };
        writeQueue = {}; // Vaciamos la cola actual
        
        try {
            const transaction = db.transaction(() => {
                for (const [key, val] of Object.entries(currentQueue)) {
                    if (val === null || val === undefined) {
                        stmtDelete.run(key);
                    } else {
                        stmtSet.run(key, JSON.stringify(val, BufferJSON.replacer));
                    }
                }
            });
            transaction();
        } catch (error) {
            console.error(`[SQLite Error en ${path.basename(filePath)}]:`, error.message);
        }
    }
    // -------------------------------------------------------

    const state = {
        creds,
        keys: {
            get(type, ids) {
                const result = {};
                for (const id of ids) {
                    const key = `${type}-${id}`;
                    // Leer primero de la cola de escritura (por si aún no se guardó en disco)
                    let val = writeQueue[key] !== undefined ? writeQueue[key] : readData(key);
                    
                    if (val !== null && val !== undefined) {
                        if (type === 'app-state-sync-key') {
                            result[id] = proto.Message.AppStateSyncKeyData.fromObject(val);
                        } else {
                            result[id] = val;
                        }
                    }
                }
                return result;
            },
            set(data_update) {
                // Enviar a la cola en lugar de escribir inmediatamente
                for (const [type, typeData] of Object.entries(data_update)) {
                    for (const [id, val] of Object.entries(typeData)) {
                        writeQueue[`${type}-${id}`] = val;
                    }
                }
                
                // Ejecutar la escritura cada 2.5 segundos (libera el Event Loop)
                if (!writeTimeout) {
                    writeTimeout = setTimeout(() => {
                        writeTimeout = null;
                        flushWriteQueue();
                    }, 2500);
                }
            }
        }
    };

    const saveCreds = () => {
        writeQueue['creds'] = state.creds;
        if (!writeTimeout) {
            writeTimeout = setTimeout(() => {
                writeTimeout = null;
                flushWriteQueue();
            }, 2500);
        }
    };

    return { state, saveCreds, db };
}

module.exports = { useSQLiteAuthState };