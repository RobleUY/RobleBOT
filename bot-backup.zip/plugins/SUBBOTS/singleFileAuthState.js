'use strict';
const path    = require('path');
const fs      = require('fs');
const Database = require('better-sqlite3');
const { initAuthCreds, BufferJSON, proto } = require('@whiskeysockets/baileys');

async function useSQLiteAuthState(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const db = new Database(filePath);
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = NORMAL');
    db.pragma('cache_size = 10000');
    db.pragma('busy_timeout = 5000');

    db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);

    const stmtGet    = db.prepare('SELECT value FROM auth WHERE key = ?');
    const stmtSet    = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');
    const stmtDelete = db.prepare('DELETE FROM auth WHERE key = ?');

    function readData(key) {
        const row = stmtGet.get(key);
        if (!row) return null;
        try { return JSON.parse(row.value, BufferJSON.reviver); } 
        catch { return null; }
    }

    let creds = readData('creds');
    if (!creds) {
        creds = initAuthCreds();
        stmtSet.run('creds', JSON.stringify(creds, BufferJSON.replacer));
    }

    // --- SISTEMA ANTI-CONGELAMIENTO (Lotes de escritura) ---
    let writeQueue = {};
    let writeTimeout = null;

    function flushWriteQueue() {
        const keysToFlush = Object.keys(writeQueue);
        if (keysToFlush.length === 0) return;
        
        const currentQueue = { ...writeQueue };
        
        try {
            const transaction = db.transaction(() => {
                for (const [key, val] of Object.entries(currentQueue)) {
                    if (val === null || val === undefined) {
                        stmtDelete.run(key);
                    } else {
                        stmtSet.run(key, JSON.stringify(val, BufferJSON.replacer));
                    }
                }
            });
            transaction();
            // Solo eliminamos de la cola de escritura las claves escritas con éxito
            for (const key of keysToFlush) {
                if (writeQueue[key] === currentQueue[key]) {
                    delete writeQueue[key];
                }
            }
        } catch (error) {
            console.error(`[SQLite Error en ${path.basename(filePath)}]:`, error.message);
        }
    }
    // -------------------------------------------------------

    // --- CACHÉ EN MEMORIA PARA LECTURAS RÁPIDAS ---
    const readCache = new Map();

    function getCachedData(key) {
        if (writeQueue[key] !== undefined) return writeQueue[key];
        if (readCache.has(key)) return readCache.get(key);
        const val = readData(key);
        if (val !== null && val !== undefined) {
            readCache.set(key, val);
        }
        return val;
    }

    const state = {
        creds,
        keys: {
            get(type, ids) {
                const result = {};
                for (const id of ids) {
                    const key = `${type}-${id}`;
                    // Leer de la cola de escritura o la caché en memoria antes de SQLite
                    let val = getCachedData(key);
                    
                    if (val !== null && val !== undefined) {
                        if (type === 'app-state-sync-key') {
                            result[id] = proto.Message.AppStateSyncKeyData.fromObject(val);
                        } else {
                            result[id] = val;
                        }
                    }
                }
                return result;
            },
            set(data_update) {
                // Enviar a la cola de escritura y actualizar la caché en memoria al instante
                for (const [type, typeData] of Object.entries(data_update)) {
                    for (const [id, val] of Object.entries(typeData)) {
                        const key = `${type}-${id}`;
                        writeQueue[key] = val;
                        if (val === null || val === undefined) {
                            readCache.delete(key);
                        } else {
                            readCache.set(key, val);
                        }
                    }
                }
                
                // Ejecutar la escritura a los 150ms para mantener el cifrado de Signal sincronizado
                if (!writeTimeout) {
                    writeTimeout = setTimeout(() => {
                        writeTimeout = null;
                        flushWriteQueue();
                    }, 150);
                }
            }
        }
    };

    const saveCreds = () => {
        // Guardar credenciales INMEDIATAMENTE (sin delay) para evitar pérdida de sesión
        try {
            stmtSet.run('creds', JSON.stringify(state.creds, BufferJSON.replacer));
        } catch (error) {
            console.error(`[SQLite saveCreds Error en ${path.basename(filePath)}]:`, error.message);
        }
        // También actualizar la cola por si hay keys pendientes
        writeQueue['creds'] = state.creds;
        if (!writeTimeout) {
            writeTimeout = setTimeout(() => {
                writeTimeout = null;
                flushWriteQueue();
            }, 2500);
        }
    };

    // Forzar escritura inmediata de todo lo pendiente (usar antes de apagar el proceso)
    const flushNow = () => {
        if (writeTimeout) {
            clearTimeout(writeTimeout);
            writeTimeout = null;
        }
        flushWriteQueue();
    };

    const close = () => {
        try {
            flushNow();
            if (db && db.open) {
                db.close();
            }
        } catch (e) {
            console.error(`[SQLite Close Error en ${path.basename(filePath)}]:`, e.message);
        }
    };

    return { state, saveCreds, flushNow, close, db };
}

module.exports = { useSQLiteAuthState };