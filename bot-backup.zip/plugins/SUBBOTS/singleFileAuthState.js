'use strict';
/**
 * singleFileAuthState.js
 *
 * Auth state de Baileys usando SQLite (better-sqlite3).
 * Cada subbot guarda TODA su sesión en un único archivo:
 *   sesiones/1.db, sesiones/2.db, sesiones/3.db ...
 *
 * En lugar de una carpeta con cientos de archivos → 1 archivo .db por sesión.
 * Reduce el uso de inodos de ~100-200 por sesión a exactamente 1.
 *
 * API idéntica a useMultiFileAuthState:
 *   const { state, saveCreds } = await useSQLiteAuthState(filePath);
 */

const path    = require('path');
const fs      = require('fs');
const Database = require('better-sqlite3');
const { initAuthCreds, BufferJSON, proto } = require('@whiskeysockets/baileys');

/**
 * @param {string} filePath  Ruta al archivo .db (ej: sesiones/1.db)
 */
async function useSQLiteAuthState(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const db = new Database(filePath);

    // ── OPTIMIZACIONES DE RENDIMIENTO SQLite ──────────────────────────────
    // WAL mode: permite lecturas concurrentes durante escrituras
    db.pragma('journal_mode = WAL');
    // NORMAL: reduce sincronización al disco (mejor rendimiento)
    db.pragma('synchronous = NORMAL');
    // Cache más grande para mejor rendimiento
    db.pragma('cache_size = 10000');
    // Timeout para locks
    db.pragma('busy_timeout = 5000');
    // ─────────────────────────────────────────────────────────────────────

    // Crear tabla si no existe
    db.exec(`
        CREATE TABLE IF NOT EXISTS auth (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    `);

    // Prepared statements para rendimiento
    const stmtGet    = db.prepare('SELECT value FROM auth WHERE key = ?');
    const stmtSet    = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');
    const stmtDelete = db.prepare('DELETE FROM auth WHERE key = ?');

    function readData(key) {
        const row = stmtGet.get(key);
        if (!row) return null;
        try {
            return JSON.parse(row.value, BufferJSON.reviver);
        } catch {
            return null;
        }
    }

    function writeData(key, value) {
        stmtSet.run(key, JSON.stringify(value, BufferJSON.replacer));
    }

    function deleteData(key) {
        stmtDelete.run(key);
    }

    // Cargar o inicializar creds
    let creds = readData('creds');
    if (!creds) {
        creds = initAuthCreds();
        writeData('creds', creds);
    }

    const state = {
        creds,

        keys: {
            get(type, ids) {
                const result = {};
                for (const id of ids) {
                    const val = readData(`${type}-${id}`);
                    if (val !== null && val !== undefined) {
                        if (type === 'app-state-sync-key') {
                            result[id] = proto.Message.AppStateSyncKeyData.fromObject(val);
                        } else {
                            result[id] = val;
                        }
                    }
                }
                return result;
            },

            set(data_update) {
                // Usar transacción para escribir todo de golpe (más rápido y seguro)
                const transaction = db.transaction(() => {
                    for (const [type, typeData] of Object.entries(data_update)) {
                        for (const [id, val] of Object.entries(typeData)) {
                            const key = `${type}-${id}`;
                            if (val === null || val === undefined) {
                                deleteData(key);
                            } else {
                                writeData(key, val);
                            }
                        }
                    }
                });
                transaction();
            }
        }
    };

    const saveCreds = () => {
        writeData('creds', state.creds);
    };

    return { state, saveCreds, db };
}

module.exports = { useSQLiteAuthState };
