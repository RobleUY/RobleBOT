const fs = require('fs');
const path = require('path');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

let handler = async (message) => {
    try {
        await message.reply('🧹 Iniciando limpieza de carpetas vacías...');

        if (!fs.existsSync(SESSIONS_DIR)) {
            return await message.reply('❌ No se encontró la carpeta de sesiones.\n📁 Ruta: ' + SESSIONS_DIR);
        }

        const items = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true });
        
        let carpetasEliminadas = 0;
        let carpetasConContenido = 0;
        let archivos = 0;
        const eliminadas = [];

        for (const item of items) {
            if (item.isDirectory()) {
                const folderPath = path.join(SESSIONS_DIR, item.name);
                
                try {
                    const contents = fs.readdirSync(folderPath);
                    
                    if (contents.length === 0) {
                        // Carpeta vacía - eliminar
                        fs.rmdirSync(folderPath);
                        eliminadas.push(item.name);
                        carpetasEliminadas++;
                    } else {
                        carpetasConContenido++;
                    }
                } catch (err) {
                    console.error(`[Limpieza] Error procesando ${item.name}:`, err.message);
                }
            } else if (item.isFile()) {
                archivos++;
            }
        }

        let resultado = '╔═══════════════════════════\n';
        resultado += '║  🧹 LIMPIEZA COMPLETADA\n';
        resultado += '╚═══════════════════════════\n\n';
        
        if (carpetasEliminadas > 0) {
            resultado += `✅ *Carpetas vacías eliminadas:* ${carpetasEliminadas}\n`;
            resultado += `📂 *Eliminadas:* ${eliminadas.join(', ')}\n\n`;
        } else {
            resultado += '✅ *No se encontraron carpetas vacías*\n\n';
        }
        
        resultado += `📁 Carpetas con contenido: ${carpetasConContenido}\n`;
        resultado += `📄 Archivos de sesión: ${archivos}\n\n`;
        
        if (carpetasEliminadas > 0) {
            resultado += '💡 _Ya no se crearán más carpetas vacías gracias al fix aplicado_';
        }

        return await message.reply(resultado);

    } catch (err) {
        console.error('[Limpieza] Error:', err);
        return await message.reply(`❌ Error durante la limpieza:\n${err.message}`);
    }
};

handler.help = ['elpepesapopapa'];
handler.tags = ['owner'];
handler.command = /^elpepesapopapa$/i;
handler.owner = true;

module.exports = handler;
