'use strict';
/**
 * migrarSesiones.js
 *
 * Convierte las carpetas de sesión existentes (sesiones/1/, sesiones/2/, ...)
 * al nuevo formato SQLite (sesiones/1.db, sesiones/2.db, ...).
 *
 * Ejecutar UNA SOLA VEZ antes de reiniciar el bot:
 *   node plugins/SUBBOTS/migrarSesiones.js
 *
 * - Lee todos los archivos JSON de cada carpeta y los inserta en el .db
 * - Renombra la carpeta original a <num>_backup (NO la borra, por seguridad)
 * - Si ya existe el .db de destino, omite esa sesión (no sobreescribe)
 */

const fs      = require('fs');
const path    = require('path');

let Database, BufferJSON, proto;
try {
    Database = require('better-sqlite3');
} catch (e) {
    console.error('❌ Falta better-sqlite3. Ejecuta: npm install');
    process.exit(1);
}
try {
    ({ BufferJSON, proto } = require('@whiskeysockets/baileys'));
} catch (e) {
    console.error('❌ No se pudo importar @whiskeysockets/baileys:', e.message);
    process.exit(1);
}

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

if (!fs.existsSync(SESSIONS_DIR)) {
    console.log('No existe la carpeta sesiones/, nada que migrar.');
    process.exit(0);
}

// Solo carpetas numéricas
const folders = fs.readdirSync(SESSIONS_DIR)
    .filter(e => {
        const n = parseInt(e);
        if (isNaN(n)) return false;
        return fs.statSync(path.join(SESSIONS_DIR, e)).isDirectory();
    })
    .map(e => parseInt(e))
    .sort((a, b) => a - b);

if (folders.length === 0) {
    console.log('No hay carpetas de sesión numéricas para migrar.');
    process.exit(0);
}

console.log(`\nEncontradas ${folders.length} sesión(es): [${folders.join(', ')}]\n`);

// Tipos de clave conocidos de Baileys (para parsear nombre de archivo → type + id)
const KNOWN_TYPES = [
    'app-state-sync-key',
    'app-state-sync-version',
    'sender-key-memory',
    'sender-key',
    'pre-key',
    'session',
];

let migradas = 0;
let omitidas = 0;
let errores  = 0;

for (const num of folders) {
    const folderPath = path.join(SESSIONS_DIR, String(num));
    const destFile   = path.join(SESSIONS_DIR, `${num}.db`);
    const backupPath = path.join(SESSIONS_DIR, `${num}_backup`);

    if (fs.existsSync(destFile)) {
        console.log(`  [${num}] ⏭  Ya existe ${num}.db, omitiendo.`);
        omitidas++;
        continue;
    }

    const credsFile = path.join(folderPath, 'creds.json');
    if (!fs.existsSync(credsFile)) {
        console.log(`  [${num}] ⚠  Sin creds.json, carpeta inválida, omitiendo.`);
        omitidas++;
        continue;
    }

    try {
        const db = new Database(destFile);
        db.exec(`
            CREATE TABLE IF NOT EXISTS auth (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        `);
        const stmtSet = db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)');

        const allFiles = fs.readdirSync(folderPath);
        let insertados = 0;

        const insertAll = db.transaction(() => {
            for (const file of allFiles) {
                if (!file.endsWith('.json')) continue;

                const filePath = path.join(folderPath, file);
                if (!fs.statSync(filePath).isFile()) continue;

                let content;
                try {
                    content = JSON.parse(fs.readFileSync(filePath, 'utf-8'), BufferJSON.reviver);
                } catch {
                    continue; // archivo corrupto, saltar
                }

                const nameNoExt = file.replace(/\.json$/, '');

                if (nameNoExt === 'creds') {
                    // Guardar creds directamente
                    stmtSet.run('creds', JSON.stringify(content, BufferJSON.replacer));
                    insertados++;
                    continue;
                }

                if (nameNoExt === 'owner') {
                    // Guardar owner info dentro del .db también
                    stmtSet.run('_owner', JSON.stringify(content));
                    insertados++;
                    continue;
                }

                // Parsear tipo e id desde el nombre del archivo
                let matched = false;
                for (const type of KNOWN_TYPES) {
                    if (nameNoExt.startsWith(type + '-')) {
                        const id  = nameNoExt.slice(type.length + 1);
                        const key = `${type}-${id}`;
                        stmtSet.run(key, JSON.stringify(content, BufferJSON.replacer));
                        insertados++;
                        matched = true;
                        break;
                    }
                }

                if (!matched) {
                    // Fallback: guardar con nombre completo como clave
                    stmtSet.run(nameNoExt, JSON.stringify(content, BufferJSON.replacer));
                    insertados++;
                }
            }
        });

        insertAll();
        db.close();

        // Renombrar carpeta original a backup (no borrar)
        fs.renameSync(folderPath, backupPath);

        console.log(`  [${num}] ✅ Migrado (${insertados} entradas → ${num}.db). Backup: ${num}_backup/`);
        migradas++;

    } catch (err) {
        console.error(`  [${num}] ❌ Error:`, err.message);
        // Si se creó un .db parcial, borrarlo para no dejar basura
        try { if (fs.existsSync(destFile)) fs.unlinkSync(destFile); } catch {}
        errores++;
    }
}

console.log(`\nResumen: ${migradas} migradas, ${omitidas} omitidas, ${errores} errores.`);
if (migradas > 0) {
    console.log('\n✅ Listo. Reinicia el bot.');
    console.log('   Las carpetas _backup/ se pueden borrar cuando confirmes que todo funciona.');
}
if (errores > 0) {
    console.log('\n⚠️  Hubo errores. Las sesiones con error NO fueron modificadas.');
}
