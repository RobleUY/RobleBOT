'use strict';

/**
 * Comando .unircanales <cantidad|all> [enlace_opcional]
 * ─────────────────────────────────────────────────────────────────────────────
 * Une de forma RÁPIDA la cantidad elegida de subbots conectados (o todos con 'all')
 * a los canales de WhatsApp oficiales (o a los canales especificados en el mensaje).
 *
 * Uso:
 *   .unircanales all                   → Une todos los subbots a los 3 canales oficiales
 *   .unircanales 5                     → Une 5 subbots a los 3 canales oficiales
 *   .unircanales 3 https://whatsapp.com/channel/... → Une 3 subbots al canal especificado
 *   .unircanales all https://whatsapp.com/channel/... → Une todos los subbots al canal especificado
 *
 * Exclusivo para Owners.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const executedMessages = new Set();

// Canales oficiales por defecto
const DEFAULT_CHANNELS = [
    'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q', // Canal Updates
    'https://whatsapp.com/channel/0029VbDaSad47XeDBsa1jl39', // Canal Memes
    'https://whatsapp.com/channel/0029Vb8VGYA3rZZi6vWV9e2d'  // Canal Frases/Memes/Stickers
];

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const handler = async (message, { text }) => {
    try {
        // ── Deduplicación: evitar ejecuciones dobles si varios bots escuchan ──
        const msgId = message.id || message.key?.id;
        if (msgId && executedMessages.has(msgId)) return;
        if (msgId) {
            executedMessages.add(msgId);
            setTimeout(() => executedMessages.delete(msgId), 30000);
        }

        const botConfig = global.botConfig || require('../../config');

        // ── Verificar permisos de Owner ─────────────────────────────────────
        const senderRaw = message.author || message.sender || message.from || '';
        const senderNum = senderRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

        const isOwner =
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) ||
            (typeof botConfig.isOwner === 'function' && botConfig.isOwner(`${senderNum}@s.whatsapp.net`));

        if (!isOwner) {
            return await message.reply('⛔ Este comando es exclusivo del *owner* del bot.');
        }

        // ── Filtrar subbots conectados activos ──────────────────────────────
        const activeSubConns = (global.subConns || []).filter(c => c && c.user);

        if (activeSubConns.length === 0) {
            return await message.reply('⚠️ No hay SubBots conectados activamente en este momento.');
        }

        // ── Parsear argumentos ──────────────────────────────────────────────
        const rawBody = (text || message.body || message.text || '').trim();
        const parts   = rawBody.split(/\s+/);

        // Detectar si hay enlaces de canales en el comando
        const channelRegex = /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([a-zA-Z0-9_-]+)/gi;
        const matches = [...rawBody.matchAll(channelRegex)];

        let targetChannels = DEFAULT_CHANNELS;
        if (matches.length > 0) {
            targetChannels = matches.map(m => `https://whatsapp.com/channel/${m[1]}`);
        }

        // Buscar el argumento de cantidad o "all"
        let isAll = false;
        let count = 0;

        for (const part of parts) {
            const p = part.toLowerCase();
            if (p === 'all' || p === 'todos') {
                isAll = true;
                break;
            }
            const num = parseInt(part, 10);
            if (!isNaN(num) && num > 0) {
                count = num;
                break;
            }
        }

        if (!isAll && count <= 0) {
            let helpText = `⚠️ *Sintaxis incorrecta del comando .unircanales*\n\n`;
            helpText += `💡 *Uso correcto:*\n`;
            helpText += `  • *.unircanales all* → Unir a TODOS los subbots ( total: *${activeSubConns.length}* )\n`;
            helpText += `  • *.unircanales <cantidad>* → Unir la cantidad especificada de subbots (ej: \`.unircanales 5\`)\n`;
            helpText += `  • *.unircanales <cantidad|all> <link_canal>* → Unir a un canal específico\n\n`;
            helpText += `📢 *Canales por defecto:* ${DEFAULT_CHANNELS.length} canales oficiales.`;
            return await message.reply(helpText);
        }

        const targetCount = isAll ? activeSubConns.length : Math.min(count, activeSubConns.length);
        const targetBots = activeSubConns.slice(0, targetCount);

        const startMsg = await message.reply(
            `⚡ *Iniciando Unión Rápida a Canales...*\n\n` +
            `🤖 Subbots a procesar: *${targetBots.length}* de *${activeSubConns.length}* conectados\n` +
            `📢 Canales a unirse: *${targetChannels.length}*\n` +
            `⏳ _Por favor espera unos segundos..._`
        );

        let totalSuccess = 0;
        let totalFailed = 0;
        const botResults = [];

        // ── Procesamiento rápido por subbot ──────────────────────────────────
        for (let idx = 0; idx < targetBots.length; idx++) {
            const subSock = targetBots[idx];
            const subNum = subSock._subNum != null ? `#${subSock._subNum}` : `Nº${idx + 1}`;
            const phone = subSock.user?.id?.split('@')[0]?.split(':')[0] || '???';

            const channelStatus = [];

            for (const channelUrl of targetChannels) {
                const inviteCode = channelUrl.split('/').pop().trim();
                try {
                    const metadata = await subSock.newsletterMetadata('invite', inviteCode);
                    if (metadata && metadata.id) {
                        await subSock.newsletterFollow(metadata.id);
                        channelStatus.push(`✅ (${inviteCode})`);
                        totalSuccess++;
                    } else {
                        channelStatus.push(`❌ (${inviteCode} - Sin ID)`);
                        totalFailed++;
                    }
                } catch (error) {
                    if (error.message?.includes('unexpected response structure')) {
                        // Ya sigue al canal (confirmado)
                        channelStatus.push(`✅ (${inviteCode} - Ya sigue)`);
                        totalSuccess++;
                    } else {
                        channelStatus.push(`❌ (${inviteCode} - Error)`);
                        totalFailed++;
                    }
                }

                // Pequeña pausa de 250ms entre canales para ser súper rápido sin saturar la red
                await sleep(250);
            }

            botResults.push(`• *Bot ${subNum}* (+${phone}): ${channelStatus.join(', ')}`);
        }

        // ── Reporte final ────────────────────────────────────────────────────
        let report = `📢 *Reporte de Unión Rápida a Canales Finalizado*\n\n`;
        report += `🤖 Subbots procesados: *${targetBots.length}*\n`;
        report += `📢 Canales objetivo: *${targetChannels.length}*\n`;
        report += `✅ Exitosos / Ya unidos: *${totalSuccess}*\n`;
        report += `❌ Fallidos: *${totalFailed}*\n\n`;
        report += `📋 *Detalle por SubBot:*\n`;
        report += botResults.join('\n');

        await message.reply(report);

    } catch (error) {
        console.error('[unircanales] Error en comando:', error);
        await message.reply(`❌ Ocurrió un error inesperado al procesar la unión a canales: ${error.message || error}`);
    }
};

handler.help    = ['unircanales <cantidad/all> [link]'];
handler.tags    = ['owner', 'subbots'];
handler.command = /^(unircanales|unircanal)$/i;
handler.owner   = true;

module.exports  = handler;
