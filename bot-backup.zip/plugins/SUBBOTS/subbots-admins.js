'use strict';

const fs   = require('fs');
const path = require('path');
const { getGroupMetadataCached } = require('../../lib/groupCache');

// ── Archivo de configuración (mismo que usaba bot-on-off.js) ─────────────────
// Mantenemos la ruta existente para preservar los datos históricos del grupo.
const GRUPOS_DIR      = path.join(__dirname, '..', 'GRUPOS');
const BOT_STATUS_FILE = path.join(GRUPOS_DIR, 'bot-on-off.json');

if (!fs.existsSync(GRUPOS_DIR)) fs.mkdirSync(GRUPOS_DIR, { recursive: true });

function loadConfig() {
    try {
        if (fs.existsSync(BOT_STATUS_FILE)) {
            return JSON.parse(fs.readFileSync(BOT_STATUS_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[subbots-admins] Error cargando bot-on-off.json:', e.message);
    }
    return {};
}

function saveConfig(data) {
    try {
        fs.writeFileSync(BOT_STATUS_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('[subbots-admins] Error guardando bot-on-off.json:', e.message);
        return false;
    }
}

// ── Funciones públicas (usadas por handler.js) ───────────────────────────────

/**
 * Verifica el estado del bot en un grupo.
 * Devuelve: true (encendido), false (apagado), 'admins' (solo admins)
 */
function getGroupJidKeys(groupJid) {
    if (!groupJid) return { raw: '', digits: '' };
    const raw = String(groupJid).split('@')[0].split(':')[0].trim();
    const digits = raw.replace(/\D/g, '');
    return { raw, digits };
}

function isBotEnabled(groupJid) {
    if (!groupJid) return true;
    const config = loadConfig();
    const { raw, digits } = getGroupJidKeys(groupJid);

    let status = config[raw];
    if (status === undefined && digits && digits !== raw) {
        status = config[digits];
    }

    if (status === false || status === 'off') return false;
    if (status === 'admins')                  return 'admins';
    return true;
}

function setBotStatus(groupJid, mode) {
    if (!groupJid) return false;
    const config = loadConfig();
    const { raw, digits } = getGroupJidKeys(groupJid);

    if (mode === 'on') {
        if (raw) delete config[raw];
        if (digits) delete config[digits];
    } else if (mode === 'off' || mode === false) {
        if (raw) config[raw] = false;
        if (digits && digits !== raw) delete config[digits];
    } else {
        if (raw) config[raw] = mode;
        if (digits && digits !== raw) delete config[digits];
    }
    return saveConfig(config);
}

function formatSubbotList(subbots) {
    if (!Array.isArray(subbots) || subbots.length === 0) {
        return '📭 No hay subbots activos en este grupo.';
    }

    const lines = subbots.map((subbot) => {
        const subNum = subbot?.subNum ?? subbot?._subNum ?? '??';
        const rawId = subbot?.id || subbot?.user?.id || subbot?.user?.jid || '';
        const cleanId = String(rawId).split('@')[0].split(':')[0];
        const withPlus = cleanId ? `+${cleanId}` : 'Sin ID';
        return `#${subNum} — ${withPlus}`;
    });

    return `📋 *Subbots en este grupo*\n\n${lines.join('\n')}\n\n🔢 Total: ${subbots.length}`;
}

async function getSubbotsInGroup(groupJid, sock) {
    const activeSubbots = (global.subConns || [])
        .filter(c => c && c.user && c._subNum != null && c !== global.conn)
        .sort((a, b) => (a._subNum || 0) - (b._subNum || 0));

    const found = [];

    for (const subbot of activeSubbots) {
        try {
            await subbot.groupMetadata(groupJid);
            found.push({
                subNum: subbot._subNum,
                id: subbot.user?.id || subbot.user?.jid || null,
                _subNum: subbot._subNum
            });
        } catch (e) {
            // Ignorar subbots que no están en este grupo o no pueden verlo.
        }
    }

    return found;
}

// ── Handler: .bots ───────────────────────────────────────────────────────────
const botsHandler = async (message, { conn } = {}) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        const sock   = message._sock || conn;

        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ El comando *.bots* solo funciona en grupos.');
        }

        // Verificar que el remitente es admin del grupo
        const groupMetadata = await getGroupMetadataCached(sock || global.conn, chatId);
        const participants  = groupMetadata?.participants || [];
        const senderNum     = (message.sender || '').split('@')[0].split(':')[0];

        // Verificar que el remitente es admin del grupo o el owner del bot
        const botConfig = global.botConfig || require('../../config');
        const isBotOwner = message.key?.fromMe || (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum));

        const senderParticipant = participants.find(p =>
            p.id.split('@')[0].split(':')[0] === senderNum
        );
        const isAdmin = senderParticipant &&
            (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

        if (!isAdmin && !isBotOwner) {
            return await message.reply('❌ Solo los *administradores del grupo* pueden usar *.bots*.');
        }

        const args   = (message.body || '').split(/\s+/).slice(1);
        const action = (args[0] || '').toLowerCase();

        // ── Sin argumentos → mostrar estado ──────────────────────────────────
        if (!action) {
            const status = isBotEnabled(chatId);
            let statusText, icon;
            if (status === false)    { statusText = '❌ Apagado';                icon = '🔴'; }
            else if (status === 'admins') { statusText = '🔒 Solo administradores'; icon = '🟡'; }
            else                     { statusText = '✅ Encendido';              icon = '🟢'; }

            let txt  = `${icon} *Estado de los bots en este grupo*\n\n`;
            txt += `📊 *Estado actual:* ${statusText}\n\n`;
            txt += `💡 *Comandos disponibles:*\n`;
            txt += `  • *.bots on* — encender todos los bots\n`;
            txt += `  • *.bots off* — apagar todos los bots\n`;
            txt += `  • *.bots admins* — solo administradores\n`;
            txt += `  • *.bots list* — ver subbots presentes en este grupo\n\n`;
            txt += `ℹ️ _Solo administradores del grupo pueden usar estos comandos._`;
            return await message.reply(txt);
        }

        // ── Procesar acción ───────────────────────────────────────────────────
        const isOn     = ['on', 'activar', 'encender'].includes(action);
        const isOff    = ['off', 'desactivar', 'apagar'].includes(action);
        const isAdmins = action === 'admins';
        const isList   = ['list', 'lista', 'l'].includes(action);

        if (isList) {
            await message.reply('🔎 Detectando subbots en este grupo, un momento...');
            const subbots = await getSubbotsInGroup(chatId, sock);
            return await message.reply(formatSubbotList(subbots));
        }

        if (!isOn && !isOff && !isAdmins) {
            return await message.reply('⚠️ Uso: *.bots on* | *.bots off* | *.bots admins* | *.bots list*');
        }

        const mode = isOn ? 'on' : isOff ? 'off' : 'admins';

        if (setBotStatus(chatId, mode)) {
            let msg;
            if (mode === 'on') {
                msg  = `✅ *Bots encendidos en este grupo*\n\n`;
                msg += `Todos los bots pueden responder a los miembros del grupo.`;
            } else if (mode === 'off') {
                msg  = `❌ *Bots apagados en este grupo*\n\n`;
                msg += `Ningún bot responderá en este grupo.\n\n`;
                msg += `💡 Para volver a encenderlos: *.bots on*`;
            } else {
                msg  = `🔒 *Bots en modo solo administradores*\n\n`;
                msg += `Solo los administradores del grupo pueden usar los bots.\n\n`;
                msg += `💡 Para permitir a todos: *.bots on*`;
            }
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('[subbots-admins] Error en .bots:', error.message);
        await message.reply('❌ Error al procesar el comando.').catch(() => {});
    }
};

botsHandler.help    = ['bots'];
botsHandler.tags    = ['subbots'];
botsHandler.command = /^bots(?:\s+\S+)?$/i;
botsHandler.group   = true;
botsHandler.admin   = true;

// ── Exports ──────────────────────────────────────────────────────────────────
module.exports              = botsHandler;
module.exports.isBotEnabled = isBotEnabled;
module.exports.setBotStatus = setBotStatus;
module.exports.formatSubbotList = formatSubbotList;
module.exports.getSubbotsInGroup = getSubbotsInGroup;
