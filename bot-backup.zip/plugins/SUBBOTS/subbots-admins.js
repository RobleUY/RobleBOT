'use strict';

const fs   = require('fs');
const path = require('path');

// ── Archivo de configuración (mismo que usaba bot-on-off.js) ─────────────────
// Mantenemos la ruta existente para preservar los datos históricos del grupo.
const GRUPOS_DIR      = path.join(__dirname, '..', 'GRUPOS');
const BOT_STATUS_FILE = path.join(GRUPOS_DIR, 'bot-on-off.json');

if (!fs.existsSync(GRUPOS_DIR)) fs.mkdirSync(GRUPOS_DIR, { recursive: true });

// ── Caché en memoria ─────────────────────────────────────────────────────────
let _cache = null, _cacheMtime = 0;

function loadConfig() {
    try {
        if (fs.existsSync(BOT_STATUS_FILE)) {
            const mtime = fs.statSync(BOT_STATUS_FILE).mtimeMs;
            if (_cache !== null && mtime === _cacheMtime) return _cache;
            _cache      = JSON.parse(fs.readFileSync(BOT_STATUS_FILE, 'utf8'));
            _cacheMtime = mtime;
            return _cache;
        }
    } catch (e) { console.error('[subbots-admins] Error cargando bot-on-off.json:', e.message); }
    _cache = {};
    return _cache;
}

function saveConfig(data) {
    try {
        fs.writeFileSync(BOT_STATUS_FILE, JSON.stringify(data, null, 2), 'utf8');
        _cache      = data;
        _cacheMtime = fs.statSync(BOT_STATUS_FILE).mtimeMs;
        return true;
    } catch (e) {
        console.error('[subbots-admins] Error guardando bot-on-off.json:', e.message);
        return false;
    }
}

// ── Funciones públicas (usadas por handler.js) ───────────────────────────────

/**
 * Verifica el estado del bot en un grupo.
 * Devuelve: true (encendido) o false (apagado).
 */
function isBotEnabled(groupJid) {
    const config   = loadConfig();
    const cleanJid = groupJid.split('@')[0];
    const status   = config[cleanJid];
    if (status === false) return false;
    if (status === 'admins') return 'admins';
    return true;
}

function setBotStatus(groupJid, mode) {
    const config   = loadConfig();
    const cleanJid = groupJid.split('@')[0];
    if (mode === 'on') {
        delete config[cleanJid];
    } else if (mode === 'off') {
        config[cleanJid] = false;
    } else if (mode === 'admins') {
        config[cleanJid] = 'admins';
    }
    return saveConfig(config);
}

/**
 * Comprueba si un usuario concreto puede usar los bots en un grupo.
 * Solo comprueba al usuario (no usa caché de todos los participantes).
 */
async function isUserAllowed(groupJid, senderNumber, sock, fromMe = false) {
    // Si viene del propio bot (fromMe) permitir
    if (fromMe) return true;

    const status = isBotEnabled(groupJid);
    if (status === false) return false;
    if (status !== 'admins') return true;

    try {
        const socket = sock || global.conn;
        const groupMetadata = await socket.groupMetadata(groupJid);
        const participants = groupMetadata.participants || [];
        const senderParticipant = participants.find(p =>
            p.id.split('@')[0].split(':')[0] === String(senderNumber)
        );

        const botConfig = global.botConfig || require('../../config');
        const isOwner = (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNumber));

        const isAdmin = senderParticipant && (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');
        return !!(isAdmin || isOwner);
    } catch (e) {
        console.error('[subbots-admins] isUserAllowed error:', e && e.message ? e.message : e);
        // En caso de error de consulta, ser conservador y bloquear
        return false;
    }
}

// ── Handler: .bots ───────────────────────────────────────────────────────────
const botsHandler = async (message, { conn } = {}) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        const sock   = message._sock || conn;

        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ El comando *.bots* solo funciona en grupos.');
        }

        // Verificar que el remitente es admin del grupo
        const groupMetadata = await (sock || global.conn).groupMetadata(chatId);
        const participants  = groupMetadata.participants;
        const senderNum     = (message.sender || '').split('@')[0].split(':')[0];

        // Verificar que el remitente es admin del grupo o el owner del bot
        const botConfig = global.botConfig || require('../../config');
        const isBotOwner = message.key?.fromMe || (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum));

        const senderParticipant = participants.find(p =>
            p.id.split('@')[0].split(':')[0] === senderNum
        );
        const isAdmin = senderParticipant &&
            (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

        if (!isAdmin && !isBotOwner) {
            return await message.reply('❌ Solo los *administradores del grupo* pueden usar *.bots*.');
        }

        const args   = (message.body || '').split(/\s+/).slice(1);
        const action = (args[0] || '').toLowerCase();

        // ── Sin argumentos → mostrar estado ──────────────────────────────────
        if (!action) {
            const status = isBotEnabled(chatId);
            let statusText, icon;
            if (status === false) { statusText = '❌ Apagado'; icon = '🔴'; }
            else                  { statusText = '✅ Encendido'; icon = '🟢'; }

            let txt  = `${icon} *Estado de los bots en este grupo*\n\n`;
            txt += `📊 *Estado actual:* ${statusText}\n\n`;
            txt += `💡 *Comandos disponibles:*\n`;
            txt += `  • *.bots on* — encender todos los bots\n`;
            txt += `  • *.bots off* — apagar todos los bots\n\n`;
            txt += `ℹ️ _Solo administradores del grupo pueden usar estos comandos._`;
            return await message.reply(txt);
        }

        // ── Procesar acción ───────────────────────────────────────────────────
        const isOn     = ['on', 'activar', 'encender'].includes(action);
        const isOff    = ['off', 'desactivar', 'apagar'].includes(action);
        const isAdmins = ['admins', 'admin', 'soloadmins', 'solo-admins'].includes(action);

        if (!isOn && !isOff && !isAdmins) {
            return await message.reply('⚠️ Uso: *.bots on* | *.bots off* | *.bots admins*');
        }

        const mode = isOn ? 'on' : (isOff ? 'off' : 'admins');

        if (setBotStatus(chatId, mode)) {
            let msg;
            if (mode === 'on') {
                msg  = `✅ *Bots encendidos en este grupo*\n\n`;
                msg += `Todos los bots pueden responder a los miembros del grupo.`;
            } else if (mode === 'off') {
                msg  = `❌ *Bots apagados en este grupo*\n\n`;
                msg += `Ningún bot responderá en este grupo.\n\n`;
                msg += `💡 Para volver a encenderlos: *.bots on*`;
            } else if (mode === 'admins') {
                msg  = `🔒 *Bots solo para administradores*\n\n`;
                msg += `Solo los administradores del grupo podrán usar los comandos de los bots.`;
            }
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('[subbots-admins] Error en .bots:', error.message);
        await message.reply('❌ Error al procesar el comando.').catch(() => {});
    }
};

botsHandler.help    = ['bots'];
botsHandler.tags    = ['subbots'];
botsHandler.command = /^bots$/i;
botsHandler.group   = true;
botsHandler.admin   = true;

// ── Exports ──────────────────────────────────────────────────────────────────
module.exports              = botsHandler;
module.exports.isBotEnabled = isBotEnabled;
module.exports.setBotStatus = setBotStatus;
module.exports.isUserAllowed = isUserAllowed;
