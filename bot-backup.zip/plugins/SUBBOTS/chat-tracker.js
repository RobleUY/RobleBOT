'use strict';

// ── chat-tracker.js ──────────────────────────────────────────────────────
// Registro liviano de "último mensaje visto por chat", por bot/subbot.
// Baileys no expone una lista de chats por defecto (a menos que uses un
// store completo), así que este módulo la arma pasivamente a medida que
// van llegando mensajes. Es la base para .borrarchat all.
//
// Ubicación: plugins/SUBBOTS/chat-tracker.js (mismo nivel que subbot-serbot.js
// y borrar-chat.js). Guarda su archivo de datos en plugins/SUBBOTS/data/,
// igual que subbot-onoff.json / subbot-responder.json.

const fs = require('fs');
const path = require('path');

const DATA_DIR   = path.join(__dirname, 'data');
const CHATS_FILE = path.join(DATA_DIR, 'known-chats.json');
const FLUSH_MS   = 5000; // cada cuánto se escribe a disco como máximo

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let cache = null;
let dirty = false;

function load() {
    if (cache) return cache;
    try {
        if (fs.existsSync(CHATS_FILE)) {
            cache = JSON.parse(fs.readFileSync(CHATS_FILE, 'utf8'));
            return cache;
        }
    } catch (e) {
        console.error('[chat-tracker] Error cargando known-chats.json:', e.message);
    }
    cache = {};
    return cache;
}

function flush() {
    if (!dirty || !cache) return;
    try {
        fs.writeFileSync(CHATS_FILE, JSON.stringify(cache, null, 2), 'utf8');
        dirty = false;
    } catch (e) {
        console.error('[chat-tracker] Error guardando known-chats.json:', e.message);
    }
}

const flushTimer = setInterval(flush, FLUSH_MS);
if (typeof flushTimer.unref === 'function') flushTimer.unref();
process.on('exit', flush);

function getCleanBotNum(botNum) {
    if (botNum === null || botNum === undefined) return 'main';
    const str = String(botNum).trim();
    if (str.toLowerCase() === 'main' || str === '') return 'main';
    const digits = str.replace(/\D/g, '');
    return digits || str;
}

/**
 * Registra/actualiza el último mensaje visto en un chat, para un bot/subbot.
 * Se llama una vez por cada mensaje entrante (ver integración más abajo).
 */
function trackChat(botNum, chatJid, key, messageTimestamp) {
    if (!chatJid || !key) return;
    const bn = getCleanBotNum(botNum);
    const data = load();
    if (!data[bn]) data[bn] = {};
    data[bn][chatJid] = {
        key,
        messageTimestamp: messageTimestamp || Math.floor(Date.now() / 1000)
    };
    dirty = true;
}

/** Devuelve [{ chatJid, key, messageTimestamp }, ...] para un bot/subbot dado. */
function getTrackedChats(botNum) {
    const bn = getCleanBotNum(botNum);
    const data = load();
    const chats = data[bn] || {};
    return Object.entries(chats).map(([chatJid, info]) => ({
        chatJid,
        key: info.key,
        messageTimestamp: info.messageTimestamp
    }));
}

function removeTrackedChat(botNum, chatJid) {
    const bn = getCleanBotNum(botNum);
    const data = load();
    if (data[bn] && data[bn][chatJid]) {
        delete data[bn][chatJid];
        dirty = true;
    }
}

function clearTrackedChats(botNum) {
    const bn = getCleanBotNum(botNum);
    const data = load();
    if (data[bn]) {
        delete data[bn];
        dirty = true;
    }
}

module.exports = {
    trackChat,
    getTrackedChats,
    removeTrackedChat,
    clearTrackedChats
};