'use strict';
const { 
    default: makeWASocket, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore 
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./singleFileAuthState'); // Misma carpeta
const P = require('pino');
const path = require('path');
const fs = require('fs');

let handler = async (message) => {
    try {
        // 1. Detección automática de identidad (Lógica maestra)
        const key = message.key || {};
        const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid;
        const numeroReal = jidReal ? jidReal.split('@')[0] : null;

        if (!numeroReal) {
            return await message.reply('❌ No pude detectar tu número real.');
        }

        await message.reply(`⏳ Generando código de emparejamiento para: ${numeroReal}...`);

        // 2. Configuración de sesión (testeo_subbot.db)
        const SESSIONS_DIR = path.join(__dirname, 'sesiones');
        if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
        
        const sessionPath = path.join(SESSIONS_DIR, 'testeo_subbot.db');
        
        // 3. Inicializar auth state
        const { state, saveCreds } = await useSQLiteAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        // 4. Crear socket del sub-bot
        const conn = makeWASocket({
            logger: P({ level: 'silent' }),
            printQRInTerminal: false,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' })),
            },
            version,
        });

        // 5. Solicitar Pairing Code
        if (!conn.authState.creds.registered) {
            // Esperar un poco para asegurar que el socket conecte
            await new Promise(resolve => setTimeout(resolve, 2000));
            const code = await conn.requestPairingCode(numeroReal);
            
            await message.reply(
                `✅ *Código generado para ${numeroReal}*\n\n` +
                `🔢 *${code}*\n\n` +
                `_Pasos: WhatsApp -> Dispositivos vinculados -> Vincular dispositivo -> Vincular con número de teléfono._`
            );
        } else {
            await message.reply('⚠️ Ya existe una sesión iniciada en `testeo_subbot.db`. Borra el archivo .db para intentar de nuevo.');
        }

        conn.ev.on('creds.update', saveCreds);

    } catch (e) {
        console.error(e);
        await message.reply('❌ Error al iniciar el sub-bot de testeo: ' + e.message);
    }
};

handler.command = /^testcode$/i;
module.exports = handler;