'use strict';

/**
 * Comando .subbotsclean2
 * Detecta subbots DUPLICADOS: casos donde el mismo número de WhatsApp
 * (el owner) vinculó su sesión más de una vez, generando 2 o más
 * SubBots #xxxx distintos para el mismo dueño.
 *
 * Para cada grupo de duplicados, se queda con el más "útil" (el que
 * más comandos tiene ejecutados; en empate, el usado más recientemente)
 * y elimina el resto — sin importar si están conectados o no.
 *
 * No requiere argumentos. Uso: .subbotsclean2
 * Solo ejecutable por owners.
 */

const fs       = require('fs');
const path     = require('path');
const Database = require('better-sqlite3');

const activityTracker = require('./subbotActivityTracker');
const { forgetSubBot, removeSessionFiles } = require('./subbot-serbot');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

// ── Helpers ────────────────────────────────────────────────────────────────
function listRegisteredNums() {
    if (!fs.existsSync(SESSIONS_DIR)) return [];
    return fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function isValidSessionDb(dbFile) {
    if (!fs.existsSync(dbFile)) return false;
    try {
        const stats = fs.statSync(dbFile);
        if (stats.size < 100) return false;
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = -256');
        db.pragma('busy_timeout = 2000');
        const hasAuthTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='auth'").get();
        if (!hasAuthTable) { db.close(); return false; }
        const rowCreds = db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
        db.close();
        return !!(rowCreds && rowCreds.value);
    } catch {
        return false;
    }
}

/**
 * Lee el owner real (número de teléfono limpio) guardado en la sesión.
 * Devuelve null si la sesión es inválida o nunca llegó a conectarse
 * (no tiene _owner todavía, ej: quedó a mitad de un QR/code sin terminar).
 */
function getOwnerPhone(num) {
    const dbFile = sessionPath(num);
    if (!isValidSessionDb(dbFile)) return null;
    try {
        const db = new Database(dbFile, { readonly: true });
        db.pragma('cache_size = -256');
        db.pragma('busy_timeout = 2000');
        const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
        db.close();
        if (!row) return null;
        const data = JSON.parse(row.value);
        const phone = (data.phoneNumber || '').replace(/[^0-9]/g, '');
        return phone || null;
    } catch {
        return null;
    }
}

/**
 * Borra un subbot de forma definitiva: primero lo purga de TODA la memoria
 * (sockets, colas de reconexión, timers) para que no se "reconecte solo" y
 * recree el .db, y recién después borra los archivos de sesión en disco.
 * Devuelve true solo si el .db realmente dejó de existir.
 */
function wipeSubBot(num) {
    try {
        forgetSubBot(num);
    } catch (e) {
        console.error(`[subbotsclean2] Error purgando memoria de #${num}:`, e.message);
    }
    const { dbGone } = removeSessionFiles(num);
    return dbGone;
}

// ── Handler ───────────────────────────────────────────────────────────────
const handler = async (message) => {
    try {
        const registeredNums = listRegisteredNums();

        if (registeredNums.length === 0) {
            return await message.reply('📭 No hay subbots registrados.');
        }

        await message.reply(`🔍 Analizando ${registeredNums.length} sesiones en busca de duplicados...`);

        // ── Agrupar por número real de owner ─────────────────────────────
        const groups = new Map();   // phoneNumber -> [num, num, ...]
        let sinOwnerCount = 0;

        for (const num of registeredNums) {
            const phone = getOwnerPhone(num);
            if (!phone) {
                sinOwnerCount++;
                continue;
            }
            if (!groups.has(phone)) groups.set(phone, []);
            groups.get(phone).push(num);
        }

        const duplicateGroups = [...groups.entries()].filter(([, nums]) => nums.length > 1);

        if (duplicateGroups.length === 0) {
            let msg = '✅ No se encontraron sesiones duplicadas (ningún número está vinculado más de una vez).';
            if (sinOwnerCount > 0) {
                msg += `\n\nℹ️ Nota: ${sinOwnerCount} sesión(es) no tienen owner registrado (quedaron a medio vincular) y no se tocaron. Podés revisarlas con \`.subbotsclean\` si querés purgarlas.`;
            }
            return await message.reply(msg);
        }

        // ── Decidir cuál mantener en cada grupo y borrar el resto ─────────
        const activityData = activityTracker.loadActivity();

        let totalEliminados = 0;
        let totalErrores    = 0;
        const resumenLines  = [];

        for (const [phone, nums] of duplicateGroups) {
            const withStats = nums.map(n => ({
                num:          n,
                commandCount: activityData[String(n)]?.commandCount || 0,
                lastUsed:     activityData[String(n)]?.lastUsed     || 0
            }));

            // Mantener el de más uso; en empate, el más reciente
            withStats.sort((a, b) => {
                if (b.commandCount !== a.commandCount) return b.commandCount - a.commandCount;
                return b.lastUsed - a.lastUsed;
            });

            const keep      = withStats[0];
            const toDelete  = withStats.slice(1);
            const deletedOk = [];
            const deletedErr = [];

            for (const bot of toDelete) {
                try {
                    const dbGone = wipeSubBot(bot.num);
                    if (dbGone) {
                        totalEliminados++;
                        deletedOk.push(`#${bot.num}`);
                    } else {
                        totalErrores++;
                        deletedErr.push(`#${bot.num}`);
                    }
                } catch (e) {
                    totalErrores++;
                    deletedErr.push(`#${bot.num}`);
                    console.error(`[subbotsclean2] Error eliminando #${bot.num}:`, e.message);
                }
            }

            let line = `📱 +${phone} — ${nums.length} sesiones duplicadas\n` +
                       `   ✅ Se mantiene: #${keep.num} (⚡ ${keep.commandCount} usos)`;
            if (deletedOk.length)  line += `\n   🗑️ Eliminados: ${deletedOk.join(', ')}`;
            if (deletedErr.length) line += `\n   ⚠️ No se pudieron borrar: ${deletedErr.join(', ')}`;

            resumenLines.push(line);
        }

        let resumen = `✅ *Limpieza de duplicados completada*\n\n`;
        resumen += `Se encontraron *${duplicateGroups.length}* número${duplicateGroups.length !== 1 ? 's' : ''} con sesiones repetidas:\n\n`;
        resumen += resumenLines.join('\n\n');
        resumen += `\n\n📊 *Total eliminados:* ${totalEliminados}`;
        if (totalErrores > 0) resumen += `\n⚠️ *Total con error:* ${totalErrores}`;
        if (sinOwnerCount > 0) resumen += `\n\nℹ️ ${sinOwnerCount} sesión(es) sin owner registrado no se tocaron (quedaron a medio vincular).`;

        await message.reply(resumen);

    } catch (error) {
        console.error('[subbotsclean2] Error general:', error.message);
        await message.reply('❌ Error al procesar el comando.').catch(() => {});
    }
};

handler.help    = ['subbotsclean2'];
handler.tags    = ['subbots'];
handler.command = /^subbotsclean2$/i;
handler.owner   = true;

module.exports = handler;