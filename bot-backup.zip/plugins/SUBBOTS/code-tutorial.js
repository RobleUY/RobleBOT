const fs = require('fs');
const path = require('path');

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;

    try {
        const videoPath = path.join(__dirname, 'tutorial-code.mp4');

        if (!fs.existsSync(videoPath)) {
            return await message.reply('❌ No se encontró el archivo `tutorial-code.mp4`.');
        }

        // Mensaje rápido antes de enviar el video
        await message.reply('📤 Enviando el tutorial, espera un momento...');

        await sock.sendMessage(
            message.from,
            {
                video: fs.readFileSync(videoPath),
                mimetype: 'video/mp4',
                fileName: 'tutorial-code.mp4',
                caption: '🎬 Aquí tienes el tutorial de código.'
            },
            { quoted: message._baileyMessage }
        );
    } catch (e) {
        console.error('[CODETUTORIAL]', e);
        await message.reply(`❌ Error: ${e.message}`);
    }
};

handler.help = ['codetutorial', 'tutocode', 'codetuto'];
handler.tags = ['fun'];
handler.command = /^(codetutorial|tutocode|codetuto)$/i;

module.exports = handler;