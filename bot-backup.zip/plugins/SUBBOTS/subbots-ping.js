let handler = async (message, { text, command }) => {
    const conn = global.conn;
    if (!conn?.user?.id) {
        return await message.reply('❌ El bot principal no está conectado actualmente.');
    }

    const mainNumber = conn.user.id.split('@')[0].split(':')[0];
    const mainJid = `${mainNumber}@s.whatsapp.net`;
    const subConns = Array.isArray(global.subConns) ? global.subConns : [];
    let subs = subConns.filter(sub => sub && sub.user);

    if (subs.length === 0) {
        return await message.reply('ℹ️ No hay SubBots conectados en este momento.');
    }

    // Comprobamos si el usuario quiere filtrar por un sub-bot específico
    const isSinglePing = command.toLowerCase() === 'botping';
    const targetNum = text ? text.trim() : null;

    if (isSinglePing) {
        if (!targetNum) {
            return await message.reply('⚠️ Debes especificar el número de 4 dígitos del SubBot. Ejemplo: *.botping 2068*');
        }
        // Filtramos la lista para quedarnos solo con el solicitado
        subs = subs.filter(sub => String(sub._subNum) === targetNum);
        if (subs.length === 0) {
            return await message.reply(`❌ No se encontró ningún SubBot activo con el número *#${targetNum}*.`);
        }
    }

    // Enviamos el mensaje de aviso inmediato para que sepas que está procesando
    const avisoTexto = isSinglePing 
        ? `⏳ Enviando ping de verificación al SubBot *#${targetNum}...*`
        : `⏳ Enviando ping a los *${subs.length}* SubBots conectados... Esto puede demorar unos segundos.`;
    
    await message.reply(avisoTexto);

    const results = [];
    for (const sub of subs) {
        const subNum = sub._subNum || '??';
        const canSend = typeof sub?.sendMessage === 'function';

        if (!canSend) {
            results.push(`⚠️ SubBot #${subNum} no tiene la función sendMessage disponible.`);
            continue;
        }

        const pingText = `🟢 Bot *#${subNum}* activo correctamente.\n\n> Este es un mensaje automático enviado para garantizar la correcta conexión del subbot.`;
        try {
            await sub.sendMessage(mainJid, { text: pingText });
            results.push(`✅ SubBot #${subNum} notificado`);
        } catch (error) {
            results.push(`❌ Falló SubBot #${subNum}: ${error?.message || 'error desconocido'}`);
        }
    }

    const done = results.filter(r => r.startsWith('✅')).length;
    const failed = results.length - done;
    
    // Armamos el reporte final
    const replyText = `📣 Reporte de Ping Finalizado.\n\n✅ Enviados: ${done}\n❌ Fallidos: ${failed}\n\n${results.join('\n')}`;
    await message.reply(replyText);
};

handler.help = ['botsping', 'botping <4-dígitos>'];
handler.tags = ['subbots'];
handler.command = /^(botsping|pingbots|botping|pingbot)$/i;
handler.owner = true;

module.exports = handler;
