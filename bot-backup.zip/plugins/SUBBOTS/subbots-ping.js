let handler = async (message) => {
    const conn = global.conn;
    if (!conn?.user?.id) {
        return await message.reply('❌ El bot principal no está conectado actualmente. Intenta de nuevo cuando el servidor esté activo.');
    }

    const mainJid = conn.user.id;
    const subs = Array.isArray(global.subConns) ? global.subConns : [];

    if (subs.length === 0) {
        return await message.reply('ℹ️ No hay SubBots conectados en este momento.');
    }

    const results = [];

    for (const sub of subs) {
        try {
            if (!sub || !sub.sendMessage || sub.ws?.readyState !== 1) {
                results.push(`⚠️ SubBot #${sub?._subNum ?? '??'} no está conectado`);
                continue;
            }

            const subNum = sub._subNum || '??';
            const text = `🟢 Bot *#${subNum}* activo correctamente.\n\n> Este es un mensaje automático enviado para garantizar la correcta conexión del subbot.`;
            await sub.sendMessage(mainJid, { text });
            results.push(`✅ SubBot #${subNum} notificado`);
        } catch (error) {
            results.push(`❌ Falló SubBot #${sub?._subNum ?? '??'}: ${error.message || 'error desconocido'}`);
        }
    }

    const done = results.filter(r => r.startsWith('✅')).length;
    const failed = results.length - done;
    const replyText = `📣 Ping enviado a los SubBots.\n\n✅ Enviados: ${done}\n❌ Fallidos: ${failed}\n\n${results.join('\n')}`;
    await message.reply(replyText);
};

handler.help = ['botsping', 'pingbots'];
handler.tags = ['subbots'];
handler.command = /^(botsping|pingbots)$/i;
handler.owner = true;

module.exports = handler;
