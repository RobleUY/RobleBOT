let handler = async (message, { text, command }) => {
    const sock = message._sock || global.conn;
    
    // Extracción dinámica y segura del número del bot principal para los avisos
    const mainBotJid = global.conn?.user?.id || sock?.user?.id || '';
    if (!mainBotJid) {
        return await message.reply('❌ El bot principal no está conectado actualmente.');
    }
    
    const mainBotNum = mainBotJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    const mainJid = `${mainBotNum}@s.whatsapp.net`;
    const linkMainBot = mainBotNum ? `wa.me/${mainBotNum}` : 'al administrador';

    // 1. Verificar que el comando se ejecute en un chat privado
    if (message.isGroup) {
        return sock.sendMessage(message.from, {
            text: `❌ Este comando solo funciona por privado.\n📱 Por favor, escribe directamente al *bot principal* aquí: *${linkMainBot}*`
        }, { quoted: message._baileyMessage });
    }

    // 2. Verificar si el comando se está ejecutando desde un sub-bot y denegar el acceso
    if (message._subNum || sock.user?.id !== global.conn?.user?.id) {
        return sock.sendMessage(message.from, {
            text: `❌ Este comando solo funciona en el *bot principal*.\n📱 Contacta directamente al bot principal para gestionar los pings aquí: *${linkMainBot}*`
        }, { quoted: message._baileyMessage });
    }

    // Obtener lista de subbots conectados en el sistema global
    const subConns = Array.isArray(global.subConns) ? global.subConns : [];
    let subs = subConns.filter(sub => sub && sub.user);

    if (subs.length === 0) {
        return await message.reply('ℹ️ No hay SubBots conectados en este momento.');
    }

    const target = text ? text.trim().toLowerCase() : null;

    // 3. Validar los parámetros del comando unificado
    if (!target) {
        return await message.reply('⚠️ Debes especificar el número de 4 dígitos del SubBot o usar *all* para todos. Ejemplo:\n*.botping 2068*\n*.botping all*');
    }

    const isAll = target === 'all';

    // Si no es "all", filtramos por el número de 4 dígitos especificado
    if (!isAll) {
        subs = subs.filter(sub => String(sub._subNum) === target);
        if (subs.length === 0) {
            return await message.reply(`❌ No se encontró ningún SubBot activo con el número *#${target}*.`);
        }
    }

    // Mensaje de aviso de procesamiento
    const avisoTexto = isAll 
        ? `⏳ Enviando ping a los *${subs.length}* SubBots conectados... Esto puede demorar unos segundos.`
        : `⏳ Enviando ping de verificación al SubBot *#${target}...*`;
    
    await message.reply(avisoTexto);

    const results = [];
    
    // Bucle de ejecución de los pings
    for (const sub of subs) {
        const subNum = sub._subNum || '??';
        const canSend = typeof sub?.sendMessage === 'function';

        if (!canSend) {
            results.push(`⚠️ SubBot #${subNum} no tiene la función sendMessage disponible.`);
            continue;
        }

        const pingText = `🟢 Bot *#${subNum}* activo correctamente.\n\n> Este es un mensaje automático enviado para garantizar la correcta conexión del subbot.`;
        try {
            await sub.sendMessage(mainJid, { text: pingText });
            results.push(`✅ SubBot #${subNum} notificado`);
        } catch (error) {
            results.push(`❌ Falló SubBot #${subNum}: ${error?.message || 'error desconocido'}`);
        }
    }

    // Conteo y reporte final
    const done = results.filter(r => r.startsWith('✅')).length;
    const failed = results.length - done;
    
    const replyText = `📣 Reporte de Ping Finalizado.\n\n✅ Enviados: ${done}\n❌ Fallidos: ${failed}\n\n${results.join('\n')}`;
    await message.reply(replyText);
};

handler.help = ['botping <4-dígitos/all>'];
handler.tags = ['subbots'];
handler.command = /^(botsping|pingbots|botping|pingbot)$/i;
handler.owner = true; // Sigue requiriendo ser Owner configurado en el bot principal

module.exports = handler;
