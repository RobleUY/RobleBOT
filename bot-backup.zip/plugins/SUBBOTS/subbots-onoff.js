'use strict';

const fs   = require('fs');
const path = require('path');

// ── Directorio de datos ──────────────────────────────────────────────────────
const DATA_DIR      = path.join(__dirname, 'data');
const ONOFF_FILE    = path.join(DATA_DIR, 'subbot-onoff.json');
const RESPONDER_FILE = path.join(DATA_DIR, 'subbot-responder.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Archivo de datos legado (mybot-on-off.json) para migración ───────────────
const LEGACY_FILE = path.join(__dirname, '..', 'GRUPOS', 'mybot-on-off.json');

// ── Caché en memoria ─────────────────────────────────────────────────────────
let _onoffCache = null, _onoffMtime = 0;
let _respCache  = null, _respMtime  = 0;

function loadOnOff() {
    try {
        if (fs.existsSync(ONOFF_FILE)) {
            const mtime = fs.statSync(ONOFF_FILE).mtimeMs;
            if (_onoffCache !== null && mtime === _onoffMtime) return _onoffCache;
            _onoffCache = JSON.parse(fs.readFileSync(ONOFF_FILE, 'utf8'));
            _onoffMtime = mtime;
            return _onoffCache;
        }
    } catch (e) { console.error('[subbots-onoff] Error cargando onoff.json:', e.message); }
    _onoffCache = {};
    return _onoffCache;
}

function saveOnOff(data) {
    try {
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(data, null, 2), 'utf8');
        _onoffCache = data;
        _onoffMtime = fs.statSync(ONOFF_FILE).mtimeMs;
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando onoff.json:', e.message);
        return false;
    }
}

function loadResponder() {
    try {
        if (fs.existsSync(RESPONDER_FILE)) {
            const mtime = fs.statSync(RESPONDER_FILE).mtimeMs;
            if (_respCache !== null && mtime === _respMtime) return _respCache;
            _respCache = JSON.parse(fs.readFileSync(RESPONDER_FILE, 'utf8'));
            _respMtime = mtime;
            return _respCache;
        }
    } catch (e) { console.error('[subbots-onoff] Error cargando responder.json:', e.message); }
    _respCache = {};
    return _respCache;
}

function saveResponder(data) {
    try {
        fs.writeFileSync(RESPONDER_FILE, JSON.stringify(data, null, 2), 'utf8');
        _respCache = data;
        _respMtime = fs.statSync(RESPONDER_FILE).mtimeMs;
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando responder.json:', e.message);
        return false;
    }
}

// ── Migración del archivo legado mybot-on-off.json ───────────────────────────
// Se ejecuta una sola vez si el archivo nuevo aún no existe pero el viejo sí.
(function migrateLegacy() {
    try {
        if (fs.existsSync(ONOFF_FILE)) return;             // ya migrado
        if (!fs.existsSync(LEGACY_FILE)) return;           // no hay legado
        const old = JSON.parse(fs.readFileSync(LEGACY_FILE, 'utf8'));
        const nuevo = {};
        for (const [key, val] of Object.entries(old)) {
            // Formato viejo: "groupId_botNum" → nuevo: "chat_groupId_botNum"
            if (val === false) {
                nuevo[`chat_${key}`] = false;
            }
        }
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(nuevo, null, 2), 'utf8');
        console.log('[subbots-onoff] ✅ Migración de mybot-on-off.json completada.');
    } catch (e) {
        console.error('[subbots-onoff] Error en migración legado:', e.message);
    }
})();

// ── Funciones públicas (usadas por handler.js) ───────────────────────────────

/**
 * Verifica si el subbot está habilitado en un chat específico.
 * Devuelve false si está globalmente apagado O si ese chat fue apagado localmente.
 */
function isSubBotEnabled(chatJid, botNum) {
    const data     = loadOnOff();
    const cleanJid = chatJid.split('@')[0];

    // Apagado global del subbot
    if (data[`global_${botNum}`] === false) return false;

    // Apagado local en este chat
    if (data[`chat_${cleanJid}_${botNum}`] === false) return false;

    return true;
}

/**
 * Verifica si el subbot responde en chats privados.
 * Default: true
 */
function isSubBotRespondsInPriv(botNum) {
    const data   = loadResponder();
    const config = data[String(botNum)];
    return !config || config.priv !== false;
}

/**
 * Verifica si el subbot responde en grupos.
 * Default: true
 */
function isSubBotRespondsInGrupos(botNum) {
    const data   = loadResponder();
    const config = data[String(botNum)];
    return !config || config.grupos !== false;
}

// ── Helper: verificar que el remitente es el dueño del subbot o el owner principal del bot ────────────────
function isBotOwner(message, sock) {
    if (message.key?.fromMe) return true;
    const senderNum = (message.sender || '').split('@')[0].split(':')[0];
    const ownerNum  = (sock?._ownerJid || '').split('@')[0].split(':')[0];

    // Permitir también al owner principal del bot configurado en config.js
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) {
            return true;
        }
    } catch (e) {
        // Ignorar fallas cargando config
    }

    return senderNum && ownerNum && senderNum === ownerNum;
}


// ── Handler principal: .bot ──────────────────────────────────────────────────
const botHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = sock?._subNum;
        const chatId = message.from || message.key?.remoteJid;

        // Solo subbots pueden usar este comando
        if (!botNum) {
            return await message.reply(
                'ℹ️ Este comando es exclusivo de cada sub-bot.\n' +
                'Envíalo directamente al sub-bot que querés controlar.'
            );
        }

        // Solo el dueño del subbot puede usarlo
        if (!isBotOwner(message, sock)) return;

        const rawBody = message.body || '';
        const args    = rawBody.split(/\s+/).slice(1);
        const sub1    = (args[0] || '').toLowerCase();
        const sub2    = (args[1] || '').toLowerCase();

        // ── Sin argumentos → mostrar estado ──────────────────────────────────
        if (!sub1) {
            const onoffData = loadOnOff();
            const respData  = loadResponder();
            const cleanJid  = chatId?.split('@')[0] || '';
            const globalOff = onoffData[`global_${botNum}`] === false;
            const localOff  = onoffData[`chat_${cleanJid}_${botNum}`] === false;
            const resp      = respData[String(botNum)] || {};
            const privOk    = resp.priv !== false;
            const grupoOk   = resp.grupos !== false;

            let txt  = `🤖 *Estado del Sub-Bot #${botNum}*\n\n`;
            txt += `🌐 *Global:*     ${globalOff ? '❌ Apagado'    : '✅ Encendido'}\n`;
            txt += `💬 *Este chat:*  ${localOff  ? '❌ Apagado'    : '✅ Encendido'}\n`;
            txt += `📱 *Privados:*   ${privOk    ? '✅ Responde'   : '❌ No responde'}\n`;
            txt += `👥 *Grupos:*     ${grupoOk   ? '✅ Responde'   : '❌ No responde'}\n\n`;
            txt += `💡 *Comandos disponibles:*\n`;
            txt += `  • *.bot apagar* → solo este chat\n`;
            txt += `  • *.bot apagar global* → todos los chats\n`;
            txt += `  • *.bot encender* → solo este chat\n`;
            txt += `  • *.bot encender global* → todos los chats\n`;
            txt += `  • *.bot priv on/off* → responder en privados\n`;
            txt += `  • *.bot grupo on/off* → responder en grupos`;
            return await message.reply(txt);
        }

        // ── .bot priv / privado / private ────────────────────────────────────
        if (['priv', 'privado', 'private'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot priv on* o *.bot priv off*');
            }

            const data = loadResponder();
            if (!data[String(botNum)]) data[String(botNum)] = { priv: true, grupos: true };
            data[String(botNum)].priv = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *Sub-Bot #${botNum}*\n\n`;
                msg += `El sub-bot ${verb} en chats privados.\n\n`;
                msg += `💡 Para revertir: *.bot priv ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot grupo / grupos / group / groups ──────────────────────────────
        if (['grupo', 'grupos', 'group', 'groups'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot grupo on* o *.bot grupo off*');
            }

            const data = loadResponder();
            if (!data[String(botNum)]) data[String(botNum)] = { priv: true, grupos: true };
            data[String(botNum)].grupos = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *Sub-Bot #${botNum}*\n\n`;
                msg += `El sub-bot ${verb} en grupos.\n\n`;
                msg += `💡 Para revertir: *.bot grupo ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot on / off / encender / apagar [global / g] ───────────────────
        const isOn  = ['on', 'encender', 'activar'].includes(sub1);
        const isOff = ['off', 'apagar', 'desactivar'].includes(sub1);

        if (!isOn && !isOff) {
            return await message.reply(
                '⚠️ *Uso del comando .bot:*\n\n' +
                '  *.bot apagar* — solo este chat\n' +
                '  *.bot apagar global* — todos los chats\n' +
                '  *.bot encender* — solo este chat\n' +
                '  *.bot encender global* — todos los chats\n' +
                '  *.bot priv on/off* — responder en privados\n' +
                '  *.bot grupo on/off* — responder en grupos'
            );
        }

        const isGlobal = ['global', 'g'].includes(sub2);
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();

        if (isGlobal) {
            // ── Acción global ─────────────────────────────────────────────────
            if (isOn) {
                delete data[`global_${botNum}`];
                // IMPORTANTE: los chats desactivados manualmente NO se reactivan
            } else {
                data[`global_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    msg  = `✅ *Sub-Bot #${botNum} encendido globalmente*\n\n`;
                    msg += `El sub-bot responde en todos los chats nuevamente.\n\n`;
                    msg += `ℹ️ _Los chats que desactivaste manualmente siguen apagados._\n`;
                    msg += `💡 Para reactivarlos, enviá *.bot encender* en cada uno.`;
                } else {
                    msg  = `❌ *Sub-Bot #${botNum} apagado globalmente*\n\n`;
                    msg += `El sub-bot dejó de responder en todos los chats.\n\n`;
                    msg += `💡 Para encenderlo: *.bot encender global*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }

        } else {
            // ── Acción local (solo este chat) ─────────────────────────────────
            if (isOn) {
                delete data[`chat_${cleanJid}_${botNum}`];
            } else {
                data[`chat_${cleanJid}_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    msg  = `✅ *Sub-Bot #${botNum} encendido en este chat*\n\n`;
                    msg += `El sub-bot vuelve a responder aquí.\n\n`;
                    msg += `💡 Para apagar en todos lados: *.bot apagar global*`;
                } else {
                    msg  = `❌ *Sub-Bot #${botNum} apagado en este chat*\n\n`;
                    msg += `Este chat quedó desactivado únicamente.\n`;
                    msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
                    msg += `💡 Para volver a activarlo aquí: *.bot encender*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        }

    } catch (error) {
        console.error('[subbots-onoff] Error en .bot:', error.message);
    }
};

botHandler.help    = ['bot'];
botHandler.tags    = ['subbots'];
botHandler.command = /^bot$/i;

// ── Alias: .onmybot (compatibilidad veteranos) ───────────────────────────────
const onmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = sock?._subNum;
        if (!botNum) return;
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();
        delete data[`chat_${cleanJid}_${botNum}`];

        if (saveOnOff(data)) {
            let msg  = `✅ *Sub-Bot #${botNum} encendido en este chat*\n\n`;
            msg += `💡 Para apagar aquí: *.bot apagar* o *.offmybot*\n`;
            msg += `💡 Para apagar globalmente: *.bot apagar global*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en onmybot:', e.message);
    }
};
onmybotHandler.help    = ['onmybot'];
onmybotHandler.tags    = ['subbots'];
onmybotHandler.command = /^onmybot$/i;

// ── Alias: .offmybot (compatibilidad veteranos) ──────────────────────────────
const offmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = sock?._subNum;
        if (!botNum) return;
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();
        data[`chat_${cleanJid}_${botNum}`] = false;

        if (saveOnOff(data)) {
            let msg  = `❌ *Sub-Bot #${botNum} apagado en este chat*\n\n`;
            msg += `Este chat quedó desactivado únicamente.\n`;
            msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
            msg += `💡 Para volver a activarlo: *.bot encender* o *.onmybot*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en offmybot:', e.message);
    }
};
offmybotHandler.help    = ['offmybot'];
offmybotHandler.tags    = ['subbots'];
offmybotHandler.command = /^offmybot$/i;

// ── Exports ──────────────────────────────────────────────────────────────────
module.exports                      = botHandler;
module.exports.onmybotAlias         = onmybotHandler;   // cargado por el plugin loader
module.exports.offmybotAlias        = offmybotHandler;  // cargado por el plugin loader
module.exports.isSubBotEnabled      = isSubBotEnabled;
module.exports.isSubBotRespondsInPriv   = isSubBotRespondsInPriv;
module.exports.isSubBotRespondsInGrupos = isSubBotRespondsInGrupos;
