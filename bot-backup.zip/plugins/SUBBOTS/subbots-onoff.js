'use strict';

const fs   = require('fs');
const path = require('path');

// ── Directorio de datos ──────────────────────────────────────────────────────
const DATA_DIR      = path.join(__dirname, 'data');
const ONOFF_FILE    = path.join(DATA_DIR, 'subbot-onoff.json');
const RESPONDER_FILE = path.join(DATA_DIR, 'subbot-responder.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Archivo de datos legado (mybot-on-off.json) para migración ───────────────
const LEGACY_FILE = path.join(__dirname, '..', 'GRUPOS', 'mybot-on-off.json');

// ── Caché en memoria ultrarrápida ───────────────────────────────────────────────
let _onoffCache = null, _lastOnoffCheck = 0;
let _respCache  = null, _lastRespCheck  = 0;
const CACHE_TTL = 10000; // Recargar de disco máximo cada 10 segundos

function loadOnOff() {
    const now = Date.now();
    if (_onoffCache !== null && (now - _lastOnoffCheck < CACHE_TTL)) {
        return _onoffCache;
    }
    _lastOnoffCheck = now;
    try {
        if (fs.existsSync(ONOFF_FILE)) {
            _onoffCache = JSON.parse(fs.readFileSync(ONOFF_FILE, 'utf8'));
            return _onoffCache;
        }
    } catch (e) { console.error('[subbots-onoff] Error cargando onoff.json:', e.message); }
    if (_onoffCache === null) _onoffCache = {};
    return _onoffCache;
}

function saveOnOff(data) {
    try {
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(data, null, 2), 'utf8');
        _onoffCache = data;
        _lastOnoffCheck = Date.now();
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando onoff.json:', e.message);
        return false;
    }
}

function loadResponder() {
    const now = Date.now();
    if (_respCache !== null && (now - _lastRespCheck < CACHE_TTL)) {
        return _respCache;
    }
    _lastRespCheck = now;
    try {
        if (fs.existsSync(RESPONDER_FILE)) {
            _respCache = JSON.parse(fs.readFileSync(RESPONDER_FILE, 'utf8'));
            return _respCache;
        }
    } catch (e) { console.error('[subbots-onoff] Error cargando responder.json:', e.message); }
    if (_respCache === null) _respCache = {};
    return _respCache;
}

function saveResponder(data) {
    try {
        fs.writeFileSync(RESPONDER_FILE, JSON.stringify(data, null, 2), 'utf8');
        _respCache = data;
        _lastRespCheck = Date.now();
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando responder.json:', e.message);
        return false;
    }
}

// ── Migración del archivo legado mybot-on-off.json ───────────────────────────
// Se ejecuta una sola vez si el archivo nuevo aún no existe pero el viejo sí.
(function migrateLegacy() {
    try {
        if (fs.existsSync(ONOFF_FILE)) return;             // ya migrado
        if (!fs.existsSync(LEGACY_FILE)) return;           // no hay legado
        const old = JSON.parse(fs.readFileSync(LEGACY_FILE, 'utf8'));
        const nuevo = {};
        for (const [key, val] of Object.entries(old)) {
            // Formato viejo: "groupId_botNum" → nuevo: "chat_groupId_botNum"
            if (val === false) {
                nuevo[`chat_${key}`] = false;
            }
        }
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(nuevo, null, 2), 'utf8');
        console.log('[subbots-onoff] ✅ Migración de mybot-on-off.json completada.');
    } catch (e) {
        console.error('[subbots-onoff] Error en migración legado:', e.message);
    }
})();

// ── Funciones públicas (usadas por handler.js) ───────────────────────────────

/**
 * Verifica si el subbot está habilitado en un chat específico.
 * Prioridad: excepción local explícita > estado global > estado local apagado
 *
 * - Si el chat tiene una excepción local activa (=== true), responde aunque
 *   el global esté apagado.
 * - Si el global está apagado y no hay excepción local activa, no responde.
 * - Si el chat está apagado localmente (=== false), no responde.
 */
function isSubBotEnabled(chatJid, botNum) {
    const data     = loadOnOff();
    const cleanJid = chatJid.split('@')[0];
    const localKey = `chat_${cleanJid}_${botNum}`;

    // Excepción local explícita: si el chat tiene activación manual (=== true),
    // tiene prioridad sobre el apagado global.
    if (data[localKey] === true) return true;

    // Apagado global del subbot
    if (data[`global_${botNum}`] === false) return false;

    // Apagado local en este chat
    if (data[localKey] === false) return false;

    return true;
}

/**
 * Verifica si el subbot responde en chats privados.
 * Default: true
 */
function isSubBotRespondsInPriv(botNum) {
    const data   = loadResponder();
    const config = data[String(botNum)];
    return !config || config.priv !== false;
}

/**
 * Verifica si el subbot responde en grupos.
 * Default: true
 */
function isSubBotRespondsInGrupos(botNum) {
    const data   = loadResponder();
    const config = data[String(botNum)];
    return !config || config.grupos !== false;
}

/**
 * Verifica si el subbot tiene permitido el contenido NSFW.
 * Default: true
 */
function isSubBotNsfwEnabled(botNum) {
    if (!botNum) return true;
    const data   = loadResponder();
    const config = data[String(botNum)];
    return !config || config.nsfw !== false;
}

// ── Helper: verificar owner del subbot o owner principal ────────────────────
function isBotOwner(message, sock) {
    if (message.key?.fromMe) return true;
    const senderNum = (message.sender || '').split('@')[0].split(':')[0];
    const ownerNum  = (sock?._ownerJid || '').split('@')[0].split(':')[0];
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return senderNum && ownerNum && senderNum === ownerNum;
}

// ── Helper: verificar si es el owner principal del config.js ────────────────
function isMainOwner(message) {
    const senderNum = (message.sender || message.author || '').split('@')[0].split(':')[0];
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return false;
}


// ── Handler principal: .bot ──────────────────────────────────────────────────
const botHandler = async (message, { conn } = {}) => {
    try {
        const sock    = message._sock || conn;
        const chatId  = message.from || message.key?.remoteJid;
        const rawBody = message.body || '';
        const allArgs = rawBody.split(/\s+/).slice(1);

        // ── Detección silenciosa de ID específico (solo owner principal) ──────
        // Si el último arg es un número >= 4 dígitos y quien escribe es owner
        // de config.js, opera sobre ese subbot sin avisar a nadie.
        let targetBotNum = sock?._subNum;
        let args = [...allArgs];

        if (isMainOwner(message) && args.length >= 2) {
            const lastArg = args[args.length - 1];
            if (/^\d{4,}$/.test(lastArg)) {
                targetBotNum = parseInt(lastArg, 10);
                args = args.slice(0, -1); // quitar el ID
            }
        }

        const botNum = targetBotNum;

        // Solo subbots (o target elegido por owner) pueden usar este comando
        if (!botNum) {
            return await message.reply(
                'ℹ️ Este comando es exclusivo de cada sub-bot.\n' +
                'Envíalo directamente al sub-bot que querés controlar.'
            );
        }

        // Solo el dueño del subbot o el owner principal pueden usarlo
        if (!isBotOwner(message, sock) && !isMainOwner(message)) return;

        const sub1 = (args[0] || '').toLowerCase();
        const sub2 = (args[1] || '').toLowerCase();

        // ── Sin argumentos → mostrar estado ──────────────────────────────────
        if (!sub1) {
            const onoffData = loadOnOff();
            const respData  = loadResponder();
            const cleanJid  = chatId?.split('@')[0] || '';
            const globalOff    = onoffData[`global_${botNum}`] === false;
            const localVal     = onoffData[`chat_${cleanJid}_${botNum}`];
            const localOff     = localVal === false;
            const localExcept  = localVal === true;   // excepción activa (on mientras global off)
            const resp         = respData[String(botNum)] || {};
            const privOk       = resp.priv !== false;
            const grupoOk      = resp.grupos !== false;
            const nsfwOk       = resp.nsfw !== false;

            // Estado efectivo real en este chat
            const effectiveOn  = localExcept || (!globalOff && !localOff);

            let txt  = `🤖 *Estado del Sub-Bot #${botNum}*\n\n`;
            txt += `🌐 *Global:*     ${globalOff ? '❌ Apagado' : '✅ Encendido'}\n`;
            if (localExcept) {
                txt += `💬 *Este chat:*  ✅ Encendido _(excepción al global apagado)_\n`;
            } else {
                txt += `💬 *Este chat:*  ${localOff ? '❌ Apagado manualmente' : '✅ Normal'}\n`;
            }
            txt += `⚡ *Efectivo:*    ${effectiveOn ? '✅ Responde aquí' : '❌ No responde aquí'}\n`;
            txt += `📱 *Privados:*   ${privOk    ? '✅ Responde'   : '❌ No responde'}\n`;
            txt += `👥 *Grupos:*     ${grupoOk   ? '✅ Responde'   : '❌ No responde'}\n`;
            txt += `🔞 *NSFW:*       ${nsfwOk    ? '✅ Permitido'  : '❌ Desactivado'}\n\n`;
            txt += `💡 *Comandos disponibles:*\n`;
            txt += `  • *.bot apagar* → solo este chat\n`;
            txt += `  • *.bot apagar global* → todos los chats\n`;
            txt += `  • *.bot encender* → solo este chat\n`;
            txt += `  • *.bot encender global* → todos los chats\n`;
            txt += `  • *.bot priv on/off* → responder en privados\n`;
            txt += `  • *.bot grupo on/off* → responder en grupos\n`;
            txt += `  • *.bot nsfw on/off* → permitir/desactivar NSFW`;
            return await message.reply(txt);
        }

        // ── .bot priv / privado / private ────────────────────────────────────
        if (['priv', 'privado', 'private'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot priv on* o *.bot priv off*');
            }

            const data = loadResponder();
            if (!data[String(botNum)]) data[String(botNum)] = { priv: true, grupos: true };
            data[String(botNum)].priv = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *Sub-Bot #${botNum}*\n\n`;
                msg += `El sub-bot ${verb} en chats privados.\n\n`;
                msg += `💡 Para revertir: *.bot priv ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot grupo / grupos / group / groups ──────────────────────────────
        if (['grupo', 'grupos', 'group', 'groups'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot grupo on* o *.bot grupo off*');
            }

            const data = loadResponder();
            if (!data[String(botNum)]) data[String(botNum)] = { priv: true, grupos: true };
            data[String(botNum)].grupos = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *Sub-Bot #${botNum}*\n\n`;
                msg += `El sub-bot ${verb} en grupos.\n\n`;
                msg += `💡 Para revertir: *.bot grupo ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot nsfw / adulto / adultos ─────────────────────────────────────
        if (['nsfw', 'adulto', 'adultos'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar', 'enable'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar', 'disable'].includes(sub2);

            if (!enable && !disable) {
                const data = loadResponder();
                const isNsfwOn = !data[String(botNum)] || data[String(botNum)].nsfw !== false;
                return await message.reply(
                    `🔞 *Sub-Bot #${botNum} - Contenido NSFW*\n\n` +
                    `Estado actual: ${isNsfwOn ? '✅ Permitido' : '❌ Desactivado'}\n\n` +
                    `💡 Uso: *.bot nsfw on* o *.bot nsfw off*`
                );
            }

            const data = loadResponder();
            if (!data[String(botNum)]) data[String(botNum)] = { priv: true, grupos: true, nsfw: true };
            data[String(botNum)].nsfw = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const statusText = enable ? 'permitido' : 'desactivado (bloqueado)';
                let msg = `${icon} *Sub-Bot #${botNum}*\n\n`;
                msg += `El contenido NSFW ahora está *${statusText}* en este sub-bot.\n\n`;
                if (!enable) {
                    msg += `ℹ️ _Aunque un administrador active NSFW en un grupo (.nsfw on), este sub-bot no enviará contenido NSFW._\n\n`;
                }
                msg += `💡 Para cambiar: *.bot nsfw ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot on / off / encender / apagar [global / g] ───────────────────
        const isOn  = ['on', 'encender', 'activar'].includes(sub1);
        const isOff = ['off', 'apagar', 'desactivar'].includes(sub1);

        if (!isOn && !isOff) {
            return await message.reply(
                '⚠️ *Uso del comando .bot:*\n\n' +
                '  *.bot apagar* — solo este chat\n' +
                '  *.bot apagar global* — todos los chats\n' +
                '  *.bot encender* — solo este chat\n' +
                '  *.bot encender global* — todos los chats\n' +
                '  *.bot priv on/off* — responder en privados\n' +
                '  *.bot grupo on/off* — responder en grupos\n' +
                '  *.bot nsfw on/off* — permitir/desactivar NSFW'
            );
        }

        const isGlobal = ['global', 'g'].includes(sub2);
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();

        if (isGlobal) {
            // ── Acción global ─────────────────────────────────────────────────
            if (isOn) {
                delete data[`global_${botNum}`];
                // Al encender globalmente, limpiar también las excepciones locales
                // activas (=== true) ya que ya no son necesarias.
                // Los chats apagados manualmente (=== false) se conservan.
                for (const k of Object.keys(data)) {
                    if (data[k] === true && k.startsWith('chat_') && k.endsWith(`_${botNum}`)) {
                        delete data[k];
                    }
                }
            } else {
                data[`global_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    msg  = `✅ *Sub-Bot #${botNum} encendido globalmente*\n\n`;
                    msg += `El sub-bot responde en todos los chats nuevamente.\n\n`;
                    msg += `ℹ️ _Los chats que desactivaste manualmente siguen apagados._\n`;
                    msg += `💡 Para reactivarlos, enviá *.bot encender* en cada uno.`;
                } else {
                    msg  = `❌ *Sub-Bot #${botNum} apagado globalmente*\n\n`;
                    msg += `El sub-bot dejó de responder en todos los chats.\n\n`;
                    msg += `💡 Para encenderlo solo aquí: *.bot encender*\n`;
                    msg += `💡 Para encender en todos lados: *.bot encender global*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }

        } else {
            // ── Acción local (solo este chat) ─────────────────────────────────
            const globalOff = data[`global_${botNum}`] === false;

            if (isOn) {
                if (globalOff) {
                    // El global está apagado: guardar excepción local activa (true)
                    // para que este chat sea la única excepción.
                    data[`chat_${cleanJid}_${botNum}`] = true;
                } else {
                    // El global está encendido: simplemente quitar la entrada local.
                    delete data[`chat_${cleanJid}_${botNum}`];
                }
            } else {
                data[`chat_${cleanJid}_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    if (globalOff) {
                        msg  = `✅ *Sub-Bot #${botNum} encendido en este chat*\n\n`;
                        msg += `⚠️ _El bot está apagado globalmente, pero responderá como excepción en este chat._\n\n`;
                        msg += `💡 Para encender en todos lados: *.bot encender global*`;
                    } else {
                        msg  = `✅ *Sub-Bot #${botNum} encendido en este chat*\n\n`;
                        msg += `El sub-bot vuelve a responder aquí.\n\n`;
                        msg += `💡 Para apagar en todos lados: *.bot apagar global*`;
                    }
                } else {
                    msg  = `❌ *Sub-Bot #${botNum} apagado en este chat*\n\n`;
                    msg += `Este chat quedó desactivado únicamente.\n`;
                    msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
                    msg += `💡 Para volver a activarlo aquí: *.bot encender*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        }

    } catch (error) {
        console.error('[subbots-onoff] Error en .bot:', error.message);
    }
};

botHandler.help    = ['bot'];
botHandler.tags    = ['subbots'];
botHandler.command = /^bot$/i;

// ── Alias: .onmybot (compatibilidad veteranos) ───────────────────────────────
const onmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = sock?._subNum;
        if (!botNum) return;
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();
        delete data[`chat_${cleanJid}_${botNum}`];

        if (saveOnOff(data)) {
            let msg  = `✅ *Sub-Bot #${botNum} encendido en este chat*\n\n`;
            msg += `💡 Para apagar aquí: *.bot apagar* o *.offmybot*\n`;
            msg += `💡 Para apagar globalmente: *.bot apagar global*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en onmybot:', e.message);
    }
};
onmybotHandler.help    = ['onmybot'];
onmybotHandler.tags    = ['subbots'];
onmybotHandler.command = /^onmybot$/i;

// ── Alias: .offmybot (compatibilidad veteranos) ──────────────────────────────
const offmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = sock?._subNum;
        if (!botNum) return;
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const cleanJid = chatId?.split('@')[0] || '';
        const data     = loadOnOff();
        data[`chat_${cleanJid}_${botNum}`] = false;

        if (saveOnOff(data)) {
            let msg  = `❌ *Sub-Bot #${botNum} apagado en este chat*\n\n`;
            msg += `Este chat quedó desactivado únicamente.\n`;
            msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
            msg += `💡 Para volver a activarlo: *.bot encender* o *.onmybot*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en offmybot:', e.message);
    }
};
offmybotHandler.help    = ['offmybot'];
offmybotHandler.tags    = ['subbots'];
offmybotHandler.command = /^offmybot$/i;

// ── Limpieza al eliminar un subbot ───────────────────────────────────────────

/**
 * Elimina todas las entradas de configuración de un subbot dado su número.
 * Debe llamarse cuando la sesión del subbot es borrada definitivamente.
 * Limpia: subbot-onoff.json (global_N y chat_*_N) y subbot-responder.json (N).
 */
function cleanupSubBot(botNum) {
    const key = String(botNum);

    // ── subbot-onoff.json ─────────────────────────────────────────────────────
    try {
        const onoff = loadOnOff();
        let changed = false;
        for (const k of Object.keys(onoff)) {
            // global_<num>  o  chat_<jid>_<num>
            if (k === `global_${key}` || k.endsWith(`_${key}`)) {
                delete onoff[k];
                changed = true;
            }
        }
        if (changed) {
            saveOnOff(onoff);
            console.log(`[subbots-onoff] 🗑️ Configuración on/off eliminada para subbot #${botNum}`);
        }
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando onoff de #${botNum}:`, e.message);
    }

    // ── subbot-responder.json ─────────────────────────────────────────────────
    try {
        const resp = loadResponder();
        if (resp[key] !== undefined) {
            delete resp[key];
            saveResponder(resp);
            console.log(`[subbots-onoff] 🗑️ Configuración responder eliminada para subbot #${botNum}`);
        }
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando responder de #${botNum}:`, e.message);
    }
}

// ── Exports ──────────────────────────────────────────────────────────────────
module.exports                      = botHandler;
module.exports.onmybotAlias         = onmybotHandler;   // cargado por el plugin loader
module.exports.offmybotAlias        = offmybotHandler;  // cargado por el plugin loader
module.exports.isSubBotEnabled      = isSubBotEnabled;
module.exports.isSubBotRespondsInPriv   = isSubBotRespondsInPriv;
module.exports.isSubBotRespondsInGrupos = isSubBotRespondsInGrupos;
module.exports.isSubBotNsfwEnabled  = isSubBotNsfwEnabled;
module.exports.cleanupSubBot        = cleanupSubBot;
