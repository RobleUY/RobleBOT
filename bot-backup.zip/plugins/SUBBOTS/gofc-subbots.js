'use strict';

const fs   = require('fs');
const path = require('path');

// ── Directorio y archivo de datos ────────────────────────────────────────────
const DATA_DIR  = path.join(__dirname, 'data');
const GOFC_FILE = path.join(DATA_DIR, 'gofc-subbots.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Caché en memoria ─────────────────────────────────────────────────────────
let _cache = null, _cacheMtime = 0;

function loadGofcData() {
    try {
        if (fs.existsSync(GOFC_FILE)) {
            const mtime = fs.statSync(GOFC_FILE).mtimeMs;
            if (_cache !== null && mtime === _cacheMtime) return _cache;
            _cache = JSON.parse(fs.readFileSync(GOFC_FILE, 'utf8'));
            _cacheMtime = mtime;
            return _cache;
        }
    } catch (e) {
        console.error('[gofc-subbots] Error cargando datos:', e.message);
    }
    _cache = { enabled: false, assignedSubbot: null };
    return _cache;
}

function saveGofcData(data) {
    try {
        fs.writeFileSync(GOFC_FILE, JSON.stringify(data, null, 2), 'utf8');
        _cache = data;
        _cacheMtime = fs.statSync(GOFC_FILE).mtimeMs;
        return true;
    } catch (e) {
        console.error('[gofc-subbots] Error guardando datos:', e.message);
        return false;
    }
}

// ── API pública ───────────────────────────────────────────────────────────────

/**
 * ¿Está activo el modo subbot en el grupo oficial?
 */
function isGofcEnabled() {
    return loadGofcData().enabled === true;
}

/**
 * Devuelve el número del subbot asignado al grupo oficial, o null si no hay ninguno.
 */
function getAssignedSubbot() {
    return loadGofcData().assignedSubbot || null;
}

/**
 * Asigna un nuevo subbot al grupo oficial y lo guarda.
 */
function assignSubbot(subNum) {
    const data = loadGofcData();
    data.assignedSubbot = subNum;
    saveGofcData(data);
}

/**
 * Elige un subbot funcional de entre los conectados.
 * Prefiere el que tenga actividad más reciente según subbotActivityTracker.
 * Devuelve el _subNum del subbot elegido, o null si no hay ninguno disponible.
 */
function pickActiveSubbot() {
    const subs = (global.subConns || []).filter(c => c?.user && c._subNum != null);
    if (subs.length === 0) return null;

    try {
        const activityTracker = require('./subbotActivityTracker');
        const nums = subs.map(c => c._subNum);
        const sorted = activityTracker.getSortedByActivity([...nums]);
        // El primero de la lista ordenada por actividad más reciente
        return sorted[0] ?? nums[0];
    } catch (e) {
        // Si falla el tracker, devolver simplemente el primero disponible
        return subs[0]._subNum;
    }
}

/**
 * Verifica si el subbot asignado actualmente sigue conectado y funcional.
 */
function isAssignedSubbotAlive(subNum) {
    if (!subNum) return false;
    return (global.subConns || []).some(c => c?.user && c._subNum === subNum);
}

module.exports.isGofcEnabled       = isGofcEnabled;
module.exports.getAssignedSubbot   = getAssignedSubbot;
module.exports.assignSubbot        = assignSubbot;
module.exports.pickActiveSubbot    = pickActiveSubbot;
module.exports.isAssignedSubbotAlive = isAssignedSubbotAlive;

// ── Handler del comando ───────────────────────────────────────────────────────

const OFFICIAL_GROUP = '120363203689229697@g.us';

const gofcHandler = async (message) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        const sock   = message._sock || global.conn;

        // Solo funciona en el grupo oficial
        if (chatId !== OFFICIAL_GROUP) {
            return await message.reply('❌ Este comando solo puede usarse en el *grupo oficial*.');
        }

        // Solo owners del config.js pueden usarlo
        const botConfig = global.botConfig || require('../../config');
        const senderRaw = message.author || message.sender || '';
        const senderNum = senderRaw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        const isOwner   = (botConfig && typeof botConfig.isOwner === 'function')
            ? (botConfig.isOwner(senderNum) || botConfig.isOwner(`${senderNum}@s.whatsapp.net`))
            : false;

        if (!isOwner) {
            return await message.reply('❌ Este comando es solo para *owners* del bot.');
        }

        // Parsear argumentos: .gofc subbots on / off
        const body = (message.body || message.text || '').trim();
        // Soporta: .gofc subbots on | .gofc subbots off
        const parts = body.split(/\s+/).slice(1); // quitar el .gofc
        const sub1  = (parts[0] || '').toLowerCase();
        const sub2  = (parts[1] || '').toLowerCase();

        // Validar que sea ".gofc subbots on/off"
        if (sub1 !== 'subbots') {
            const data = loadGofcData();
            const estado = data.enabled ? `✅ *Activo* (subbot asignado: #${data.assignedSubbot ?? 'ninguno'})` : '❌ *Inactivo*';
            let txt  = `🤖 *Subbots en grupo oficial*\n\n`;
            txt += `📊 *Estado:* ${estado}\n\n`;
            txt += `💡 *Comandos:*\n`;
            txt += `  • *.gofc subbots on* — permite que un subbot responda aquí\n`;
            txt += `  • *.gofc subbots off* — subbots dejan de responder aquí`;
            return await message.reply(txt);
        }

        const isOn  = ['on', 'activar', 'encender'].includes(sub2);
        const isOff = ['off', 'desactivar', 'apagar'].includes(sub2);

        if (!isOn && !isOff) {
            return await message.reply('⚠️ Uso: *.gofc subbots on* o *.gofc subbots off*');
        }

        const data = loadGofcData();

        if (isOn) {
            // Elegir un subbot activo
            const chosen = pickActiveSubbot();
            if (!chosen) {
                return await message.reply(
                    '⚠️ No hay subbots conectados en este momento.\n' +
                    'Conecta al menos un subbot e intenta de nuevo.'
                );
            }
            data.enabled       = true;
            data.assignedSubbot = chosen;

            if (saveGofcData(data)) {
                const subSock = (global.subConns || []).find(c => c._subNum === chosen);
                const phoneNum = subSock?.user?.id?.split('@')[0]?.split(':')[0] || '?';
                let msg  = `✅ *Subbots en grupo oficial: ACTIVADO*\n\n`;
                msg += `📱 *Subbot asignado:* #${chosen} (+${phoneNum})\n\n`;
                msg += `ℹ️ Solo este subbot responderá aquí (junto al bot principal).\n`;
                msg += `Si se desconecta, se asignará otro automáticamente.\n\n`;
                msg += `💡 Para desactivar: *.gofc subbots off*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }

        } else {
            // OFF
            data.enabled        = false;
            data.assignedSubbot = null;

            if (saveGofcData(data)) {
                let msg  = `❌ *Subbots en grupo oficial: DESACTIVADO*\n\n`;
                msg += `Los subbots ya no responderán en este grupo.\n\n`;
                msg += `💡 Para reactivar: *.gofc subbots on*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        }

    } catch (error) {
        console.error('[gofc-subbots] Error en comando .gofc:', error.message);
        await message.reply('❌ Error inesperado al procesar el comando.').catch(() => {});
    }
};

gofcHandler.help    = ['gofc'];
gofcHandler.tags    = ['owner', 'subbots'];
gofcHandler.command = /^gofc$/i;
gofcHandler.owner   = false; // La verificación de owner se hace manualmente (config.js owners)
gofcHandler.group   = true;

module.exports        = gofcHandler;
module.exports.isGofcEnabled       = isGofcEnabled;
module.exports.getAssignedSubbot   = getAssignedSubbot;
module.exports.assignSubbot        = assignSubbot;
module.exports.pickActiveSubbot    = pickActiveSubbot;
module.exports.isAssignedSubbotAlive = isAssignedSubbotAlive;
