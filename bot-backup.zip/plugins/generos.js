const db = require('../database.js'); // Ajusta la ruta según tu estructura

let handler = async (message, { text, args }) => {
    try {
        // Obtener el sender correctamente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const sender = senderJid.split('@')[0];
        const user = db.getUser(sender);
        
        if (!user) {
            return await message.reply('❌ Error al acceder a la base de datos.');
        }

        // Si no escribe nada → mostrar el género actual o instrucciones
        if (!text || text.trim() === '') {
            const actual = user.genero || 'No definido';
            return await message.reply(
`🚻 *Tu género actual:* ${actual}

💡 Para cambiarlo, usa uno de los siguientes comandos:
• \`.genero hombre\`
• \`.genero mujer\`

✨ Por defecto: No definido`
            );
        }

        // Normalizar entrada
        const generoInput = text.trim().toLowerCase();

        // Validar opciones
        if (!['hombre', 'mujer'].includes(generoInput)) {
            return await message.reply(
`❌ Opción no válida.

🧭 Usa uno de los siguientes valores:
• \`.genero hombre\`
• \`.genero mujer\``
            );
        }

        // Actualizar base de datos
        user.genero = generoInput.charAt(0).toUpperCase() + generoInput.slice(1); // capitalizar
        const success = db.setUser(sender, user);

        if (!success) {
            console.error('Error al guardar el género');
            return await message.reply('❌ Error al guardar el género en la base de datos.');
        }

        // Mensajes decorados
        const respuestas = [
            `🚹 *¡Perfecto!* Tu género fue actualizado a *${user.genero}*.`,
            `🚺 *Hecho!* A partir de ahora tu género es *${user.genero}*.`,
            `✨ *Actualización guardada!* Género: *${user.genero}*.`,
            `✅ *Listo!* Tu perfil ahora dice: *${user.genero}*.`
        ];

        const respuestaAleatoria = respuestas[Math.floor(Math.random() * respuestas.length)];

        return await message.reply(respuestaAleatoria);

    } catch (error) {
        console.error('Error en comando genero:', error);
        return await message.reply('❌ Ocurrió un error al procesar tu género. ¡Inténtalo de nuevo!');
    }
};

handler.help = ['genero [hombre/mujer]'];
handler.tags = ['info', 'perfil'];
handler.command = /^(genero|género)$/i;

module.exports = handler;
handler.group = true
