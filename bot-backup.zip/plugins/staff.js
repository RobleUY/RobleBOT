/**
 * staff.js
 * Comando .staff / .staff on / .staff off
 */

const fs = require('fs');
const path = require('path');
const botConfig = require('../config');

const STAFF_FILE = path.join(__dirname, '../data/staff-roblebot.json');

function loadStaffData() {
    try {
        if (fs.existsSync(STAFF_FILE)) {
            return JSON.parse(fs.readFileSync(STAFF_FILE, 'utf8'));
        }
    } catch (_) {}
    return {};
}

function saveStaffData(data) {
    try {
        const dir = path.dirname(STAFF_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(STAFF_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[Staff] Error guardando staff-roblebot.json:', e.message);
    }
}

function isStaffTagEnabled(number) {
    const clean = (number || '').toString().split('@')[0].split(':')[0].replace(/\D/g, '');
    if (!clean) return false;
    const isStaff = botConfig.adminsbot.some(n => n.replace(/\D/g, '') === clean);
    if (!isStaff) return false;
    const data = loadStaffData();
    return data[clean] !== false;
}

// 1. Usar un String con el nombre del comando base en lugar de RegExp
const command = 'staff'; 
const help = ['staff', 'staff on', 'staff off'];
const tags = ['owner'];

async function handler(message, { args }) {
    const rawSender = message.sender || message.author || message.from || '';
    const clean = rawSender.toString().split('@')[0].split(':')[0].replace(/\D/g, '');

    // Solo staff puede usar este comando
    const isStaff = botConfig.adminsbot.some(n => n.replace(/\D/g, '') === clean);
    if (!isStaff) {
        return await message.reply('❌ Este comando es solo para el *Staff de RobleBOT*.');
    }

    const action = (args[0] || '').toLowerCase();

    if (action !== 'on' && action !== 'off') {
        const data = loadStaffData();
        const currentState = data[clean] !== false;
        return await message.reply(
            `🛡️ *Modo Staff*\n\n` +
            `Estado actual: ${currentState ? '✅ Activado' : '❌ Desactivado'}\n\n` +
            `• *.staff on*  — Activar etiqueta _[RobleBOT Staff]_\n` +
            `• *.staff off* — Desactivar etiqueta _[RobleBOT Staff]_`
        );
    }

    const data = loadStaffData();
    const enable = action === 'on';
    data[clean] = enable;
    saveStaffData(data);

    if (enable) {
        return await message.reply(
            `✅ *Etiqueta Staff activada*\n\n` +
            `Tus mensajes mostrarán _[RobleBOT Staff]_ nuevamente.`
        );
    } else {
        return await message.reply(
            `🔕 *Etiqueta Staff desactivada*\n\n` +
            `Tus mensajes ya *no* mostrarán _[RobleBOT Staff]_.`
        );
    }
}

// Exportamos la función auxiliar para que handler.js la pueda requerir si es necesario
module.exports = {
    command,
    help,
    tags,
    handler,
    isStaffTagEnabled
};