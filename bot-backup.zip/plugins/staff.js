/**
 * staff.js
 *
 * Comando .staff on/off
 * Permite a los miembros del Staff de RobleBOT activar o desactivar
 * la etiqueta [RobleBOT Staff] en sus respuestas.
 *
 * - Solo pueden usarlo quienes estan en config.adminsbot
 * - La preferencia se guarda en data/staff-roblebot.json
 * - Por defecto la etiqueta viene ACTIVADA para todos
 */

const fs   = require('fs');
const path = require('path');
const botConfig = require('../config');

const STAFF_FILE = path.join(__dirname, '../data/staff-roblebot.json');

// -- Helpers --

function loadStaffData() {
    try {
        if (fs.existsSync(STAFF_FILE)) {
            return JSON.parse(fs.readFileSync(STAFF_FILE, 'utf8'));
        }
    } catch (_) {}
    return {};
}

function saveStaffData(data) {
    try {
        const dir = path.dirname(STAFF_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(STAFF_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[Staff] Error guardando staff-roblebot.json:', e.message);
    }
}

// -- API publica --

/**
 * Devuelve true si la etiqueta [RobleBOT Staff] esta ACTIVADA para ese numero.
 * Por defecto devuelve true (activo), salvo que el usuario la haya desactivado explicitamente.
 * @param {string} number - numero limpio (sin @s.whatsapp.net / @lid)
 */
function isStaffTagEnabled(number) {
    const clean = (number || '').toString().split('@')[0].split(':')[0].replace(/\D/g, '');
    if (!clean) return false;

    const isStaff = botConfig.adminsbot.some(n => n.replace(/\D/g, '') === clean);
    if (!isStaff) return false;

    const data = loadStaffData();
    // Por defecto activo si no hay entrada explicita
    return data[clean] !== false;
}

async function handler(message) {
    // Obtener numero del remitente (funciona en grupos y privados)
    const rawSender = message.author || message.sender || message.from || '';
    const clean = rawSender.toString().split('@')[0].split(':')[0].replace(/\D/g, '');

    // Solo staff puede usar este comando
    const isStaff = botConfig.adminsbot.some(n => n.replace(/\D/g, '') === clean);
    if (!isStaff) {
        return await message.reply('❌ Este comando es solo para el *Staff de RobleBOT*.');
    }

    const args = (message.body || '').trim().split(/\s+/);
    const action = (args[1] || '').toLowerCase();

    if (action !== 'on' && action !== 'off') {
        const data = loadStaffData();
        const currentState = data[clean] !== false;
        return await message.reply(
            `🛡️ *Modo Staff*\n\nEstado actual: ${currentState ? '✅ Activado' : '❌ Desactivado'}\n\n• *.staff on*  — Activar etiqueta _[RobleBOT Staff]_\n• *.staff off* — Desactivar etiqueta _[RobleBOT Staff]_`
        );
    }

    const data = loadStaffData();
    const enable = action === 'on';
    data[clean] = enable;
    saveStaffData(data);

    if (enable) {
        return await message.reply(`✅ *Etiqueta Staff activada*\n\nTus mensajes mostrarán _[RobleBOT Staff]_ nuevamente.`);
    } else {
        return await message.reply(`🔕 *Etiqueta Staff desactivada*\n\nTus mensajes ya *no* mostrarán _[RobleBOT Staff]_.`);
    }
}

handler.command  = '.staff';
handler.help     = ['staff on', 'staff off'];
handler.tags     = ['owner'];
handler.description = 'Activa o desactiva la etiqueta [RobleBOT Staff] en tus mensajes.';

module.exports = {
    isStaffTagEnabled,
    command:  handler.command,
    help:     handler.help,
    tags:     handler.tags,
    handler
};
