/**
 * Comandos: conocer, noconocer
 * Descripción: Sistema para conocer personas que usan el bot
 * Uso: 
 *   .conocer [descripción] - Publicar tu número
 *   .conocer - Ver lista de personas
 *   .noconocer - Eliminar tu número de la lista
 */

const fs = require('fs');
const path = require('path');
const { parsePhoneNumberFromString } = require('libphonenumber-js');

// Ruta del archivo JSON (misma ubicación que este archivo .js)
const DATA_FILE = path.join(__dirname, 'conocer-gente.json');

// --- Funciones auxiliares para manejar el JSON ---
function cargarDatos() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (error) {
        console.error('Error al cargar datos:', error);
        return {};
    }
}

function guardarDatos(datos) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(datos, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error al guardar datos:', error);
        return false;
    }
}

function obtenerPais(numero) {
    try {
        const phoneNumber = parsePhoneNumberFromString('+' + numero);
        
        if (!phoneNumber || !phoneNumber.isValid()) {
            return 'Desconocido';
        }
        
        if (phoneNumber.country) {
            // Usar Intl.DisplayNames para obtener el nombre del país en español
            const countryName = new Intl.DisplayNames(['es'], { type: 'region' }).of(phoneNumber.country);
            return countryName || phoneNumber.country;
        }
        
        return 'Desconocido';
    } catch (error) {
        console.error('Error al obtener país:', error);
        return 'Desconocido';
    }
}

// Función para mezclar array aleatoriamente (algoritmo Fisher-Yates)
function mezclarArray(array) {
    const resultado = [...array]; // Crear copia para no modificar el original
    for (let i = resultado.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [resultado[i], resultado[j]] = [resultado[j], resultado[i]];
    }
    return resultado;
}

let handler = async (message, { conn, text, command }) => {
    try {
        const chat = message.key.remoteJid;
        const isPrivateChat = !chat.includes('-') && !chat.includes('@g.us');
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener tu información de usuario.');
        }
        
        let senderNumber = senderJid.split('@')[0];
        
        // Si es un grupo, intentar obtener el número real
        if (message.isGroup) {
            try {
                const groupMeta = await conn.groupMetadata(chat);
                const participant = groupMeta.participants.find(p => p.id === senderJid);
                if (participant?.jid) {
                    senderNumber = participant.jid.split('@')[0];
                }
            } catch {}
        }
        
        // Limpiar el número de caracteres no numéricos
        senderNumber = senderNumber.split(':')[0].replace(/[^0-9]/g, '');

        // ==================== COMANDO: CONOCER ====================
        if (command === 'conocer') {
            
            // --- SI HAY TEXTO: PUBLICAR PERFIL ---
            if (text && text.trim() !== '') {
                // Verificar que sea chat privado
                if (!isPrivateChat) {
                    return await message.reply(
                        `❌ Para publicar tu perfil debes usar este comando en el chat privado del bot.`
                    );
                }

                const descripcion = text.trim();
                
                // Verificar longitud de la descripción
                if (descripcion.length > 70) {
                    return await message.reply(
                        `❌ La descripción es demasiado larga.\n\n` +
                        `📝 Actual: ${descripcion.length} caracteres\n` +
                        `📝 Máximo: 70 caracteres\n\n` +
                        `Por favor, acórtala un poco.`
                    );
                }

                // Obtener país del usuario
                const pais = obtenerPais(senderNumber);

                // Cargar datos actuales
                const datos = cargarDatos();

                // Agregar o actualizar usuario
                datos[senderNumber] = {
                    numero: senderNumber,
                    pais: pais,
                    descripcion: descripcion,
                    fecha: new Date().toISOString()
                };

                // Guardar datos
                if (guardarDatos(datos)) {
                    await message.reply(
                        `✅ *¡Tu perfil ha sido publicado!*\n\n` +
                        `👤 *Número:* +${senderNumber}\n` +
                        `🌎 *País:* ${pais}\n` +
                        `📝 *Descripción:* ${descripcion}\n\n` +
                        `💡 Otros usuarios podrán verte con el comando */conocer*\n\n` +
                        `🔴 Para eliminar tu perfil usa:\n*/noconocer*\n\n` +
                        `🔴 Es posible que tu numero no se haya guardado correctamente,\nDe ser asi usa de nuevo el comando para publicar tu perfil.`
                    );
                } else {
                    await message.reply('❌ Error al guardar tu perfil. Intenta nuevamente.');
                }
            } 
            // --- SI NO HAY TEXTO: MOSTRAR LISTA ---
            else {
                const datos = cargarDatos();
                let usuarios = Object.values(datos);

                if (usuarios.length === 0) {
                    return await message.reply(
                        `📭 *No hay personas disponibles*\n\n` +
                        `Sé el primero en publicar tu perfil con:\n` +
                        `*/conocer [descripción]*\n\n` +
                        `Ejemplo: /conocer Hola, quiero hacer amigos`
                    );
                }

                // *** MEZCLAR USUARIOS ALEATORIAMENTE ***
                usuarios = mezclarArray(usuarios);

                // Construir lista de usuarios
                let mensajeUsuarios = `👥 *PERSONAS QUE QUIEREN CONOCER GENTE*\n`;
                mensajeUsuarios += `━━━━━━━━━━━━━━━\n\n`;
                mensajeUsuarios += `📱 Total de personas: ${usuarios.length}\n\n`;

                usuarios.forEach((usuario) => {
                    mensajeUsuarios += `👤 *wa.me/+${usuario.numero}*\n`;
                    mensajeUsuarios += `   🌎 País: ${usuario.pais}\n`;
                    mensajeUsuarios += `   📝 ${usuario.descripcion}\n\n`;
                });

                mensajeUsuarios += `━━━━━━━━━━━━━━━\n`;
                mensajeUsuarios += `💡 *Tip:* Pulsá el número y escríbele por WhatsApp\n\n`;
                mensajeUsuarios += `¿Quieres aparecer aquí? Usa:\n`;
                mensajeUsuarios += `*/conocer [descripción]*`;

                await message.reply(mensajeUsuarios);
            }
        }

        // ==================== COMANDO: NOCONOCER ====================
        else if (command === 'noconocer') {
            // Verificar que sea chat privado
            if (!isPrivateChat) {
                return await message.reply(
                    `❌ Este comando solo se puede usar en el chat privado del bot.`
                );
            }

            // Cargar datos actuales
            const datos = cargarDatos();

            // Verificar si el usuario está en la lista
            if (!datos[senderNumber]) {
                return await message.reply(
                    `❌ No estás en la lista de personas.\n\n` +
                    `💡 Para aparecer usa: */conocer [descripción]*`
                );
            }

            // Eliminar usuario
            delete datos[senderNumber];

            // Guardar datos
            if (guardarDatos(datos)) {
                await message.reply(
                    `✅ *Tu perfil ha sido eliminado*\n\n` +
                    `🗑️ Ya no aparecerás en la lista de personas.\n\n` +
                    `💡 Si cambias de opinión, puedes volver a publicarte con:\n` +
                    `*/conocer [descripción]*`
                );
            } else {
                await message.reply('❌ Error al eliminar tu perfil. Intenta nuevamente.');
            }
        }

    } catch (error) {
        console.error(`Error en comando ${command}:`, error);
        await message.reply(`❌ Ocurrió un error inesperado. Intenta nuevamente.`);
    }
};

// --- Configuración del Handler ---
handler.help = ['conocer [descripción]', 'conocer', 'noconocer'];
handler.tags = ['social', 'community'];
handler.command = /^(conocer|noconocer)$/i;

module.exports = handler;