const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones en la raíz del proyecto
const DATA_DIR = path.join(__dirname, '..', 'data');
const TAG_FILE = path.join(DATA_DIR, 'tag-protection.json');

// Asegurar que el directorio y el archivo existen
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(TAG_FILE)) {
    fs.writeFileSync(TAG_FILE, JSON.stringify({ global: {}, groups: {} }, null, 2), 'utf8');
}

// Cachés en memoria para consultas ultrarrápidas (0ms de latencia, sin lectura de disco en cada mensaje)
const globalProtectedUsers = new Set(); // Set<userNum>
const groupProtectedUsers = new Map();  // Map<groupJid, Set<userNum>>

// Control de cooldown de avisos por grupo y emisor para evitar spam en chat
const recentWarns = new Map(); // key: `${chatId}:${senderNum}` -> timestamp
const processedMessages = new Set(); // IDs de mensajes procesados recientemente

function cleanNumber(jidOrNum) {
    if (!jidOrNum) return '';
    return String(jidOrNum).split('@')[0].split(':')[0].replace(/\D/g, '');
}

/**
 * Carga la configuración desde el archivo JSON y actualiza el caché en memoria
 */
function loadTagConfig() {
    try {
        if (fs.existsSync(TAG_FILE)) {
            const raw = fs.readFileSync(TAG_FILE, 'utf8');
            const data = JSON.parse(raw);
            return {
                global: data.global || {},
                groups: data.groups || {}
            };
        }
    } catch (error) {
        console.error('[TagProtection] Error cargando tag-protection.json:', error.message);
    }
    return { global: {}, groups: {} };
}

/**
 * Guarda la configuración en disco
 */
function saveTagConfig(config) {
    try {
        fs.writeFileSync(TAG_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('[TagProtection] Error guardando tag-protection.json:', error.message);
        return false;
    }
}

/**
 * Inicializa los Sets y Maps en memoria desde el archivo JSON
 */
function initMemoryCache() {
    globalProtectedUsers.clear();
    groupProtectedUsers.clear();

    const config = loadTagConfig();

    for (const [userNum, val] of Object.entries(config.global || {})) {
        if (val === true || val?.enabled === true) {
            globalProtectedUsers.add(cleanNumber(userNum));
        }
    }

    for (const [groupJid, usersMap] of Object.entries(config.groups || {})) {
        const cleanGroup = groupJid.trim();
        const set = new Set();
        for (const [userNum, val] of Object.entries(usersMap || {})) {
            if (val === true || val?.enabled === true) {
                set.add(cleanNumber(userNum));
            }
        }
        groupProtectedUsers.set(cleanGroup, set);
    }
}

// Cargar caché al importar el módulo
initMemoryCache();

/**
 * Comprueba si un usuario tiene las menciones desactivadas (globalmente o en el grupo dado)
 */
function isTagProtectionEnabled(userNum, groupJid = null) {
    const clean = cleanNumber(userNum);
    if (!clean) return false;

    // 1. Verificación global
    if (globalProtectedUsers.has(clean)) return true;

    // 2. Verificación por grupo
    if (groupJid) {
        const cleanGroup = groupJid.trim();
        const groupSet = groupProtectedUsers.get(cleanGroup);
        if (groupSet && groupSet.has(clean)) return true;
    }

    return false;
}

/**
 * Modifica la protección de menciones para un usuario (en un grupo o globalmente)
 */
function setTagProtection(userNum, enabled, groupJid = null, isGlobal = false) {
    const clean = cleanNumber(userNum);
    if (!clean) return false;

    const config = loadTagConfig();

    if (isGlobal || !groupJid) {
        // Ajuste global
        if (enabled) {
            config.global[clean] = { enabled: true, updatedAt: Date.now() };
            globalProtectedUsers.add(clean);
        } else {
            delete config.global[clean];
            globalProtectedUsers.delete(clean);
        }
    } else {
        // Ajuste por grupo
        const cleanGroup = groupJid.trim();
        if (!config.groups[cleanGroup]) {
            config.groups[cleanGroup] = {};
        }

        if (enabled) {
            config.groups[cleanGroup][clean] = { enabled: true, updatedAt: Date.now() };
            if (!groupProtectedUsers.has(cleanGroup)) {
                groupProtectedUsers.set(cleanGroup, new Set());
            }
            groupProtectedUsers.get(cleanGroup).add(clean);
        } else {
            delete config.groups[cleanGroup][clean];
            if (Object.keys(config.groups[cleanGroup]).length === 0) {
                delete config.groups[cleanGroup];
            }
            if (groupProtectedUsers.has(cleanGroup)) {
                groupProtectedUsers.get(cleanGroup).delete(clean);
            }
        }
    }

    saveTagConfig(config);
    return true;
}

/**
 * Extrae todos los números/JIDs mencionados en un mensaje de Baileys
 */
function extractMentionedNumbers(baileyMessage) {
    const mentionedNumbers = new Set();
    const msg = baileyMessage?.message;
    if (!msg) return mentionedNumbers;

    // 1. Buscar en contextInfo.mentionedJid de cualquier estructura de mensaje
    const checkContext = (obj) => {
        if (!obj || typeof obj !== 'object') return;
        if (Array.isArray(obj.mentionedJid)) {
            for (const jid of obj.mentionedJid) {
                const num = cleanNumber(jid);
                if (num) mentionedNumbers.add(num);
            }
        }
    };

    checkContext(msg.extendedTextMessage?.contextInfo);
    checkContext(msg.imageMessage?.contextInfo);
    checkContext(msg.videoMessage?.contextInfo);
    checkContext(msg.documentMessage?.contextInfo);
    checkContext(msg.audioMessage?.contextInfo);
    checkContext(msg.stickerMessage?.contextInfo);
    checkContext(msg.buttonsResponseMessage?.contextInfo);
    checkContext(msg.templateButtonReplyMessage?.contextInfo);
    checkContext(msg.listResponseMessage?.contextInfo);

    // Mensajes efímeros o viewOnce
    const innerMsg = msg.viewOnceMessage?.message || 
                     msg.viewOnceMessageV2?.message || 
                     msg.ephemeralMessage?.message;
    if (innerMsg) {
        for (const sub of Object.values(innerMsg)) {
            if (sub?.contextInfo) checkContext(sub.contextInfo);
        }
    }

    // 2. Extraer del texto cualquier patrón @123456789
    const text = msg.conversation || 
                 msg.extendedTextMessage?.text || 
                 msg.imageMessage?.caption || 
                 msg.videoMessage?.caption || 
                 msg.documentMessage?.caption || 
                 '';

    if (text && typeof text === 'string') {
        const matches = text.match(/@(\d{5,20})/g);
        if (matches) {
            for (const m of matches) {
                const num = cleanNumber(m);
                if (num) mentionedNumbers.add(num);
            }
        }
    }

    return mentionedNumbers;
}

/**
 * Verifica y maneja mensajes que mencionen usuarios protegidos.
 * Llamado desde index.js y subbot-serbot.js antes de procesar comandos.
 * Retorna true si detectó mención a un usuario protegido y actuó.
 */
async function checkAndDeleteTagMessage(baileyMessage, sock) {
    try {
        if (!sock || !baileyMessage?.key) return false;

        const chatId = baileyMessage.key.remoteJid;
        // Solo aplica en grupos y mensajes que no son del bot
        if (!chatId || !chatId.endsWith('@g.us') || baileyMessage.key.fromMe) {
            return false;
        }

        // Ignorar mensajes de protocolo (eliminaciones, etc.)
        if (baileyMessage.message?.protocolMessage) return false;

        const messageId = baileyMessage.key.id;
        if (messageId && processedMessages.has(messageId)) return false;

        // Identificar emisor
        const senderJid = baileyMessage.key.participant || baileyMessage.participant || chatId;
        const senderNum = cleanNumber(senderJid);
        if (!senderNum) return false;

        // Extraer menciones
        const mentioned = extractMentionedNumbers(baileyMessage);
        // Excluir auto-mención (el usuario mencionándose a sí mismo)
        mentioned.delete(senderNum);
        if (mentioned.size === 0) return false;

        // Verificar si alguno de los mencionados tiene protección activa en este grupo o global
        let hasProtectedMention = false;
        for (const num of mentioned) {
            if (isTagProtectionEnabled(num, chatId)) {
                hasProtectedMention = true;
                break;
            }
        }

        if (!hasProtectedMention) return false;

        // Marcar como procesado para evitar duplicados
        if (messageId) {
            processedMessages.add(messageId);
            setTimeout(() => processedMessages.delete(messageId), 15000);
        }

        // Obtener metadatos del grupo con caché seguro
        let groupMetadata = null;
        try {
            const { getGroupMetadataCached } = require('../lib/groupCache');
            groupMetadata = await getGroupMetadataCached(sock, chatId);
        } catch (_) {
            try {
                if (typeof sock.groupMetadata === 'function') {
                    groupMetadata = await sock.groupMetadata(chatId);
                }
            } catch (_) {}
        }

        const participants = groupMetadata?.participants || [];

        // ── Comprobar si el emisor es ADMIN o OWNER ──
        // "solo permite el @ de admins del grupo basicamente"
        const senderParticipant = participants.find(p => {
            const pNum = cleanNumber(p.id);
            return pNum === senderNum || p.id === senderJid;
        });

        const isSenderAdmin = senderParticipant && 
            (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

        let isOwner = false;
        try {
            const botConfig = require('../config');
            isOwner = botConfig.isOwner(senderNum) || botConfig.isOwner(`${senderNum}@s.whatsapp.net`);
        } catch (_) {}

        // Si el emisor es admin del grupo o el owner del bot, la mención está permitida
        if (isSenderAdmin || isOwner) {
            return false;
        }

        // ── El emisor NO es admin: procede la eliminación y el aviso ──

        // Intentar eliminar el mensaje (si el bot es admin lo eliminará con éxito)
        try {
            await sock.sendMessage(chatId, { delete: baileyMessage.key });
        } catch (delError) {
            try {
                const altKey = {
                    remoteJid: chatId,
                    id: messageId,
                    participant: baileyMessage.key.participant || senderJid,
                    fromMe: false
                };
                await sock.sendMessage(chatId, { delete: altKey });
            } catch (_) {
                // Si el bot no es admin o WhatsApp rechaza, continuamos sin error
            }
        }

        // ── Enviar aviso al usuario ──
        // Regla solicitada:
        // 1. NO hacerle @ al usuario que tiene las menciones desactivadas.
        // 2. Decir que uno o más usuarios de los mencionados tiene las menciones desactivadas.
        // 3. Si el bot no es admin, igual responde el aviso sin decir nada sobre que no es admin.
        const warnKey = `${chatId}:${senderNum}`;
        const now = Date.now();
        const lastWarn = recentWarns.get(warnKey) || 0;

        // Cooldown de 4 segundos por emisor en el grupo para no floodear el chat
        if (now - lastWarn >= 4000) {
            recentWarns.set(warnKey, now);
            setTimeout(() => recentWarns.delete(warnKey), 10000);

            const alertText = `⚠️ Uno o más usuarios de los que mencionaste tiene las menciones desactivadas.`;

            try {
                // Responder al mensaje infractor (o en el chat citándolo)
                await sock.sendMessage(chatId, {
                    text: alertText
                }, { quoted: baileyMessage });
            } catch (sendErr) {
                try {
                    await sock.sendMessage(chatId, { text: alertText });
                } catch (_) {}
            }
        }

        // Retorna true para cancelar la ejecución de cualquier comando o procesamiento posterior
        return true;

    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[TagProtection] Error en checkAndDeleteTagMessage:', error.message);
        }
        return false;
    }
}

// ── Handler del comando .tag ─────────────────────────────────────────
let handler = async (message, { conn, args }) => {
    try {
        const isGroup = message.isGroup || (message.from && message.from.endsWith('@g.us'));
        const chatId = message.from;
        const senderJid = message.sender || message.author;
        const senderNum = cleanNumber(senderJid);

        if (!senderNum) {
            return await message.reply('❌ No se pudo identificar tu número.');
        }

        const rawArgs = (args || []).map(a => a.toLowerCase().trim());
        const action = rawArgs[0] || '';
        const targetScope = rawArgs[1] || '';

        const isGlobalFlag = targetScope === 'global' || action === 'global' || !isGroup;
        const isGroupFlag = targetScope === 'grupo' || targetScope === 'group' || action === 'grupo';

        // ── Mostrar Estado y Ayuda (sin argumentos o con .tag status / .tag estado) ──
        if (!action || action === 'status' || action === 'estado' || action === 'help') {
            const groupEnabled = isGroup ? (groupProtectedUsers.get(chatId.trim())?.has(senderNum) || false) : false;
            const globalEnabled = globalProtectedUsers.has(senderNum);
            const totalActive = isTagProtectionEnabled(senderNum, chatId);

            let text = `🛡️ *PROTECCIÓN DE MENCIONES (TAG)*\n\n`;
            if (isGroup) {
                text += `📍 *En este grupo:* ${groupEnabled ? '✅ Activado' : '❌ Desactivado'}\n`;
            }
            text += `🌐 *Global (todos los grupos):* ${globalEnabled ? '✅ Activado' : '❌ Desactivado'}\n`;
            text += `📊 *Estado actual aquí:* ${totalActive ? '🛡️ *PROTEGIDO*' : '⚪ *DESPROTEGIDO*'}\n\n`;

            text += `💡 *Comandos disponibles:*\n`;
            if (isGroup) {
                text += `• *.tag on* (o *.tag encender*) - Activar en este grupo\n`;
                text += `• *.tag off* (o *.tag apagar*) - Desactivar en este grupo\n`;
            }
            text += `• *.tag on global* - Activar en todos los grupos\n`;
            text += `• *.tag off global* - Desactivar en todos los grupos\n\n`;

            text += `ℹ️ _Cuando está activado, el bot elimina mensajes que te mencionen y avisa al usuario que tienes las menciones desactivadas. Solo los administradores del grupo tienen permitido etiquetarte._`;

            return await message.reply(text);
        }

        // ── Procesar encendido/apagado ──
        let enable = null;
        if (['on', 'encender', 'activar', 'enable', '1'].includes(action)) {
            enable = true;
        } else if (['off', 'apagar', 'desactivar', 'disable', '0'].includes(action)) {
            enable = false;
        } else if (action === 'global') {
            if (['on', 'encender', 'activar', 'enable', '1'].includes(targetScope)) enable = true;
            if (['off', 'apagar', 'desactivar', 'disable', '0'].includes(targetScope)) enable = false;
        }

        if (enable === null) {
            return await message.reply('⚠️ Opción inválida.\n\nUsa:\n• *.tag on* / *.tag off*\n• *.tag on global* / *.tag off global*');
        }

        // Determinar alcance (global o por grupo)
        const applyGlobally = isGlobalFlag && !isGroupFlag;

        if (applyGlobally) {
            setTagProtection(senderNum, enable, null, true);
            const estadoTexto = enable ? '✅ *ACTIVADA de forma GLOBAL*' : '❌ *DESACTIVADA de forma GLOBAL*';
            return await message.reply(`🛡️ *PROTECCIÓN DE MENCIONES*\n\n${estadoTexto}\n\n${enable ? 'ℹ️ Ahora nadie (excepto administradores) podrá etiquetarte en ningún grupo donde esté el bot.' : 'ℹ️ Ahora los usuarios podrán etiquetarte en los grupos.'}`);
        } else {
            setTagProtection(senderNum, enable, chatId, false);
            const estadoTexto = enable ? '✅ *ACTIVADA en este grupo*' : '❌ *DESACTIVADA en este grupo*';
            return await message.reply(`🛡️ *PROTECCIÓN DE MENCIONES*\n\n${estadoTexto}\n\n${enable ? 'ℹ️ Los mensajes o comandos de usuarios comunes que te mencionen en este grupo serán eliminados.\n_Los administradores del grupo sí pueden etiquetarte._' : 'ℹ️ Ahora los usuarios pueden etiquetarte con normalidad en este grupo.'}`);
        }

    } catch (error) {
        console.error('[Plugin Tag] Error:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando .tag.');
    }
};

handler.help = ['tag'];
handler.tags = ['herramientas', 'config', 'grupos'];
handler.command = /^(tag|antitag|notag)$/i;

module.exports = handler;
module.exports.checkAndDeleteTagMessage = checkAndDeleteTagMessage;
module.exports.isTagProtectionEnabled = isTagProtectionEnabled;
module.exports.setTagProtection = setTagProtection;
