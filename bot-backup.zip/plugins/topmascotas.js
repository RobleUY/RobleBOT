const fs = require('fs');
const path = require('path');
const db = require('../database.js');

// Ruta del archivo para almacenar los datos de las mascotas globalmente
const DATA_DIR = path.join(__dirname, '..', 'data');
const MASCOTAS_FILE = path.join(DATA_DIR, 'mascotas.json');

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

// Función auxiliar para obtener el apodo del usuario
function getApodo(numero) {
    if (!numero) return '👤 Sin Apodo';
    
    // Buscar en la base de datos usando global.db o db normal
    const database = global.db || db;
    let user = database.data?.users?.[numero] || database.data?.users?.[`${numero}@s.whatsapp.net`];
    
    // Búsqueda profunda si no se encontró directamente
    if (!user) {
        user = Object.entries(database.data?.users || {}).find(([id]) => id.startsWith(numero))?.[1];
    }
    
    if (!user) return '👤 Sin Apodo';
    
    const apodo = String(user.apodo || '').trim();
    return (!apodo || apodo.toLowerCase() === 'sin apodo') ? '👤 Sin Apodo' : apodo;
}

let handler = async (message, { text, command }) => {
    try {
        if (!fs.existsSync(MASCOTAS_FILE)) {
            return await message.reply('❌ *Aún no hay mascotas registradas.*\n\n_¡Sé el primero en adoptar una usando .pet adoptar!_');
        }

        const datosMascotas = JSON.parse(fs.readFileSync(MASCOTAS_FILE, 'utf8'));
        const listaMascotas = Object.entries(datosMascotas);

        if (listaMascotas.length === 0) {
            return await message.reply('❌ *Aún no hay mascotas registradas.*\n\n_¡Sé el primero en adoptar una usando .pet adoptar!_');
        }

        // Obtener el número del usuario actual
        const senderJid = message.sender || message?.key?.participant || message?.key?.remoteJid;
        const currentUserNumber = normalizeNumber(senderJid);

        // Variables para el comando
        const body = message.body || text || `.${command}`;
        const usedPrefix = body.charAt(0).match(/^[\\/!#.]/) ? body.charAt(0) : '.';
        const args = body.trim().replace(usedPrefix, '').split(/\s+/);
        const cmd = args[0] || 'toppets';

        // Mapear y calcular los cuidados totales (como desempate)
        let ranking = listaMascotas.map(([numeroDueño, data]) => {
            const totalCuidados = (data.total_comida || 0) + (data.total_agua || 0) + (data.total_juego || 0);
            return {
                number: numeroDueño,
                ...data,
                totalCuidados
            };
        });

        // Lógica de ordenamiento: 1º Nivel | 2º Total de Cuidados
        ranking.sort((a, b) => {
            if (b.nivel !== a.nivel) return b.nivel - a.nivel;
            return b.totalCuidados - a.totalCuidados;
        });

        // ===== CÁLCULOS DE POSICIÓN Y PAGINACIÓN =====
        const totalPets = ranking.length;
        const itemsPerPage = 10;
        
        // Posición del usuario actual
        const userIndex = ranking.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        const totalPages = Math.max(1, Math.ceil(totalPets / itemsPerPage));

        // Determinar qué página mostrar
        let page = 1;
        const pageArg = args[1]; // ej: .toppets 2
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = ranking.slice(start, end);

        // ===== CONSTRUIR MENSAJE =====
        let rankingText = `*🏆 TOP MASCOTAS 🐾*\n\n`;
        rankingText += `🌍 *${totalPets}* mascotas en el mundo\n\n`;

        if (userPosition > 0) {
            const miMascota = ranking[userIndex];
            rankingText += `📍 *Tu pos. global:* #${userPosition} — *${miMascota.nombre}* (Pág. ${userPage})\n`;
            if (userPage !== page) {
                rankingText += `   ↳ Usa *${usedPrefix}${cmd} ${userPage}* para ir a tu página\n`;
            }
        } else {
            rankingText += `📍 *Tu pos. global:* No tienes mascota en el ranking\n`;
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        // Controles de Paginación
        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;

            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *${usedPrefix}${cmd} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *${usedPrefix}${cmd} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        // ===== LISTA DE MASCOTAS =====
        pageUsers.forEach((m, i) => {
            const pos = start + i + 1;
            let medal;
            if (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else medal = `${pos}.`;

            const apodo = getApodo(m.number);

            rankingText += `${medal} ${m.tipo} *${m.nombre}* (Nvl. ${m.nivel})\n`;
            rankingText += `👤 Dueño: *${apodo}*\n`;
            rankingText += `🌟 _Cuidados: ${m.totalCuidados}_\n\n`;
        });

        return await message.reply(rankingText.trim());

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al generar el ranking de mascotas:\x1b[0m', error);
        return await message.reply('⚠️ Error al obtener el top global de mascotas.');
    }
};

handler.help = ['toppets', 'petstop', 'topmascotas'];
handler.tags = ['mascotas', 'top'];
handler.command = /^(toppets|petstop|topmascotas|mascotastop)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;