/**
 * Plugin: view / ver
 * Abre mensajes view-once (o cualquier media citada) y los reenvía
 * en el mismo chat donde se ejecutó el comando.
 */

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ── Helpers (copiados de wao.js) ──────────────────────────────────────────────

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

async function detectQuotedMedia(baileyMsg) {
    try {
        if (!baileyMsg) return null;

        let contextInfo =
            baileyMsg.message?.extendedTextMessage?.contextInfo ||
            baileyMsg.message?.imageMessage?.contextInfo ||
            baileyMsg.message?.videoMessage?.contextInfo ||
            baileyMsg.message?.stickerMessage?.contextInfo ||
            baileyMsg.message?.audioMessage?.contextInfo;

        if (!contextInfo?.quotedMessage) return null;

        const quotedMessage = contextInfo.quotedMessage;

        // Buscar media normal o dentro de view-once
        let mediaMessage =
            quotedMessage.imageMessage ||
            quotedMessage.videoMessage ||
            quotedMessage.stickerMessage ||
            quotedMessage.audioMessage;

        if (quotedMessage.viewOnceMessage) {
            const inner = quotedMessage.viewOnceMessage.message;
            mediaMessage =
                inner.imageMessage ||
                inner.videoMessage ||
                inner.audioMessage ||
                mediaMessage;
        } else if (quotedMessage.viewOnceMessageV2) {
            const inner = quotedMessage.viewOnceMessageV2.message;
            mediaMessage =
                inner.imageMessage ||
                inner.videoMessage ||
                inner.audioMessage ||
                mediaMessage;
        } else if (quotedMessage.viewOnceMessageV2Extension) {
            const inner = quotedMessage.viewOnceMessageV2Extension.message;
            mediaMessage =
                inner.imageMessage ||
                inner.videoMessage ||
                inner.audioMessage ||
                mediaMessage;
        }

        if (!mediaMessage) return null;

        // Determinar tipo
        let type, downloadType;
        const mime = mediaMessage.mimetype || '';

        if (mime.startsWith('audio')) {
            type = 'audio';
            downloadType = 'audio';
        } else if (mime.startsWith('video') || mediaMessage.gifPlayback) {
            type = mediaMessage.gifPlayback ? 'gif' : 'video';
            downloadType = 'video';
        } else if (mime.startsWith('image') || mime.includes('webp')) {
            type = mime.includes('webp') ? 'sticker' : 'image';
            downloadType = mime.includes('webp') ? 'sticker' : 'image';
        } else {
            // Fallback por tipo de mensaje
            if (quotedMessage.imageMessage || quotedMessage.viewOnceMessage?.message?.imageMessage) {
                type = 'image'; downloadType = 'image';
            } else if (quotedMessage.videoMessage || quotedMessage.viewOnceMessage?.message?.videoMessage) {
                type = 'video'; downloadType = 'video';
            } else if (quotedMessage.audioMessage) {
                type = 'audio'; downloadType = 'audio';
            } else {
                return null;
            }
        }

        const stream = await downloadContentFromMessage(mediaMessage, downloadType);
        const buffer = await streamToBuffer(stream);
        return { data: buffer, type, mime };

    } catch (error) {
        console.error('[view] Error detectQuotedMedia:', error.message);
        return null;
    }
}

// ── Handler principal ─────────────────────────────────────────────────────────

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    // Priorizar _baileyMessage del propio mensaje para evitar race conditions con subbots.
    // global.lastBaileyMessage puede haber sido sobreescrito por otro subbot en paralelo.
    const baileyMsg = message._baileysMessage
        || message._baileyMessage
        || message.baileysMessage
        || message.baileyMessage
        || message.rawMessage
        || global.lastBaileyMessage;
    if (!baileyMsg) return message.reply('❌ No se encontró el mensaje.');

    const chatId = message.from;

    let media = await detectQuotedMedia(baileyMsg);

    // Fallback si detectQuotedMedia no encontró nada pero existe message.quoted
    if (!media && message.quoted?.download) {
        try {
            const buf = await message.quoted.download();
            if (buf && buf.length > 100) {
                const mime = message.quoted.mimetype || 'image/jpeg';
                const type = mime.includes('video') ? (message.quoted.mtype === 'videoMessage' ? 'video' : 'gif')
                           : mime.includes('audio') ? 'audio'
                           : mime.includes('webp')  ? 'sticker'
                           : 'image';
                media = { data: buf, type, mime };
            }
        } catch (e) {
            console.error('[view fallback] error:', e.message);
        }
    }

    if (!media) {
        return message.reply(
            '❌ Respondé a una imagen, video, audio o mensaje view-once con *.view*'
        );
    }

    try {
        if (media.type === 'image') {
            await sock.sendMessage(chatId, { image: media.data, caption: '' }, { quoted: baileyMsg });

        } else if (media.type === 'sticker') {
            await sock.sendMessage(chatId, { sticker: media.data }, { quoted: baileyMsg });

        } else if (media.type === 'video' || media.type === 'gif') {
            await sock.sendMessage(chatId, {
                video: media.data,
                gifPlayback: media.type === 'gif',
                caption: ''
            }, { quoted: baileyMsg });

        } else if (media.type === 'audio') {
            await sock.sendMessage(chatId, {
                audio: media.data,
                mimetype: media.mime || 'audio/ogg; codecs=opus',
                ptt: true
            }, { quoted: baileyMsg });
        }

    } catch (err) {
        console.error('[view] Error enviando media:', err.message);
        await message.reply('❌ No pude enviar el archivo.');
    }
};

handler.help    = ['view', 'ver'];
handler.tags    = ['herramientas'];
handler.command = /^(view|ver|escrachar)$/i;
handler.group   = false;

module.exports = handler;

