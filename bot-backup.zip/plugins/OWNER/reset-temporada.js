const fs = require('fs');
const path = require('path');
const db = require('../../database.js');

module.exports = {
  name: 'reset-temporada',
  aliases: ['resettemporada', 'nuevatemporada', 'reset-season'],
  category: 'owner',
  description: 'Reinicia datos de temporada: database (mantiene apodos), botstats (vacía usuariosUsados), ias-personalizadas (resetea cantidadUsuarios), comandos personalizados (resetea usos y usuariosUsados)',
  ownerOnly: true,
  
  async execute(sock, msg, args) {
    const jid = msg.messages[0].key.remoteJid;
    
    try {
      await sock.sendMessage(jid, { text: '🔄 *INICIANDO RESET DE TEMPORADA*\n\n⏳ Creando backups de seguridad...' });
      
      // Definir rutas de archivos
      const databasePath = path.join(__dirname, '../../database.db');
      const botstatsPath = path.join(__dirname, '../../data/botstats.json');
      const iasPath = path.join(__dirname, '../../data/ias-personalizadas.json');
      const comandosPath = path.join(__dirname, '../../data/comandos.json');
      
      // ============ PASO 1: CREAR BACKUPS ============
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
      const backupResults = [];
      
      // Backup database.db (SQLite)
      try {
        if (global.db && typeof global.db.backup === 'function') {
          global.db.backup(); // guarda en la raíz con timestamp
          backupResults.push('✅ database.db');
        } else if (fs.existsSync(databasePath)) {
          const backupDbPath = path.join(__dirname, '../../', `database_backup_${timestamp}.db`);
          fs.copyFileSync(databasePath, backupDbPath);
          backupResults.push('✅ database.db (copia directa)');
        }
      } catch (err) {
        backupResults.push('❌ database.db: ' + err.message);
      }
      
      // Backup botstats.json (en data/)
      try {
        if (fs.existsSync(botstatsPath)) {
          const backupBotstatsPath = path.join(__dirname, '../../data', `backup-botstats-${timestamp}.json`);
          fs.copyFileSync(botstatsPath, backupBotstatsPath);
          backupResults.push('✅ botstats.json');
        }
      } catch (err) {
        backupResults.push('❌ botstats.json: ' + err.message);
      }
      
      // Backup ias-personalizadas.json (en data/)
      try {
        if (fs.existsSync(iasPath)) {
          const backupIasPath = path.join(__dirname, '../../data', `backup-ias-personalizadas-${timestamp}.json`);
          fs.copyFileSync(iasPath, backupIasPath);
          backupResults.push('✅ ias-personalizadas.json');
        }
      } catch (err) {
        backupResults.push('❌ ias-personalizadas.json: ' + err.message);
      }
      
      // Backup comandos.json (en data/)
      try {
        if (fs.existsSync(comandosPath)) {
          const backupComandosPath = path.join(__dirname, '../../data', `backup-comandos-${timestamp}.json`);
          fs.copyFileSync(comandosPath, backupComandosPath);
          backupResults.push('✅ comandos.json');
        }
      } catch (err) {
        backupResults.push('❌ comandos.json: ' + err.message);
      }
      
      await sock.sendMessage(jid, { 
        text: `📦 *BACKUPS CREADOS*\n\n${backupResults.join('\n')}\n\n⏳ Iniciando reset de datos...` 
      });
      
      // ============ PASO 2: RESETEAR DATOS ============
      const resetResults = [];
      let usersResetCount = 0;
      
      // 1. RESETEAR DATABASE (usuarios — mantener solo apodos)
      try {
        if (global.db) {
          // Leer todos los usuarios desde SQLite
          const allUsers = global.db.data.users;
          
          for (const userId in allUsers) {
            const user = allUsers[userId];
            const apodoActual = user.apodo || '';
            
            // Construir objeto reseteado manteniendo solo el apodo
            const resetData = {
              apodo: apodoActual,
              money: 0,
              bank: 0,
              exp: 0,
              level: 1,
              ComandosEjecutados: 0,
              lastWork: 0,
              lastSlut: 0,
              lastDaily: 0,
              lastCrime: 0,
              lastRob: 0,
              lastStudy: 0,
              lastMine: 0,
              lastHunt: 0,
              respeto: 0,
              rango: '🌱 Novato',
              minerales: {},
              animales: {},
              betStats: {},
              blackjackStats: {},
              bombaStats: {},
              carreraStats: {},
              dadosStats: {},
              ruletaStats: {},
              tragamonedasStats: {},
              caballosStats: {},
              prestamo: 0,
              prestamoFecha: 0,
              inversiones: {},
              wordleStats: {},
              numberleStats: {},
              ahorcadoStats: {},
              tatetiStats: {},
            };
            
            // Persistir con setUser (compatible con SQLite)
            global.db.setUser(userId, resetData);
            usersResetCount++;
          }
          
          resetResults.push(`✅ Database: ${usersResetCount} usuarios reseteados (apodos mantenidos)`);
        }
      } catch (err) {
        resetResults.push('❌ Database: ' + err.message);
      }
      
      // 2. RESETEAR BOTSTATS.JSON (vaciar usuariosUsados)
      try {
        if (fs.existsSync(botstatsPath)) {
          const botstatsData = JSON.parse(fs.readFileSync(botstatsPath, 'utf-8'));
          const previousUsers = botstatsData.usuariosUsados ? botstatsData.usuariosUsados.length : 0;
          
          // Vaciar el array de usuarios usados
          botstatsData.usuariosUsados = [];
          
          fs.writeFileSync(botstatsPath, JSON.stringify(botstatsData, null, 2), 'utf-8');
          resetResults.push(`✅ BotStats: ${previousUsers} usuarios removidos de usuariosUsados`);
        }
      } catch (err) {
        resetResults.push('❌ BotStats: ' + err.message);
      }
      
      // 3. RESETEAR IAS-PERSONALIZADAS.JSON (resetear cantidadUsuarios, mantener IAs y creadores)
      try {
        if (fs.existsSync(iasPath)) {
          const iasData = JSON.parse(fs.readFileSync(iasPath, 'utf-8'));
          let iasResetCount = 0;
          
          if (iasData.ias) {
            for (const iaKey in iasData.ias) {
              const ia = iasData.ias[iaKey];
              // Resetear uses y usedBy pero mantener todo lo demás
              if (ia.uses !== undefined) {
                ia.uses = 0;
              }
              if (ia.usedBy !== undefined) {
                ia.usedBy = [];
              }
              iasResetCount++;
            }
          }
          
          fs.writeFileSync(iasPath, JSON.stringify(iasData, null, 2), 'utf-8');
          resetResults.push(`✅ IAs Personalizadas: ${iasResetCount} IAs reseteadas (manteniendo creadores y configuración)`);
        }
      } catch (err) {
        resetResults.push('❌ IAs Personalizadas: ' + err.message);
      }
      
      // 4. RESETEAR COMANDOS.JSON (resetear usos y usuariosUsados, mantener comandos creados)
      try {
        if (fs.existsSync(comandosPath)) {
          const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf-8'));
          let comandosResetCount = 0;
          
          if (comandosData.commands) {
            for (const cmdKey in comandosData.commands) {
              const cmd = comandosData.commands[cmdKey];
              // Resetear uses y usedBy pero mantener todo lo demás (template, creator, etc.)
              if (cmd.uses !== undefined) {
                cmd.uses = 0;
              }
              if (cmd.usedBy !== undefined) {
                cmd.usedBy = [];
              }
              comandosResetCount++;
            }
          }
          
          fs.writeFileSync(comandosPath, JSON.stringify(comandosData, null, 2), 'utf-8');
          resetResults.push(`✅ Comandos Personalizados: ${comandosResetCount} comandos reseteados (manteniendo configuración)`);
        }
      } catch (err) {
        resetResults.push('❌ Comandos Personalizados: ' + err.message);
      }
      
      // ============ RESULTADO FINAL ============
      const finalMessage = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎊 *RESET DE TEMPORADA COMPLETADO* 🎊
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 *RESULTADOS:*

${resetResults.join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ *Los datos han sido reseteados exitosamente*
📦 *Backups guardados con fecha ${timestamp}*
   • database.db → raíz del proyecto
   • Otros archivos → carpeta /data/

🔄 *Nueva temporada iniciada*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
      
      await sock.sendMessage(jid, { text: finalMessage });
      
    } catch (error) {
      console.error('Error en reset-temporada:', error);
      await sock.sendMessage(jid, { 
        text: `❌ *ERROR DURANTE EL RESET*\n\n${error.message}\n\n⚠️ Los backups se crearon correctamente antes del error.` 
      });
    }
  }
};
