const { ejecutarResetTemporada } = require('../../resetScheduler');

module.exports = {
  name: 'reset-temporada',
  aliases: ['resettemporada', 'nuevatemporada', 'reset-season'],
  category: 'owner',
  description: 'Ejecuta el reset mensual de temporada conservando apodos, parejas, clanes (estructura) y reseteando economía y estadísticas.',
  ownerOnly: true,

  async execute(sock, msg, args) {
    const jid = msg.messages[0]?.key?.remoteJid || msg.from;

    try {
      if (sock && typeof sock.sendMessage === 'function' && jid) {
        await sock.sendMessage(jid, { text: '🔄 *INICIANDO RESET DE TEMPORADA*\n\n⏳ Creando backups de seguridad y reseteando datos...' });
      }

      const res = await ejecutarResetTemporada(sock, false);

      if (res && res.success) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
        const finalMessage = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎊 *RESET DE TEMPORADA COMPLETADO* 🎊
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 *BACKUPS CREADOS:*
${(res.backupResults || []).join('\n')}

📋 *RESULTADOS:*
${(res.resetResults || []).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ *Los datos han sido reseteados exitosamente*
📦 *Backups guardados con fecha ${timestamp}*
🔄 *Nueva temporada iniciada*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

        if (sock && typeof sock.sendMessage === 'function' && jid) {
          await sock.sendMessage(jid, { text: finalMessage });
        }
      } else {
        const errorMsg = res?.error || 'Error desconocido';
        if (sock && typeof sock.sendMessage === 'function' && jid) {
          await sock.sendMessage(jid, { text: `❌ *ERROR DURANTE EL RESET DE TEMPORADA*\n\n${errorMsg}` });
        }
      }
    } catch (error) {
      console.error('Error en comando reset-temporada:', error);
      if (sock && typeof sock.sendMessage === 'function' && jid) {
        await sock.sendMessage(jid, { text: `❌ *ERROR DURANTE EL RESET*\n\n${error.message}` }).catch(() => {});
      }
    }
  }
};
