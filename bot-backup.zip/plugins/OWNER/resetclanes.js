const path = require('path');
const fs = require('fs');

module.exports = {
  name: 'resetclanes',
  aliases: ['reset-clanes'],
  category: 'owner',
  description: 'Resetea TODOS los clanes aplicando la lista blanca del reset de temporada. Uso único para limpiar clanes corruptos.',
  ownerOnly: true,

  async execute(sock, msg, args) {
    const jid = msg.messages[0]?.key?.remoteJid || msg.from;

    try {
      await sock.sendMessage(jid, { text: '🔄 *INICIANDO RESET DE CLANES*\n\n⏳ Procesando...' });

      if (!global.db || !global.db.db) {
        return await sock.sendMessage(jid, { text: '❌ No se pudo acceder a la base de datos.' });
      }

      const sqliteDb = global.db.db;

      // Cargar lista blanca de clanes
      const whitelistPath = path.join(__dirname, '../../data/reset-whitelist.json');
      let clanFieldsToKeep = ['nombre', 'lider', 'decanos', 'miembros', 'invitaciones', 'creadoEn', 'logo', 'banner', 'descripcion'];

      if (fs.existsSync(whitelistPath)) {
        try {
          const wl = JSON.parse(fs.readFileSync(whitelistPath, 'utf8'));
          if (wl.clanFieldsToKeep) clanFieldsToKeep = wl.clanFieldsToKeep;
        } catch (_) {}
      }

      // Checkpoint WAL previo
      try { sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}

      const clanRows = sqliteDb.prepare("SELECT key, value FROM kv WHERE collection = 'clanes'").all();
      let clanesReseteados = 0;
      let clanesEliminados = 0;

      sqliteDb.exec('BEGIN IMMEDIATE');

      for (const row of clanRows) {
        let clan = {};
        try { clan = JSON.parse(row.value); } catch (_) {}

        // Verificar si el clan tiene al menos un miembro válido, si no eliminarlo
        const miembros = Array.isArray(clan.miembros) ? clan.miembros : [];
        const lider = clan.lider || null;

        if (!lider && miembros.length === 0) {
          // Clan vacío/corrupto → eliminar
          sqliteDb.prepare("DELETE FROM kv WHERE collection = 'clanes' AND key = ?").run(row.key);
          clanesEliminados++;
          continue;
        }

        // Reconstruir clan conservando solo los campos de la lista blanca
        const resetClan = {
          nombre: clan.nombre || row.key,
          lider: clan.lider || '',
          decanos: Array.isArray(clan.decanos) ? clan.decanos : [],
          miembros: Array.isArray(clan.miembros) ? clan.miembros : [],
          invitaciones: Array.isArray(clan.invitaciones) ? clan.invitaciones : [],
          creadoEn: clan.creadoEn || Date.now(),
          logo: clan.logo || null,
          banner: clan.banner || null,
          descripcion: clan.descripcion || '',

          // Campos reseteados a valores por defecto
          vida: 100,
          maxVida: 100,
          depositos: {},
          lastAttackedTime: 0,
          reparaciones: 0,
          stats: {
            ataquesRealizados: 0,
            ataquesRecibidos: 0,
            clanesDerrotados: 0
          }
        };

        sqliteDb.prepare("INSERT OR REPLACE INTO kv (collection, key, value) VALUES ('clanes', ?, ?)").run(row.key, JSON.stringify(resetClan));
        clanesReseteados++;
      }

      sqliteDb.exec('COMMIT');

      // Limpiar caché en memoria
      if (global.db._kvCache && typeof global.db._kvCache.clear === 'function') {
        global.db._kvCache.clear();
      }

      // Checkpoint WAL final
      try { sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}

      const msg_final = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏰 *RESET DE CLANES COMPLETADO* 🏰
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ *Clanes reseteados:* ${clanesReseteados}
🗑️ *Clanes corruptos eliminados:* ${clanesEliminados}

📋 *Qué se conservó:*
• Nombre, líder, decanos, miembros
• Invitaciones, logo, banner, descripción

🔄 *Qué se reinició:*
• Vida → 100/100
• Depósitos → vacíos
• Estadísticas de batalla → 0
• Ataques realizados/recibidos → 0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      await sock.sendMessage(jid, { text: msg_final });

    } catch (error) {
      console.error('Error en resetclanes:', error);
      try { global.db?.db?.exec('ROLLBACK'); } catch (_) {}
      await sock.sendMessage(jid, { text: `❌ *ERROR DURANTE EL RESET DE CLANES*\n\n${error.message}` }).catch(() => {});
    }
  }
};
