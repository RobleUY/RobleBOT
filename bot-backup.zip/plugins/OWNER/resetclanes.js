const path = require('path');
const fs = require('fs');
const config = require('../../config.js');

let handler = async (message, { conn }) => {
    const sender = message.sender || message.key?.participant || message.key?.remoteJid;
    const cleanNumber = sender.split('@')[0].split(':')[0].replace(/\D/g, '');
    const isOwner = config.adminsbot.includes(cleanNumber) || config.adminsbot.includes(sender);

    if (!isOwner) {
        return await message.reply('⛔ *Acceso denegado* — Solo el owner puede usar este comando.');
    }

    const jid = message.from || message.key?.remoteJid;

    try {
        await message.reply('🔄 *INICIANDO RESET DE CLANES*\n\n⏳ Procesando...');

        if (!global.db || !global.db.db) {
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        }

        const sqliteDb = global.db.db;

        // Checkpoint WAL previo
        try { sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}

        const clanRows = sqliteDb.prepare("SELECT key, value FROM kv WHERE collection = 'clanes'").all();
        let clanesReseteados = 0;
        let clanesEliminados = 0;

        sqliteDb.exec('BEGIN IMMEDIATE');

        for (const row of clanRows) {
            let clan = {};
            try { clan = JSON.parse(row.value); } catch (_) {}

            const miembros = Array.isArray(clan.miembros) ? clan.miembros : [];
            const lider = clan.lider || null;

            if (!lider && miembros.length === 0) {
                sqliteDb.prepare("DELETE FROM kv WHERE collection = 'clanes' AND key = ?").run(row.key);
                clanesEliminados++;
                continue;
            }

            const resetClan = {
                nombre: clan.nombre || row.key,
                lider: clan.lider || '',
                decanos: Array.isArray(clan.decanos) ? clan.decanos : [],
                miembros: Array.isArray(clan.miembros) ? clan.miembros : [],
                invitaciones: Array.isArray(clan.invitaciones) ? clan.invitaciones : [],
                creadoEn: clan.creadoEn || Date.now(),
                logo: clan.logo || null,
                banner: clan.banner || null,
                descripcion: clan.descripcion || '',

                // Campos reseteados
                vida: 100,
                maxVida: 100,
                depositos: {},
                lastAttackedTime: 0,
                reparaciones: 0,
                stats: {
                    ataquesRealizados: 0,
                    ataquesRecibidos: 0,
                    clanesDerrotados: 0
                }
            };

            sqliteDb.prepare("INSERT OR REPLACE INTO kv (collection, key, value) VALUES ('clanes', ?, ?)").run(row.key, JSON.stringify(resetClan));
            clanesReseteados++;
        }

        sqliteDb.exec('COMMIT');

        // Limpiar caché en memoria
        if (global.db._kvCache && typeof global.db._kvCache.clear === 'function') {
            global.db._kvCache.clear();
        }

        // Checkpoint WAL final
        try { sqliteDb.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}

        await message.reply(`━━━━━━━━━━━━━━━
🏰 *RESET DE CLANES COMPLETADO* 🏰
━━━━━━━━━━━━━━━

✅ *Clanes reseteados:* ${clanesReseteados}
🗑️ *Clanes corruptos eliminados:* ${clanesEliminados}

📋 *Qué se conservó:*
• Nombre, líder, decanos, miembros
• Invitaciones, logo, banner, descripción

🔄 *Qué se reinició:*
• Vida → 100/100
• Depósitos → vacíos
• Estadísticas de batalla → 0
• Ataques realizados/recibidos → 0

━━━━━━━━━━━━━━━`);

    } catch (error) {
        console.error('Error en resetclanes:', error);
        try { global.db?.db?.exec('ROLLBACK'); } catch (_) {}
        await message.reply(`❌ *ERROR DURANTE EL RESET DE CLANES*\n\n${error.message}`).catch(() => {});
    }
};

handler.help = ['resetclanes'];
handler.tags = ['owner'];
handler.owner = true;
handler.command = /^(resetclanes|reset-clanes)$/i;

module.exports = handler;
