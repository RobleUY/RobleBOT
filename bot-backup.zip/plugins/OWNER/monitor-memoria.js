// plugins/OWNER/monitor-memoria.js
// Comando OWNER para controlar manualmente el monitor de memoria

const { startMemoryMonitor, stopMemoryMonitor, getMonitorStatus } = require('../../memoryMonitor');
const config = require('../../config.js');

let handler = async (message, { args }) => {
    // Verificar si el usuario es owner
    const ownerNumbers = config.ownerNumbers || [];
    const senderNumber = message.sender.split('@')[0];
    
    const isOwner = ownerNumbers.includes(senderNumber);
    if (!isOwner) {
        return await message.reply('❌ Este comando solo está disponible para el owner del bot.');
    }

    const action = args[0]?.toLowerCase();

    if (!action || !['start', 'stop', 'status', 'iniciar', 'detener', 'estado'].includes(action)) {
        return await message.reply(
            `📋 *USO DEL COMANDO*\n\n` +
            `*Iniciar monitor:*\n.monitormemoria start\n\n` +
            `*Detener monitor:*\n.monitormemoria stop\n\n` +
            `*Ver estado:*\n.monitormemoria status`
        );
    }

    try {
        if (action === 'start' || action === 'iniciar') {
            if (global._memoryMonitorActive) {
                return await message.reply('⚠️ El monitor de memoria ya está activo.');
            }
            
            startMemoryMonitor();
            global._memoryMonitorActive = true;
            
            const status = getMonitorStatus();
            await message.reply(
                `✅ *Monitor de memoria INICIADO*\n\n` +
                `🎯 Umbral: ${status.thresholdGB} GB\n` +
                `📊 Uso actual: ${status.currentMemory.rssGB} GB\n` +
                `⏱️ Chequeo: cada 30s`
            );

        } else if (action === 'stop' || action === 'detener') {
            if (!global._memoryMonitorActive) {
                return await message.reply('⚠️ El monitor de memoria ya está inactivo.');
            }
            
            stopMemoryMonitor();
            global._memoryMonitorActive = false;
            
            await message.reply('🛑 Monitor de memoria detenido correctamente.');

        } else if (action === 'status' || action === 'estado') {
            const status = getMonitorStatus();
            const memory = status.currentMemory;
            
            await message.reply(
                `📊 *ESTADO DEL MONITOR DE MEMORIA*\n\n` +
                `🛡️ *Estado:* ${status.isActive ? '✅ Activo' : '❌ Inactivo'}\n` +
                `🔹 *Uso actual:* ${memory.rssGB} GB\n` +
                `🎯 *Umbral:* ${status.thresholdGB} GB\n` +
                `📈 *Porcentaje:* ${status.percentageUsed}%\n\n` +
                `${status.isRestarting ? '⚠️ *Reinicio en progreso...*' : ''}` +
                `${!status.isActive ? '\n💡 Usa `.monitormemoria start` para activarlo' : ''}`
            );
        }
    } catch (error) {
        await message.reply(`❌ Error: ${error.message}`);
        console.error('[MonitorMemoria] Error:', error);
    }
};

handler.help = ['monitormemoria'];
handler.tags = ['owner'];
handler.command = /^(monitormemoria|monitorram)$/i;

module.exports = handler;
