const { tempCleaner } = require('../../tempCleaner');

module.exports = {
  name: 'limpiar-temp',
  aliases: ['cleantemp', 'limpiartemp', 'temp-clean'],
  category: 'owner',
  description: 'Limpia archivos temporales del bot y muestra estadísticas',
  ownerOnly: true,
  
  async execute(sock, msg, args) {
    const jid = msg.messages[0].key.remoteJid;
    
    try {
      const action = args[0]?.toLowerCase();
      
      if (action === 'stats' || action === 'estadisticas') {
        // Mostrar estadísticas
        await sock.sendMessage(jid, { text: '📊 Obteniendo estadísticas de archivos temporales...' });
        
        const stats = tempCleaner.getTempStats();
        
        if (stats.error) {
          return await sock.sendMessage(jid, { text: `❌ Error obteniendo estadísticas: ${stats.error}` });
        }
        
        const response = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 ESTADÍSTICAS DE ARCHIVOS TEMPORALES

📁 Total de archivos: ${stats.totalFiles}
🤖 Archivos del bot: ${stats.botFiles}
💾 Tamaño total: ${stats.totalSize}
🧹 Tamaño del bot: ${stats.botSize}

ℹ️ Los archivos del bot se limpian automáticamente
   después de 15 minutos de inactividad.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

        await sock.sendMessage(jid, { text: response });
        
      } else {
        // Limpieza manual
        await sock.sendMessage(jid, { text: '🧹 Iniciando limpieza manual de archivos temporales...' });
        
        const result = await tempCleaner.manualCleanup();
        
        if (result.error) {
          return await sock.sendMessage(jid, { text: `❌ Error durante la limpieza: ${result.error}` });
        }
        
        let response = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧹 LIMPIEZA COMPLETADA

`;

        if (result.cleaned === 0) {
          response += `✅ No había archivos temporales para limpiar
📊 Sistema limpio`;
        } else {
          const sizeMB = (result.totalSize / (1024 * 1024)).toFixed(2);
          response += `🗑️  Archivos eliminados: ${result.cleaned}
💾 Espacio liberado: ${sizeMB} MB`;
          
          if (result.errors > 0) {
            response += `\n⚠️ Errores: ${result.errors} archivos no se pudieron eliminar`;
          }
        }
        
        response += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ℹ️ La limpieza automática funciona cada 20 minutos`;

        await sock.sendMessage(jid, { text: response });
      }
      
    } catch (error) {
      console.error('Error en limpiar-temp:', error);
      await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` });
    }
  }
};