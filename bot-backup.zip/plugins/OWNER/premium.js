const premium = require('../../premium');
const botConfig = require('../../config');

let handler = async (message, { text, args }) => {
  try {
    const senderJid = message.author || message.from || message.sender;
    const senderNumber = senderJid ? senderJid.split('@')[0].replace(/[^0-9]/g, '') : null;
    if (!senderNumber) {
      return await message.reply('❌ No se pudo identificar tu número.');
    }

    const isOwner = botConfig.isOwner(senderNumber) || botConfig.isOwner(`${senderNumber}@s.whatsapp.net`);

    if (!text || !args || args.length === 0) {
      const info = premium.getPremiumInfo(senderNumber);

      const beneficios =
        `👑 *Beneficios Premium*\n` +
        `⚡ Multiplicador *x2* de dinero en todos los comandos\n` +
        `⏱️ *50% menos* tiempo de espera en cooldowns\n` +
        `🏆 Rango máximo automático con premium comprado en *.rankup*\n` +
        `🐾 Autocuidado automático de mascotas\n` +
        `★ Símbolo especial *★* en tus respuestas`;

      const tienda =
        `\n\n🛒 *¿Querés adquirirlo?*\n` +
        `Compralo desde la tienda oficial:\n` +
        `https://roblebotpage.vercel.app/tienda.html\n\n` +
        `El pago es seguro vía PayPal y se activa automáticamente.`;

      if (info.active) {
        return await message.reply(
          `✨ *Eres usuario Premium.* ★\n\n` +
          `📌 *Inicio:* ${premium.formatDateOnly(info.startedAt)}\n` +
          `⏳ *Tiempo restante:* ${premium.formatRemaining(info.remainingMs)}\n\n` +
          beneficios + tienda
        );
      }

      return await message.reply(
        `❌ *No eres usuario Premium.*\n\n` +
        beneficios + tienda
      );
    }

    const action = args[0].toLowerCase();

    if (action === 'migrar' || action === 'migrate') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const result = premium.migratePremiumEntriesToMixed();
      return await message.reply(
        `✅ Migración completada.\n` +
        `📌 Entradas revisadas: ${result.totalEntries}\n` +
        `🔄 Actualizadas a mixed: ${result.migratedCount}`
      );
    }

    if (action === 'list' || action === 'lista') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const premiumUsers = premium.getPremiumList();
      if (!premiumUsers.length) {
        return await message.reply('📋 No hay usuarios premium activos en este momento.');
      }

      const lines = [];
      for (const entry of premiumUsers) {
        const user = global.db.getUser(entry.userId);
        const apodo = (user?.apodo || '').trim() || entry.userId;
        lines.push(`• ${apodo} — ${premium.formatRemaining(entry.remainingMs)}`);
      }

      return await message.reply(
        `📋 *Lista de usuarios premium activos*\n\n${lines.join('\n')}`
      );
    }

    if (['resetfree', 'reset-free', 'reset'].includes(action)) {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const targetArg = args[1] ? args[1].trim() : '';

      if (!targetArg) {
        return await message.reply(
          '❌ Debes especificar un apodo, mención o "all".\n\n' +
          'Ejemplos:\n' +
          '• `.premium resetfree pepe` (resetea el reclamo a un usuario)\n' +
          '• `.premium resetfree all` (resetea el reclamo a TODOS los usuarios)'
        );
      }

      if (targetArg.toLowerCase() === 'all' || targetArg.toLowerCase() === 'todos') {
        let count = 0;
        const allUsersRows = global.db._stmts.getAllUsers.all();
        for (const row of allUsersRows) {
          const user = global.db.getUser(row.id);
          if (user && (user.premium_free_claimed !== undefined && user.premium_free_claimed !== false && user.premium_free_claimed !== null)) {
            user.premium_free_claimed = false;
            global.db.setUser(row.id, user);
            count++;
          }
        }
        if (global.db && typeof global.db.saveNow === 'function') {
          global.db.saveNow();
        }
        return await message.reply(`✅ Se reseteó el estado de Premium gratuito a *${count}* usuario(s). Pueden volver a reclamarlo en la web (sus días premium actuales NO fueron modificados).`);
      }

      let targetNumber = null;
      const mentions = Array.isArray(message.mentions) ? message.mentions : [];
      const normalizedTargetArg = targetArg.replace(/^@+/, '');
      if (mentions.length > 0) {
        targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
      } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
        targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
      } else {
        targetNumber = premium.findNumberByApodo(normalizedTargetArg);
      }

      if (!targetNumber) {
        return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
      }

      const canonicalId = global.db?.getCanonicalId?.(targetNumber) || targetNumber;
      const user = global.db.getUser(canonicalId);
      if (!user) {
        return await message.reply(`❌ No se encontró la cuenta de *${targetArg}* en la base de datos.`);
      }

      user.premium_free_claimed = false;
      global.db.setUser(canonicalId, user);
      if (global.db && typeof global.db.saveNow === 'function') {
        global.db.saveNow();
      }

      return await message.reply(`✅ Se reseteó el estado de Premium gratuito para *${targetArg}*. Ahora puede volver a reclamar el día gratis en la web (sus días premium actuales NO fueron modificados).`);
    }

    if (!['dar', 'give'].includes(action)) {
      return await message.reply(
        'Uso:\n' +
        '.premium\n' +
        '.premium dar @usuario/apodo cantidad-de-días\n' +
        '.premium resetfree apodo / all\n' +
        '.premium list\n' +
        '.premium migrar\n\n' +
        'Ejemplos:\n' +
        '• .premium dar pepe 30\n' +
        '• .premium resetfree pepe\n' +
        '• .premium resetfree all'
      );
    }

    if (!isOwner) {
      return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
    }

    if (args.length < 3) {
      return await message.reply('❌ Debes especificar a quién dar premium y la cantidad de días. Ejemplo: .premium dar pepe 30');
    }

    const targetArg = args[1];
    const days = parseInt(args[2], 10);

    if (isNaN(days) || days <= 0) {
      return await message.reply('❌ La cantidad de días debe ser un número entero positivo.');
    }

    let targetNumber = null;
    const mentions = Array.isArray(message.mentions) ? message.mentions : [];
    const normalizedTargetArg = targetArg.toString().trim().replace(/^@+/, '');
    if (mentions.length > 0) {
      targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
    } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
      targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
    } else {
      targetNumber = premium.findNumberByApodo(normalizedTargetArg);
    }

    if (!targetNumber) {
      return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
    }

    const result = premium.addPremium(targetNumber, days / 30, { source: 'free' });
    if (!result) {
      return await message.reply('❌ No se pudo otorgar premium. Intenta nuevamente.');
    }

    return await message.reply(
      `✅ Premium otorgado con éxito a *${targetArg}*.\n` +
      `📌 Fecha de inicio: ${premium.formatDateOnly(result.startedAt)}\n` +
      `⏳ Tiempo restante: ${premium.formatRemaining(result.remainingMs)}\n` +
      `\n★ Usa: .premium para ver los beneficios.`
    );
  } catch (error) {
    console.error('[Premium] Error en comando premium:', error);
    return await message.reply('❌ Ocurrió un error al procesar el comando premium.');
  }
};

handler.help = ['premium'];
handler.tags = ['owner'];
handler.command = /^premium$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;
