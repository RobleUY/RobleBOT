const premium = require('../../premium');
const botConfig = require('../../config');

let handler = async (message, { text, args }) => {
  try {
    const senderJid = message.author || message.from || message.sender;
    const senderNumber = senderJid ? senderJid.split('@')[0].replace(/[^0-9]/g, '') : null;
    if (!senderNumber) {
      return await message.reply('❌ No se pudo identificar tu número.');
    }

    const isOwner = botConfig.isOwner(senderNumber) || botConfig.isOwner(`${senderNumber}@s.whatsapp.net`);

    if (!text || !args || args.length === 0) {
      const info = premium.getPremiumInfo(senderNumber);

      const beneficios =
        `👑 *Beneficios Premium*\n` +
        `⚡ Multiplicador *x2* de dinero en todos los comandos\n` +
        `⏱️ *50% menos* tiempo de espera en cooldowns\n` +
        `🏆 Rango máximo automático con premium comprado en *.rankup*\n` +
        `🐾 Autocuidado automático de mascotas\n` +
        `★ Símbolo especial *★* en tus respuestas`;

      const tienda =
        `\n\n🛒 *¿Querés adquirirlo?*\n` +
        `Compralo desde la tienda oficial:\n` +
        `https://roblebotpage.vercel.app/tienda.html\n\n` +
        `El pago es seguro vía PayPal y se activa automáticamente.`;

      if (info.active) {
        return await message.reply(
          `✨ *Eres usuario Premium.* ★\n\n` +
          `📌 *Inicio:* ${premium.formatDateOnly(info.startedAt)}\n` +
          `⏳ *Tiempo restante:* ${premium.formatRemaining(info.remainingMs)}\n\n` +
          beneficios + tienda
        );
      }

      return await message.reply(
        `❌ *No eres usuario Premium.*\n\n` +
        beneficios + tienda
      );
    }

    const action = args[0].toLowerCase();

    if (action === 'migrar' || action === 'migrate') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const result = premium.migratePremiumEntriesToMixed();
      return await message.reply(
        `✅ Migración completada.\n` +
        `📌 Entradas revisadas: ${result.totalEntries}\n` +
        `🔄 Actualizadas a mixed: ${result.migratedCount}`
      );
    }

    if (action === 'list' || action === 'lista') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const premiumUsers = premium.getPremiumList();
      if (!premiumUsers.length) {
        return await message.reply('📋 No hay usuarios premium activos en este momento.');
      }

      const lines = [];
      for (const entry of premiumUsers) {
        const user = global.db.getUser(entry.userId);
        const apodo = (user?.apodo || '').trim() || entry.userId;
        lines.push(`• ${apodo} — ${premium.formatRemaining(entry.remainingMs)}`);
      }

      return await message.reply(
        `📋 *Lista de usuarios premium activos*\n\n${lines.join('\n')}`
      );
    }

    if (action === 'resetfree' || action === 'reset-free') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      if (args.length < 2) {
        return await message.reply('❌ Debes especificar el usuario o "all". Ejemplo: .premium resetfree @usuario o .premium resetfree all');
      }

      const targetArg = args[1];

      // ── RESET ALL ──────────────────────────────────────────────────────────
      if (targetArg.toLowerCase() === 'all' || targetArg.toLowerCase() === 'todos') {
        await message.reply('🔄 Iniciando reset masivo del flag premium_free_claimed...');

        const allUsers = global.db?.data?.users || {};
        let totalUsers = 0;
        let resettedCount = 0;
        let alreadyAvailableCount = 0;

        for (const userId in allUsers) {
          const user = allUsers[userId];
          if (!user) continue;
          
          totalUsers++;
          
          if (user.premium_free_claimed === true) {
            user.premium_free_claimed = false;
            global.db.setUser(userId, user);
            resettedCount++;
          } else {
            alreadyAvailableCount++;
          }
        }

        return await message.reply(
          `✅ *Reset masivo completado*\n\n` +
          `👥 Total de usuarios: ${totalUsers}\n` +
          `🔓 Flags reseteados: ${resettedCount}\n` +
          `✔️ Ya disponibles: ${alreadyAvailableCount}\n\n` +
          `🎁 Todos los usuarios ahora pueden reclamar su día de premium gratis desde la web.`
        );
      }

      // ── RESET INDIVIDUAL ───────────────────────────────────────────────────
      let targetNumber = null;
      const mentions = Array.isArray(message.mentions) ? message.mentions : [];
      const normalizedTargetArg = targetArg.toString().trim().replace(/^@+/, '');

      if (mentions.length > 0) {
        targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
      } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
        targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
      } else {
        targetNumber = premium.findNumberByApodo(normalizedTargetArg);
      }

      if (!targetNumber) {
        return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
      }

      const user = global.db.getUser(targetNumber);
      if (!user) {
        return await message.reply(`❌ Usuario *${targetArg}* no encontrado en la base de datos.`);
      }

      const wasClaimed = user.premium_free_claimed === true;
      user.premium_free_claimed = false;
      global.db.setUser(targetNumber, user);

      if (wasClaimed) {
        return await message.reply(
          `✅ Flag de premium gratis reseteado para *${targetArg}*.\n` +
          `🎁 Ahora puede volver a reclamar su día de premium gratis desde la web.`
        );
      } else {
        return await message.reply(
          `ℹ️ El usuario *${targetArg}* ya tenía disponible el reclamo gratuito.\n` +
          `(No había reclamado antes)`
        );
      }
    }

    if (!['dar', 'give'].includes(action)) {
      return await message.reply(
        '📋 *Uso del comando .premium*\n\n' +
        '🔹 `.premium` — Ver tu estado\n' +
        '🔹 `.premium dar @usuario días` — Dar premium\n' +
        '🔹 `.premium list` — Lista de usuarios premium\n' +
        '🔹 `.premium migrar` — Migrar entradas a mixed\n' +
        '🔹 `.premium resetfree @usuario` — Resetear flag individual\n' +
        '🔹 `.premium resetfree all` — Resetear flags de todos ✨\n\n' +
        '📌 *Ejemplos:*\n' +
        '• `.premium dar pepe 30`\n' +
        '• `.premium resetfree @usuario`\n' +
        '• `.premium resetfree all`'
      );
    }

    if (!isOwner) {
      return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
    }

    if (args.length < 3) {
      return await message.reply('❌ Debes especificar a quién dar premium y la cantidad de días. Ejemplo: .premium dar pepe 30');
    }

    const targetArg = args[1];
    const days = parseInt(args[2], 10);

    if (isNaN(days) || days <= 0) {
      return await message.reply('❌ La cantidad de días debe ser un número entero positivo.');
    }

    let targetNumber = null;
    const mentions = Array.isArray(message.mentions) ? message.mentions : [];
    const normalizedTargetArg = targetArg.toString().trim().replace(/^@+/, '');
    if (mentions.length > 0) {
      targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
    } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
      targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
    } else {
      targetNumber = premium.findNumberByApodo(normalizedTargetArg);
    }

    if (!targetNumber) {
      return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
    }

    const result = premium.addPremium(targetNumber, days / 30, { source: 'free' });
    if (!result) {
      return await message.reply('❌ No se pudo otorgar premium. Intenta nuevamente.');
    }

    return await message.reply(
      `✅ Premium otorgado con éxito a *${targetArg}*.\n` +
      `📌 Fecha de inicio: ${premium.formatDateOnly(result.startedAt)}\n` +
      `⏳ Tiempo restante: ${premium.formatRemaining(result.remainingMs)}\n` +
      `\n★ Usa: .premium para ver los beneficios.`
    );
  } catch (error) {
    console.error('[Premium] Error en comando premium:', error);
    return await message.reply('❌ Ocurrió un error al procesar el comando premium.');
  }
};

handler.help = ['premium'];
handler.tags = ['owner'];
handler.command = /^premium$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;
