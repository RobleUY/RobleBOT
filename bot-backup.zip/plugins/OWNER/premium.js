const premium = require('../../premium');
const botConfig = require('../../config');

// ==========================================
// CONFIGURACIÓN DEL SORTEO DE PREMIUM
// ==========================================
// true  -> los usuarios que YA tienen premium activo también pueden entrar al sorteo
// false -> el sorteo solo toma en cuenta a usuarios que NO tienen premium activo
const SORTEO_PERMITIR_USUARIOS_PREMIUM = false;

// ==========================================
// HELPERS PARA EL SORTEO
// ==========================================

/**
 * Parsea una duración tipo "30d", "2w", "12h", "45m" (o un número plano, que se
 * interpreta como días) y devuelve el equivalente en días (puede ser decimal).
 */
function parseSorteoDuration(input) {
  if (!input) return null;
  const match = input.toString().trim().toLowerCase().match(/^(\d+(?:\.\d+)?)\s*(d|h|m|w)?$/);
  if (!match) return null;

  const value = parseFloat(match[1]);
  if (isNaN(value) || value <= 0) return null;

  const unit = match[2] || 'd';
  let days;
  switch (unit) {
    case 'h': days = value / 24; break;
    case 'm': days = value / (24 * 60); break;
    case 'w': days = value * 7; break;
    case 'd':
    default: days = value; break;
  }

  return { days, unit };
}

/** Fisher-Yates shuffle, no muta el array original. */
function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Un apodo "válido" es uno real, no vacío ni un placeholder tipo "sin apodo", ".", "-". */
function isApodoValido(apodo) {
  const ap = String(apodo || '').trim();
  if (!ap) return false;
  const lower = ap.toLowerCase();
  if (lower === 'sin apodo' || ap === '.' || ap === '-') return false;
  return true;
}

let handler = async (message, { text, args }) => {
  try {
    const senderJid = message.author || message.from || message.sender;
    const senderNumber = senderJid ? senderJid.split('@')[0].replace(/[^0-9]/g, '') : null;
    if (!senderNumber) {
      return await message.reply('❌ No se pudo identificar tu número.');
    }

    const isOwner = botConfig.isOwner(senderNumber) || botConfig.isOwner(`${senderNumber}@s.whatsapp.net`);

    if (!text || !args || args.length === 0) {
      const info = premium.getPremiumInfo(senderNumber);

      const beneficios =
        `👑 *Beneficios Premium*\n` +
        `⚡ Multiplicador *x2* de dinero en todos los comandos\n` +
        `⏱️ *50% menos* tiempo de espera en cooldowns\n` +
        `🏆 Rango máximo automático con premium comprado en *.rankup*\n` +
        `🐾 Autocuidado automático de mascotas\n` +
        `★ Símbolo especial *★* en tus respuestas`;

      const tienda =
        `\n\n🛒 *¿Querés adquirirlo?*\n` +
        `Compralo desde la tienda oficial:\n` +
        `https://roblebotpage.vercel.app/tienda.html\n\n` +
        `El pago es seguro vía PayPal y se activa automáticamente.`;

      if (info.active) {
        return await message.reply(
          `✨ *Eres usuario Premium.* ★\n\n` +
          `📌 *Inicio:* ${premium.formatDateOnly(info.startedAt)}\n` +
          `⏳ *Tiempo restante:* ${premium.formatRemaining(info.remainingMs)}\n\n` +
          beneficios + tienda
        );
      }

      return await message.reply(
        `❌ *No eres usuario Premium.*\n\n` +
        beneficios + tienda
      );
    }

    const action = args[0].toLowerCase();

    if (action === 'migrar' || action === 'migrate') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const result = premium.migratePremiumEntriesToMixed();
      return await message.reply(
        `✅ Migración completada.\n` +
        `📌 Entradas revisadas: ${result.totalEntries}\n` +
        `🔄 Actualizadas a mixed: ${result.migratedCount}`
      );
    }

    if (action === 'list' || action === 'lista') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const premiumUsers = premium.getPremiumList();
      if (!premiumUsers.length) {
        return await message.reply('📋 No hay usuarios premium activos en este momento.');
      }

      const lines = [];
      for (const entry of premiumUsers) {
        const user = global.db.getUser(entry.userId);
        const apodo = (user?.apodo || '').trim() || entry.userId;
        lines.push(`• ${apodo} — ${premium.formatRemaining(entry.remainingMs)}`);
      }

      return await message.reply(
        `📋 *Lista de usuarios premium activos*\n\n${lines.join('\n')}`
      );
    }

    if (['resetfree', 'reset-free', 'reset'].includes(action)) {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const targetArg = args[1] ? args[1].trim() : '';

      if (!targetArg) {
        return await message.reply(
          '❌ Debes especificar un apodo, mención o "all".\n\n' +
          'Ejemplos:\n' +
          '• `.premium resetfree pepe` (resetea el reclamo a un usuario)\n' +
          '• `.premium resetfree all` (resetea el reclamo a TODOS los usuarios)'
        );
      }

      if (targetArg.toLowerCase() === 'all' || targetArg.toLowerCase() === 'todos') {
        let count = 0;
        const allUsersRows = global.db._stmts.getAllUsers.all();
        for (const row of allUsersRows) {
          const user = global.db.getUser(row.id);
          if (user && (user.premium_free_claimed !== undefined && user.premium_free_claimed !== false && user.premium_free_claimed !== null)) {
            user.premium_free_claimed = false;
            global.db.setUser(row.id, user);
            count++;
          }
        }
        if (global.db && typeof global.db.saveNow === 'function') {
          global.db.saveNow();
        }
        return await message.reply(`✅ Se reseteó el estado de Premium gratuito a *${count}* usuario(s). Pueden volver a reclamarlo en la web (sus días premium actuales NO fueron modificados).`);
      }

      let targetNumber = null;
      const mentions = Array.isArray(message.mentions) ? message.mentions : [];
      const normalizedTargetArg = targetArg.replace(/^@+/, '');
      if (mentions.length > 0) {
        targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
      } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
        targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
      } else {
        targetNumber = premium.findNumberByApodo(normalizedTargetArg);
      }

      if (!targetNumber) {
        return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
      }

      const canonicalId = global.db?.getCanonicalId?.(targetNumber) || targetNumber;
      const user = global.db.getUser(canonicalId);
      if (!user) {
        return await message.reply(`❌ No se encontró la cuenta de *${targetArg}* en la base de datos.`);
      }

      user.premium_free_claimed = false;
      global.db.setUser(canonicalId, user);
      if (global.db && typeof global.db.saveNow === 'function') {
        global.db.saveNow();
      }

      return await message.reply(`✅ Se reseteó el estado de Premium gratuito para *${targetArg}*. Ahora puede volver a reclamar el día gratis en la web (sus días premium actuales NO fueron modificados).`);
    }

    if (['sortear', 'sorteo'].includes(action)) {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const cantidadArg = args[1];
      const duracionArg = args[2];

      if (!cantidadArg || !duracionArg) {
        return await message.reply(
          '❌ Debes especificar cantidad y duración.\n\n' +
          'Ejemplo: `.premium sortear 10 30d`\n' +
          '(Sortea 10 usuarios y les da 30 días de premium)\n\n' +
          'Unidades soportadas: `d` (días), `h` (horas), `m` (minutos), `w` (semanas). Sin unidad = días.'
        );
      }

      const cantidad = parseInt(cantidadArg, 10);
      if (isNaN(cantidad) || cantidad <= 0) {
        return await message.reply('❌ La cantidad de ganadores debe ser un número entero positivo.');
      }

      const duracion = parseSorteoDuration(duracionArg);
      if (!duracion) {
        return await message.reply('❌ Duración inválida. Ejemplos válidos: `30d`, `2w`, `12h`, `1440m`.');
      }

      // Reunir candidatos únicos con apodo válido (y, según configuración, sin premium activo)
      const rows = global.db._stmts.getAllUsers.all();
      const seen = new Set();
      const candidatos = [];

      for (const row of rows) {
        const canonicalId = global.db.getCanonicalId(row.id) || row.id;
        if (seen.has(canonicalId)) continue;
        seen.add(canonicalId);

        const user = global.db.getUser(canonicalId);
        if (!user) continue;
        if (!isApodoValido(user.apodo)) continue;

        if (!SORTEO_PERMITIR_USUARIOS_PREMIUM) {
          const info = premium.getPremiumInfo(canonicalId);
          if (info && info.active) continue;
        }

        candidatos.push({ id: canonicalId, apodo: String(user.apodo).trim() });
      }

      if (candidatos.length === 0) {
        return await message.reply('❌ No hay usuarios elegibles para el sorteo en este momento.');
      }

      const cantidadFinal = Math.min(cantidad, candidatos.length);
      const ganadores = shuffleArray(candidatos).slice(0, cantidadFinal);

      const lineas = [];
      for (const ganador of ganadores) {
        const result = premium.addPremium(ganador.id, duracion.days / 30, { source: 'sorteo' });
        if (result) {
          lineas.push(`• ${ganador.apodo} — ${premium.formatRemaining(result.remainingMs)}`);
        } else {
          lineas.push(`• ${ganador.apodo} — ⚠️ error al otorgar`);
        }
      }

      let aviso = '';
      if (cantidadFinal < cantidad) {
        aviso = `\n\n⚠️ Solo había *${candidatos.length}* usuario(s) elegible(s), se sortearon *${cantidadFinal}*.`;
      }

      return await message.reply(
        `🎉 *Sorteo de Premium realizado*\n` +
        `⏳ Duración otorgada: ${duracionArg}\n` +
        `👥 Ganadores: ${cantidadFinal}\n` +
        `${SORTEO_PERMITIR_USUARIOS_PREMIUM ? '🔓 Incluyó usuarios ya premium' : '🔒 Solo usuarios sin premium activo'}\n\n` +
        lineas.join('\n') +
        aviso
      );
    }

    if (!['dar', 'give'].includes(action)) {
      return await message.reply(
        'Uso:\n' +
        '.premium\n' +
        '.premium dar @usuario/apodo cantidad-de-días\n' +
        '.premium sortear cantidad duración (ej: .premium sortear 10 30d)\n' +
        '.premium resetfree apodo / all\n' +
        '.premium list\n' +
        '.premium migrar\n\n' +
        'Ejemplos:\n' +
        '• .premium dar pepe 30\n' +
        '• .premium sortear 10 30d\n' +
        '• .premium resetfree pepe\n' +
        '• .premium resetfree all'
      );
    }

    if (!isOwner) {
      return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
    }

    if (args.length < 3) {
      return await message.reply('❌ Debes especificar a quién dar premium y la cantidad de días. Ejemplo: .premium dar pepe 30');
    }

    const targetArg = args[1];
    const days = parseInt(args[2], 10);

    if (isNaN(days) || days <= 0) {
      return await message.reply('❌ La cantidad de días debe ser un número entero positivo.');
    }

    let targetNumber = null;
    const mentions = Array.isArray(message.mentions) ? message.mentions : [];
    const normalizedTargetArg = targetArg.toString().trim().replace(/^@+/, '');
    if (mentions.length > 0) {
      targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
    } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
      targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
    } else {
      targetNumber = premium.findNumberByApodo(normalizedTargetArg);
    }

    if (!targetNumber) {
      return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
    }

    const result = premium.addPremium(targetNumber, days / 30, { source: 'free' });
    if (!result) {
      return await message.reply('❌ No se pudo otorgar premium. Intenta nuevamente.');
    }

    return await message.reply(
      `✅ Premium otorgado con éxito a *${targetArg}*.\n` +
      `📌 Fecha de inicio: ${premium.formatDateOnly(result.startedAt)}\n` +
      `⏳ Tiempo restante: ${premium.formatRemaining(result.remainingMs)}\n` +
      `\n★ Usa: .premium para ver los beneficios.`
    );
  } catch (error) {
    console.error('[Premium] Error en comando premium:', error);
    return await message.reply('❌ Ocurrió un error al procesar el comando premium.');
  }
};

handler.help = ['premium'];
handler.tags = ['owner'];
handler.command = /^premium$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;