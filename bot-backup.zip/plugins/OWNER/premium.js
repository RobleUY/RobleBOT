const premium = require('../../premium');
const botConfig = require('../../config');

let handler = async (message, { text, args }) => {
  try {
    const senderJid = message.author || message.from || message.sender;
    const senderNumber = senderJid ? senderJid.split('@')[0].replace(/[^0-9]/g, '') : null;
    if (!senderNumber) {
      return await message.reply('❌ No se pudo identificar tu número.');
    }

    const isOwner = botConfig.isOwner(senderNumber) || botConfig.isOwner(`${senderNumber}@s.whatsapp.net`);

    if (!text || !args || args.length === 0) {
      const info = premium.getPremiumInfo(senderNumber);

      const beneficios =
        `👑 *Beneficios Premium*\n` +
        `⚡ Multiplicador *x2* de dinero en todos los comandos\n` +
        `⏱️ *50% menos* tiempo de espera en cooldowns\n` +
        `🏆 Rango máximo automático con premium comprado en *.rankup*\n` +
        `🐾 Autocuidado automático de mascotas\n` +
        `★ Símbolo especial *★* en tus respuestas`;

      const tienda =
        `\n\n🛒 *¿Querés adquirirlo?*\n` +
        `Compralo desde la tienda oficial:\n` +
        `https://roblebotpage.vercel.app/tienda.html\n\n` +
        `El pago es seguro vía PayPal y se activa automáticamente.`;

      if (info.active) {
        return await message.reply(
          `✨ *Eres usuario Premium.* ★\n\n` +
          `📌 *Inicio:* ${premium.formatDateOnly(info.startedAt)}\n` +
          `⏳ *Tiempo restante:* ${premium.formatRemaining(info.remainingMs)}\n\n` +
          beneficios + tienda
        );
      }

      return await message.reply(
        `❌ *No eres usuario Premium.*\n\n` +
        beneficios + tienda
      );
    }

    const action = args[0].toLowerCase();

    if (action === 'migrar' || action === 'migrate') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const result = premium.migratePremiumEntriesToMixed();
      return await message.reply(
        `✅ Migración completada.\n` +
        `📌 Entradas revisadas: ${result.totalEntries}\n` +
        `🔄 Actualizadas a mixed: ${result.migratedCount}`
      );
    }

    if (action === 'list' || action === 'lista') {
      if (!isOwner) {
        return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
      }

      const premiumUsers = premium.getPremiumList();
      if (!premiumUsers.length) {
        return await message.reply('📋 No hay usuarios premium activos en este momento.');
      }

      const lines = [];
      for (const entry of premiumUsers) {
        const user = global.db.getUser(entry.userId);
        const apodo = (user?.apodo || '').trim() || entry.userId;
        lines.push(`• ${apodo} — ${premium.formatRemaining(entry.remainingMs)}`);
      }

      return await message.reply(
        `📋 *Lista de usuarios premium activos*\n\n${lines.join('\n')}`
      );
    }

    if (!['dar', 'give'].includes(action)) {
      return await message.reply(
        'Uso:\n' +
        '.premium\n' +
        '.premium dar @usuario/apodo cantidad-de-meses\n' +
        '.premium list\n' +
        '.premium migrar\n\n' +
        'Ejemplo:\n' +
        '.premium dar pepe 1'
      );
    }

    if (!isOwner) {
      return await message.reply('❌ Este comando solo puede usarlo el owner del bot.');
    }

    if (args.length < 3) {
      return await message.reply('❌ Debes especificar a quién dar premium y la cantidad de meses. Ejemplo: .premium dar pepe 1');
    }

    const targetArg = args[1];
    const months = parseInt(args[2], 10);

    if (isNaN(months) || months <= 0) {
      return await message.reply('❌ La cantidad de meses debe ser un número entero positivo.');
    }

    let targetNumber = null;
    const mentions = Array.isArray(message.mentions) ? message.mentions : [];
    const normalizedTargetArg = targetArg.toString().trim().replace(/^@+/, '');
    if (mentions.length > 0) {
      targetNumber = mentions[0].split('@')[0].replace(/[^0-9]/g, '');
    } else if (/^\d+$/.test(normalizedTargetArg.replace(/\D/g, ''))) {
      targetNumber = normalizedTargetArg.replace(/[^0-9]/g, '');
    } else {
      targetNumber = premium.findNumberByApodo(normalizedTargetArg);
    }

    if (!targetNumber) {
      return await message.reply(`❌ No se encontró usuario con @ o apodo *${targetArg}*.`);
    }

    const result = premium.addPremium(targetNumber, months);
    if (!result) {
      return await message.reply('❌ No se pudo otorgar premium. Intenta nuevamente.');
    }

    return await message.reply(
      `✅ Premium otorgado con éxito a *${targetArg}*.\n` +
      `📌 Fecha de inicio: ${premium.formatDateOnly(result.startedAt)}\n` +
      `⏳ Tiempo restante: ${premium.formatRemaining(result.remainingMs)}\n` +
      `\n★ El usuario ahora recibe el doble de recompensas en .work .daily .hunt .mine`
    );
  } catch (error) {
    console.error('[Premium] Error en comando premium:', error);
    return await message.reply('❌ Ocurrió un error al procesar el comando premium.');
  }
};

handler.help = ['premium'];
handler.tags = ['owner'];
handler.command = /^premium$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;
