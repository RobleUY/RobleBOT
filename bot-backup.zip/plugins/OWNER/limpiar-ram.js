// Comando para liberar memoria RAM manualmente (solo owner)
let handler = async (message, { args }) => {
    try {
        // Obtener estadísticas antes de la limpieza
        const beforeUsage = process.memoryUsage();
        const beforeHeapMB = Math.round(beforeUsage.heapUsed / 1024 / 1024);
        const beforeRssMB = Math.round(beforeUsage.rss / 1024 / 1024);
        
        await message.reply(
            `🧹 *INICIANDO LIMPIEZA DE MEMORIA*\n\n` +
            `📊 *Estado actual:*\n` +
            `   • Heap: ${beforeHeapMB}MB\n` +
            `   • RSS: ${beforeRssMB}MB\n\n` +
            `⏳ Ejecutando limpieza...`
        );

        let cleanupReport = [];
        let totalFreed = 0;

        // 1. Limpiar caché de mensajes procesados
        if (global.processedMessageIds && global.processedMessageIds.size > 0) {
            const beforeSize = global.processedMessageIds.size;
            global.processedMessageIds.clear();
            cleanupReport.push(`🗑️ Caché de mensajes: ${beforeSize} entradas`);
        }

        // 2. Limpiar errores de Bad MAC
        if (global.badMacErrors && global.badMacErrors.size > 0) {
            const beforeSize = global.badMacErrors.size;
            global.badMacErrors.clear();
            cleanupReport.push(`🔧 Errores Bad MAC: ${beforeSize} entradas`);
        }

        // 3. Limpiar subbots desconectados
        if (global.subConns && Array.isArray(global.subConns)) {
            const beforeCount = global.subConns.length;
            global.subConns = global.subConns.filter(c => c && c.user);
            const afterCount = global.subConns.length;
            const cleaned = beforeCount - afterCount;
            if (cleaned > 0) {
                cleanupReport.push(`🤖 Subbots desconectados: ${cleaned} eliminados`);
            }
        }

        // 4. Limpiar caché de require (solo archivos del proyecto, no node_modules)
        let modulesCleaned = 0;
        Object.keys(require.cache).forEach((key) => {
            if (key.includes(__dirname) && 
                !key.includes('node_modules') && 
                !key.includes('main-session.db') &&
                !key.includes('database.js') && // No limpiar BD
                !key.includes('config.js')) {   // No limpiar config
                delete require.cache[key];
                modulesCleaned++;
            }
        });
        if (modulesCleaned > 0) {
            cleanupReport.push(`📦 Módulos en caché: ${modulesCleaned} limpiados`);
        }

        // 5. Limpiar datos temporales de la base de datos (si existen)
        if (global.db?.data) {
            // Limpiar actividad de grupos muy antigua (más de 30 días)
            if (global.db.data.groupActivity) {
                let oldEntriesCleaned = 0;
                const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
                
                for (const groupId in global.db.data.groupActivity) {
                    for (const userId in global.db.data.groupActivity[groupId]) {
                        if (userId === '__total') continue;
                        const activity = global.db.data.groupActivity[groupId][userId];
                        const lastActivity = (typeof activity === 'object') ? activity.last : activity;
                        
                        if (lastActivity && lastActivity < thirtyDaysAgo) {
                            delete global.db.data.groupActivity[groupId][userId];
                            oldEntriesCleaned++;
                        }
                    }
                }
                
                if (oldEntriesCleaned > 0) {
                    cleanupReport.push(`📅 Actividad antigua: ${oldEntriesCleaned} entradas`);
                    global.db.save();
                }
            }
        }

        // 6. Ejecutar Garbage Collection si está disponible
        if (global.gc) {
            const beforeGC = process.memoryUsage().heapUsed;
            global.gc();
            const afterGC = process.memoryUsage().heapUsed;
            const freedByGC = Math.round((beforeGC - afterGC) / 1024 / 1024);
            if (freedByGC > 0) {
                cleanupReport.push(`🗑️ Garbage Collection: ${freedByGC}MB liberados`);
                totalFreed += freedByGC;
            }
        } else {
            cleanupReport.push(`⚠️ GC no disponible (ejecuta con --expose-gc)`);
        }

        // 7. Forzar limpieza adicional del monitor de memoria
        if (global.memoryMonitor && typeof global.memoryMonitor.forceGC === 'function') {
            global.memoryMonitor.forceGC();
        }

        // Obtener estadísticas después de la limpieza
        await new Promise(resolve => setTimeout(resolve, 1000)); // Esperar un poco
        const afterUsage = process.memoryUsage();
        const afterHeapMB = Math.round(afterUsage.heapUsed / 1024 / 1024);
        const afterRssMB = Math.round(afterUsage.rss / 1024 / 1024);
        
        const heapFreed = beforeHeapMB - afterHeapMB;
        const rssFreed = beforeRssMB - afterRssMB;

        // Calcular uptime
        const uptimeMs = Date.now() - (global._botStartTime || Date.now());
        const uptimeHours = Math.floor(uptimeMs / (60 * 60 * 1000));
        const uptimeMinutes = Math.floor((uptimeMs % (60 * 60 * 1000)) / (60 * 1000));

        // Generar reporte final
        let finalReport = `✅ *LIMPIEZA COMPLETADA*\n\n`;
        
        finalReport += `📊 *Memoria liberada:*\n`;
        finalReport += `   • Heap: ${beforeHeapMB}MB → ${afterHeapMB}MB`;
        if (heapFreed > 0) {
            finalReport += ` (-${heapFreed}MB)`;
        }
        finalReport += `\n   • RSS: ${beforeRssMB}MB → ${afterRssMB}MB`;
        if (rssFreed > 0) {
            finalReport += ` (-${rssFreed}MB)`;
        }
        finalReport += `\n\n`;

        if (cleanupReport.length > 0) {
            finalReport += `🧹 *Elementos limpiados:*\n`;
            cleanupReport.forEach(item => {
                finalReport += `   • ${item}\n`;
            });
            finalReport += `\n`;
        }

        finalReport += `⏱️ *Sistema:*\n`;
        finalReport += `   • Uptime: ${uptimeHours}h ${uptimeMinutes}m\n`;
        
        // Información de subbots activos
        if (global.subConns) {
            const activeSubbots = global.subConns.filter(c => c && c.user).length;
            finalReport += `   • Subbots activos: ${activeSubbots}\n`;
        }

        // Información de base de datos
        if (global.db?.data) {
            const users = Object.keys(global.db.data.users || {}).length;
            const groups = Object.keys(global.db.data.groups || {}).length;
            finalReport += `   • BD: ${users} usuarios, ${groups} grupos\n`;
        }

        finalReport += `\n💡 *Tip:* Usa este comando cuando notes que el bot está lento o usando mucha RAM.`;

        await message.reply(finalReport);

        // Log en consola para el administrador
        console.log(`[LIMPIEZA-RAM] Ejecutada por owner - Heap: ${beforeHeapMB}MB → ${afterHeapMB}MB`);

    } catch (error) {
        console.error('[limpiar-ram] Error:', error.message);
        await message.reply(
            `❌ *Error durante la limpieza:*\n\n` +
            `${error.message}\n\n` +
            `Intenta nuevamente en unos segundos.`
        );
    }
};

handler.help = ['limpiarram', 'cleanram', 'gc'];
handler.tags = ['owner'];
handler.command = /^(limpiarram|cleanram|gc|liberarram|freeram)$/i;
handler.owner = true;

module.exports = handler;