// plugins/owner/restart.js
const { exec } = require('child_process');
const config = require('../../config.js'); // Ajusta la ruta si tu config.js está en otro nivel

let handler = async (message, { conn }) => {
    const sender = message.sender || message.key.participant || message.key.remoteJid;

    // Limpiamos el número igual que hace config.js internamente
    const cleanNumber = sender.split('@')[0].split(':')[0].replace(/\D/g, '');

    const isAdminBot = config.adminsbot.includes(cleanNumber) || config.adminsbot.includes(sender);

    if (!isAdminBot) {
        return await message.reply(
            '⛔ *Acceso denegado*\n\n' +
            'Este comando solo puede ser usado por administradores autorizados del bot.\n' +
            'Si crees que esto es un error, contacta al propietario del bot.'
        );
    }

    await message.reply('🔄 *Reiniciando servidor...*\nEl bot volverá a estar activo en unos segundos.');

    // Llamamos a la función de cierre forzado si existe en el global o salimos directamente
    if (global.forceRestart) {
        global.forceRestart();
    } else {
        process.exit(1); // Esto dispara el reinicio del gestor de procesos (PM2)
    }
};

handler.help = ['restart', 'reiniciar'];
handler.tags = ['owner'];
handler.command = /^(restart|reiniciar)$/i;

// Ya NO usamos handler.owner = true;
// El control de acceso se hace manualmente arriba usando config.adminsbot

module.exports = handler;