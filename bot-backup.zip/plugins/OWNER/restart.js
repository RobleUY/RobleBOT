// plugins/owner/restart.js
const { exec } = require('child_process');

let handler = async (message, { conn }) => {
    await message.reply('🔄 *Reiniciando servidor...*\nEl bot volverá a estar activo en unos segundos.');
    
    // Llamamos a la función de cierre forzado si existe en el global o salimos directamente
    if (global.forceRestart) {
        global.forceRestart();
    } else {
        process.exit(1); // Esto dispara el reinicio del gestor de procesos (PM2)
    }
};

handler.help = ['restart', 'reiniciar', 'reinicio'];
handler.tags = ['owner'];
handler.command = /^(restart|reiniciar|reinicio)$/i;
handler.adminbot = true;

module.exports = handler;