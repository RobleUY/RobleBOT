// plugins/owner/reconnect.js
const fs = require('fs');
const path = require('path');
const { connectSubBot } = require('../SUBBOTS/subbot-serbot');

let handler = async (message, { args, conn }) => {
    const param = args[0];
    if (!param) return message.reply('❌ Debes ingresar un número de sub-bot (ej. .reconnect 1234) o "all".');

    if (param.toLowerCase() === 'all') {
        await message.reply('🔄 Intentando reconectar todos los sub-bots...');
        // Lógica simplificada de reconexión masiva
        const sessionsDir = path.resolve(__dirname, '../SUBBOTS/sesiones');
        const files = fs.readdirSync(sessionsDir).filter(f => f.endsWith('.db'));
        
        let count = 0;
        for (const file of files) {
            const num = file.replace('.db', '');
            const isActive = global.subConns.find(c => c._subNum == num);
            if (!isActive) {
                await connectSubBot({ num, conn });
                count++;
            }
        }
        return message.reply(`✅ Se han procesado ${count} intentos de reconexión.`);
    } else {
        const num = param;
        const isActive = global.subConns.find(c => c._subNum == num);
        if (isActive) return message.reply(`⚠️ El sub-bot #${num} ya está conectado.`);
        
        await message.reply(`🔄 Intentando reconectar sub-bot #${num}...`);
        await connectSubBot({ num, conn });
        await message.reply(`✅ Intento de conexión para #${num} finalizado.`);
    }
};

handler.help = ['reconnect', 'reconectar', 'reconect'];
handler.tags = ['owner'];
handler.command = /^(reconnect|reconectar|reconect)$/i;
handler.owner = true;

module.exports = handler;