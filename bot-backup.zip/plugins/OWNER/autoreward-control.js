// Control del sistema de recompensas automáticas (solo owner)
let handler = async (message, { args, text }) => {
    try {
        if (!global.autoRewardSystem) {
            return await message.reply('❌ El sistema de recompensas automáticas no está inicializado.');
        }

        const action = args[0]?.toLowerCase();

        if (!action) {
            const stats = global.autoRewardSystem.getStats();
            const nextRewardMs = stats.nextRewardIn;
            const nextRewardSeconds = Math.floor(nextRewardMs / 1000);

            return await message.reply(
                `╔═══════════════════════════╗\n` +
                `║  🔧 *CONTROL DE RECOMPENSAS*  ║\n` +
                `╚═══════════════════════════╝\n\n` +
                `📊 *Estado Actual:*\n` +
                `   • Uptime: ${stats.uptimeFormatted}\n` +
                `   • Recompensas dadas: ${stats.rewardsGiven}\n` +
                `   • Próxima en: ${nextRewardSeconds}s\n` +
                `   • Monto: ${stats.rewardAmount.toLocaleString()} monedas/min\n\n` +
                `🛠️ *Comandos disponibles:*\n` +
                `   • *.autorewardctl forzar* - Forzar entrega inmediata\n` +
                `   • *.autorewardctl stats* - Ver estadísticas\n` +
                `   • *.autorewardctl reiniciar* - Reiniciar contador\n\n` +
                `_Solo el owner puede usar estos comandos._`
            );
        }

        switch (action) {
            case 'forzar':
            case 'force':
            case 'now':
                await message.reply('⏳ Forzando entrega de recompensas...');
                await global.autoRewardSystem.giveRewardsToAllUsers();
                global.autoRewardSystem.rewardsGiven++;
                return await message.reply('✅ Recompensas entregadas manualmente.');

            case 'stats':
            case 'estadisticas':
                const stats = global.autoRewardSystem.getStats();
                return await message.reply(
                    `📊 *Estadísticas del Sistema:*\n\n` +
                    `⏰ Uptime: ${stats.uptimeFormatted}\n` +
                    `🎁 Recompensas entregadas: ${stats.rewardsGiven}\n` +
                    `💰 Monto por recompensa: ${stats.rewardAmount.toLocaleString()}\n` +
                    `⏱️ Intervalo: ${stats.rewardInterval / 1000} segundos (1 minuto)\n` +
                    `📅 Última recompensa: ${stats.lastRewardTime > 0 ? new Date(stats.lastRewardTime).toLocaleString() : 'Ninguna'}\n` +
                    `⏳ Próxima recompensa: ${Math.floor(stats.nextRewardIn / 1000)}s`
                );

            case 'reiniciar':
            case 'reset':
                global.autoRewardSystem.rewardsGiven = 0;
                global.autoRewardSystem.lastRewardTime = 0;
                global.autoRewardSystem.startTime = Date.now();
                return await message.reply('✅ Sistema de recompensas reiniciado. El contador vuelve a 0.');

            case 'parar':
            case 'stop':
                global.autoRewardSystem.stop();
                return await message.reply('⏸️ Sistema de recompensas detenido.');

            case 'iniciar':
            case 'start':
                global.autoRewardSystem.start();
                return await message.reply('▶️ Sistema de recompensas iniciado.');

            default:
                return await message.reply(
                    `❌ Acción no reconocida.\n\n` +
                    `Usa: *.autorewardctl* para ver comandos disponibles.`
                );
        }

    } catch (error) {
        console.error('[autorewardctl] Error:', error.message);
        return await message.reply('❌ Error al controlar el sistema de recompensas.');
    }
};

handler.help = ['autorewardctl'];
handler.tags = ['owner'];
handler.command = /^(autorewardctl|rewardctl|controlreward)$/i;
handler.owner = true;

module.exports = handler;
