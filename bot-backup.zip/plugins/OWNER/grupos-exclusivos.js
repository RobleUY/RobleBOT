const config = require('../../config.js');

/**
 * Comando para gestionar grupos exclusivos del bot principal
 * .exclusivo add - Agregar el grupo actual como exclusivo
 * .exclusivo remove - Remover el grupo actual de exclusivos
 * .exclusivo list - Ver lista de grupos exclusivos
 */

let handler = async (message, { args, conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!args || args.length === 0) {
            const helpText = 
                `🏠 *GRUPOS EXCLUSIVOS*\n\n` +
                `Los grupos exclusivos son aquellos donde *solo el bot principal* puede responder.\n` +
                `Los subbots ignorarán todos los mensajes en estos grupos.\n\n` +
                `📋 *Comandos:*\n` +
                `• .exclusivo add - Agregar este grupo como exclusivo\n` +
                `• .exclusivo remove - Quitar este grupo de exclusivos\n` +
                `• .exclusivo list - Ver lista de grupos exclusivos\n\n` +
                `⚠️ Solo el owner puede usar este comando.`;
            
            return await message.reply(helpText);
        }

        const action = args[0].toLowerCase();

        if (action === 'list') {
            const groups = config.exclusiveGroups || [];
            
            if (groups.length === 0) {
                return await message.reply('📭 No hay grupos exclusivos configurados.');
            }

            let texto = `🏠 *GRUPOS EXCLUSIVOS* (${groups.length})\n\n`;
            
            for (const groupJid of groups) {
                try {
                    const metadata = await conn.groupMetadata(groupJid);
                    const groupName = metadata.subject || 'Sin nombre';
                    const isCurrentGroup = groupJid === chatId ? ' ← *Este grupo*' : '';
                    texto += `• ${groupName}${isCurrentGroup}\n`;
                    texto += `  _${groupJid}_\n\n`;
                } catch (e) {
                    texto += `• Grupo desconocido\n`;
                    texto += `  _${groupJid}_\n\n`;
                }
            }

            return await message.reply(texto);
        }

        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        if (action === 'add') {
            if (config.isExclusiveGroup(chatId)) {
                return await message.reply('ℹ️ Este grupo ya está en la lista de grupos exclusivos.');
            }

            config.addExclusiveGroup(chatId);

            const groupMetadata = await conn.groupMetadata(chatId);
            const groupName = groupMetadata.subject || 'Sin nombre';

            await message.reply(
                `✅ *Grupo agregado a exclusivos*\n\n` +
                `📝 Grupo: ${groupName}\n` +
                `🆔 ID: ${chatId}\n\n` +
                `🤖 A partir de ahora, solo el bot principal responderá en este grupo.\n` +
                `Los subbots ignorarán todos los mensajes aquí.\n\n` +
                `⚠️ *NOTA:* Este cambio es temporal. Para hacerlo permanente, edita el archivo \`config.js\` y agrega el grupo manualmente.`
            );

        } else if (action === 'remove') {
            if (!config.isExclusiveGroup(chatId)) {
                return await message.reply('ℹ️ Este grupo no está en la lista de grupos exclusivos.');
            }

            config.removeExclusiveGroup(chatId);

            const groupMetadata = await conn.groupMetadata(chatId);
            const groupName = groupMetadata.subject || 'Sin nombre';

            await message.reply(
                `✅ *Grupo removido de exclusivos*\n\n` +
                `📝 Grupo: ${groupName}\n` +
                `🆔 ID: ${chatId}\n\n` +
                `🤖 Ahora todos los bots (principal y subbots) pueden responder en este grupo.\n\n` +
                `⚠️ *NOTA:* Este cambio es temporal. Para hacerlo permanente, edita el archivo \`config.js\` y remueve el grupo manualmente.`
            );

        } else {
            await message.reply('⚠️ Acción no válida. Usa: add, remove o list');
        }

    } catch (error) {
        console.error('Error en comando exclusivo:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['exclusivo'];
handler.tags = ['owner'];
handler.command = /^(exclusivo|exclusive)$/i;
handler.owner = true;

module.exports = handler;
