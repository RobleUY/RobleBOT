// plugins/OWNER/ramstatus.js
const config = require('../../config.js');
const { groupMetadataCache, trimGroupCache } = require('../../lib/groupCache');
const { tempCleaner } = require('../../tempCleaner');

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    parts.push(`${s}s`);
    return parts.join(' ');
}

let handler = async (message, { conn, args }) => {
    const sender = message.sender || message.key?.participant || message.key?.remoteJid;
    const cleanNumber = (sender || '').split('@')[0].split(':')[0].replace(/\D/g, '');

    const isAdminBot = config.adminsbot.includes(cleanNumber) || config.adminsbot.includes(sender);

    if (!isAdminBot) {
        return await message.reply(
            '⛔ *Acceso denegado*\n\n' +
            'Este comando solo puede ser usado por los propietarios/administradores del bot.'
        );
    }

    const action = (args[0] || '').toLowerCase();

    // Opción para forzar limpieza manual inmediata
    if (action === 'gc' || action === 'limpiar' || action === 'clean') {
        const preMem = process.memoryUsage();
        const preRss = Math.round(preMem.rss / (1024 * 1024));

        let trimmedGroups = 0;
        try {
            trimmedGroups = trimGroupCache(100);
        } catch (_) {}

        let tempResult = { cleaned: 0 };
        try {
            tempResult = await tempCleaner.cleanTempFiles();
        } catch (_) {}

        let gcExecuted = false;
        if (typeof global.gc === 'function') {
            try {
                global.gc();
                gcExecuted = true;
            } catch (_) {}
        }

        const postMem = process.memoryUsage();
        const postRss = Math.round(postMem.rss / (1024 * 1024));
        const diff = preRss - postRss;

        return await message.reply(
            `🧹 *Limpieza de Memoria Ejecutada*\n\n` +
            `• *RAM previa:* ${preRss} MB\n` +
            `• *RAM actual:* ${postRss} MB\n` +
            `• *RAM liberada:* ${diff > 0 ? diff : 0} MB\n` +
            `• *GC ejecutado:* ${gcExecuted ? '✅ Sí' : '❌ No (sin --expose-gc)'}\n` +
            `• *Grupos recortados:* ${trimmedGroups}\n` +
            `• *Temporales eliminados:* ${tempResult.cleaned || 0}`
        );
    }

    // Reporte de estado actual
    const mem = process.memoryUsage();
    const rssMB = Math.round(mem.rss / (1024 * 1024));
    const heapUsedMB = Math.round(mem.heapUsed / (1024 * 1024));
    const heapTotalMB = Math.round(mem.heapTotal / (1024 * 1024));
    const externalMB = Math.round(mem.external / (1024 * 1024));

    const totalVpsMB = 3072; // HidenCloud 3GB
    const ramPercent = ((rssMB / totalVpsMB) * 100).toFixed(1);

    const activeSubbots = Array.isArray(global.subConns)
        ? global.subConns.filter(c => c && c.user).length
        : 0;

    const cachedGroupsCount = groupMetadataCache?.size || 0;
    const uptimeStr = formatUptime(process.uptime());

    const ramStatusText = rssMB >= 2200
        ? '🚨 *CRÍTICO* (Reinicio inminente en 2200 MB)'
        : rssMB >= 1800
        ? '⚠️ *ALTO* (Auto-limpieza y GC activos)'
        : rssMB >= 1500
        ? '🟡 *MODERADO* (GC preventivo activo)'
        : '🟢 *ESTABLE*';

    const text =
        `📊 *ESTADO DEL SERVIDOR Y MEMORIA RAM*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `• *Estado RAM:* ${ramStatusText}\n` +
        `• *Consumo RSS:* *${rssMB} MB* / ${totalVpsMB} MB (~${ramPercent}% VPS)\n` +
        `• *Heap Usado:* ${heapUsedMB} MB / ${heapTotalMB} MB\n` +
        `• *External / Buffers:* ${externalMB} MB\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🤖 *Subbots conectados:* ${activeSubbots} activos\n` +
        `👥 *Grupos en caché:* ${cachedGroupsCount} grupos\n` +
        `🛡️ *Límite Watchdog:* 2200 MB (reinicio seguro)\n` +
        `⏱️ *Tiempo activo:* ${uptimeStr}\n` +
        `🧹 *Soporte GC:* ${typeof global.gc === 'function' ? '✅ Activo' : '❌ Inactivo'}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `💡 *Consejo:* Usa *.ramstatus gc* para liberar RAM manualmente si es necesario.`;

    await message.reply(text);
};

handler.help = ['ramstatus', 'ram', 'memoria'];
handler.tags = ['owner'];
handler.command = /^(ramstatus|ram|memoria)$/i;

module.exports = handler;
