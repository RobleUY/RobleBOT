// Comando para ver el estado actual de la memoria (solo owner)
let handler = async (message, { args }) => {
    try {
        const usage = process.memoryUsage();
        const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
        const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
        const rssMB = Math.round(usage.rss / 1024 / 1024);
        const externalMB = Math.round(usage.external / 1024 / 1024);

        // Calcular uptime
        const uptimeMs = Date.now() - (global._botStartTime || Date.now());
        const uptimeHours = Math.floor(uptimeMs / (60 * 60 * 1000));
        const uptimeMinutes = Math.floor((uptimeMs % (60 * 60 * 1000)) / (60 * 1000));

        // Obtener estadísticas del monitor de memoria si está disponible
        let memoryStats = null;
        if (global.memoryMonitor && typeof global.memoryMonitor.getStats === 'function') {
            memoryStats = global.memoryMonitor.getStats();
        }

        // Determinar el estado de la memoria
        let status = '🟢 NORMAL';
        let statusColor = '🟢';
        if (heapUsedMB > 600) {
            status = '🔴 CRÍTICO';
            statusColor = '🔴';
        } else if (heapUsedMB > 400) {
            status = '🟡 MODERADO';
            statusColor = '🟡';
        }

        let report = `${statusColor} *ESTADO DE MEMORIA*\n\n`;
        
        report += `📊 *Uso actual:*\n`;
        report += `   • Estado: ${status}\n`;
        report += `   • Heap: ${heapUsedMB}MB / ${heapTotalMB}MB\n`;
        report += `   • RSS: ${rssMB}MB\n`;
        report += `   • External: ${externalMB}MB\n`;
        
        if (memoryStats) {
            report += `   • Pico máximo: ${memoryStats.peak}MB\n`;
        }
        
        report += `\n⏱️ *Sistema:*\n`;
        report += `   • Uptime: ${uptimeHours}h ${uptimeMinutes}m\n`;

        // Información de subbots
        if (global.subConns) {
            const totalSubbots = global.subConns.length;
            const activeSubbots = global.subConns.filter(c => c && c.user).length;
            const disconnectedSubbots = totalSubbots - activeSubbots;
            report += `   • Subbots: ${activeSubbots} activos`;
            if (disconnectedSubbots > 0) {
                report += ` (${disconnectedSubbots} desconectados)`;
            }
            report += `\n`;
        }

        // Información de base de datos
        if (global.db?.data) {
            const users = Object.keys(global.db.data.users || {}).length;
            const groups = Object.keys(global.db.data.groups || {}).length;
            report += `   • BD: ${users} usuarios, ${groups} grupos\n`;
        }

        // Información de cachés
        report += `\n🗂️ *Cachés:*\n`;
        
        if (global.processedMessageIds) {
            report += `   • Mensajes procesados: ${global.processedMessageIds.size}\n`;
        }
        
        if (global.badMacErrors) {
            report += `   • Errores Bad MAC: ${global.badMacErrors.size}\n`;
        }

        const modulesCached = Object.keys(require.cache).filter(key => 
            key.includes(__dirname) && !key.includes('node_modules')
        ).length;
        report += `   • Módulos en caché: ${modulesCached}\n`;

        // Recomendaciones
        report += `\n💡 *Recomendaciones:*\n`;
        
        if (heapUsedMB > 600) {
            report += `   🔴 Memoria crítica - Ejecuta *.limpiarram* AHORA\n`;
            report += `   🔴 Considera reiniciar el bot pronto\n`;
        } else if (heapUsedMB > 400) {
            report += `   🟡 Memoria moderada - Ejecuta *.limpiarram* pronto\n`;
        } else {
            report += `   🟢 Memoria en buen estado\n`;
        }

        // Información sobre garbage collection
        if (global.gc) {
            report += `   ✅ Garbage Collection disponible\n`;
        } else {
            report += `   ⚠️ GC no disponible (ejecuta con --expose-gc)\n`;
        }

        report += `\n🛠️ *Comandos útiles:*\n`;
        report += `   • *.limpiarram* - Liberar memoria\n`;
        report += `   • *.memoria* - Ver este estado\n`;

        await message.reply(report);

        // Log en consola
        console.log(`[MEMORIA] Consultado por owner - Heap: ${heapUsedMB}MB, RSS: ${rssMB}MB, Estado: ${status}`);

    } catch (error) {
        console.error('[memoria] Error:', error.message);
        await message.reply(
            `❌ *Error al obtener información de memoria:*\n\n` +
            `${error.message}`
        );
    }
};

handler.help = ['memoria', 'memory', 'ram'];
handler.tags = ['owner'];
handler.command = /^(memoria|memory|ram|memstatus)$/i;
handler.owner = true;

module.exports = handler;