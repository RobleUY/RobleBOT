const axios = require('axios');

// ⚙️ Configuración de timeouts
const TIMEOUT_MS = 15000; // 15 segundos por API

// 🎯 Función para verificar una API individual
async function checkAPI(url, method = 'GET') {
    try {
        const response = await axios({
            method,
            url,
            timeout: TIMEOUT_MS,
            validateStatus: (status) => status < 500 // Considera OK si no es error 5xx
        });
        
        // Verificar si la respuesta tiene el formato esperado
        if (response.data && (response.data.status || response.status === 200)) {
            return true;
        }
        return false;
    } catch (error) {
        return false;
    }
}

// 🔍 Función para verificar servicios con múltiples APIs (usa la primera disponible)
async function checkService(apis) {
    for (const api of apis) {
        const result = await checkAPI(api);
        if (result) return true; // Si al menos una API funciona, el servicio está OK
    }
    return false; // Ninguna API funcionó
}

// 📊 Handler principal
let handler = async (message, { conn }) => {
    try {
        // Mensaje inicial
        await message.reply('🔄 *Verificando estado de las APIs...*\n_Esto puede tardar unos segundos..._');

        const statusEmoji = {
            true: '✅',
            false: '❌'
        };

        // 🎬 YOUTUBE
        const youtubeVideoApis = [
            'https://robleapi.vercel.app/download/ytmp4?url=https://youtu.be/dQw4w9WgXcQ'
        ];
        const youtubeAudioApis = [
            'https://robleapi.vercel.app/download/ytmp3?url=https://youtu.be/dQw4w9WgXcQ'
        ];

        // 🎵 SPOTIFY
        const spotifySearchApis = [
            'https://www.sankavollerei.com/search/spotify?apikey=planaai&q=test',
            'https://delirius-apiofc.vercel.app/search/spotify?q=test&limit=20'
        ];
        const spotifyDownloadApis = [
            'https://delirius-apiofc.vercel.app/download/spotifydlv2?url=https://open.spotify.com/track/3n3Ppam7vgaVa1iaRUc9Lp',
            'https://delirius-apiofc.vercel.app/download/spotifydl?url=https://open.spotify.com/track/3n3Ppam7vgaVa1iaRUc9Lp'
        ];

        // 🍎 APPLE MUSIC
        const appleMusicApis = [
            'https://delirius-apiofc.vercel.app/search/applemusic?text=test',
            'https://delirius-apiofc.vercel.app/download/applemusicdl?url=https://music.apple.com/us/album/test'
        ];

        // 🎬 TIKTOK
        const tiktokApis = [
            'https://delirius-apiofc.vercel.app/search/tiktoksearch?query=test'
        ];

        // 📘 FACEBOOK
        const facebookApis = [
            'https://www.sankavollerei.com/download/facebook?apikey=planaai&url=https://www.facebook.com/test'
        ];

        // 📸 INSTAGRAM
        const instagramApis = [
            'https://delirius-apiofc.vercel.app/download/instagram?url=https://www.instagram.com/p/test'
        ];

        // 🧵 THREADS
        const threadsApis = [
            'https://delirius-apiofc.vercel.app/download/threads?url=https://www.threads.net/test'
        ];

        // 🐦 TWITTER
        const twitterApis = [
            'https://delirius-apiofc.vercel.app/download/twitterdl?url=https://x.com/test/status/123'
        ];

        // 🖼️ PINTEREST
        const pinterestApis = [
            'https://delirius-apiofc.vercel.app/search/pinterest?text=test'
        ];

        // 📦 APK
        const apkApis = [
            'https://delirius-apiofc.vercel.app/download/apk?query=whatsapp'
        ];

        // 🖼️ GOOGLE IMAGES
        const googleImagesApis = (process.env.GOOGLE_SEARCH_API_KEY || process.env.GOOGLE_API_KEY) ? [
            `https://www.googleapis.com/customsearch/v1?q=test&cx=${encodeURIComponent(process.env.GOOGLE_SEARCH_ENGINE_ID || process.env.GOOGLE_CX || '')}&key=${encodeURIComponent(process.env.GOOGLE_SEARCH_API_KEY || process.env.GOOGLE_API_KEY || '')}&searchType=image&num=1`
        ] : [];

        // 🔄 Ejecutar verificaciones en paralelo para mayor velocidad
        const [
            youtubeVideoStatus,
            youtubeAudioStatus,
            spotifySearchStatus,
            spotifyDownloadStatus,
            appleMusicStatus,
            tiktokStatus,
            facebookStatus,
            instagramStatus,
            threadsStatus,
            twitterStatus,
            pinterestStatus,
            apkStatus,
            googleImagesStatus
        ] = await Promise.all([
            checkService(youtubeVideoApis),
            checkService(youtubeAudioApis),
            checkService(spotifySearchApis),
            checkService(spotifyDownloadApis),
            checkService(appleMusicApis),
            checkService(tiktokApis),
            checkService(facebookApis),
            checkService(instagramApis),
            checkService(threadsApis),
            checkService(twitterApis),
            checkService(pinterestApis),
            checkService(apkApis),
            checkService(googleImagesApis)
        ]);

        // Calcular estado combinado de audios (YouTube + Spotify + Apple Music)
        const audioStatus = youtubeAudioStatus || spotifyDownloadStatus || appleMusicStatus;

        // 📝 Construir mensaje de respuesta
        const statusMessage = 
            `📊 *ESTADO DE LAS APIs*\n` +
            `_Última actualización: ${new Date().toLocaleString('es-ES', { timeZone: 'America/Montevideo' })}_\n\n` +
            `━━━━━━━━━━━━━━━━━━\n\n` +
            
            `🎬 *DESCARGAS*\n` +
            `├ Videos: ${statusEmoji[youtubeVideoStatus]}\n` +
            `└ Audios: ${statusEmoji[audioStatus]}\n` +
            `   └─ YouTube: ${statusEmoji[youtubeAudioStatus]}\n` +
            `   └─ Spotify: ${statusEmoji[spotifyDownloadStatus]}\n` +
            `   └─ Apple Music: ${statusEmoji[appleMusicStatus]}\n\n` +
            
            `📱 *REDES SOCIALES*\n` +
            `├ TikTok: ${statusEmoji[tiktokStatus]}\n` +
            `├ Facebook: ${statusEmoji[facebookStatus]}\n` +
            `├ Instagram: ${statusEmoji[instagramStatus]}\n` +
            `├ Threads: ${statusEmoji[threadsStatus]}\n` +
            `└ Twitter/X: ${statusEmoji[twitterStatus]}\n\n` +
            
            `🖼️ *IMÁGENES*\n` +
            `├ Pinterest: ${statusEmoji[pinterestStatus]}\n` +
            `└ Google Images: ${statusEmoji[googleImagesStatus]}\n\n` +
            
            `📦 *OTROS*\n` +
            `└ APK Download: ${statusEmoji[apkStatus]}\n\n` +
            
            `━━━━━━━━━━━━━━━━━━\n\n` +
            `💡 *Leyenda:*\n` +
            `✅ = Funcionando\n` +
            `❌ = No disponible\n\n` +
            `_Nota: Si un servicio está caído, puede ser temporal. Intenta de nuevo en unos minutos._`;

        await message.reply(statusMessage);

    } catch (error) {
        console.error('[API STATUS] Error general:', error.message);
        await message.reply('❌ Ocurrió un error al verificar el estado de las APIs. Intenta de nuevo más tarde.');
    }
};

// Configuración del comando
handler.help = ['apistatus', 'statusapi', 'apis'];
handler.tags = ['info', 'tools'];
handler.command = /^(apistatus|statusapi|statusapis|apisstatus|apis)$/i;

module.exports = handler;