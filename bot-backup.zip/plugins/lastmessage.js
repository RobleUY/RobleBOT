/**
 * Plugin: lastmessage / lastmensaje / ultimomsg
 * Muestra el último mensaje asdregistrado de quien ejecuta el comando
 * o del usuario mencionado en el grupo.
 */

'use strict';

const chatHistory = require('../chatHistory');

const normalizeNumber = (jid) =>
    String(jid || '')
        .split('@')[0]
        .split(':')[0]
        .replace(/[^0-9]/g, '')
        .trim();

const formatElapsed = (timestamp) => {
    if (!timestamp || typeof timestamp !== 'number') return 'tiempo desconocido';

    const diffMs = Date.now() - timestamp;
    if (diffMs < 0) return 'en el futuro';

    const seconds = Math.floor(diffMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `hace ${days} día${days === 1 ? '' : 's'}`;
    if (hours > 0) return `hace ${hours} hora${hours === 1 ? '' : 's'}`;
    if (minutes > 0) return `hace ${minutes} minuto${minutes === 1 ? '' : 's'}`;
    if (seconds > 0) return `hace ${seconds} segundo${seconds === 1 ? '' : 's'}`;
    return 'justo ahora';
};

let handler = async (message, { conn }) => {
    try {
        const chatId = message.from;
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        if (!chatHistory || !chatHistory.isReady) {
            return await message.reply('❌ El historial de chat no está disponible aún.');
        }

        const mentionedJid = Array.isArray(message.mentions) && message.mentions.length > 0
            ? message.mentions[0]
            : null;

        const targetJid = mentionedJid || message.key?.participant || message.sender || message.author || message.key?.remoteJid;
        const targetId  = normalizeNumber(targetJid);

        if (!targetId) {
            return await message.reply('❌ No pude determinar el usuario para consultar el último mensaje.');
        }

        const histData = chatHistory.getUserHistory(chatId, targetId);
        if (!histData || !histData.lastMsgTs) {
            const targetTag = mentionedJid ? `@${normalizeNumber(mentionedJid)}` : 'Vos';
            return await message.reply(`📭 ${targetTag} no tiene mensajes registrados en este grupo.`);
        }

        const history = String(histData.history || '').trim();
        const lastLine = history
            ? history.split('\n').filter(Boolean).pop() || history
            : '';

        const targetTag = mentionedJid ? `@${normalizeNumber(mentionedJid)}` : 'Tu último mensaje';
        const elapsed = formatElapsed(histData.lastMsgTs);

        let text = `📌 *Último mensaje de ${mentionedJid ? targetTag : 'vos'}*\n`;
        text += `🕐 ${elapsed}\n`;
        text += `💬 ${lastLine || '_Sin contenido registrado_'}`;

        const mentions = mentionedJid ? [mentionedJid] : [];
        await message.reply(text, { mentions });

    } catch (error) {
        console.error('[LASTMESSAGE] Error:', error);
        await message.reply('⚠️ Ocurrió un error al obtener el último mensaje.');
    }
};

handler.help = ['lastmessage', 'lastmensaje', 'ultimomsg'];
handler.tags = ['grupos', 'info'];
handler.command = /^(lastmessage|lastmensaje|ultimomsg)$/i;
handler.group = true;

module.exports = handler;
