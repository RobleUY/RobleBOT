const db = require('../database.js'); // Ajusta la ruta según tu estructura

let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        let targetJid = senderJid; // Por defecto, mostrar el perfil propio
        let targetNumber = senderNumber;
        let isOwnProfile = true;
        
        // Obtener las menciones directamente del objeto message
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            // Si hay menciones, mostrar el perfil del usuario mencionado
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0];
            isOwnProfile = false;
        }
        
        // Obtener datos del usuario objetivo
        const userData = db.getUser(targetNumber);
        
        if (!userData) {
            return await message.reply('❌ Error al obtener los datos del usuario.');
        }
        
        // Calcular total de dinero
        const totalMoney = (userData.money || 0) + (userData.bank || 0);
        
        // Obtener apodo o usar "Sin apodo"
        const apodo = (userData.apodo && userData.apodo.trim() !== '') ? userData.apodo : 'Sin apodo';
        
        // Obtener respeto
        const respeto = userData.respeto || 0;
        
        // Obtener rank
        const rank = userData.rank || 0;
        
        // Crear mensaje del perfil
        let profileMessage = `👤 Perfil de @${targetNumber}\n\n`;
        
        // Apodo
        profileMessage += `📝 Apodo: ${apodo}\n\n`;
        
        // Información económica
        profileMessage += `💵 Dinero: ${(userData.money || 0).toLocaleString()}\n`;
        profileMessage += `🏦 Banco: ${(userData.bank || 0).toLocaleString()}\n`;
        profileMessage += `💎 Total: ${totalMoney.toLocaleString()}\n`;
        
        // Obtener deuda (si existe)
        const deuda = (userData.prestamo && userData.prestamo.activo && userData.prestamo.deuda > 0) 
            ? userData.prestamo.deuda 
            : 0;
        profileMessage += `💸 Deuda: ${deuda.toLocaleString()}\n\n`;
        
        // Información de rank y respeto
        profileMessage += `🎖️ Respeto: ${respeto}\n\n`;
        
        // Veces trabajadas
        profileMessage += `👷 Veces trabajadas: ${userData.totalWorkedTimes || 0}`;
        
        // Lista de menciones para el mensaje
        let mentions = [targetJid];
        
        // Enviar el perfil con las menciones correctas
        await message.reply(profileMessage, { mentions: mentions });
        
    } catch (error) {
        console.error('Error en comando perfil:', error);
        await message.reply('❌ Ocurrió un error al mostrar el perfil.');
    }
};

handler.help = ['perfil', 'perfil @usuario'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(perfil|profile|me)$/i;

module.exports = handler;
handler.group = true