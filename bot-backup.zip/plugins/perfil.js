const db = require('../database.js');
const achievements = require('../achievements');
const premium = require('../premium');

// Función para normalizar texto (eliminar tildes y convertir a minúsculas)
function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

// Funciones para formato de pareja
function tiempoTranscurrido(fecha) {
    const ahora = new Date();
    const inicio = new Date(fecha);
    const diferencia = ahora - inicio;
    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
    return { dias, horas, minutos };
}

function formatearFecha(fecha) {
    const d = new Date(fecha);
    return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
}

// Level calculation handled by achievements module

// Función para buscar usuario por apodo
function findUserByApodo(apodo) {
    const normalizedApodo = normalizeText(apodo);
    const allUsers = global.db.data.users || {};
    
    // Primera pasada: búsqueda exacta
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo === normalizedApodo) {
                return { number, userData };
            }
        }
    }
    
    // Segunda pasada: búsqueda parcial (contiene)
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                return { number, userData };
            }
        }
    }
    
    return null;
}

let handler = async (message, { text, args, conn }) => {
    try {
        const senderJid = message?.author || message?.sender || message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        let targetJid = senderJid;
        let targetNumber = senderNumber;
        let searchedByApodo = false;
        
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0].split(':')[0];
        } 
        else if ((text && text.trim() !== '') || (args && args.length > 0)) {
            const apodoQuery = args && args.length > 0 ? args.join(' ') : text.trim();
            const foundUser = findUserByApodo(apodoQuery);
            if (foundUser) {
                targetNumber = foundUser.number;
                targetJid = targetNumber + '@s.whatsapp.net';
                searchedByApodo = true;
            } else {
                return await message.reply(`❌ No se encontró ningún usuario con el apodo "${apodoQuery}".\n\nℹ️ Usa: .perfil @usuario o .perfil <apodo>`);
            }
        }
        
        const userData = db.getUser(targetNumber);
        if (!userData) return await message.reply('❌ Error al obtener los datos del usuario.');
        
        // Nivel y XP
        const levelInfo = achievements.calculateLevel(userData.exp || 0);
        
        const totalMoney = (userData.money || 0) + (userData.bank || 0);
        const apodo = (userData.apodo && userData.apodo.trim() !== '') ? userData.apodo : 'Sin apodo';
        const respeto = userData.respeto || 0;
        const rango = userData.rango || '🌱 Novato';
        const genero = userData.genero || 'No definido';
        
        // ── Posición global ──
        targetNumber = global.db?.cleanNumber ? global.db.cleanNumber(targetNumber) : targetNumber.replace(/\.0+$/, '').replace(/\D/g, '');
        const allUsers = global.db.data.users || {};
        const aliases = global.db.data.aliases || {};
        const seenNumbers = new Set();
        const globalRanking = [];
        
        for (const [num, u] of Object.entries(allUsers)) {
            if (!u) continue;
            if (aliases[num] && aliases[num] !== num) continue;
            const cleanNum = global.db?.cleanNumber ? global.db.cleanNumber(num) : num;
            if (!cleanNum || seenNumbers.has(cleanNum)) continue;
            seenNumbers.add(cleanNum);
            const total = (u.money || 0) + (u.bank || 0);
            if (total > 0) {
                globalRanking.push({ num: cleanNum, total });
            }
        }
        globalRanking.sort((a, b) => b.total - a.total);
        const globalPos = globalRanking.findIndex(u => u.num === targetNumber) + 1;
        const globalTotal = globalRanking.length;

        // ── Posición en el grupo (solo si es grupo) ──
        let groupPos = null;
        let groupTotal = null;
        if (message.isGroup && conn) {
            try {
                const meta = await conn.groupMetadata(message.from);
                const members = meta.participants.map(p => p.id.split('@')[0].split(':')[0]);
                const groupRanking = members
                    .map(num => {
                        const u = global.db.getUser(num);
                        return { num, total: u ? (u.money || 0) + (u.bank || 0) : 0 };
                    })
                    .filter(u => u.total > 0)
                    .sort((a, b) => b.total - a.total);
                groupPos = groupRanking.findIndex(u => u.num === targetNumber) + 1;
                groupTotal = groupRanking.length;
            } catch (_) {}
        }

        // ── Construir mensaje ──
        let profileMessage = searchedByApodo
            ? `👤 Perfil de ${apodo}\n\n`
            : `👤 Perfil de @${targetNumber}\n\n`;
        
        profileMessage += `📝 Apodo: ${apodo}\n`;
        profileMessage += `🚻 Género: ${genero}\n`;
        profileMessage += `💠 Premium: ${premium.isPremium(targetJid) ? 'Sí ⭐' : 'No'}\n\n`;
        
        profileMessage += `⭐ Nivel: ${levelInfo.level}\n`;
        profileMessage += `✨ XP: ${levelInfo.xpActual}/${levelInfo.xpTotal} (Faltan ${levelInfo.xpFaltante})\n\n`;
        
        profileMessage += `💵 Dinero: ${(userData.money || 0).toLocaleString()}\n`;
        profileMessage += `🏦 Banco: ${(userData.bank || 0).toLocaleString()}\n`;
        profileMessage += `💎 Total: ${totalMoney.toLocaleString()}\n`;
        
        const deuda = (userData.prestamo?.activo && userData.prestamo?.deuda > 0) ? userData.prestamo.deuda : 0;
        profileMessage += `💸 Deuda: ${deuda.toLocaleString()}\n\n`;
        
        profileMessage += `🎖️ Respeto: ${respeto}\n`;
        profileMessage += `🏅 Rango: ${rango}\n\n`;
        
        profileMessage += `👷 Veces trabajadas: ${userData.totalWorkedTimes || 0}\n`;
        profileMessage += `🎮 Comandos usados: ${userData.ComandosEjecutados || 0}\n\n`;

        // Estado civil / Pareja
        try {
            const pareja = db.getPareja(targetNumber);
            if (!pareja || pareja.estado !== 'aceptado') {
                profileMessage += `\n💘 Estado civil: Soltero(a)\n`;
            } else {
                const partner = db.getUser(pareja.numero) || {};
                const partnerApodo = partner.apodo || 'Desconocido';
                const tiempo = tiempoTranscurrido(pareja.fecha);
                profileMessage += `\n💘 Estado civil: Casado(a)\n`;
                profileMessage += `👫 Pareja: ${partnerApodo}\n`;
                profileMessage += `⏳ Juntos: ${tiempo.dias} días, ${tiempo.horas} horas y ${tiempo.minutos} minutos\n`;
            }
        } catch (_) {}

        // ── Información de Clan ──
        try {
            const clanInfo = db.getClanDeUsuario ? db.getClanDeUsuario(targetNumber) : null;
            if (clanInfo && clanInfo.clan) {
                const { nombre, clan } = clanInfo;
                
                const liderUser = db.getUser(clan.lider);
                const liderApodo = (liderUser?.apodo && liderUser.apodo.trim() !== '' && liderUser.apodo.toLowerCase() !== 'sin apodo')
                    ? liderUser.apodo
                    : `@${clan.lider}`;

                const rolClan = clan.lider === targetNumber
                    ? '👑 Líder'
                    : (clan.decanos || []).includes(targetNumber)
                        ? '⭐ Decano'
                        : '👤 Miembro';

                const depositosClan = clan.depositos || {};
                let dineroClan = 0;
                for (const mNum of (clan.miembros || [])) {
                    dineroClan += Number(depositosClan[mNum]) || 0;
                }

                const allClanes = db.getClanes ? db.getClanes() : (db.data?.clanes || {});
                const rankingClanes = Object.entries(allClanes).map(([cNombre, cData]) => {
                    let totalC = 0;
                    const cDeps = cData?.depositos || {};
                    for (const mNum of (cData?.miembros || [])) {
                        totalC += Number(cDeps[mNum]) || 0;
                    }
                    return { nombre: cNombre, dinero: totalC };
                }).sort((a, b) => b.dinero - a.dinero);

                const clanPosIndex = rankingClanes.findIndex(c => c.nombre.toLowerCase() === nombre.toLowerCase());
                const clanPos = clanPosIndex >= 0 ? clanPosIndex + 1 : null;
                const posClanEmoji = clanPos === 1 ? '🥇' : clanPos === 2 ? '🥈' : clanPos === 3 ? '🥉' : clanPos ? `#${clanPos}` : 'Sin posición';

                profileMessage += `\n🏴 *INFORMACIÓN DEL CLAN*\n`;
                profileMessage += `🏰 Clan: *${nombre}*\n`;
                profileMessage += `👑 Líder: *${liderApodo}*\n`;
                profileMessage += `📌 Rol: *${rolClan}*\n`;
                profileMessage += `💰 Dinero del clan: *$${dineroClan.toLocaleString()}*\n`;
                profileMessage += `🌍 Top global clan: *${posClanEmoji}* de ${rankingClanes.length}\n`;
            } else {
                profileMessage += `\n🏴 Clan: *Sin clan*\n`;
            }
        } catch (_) {}

        // ── Rankings ──
        profileMessage += `━━━━━━━━━━━━━━━━\n`;
        profileMessage += `📊 *RANKING DE DINERO*\n\n`;

        if (message.isGroup) {
            if (groupPos && groupPos > 0) {
                const gpEmoji = groupPos === 1 ? '🥇' : groupPos === 2 ? '🥈' : groupPos === 3 ? '🥉' : `#${groupPos}`;
                profileMessage += `🏠 *Top dinero del grupo:* ${gpEmoji} de ${groupTotal}\n`;
            } else {
                profileMessage += `🏠 *Top dinero del grupo:* Sin coins aún\n`;
            }
        } else {
            profileMessage += `🏠 *Top dinero del grupo:* Solo disponible en grupos\n`;
            profileMessage += `💡 Usa *.top* en un grupo para verlo\n`;
        }

        if (globalPos > 0) {
            const gpEmoji = globalPos === 1 ? '🥇' : globalPos === 2 ? '🥈' : globalPos === 3 ? '🥉' : `#${globalPos}`;
            profileMessage += `🌍 *Top dinero global:* ${gpEmoji} de ${globalTotal}\n`;
        } else {
            profileMessage += `🌍 *Top dinero global:* Sin coins aún\n`;
        }

        profileMessage += `\n💡 Usa *.top* o *.top global* para ver el ranking completo`;

        // ── Medallas ──
        try {
            const medallasModule = require('./medallas');
            if (medallasModule && typeof medallasModule.obtenerMedallas === 'function') {
                const userMedallas = medallasModule.obtenerMedallas(targetNumber);
                if (userMedallas && userMedallas.length > 0) {
                    profileMessage += `\n\n🏅 *MEDALLAS (${userMedallas.length})*\n`;
                    userMedallas.forEach(m => {
                        profileMessage += `  • ${m.emoji} *${m.nombre}:* ${m.badge}\n`;
                    });
                }
            }
        } catch (_) {}

        // ── Enlace al perfil web ──
        const apodoParaUrl = (userData.apodo && userData.apodo.trim() !== '')
            ? encodeURIComponent(userData.apodo.trim())
            : targetNumber;
        profileMessage += `\n\n🌐 *¿Querés ver tu perfil en la web?*\nhttps://roblebotpage.vercel.app/perfil.html?apodo=${apodoParaUrl}`;
        
        await message.reply(profileMessage, { mentions: [targetJid] });
        
    } catch (error) {
        console.error('Error en comando perfil:', error);
        await message.reply('❌ Ocurrió un error al mostrar el perfil.');
    }
};

handler.help = ['perfil', 'perfil @usuario', 'perfil <apodo>'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(perfil|profile|me)$/i;
module.exports = handler;
handler.group = false;
handler.apodo = true;