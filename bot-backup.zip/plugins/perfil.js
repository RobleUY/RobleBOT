const db = require('../database.js');
const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON de temporadas (mismo directorio que el plugin)
const TEMPORADAS_FILE = path.join(__dirname, 'temporadas_coins.json');

// Función para cargar datos de temporadas
function loadTemporadas() {
    try {
        if (fs.existsSync(TEMPORADAS_FILE)) {
            const data = fs.readFileSync(TEMPORADAS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error al cargar temporadas:', error);
    }
    return null;
}

// Función para calcular posición actual en la temporada que está corriendo
function calcularPosicionEnTemporadaActual(targetNumber) {
    try {
        const temporadasData = loadTemporadas();
        
        // La temporada actual es la siguiente que se finalizará
        const temporadaActualCorriendo = temporadasData ? temporadasData.temporadaActual + 1 : 1;
        
        const allUsers = global.db.data.users || {};
        
        // Crear array con todos los usuarios y sus coins actuales
        const usersWithCoins = [];
        for (let [number, userData] of Object.entries(allUsers)) {
            const totalCoins = (userData.money || 0) + (userData.bank || 0);
            usersWithCoins.push({
                number: number,
                totalCoins: totalCoins
            });
        }
        
        // Ordenar por coins (mayor a menor)
        usersWithCoins.sort((a, b) => b.totalCoins - a.totalCoins);
        
        // Encontrar la posición del usuario
        const posicion = usersWithCoins.findIndex(u => u.number === targetNumber) + 1;
        
        return { 
            posicion, 
            temporada: temporadaActualCorriendo
        };
    } catch (error) {
        console.error('Error al calcular posición actual:', error);
        return null;
    }
}

// Función para obtener las temporadas del usuario desde el JSON
function getTemporadasDelUsuario(userNumber) {
    const temporadasData = loadTemporadas();
    if (!temporadasData || !temporadasData.temporadas) {
        return [];
    }
    
    const temporadasDelUsuario = [];
    
    // Recorrer todas las temporadas en el JSON
    for (let [numTemporada, usuarios] of Object.entries(temporadasData.temporadas)) {
        // Ver si el usuario participó en esta temporada
        if (usuarios[userNumber]) {
            temporadasDelUsuario.push({
                numero: parseInt(numTemporada),
                posicion: usuarios[userNumber].posicion,
                coins: usuarios[userNumber].coins
            });
        }
    }
    
    // Ordenar por número de temporada (de menor a mayor)
    temporadasDelUsuario.sort((a, b) => a.numero - b.numero);
    
    return temporadasDelUsuario;
}

// Función para normalizar texto (eliminar tildes y convertir a minúsculas)
function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

// Función para calcular nivel y XP necesaria para siguiente nivel
function calculateLevel(comandos) {
    let level = 0;
    let comandosUsados = 0;
    let incremento = 10;
    
    while (comandosUsados <= comandos) {
        // Determinar el incremento actual según el nivel
        if (level < 10) {
            incremento = 10;
        } else if (level < 20) {
            incremento = 20;
        } else if (level < 30) {
            incremento = 30;
        } else if (level < 40) {
            incremento = 40;
        } else if (level < 50) {
            incremento = 50;
        } else {
            incremento = 60;
        }
        
        // Si con este incremento nos pasamos, paramos
        if (comandosUsados + incremento > comandos) {
            break;
        }
        
        comandosUsados += incremento;
        level++;
    }
    
    // Calcular XP faltante para siguiente nivel
    const xpParaSiguienteNivel = incremento - (comandos - comandosUsados);
    
    return {
        level,
        xpFaltante: xpParaSiguienteNivel,
        xpActual: comandos - comandosUsados,
        xpTotal: incremento
    };
}

// Función para buscar usuario por apodo
function findUserByApodo(apodo) {
    const normalizedApodo = normalizeText(apodo);
    const allUsers = global.db.data.users || {};
    
    // Primera pasada: búsqueda exacta
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo === normalizedApodo) {
                return { number, userData };
            }
        }
    }
    
    // Segunda pasada: búsqueda parcial (contiene)
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                return { number, userData };
            }
        }
    }
    
    return null;
}

let handler = async (message, { text, args }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        let targetJid = senderJid;
        let targetNumber = senderNumber;
        let searchedByApodo = false;
        
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0];
        } 
        else if ((text && text.trim() !== '') || (args && args.length > 0)) {
            const apodoQuery = args && args.length > 0 ? args.join(' ') : text.trim();
            
            const foundUser = findUserByApodo(apodoQuery);
            
            if (foundUser) {
                targetNumber = foundUser.number;
                targetJid = targetNumber + '@s.whatsapp.net';
                searchedByApodo = true;
            } else {
                return await message.reply(`❌ No se encontró ningún usuario con el apodo "${apodoQuery}".\n\nℹ️ Usa: .perfil @usuario o .perfil <apodo>`);
            }
        }
        
        const userData = db.getUser(targetNumber);
        
        if (!userData) {
            return await message.reply('❌ Error al obtener los datos del usuario.');
        }
        
        // Calcular nivel y XP
        const comandosEjecutados = userData.ComandosEjecutados || 0;
        const levelInfo = calculateLevel(comandosEjecutados);
        
        const totalMoney = (userData.money || 0) + (userData.bank || 0);
        const apodo = (userData.apodo && userData.apodo.trim() !== '') ? userData.apodo : 'Sin apodo';
        
        // Obtener clan y formatearlo
        let clanInfo = 'Sin clan';
        if (userData.clan) {
            const clan = global.db.getClan(userData.clan);
            if (clan) {
                const clanName = userData.clan.toUpperCase();
                
                let role = '👤 Miembro';
                if (clan.leader === targetNumber) {
                    role = '👑 Líder';
                } else if (clan.elders && clan.elders.includes(targetNumber)) {
                    role = '⭐ Decano';
                }
                
                clanInfo = `${clanName} (${role})`;
            }
        }
        
        const respeto = userData.respeto || 0;
        const rango = userData.rango || '🌱 Novato';
        const genero = userData.genero || 'No definido';
        
        // Crear mensaje del perfil
        let profileMessage;
        if (searchedByApodo) {
            profileMessage = `👤 Perfil de ${apodo}\n\n`;
        } else {
            profileMessage = `👤 Perfil de @${targetNumber}\n\n`;
        }
        
        profileMessage += `📝 Apodo: ${apodo}\n`;
        profileMessage += `🚻 Género: ${genero}\n`;
        profileMessage += `🏰 Clan: ${clanInfo}\n\n`;
        
        // Nivel y XP
        profileMessage += `⭐ Nivel: ${levelInfo.level}\n`;
        profileMessage += `✨ XP: ${levelInfo.xpActual}/${levelInfo.xpTotal} (Faltan ${levelInfo.xpFaltante})\n\n`;
        
        profileMessage += `💵 Dinero: ${(userData.money || 0).toLocaleString()}\n`;
        profileMessage += `🏦 Banco: ${(userData.bank || 0).toLocaleString()}\n`;
        profileMessage += `💎 Total: ${totalMoney.toLocaleString()}\n`;
        
        const deuda = (userData.prestamo && userData.prestamo.activo && userData.prestamo.deuda > 0) 
            ? userData.prestamo.deuda 
            : 0;
        profileMessage += `💸 Deuda: ${deuda.toLocaleString()}\n\n`;
        
        profileMessage += `🎖️ Respeto: ${respeto}\n`;
        profileMessage += `🏅 Rango: ${rango}\n\n`;
        
        profileMessage += `👷 Veces trabajadas: ${userData.totalWorkedTimes || 0}\n`;
        
        // Añadir sección de temporadas (SIEMPRE se muestra)
        profileMessage += `\n━━━━━━━━━━━━━━━━\n`;
        profileMessage += `🏆 *HISTORIAL DE TEMPORADAS*\n\n`;
        
        // Obtener temporadas del usuario SOLO DEL JSON
        const temporadasDelUsuario = getTemporadasDelUsuario(targetNumber);
        
        // Mostrar historial de temporadas PASADAS (finalizadas)
        if (temporadasDelUsuario.length > 0) {
            profileMessage += `📜 *Temporadas anteriores:*\n\n`;
            
            // Mostrar últimas 5 temporadas
            const ultimas = temporadasDelUsuario.slice(-5).reverse();
            for (let temp of ultimas) {
                let posEmoji = '';
                if (temp.posicion === 1) posEmoji = '🥇';
                else if (temp.posicion === 2) posEmoji = '🥈';
                else if (temp.posicion === 3) posEmoji = '🥉';
                else posEmoji = `${temp.posicion}º`;
                
                profileMessage += `Temporada #${temp.numero}: ${posEmoji}\n`;
                profileMessage += `💰 ${temp.coins.toLocaleString()} coins\n\n`;
            }
        }
        
        // SIEMPRE mostrar posición en la temporada ACTUAL (la que está corriendo)
        const posActual = calcularPosicionEnTemporadaActual(targetNumber);
        if (posActual) {
            let emojiPos = '';
            if (posActual.posicion === 1) emojiPos = '🥇';
            else if (posActual.posicion === 2) emojiPos = '🥈';
            else if (posActual.posicion === 3) emojiPos = '🥉';
            else emojiPos = `${posActual.posicion}º`;
            
            profileMessage += `📍 *Temporada actual: #${posActual.temporada}*\n`;
            profileMessage += `Tu posición: ${emojiPos}`;
        }
        
        let mentions = [targetJid];
        
        await message.reply(profileMessage, { mentions: mentions });
        
    } catch (error) {
        console.error('Error en comando perfil:', error);
        await message.reply('❌ Ocurrió un error al mostrar el perfil.');
    }
};

handler.help = ['perfil', 'perfil @usuario', 'perfil <apodo>'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(perfil|profile|me)$/i;
module.exports = handler;
handler.group = true;
handler.apodo = true;