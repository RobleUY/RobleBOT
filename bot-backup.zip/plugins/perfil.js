const db = require('../database.js');

// Función para normalizar texto (eliminar tildes y convertir a minúsculas)
function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

// Función para calcular nivel y XP
// Nivel 1 requiere 10 comandos, nivel 2 requiere 20 más, nivel 3 requiere 30 más, etc.
// xpParaNivel(n) = n * 10
function calculateLevel(comandos) {
    let level = 0;
    let acumulado = 0;

    while (true) {
        const xpNecesaria = (level + 1) * 10; // nivel 1=10, nivel 2=20, nivel 3=30...
        if (acumulado + xpNecesaria > comandos) {
            // No alcanza para subir al siguiente nivel
            return {
                level,
                xpActual: comandos - acumulado,
                xpTotal: xpNecesaria,
                xpFaltante: xpNecesaria - (comandos - acumulado)
            };
        }
        acumulado += xpNecesaria;
        level++;
    }
}

// Función para buscar usuario por apodo
function findUserByApodo(apodo) {
    const normalizedApodo = normalizeText(apodo);
    const allUsers = global.db.data.users || {};
    
    // Primera pasada: búsqueda exacta
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo === normalizedApodo) {
                return { number, userData };
            }
        }
    }
    
    // Segunda pasada: búsqueda parcial (contiene)
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                return { number, userData };
            }
        }
    }
    
    return null;
}

let handler = async (message, { text, args, conn }) => {
    try {
        const senderJid = message?.author || message?.sender || message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        let targetJid = senderJid;
        let targetNumber = senderNumber;
        let searchedByApodo = false;
        
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0].split(':')[0];
        } 
        else if ((text && text.trim() !== '') || (args && args.length > 0)) {
            const apodoQuery = args && args.length > 0 ? args.join(' ') : text.trim();
            const foundUser = findUserByApodo(apodoQuery);
            if (foundUser) {
                targetNumber = foundUser.number;
                targetJid = targetNumber + '@s.whatsapp.net';
                searchedByApodo = true;
            } else {
                return await message.reply(`❌ No se encontró ningún usuario con el apodo "${apodoQuery}".\n\nℹ️ Usa: .perfil @usuario o .perfil <apodo>`);
            }
        }
        
        const userData = db.getUser(targetNumber);
        if (!userData) return await message.reply('❌ Error al obtener los datos del usuario.');
        
        // Nivel y XP
        const comandosEjecutados = userData.ComandosEjecutados || 0;
        const levelInfo = calculateLevel(comandosEjecutados);
        
        const totalMoney = (userData.money || 0) + (userData.bank || 0);
        const apodo = (userData.apodo && userData.apodo.trim() !== '') ? userData.apodo : 'Sin apodo';
        const respeto = userData.respeto || 0;
        const rango = userData.rango || '🌱 Novato';
        const genero = userData.genero || 'No definido';
        
        // ── Posición global ──
        const allUsers = global.db.data.users || {};
        const globalRanking = Object.entries(allUsers)
            .map(([num, u]) => ({ num, total: (u.money || 0) + (u.bank || 0) }))
            .filter(u => u.total > 0)
            .sort((a, b) => b.total - a.total);
        const globalPos = globalRanking.findIndex(u => u.num === targetNumber) + 1;
        const globalTotal = globalRanking.length;

        // ── Posición en el grupo (solo si es grupo) ──
        let groupPos = null;
        let groupTotal = null;
        if (message.isGroup && conn) {
            try {
                const meta = await conn.groupMetadata(message.from);
                const members = meta.participants.map(p => p.id.split('@')[0].split(':')[0]);
                const groupRanking = members
                    .map(num => {
                        const u = global.db.getUser(num);
                        return { num, total: u ? (u.money || 0) + (u.bank || 0) : 0 };
                    })
                    .filter(u => u.total > 0)
                    .sort((a, b) => b.total - a.total);
                groupPos = groupRanking.findIndex(u => u.num === targetNumber) + 1;
                groupTotal = groupRanking.length;
            } catch (_) {}
        }

        // ── Construir mensaje ──
        let profileMessage = searchedByApodo
            ? `👤 Perfil de ${apodo}\n\n`
            : `👤 Perfil de @${targetNumber}\n\n`;
        
        profileMessage += `📝 Apodo: ${apodo}\n`;
        profileMessage += `🚻 Género: ${genero}\n\n`;
        
        profileMessage += `⭐ Nivel: ${levelInfo.level}\n`;
        profileMessage += `✨ XP: ${levelInfo.xpActual}/${levelInfo.xpTotal} (Faltan ${levelInfo.xpFaltante})\n\n`;
        
        profileMessage += `💵 Dinero: ${(userData.money || 0).toLocaleString()}\n`;
        profileMessage += `🏦 Banco: ${(userData.bank || 0).toLocaleString()}\n`;
        profileMessage += `💎 Total: ${totalMoney.toLocaleString()}\n`;
        
        const deuda = (userData.prestamo?.activo && userData.prestamo?.deuda > 0) ? userData.prestamo.deuda : 0;
        profileMessage += `💸 Deuda: ${deuda.toLocaleString()}\n\n`;
        
        profileMessage += `🎖️ Respeto: ${respeto}\n`;
        profileMessage += `🏅 Rango: ${rango}\n\n`;
        
        profileMessage += `👷 Veces trabajadas: ${userData.totalWorkedTimes || 0}\n`;
        profileMessage += `🎮 Comandos usados: ${comandosEjecutados}\n\n`;

        // ── Rankings ──
        profileMessage += `━━━━━━━━━━━━━━━━\n`;
        profileMessage += `📊 *RANKING DE DINERO*\n\n`;

        if (message.isGroup) {
            if (groupPos && groupPos > 0) {
                const gpEmoji = groupPos === 1 ? '🥇' : groupPos === 2 ? '🥈' : groupPos === 3 ? '🥉' : `#${groupPos}`;
                profileMessage += `🏠 *Top dinero del grupo:* ${gpEmoji} de ${groupTotal}\n`;
            } else {
                profileMessage += `🏠 *Top dinero del grupo:* Sin coins aún\n`;
            }
        } else {
            profileMessage += `🏠 *Top dinero del grupo:* Solo disponible en grupos\n`;
            profileMessage += `💡 Usa *.top* en un grupo para verlo\n`;
        }

        if (globalPos > 0) {
            const gpEmoji = globalPos === 1 ? '🥇' : globalPos === 2 ? '🥈' : globalPos === 3 ? '🥉' : `#${globalPos}`;
            profileMessage += `🌍 *Top dinero global:* ${gpEmoji} de ${globalTotal}\n`;
        } else {
            profileMessage += `🌍 *Top dinero global:* Sin coins aún\n`;
        }

        profileMessage += `\n💡 Usa *.top* o *.top global* para ver el ranking completo`;
        
        await message.reply(profileMessage, { mentions: [targetJid] });
        
    } catch (error) {
        console.error('Error en comando perfil:', error);
        await message.reply('❌ Ocurrió un error al mostrar el perfil.');
    }
};

handler.help = ['perfil', 'perfil @usuario', 'perfil <apodo>'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(perfil|profile|me)$/i;
module.exports = handler;
handler.group = false;
handler.apodo = true;