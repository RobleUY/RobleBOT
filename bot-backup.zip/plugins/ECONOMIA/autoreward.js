// Comando para ver el estado del sistema de recompensas automáticas
let handler = async (message, { text }) => {
    try {
        if (!global.autoRewardSystem) {
            return await message.reply('❌ El sistema de recompensas automáticas no está activo.');
        }

        const stats = global.autoRewardSystem.getStats();
        
        // Calcular tiempo hasta la próxima recompensa
        const nextRewardMs = stats.nextRewardIn;
        const nextRewardMinutes = Math.floor(nextRewardMs / (60 * 1000));
        const nextRewardSeconds = Math.floor((nextRewardMs % (60 * 1000)) / 1000);

        const responseText = 
            `╔═══════════════════════╗\n` +
            `║  💰 *RECOMPENSAS AUTOMÁTICAS*  ║\n` +
            `╚═══════════════════════╝\n\n` +
            `🎁 *Recompensa:* ${stats.rewardAmount.toLocaleString()} monedas\n` +
            `⏱️ *Frecuencia:* Cada minuto\n` +
            `📊 *Recompensas entregadas:* ${stats.rewardsGiven}\n` +
            `⏰ *Uptime del bot:* ${stats.uptimeFormatted}\n` +
            `⏳ *Próxima recompensa en:* ${nextRewardSeconds}s\n\n` +
            `✅ *Requisito:* Tener un apodo configurado\n` +
            `💡 *Tip:* Usa *.apodo TuApodo* para configurar tu apodo\n\n` +
            `_Las recompensas se entregan automáticamente y de forma silenciosa cada minuto._`;

        await message.reply(responseText);

    } catch (error) {
        console.error('[autoreward] Error:', error.message);
        await message.reply('❌ Error al obtener información del sistema de recompensas.');
    }
};

handler.help = ['autoreward', 'recompensas', 'autorecompensas'];
handler.tags = ['economia'];
handler.command = /^(autoreward|recompensas|autorecompensas|recompensa)$/i;
handler.group = true;

module.exports = handler;
