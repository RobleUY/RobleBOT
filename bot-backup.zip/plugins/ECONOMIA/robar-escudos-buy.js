let escudoCooldowns = new Map();

let handler = async (message, { conn }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ Ocurrió un error al procesar el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        const user = global.db.getUser(senderNumber);

        if (!user) {
            return await message.reply('❌ Ocurrió un error al obtener tus datos. Asegúrate de estar registrado en la base de datos.');
        }

        // Inicializar escudos si no existen
        if (typeof user.escudosAntiRobos === 'undefined') {
            user.escudosAntiRobos = 0;
            global.db.setUser(senderNumber, user);
        }

        const maxEscudos = 3;
        const saldoTotal = (user.money || 0) + (user.bank || 0);
        const precioEscudo = Math.floor(saldoTotal * 0.15);
        const cooldownTime = 10 * 60 * 1000; // 10 minutos en milisegundos
        const saldoMinimo = 10000000; // 10 millones

        // Verificar si tiene el saldo mínimo requerido
        if (saldoTotal < saldoMinimo) {
            return await message.reply(
                `❌ No cumples con el requisito mínimo para comprar escudos.\n\n` +
                `💰 Saldo mínimo requerido: *${saldoMinimo.toLocaleString()}* monedas\n` +
                `📊 Tu saldo total: *${saldoTotal.toLocaleString()}* monedas\n` +
                `📉 Te faltan: *${(saldoMinimo - saldoTotal).toLocaleString()}* monedas`
            );
        }

        // Verificar si ya tiene el máximo de escudos
        if (user.escudosAntiRobos >= maxEscudos) {
            return await message.reply(`🛡️ Ya tienes el máximo de escudos (${maxEscudos}). No puedes comprar más.`);
        }

        // Verificar cooldown
        const lastPurchase = escudoCooldowns.get(senderJid) || 0;
        const timeLeft = lastPurchase + cooldownTime - Date.now();

        if (timeLeft > 0) {
            const minutes = Math.floor(timeLeft / 60000);
            const seconds = Math.ceil((timeLeft % 60000) / 1000);
            return await message.reply(`⏰ Debes esperar *${minutes}m ${seconds}s* antes de comprar otro escudo.`);
        }

        // Verificar si tiene suficiente dinero
        if (saldoTotal < precioEscudo || precioEscudo <= 0) {
            return await message.reply(
                `❌ No tienes suficiente dinero. Necesitas *${precioEscudo.toLocaleString()}* monedas para comprar un escudo.\n\n` +
                `💵 Dinero en efectivo: *${user.money || 0}* monedas\n` +
                `🏦 Dinero en banco: *${user.bank || 0}* monedas\n` +
                `📊 Saldo total: *${saldoTotal.toLocaleString()}* monedas`
            );
        }

        // Descontar el dinero (primero del efectivo, luego del banco si es necesario)
        let restante = precioEscudo;
        let dineroEfectivoUsado = 0;
        let dineroBancoUsado = 0;

        if (user.money >= restante) {
            // Hay suficiente en efectivo
            user.money -= restante;
            dineroEfectivoUsado = restante;
        } else {
            // Se necesita usar efectivo y banco
            dineroEfectivoUsado = user.money || 0;
            restante -= dineroEfectivoUsado;
            user.money = 0;
            
            dineroBancoUsado = restante;
            user.bank = (user.bank || 0) - restante;
        }

        // Agregar el escudo
        user.escudosAntiRobos = (user.escudosAntiRobos || 0) + 1;
        global.db.setUser(senderNumber, user);

        // Establecer cooldown
        escudoCooldowns.set(senderJid, Date.now());

        let detalleCompra = `✅ ¡Compra exitosa!\n\n` +
            `🛡️ Has adquirido un escudo anti-robos por *${precioEscudo.toLocaleString()}* monedas.\n\n`;

        if (dineroBancoUsado > 0) {
            detalleCompra += `💵 Pagado desde efectivo: *${dineroEfectivoUsado.toLocaleString()}* monedas\n` +
                `🏦 Pagado desde banco: *${dineroBancoUsado.toLocaleString()}* monedas\n\n`;
        } else {
            detalleCompra += `💵 Pagado desde efectivo: *${precioEscudo.toLocaleString()}* monedas\n\n`;
        }

        detalleCompra += `🛡️ Escudos actuales: *${user.escudosAntiRobos}/3*\n` +
            `💰 Efectivo restante: *${user.money.toLocaleString()}* monedas\n` +
            `🏦 Banco restante: *${(user.bank || 0).toLocaleString()}* monedas\n\n` +
            `⏰ Podrás comprar otro escudo en 10 minutos.`;

        return await message.reply(detalleCompra);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al comprar escudo:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al procesar la compra. Revisa el registro de errores para más detalles.');
    }
};

handler.help = ['escudobuy'];
handler.tags = ['economy'];
handler.command = /^(escudobuy|buyescudo|comprarescudo)$/i;

module.exports = handler;
handler.group = true;