const axios = require('axios');

// Credenciales Google API
const GOOGLE_API_KEY = 'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4';
const GOOGLE_CX = '635e6b14f7cf84f2c';

// Lista de términos de búsqueda de anime
const ANIME_TERMS = [
    'anime character',
    'anime girl',
    'anime boy',
    'anime fanart',
    'anime cute',
    'anime chibi',
    'anime action',
    'anime aesthetic',
    'anime manga',
    'anime original character'
];

async function buscarImagenAnime() {
    try {
        // Elegimos un término aleatorio
        const randomTerm = ANIME_TERMS[Math.floor(Math.random() * ANIME_TERMS.length)];

        // Elegimos un índice de inicio aleatorio para más variedad
        const startIndex = Math.floor(Math.random() * 50) + 1; // 1 a 50

        const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${GOOGLE_API_KEY}&searchType=image&num=10&start=${startIndex}&safe=off`;

        const response = await axios.get(url);

        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => item.fileFormat?.startsWith('image/'));
            if (validImages.length > 0) {
                const randomImage = validImages[Math.floor(Math.random() * validImages.length)];
                return randomImage.link;
            }
        }
    } catch (error) {
        console.error('Error al buscar imagen de anime en Google:', error.message);
    }
    return null;
}

let handler = async (message, { conn }) => {
    try {
        const imageUrl = await buscarImagenAnime();

        if (!imageUrl) {
            return await message.reply('❌ No se encontraron imágenes de anime 😢');
        }

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        const recipient = message.key.remoteJid;

        const fanMessage = '✨ Anime ✨';

        await conn.sendMessage(recipient, {
            image: imageBuffer,
            caption: fanMessage,
            quoted: message
        });

    } catch (error) {
        console.error('[ANIME] Error al enviar imagen:', error.message || error);
        await message.reply('❌ Ocurrió un error al buscar tu imagen de anime 😢');
    }
};

handler.help = ['anime'];
handler.tags = ['anime', 'personajes', 'imagenes'];
handler.command = /^anime$/i;

module.exports = handler;
