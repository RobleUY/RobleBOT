// Empresas disponibles para invertir
const EMPRESAS = [
    'TechCorp',
    'CryptoInvest',
    'GlobalBank',
    'MegaRetail',
    'EnergyPlus',
    'FoodChain',
    'AutoMotors',
    'PharmaLife',
    'RealEstate Co.',
    'SoftwarePro'
];

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Verificar que se haya proporcionado una cantidad
        if (!text || text.trim() === '') {
            return await message.reply('❌ Debes especificar una cantidad para invertir.\n\n*Uso:* .invertir [cantidad]\n*Ejemplo:* .invertir 10000');
        }

        // Convertir el texto a número
        const cantidad = parseInt(text.trim());

        // Validar que sea un número válido y positivo
        if (isNaN(cantidad) || cantidad <= 0) {
            return await message.reply('❌ Debes especificar una cantidad válida mayor a 0.');
        }

        // Verificar que sea múltiplo de 10000
        if (cantidad % 10000 !== 0) {
            return await message.reply('❌ Solo puedes invertir en múltiplos de 10,000 monedas.\n\n*Ejemplos válidos:* 10000, 20000, 50000, 100000');
        }

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                bank: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar que el usuario tenga suficiente dinero en efectivo
        if ((user.money || 0) < cantidad) {
            return await message.reply(`❌ No tienes suficiente dinero en efectivo.\n\n💰 Tu saldo: ${(user.money || 0).toLocaleString()}\n💸 Necesitas: ${cantidad.toLocaleString()}`);
        }

        // Seleccionar una empresa aleatoria
        const empresaSeleccionada = EMPRESAS[Math.floor(Math.random() * EMPRESAS.length)];

        // Restar el dinero invertido
        user.money = (user.money || 0) - cantidad;
        global.db.setUser(senderNumber, user);

        // Enviar mensaje inicial
        await message.reply(
            `📊 *INVERSIÓN REALIZADA*\n\n` +
            `👤 @${senderNumber.split('@')[0]}\n` +
            `💼 Empresa: *${empresaSeleccionada}*\n` +
            `💰 Cantidad invertida: *${cantidad.toLocaleString()}* monedas\n\n` +
            `⏳ Conocerás los resultados en 5 segundos...`,
            { mentions: [message.author || sender] }
        );

        // Esperar 5 segundos
        await new Promise(resolve => setTimeout(resolve, 5000));

        // Generar porcentaje aleatorio entre -50% y +50%
        const porcentaje = Math.floor(Math.random() * 101) - 50; // -50 a +50
        
        // Calcular ganancia o pérdida (sin decimales)
        const cambio = Math.floor((cantidad * porcentaje) / 100);
        const montoFinal = cantidad + cambio;

        // Actualizar el saldo del usuario
        user = global.db.getUser(senderNumber);
        user.money = (user.money || 0) + montoFinal;
        global.db.setUser(senderNumber, user);

        // Determinar el emoji y texto según el resultado
        let emoji, texto, resultado;
        
        if (porcentaje > 0) {
            emoji = '📈';
            texto = 'ha aumentado';
            resultado = `💰 *¡GANASTE ${Math.abs(cambio).toLocaleString()} monedas!*`;
        } else if (porcentaje < 0) {
            emoji = '📉';
            texto = 'ha disminuido';
            resultado = `💸 *Perdiste ${Math.abs(cambio).toLocaleString()} monedas*`;
        } else {
            emoji = '➡️';
            texto = 'se mantuvo estable';
            resultado = `💵 *No ganaste ni perdiste*`;
        }

        // Enviar mensaje con los resultados
        await message.reply(
            `${emoji} *RESULTADO DE LA INVERSIÓN*\n\n` +
            `👤 @${senderNumber.split('@')[0]}\n` +
            `💼 Empresa: *${empresaSeleccionada}*\n` +
            `📊 La empresa ${texto} un *${Math.abs(porcentaje)}%*\n\n` +
            `${resultado}\n\n` +
            `💵 Recuperaste: *${montoFinal.toLocaleString()}* monedas\n` +
            `💰 Nuevo saldo: *${user.money.toLocaleString()}* monedas`,
            { mentions: [message.author || sender] }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al invertir:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al procesar la inversión.');
    }
};

handler.help = ['invertir'];
handler.tags = ['economy'];
handler.command = /^(invertir|invest)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;