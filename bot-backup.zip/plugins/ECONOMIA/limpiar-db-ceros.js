// Comando temporal para limpiar usuarios con dinero 0 de la base de datos
// Este comando solo puede ser usado por el owner del bot

let handler = async (message, { conn, isOwner }) => {
    if (!isOwner) {
        return await message.reply('❌ Este comando solo puede ser usado por el owner del bot.');
    }

    try {
        await message.reply('🔄 Limpiando base de datos...\n\nEsto puede tomar un momento...');

        const allUsers = global.db.data.users;
        let totalUsers = 0;
        let cleanedUsers = 0;
        let preservedUsers = 0;

        // Primero, contar total
        for (const [userKey, userData] of Object.entries(allUsers)) {
            totalUsers++;
        }

        // Obtener aliases
        const aliases = global.db._getKvAll ? global.db._getKvAll('aliases') : (global.db.data.aliases || {});

        // Procesar cada usuario
        for (const [userKey, userData] of Object.entries(allUsers)) {
            if (!userData) continue;

            const totalMoney = (userData.money || 0) + (userData.bank || 0);
            
            // Si el usuario tiene 0 dinero, resetear a valores por defecto
            if (totalMoney === 0) {
                // Resetear money y bank explícitamente a 0
                userData.money = 0;
                userData.bank = 0;
                
                // Guardar el usuario actualizado
                const cleanNumber = userKey.split('@')[0].replace(/[^0-9]/g, '').trim();
                if (cleanNumber) {
                    global.db.setUser(cleanNumber, userData);
                }
                cleanedUsers++;
            } else {
                preservedUsers++;
            }
        }

        // Forzar guardado
        await global.db.saveNow();

        const report = `✅ *Limpieza completada*\n\n` +
            `📊 *Estadísticas:*\n` +
            `• Total de usuarios: ${totalUsers}\n` +
            `• Usuarios con dinero: ${preservedUsers}\n` +
            `• Usuarios limpiados: ${cleanedUsers}\n\n` +
            `💾 Cambios guardados en la base de datos.\n` +
            `🔄 Se recomienda reiniciar el bot para que los cambios se reflejen completamente.`;

        await message.reply(report);

    } catch (error) {
        console.error('[ERROR EN LIMPIAR-DB]:', error);
        await message.reply('⚠️ Error al limpiar la base de datos: ' + error.message);
    }
};

handler.help = ['limpiardb'];
handler.tags = ['owner'];
handler.command = /^(limpiardb|cleandb|limpiarbasedatos)$/i;
handler.owner = true;

module.exports = handler;
