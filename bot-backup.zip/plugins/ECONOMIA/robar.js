let cooldowns = new Map();
let victimProtection = new Map();

// 🧹 LIMPIEZA AUTOMÁTICA DE MEMORIA
// Limpiar cooldowns y protecciones expiradas cada 5 minutos
setInterval(() => {
    const now = Date.now();
    const cooldownTime = 2 * 60 * 1000; // 2 minutos
    
    // Limpiar cooldowns expirados (después de 10 minutos sin uso)
    for (const [key, timestamp] of cooldowns.entries()) {
        if (now - timestamp > cooldownTime * 5) { // 10 minutos
            cooldowns.delete(key);
        }
    }
    
    // Limpiar protecciones expiradas (después de 10 minutos sin uso)
    for (const [key, timestamp] of victimProtection.entries()) {
        if (now - timestamp > cooldownTime * 5) { // 10 minutos
            victimProtection.delete(key);
        }
    }
    
    // Log de limpieza si hay muchas entradas
    const cooldownSize = cooldowns.size;
    const protectionSize = victimProtection.size;
    if (cooldownSize > 50 || protectionSize > 50) {
        console.log(`[ROBAR] Limpieza: ${cooldownSize} cooldowns, ${protectionSize} protecciones`);
    }
}, 5 * 60 * 1000); // Cada 5 minutos

let handler = async (message, { conn, text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ Ocurrió un error al procesar el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        const mentionedJids = message?.mentions || [];

        if (mentionedJids.length === 0) {
            return await message.reply('❌ Debes mencionar a un usuario para robar. Uso: */robar @usuario*');
        }

        const targetJid = mentionedJids[0];
        const victimNumber = targetJid.split('@')[0];

        // No permitir robarse a sí mismo
        if (senderNumber === victimNumber) {
            return await message.reply('❌ No puedes robarte a ti mismo.');
        }

        const cooldownTime = 2 * 60 * 1000; // 2 minutos en milisegundos

        // Verificar cooldown del ladrón
        const lastRob = cooldowns.get(senderJid) || 0;
        const timeLeftRobber = lastRob + cooldownTime - Date.now();

        if (timeLeftRobber > 0) {
            const seconds = Math.ceil(timeLeftRobber / 1000);
            return await message.reply(`⏰ Debes esperar ${seconds} segundos antes de volver a robar.`);
        }

        // Verificar protección de la víctima
        const lastRobbed = victimProtection.get(targetJid) || 0;
        const timeLeftVictim = lastRobbed + cooldownTime - Date.now();

        if (timeLeftVictim > 0) {
            const seconds = Math.ceil(timeLeftVictim / 1000);
            return await message.reply(`🛡️ *@${victimNumber}* está protegido. No puede ser robado durante ${seconds} segundos más.`, { mentions: [targetJid] });
        }

        // Obtener datos de usuarios
        const victim = global.db.getUser(victimNumber);
        const robber = global.db.getUser(senderNumber);

        if (!victim || !robber) {
            return await message.reply('❌ Ocurrió un error al obtener los datos de los usuarios. Asegúrate de que ambos estén registrados en la base de datos.');
        }

        // ACTIVAR COOLDOWNS ANTES DE LAS VERIFICACIONES
        // Cooldown del ladrón (siempre se activa al intentar robar)
        cooldowns.set(senderJid, Date.now());
        
        // Protección de la víctima (siempre se activa cuando alguien intenta robarle)
        victimProtection.set(targetJid, Date.now());

        // Verificar si la víctima tiene suficiente dinero
        if (!victim.money || victim.money < 1000) {
            return await message.reply(`🚫 *@${victimNumber}* no tiene suficiente efectivo en los bolsillos para robar.`, { mentions: [targetJid] });
        }

        // Verificar si la víctima tiene escudos anti-robos
        if (victim.escudosAntiRobos && victim.escudosAntiRobos > 0) {
            victim.escudosAntiRobos -= 1;
            global.db.setUser(victimNumber, victim);
            
            const escudosRestantes = victim.escudosAntiRobos;
            return await message.reply(
                `🛡️ ¡El robo ha fallado! *@${victimNumber}* tenía un escudo anti-robos activo.\n\n` +
                `El escudo se ha consumido. Escudos restantes: *${escudosRestantes}*`,
                { mentions: [targetJid] }
            );
        }

        // Realizar el sorteo del 50%
        const coinFlip = Math.random() < 0.5;

        let replyMessage = '';
        let replyMentions = [senderJid, targetJid];
        
        if (coinFlip) {
            // El robo salió mal, el ladrón pierde entre 2k y 10k
            const penalty = Math.floor(Math.random() * (10000 - 2000 + 1)) + 2000;
            const penaltyReal = Math.min(penalty, robber.money || 0);

            if (!robber.money || robber.money < 1 || penaltyReal <= 0) {
                return await message.reply(`😅 Intentaste robar a *@${victimNumber}* pero fallaste y no tenías dinero para pagar la multa.`, { mentions: [targetJid] });
            }

            robber.money -= penaltyReal;
            victim.money += penaltyReal;

            replyMessage = `❌ ¡El robo salió mal! *@${victimNumber}* te ha quitado *$${penaltyReal.toLocaleString()}* monedas.`;
        } else {
            // El robo fue un éxito, roba entre 2k y 10k
            const amountToSteal = Math.min(
                Math.floor(Math.random() * (10000 - 2000 + 1)) + 2000,
                victim.money
            );
            victim.money -= amountToSteal;
            robber.money = (robber.money || 0) + amountToSteal;

            replyMessage = `💰 ¡Has robado *$${amountToSteal.toLocaleString()}* monedas con éxito a *@${victimNumber}*!`;
        }

        // Guardar cambios en la base de datos
        global.db.setUser(victimNumber, victim);
        global.db.setUser(senderNumber, robber);

        await message.reply(replyMessage, { mentions: replyMentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al robar:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al intentar robar. Revisa el registro de errores para más detalles.');
    }
};

handler.help = ['robar @usuario', 'rob @usuario'];
handler.tags = ['economy'];
handler.command = /^(robar|rob|steal)$/i;

module.exports = handler;
handler.apodo = true;
handler.group = false;