let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Asegurar valores numéricos
        user.money = Number(user.money) || 0;
        user.bank = Number(user.bank) || 0;

        // Calcular total
        const total = user.money + user.bank;

        // Formatear el mensaje con separador de miles
        let saldoInfo = `*💰 Tu saldo actual es: ${user.money.toLocaleString()} Monedas*\n` +
                        `*🏦 Tu saldo en el banco es: ${user.bank.toLocaleString()} Monedas*\n` +
                        `*💎 Total: ${total.toLocaleString()} Monedas*`;

        return await message.reply(saldoInfo);
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al obtener saldo:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al obtener tu saldo.');
    }
};

handler.help = [
    'saldo',
    'balance',
    'bal',
    'cartera',
    'wallet',
    'dinero',
    'coins',
    'coin',
    'diner',
    'money'
];
handler.tags = ['economy'];
handler.command = /^(saldo|balance|bal|dinero|cartera|wallet|money)$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;