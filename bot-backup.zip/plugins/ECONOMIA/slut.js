let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastSlut: 0,
                totalSlutJobs: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        user.lastSlut = Number(user.lastSlut) || 0;

        const cooldown = 30 * 1000;
        const now = Date.now();

        if (now - user.lastSlut < cooldown) {
            const restante = Math.ceil((cooldown - (now - user.lastSlut)) / 1000);
            return await message.reply(`⏳ Espera *${restante} segundos* antes de volver a salir a la calle.`);
        }

        // Lista de clientes en tono de rol serio
        const clientes = [
            { nombre: "empresario de noche", pago: 950 },
            { nombre: "viajero solitario", pago: 600 },
            { nombre: "coleccionista excéntrico", pago: 1200 },
            { nombre: "hombre misterioso del bar", pago: 850 },
            { nombre: "político discreto", pago: 1300 },
            { nombre: "turista con dinero", pago: 700 },
            { nombre: "ejecutivo estresado", pago: 1100 },
            { nombre: "artista famoso", pago: 1400 },
            { nombre: "propietario de un club", pago: 1600 },
            { nombre: "empresario extranjero", pago: 2000 },
            { nombre: "agente encubierto", pago: 1000 },
            { nombre: "cliente habitual", pago: 500 },
        ];

        const cliente = clientes[Math.floor(Math.random() * clientes.length)];
        const ganancia = cliente.pago + Math.floor(Math.random() * 150);

        user.money += ganancia;
        user.lastSlut = now;
        user.totalSlutJobs = (user.totalSlutJobs || 0) + 1;

        global.db.setUser(senderNumber, user);

        // Mensaje decorado
        const decorado = [
            `Tuviste un encuentro con un *${cliente.nombre}*...`,
            "✨ Has ganado *$" + ganancia + "* prostituyéndote.",
        ].join('\n');

        return await message.reply(decorado);

    } catch (error) {
        console.error('[ERROR] Error en comando slut:', error);
        return await message.reply('❌ Hubo un problema al ejecutar el comando.');
    }
};

handler.help = ['slut'];
handler.tags = ['economy'];
handler.command = /^slut$/i;

module.exports = handler;
handler.group = true;
handler.apodo = true;