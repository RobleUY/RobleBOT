let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastSlut: 0,
                totalSlutJobs: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        user.lastSlut = Number(user.lastSlut) || 0;

        const cooldown = 60 * 1000;
        const now = Date.now();

        if (now - user.lastSlut < cooldown) {
            const restante = Math.ceil((cooldown - (now - user.lastSlut)) / 1000);
            return await message.reply(`⏳ Espera *${restante} segundos* antes de volver a salir a la calle.`);
        }

        const ganancias = [500, 600, 700, 850, 950, 1000];
        const base = ganancias[Math.floor(Math.random() * ganancias.length)];
        const ganancia = base + Math.floor(Math.random() * 150);

        // Aplicar multiplicador según respeto actual (antes de sumar +1)
        const respeto = Number(user.respeto) || 0;
        const finalGain = Math.floor(ganancia * (1 + respeto / 100));

        user.money += finalGain;
        user.lastSlut = now;
        user.totalSlutJobs = (user.totalSlutJobs || 0) + 1;
        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;

        global.db.setUser(senderNumber, user);

        return await message.reply(`_Fuiste a prostituirte y ganaste_ *$${finalGain.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`);

    } catch (error) {
        console.error('[ERROR] Error en comando slut:', error);
        return await message.reply('❌ Hubo un problema al ejecutar el comando.');
    }
};

handler.help = ['slut'];
handler.tags = ['economy'];
handler.command = /^slut$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;