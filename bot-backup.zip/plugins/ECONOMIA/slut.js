const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastSlut: 0,
                totalSlutJobs: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        user.lastSlut = Number(user.lastSlut) || 0;

        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        const cooldown = Math.floor(60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (now - user.lastSlut < cooldown) {
            const restante = Math.ceil((cooldown - (now - user.lastSlut)) / 1000);
            return await message.reply(`⏳ Espera *${restante} segundos* antes de volver a salir a la calle.`);
        }

        const ganancias = [200, 300, 400, 500, 600, 700, 850, 950, 1000];
        const base = ganancias[Math.floor(Math.random() * ganancias.length)];
        const ganancia = base + Math.floor(Math.random() * 50);

        // Aplicar multiplicador según respeto actual (antes de sumar +1)
        const respeto = Number(user.respeto) || 0;
        const finalGain = Math.floor(ganancia * (1 + respeto / 100));
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const finalPremiumGain = Math.floor(finalGain * multiplier);

        user.money += finalPremiumGain;
        user.lastSlut = now;
        user.totalSlutJobs = (user.totalSlutJobs || 0) + 1;
        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;

        global.db.setUser(senderNumber, user);

        let response = `_Fuiste a prostituirte y ganaste_ *$${finalPremiumGain.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando slut:', error);
        return await message.reply('❌ Hubo un problema al ejecutar el comando.');
    }
};

handler.help = ['slut'];
handler.tags = ['economy'];
handler.command = /^slut$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;