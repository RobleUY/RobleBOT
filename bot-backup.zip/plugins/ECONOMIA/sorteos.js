// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

let handler = async (message, { text }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        if (!global.conn) {
            return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
        }

        // Verificar que se haya proporcionado una cantidad
        if (!text || text.trim() === '') {
            return await message.reply('❌ Debes especificar una cantidad, porcentaje o "all".\n\n*Uso:* .sorteo [cantidad/porcentaje%/all]\n*Ejemplos:*\n.sorteo 100000\n.sorteo 50%\n.sorteo all');
        }

        // Obtener el número del remitente
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener datos del usuario que hace el sorteo
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                bank: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Asegurar que el dinero esté definido
        user.money = Number(user.money) || 0;

        let cantidad;
        const textLower = text.trim().toLowerCase();
        
        // Verificar si es "all"
        if (textLower === 'all') {
            cantidad = user.money;
        }
        // Verificar si es porcentaje
        else if (textLower.includes('%')) {
            const percentageMatch = textLower.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!percentageMatch) {
                return await message.reply('❌ Formato de porcentaje inválido. Usa por ejemplo: 50% o 25%');
            }
            
            const percentage = parseFloat(percentageMatch[1]);
            
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                return await message.reply('❌ El porcentaje debe estar entre 1% y 100%.');
            }
            
            // Calcular el monto basado en el porcentaje y redondear
            cantidad = Math.floor((user.money * percentage) / 100);
        }
        // Si es un número directo
        else {
            cantidad = parseInt(textLower);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ Debes especificar una cantidad válida mayor a 0, un porcentaje válido o "all".\n*Ejemplos:*\n.sorteo 100000\n.sorteo 50%\n.sorteo all');
            }
        }

        // Asegurar que la cantidad sea positiva y entera
        cantidad = Math.max(0, Math.floor(cantidad));

        if (cantidad === 0) {
            return await message.reply('❌ No tienes dinero en efectivo para sortear o el monto calculado es 0.');
        }

        // Verificar que el usuario tenga suficiente dinero (solo efectivo, no banco)
        if (user.money < cantidad) {
            return await message.reply(`❌ No tienes suficiente dinero en efectivo.\n\n💰 Tu saldo: $${user.money.toLocaleString()}\n💸 Necesitas: $${cantidad.toLocaleString()}`);
        }

        // Obtener metadatos del grupo y participantes
        const groupMetadata = await global.conn.groupMetadata(message.from);
        const participants = groupMetadata.participants.map(p => p.id);

        // Filtrar participantes excluyendo al que hace el sorteo
        const eligibleParticipants = participants.filter(participant => {
            const participantNumber = normalizeNumber(participant);
            return participantNumber !== normalizeNumber(senderNumber);
        });

        // Verificar que haya al menos un participante elegible
        if (eligibleParticipants.length === 0) {
            return await message.reply('❌ No hay otros participantes en el grupo para el sorteo.');
        }

        // Seleccionar un ganador aleatorio
        const randomIndex = Math.floor(Math.random() * eligibleParticipants.length);
        const winnerJid = eligibleParticipants[randomIndex];
        const winnerNumber = normalizeNumber(winnerJid);

        // Obtener o crear datos del ganador
        let winner = global.db.getUser(winnerNumber);
        
        if (!winner) {
            winner = {
                money: 0,
                bank: 0
            };
        }

        // Realizar la transacción
        user.money -= cantidad;
        winner.money = (winner.money || 0) + cantidad;

        // Guardar los cambios en la base de datos
        global.db.setUser(senderNumber, user);
        global.db.setUser(winnerNumber, winner);

        // Crear mensaje de ganador
        const mensajeSorteo = `🎉 *¡SORTEO REALIZADO!* 🎉\n\n` +
                             `🎁 Cantidad sorteada: *$${cantidad.toLocaleString()}* monedas\n\n` +
                             `🏆 *¡GANADOR!*\n` +
                             `@${winnerNumber}\n\n` +
                             `💰 Ha recibido *$${cantidad.toLocaleString()}* monedas\n\n` +
                             `✨ ¡Felicidades!`;

        // Enviar mensaje con mención al ganador
        await message.reply(mensajeSorteo, { mentions: [winnerJid] });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al realizar sorteo:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al realizar el sorteo.');
    }
};

handler.help = ['sorteo cantidad/porcentaje%/all'];
handler.tags = ['economy'];
handler.command = /^(sorteo|draw|sorteos)$/i;
handler.group = false;
handler.apodo = true;
module.exports = handler;