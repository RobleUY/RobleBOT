const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn, args }) => {
    try {
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en grupos.');
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = normalizeNumber(senderJid);
        const botNumber = normalizeNumber(conn.user.id);

        if (!args[0]) {
            return await message.reply(
                '❌ Debes especificar la cantidad a sortear.\n\n' +
                'Ejemplos:\n' +
                '*.sorteo 500*\n' +
                '*.sorteo 50%*\n' +
                '*.sorteo all*'
            );
        }

        // Obtener datos del usuario que realiza el sorteo
        let senderUser = global.db.getUser(senderNumber);
        if (!senderUser) {
            return await message.reply('❌ Ocurrió un error al obtener tus datos.');
        }

        senderUser.money = Number(senderUser.money) || 0;
        const amountText = args[0].toLowerCase();
        let amount = 0;

        // Validar y calcular el monto
        if (amountText === 'all') {
            amount = senderUser.money;
        } else if (amountText.includes('%')) {
            const percentageMatch = amountText.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!percentageMatch) {
                return await message.reply('❌ Formato de porcentaje inválido. Ejemplo: 50%');
            }
            const percentage = parseFloat(percentageMatch[1]);
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                return await message.reply('❌ El porcentaje debe estar entre 1% y 100%.');
            }
            amount = Math.floor((senderUser.money * percentage) / 100);
        } else {
            amount = parseInt(amountText);
            if (isNaN(amount) || amount <= 0) {
                return await message.reply('❌ La cantidad debe ser un número positivo, un porcentaje o "all".');
            }
        }

        amount = Math.max(0, Math.floor(amount));

        if (amount === 0) {
            return await message.reply('❌ No tienes suficiente saldo o el monto calculado es 0.');
        }

        if (senderUser.money < amount) {
            return await message.reply(
                `❌ No tienes suficientes monedas para el sorteo.\n` +
                `💰 Tu saldo: *${senderUser.money.toLocaleString()}*\n` +
                `📤 Intentaste sortear: *${amount.toLocaleString()}*`
            );
        }

        // Obtener participantes del grupo y filtrar al remitente y al bot
        const metadata = await conn.groupMetadata(message.from);
        const candidates = metadata.participants
            .map(p => p.id)
            .filter(jid => {
                const num = normalizeNumber(jid);
                return num !== senderNumber && num !== botNumber;
            });

        if (candidates.length === 0) {
            return await message.reply('⚠️ No hay suficientes miembros en el grupo para realizar el sorteo.');
        }

        // Seleccionar ganador aleatorio
        const winnerJid = candidates[Math.floor(Math.random() * candidates.length)];
        const winnerNumber = normalizeNumber(winnerJid);

        let winnerUser = global.db.getUser(winnerNumber);
        if (!winnerUser) {
            return await message.reply('❌ Ocurrió un error al procesar al ganador.');
        }

        winnerUser.money = Number(winnerUser.money) || 0;

        // Ejecutar transferencia
        senderUser.money -= amount;
        winnerUser.money += amount;

        global.db.setUser(senderNumber, senderUser);
        global.db.setUser(winnerNumber, winnerUser);

        // Obtener apodo del ganador si existe
        const winnerApodo = (winnerUser?.apodo || '').trim();
        const winnerDisplay = winnerApodo ? `${winnerApodo} (@${winnerNumber})` : `@${winnerNumber}`;

        await message.reply(
            `🎉 *¡SORTEO REALIZADO!* 🎉\n\n` +
            `🎁 *Premio:* ${amount.toLocaleString()} monedas\n` +
            `🏆 *Ganador:* ${winnerDisplay}\n\n` +
            `💰 *Saldo restante de quien sorteó:* ${senderUser.money.toLocaleString()}`,
            { mentions: [winnerJid] }
        );

    } catch (error) {
        console.error('[ERROR EN SORTEO]:', error);
        await message.reply('❌ Ocurrió un error al ejecutar el sorteo.');
    }
};

handler.help = ['sorteo <cantidad/porcentaje%/all>'];
handler.tags = ['economy', 'group'];
handler.command = /^(sorteo|sortear)$/i;
handler.group = true;

module.exports = handler;