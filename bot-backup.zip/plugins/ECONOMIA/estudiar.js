// --- Mapa en memoria para cooldowns ---
const cooldowns = new Map();

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        // --- Cooldown en memoria (15 segundos) ---
        const cooldown = 15 * 1000;
        const now = Date.now();

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);
            if (remaining > 0) {
                const segundos = Math.ceil(remaining / 1000);
                return await message.reply(`📚 Debes esperar *${segundos} segundos* antes de volver a estudiar.`);
            }
        }

        // Materias con recompensas
        const materias = [
            { nombre: "Matemáticas", pago: 1200 },
            { nombre: "Historia", pago: 900 },
            { nombre: "Física", pago: 1500 },
            { nombre: "Química", pago: 1400 },
            { nombre: "Programación", pago: 2000 },
            { nombre: "Economía", pago: 1300 },
            { nombre: "Literatura", pago: 1000 },
            { nombre: "Arte", pago: 800 },
            { nombre: "Idiomas", pago: 1100 },
            { nombre: "Biología", pago: 1205 },
        ];

        // Materia aleatoria
        const materia = materias[Math.floor(Math.random() * materias.length)];

        // Ganancia
        user.money += materia.pago;
        global.db.setUser(senderNumber, user);

        // Guardar tiempo actual en memoria
        cooldowns.set(senderNumber, now);
        setTimeout(() => cooldowns.delete(senderNumber), cooldown);

        return await message.reply(
            `🎓 Estudiaste *${materia.nombre}* y ganaste *$${materia.pago}* por tu esfuerzo.\n\n💵 Dinero actual: *$${user.money}*`
        );

    } catch (error) {
        console.error('[ERROR] Error en comando estudiar:', error);
        return await message.reply('❌ Ocurrió un error al intentar estudiar.');
    }
};

handler.help = ['estudiar'];
handler.tags = ['economy'];
handler.command = /^estudiar|study$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;