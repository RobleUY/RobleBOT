const premium = require('../../premium');

// --- Mapa en memoria para cooldowns ---
const cooldowns = new Map();

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        // --- Cooldown en memoria (60 segundos) ---
        const cooldown = Math.floor(60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);
            if (remaining > 0) {
                const segundos = Math.ceil(remaining / 1000);
                return await message.reply(`📚 Debes esperar *${segundos} segundos* antes de volver a estudiar.`);
            }
        }

        // Materias con recompensas
        const materias = [
            { nombre: "Matemáticas", pago: 400 },
            { nombre: "Historia", pago: 370 },
            { nombre: "Física", pago: 500 },
            { nombre: "Química", pago: 425 },
            { nombre: "Programación", pago: 550 },
            { nombre: "Economía", pago: 600 },
            { nombre: "Literatura", pago: 500 },
            { nombre: "Arte", pago: 100 },
            { nombre: "Idiomas", pago: 400 },
            { nombre: "Biología", pago: 200 },
        ];

        // Materia aleatoria
        const materia = materias[Math.floor(Math.random() * materias.length)];

        // Ganancia base
        const basePago = materia.pago;
        const respeto = Number(user.respeto) || 0;
        const pagoFinal = Math.floor(basePago * (1 + respeto / 100));
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const pagoPremium = Math.floor(pagoFinal * multiplier);

        user.money += pagoPremium;
        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;
        global.db.setUser(senderNumber, user);

        // Guardar tiempo actual en memoria
        cooldowns.set(senderNumber, now);
        setTimeout(() => cooldowns.delete(senderNumber), cooldown);

        let response = `_Estudiaste_ *${materia.nombre}* _y ganaste_ *$${pagoPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando estudiar:', error);
        return await message.reply('❌ Ocurrió un error al intentar estudiar.');
    }
};

handler.help = ['estudiar'];
handler.tags = ['economy'];
handler.command = /^estudiar|study$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;