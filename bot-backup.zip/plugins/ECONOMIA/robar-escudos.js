let handler = async (message, { conn }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ Ocurrió un error al procesar el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        const user = global.db.getUser(senderNumber);

        if (!user) {
            return await message.reply('❌ Ocurrió un error al obtener tus datos. Asegúrate de estar registrado en la base de datos.');
        }

        // Inicializar escudos si no existen
        if (typeof user.escudosAntiRobos === 'undefined') {
            user.escudosAntiRobos = 0;
            global.db.setUser(senderNumber, user);
        }

        const escudosActuales = user.escudosAntiRobos || 0;
        const saldoTotal = (user.money || 0) + (user.bank || 0);
        const precioEscudo = Math.floor(saldoTotal * 0.15);
        const saldoMinimo = 10000000; // 10 millones
        
        let mensaje = `🛡️ *ESCUDOS ANTI-ROBOS*\n\n` +
            `Escudos disponibles: *${escudosActuales}/3*\n\n`;

        if (saldoTotal >= saldoMinimo) {
            mensaje += `💰 Precio: *${precioEscudo.toLocaleString()}* monedas (15% de tu saldo)\n` +
                `📊 Saldo total: *${saldoTotal.toLocaleString()}* monedas\n\n` +
                `💡 Usa *escudobuy* para comprar.`;
        } else {
            mensaje += `🔒 Requieres *${saldoMinimo.toLocaleString()}* monedas para desbloquear.\n` +
                `📊 Tu saldo: *${saldoTotal.toLocaleString()}* monedas`;
        }
        
        return await message.reply(mensaje);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando de escudos:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al procesar el comando. Revisa el registro de errores para más detalles.');
    }
};

handler.help = ['escudos'];
handler.tags = ['economy'];
handler.command = /^(escudos)$/i;

module.exports = handler;
handler.group = true;