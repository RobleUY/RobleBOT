let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user || typeof user.money === 'undefined') {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        if (typeof user.bank === 'undefined') {
            user.bank = 0;
            global.db.setUser(senderNumber, user);
        }

        user.money = Number(user.money) || 0;
        user.bank = Number(user.bank) || 0;

        if (!text) {
            return await message.reply(
                `❌ Por favor, especifica la cantidad, porcentaje o usa 'all' para todo.\n\n📥 *DEPOSITAR:*\n.depositar 1000\n.deposit 1000\n.d 1000\n.dep 1000\n.deposito 50%\n.depositar all\n\n📤 *RETIRAR:*\n.retirar 500\n.retirar 25%\n.r 500\n.reti 500\n.retire 500\n.retiro all\n\n💰 *Tu saldo actual:*\n🏦 Banco: $${user.bank}\n💵 Efectivo: $${user.money}`
            );
        }

        let command = message.body.toLowerCase().split(' ')[0].slice(1);

        // Normalizar comandos de DEPOSITAR
        if (['d', 'dep', 'deposit', 'deposito'].includes(command)) {
            command = 'depositar';
        }

        // Normalizar comandos de RETIRAR
        if (['r', 'reti', 'retire', 'retiro'].includes(command)) {
            command = 'retirar';
        }

        let amount;
        const textLower = text.toLowerCase();
        
        // Verificar si es porcentaje
        if (textLower.includes('%')) {
            const percentageMatch = textLower.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!percentageMatch) {
                return await message.reply('❌ Formato de porcentaje inválido. Usa por ejemplo: 50% o 25%');
            }
            
            const percentage = parseFloat(percentageMatch[1]);
            
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                return await message.reply('❌ El porcentaje debe estar entre 1% y 100%.');
            }
            
            // Calcular el monto basado en el porcentaje y redondear
            if (command === 'depositar') {
                amount = Math.floor((user.money * percentage) / 100);
            } else {
                amount = Math.floor((user.bank * percentage) / 100);
            }
        } else if (textLower === 'all') {
            amount = command === 'depositar' ? user.money : user.bank;
        } else {
            amount = parseInt(text);
            if (isNaN(amount) || amount <= 0) {
                return await message.reply('❌ Por favor, ingresa una cantidad válida mayor a 0, un porcentaje válido o usa "all".');
            }
        }

        // Asegurar que el monto sea positivo y entero
        amount = Math.max(0, Math.floor(amount));

        if (command === 'depositar') {
            if (amount === 0) {
                return await message.reply('❌ No tienes dinero en efectivo para depositar o el monto calculado es 0.');
            }

            if (amount > user.money) {
                return await message.reply(
                    `❌ No tienes suficiente dinero para depositar $${amount}.\n💵 Tu saldo en efectivo es: $${user.money}`
                );
            }

            user.money -= amount;
            user.bank += amount;

            const saved = global.db.setUser(senderNumber, user);
            if (!saved) return await message.reply('❌ Ocurrió un error al guardar la transacción.');

            return await message.reply(
                `✅ *Depósito exitoso*\n\n💰 Depositado: $${amount}\n🏦 Saldo en banco: $${user.bank}\n💵 Dinero en efectivo: $${user.money}`
            );
        }

        if (command === 'retirar') {
            if (amount === 0) {
                return await message.reply('❌ No tienes dinero en el banco para retirar o el monto calculado es 0.');
            }

            if (amount > user.bank) {
                return await message.reply(
                    `❌ No tienes suficiente dinero en el banco para retirar $${amount}.\n🏦 Tu saldo en banco es: $${user.bank}`
                );
            }

            user.bank -= amount;
            user.money += amount;

            const saved = global.db.setUser(senderNumber, user);
            if (!saved) return await message.reply('❌ Ocurrió un error al guardar la transacción.');

            return await message.reply(
                `✅ *Retiro exitoso*\n\n💰 Retirado: $${amount}\n🏦 Saldo en banco: $${user.bank}\n💵 Dinero en efectivo: $${user.money}`
            );
        }
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando banco:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al procesar tu solicitud.');
    }
};

handler.help = [
    'depositar <cantidad/porcentaje%/all>',
    'd <cantidad>',
    'dep <cantidad>',
    'deposit <cantidad>',
    'deposito <cantidad>',
    'retirar <cantidad/porcentaje%/all>',
    'r <cantidad>',
    'reti <cantidad>',
    'retire <cantidad>',
    'retiro <cantidad>'
];
handler.tags = ['economy'];
handler.command = /^(depositar|d|dep|deposit|deposito|retirar|r|reti|retire|retiro)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;