let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
                lastHunt: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // --- FIX: asegurar que lastHunt es número ---
        user.lastHunt = Number(user.lastHunt) || 0;

        // Cooldown de 30 segundos
        const cooldown = 30 * 1000;
        const now = Date.now();

        if (now - user.lastHunt < cooldown) {
            const restante = Math.ceil((cooldown - (now - user.lastHunt)) / 1000);
            return await message.reply(`⏳ Debes esperar *${restante} segundos* para volver a cazar.`);
        }

        // Lista de animales con precios
        const animales = [
            { nombre: "Conejo", precio: 50 },
            { nombre: "Zorro", precio: 120 },
            { nombre: "Ciervo", precio: 300 },
            { nombre: "Jabalí", precio: 450 },
            { nombre: "Pato salvaje", precio: 80 },
            { nombre: "Oso pardo", precio: 800 },
            { nombre: "Lobo", precio: 500 },
            { nombre: "Mapache", precio: 150 },
            { nombre: "Serpiente", precio: 90 },
            { nombre: "Puma", precio: 900 },
            { nombre: "Águila", precio: 700 },
            { nombre: "Zorrillo", precio: 60 },
            { nombre: "Tortuga", precio: 110 },
            { nombre: "Iguana", precio: 75 },
            { nombre: "Jaguar", precio: 1200 },
            { nombre: "Lechuza", precio: 95 },
            { nombre: "Búho", precio: 130 },
            { nombre: "Tiburón pequeño", precio: 1000 },
            { nombre: "Rana", precio: 40 },
            { nombre: "Murciélago", precio: 55 },
            { nombre: "Cocodrilo", precio: 1500 },
            { nombre: "Cabra montés", precio: 350 },
            { nombre: "Jirafa", precio: 2000 },
            { nombre: "Elefante", precio: 5000 },
            { nombre: "Hipopótamo", precio: 4000 },
            { nombre: "Camello", precio: 1800 },
            { nombre: "Avestruz", precio: 950 },
            { nombre: "Mono", precio: 400 },
            { nombre: "Tigre", precio: 2500 },
            { nombre: "León", precio: 2700 },
            { nombre: "Pantera", precio: 2200 },
            { nombre: "Cebra", precio: 1600 },
            { nombre: "Gacela", precio: 800 },
            { nombre: "Panda", precio: 3500 },
        ];

        // Animal aleatorio
        const animal = animales[Math.floor(Math.random() * animales.length)];

        // Dinero ganado
        user.money += animal.precio;

        // --- FIX: guardar lastHunt actualizado ---
        user.lastHunt = now;
        global.db.setUser(senderNumber, user);

        return await message.reply(
            `🎯 Cazaste 1 *${animal.nombre}* y conseguiste *$${animal.precio}*.\n\n💵 Dinero actual: *$${user.money}*`
        );

    } catch (error) {
        console.error('[ERROR] Error en comando cazar:', error);
        return await message.reply('❌ Ocurrió un error al intentar cazar.');
    }
};

handler.help = ['cazar'];
handler.tags = ['economy'];
handler.command = /^cazar$/i;

module.exports = handler;
handler.group = true;
