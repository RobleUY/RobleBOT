// --- Mapa en memoria para cooldowns ---
const cooldowns = new Map();
const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        // --- Cooldown en memoria (60 segundos, mitad para premium) ---
        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        const cooldown = Math.floor(60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);
            if (remaining > 0) {
                const segundos = Math.ceil(remaining / 1000);
                return await message.reply(`⏳ Debes esperar *${segundos} segundos* para volver a cazar.`);
            }
        }

        // lista de animales y el precio (máximo 1000)
        const animales = [
            { nombre: "Furro", precio: 1000 },
            { nombre: "Conejo", precio: 50 },
            { nombre: "Zorro", precio: 120 },
            { nombre: "Ciervo", precio: 300 },
            { nombre: "Jabalí", precio: 450 },
            { nombre: "Pato salvaje", precio: 80 },
            { nombre: "Oso pardo", precio: 800 },
            { nombre: "Lobo", precio: 500 },
            { nombre: "Mapache", precio: 150 },
            { nombre: "Serpiente", precio: 90 },
            { nombre: "Puma", precio: 900 },
            { nombre: "Águila", precio: 700 },
            { nombre: "Zorrillo", precio: 60 },
            { nombre: "Tortuga", precio: 110 },
            { nombre: "Iguana", precio: 75 },
            { nombre: "Jaguar", precio: 1000 },
            { nombre: "Lechuza", precio: 95 },
            { nombre: "Búho", precio: 130 },
            { nombre: "Tiburón pequeño", precio: 1000 },
            { nombre: "Rana", precio: 40 },
            { nombre: "Murciélago", precio: 55 },
            { nombre: "Cocodrilo", precio: 1000 },
            { nombre: "Cabra montés", precio: 350 },
            { nombre: "Jirafa", precio: 1000 },
            { nombre: "Elefante", precio: 1000 },
            { nombre: "Hipopótamo", precio: 1000 },
            { nombre: "Camello", precio: 800 },
            { nombre: "Avestruz", precio: 950 },
            { nombre: "Mono", precio: 400 },
            { nombre: "Tigre", precio: 1000 },
            { nombre: "León", precio: 1000 },
            { nombre: "Pantera", precio: 900 },
            { nombre: "Cebra", precio: 800 },
            { nombre: "Gacela", precio: 800 },
            { nombre: "Panda", precio: 1000 },
        ];

        // Animal aleatorio
        const animal = animales[Math.floor(Math.random() * animales.length)];

        // Aplicar multiplicador según respeto actual (antes de sumar +1)
        const respeto = Number(user.respeto) || 0;
        const gananciaFinal = Math.floor(animal.precio * (1 + respeto / 100));
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        // Dinero ganado
        user.money += gananciaPremium;
        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;
        global.db.setUser(senderNumber, user);

        // Guardar el tiempo actual en memoria
        cooldowns.set(senderNumber, now);

        // Eliminar del mapa después del cooldown (para no llenar la RAM)
        setTimeout(() => cooldowns.delete(senderNumber), cooldown);

        let response = `_Cazaste 1_ *${animal.nombre}* _y ganaste_ *$${gananciaPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando cazar:', error);
        return await message.reply('❌ Ocurrió un error al intentar cazar.');
    }
};

handler.help = ['cazar'];
handler.tags = ['economy'];
handler.command = /^cazar|hunt$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;