const db = require('../../database.js');

// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

let handler = async (message, { text }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        if (!global.conn) {
            return await message.reply('❌ El bot no está conectado correctamente. Inténtalo de nuevo.');
        }

        // Obtener metadatos del grupo para obtener los participantes
        const groupMetadata = await global.conn.groupMetadata(message.from);
        const participants = groupMetadata.participants.map(p => p.id);

        // Crear un array con los usuarios que tienen deudas
        let usersWithDebt = [];

        for (let participant of participants) {
            const userNumber = normalizeNumber(participant);
            const user = db.getUser(userNumber);

            if (user && user.prestamo && user.prestamo.activo && user.prestamo.deuda > 0) {
                const diasTranscurridos = Math.floor((Date.now() - user.prestamo.fechaPrestamo) / (1000 * 60 * 60 * 24));
                
                usersWithDebt.push({
                    jid: participant,
                    number: userNumber,
                    deuda: user.prestamo.deuda,
                    montoOriginal: user.prestamo.monto,
                    dias: diasTranscurridos
                });
            }
        }

        // Ordenar por deuda de mayor a menor
        usersWithDebt.sort((a, b) => b.deuda - a.deuda);

        // Verificar si hay usuarios con deudas
        if (usersWithDebt.length === 0) {
            return await message.reply('✅ ¡No hay deudores en este grupo! Todos están al día. 🎉');
        }

        // Crear el mensaje con la lista de deudores
        let deudoresText = '*💸 LISTA DE DEUDORES DEL GRUPO 💸*\n\n';
        deudoresText += `📊 Total de deudores: ${usersWithDebt.length}\n\n`;

        usersWithDebt.forEach((user, index) => {
            deudoresText += `${index + 1}. @${user.number}\n`;
            deudoresText += `   💸 Deuda: $${user.deuda.toLocaleString()}\n`;
        });

        deudoresText += `\n💡 *Ayuda a un amigo pagando su deuda:*\n`;
        deudoresText += `.prestamo pagar <cantidad> @user\n`;
        deudoresText += `.prestamo pagar todo @user`;

        // Crear array de JIDs para las menciones
        const mentionJids = usersWithDebt.map(user => user.jid);

        // Enviar el mensaje con las menciones
        await message.reply(deudoresText, { mentions: mentionJids });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al obtener deudores:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al obtener la lista de deudores.');
    }
};

handler.help = ['deudores'];
handler.tags = ['economia', 'dinero'];
handler.command = /^(deudores|debtors)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;