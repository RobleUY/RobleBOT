let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                totalCrimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        // Cooldown en memoria
        global.crimeCooldown = global.crimeCooldown || {};

        const cooldown = 30 * 1000;
        const now = Date.now();

        if (
            global.crimeCooldown[senderNumber] &&
            now - global.crimeCooldown[senderNumber] < cooldown
        ) {
            const restante = Math.ceil(
                (cooldown - (now - global.crimeCooldown[senderNumber])) / 1000
            );

            return await message.reply(
                `⏳ Debes esperar *${restante} segundos* antes de volver a cometer un crimen.`
            );
        }

        const crimes = [
            {
                texto: '🔫 Asaltaste una tienda abandonada',
                min: 500,
                max: 1800
            },
            {
                texto: '🏦 Robaste un cajero automático',
                min: 1200,
                max: 3500
            },
            {
                texto: '🚗 Vendiste autos robados en el mercado negro',
                min: 2000,
                max: 5000
            },
            {
                texto: '💻 Hackeaste cuentas bancarias',
                min: 1500,
                max: 4200
            },
            {
                texto: '👜 Le robaste la cartera a un millonario',
                min: 800,
                max: 2600
            },
            {
                texto: '💎 Entraste a una joyería',
                min: 2500,
                max: 6500
            },
            {
                texto: '🚛 Secuestraste un camión con mercancía',
                min: 3000,
                max: 7000
            },
            {
                texto: '🕵️ Hiciste una estafa por internet',
                min: 1000,
                max: 3000
            },
            {
                texto: '🏍️ Robaste motos de lujo',
                min: 1700,
                max: 4500
            },
            {
                texto: '🏪 Entraste a robar un supermercado',
                min: 1300,
                max: 3900
            }
        ];

        const crime = crimes[Math.floor(Math.random() * crimes.length)];

        const fallo = Math.random() < 0.20;

        // Guardar cooldown
        global.crimeCooldown[senderNumber] = now;

        if (fallo) {
            const perdida = Math.floor(Math.random() * 2500) + 500;

            user.money = Math.max(0, user.money - perdida);

            global.db.setUser(senderNumber, user);

            return await message.reply(
                `🚔 Intentaste cometer un crimen pero la policía te atrapó.\n` +
                `💸 Pagaste una multa de *$${perdida.toLocaleString()}*\n` +
                `💰 Dinero actual: *$${user.money.toLocaleString()}*`
            );
        }

        const ganancia =
            Math.floor(Math.random() * (crime.max - crime.min + 1)) + crime.min;

        user.money += ganancia;
        user.totalCrimes = (user.totalCrimes || 0) + 1;

        global.db.setUser(senderNumber, user);

        return await message.reply(
            `${crime.texto}\n` +
            `💰 Ganaste *$${ganancia.toLocaleString()}*\n` +
            `🏦 Saldo actual: *$${user.money.toLocaleString()}*`
        );

    } catch (error) {
        console.error('[ERROR] Error en comando crime:', error);
        return await message.reply('❌ Hubo un problema al ejecutar el comando.');
    }
};

handler.help = ['crime', 'crimen'];
handler.tags = ['economy'];
handler.command = /^(crime|crimen)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;