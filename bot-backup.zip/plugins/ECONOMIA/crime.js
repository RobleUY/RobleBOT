const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                totalCrimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        // Cooldown en memoria
        global.crimeCooldown = global.crimeCooldown || {};

        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        const cooldown = Math.floor(60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (
            global.crimeCooldown[senderNumber] &&
            now - global.crimeCooldown[senderNumber] < cooldown
        ) {
            const restante = Math.ceil(
                (cooldown - (now - global.crimeCooldown[senderNumber])) / 1000
            );

            return await message.reply(
                `⏳ Debes esperar *${restante} segundos* antes de volver a cometer un crimen.`
            );
        }

        const crimes = [
            {
                texto: '🔫 Asaltaste una tienda abandonada',
                min: 200,
                max: 1000
            },
            {
                texto: '🏦 Robaste un cajero automático',
                min: 200,
                max: 1000
            },
            {
                texto: '🚗 Vendiste autos robados en el mercado negro',
                min: 200,
                max: 1000
            },
            {
                texto: '💻 Hackeaste cuentas bancarias',
                min: 200,
                max: 1000
            },
            {
                texto: '👜 Le robaste la cartera a un millonario',
                min: 200,
                max: 1000
            },
            {
                texto: '💎 Entraste a una joyería',
                min: 200,
                max: 1000
            },
            {
                texto: '🚛 Secuestraste un camión con mercancía',
                min: 200,
                max: 1000
            },
            {
                texto: '🕵️ Hiciste una estafa por internet',
                min: 200,
                max: 1000
            },
            {
                texto: '🏍️ Robaste motos de lujo',
                min: 200,
                max: 1000
            },
            {
                texto: '🏪 Entraste a robar un supermercado',
                min: 200,
                max: 1000
            }
        ];

        const crime = crimes[Math.floor(Math.random() * crimes.length)];

        const fallo = Math.random() < 0.20;

        // Guardar cooldown
        global.crimeCooldown[senderNumber] = now;

        if (fallo) {
            const perdida = Math.floor(Math.random() * 2500) + 500;

            user.money = Math.max(0, user.money - perdida);

            global.db.setUser(senderNumber, user);

            return await message.reply(
                `🚔 Intentaste cometer un crimen pero la policía te atrapó.\n` +
                `💸 Pagaste una multa de *$${perdida.toLocaleString()}*\n` +
                `💰 Dinero actual: *$${user.money.toLocaleString()}*`
            );
        }

        const ganancia =
            Math.floor(Math.random() * (crime.max - crime.min + 1)) + crime.min;

        // Aplicar multiplicador según respeto actual (antes de sumar +1)
        const respeto = Number(user.respeto) || 0;
        const gananciaFinal = Math.floor(ganancia * (1 + respeto / 100));
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        user.money += gananciaPremium;
        user.totalCrimes = (user.totalCrimes || 0) + 1;
        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;

        global.db.setUser(senderNumber, user);

        let response =
            `${crime.texto}\n` +
            `💰 Ganaste *$${gananciaPremium.toLocaleString()}*\n` +
            `🏦 Saldo actual: *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando crime:', error);
        return await message.reply('❌ Hubo un problema al ejecutar el comando.');
    }
};

handler.help = ['crime', 'crimen'];
handler.tags = ['economy'];
handler.command = /^(crime|crimen)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;