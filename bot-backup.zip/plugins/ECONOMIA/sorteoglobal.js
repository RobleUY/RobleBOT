const normalizeNumber = (jid) => jid.split('@')[0].replace(/[^0-9]/g, '').trim();

function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
}

let handler = async (message, { text }) => {
    try {
        if (!message.isGroup)
            return await message.reply('Este comando solo puede usarse en un grupo.');

        if (!text || text.trim() === '')
            return await message.reply('Debes especificar una cantidad.\nUso: .sorteoglobal [cantidad]\nEjemplo: .sorteoglobal 2000');

        const senderNumber = normalizeNumber(message.author || message.sender);
        const user = global.db.getUser(senderNumber);
        if (!user) return await message.reply('Error al acceder a la base de datos.');

        user.money = Number(user.money) || 0;
        const senderApodo = (user.apodo || '').trim() || senderNumber;

        let cantidad;
        const textLower = text.trim().toLowerCase();
        if (textLower === 'all') {
            cantidad = user.money;
        } else if (textLower.includes('%')) {
            const match = textLower.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!match) return await message.reply('Formato de porcentaje invalido.');
            const pct = parseFloat(match[1]);
            if (isNaN(pct) || pct <= 0 || pct > 100)
                return await message.reply('El porcentaje debe estar entre 1% y 100%.');
            cantidad = Math.floor((user.money * pct) / 100);
        } else {
            cantidad = parseInt(textLower);
            if (isNaN(cantidad) || cantidad <= 0)
                return await message.reply('Cantidad invalida.');
        }

        cantidad = Math.max(0, Math.floor(cantidad));
        if (cantidad === 0) return await message.reply('No tienes dinero suficiente o el monto es 0.');

        const saldoStr = Number(user.money).toLocaleString();
        const cantidadStr = Number(cantidad).toLocaleString();

        if (user.money < cantidad)
            return await message.reply('No tienes suficiente dinero.\nSaldo: ' + saldoStr + '\nNecesitas: ' + cantidadStr);

        const allConns = shuffle([global.conn].concat(global.subConns || []).filter(function(c) { return c && c.user; }));
        const botNumbers = allConns.map(function(c) { return normalizeNumber(c.user.id); });

        console.log('[SORTEOG] Bots disponibles: ' + allConns.length);

        // Recolectar grupos con metadata
        const groupData = new Map(); // gid -> { conn, name, participants }
        for (let i = 0; i < allConns.length; i++) {
            try {
                const chats = await allConns[i].groupFetchAllParticipating();
                const entries = Object.entries(chats);
                for (let j = 0; j < entries.length; j++) {
                    const gid = entries[j][0];
                    const gmeta = entries[j][1];
                    if (!groupData.has(gid)) {
                        groupData.set(gid, {
                            conn: allConns[i],
                            name: (gmeta && gmeta.subject) || gid,
                            participants: (gmeta && gmeta.participants) || [],
                            isParent: !!(gmeta && (gmeta.isParent || gmeta.isCommunity || gmeta.isAnnounce))
                        });
                    }
                }
            } catch (e) {
                console.log('[SORTEOG] Error obteniendo grupos del bot ' + i + ': ' + e.message);
            }
        }

        console.log('[SORTEOG] Total grupos encontrados: ' + groupData.size);

        if (groupData.size === 0)
            return await message.reply('No se encontraron grupos disponibles.');

        // Calcular elegibles por grupo y loggear
        const gruposConApodo = [];
        groupData.forEach(function(data, gid) {
            // Excluir grupos padre de comunidades (isParent/isCommunity/isAnnounce)
            if (data.isParent) {
                console.log('[SORTEOG] Saltando comunidad/grupo-padre: "' + data.name + '"');
                return;
            }
            // Excluir grupos raiz de comunidad (isParent = true o announce + size grande sin participantes reales)
            if (data.isParent) {
                console.log('[SORTEOG] Saltando grupo raiz de comunidad: "' + data.name + '"');
                return;
            }
            const parts = data.participants.map(function(p) { return p.id || p; });
            const elegibles = parts.filter(function(jid) {
                const num = normalizeNumber(jid);
                if (num === senderNumber) return false;
                if (botNumbers.indexOf(num) !== -1) return false;
                const ud = global.db.getUser(num);
                const apodo = ((ud && ud.apodo) || '').trim().toLowerCase();
                return apodo && apodo !== 'sin apodo';
            });
            console.log('[SORTEOG] Grupo "' + data.name + '" -> ' + elegibles.length + ' usuarios con apodo de ' + parts.length + ' participantes');
            if (elegibles.length >= 5) {
                gruposConApodo.push({ gid: gid, name: data.name, conn: data.conn, eligible: elegibles });
            }
        });

        console.log('[SORTEOG] Grupos con al menos 1 usuario con apodo: ' + gruposConApodo.length);

        if (gruposConApodo.length === 0)
            return await message.reply('No hay ningun grupo con participantes que tengan apodo.');

        // Mezclar y elegir grupo al azar
        const gruposMezclados = shuffle(gruposConApodo);
        const grupoElegido = gruposMezclados[Math.floor(Math.random() * gruposMezclados.length)];

        console.log('[SORTEOG] Grupo seleccionado: "' + grupoElegido.name + '" con ' + grupoElegido.eligible.length + ' candidatos');

        // Mezclar elegibles y elegir ganador
        const eligibleMezclados = shuffle(grupoElegido.eligible);
        const winnerJid = eligibleMezclados[Math.floor(Math.random() * eligibleMezclados.length)];
        const winnerNumber = normalizeNumber(winnerJid);
        const winnerData = global.db.getUser(winnerNumber);
        const winnerApodo = ((winnerData && winnerData.apodo) || '').trim() || winnerNumber;

        console.log('[SORTEOG] Ganador elegido: ' + winnerNumber + ' (' + winnerApodo + ')');

        // Transaccion
        user.money -= cantidad;
        winnerData.money = (Number(winnerData.money) || 0) + cantidad;
        global.db.setUser(senderNumber, user);
        global.db.setUser(winnerNumber, winnerData);

        // Determinar bot que entrega
        let deliveryConn = grupoElegido.conn;
        if (!deliveryConn || !deliveryConn.user) {
            for (let i = 0; i < allConns.length; i++) {
                try {
                    const m = await allConns[i].groupMetadata(grupoElegido.gid).catch(function() { return null; });
                    if (m) { deliveryConn = allConns[i]; break; }
                } catch (_) {}
            }
        }

        const botLabel = deliveryConn === global.conn
            ? 'Bot oficial'
            : 'SubBot #' + (deliveryConn && deliveryConn._subNum ? deliveryConn._subNum : '?');

        console.log('[SORTEOG] Entrega ejecutada por: ' + botLabel);

        const msgGrupo = [
            '🌍 *SORTEO GLOBAL* 🌍',
            '',
            '🎉 Este grupo fue seleccionado!',
            '👤 Organizado por: *' + senderApodo + '*',
            '',
            '🏆 GANADOR: @' + winnerNumber,
            '🎭 Apodo: *' + winnerApodo + '*',
            '💰 Premio: *' + cantidadStr + '* monedas',
            '',
            '✨ Felicidades!',
            '',
            '� Para hacer un sorteo global usa: *.sorteoglobal [cantidad]*',
            'Ejemplo: .sorteoglobal 2000'
        ].join('\n');

        if (deliveryConn) {
            deliveryConn.sendMessage(grupoElegido.gid, {
                text: msgGrupo,
                mentions: [winnerJid]
            }).catch(function(e) { console.error('[SORTEOG] Error enviando al grupo:', e.message); });
        }

        const msgSender = [
            '✅ *Sorteo global realizado!*',
            '',
            '👤 Organizador: *' + senderApodo + '*',
            '📍 Grupo premiado: *' + grupoElegido.name + '*',
            '🏆 Ganador: @' + winnerNumber + ' (*' + winnerApodo + '*)',
            '💸 Entregado por: ' + botLabel,
            '💰 Monto: ' + cantidadStr + ' monedas'
        ].join('\n');

        await message.reply(msgSender, { mentions: [winnerJid] });

    } catch (error) {
        console.error('[SORTEOG] Error:', error);
        await message.reply('Ocurrio un error al realizar el sorteo global.');
    }
};

handler.help = ['sorteoglobal [cantidad/porcentaje%/all]'];
handler.tags = ['economy'];
handler.command = /^(sorteog|sorteoglobal)$/i;
handler.group = true;

module.exports = handler;
