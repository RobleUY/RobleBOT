let handler = async (message, { conn, text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        const mentionedJids = message?.mentions || [];
        
        if (mentionedJids.length === 0 || !text) {
            return await message.reply('❌ Debes mencionar a un usuario y especificar la cantidad.\nUso: *.darcoins @usuario cantidad/porcentaje%/all*\nEjemplo:\n*.darcoins @usuario 500*\n*.darcoins @usuario 50%*\n*.darcoins @usuario all*');
        }
        const receiverJid = mentionedJids[0];
        const amountText = text.replace(/@\d+/g, "").trim();
        
        if (senderJid === receiverJid) {
            return await message.reply('❌ No puedes darte monedas a ti mismo.');
        }
        const senderNumber = senderJid.split('@')[0];
        const receiverNumber = receiverJid.split('@')[0];
        // Se asume que global.db y sus métodos getUser/setUser están disponibles
        let sender_user = global.db.getUser(senderNumber);
        let receiver = global.db.getUser(receiverNumber);
        
        if (!sender_user || !receiver) {
            return await message.reply('❌ Ocurrió un error al obtener los datos de los usuarios. Asegúrate de que ambos estén registrados en la base de datos.');
        }

        // Asegurar que el remitente tenga dinero definido
        sender_user.money = Number(sender_user.money) || 0;
        receiver.money = Number(receiver.money) || 0;

        let amount;
        const textLower = amountText.toLowerCase();
        
        // Verificar si es "all"
        if (textLower === 'all') {
            amount = sender_user.money;
        }
        // Verificar si es porcentaje
        else if (textLower.includes('%')) {
            const percentageMatch = textLower.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!percentageMatch) {
                return await message.reply('❌ Formato de porcentaje inválido. Usa por ejemplo: 50% o 25%');
            }
            
            const percentage = parseFloat(percentageMatch[1]);
            
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                return await message.reply('❌ El porcentaje debe estar entre 1% y 100%.');
            }
            
            // Calcular el monto basado en el porcentaje y redondear
            amount = Math.floor((sender_user.money * percentage) / 100);
        } 
        // Si es un número directo
        else {
            amount = parseInt(amountText);
            if (isNaN(amount) || amount <= 0) {
                return await message.reply('❌ La cantidad debe ser un número positivo, un porcentaje válido o "all".\nEjemplo:\n*.darcoins @usuario 500*\n*.darcoins @usuario 50%*\n*.darcoins @usuario all*');
            }
        }

        // Asegurar que el monto sea positivo y entero
        amount = Math.max(0, Math.floor(amount));

        if (amount === 0) {
            return await message.reply('❌ No tienes monedas para dar o el monto calculado es 0.');
        }
        
        if (sender_user.money < amount) {
            return await message.reply(`❌ No tienes suficientes monedas para dar.\nTu saldo: $${sender_user.money}\nIntentaste enviar: $${amount}`);
        }
        
        // Realizar la transferencia de monedas
        sender_user.money -= amount;
        receiver.money += amount;
        
        // Guardar los cambios en la base de datos
        global.db.setUser(senderNumber, sender_user);
        global.db.setUser(receiverNumber, receiver);
        
        // Enviar la respuesta con las menciones correctas
        const replyMessage = `✅ Has enviado $${amount} monedas a @${receiverNumber} exitosamente.\n💰 Tu saldo restante: $${sender_user.money}`;
        await message.reply(replyMessage, { mentions: [senderJid, receiverJid] });
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al dar monedas:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al dar las monedas.');
    }
};
handler.help = ['darcoins @usuario cantidad/porcentaje%/all', 'dar @usuario cantidad/porcentaje%/all'];
handler.tags = ['economy'];
handler.command = /^(darcoins|dar)$/i;
module.exports = handler;
handler.group = true;