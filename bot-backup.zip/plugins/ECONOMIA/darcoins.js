// Busca un número por apodo en la base de datos
function findNumberByApodo(apodo) {
    if (!global.db?.data?.users) return null;
    const target = apodo.trim().toLowerCase();
    for (const [num, userData] of Object.entries(global.db.data.users)) {
        const userApodo = (userData.apodo || '').trim().toLowerCase();
        if (userApodo === target) return num;
    }
    return null;
}

let handler = async (message, { conn, text, args }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');

        const quotedJid = message?.quoted?.sender
            || message?.quoted?.key?.participant
            || message?.message?.extendedTextMessage?.contextInfo?.participant;

        const mentionedJids = message?.mentions
            || message?.message?.extendedTextMessage?.contextInfo?.mentionedJid
            || [];

        let receiverNumber = null;
        let receiverJid = null;
        let amountText = '';

        if (quotedJid) {
            receiverJid = quotedJid;
            receiverNumber = receiverJid.split('@')[0].split(':')[0].replace(/\D/g, '');
            amountText = (text || '').trim();
        } else if (mentionedJids.length > 0) {
            receiverJid = mentionedJids[0];
            receiverNumber = receiverJid.split('@')[0].split(':')[0].replace(/\D/g, '');
            amountText = (text || '').replace(/@\d+/g, '').trim();
        } else if (args && args.length >= 2) {
            let potentialAmountIdx = -1;
            for (let i = 0; i < args.length; i++) {
                const arg = args[i].trim().toLowerCase();
                if (arg === 'all' || /^\d+%\$?$/.test(arg) || /^\d+$/.test(arg)) {
                    potentialAmountIdx = i;
                    break;
                }
            }

            if (potentialAmountIdx !== -1) {
                amountText = args[potentialAmountIdx];
                const apodoArgs = args.filter((_, idx) => idx !== potentialAmountIdx);
                const apodo = apodoArgs.join(' ').trim();
                receiverNumber = findNumberByApodo(apodo);
                if (!receiverNumber) {
                    return await message.reply(`❌ No se encontró ningún usuario con el apodo *${apodo}*.`);
                }
                receiverJid = `${receiverNumber}@s.whatsapp.net`;
            } else {
                const apodo = args[0];
                amountText = args.slice(1).join(' ').trim();
                receiverNumber = findNumberByApodo(apodo);
                if (!receiverNumber) {
                    return await message.reply(`❌ No se encontró ningún usuario con el apodo *${apodo}*.`);
                }
                receiverJid = `${receiverNumber}@s.whatsapp.net`;
            }
        } else {
            return await message.reply(
                '❌ Debes indicar a quién enviar y la cantidad.\n\n' +
                '• Respondiendo a un mensaje:\n*.dar 500*\n\n' +
                '• Por mención:\n*.dar @usuario 500*\n\n' +
                '• Por apodo:\n*.dar pepe 500*\n\n' +
                'Ejemplos:\n*.dar pepe 500*\n*.dar pepe 50%*\n*.dar pepe all*'
            );
        }

        if (!receiverNumber) {
            return await message.reply('❌ No se pudo determinar el usuario receptor.');
        }

        if (senderNumber === receiverNumber) {
            return await message.reply('❌ No puedes darte monedas a ti mismo.');
        }

        let sender_user = global.db.getUser(senderNumber);
        let receiver = global.db.getUser(receiverNumber);

        if (!sender_user || !receiver) {
            return await message.reply('❌ Ocurrió un error al obtener los datos de los usuarios.');
        }

        sender_user.money = Number(sender_user.money) || 0;
        receiver.money = Number(receiver.money) || 0;

        let amount;
        const textLower = (amountText || '').toLowerCase().trim();

        if (textLower === 'all') {
            amount = sender_user.money;
        } else if (textLower.includes('%')) {
            const percentageMatch = textLower.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!percentageMatch) {
                return await message.reply('❌ Formato de porcentaje inválido. Usa por ejemplo: 50% o 25%');
            }
            const percentage = parseFloat(percentageMatch[1]);
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                return await message.reply('❌ El porcentaje debe estar entre 1% y 100%.');
            }
            amount = Math.floor((sender_user.money * percentage) / 100);
        } else {
            amount = parseInt(textLower.replace(/[^\d]/g, ''), 10);
            if (isNaN(amount) || amount <= 0) {
                return await message.reply(
                    '❌ La cantidad debe ser un número positivo, un porcentaje válido o "all".\n' +
                    'Ejemplos:\n*.dar pepe 500*\n*.dar pepe 50%*\n*.dar pepe all*'
                );
            }
        }

        amount = Math.max(0, Math.floor(amount));

        if (amount === 0) {
            return await message.reply('❌ No tienes monedas para dar o el monto calculado es 0.');
        }

        if (sender_user.money < amount) {
            return await message.reply(
                `❌ No tienes suficientes monedas.\n💰 Tu saldo: *$${sender_user.money.toLocaleString()}*\n📤 Intentaste enviar: *$${amount.toLocaleString()}*`
            );
        }

        // Transferencia
        sender_user.money -= amount;
        receiver.money += amount;

        global.db.setUser(senderNumber, sender_user);
        global.db.setUser(receiverNumber, receiver);

        try { if (global.db && typeof global.db.save === 'function') global.db.save(); } catch (_) {}

        // Obtener apodo del receptor para mostrar en la respuesta
        const receiverUser = global.db.getUser(receiverNumber);
        const receiverApodo = (receiverUser?.apodo || '').trim() || `@${receiverNumber}`;

        await message.reply(
            `✅ Enviaste *${amount.toLocaleString()}* monedas a *${receiverApodo}* exitosamente.\n` +
            `💰 Tu saldo restante: *${sender_user.money.toLocaleString()}*`,
            { mentions: [receiverJid] }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al dar monedas:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al dar las monedas.');
    }
};

handler.help = [
    'darcoins @usuario cantidad/porcentaje%/all',
    'darcoins apodo cantidad/porcentaje%/all'
];
handler.tags = ['economy'];
handler.command = /^(darcoins|dar|pay|pagar)$/i;
handler.group = true;
handler.apodo = true;

module.exports = handler;
