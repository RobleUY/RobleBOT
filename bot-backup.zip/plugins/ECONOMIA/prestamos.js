const db = require('../../database.js'); // Ruta desde plugins/Economia/

// Constantes del sistema de préstamos
const MIN_PRESTAMO = 1000;
const INTERES_RATE = 0.20; // 20% de interés por préstamo

// Función para normalizar texto (quitar tildes)
function normalizeText(text) {
    if (!text || typeof text !== 'string') return '';
    return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

// Función de utilidad para limpiar un número de teléfono (quita '+' y sufijos)
const normalizeNumber = (jidPart) => {
    return jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();
};

let handler = async (message, { text, args, command }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente del mensaje.');

        const sender = senderJid.split('@')[0];
        const user = db.getUser(sender);
        if (!user) return await message.reply('❌ Error al acceder a la base de datos.');

        const normalizedCommand = normalizeText(command);

        // Comando: prestamo pagar @user <cantidad> o .prestamopagar
        if (normalizedCommand === 'prestamopagar' || (args[0] && normalizeText(args[0]) === 'pagar')) {
            if (message.mentions && message.mentions.length > 0) {
                // Aquí se llama a pagarDeudaAOtro, asumiendo una transferencia de pago de deuda
                // Esto podría no ser necesario si el préstamo es solo con la "banca"
                // Pero se mantiene para ser fiel al flujo de tu código incompleto.
                return await pagarDeudaAOtro(message, user, sender, args);
            }
            return await pagarPrestamo(message, user, sender, args);
        }

        // Comando: prestamo <cantidad>
        return await solicitarPrestamo(message, user, sender, args);

    } catch (error) {
        console.error('Error en comando prestamo:', error);
        return await message.reply('❌ Ocurrió un error al procesar tu préstamo.');
    }
};

// Función para solicitar un préstamo
async function solicitarPrestamo(message, user, sender, args) {
    // Si ya tiene préstamo activo
    if (user.prestamo && user.prestamo.activo && user.prestamo.deuda > 0) {
        const diasTranscurridos = Math.floor((Date.now() - user.prestamo.fechaPrestamo) / (1000 * 60 * 60 * 24));
        return await message.reply(
            `⚠️ *YA TIENES UN PRÉSTAMO ACTIVO*\n\n` +
            `💰 Monto original: $${user.prestamo.monto.toLocaleString()}\n` +
            `💸 Deuda actual: $${user.prestamo.deuda.toLocaleString()}\n` +
            `📊 Intereses: $${user.prestamo.intereses.toLocaleString()}\n` +
            `📅 Días transcurridos: ${diasTranscurridos}\n\n` +
            `💡 Debes pagar tu préstamo actual antes de solicitar uno nuevo.\n` +
            `Usa: \`.prestamo pagar <cantidad>\` para pagar.`
        );
    }

    // Verificar respeto
    const respeto = user.respeto || 0;
    if (respeto <= 0) {
        return await message.reply('❌ No tienes respeto suficiente para solicitar un préstamo. Trabaja y gana respeto primero.');
    }

    // Calcular préstamo máximo según respeto
    const MAX_PRESTAMO = respeto * 10000;

    // Verificar que se haya proporcionado una cantidad
    if (!args[0]) {
    return await message.reply(
        `💰 *SISTEMA DE PRÉSTAMOS* 💰\n\n` +
        `📌 Para solicitar un préstamo usa:\n` +
        `\`.prestamo <cantidad>\`\n\n` +
        `📊 *Información según tu respeto (${respeto}):*\n` +
        `• Máximo préstamo que puedes pedir: $${MAX_PRESTAMO.toLocaleString()}\n` +
        `• Interés: ${INTERES_RATE * 100}%\n\n` +
        `💡 ¡Mientras más respeto tengas, mayor préstamo podrás solicitar!\n` +
        `💼 Usa el comando \`.work\` para trabajar, ganar dinero y aumentar tu respeto.\n\n` +
        `💡 *Ejemplo:* \`.prestamo 10000\``
    );
}

    const cantidad = parseInt(args[0]);
    if (isNaN(cantidad) || cantidad <= 0) return await message.reply('❌ Debes especificar una cantidad válida.');

    if (cantidad < MIN_PRESTAMO) return await message.reply(`❌ El préstamo mínimo es de $${MIN_PRESTAMO.toLocaleString()}.`);
    if (cantidad > MAX_PRESTAMO) return await message.reply(`❌ El préstamo máximo según tu respeto (${respeto}) es $${MAX_PRESTAMO.toLocaleString()}.`);

    // Calcular intereses y deuda total
    const intereses = Math.floor(cantidad * INTERES_RATE);
    const deudaTotal = cantidad + intereses;

    // Actualizar datos del usuario
    user.money += cantidad;
    user.prestamo = {
        activo: true,
        monto: cantidad,
        deuda: deudaTotal,
        intereses: intereses,
        fechaPrestamo: Date.now()
    };

    const success = db.setUser(sender, user);
    if (!success) return await message.reply('❌ Error al procesar el préstamo. Intenta de nuevo.');

    return await message.reply(
        `✅ *PRÉSTAMO APROBADO* ✅\n\n` +
        `💰 Recibido: $${cantidad.toLocaleString()}\n` +
        `📊 Interés (${INTERES_RATE * 100}%): $${intereses.toLocaleString()}\n` +
        `💸 Deuda total: $${deudaTotal.toLocaleString()}\n\n` +
        `🏦 Tu nuevo saldo: $${user.money.toLocaleString()}\n\n` +
        `⚠️ Recuerda pagar tu préstamo usando:\n` +
        `\`.prestamo pagar <cantidad>\``
    );
}

// ----------------------------------------------------------------------------------
// FUNCIONES FALTANTES PARA RESOLVER EL ReferenceError
// ----------------------------------------------------------------------------------

/**
 * Función para pagar el préstamo a la "banca" o sistema.
 */
async function pagarPrestamo(message, user, sender, args) {
    if (!user.prestamo || !user.prestamo.activo || user.prestamo.deuda <= 0) {
        return await message.reply('❌ No tienes un préstamo activo para pagar.');
    }

    let cantidadAPagar;
    const deudaRestante = user.prestamo.deuda;
    let cantidadArg = args[0] === 'pagar' ? args[1] : args[0]; // Manejar .prestamo pagar <cantidad> o .prestamopagar <cantidad>

    if (!cantidadArg) {
        return await message.reply(
            `💰 *PAGAR PRÉSTAMO*\n\n` +
            `💸 Deuda restante: $${deudaRestante.toLocaleString()}\n` +
            `💡 Usa: \`.prestamo pagar <cantidad>\` o \`.prestamo pagar todo\``
        );
    }

    if (normalizeText(cantidadArg) === 'todo') {
        cantidadAPagar = deudaRestante;
    } else {
        cantidadAPagar = parseInt(cantidadArg);
    }

    if (isNaN(cantidadAPagar) || cantidadAPagar <= 0) {
        return await message.reply('❌ Debes especificar una cantidad válida o usar "todo".');
    }

    if (cantidadAPagar > deudaRestante) {
        return await message.reply(`❌ No puedes pagar más de tu deuda actual ($${deudaRestante.toLocaleString()}).`);
    }

    if (user.money < cantidadAPagar) {
        return await message.reply(`❌ No tienes suficiente dinero. Saldo actual: $${user.money.toLocaleString()}.`);
    }

    // Realizar el pago
    user.money -= cantidadAPagar;
    user.prestamo.deuda -= cantidadAPagar;

    let mensajeRespuesta = `✅ *PAGO DE PRÉSTAMO REALIZADO* ✅\n\n` +
                           `💸 Pagaste: $${cantidadAPagar.toLocaleString()}\n`;

    if (user.prestamo.deuda <= 0) {
        // Préstamo liquidado
        user.prestamo = { activo: false, monto: 0, deuda: 0, intereses: 0, fechaPrestamo: 0 };
        mensajeRespuesta += `🎉 ¡Tu préstamo ha sido *LIQUIDADO* por completo!\n`;
    } else {
        // Queda deuda pendiente
        mensajeRespuesta += `⚖️ Deuda restante: $${user.prestamo.deuda.toLocaleString()}\n`;
    }
    
    mensajeRespuesta += `🏦 Tu nuevo saldo: $${user.money.toLocaleString()}`;

    const success = db.setUser(sender, user);
    if (!success) return await message.reply('❌ Error al registrar el pago. Intenta de nuevo.');

    return await message.reply(mensajeRespuesta);
}

/**
 * Función para que un usuario pague la deuda de OTRO usuario.
 * Nota: Esta implementación asume que un préstamo *NO* se puede pagar por otro. 
 * Para simplificar y enfocarnos en el error, se emite un mensaje claro.
 * Si esto fuera una deuda entre usuarios, la lógica sería diferente.
 */
async function pagarDeudaAOtro(message, user, sender, args) {
    const mention = message.mentions[0]; // El primer usuario mencionado
    const targetJid = normalizeNumber(mention);
    const targetUser = db.getUser(targetJid);
    
    // Si la mención es el propio usuario, redirigir a pagarPrestamo
    if (targetJid === sender) {
        return await pagarPrestamo(message, user, sender, args.slice(1));
    }

    if (!targetUser) return await message.reply('❌ El usuario mencionado no está registrado.');
    
    // Lógica específica para pagos a terceros (si aplica). Aquí se asume que
    // el comando 'prestamo' es para el sistema, no entre usuarios.
    if (targetUser.prestamo && targetUser.prestamo.activo && targetUser.prestamo.deuda > 0) {
        return await message.reply(
            `❌ El comando \`.prestamo pagar\` se usa para pagar deudas al *sistema*.\n` +
            `*${targetUser.name || targetJid}* debe usar \`.prestamo pagar <cantidad>\` para pagar su propia deuda.`
        );
    } else {
        return await message.reply(
            `❌ La función de pagar deudas a otros usuarios por el comando *prestamo* no está implementada para deudas al sistema.`
        );
    }
}

// ----------------------------------------------------------------------------------

handler.help = [
    'prestamo <cantidad>', 
    'prestamo pagar <cantidad>', 
    'prestamo pagar todo',
    'prestamo pagar @user <cantidad>',
    'prestamo pagar @user todo'
];
handler.tags = ['economia', 'dinero'];
handler.command = /^(prestamo|préstamo|loan|prestamopagar|préstamopagar)$/i;
module.exports = handler;
handler.group = true;