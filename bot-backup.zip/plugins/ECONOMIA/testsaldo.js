const sharp = require('sharp');

function formatAmount(value) {
    return Number(value).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function amountFontSize(value) {
    const len = String(value).length;
    if (len >= 13) return 22;
    if (len >= 12) return 24;
    if (len >= 11) return 26;
    if (len >= 10) return 28;
    if (len >= 9) return 30;
    if (len >= 8) return 32;
    if (len >= 7) return 34;
    return 38;
}

function createBalanceSVG(name, money, bank, total) {
    const heading = name || 'Usuario';

    // Truncate long names
    const displayName = heading.length > 18 ? heading.substring(0, 16) + '…' : heading;

    return `<svg width="1060" height="660" xmlns="http://www.w3.org/2000/svg">
  <defs>

    <!-- Card base gradient: deep navy to slate -->
    <linearGradient id="cardBase" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0A0E27"/>
      <stop offset="55%" stop-color="#111535"/>
      <stop offset="100%" stop-color="#1C2155"/>
    </linearGradient>

    <!-- Shimmer stripe on card -->
    <linearGradient id="shimmer" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0"/>
      <stop offset="40%" stop-color="#FFFFFF" stop-opacity="0.04"/>
      <stop offset="60%" stop-color="#FFFFFF" stop-opacity="0.10"/>
      <stop offset="100%" stop-color="#FFFFFF" stop-opacity="0"/>
    </linearGradient>

    <!-- Holographic circle gradient -->
    <radialGradient id="holo" cx="50%" cy="50%" r="50%">
      <stop offset="0%"   stop-color="#FF6BFF" stop-opacity="0.75"/>
      <stop offset="25%"  stop-color="#6BFFFF" stop-opacity="0.60"/>
      <stop offset="50%"  stop-color="#FFEA6B" stop-opacity="0.55"/>
      <stop offset="75%"  stop-color="#6BFF9E" stop-opacity="0.60"/>
      <stop offset="100%" stop-color="#6B8EFF" stop-opacity="0.50"/>
    </radialGradient>

    <!-- Chip gradient -->
    <linearGradient id="chipBody" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%"   stop-color="#D4AF37"/>
      <stop offset="40%"  stop-color="#F5E07A"/>
      <stop offset="70%"  stop-color="#C9991E"/>
      <stop offset="100%" stop-color="#E8C84A"/>
    </linearGradient>

    <!-- Accent line gradient -->
    <linearGradient id="accentLine" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%"   stop-color="#5C86FF"/>
      <stop offset="50%"  stop-color="#B87FFF"/>
      <stop offset="100%" stop-color="#FF6BFF"/>
    </linearGradient>

    <!-- Money card gradient (left) -->
    <linearGradient id="moneyCard" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%"   stop-color="#1A2060"/>
      <stop offset="100%" stop-color="#0F1440"/>
    </linearGradient>

    <!-- Bank card gradient (center) -->
    <linearGradient id="bankCard" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%"   stop-color="#1A2060"/>
      <stop offset="100%" stop-color="#0F1440"/>
    </linearGradient>

    <!-- Total card gradient (right) - slightly brighter -->
    <linearGradient id="totalCard" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%"   stop-color="#22206A"/>
      <stop offset="100%" stop-color="#14124E"/>
    </linearGradient>

    <!-- Outer glow filter -->
    <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>

    <!-- Card shadow -->
    <filter id="cardShadow" x="-10%" y="-10%" width="120%" height="130%">
      <feDropShadow dx="0" dy="20" stdDeviation="28" flood-color="#000000" flood-opacity="0.55"/>
    </filter>

    <!-- Subtle inner glow for mini cards -->
    <filter id="miniGlow" x="-15%" y="-15%" width="130%" height="130%">
      <feDropShadow dx="0" dy="4" stdDeviation="10" flood-color="#5C86FF" flood-opacity="0.20"/>
    </filter>

    <!-- Clip for card shape -->
    <clipPath id="cardClip">
      <rect width="1060" height="660" rx="36"/>
    </clipPath>

  </defs>

  <!-- ═══════════════════════════════════════════ -->
  <!-- CARD BACKGROUND                             -->
  <!-- ═══════════════════════════════════════════ -->
  <rect width="1060" height="660" rx="36" fill="url(#cardBase)" filter="url(#cardShadow)"/>

  <!-- Shimmer overlay -->
  <rect width="1060" height="660" rx="36" fill="url(#shimmer)" clip-path="url(#cardClip)"/>

  <!-- Subtle top-left light bleed -->
  <ellipse cx="180" cy="130" rx="260" ry="180" fill="#3A4FCC" opacity="0.12"/>

  <!-- Bottom-right depth shadow -->
  <ellipse cx="920" cy="560" rx="220" ry="160" fill="#0A0E27" opacity="0.35"/>

  <!-- Decorative corner arc top-right -->
  <circle cx="1060" cy="0" r="300" fill="none" stroke="#FFFFFF" stroke-width="0.6" opacity="0.08"/>
  <circle cx="1060" cy="0" r="220" fill="none" stroke="#FFFFFF" stroke-width="0.5" opacity="0.06"/>
  <circle cx="1060" cy="0" r="140" fill="none" stroke="#FFFFFF" stroke-width="0.4" opacity="0.05"/>

  <!-- Decorative corner arc bottom-left -->
  <circle cx="0" cy="660" r="260" fill="none" stroke="#5C86FF" stroke-width="0.7" opacity="0.10"/>
  <circle cx="0" cy="660" r="180" fill="none" stroke="#5C86FF" stroke-width="0.5" opacity="0.08"/>

  <!-- Subtle grid texture lines (horizontal) -->
  <line x1="0" y1="100" x2="1060" y2="100" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="0" y1="200" x2="1060" y2="200" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="0" y1="300" x2="1060" y2="300" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="0" y1="400" x2="1060" y2="400" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="0" y1="500" x2="1060" y2="500" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>

  <!-- Subtle grid texture lines (vertical) -->
  <line x1="265" y1="0" x2="265" y2="660" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="530" y1="0" x2="530" y2="660" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>
  <line x1="795" y1="0" x2="795" y2="660" stroke="#FFFFFF" stroke-width="0.3" opacity="0.04"/>


  <!-- ═══════════════════════════════════════════ -->
  <!-- HOLOGRAPHIC CIRCLE (top-right)              -->
  <!-- ═══════════════════════════════════════════ -->
  <circle cx="950" cy="110" r="72" fill="url(#holo)" opacity="0.55" filter="url(#glow)"/>
  <circle cx="950" cy="110" r="72" fill="none" stroke="#FFFFFF" stroke-width="1" opacity="0.25"/>
  <!-- Inner rings for holographic effect -->
  <circle cx="950" cy="110" r="52" fill="none" stroke="#FFFFFF" stroke-width="0.6" opacity="0.20"/>
  <circle cx="950" cy="110" r="35" fill="none" stroke="#FFFFFF" stroke-width="0.5" opacity="0.18"/>
  <!-- Diagonal lines through holo -->
  <line x1="890" y1="50" x2="1010" y2="170" stroke="#FFFFFF" stroke-width="0.7" opacity="0.15"/>
  <line x1="1010" y1="50" x2="890" y2="170" stroke="#FFFFFF" stroke-width="0.7" opacity="0.15"/>


  <!-- ═══════════════════════════════════════════ -->
  <!-- CHIP (EMV)                                  -->
  <!-- ═══════════════════════════════════════════ -->
  <!-- Chip body -->
  <rect x="68" y="78" width="68" height="52" rx="8" fill="url(#chipBody)"/>
  <!-- Chip internal lines (EMV circuit look) -->
  <line x1="68"  y1="100" x2="136" y2="100" stroke="#8B6914" stroke-width="1.2" opacity="0.6"/>
  <line x1="68"  y1="110" x2="136" y2="110" stroke="#8B6914" stroke-width="1.2" opacity="0.6"/>
  <line x1="90"  y1="78"  x2="90"  y2="130" stroke="#8B6914" stroke-width="1.2" opacity="0.6"/>
  <line x1="102" y1="78"  x2="102" y2="130" stroke="#8B6914" stroke-width="1.2" opacity="0.6"/>
  <line x1="114" y1="78"  x2="114" y2="130" stroke="#8B6914" stroke-width="1.2" opacity="0.6"/>
  <!-- Central chip contact -->
  <rect x="86" y="91" width="32" height="26" rx="4" fill="#C9991E" opacity="0.7"/>

  <!-- NFC contactless symbol -->
  <path d="M 160 90 Q 174 104 160 118" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" opacity="0.55"/>
  <path d="M 169 83 Q 190 104 169 125" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" opacity="0.42"/>
  <path d="M 178 76 Q 206 104 178 132" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" opacity="0.28"/>


  <!-- ═══════════════════════════════════════════ -->
  <!-- CARD BRAND NAME (top-left)                  -->
  <!-- ═══════════════════════════════════════════ -->
  <text x="68" y="62"
    fill="#FFFFFF"
    font-family="'Georgia', 'Times New Roman', serif"
    font-size="26"
    font-weight="700"
    letter-spacing="6"
    opacity="0.90">RobleBOT</text>

  <!-- Tiny "BANK" subtext -->
  <text x="68" y="78"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="4"
    opacity="0.60">BANK</text>

  <!-- ═══════════════════════════════════════════ -->
  <!-- CARD NUMBER (fake decorative)               -->
  <!-- ═══════════════════════════════════════════ -->
  <text x="68" y="234"
    fill="#FFFFFF"
    font-family="'Courier New', 'Lucida Console', monospace"
    font-size="32"
    font-weight="400"
    letter-spacing="5"
    opacity="0.88">•••• •••• ••••  9471</text>


  <!-- ═══════════════════════════════════════════ -->
  <!-- HOLDER NAME + VALID                         -->
  <!-- ═══════════════════════════════════════════ -->
  <text x="68" y="278"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2.5"
    opacity="0.70">TITULAR</text>

  <text x="68" y="302"
    fill="#FFFFFF"
    font-family="'Arial', sans-serif"
    font-size="22"
    font-weight="700"
    letter-spacing="2"
    opacity="0.95">${displayName.toUpperCase()}</text>

  <text x="820" y="278"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2.5"
    opacity="0.70">VÁLIDO HASTA</text>

  <text x="820" y="302"
    fill="#FFFFFF"
    font-family="'Arial', sans-serif"
    font-size="20"
    font-weight="600"
    letter-spacing="2"
    opacity="0.90">12 / 28</text>


  <!-- ═══════════════════════════════════════════ -->
  <!-- ACCENT LINE                                 -->
  <!-- ═══════════════════════════════════════════ -->
  <rect x="68" y="324" width="520" height="3" rx="2" fill="url(#accentLine)" opacity="0.85"/>

  <!-- Small diamond decorations on the line -->
  <polygon points="592,325.5 600,321 608,325.5 600,330" fill="#B87FFF" opacity="0.70"/>
  <polygon points="618,325.5 626,321 634,325.5 626,330" fill="#5C86FF" opacity="0.60"/>


  <!-- ═══════════════════════════════════════════ -->
  <!-- BALANCE SECTION LABEL                       -->
  <!-- ═══════════════════════════════════════════ -->
  <text x="68" y="366"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="12"
    letter-spacing="3"
    opacity="0.70">RESUMEN DE SALDO</text>


  <!-- ═══════════════════════════════════════════ -->
  <!-- BALANCE MINI CARDS                          -->
  <!-- ═══════════════════════════════════════════ -->

  <!-- === SALDO (left) === -->
  <rect x="68" y="384" width="290" height="200" rx="18" fill="url(#moneyCard)" filter="url(#miniGlow)"/>
  <rect x="68" y="384" width="290" height="200" rx="18" fill="none" stroke="#5C86FF" stroke-width="1" opacity="0.30"/>

  <!-- Accent dot top-right of card -->
  <circle cx="338" cy="404" r="6" fill="#5C86FF" opacity="0.60"/>
  <circle cx="322" cy="404" r="4" fill="#5C86FF" opacity="0.30"/>

  <!-- Icon: coin stack (3 ellipses) -->
  <ellipse cx="108" cy="432" rx="22" ry="7" fill="#5C86FF" opacity="0.18"/>
  <ellipse cx="108" cy="425" rx="22" ry="7" fill="#5C86FF" opacity="0.28"/>
  <ellipse cx="108" cy="418" rx="22" ry="7" fill="#5C86FF" opacity="0.50"/>
  <text x="108" y="422" text-anchor="middle" fill="#8BAAFF" font-family="'Arial', sans-serif" font-size="10" font-weight="700" opacity="0.95">$</text>

  <text x="148" y="425"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2"
    opacity="0.80">EFECTIVO</text>

  <text x="88" y="490"
    fill="#FFFFFF"
    font-family="'Courier New', monospace"
    font-size="${amountFontSize(money)}"
    font-weight="700"
    letter-spacing="-0.5"
    opacity="0.97">${money}</text>

  <text x="88" y="516"
    fill="#5C86FF"
    font-family="'Arial', sans-serif"
    font-size="13"
    letter-spacing="1"
    opacity="0.80">coins en mano</text>

  <!-- Thin bottom accent line -->
  <rect x="88" y="558" width="180" height="2" rx="1" fill="#5C86FF" opacity="0.45"/>
  <rect x="278" y="558" width="60" height="2" rx="1" fill="#5C86FF" opacity="0.20"/>


  <!-- === BANCO (center) === -->
  <rect x="382" y="384" width="290" height="200" rx="18" fill="url(#bankCard)" filter="url(#miniGlow)"/>
  <rect x="382" y="384" width="290" height="200" rx="18" fill="none" stroke="#A875FF" stroke-width="1" opacity="0.30"/>

  <!-- Accent dots -->
  <circle cx="652" cy="404" r="6" fill="#A875FF" opacity="0.60"/>
  <circle cx="636" cy="404" r="4" fill="#A875FF" opacity="0.30"/>

  <!-- Icon: building / bank columns (3 rects) -->
  <rect x="402" y="424" width="7" height="14" rx="2" fill="#A875FF" opacity="0.70"/>
  <rect x="413" y="420" width="7" height="18" rx="2" fill="#A875FF" opacity="0.85"/>
  <rect x="424" y="424" width="7" height="14" rx="2" fill="#A875FF" opacity="0.70"/>
  <rect x="400" y="438" width="33" height="3" rx="1" fill="#A875FF" opacity="0.50"/>
  <rect x="400" y="415" width="33" height="3" rx="1" fill="#A875FF" opacity="0.40"/>

  <text x="444" y="425"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2"
    opacity="0.80">BANCO</text>

  <text x="402" y="490"
    fill="#FFFFFF"
    font-family="'Courier New', monospace"
    font-size="${amountFontSize(bank)}"
    font-weight="700"
    letter-spacing="-0.5"
    opacity="0.97">${bank}</text>

  <text x="402" y="516"
    fill="#A875FF"
    font-family="'Arial', sans-serif"
    font-size="13"
    letter-spacing="1"
    opacity="0.80">coins guardadas</text>

  <rect x="402" y="558" width="180" height="2" rx="1" fill="#A875FF" opacity="0.45"/>
  <rect x="592" y="558" width="60" height="2" rx="1" fill="#A875FF" opacity="0.20"/>


  <!-- === TOTAL (right) === -->
  <rect x="696" y="384" width="296" height="200" rx="18" fill="url(#totalCard)"/>
  <rect x="696" y="384" width="296" height="200" rx="18" fill="none" stroke="#FF6BFF" stroke-width="1" opacity="0.35"/>
  <!-- Extra shimmer for "total" card -->
  <rect x="696" y="384" width="296" height="90" rx="18" fill="#FFFFFF" opacity="0.025"/>

  <!-- Accent dots -->
  <circle cx="970" cy="404" r="6" fill="#FF6BFF" opacity="0.60"/>
  <circle cx="954" cy="404" r="4" fill="#FF6BFF" opacity="0.30"/>

  <!-- Icon: Star / total symbol -->
  <polygon points="726,432 730,420 734,432 745,432 736,440 739,452 730,445 721,452 724,440 715,432"
    fill="#FF6BFF" opacity="0.70"/>

  <text x="754" y="425"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2"
    opacity="0.80">TOTAL</text>

  <text x="716" y="490"
    fill="#FFFFFF"
    font-family="'Courier New', monospace"
    font-size="${amountFontSize(total)}"
    font-weight="700"
    letter-spacing="-0.5"
    opacity="0.97">${total}</text>

  <text x="716" y="516"
    fill="#FF6BFF"
    font-family="'Arial', sans-serif"
    font-size="13"
    letter-spacing="1"
    opacity="0.80">coins en total</text>

  <rect x="716" y="558" width="200" height="2" rx="1" fill="url(#accentLine)" opacity="0.55"/>


  <!-- ═══════════════════════════════════════════ -->
  <!-- FOOTER                                      -->
  <!-- ═══════════════════════════════════════════ -->
  <text x="68" y="634"
    fill="#3A4A80"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="1.5"
    opacity="0.80">NEXUS BANK  ·  SISTEMA DE ECONOMÍA VIRTUAL</text>

  <!-- Footer right: card type badge -->
  <rect x="880" y="618" width="112" height="26" rx="6" fill="#FFFFFF" opacity="0.06"/>
  <rect x="880" y="618" width="112" height="26" rx="6" fill="none" stroke="#FFFFFF" stroke-width="0.6" opacity="0.18"/>
  <text x="936" y="636" text-anchor="middle"
    fill="#8899CC"
    font-family="'Arial', sans-serif"
    font-size="11"
    letter-spacing="2"
    opacity="0.80">PREMIUM ★</text>

</svg>`;
}

async function createBalanceImage(name, money, bank, total) {
    const svg = createBalanceSVG(name, money, bank, total);
    return await sharp(Buffer.from(svg))
        .png()
        .toBuffer();
}

function normalizeApodo(text) {
    return text ? String(text).trim().toLowerCase() : '';
}

function findUserByApodo(apodo) {
    const normalized = normalizeApodo(apodo).replace(/^@/, '');
    const users = global.db?.data?.users || {};
    for (const [userId, userData] of Object.entries(users)) {
        if (!userData || !userData.apodo) continue;
        if (normalizeApodo(userData.apodo) === normalized) return userId;
    }
    return null;
}

let handler = async (message, { conn, text }) => {
    try {
        const sender = message.author
            ? message.author.split('@')[0]
            : message.sender
            ? message.sender.split('@')[0]
            : message.from.split('@')[0];

        const requested = text ? text.trim() : '';
        const mentionedJids = message?.mentions || [];

        let targetSender = sender;
        if (mentionedJids.length > 0) {
            targetSender = mentionedJids[0].split('@')[0];
        } else if (requested) {
            const arg = requested.split(/\s+/)[0].replace(/^@/, '');
            if (/^\d+$/.test(arg)) {
                targetSender = arg;
            } else {
                const foundByApodo = findUserByApodo(arg);
                if (foundByApodo) {
                    targetSender = foundByApodo;
                } else {
                    return await message.reply(`❌ No encontré a ningún usuario con el apodo o número "${arg}".`);
                }
            }
        }

        let user = global.db.getUser(targetSender);

        if (!user) {
            user = { money: 0, bank: 0 };
            global.db.setUser(sender, user);
        }

        const money = Number(user.money) || 0;
        const bank  = Number(user.bank)  || 0;
        const total = money + bank;

        const displayName =
            user.apodo && user.apodo.trim() && user.apodo.trim().toLowerCase() !== 'sin apodo'
                ? user.apodo.trim()
                : targetSender;

        const chatId        = message.from || message.key?.remoteJid;
        const quotedMessage = message._baileyMessage || message.baileyMessage || message;

        const imageBuffer = await createBalanceImage(
            displayName,
            formatAmount(money),
            formatAmount(bank),
            formatAmount(total)
        );

        await conn.sendMessage(
            chatId,
            { image: imageBuffer, caption: '💳 Tu tarjeta de saldo.' },
            { quoted: quotedMessage }
        );
    } catch (error) {
        console.error('[ERROR] testsaldo:', error);
        await message.reply('❌ Ocurrió un error al generar tu imagen de saldo.');
    }
};

handler.help    = ['testsaldo'];
handler.tags    = ['economy'];
handler.command = /^(testsaldo)$/i;
handler.group   = false;

module.exports = handler;