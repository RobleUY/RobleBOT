const db = require('../../database.js');

const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!global.db?.data?.users) 
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const currentUserNumber = normalizeNumber(message.sender);

        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];

        const isGlobal = args[1] && /^(g|global)$/i.test(args[1]);

        if (!isGlobal && !message.isGroup) 
            return await message.reply('❌ Este comando solo puede usarse en grupos.\n💡 Usa *' + usedPrefix + cmd + ' global* para ver el top global.');

        const usersWithMoney = [];

        if (isGlobal) {
            const allUsers = global.db.data.users;
            const aliases = global.db.data.aliases || {};
            const seenNumbers = new Set();

            for (const [userKey, userData] of Object.entries(allUsers)) {
                if (!userData) continue;
                // Saltar claves alias para no contar el mismo usuario dos veces
                if (aliases[userKey] && aliases[userKey] !== userKey) continue;

                const userNumber = normalizeNumber(userKey);
                if (!userNumber || seenNumbers.has(userNumber)) continue;
                seenNumbers.add(userNumber);

                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? '👤 Sin Apodo'
                    : apodoRaw;

                const clanName = userData.clan ? userData.clan.toUpperCase() : null;

                usersWithMoney.push({
                    jid: userKey,
                    number: userNumber,
                    totalMoney,
                    apodo,
                    clan: clanName
                });
            }
        } else {
            const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);

            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                const userData = global.db.getUser(userNumber);
                if (!userData) continue;

                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? '👤 Sin Apodo'
                    : apodoRaw;

                const clanName = userData.clan ? userData.clan.toUpperCase() : null;

                usersWithMoney.push({
                    jid: participant,
                    number: userNumber,
                    totalMoney,
                    apodo,
                    clan: clanName
                });
            }
        }

        if (usersWithMoney.length === 0)
            return await message.reply('📊 No hay usuarios con monedas en el ranking todavía.');

        // Ordenar de mayor a menor
        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);

        // ===== CALCULAR POSICIÓN GLOBAL SIEMPRE =====
        const allUsersGlobal = [];
        {
            const _aliases = global.db.data.aliases || {};
            const _seen = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (!userData) continue;
                if (_aliases[userKey] && _aliases[userKey] !== userKey) continue;
                const _num = normalizeNumber(userKey);
                if (!_num || _seen.has(_num)) continue;
                _seen.add(_num);
                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;
                allUsersGlobal.push({ number: _num, totalMoney });
            }
        }
        allUsersGlobal.sort((a, b) => b.totalMoney - a.totalMoney);
        const globalPos = allUsersGlobal.findIndex(u => u.number === currentUserNumber) + 1;
        const globalTotal = allUsersGlobal.length;
        const itemsPerPage = 10;
        const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;
        // =============================================

        // Posición del usuario en la lista actual
        const userIndex = usersWithMoney.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // Paginación
        const totalPages = Math.max(1, Math.ceil(usersWithMoney.length / itemsPerPage));
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        const pageArg = isGlobal ? args[2] : args[1];
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = usersWithMoney.slice(start, end);

        // ===== CONSTRUIR MENSAJE =====
        let rankingText = isGlobal
            ? `*🌍 TOP DINERO GLOBAL 💰*\n\n`
            : `*🏆 TOP DINERO DEL GRUPO 💰*\n\n`;

        if (!isGlobal) {
            rankingText += `👥 *En este grupo:* ${usersWithMoney.length} jugadores en el top\n`;
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = usersWithMoney[userIndex];
                rankingText += `📍 *Tu pos. en el grupo:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *${usedPrefix}${cmd} ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. en el grupo:* No estás en el ranking\n`;
            }

            if (globalPos > 0) {
                rankingText += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                rankingText += `   ↳ Usa *${usedPrefix}${cmd} global ${globalUserPage}* para verlo\n`;
            } else {
                rankingText += `🌐 *Tu pos. global:* No estás en el ranking\n`;
            }

        } else {
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = usersWithMoney[userIndex];
                rankingText += `📍 *Tu pos. global:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *${usedPrefix}${cmd} global ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. global:* No estás en el ranking\n`;
            }
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            const modeArg = isGlobal ? ' global' : '';

            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *${usedPrefix}${cmd}${modeArg} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *${usedPrefix}${cmd}${modeArg} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        // ===== LISTA DE USUARIOS =====
        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;

            let medal;
            if (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else medal = `${pos}.`;

            const displayName = u.clan
                ? `[${u.clan}] ${u.apodo}`
                : u.apodo;

            rankingText += `${medal} *${displayName}*\n💰 ${u.totalMoney.toLocaleString()}\n\n`;
        });

        if (!isGlobal) {
            rankingText += `💡 _Usa *${usedPrefix}${cmd} global* para el top mundial_`;
        }

        await message.reply(rankingText);

    } catch (error) {
        console.error('[ERROR EN TOPCOINS]:', error);
        await message.reply('⚠️ Error al obtener el top de monedas.');
    }
};

handler.help = [
    'top', 'topcoins', 'topbal', 'baltop', 'ranking',
    'topmoney', 'moneytop', 'balancetop', 'topbalance',
    'coinstop', 'tcoins', 'tbalance', 'leaderboard', 'lb'
];
handler.tags = ['economy'];
handler.command = /^(top|topcoins|topbal|baltop|ranking|topmoney|moneytop|balancetop|topbalance|coinstop|tcoins|tbalance|leaderboard|lb)$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;