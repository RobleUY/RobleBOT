const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!message.isGroup) 
            return await message.reply('❌ Este comando solo puede usarse en grupos.');
        
        if (!global.db?.data?.users) 
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        
        const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
        const participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);
        const usersWithMoney = [];
        const currentUserNumber = normalizeNumber(message.sender);
        
        // Recolectar datos
        for (const participant of participants) {
            const userNumber = normalizeNumber(participant);
            const user = global.db.getUser(userNumber);
            
            if (!user) continue;
            
            if (!user.phone || user.phone !== userNumber) {
                user.phone = userNumber;
                global.db.setUser(userNumber, user);
            }
            
            const totalMoney = (user.money || 0) + (user.bank || 0);
            usersWithMoney.push({ jid: participant, number: userNumber, totalMoney });
        }
        
        // Ordenar de mayor a menor
        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);
        
        // Posición actual del usuario
        const userPosition = usersWithMoney.findIndex(u => u.number === currentUserNumber) + 1;
        
        // Paginación
        const itemsPerPage = 10;
        const totalPages = Math.max(1, Math.ceil(usersWithMoney.length / itemsPerPage));
        
        // Detectar prefijo y página correctamente
        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];
        
        let page = 1;
        if (args[1] && !isNaN(args[1])) page = Math.max(1, parseInt(args[1]));
        if (page > totalPages) page = totalPages;
        
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = usersWithMoney.slice(start, end);
        
        let rankingText = `*🏆 TOP DINERO DEL GRUPO 💰*\n`;
        rankingText += `_Tu posición actual:_ *#${userPosition}*\n`;
        rankingText += `_Página_ *${page}* _de_ *${totalPages}*\n`;
        
        // Solo mostrar instrucciones si hay más de una página
        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ Usa *${usedPrefix}${cmd} ${prevPage}* para la página anterior\n`;
            if (nextPage) rankingText += `➡️ Usa *${usedPrefix}${cmd} ${nextPage}* para la siguiente página\n`;
        }
        
        rankingText += `\n`;
        
        pageUsers.forEach((user, i) => {
            const globalIndex = start + i + 1;
            const medal = medals[i] || `${globalIndex}️⃣`;
            rankingText += `${medal} @${user.number}\n💰 ${user.totalMoney.toLocaleString()}\n\n`;
        });
        
        const mentionJids = pageUsers.map(u => u.jid);
        await message.reply(rankingText, { mentions: mentionJids });
        
    } catch (error) {
        console.error('[ERROR EN TOPCOINS]:', error);
        await message.reply('⚠️ Error al obtener el top de monedas.');
    }
};

handler.help = [
    'top',
    'topcoins',
    'topbal',
    'baltop',
    'ranking',
    'topmoney',
    'moneytop',
    'balancetop',
    'topbalance',
    'coinstop',
    'tcoins',
    'tbalance',
    'leaderboard',
    'lb'
];
handler.tags = ['economy'];
handler.command = /^(top|topcoins|topbal|baltop|ranking|topmoney|moneytop|balancetop|topbalance|coinstop|tcoins|tbalance|leaderboard|lb)$/i;
handler.group = true;

module.exports = handler;