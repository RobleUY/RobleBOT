const db = require('../../database.js'); // Ajusta según tu estructura

// Función para normalizar números
const normalizeNumber = (jidPart) => jidPart.split('@')[0].replace(/[^0-9]/g, '').trim();

let handler = async (message, { conn }) => {
    try {
        if (!global.db?.data?.users) 
            return await message.reply('❌ No se pudo acceder a la base de datos.');

        const senderNumber = normalizeNumber(message.sender);
        const user = global.db.getUser(senderNumber);

        // 🔒 Bloquear acceso si no tiene apodo o es "Sin Apodo"
        if (
            !user || 
            !user.apodo || 
            user.apodo.trim() === '' || 
            user.apodo.trim().toLowerCase() === 'sin apodo'
        ) {
            return await message.reply(
                `🚫 No puedes usar este comando sin tener un apodo.\n\n💡 Usa: *.apodo TuApodo* para establecer uno antes de ver el ranking.`
            );
        }

        const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];

        // Detectar prefijo, comando y argumentos
        const body = message.body || '';
        const usedPrefix = body.charAt(0) || '.';
        const args = body.trim().slice(1).split(/\s+/);
        const cmd = args[0];

        // Detectar si es modo global
        const isGlobal = args[1] && /^(g|global)$/i.test(args[1]);

        // Si no es global, verificar que sea un grupo
        if (!isGlobal && !message.isGroup) 
            return await message.reply('❌ Este comando solo puede usarse en grupos.\n💡 Usa *' + usedPrefix + cmd + ' global* para ver el top global.');

        const usersWithMoney = [];
        const currentUserNumber = normalizeNumber(message.sender);
        let participants = [];

        if (isGlobal) {
            // 🌍 Modo global: obtener todos los usuarios de la base
            const allUsers = global.db.data.users;

            for (const [userKey, userData] of Object.entries(allUsers)) {
                if (!userData) continue;

                const userNumber = normalizeNumber(userKey);
                const totalMoney = (userData.money || 0) + (userData.bank || 0);

                // Solo usuarios con apodo válido y dinero
                const apodo = (userData.apodo || '').trim();
                if (!apodo || apodo.toLowerCase() === 'sin apodo' || totalMoney <= 0) continue;

                // Obtener clan si tiene
                const clanName = userData.clan ? userData.clan.toUpperCase() : null;

                usersWithMoney.push({
                    jid: userKey,
                    number: userNumber,
                    totalMoney,
                    apodo,
                    clan: clanName
                });
            }
        } else {
            // 👥 Modo grupo: solo usuarios del grupo actual
            participants = (await conn.groupMetadata(message.from)).participants.map(p => p.id);

            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                const userData = global.db.getUser(userNumber);

                if (!userData) continue;

                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                const apodo = (userData.apodo || '').trim();

                if (!apodo || apodo.toLowerCase() === 'sin apodo' || totalMoney <= 0) continue;

                // Obtener clan si tiene
                const clanName = userData.clan ? userData.clan.toUpperCase() : null;

                usersWithMoney.push({
                    jid: participant,
                    number: userNumber,
                    totalMoney,
                    apodo,
                    clan: clanName
                });
            }
        }

        // 🧾 Verificar si hay usuarios válidos
        if (usersWithMoney.length === 0) {
            return await message.reply('📊 No hay usuarios con dinero o apodo en el ranking todavía.');
        }

        // Ordenar de mayor a menor
        usersWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);

        // Posición actual del usuario
        const userIndex = usersWithMoney.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // Paginación
        const itemsPerPage = 10;
        const totalPages = Math.max(1, Math.ceil(usersWithMoney.length / itemsPerPage));

        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        const pageArg = isGlobal ? args[2] : args[1];
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = usersWithMoney.slice(start, end);

        // 🏆 Construir mensaje
        let rankingText = isGlobal 
            ? `*🌍 TOP DINERO GLOBAL 💰*\n`
            : `*🏆 TOP DINERO DEL GRUPO 💰*\n`;

        if (userPosition > 0) {
            rankingText += `_Tu posición:_ *#${userPosition}* (Página ${userPage})\n`;
        } else {
            rankingText += `_No estás en el ranking_\n`;
        }

        rankingText += `_Mostrando página_ *${page}* _de_ *${totalPages}*\n`;

        // Navegación entre páginas
        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            const modeArg = isGlobal ? ' global' : '';

            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ Usa *${usedPrefix}${cmd}${modeArg} ${prevPage}* para la página anterior\n`;
            if (nextPage) rankingText += `➡️ Usa *${usedPrefix}${cmd}${modeArg} ${nextPage}* para la siguiente página\n`;
            if (userPage > 0 && userPage !== page) {
                rankingText += `📍 Usa *${usedPrefix}${cmd}${modeArg} ${userPage}* para ir a tu página\n`;
            }
        }

        rankingText += `\n`;

        // Mostrar ranking con clan
        pageUsers.forEach((user, i) => {
            const globalIndex = start + i + 1;
            const medal = medals[i] || `${globalIndex}️⃣`;
            
            // Construir nombre con clan
            const displayName = user.clan 
                ? `[${user.clan}] ${user.apodo}` 
                : user.apodo;
            
            rankingText += `${medal} *${displayName}*\n💰 ${user.totalMoney.toLocaleString()}\n\n`;
        });

        if (!isGlobal) {
            rankingText += `\n💡 _Usa *${usedPrefix}${cmd} global* para ver el top mundial_`;
        }

        // Enviar mensaje
        await message.reply(rankingText);

    } catch (error) {
        console.error('[ERROR EN TOPCOINS]:', error);
        await message.reply('⚠️ Error al obtener el top de monedas.');
    }
};

handler.help = [
    'top', 'topcoins', 'topbal', 'baltop', 'ranking',
    'topmoney', 'moneytop', 'balancetop', 'topbalance',
    'coinstop', 'tcoins', 'tbalance', 'leaderboard', 'lb'
];
handler.tags = ['economy'];
handler.command = /^(top|topcoins|topbal|baltop|ranking|topmoney|moneytop|balancetop|topbalance|coinstop|tcoins|tbalance|leaderboard|lb)$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;