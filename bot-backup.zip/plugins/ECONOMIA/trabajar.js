let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Asegurarnos de que el usuario existe en la base de datos
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si el usuario tiene lastWork inicializado
        if (!user.lastWork) {
            user.lastWork = 0;
        }

        let timeDiff = Date.now() - (new Date(user.lastWork)).getTime();
        let waitTime = 30000;  // 1 minuto de espera entre trabajos

        if (timeDiff < waitTime) {
            return await message.reply(`*⏰ DEBES ESPERAR ${Math.ceil((waitTime - timeDiff) / 1000)} SEGUNDOS ANTES DE TRABAJAR NUEVAMENTE.*`);
        }

        // Lista de trabajos disponibles
        let trabajos = [
            "programador", "diseñador", "escritor", "mesero", "conductor", "pintor", "jardinero", "chef", 
            "repartidor", "cajero", "vendedor", "músico", "modelo", "actor", "profesor", "ingeniero", "arquitecto", 
            "doctor", "enfermero", "fotógrafo", "astrónomo"
        ];
        
        // Selección aleatoria de trabajo
        let trabajoActual = trabajos[Math.floor(Math.random() * trabajos.length)];
        let ganancia = Math.floor(Math.random() * (10000 - 1000 + 1)) + 1000;

        // Aumentar la ganancia de dinero del usuario
        user.money = (user.money || 0) + ganancia;

        // Actualizar el tiempo de trabajo
        user.lastWork = new Date();
        user.workedHours = (user.workedHours || 0) + 1;
        user.totalWorkedHours = (user.totalWorkedHours || 0) + 1;
        user.totalWorkedTimes = (user.totalWorkedTimes || 0) + 1;

        // Aumentar 1 de respeto por trabajar
        user.respeto = (user.respeto || 0) + 1;

        // Guardar cambios en la base de datos
        global.db.setUser(senderNumber, user);
        global.db.save();

        // Formato de la respuesta con la información del trabajo realizado
        let profileInfo = `*Trabajaste de ${trabajoActual} y ganaste ${ganancia} Monedas.*\n\nTu respeto ahora es: ${user.respeto}`;

        // Enviar respuesta sin menciones para evitar errores
        return await message.reply(profileInfo);
    } catch (error) {
        console.error('[ERROR] Error en trabajo:', error);
        return await message.reply('❌ Ocurrió un error al procesar el trabajo.');
    }
};

handler.help = ['work', 'trabajar'];
handler.tags = ['economy'];
handler.command = /^(work|trabajar)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;