const achievements = require('../../achievements');
const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        // Asegurarnos de que el usuario existe en la base de datos
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si el usuario tiene lastWork inicializado
        if (!user.lastWork) {
            user.lastWork = 0;
        }

        let timeDiff = Date.now() - (new Date(user.lastWork)).getTime();
        const premiumMultiplier = premium.isPremium(message.author || sender) ? 0.5 : 1;
        let waitTime = Math.floor(60000 * premiumMultiplier);  // 1 minuto de espera entre trabajos, la mitad si es premium

        if (timeDiff < waitTime) {
            return await message.reply(`*⏰ DEBES ESPERAR ${Math.ceil((waitTime - timeDiff) / 1000)} SEGUNDOS ANTES DE TRABAJAR NUEVAMENTE.*`);
        }

        // Lista de trabajos disponibles
        let trabajos = [
            "programador", "diseñador", "escritor", "mesero", "conductor", "pintor", "jardinero", "chef", 
            "repartidor", "cajero", "vendedor", "músico", "modelo", "actor", "profesor", "ingeniero", "arquitecto", 
            "doctor", "enfermero", "fotógrafo", "astrónomo"
        ];
        
        // Selección aleatoria de trabajo
        let trabajoActual = trabajos[Math.floor(Math.random() * trabajos.length)];
        let ganancia = Math.floor(Math.random() * (1000 - 500 + 1)) + 500;

        // Aplicar multiplicador según respeto actual (antes de sumar +1)
        const respetoActual = Number(user.respeto) || 0;
        const gananciaFinal = Math.floor(ganancia * (1 + respetoActual / 100));
        const multiplier = premium.getPremiumMultiplier(message.author || sender);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        // Aumentar la ganancia de dinero del usuario
        user.money = (user.money || 0) + gananciaPremium;

        // Actualizar el tiempo de trabajo
        user.lastWork = new Date();
        user.workedHours = (user.workedHours || 0) + 1;
        user.totalWorkedHours = (user.totalWorkedHours || 0) + 1;
        user.totalWorkedTimes = (user.totalWorkedTimes || 0) + 1;

        // Sumar +1 de respeto en silencio
        user.respeto = (user.respeto || 0) + 1;
        const achievementMessage = achievements.addAchievementProgress(user, 'work');

        // Guardar cambios en la base de datos
        global.db.setUser(senderNumber, user);
        global.db.save();

        // Formato de la respuesta con la información del trabajo realizado
        let profileInfo = `_Trabajaste de_ *${trabajoActual}* _y ganaste_ *$${gananciaPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            profileInfo += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }

        if (achievementMessage) {
            profileInfo += `\n\n${achievementMessage}`;
        }

        // Enviar respuesta sin menciones para evitar errores
        return await message.reply(profileInfo);
    } catch (error) {
        console.error('[ERROR] Error en trabajo:', error);
        return await message.reply('❌ Ocurrió un error al procesar el trabajo.');
    }
};

handler.help = ['work', 'trabajar'];
handler.tags = ['economy'];
handler.command = /^(work|trabajar)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;