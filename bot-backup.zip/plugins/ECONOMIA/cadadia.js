const achievements = require('../../achievements');
const premium = require('../../premium');

let handler = async (message) => {
  try {
    const senderId = message.author || message.from;

    let user = global.db.getUser(senderId);
    if (!user) {
      user = { money: 0, lastDaily: 0, dailyReward: 0 };
    } else if (typeof user.dailyReward === 'undefined') {
      user.dailyReward = 0;
    }

    const now = Date.now();
    const premiumMultiplier = premium.isPremium(senderId) ? 0.5 : 1;
    const cooldown = Math.floor(24 * 60 * 60 * 1000 * premiumMultiplier);

    if (now - user.lastDaily < cooldown) {
      const timeLeft = cooldown - (now - user.lastDaily);
      const h = Math.floor(timeLeft / (60 * 60 * 1000));
      const m = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
      const s = Math.floor((timeLeft % (60 * 1000)) / 1000);
      return await message.reply(`⏰ Debes esperar *${h}h ${m}m ${s}s* para tu próxima recompensa diaria.`);
    }

    const baseReward = 100000;
    const reward = (user.dailyReward + 1) * baseReward;
    const multiplier = premium.getPremiumMultiplier(senderId);
    const rewardPremium = Math.floor(reward * multiplier);

    user.money += rewardPremium;
    user.lastDaily = now;
    user.dailyReward += 1;
    const achievementMessage = achievements.addAchievementProgress(user, 'daily');
    global.db.setUser(senderId, user);

    let response = `_Reclamaste tu recompensa diaria y obtuviste_ *$${rewardPremium.toLocaleString()}*\n` +
      `_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
    if (multiplier > 1) {
      response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
    }

    if (achievementMessage) {
      response += `\n\n${achievementMessage}`;
    }

    return await message.reply(response);

  } catch (err) {
    console.error('[ERROR daily]:', err);
    return await message.reply('❌ Error al procesar la diaria.');
  }
};

// Comandos que activan esta función
handler.command = /^(cadadia|daily)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;