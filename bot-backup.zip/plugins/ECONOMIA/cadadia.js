// handler-daily.js
let handler = async (message, { text }) => {
  try {
    // 1) Obtener ID único del usuario
    const senderId = message.author || message.from; 
    const senderNumber = senderId.split('@')[0];

    // 2) Cargar datos del usuario desde tu base de datos global
    let user = global.db.getUser(senderId); 
    if (!user) {
      user = { money: 0, lastDaily: 0 };
    }

    // 3) Calcular cooldown de 24 horas
    const now = Date.now();
    const cooldown = 24 * 60 * 60 * 1000; // 24h en milisegundos
    if (now - user.lastDaily < cooldown) {
      const timeLeft = cooldown - (now - user.lastDaily);
      const h = Math.floor(timeLeft / (60*60*1000));
      const m = Math.floor((timeLeft % (60*60*1000)) / (60*1000));

      return await message.reply(
        `⏰ Debes esperar ${h}h ${m}m para tu próxima diaria.`,
        { mentions: [senderId] }
      );
    }

    // 4) Dar recompensa y guardar cambios
    const reward = 100000;
    user.money += reward;
    user.lastDaily = now;
    global.db.setUser(senderId, user);

    // 5) Enviar mensaje de confirmación
    return await message.reply(
      `✅ ¡Reclamado!\n\n💰 Recompensa: ${reward} monedas\n` +
      `💳 Saldo: ${user.money} monedas\n\n📅 Vuelve mañana.`,
      { mentions: [senderId] }
    );

  } catch (err) {
    console.error('[ERROR daily]:', err);
    return await message.reply('❌ Error al procesar la diaria.');
  }
};

// Comandos que activan esta función
handler.command = /^(cadadia|daily)$/i;

module.exports = handler;
handler.group = true;
