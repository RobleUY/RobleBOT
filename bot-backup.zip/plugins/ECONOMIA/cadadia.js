// handler-daily.js
let handler = async (message, { text }) => {
  try {
    // 1) Obtener ID único del usuario
    const senderId = message.author || message.from;
    // const senderNumber = senderId.split('@')[0]; // No es necesario para esta lógica

    // 2) Cargar datos del usuario desde tu base de datos global
    let user = global.db.getUser(senderId);
    if (!user) {
      // ⚠️ IMPORTANTE: Inicializar 'dailyReward' a 0 para el primer reclamo
      user = { money: 0, lastDaily: 0, dailyReward: 0 };
      // Asegúrate de que `global.db.getUser` devuelva un objeto con la estructura completa,
      // o ajusta la inicialización aquí si es la primera vez que se carga.
      // Si el usuario existe pero no tiene 'dailyReward', debes inicializarlo:
    } else if (typeof user.dailyReward === 'undefined') {
        user.dailyReward = 0;
    }

    // 3) Calcular cooldown de 24 horas
    const now = Date.now();
    const cooldown = 24 * 60 * 60 * 1000; // 24h en milisegundos
    if (now - user.lastDaily < cooldown) {
      const timeLeft = cooldown - (now - user.lastDaily);
      const h = Math.floor(timeLeft / (60 * 60 * 1000));
      const m = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
      const s = Math.floor((timeLeft % (60 * 1000)) / 1000); // Agregamos segundos para más precisión

      return await message.reply(
        `⏰ Debes esperar *${h}h ${m}m ${s}s* para tu próxima recompensa diaria.`,
        { mentions: [senderId] }
      );
    }

    // 4) Calcular la recompensa progresiva y actualizar
    // dailyReward empieza en 0.
    // Primer reclamo (dailyReward = 0) -> (0 + 1) * 100,000 = 100,000
    // Segundo reclamo (dailyReward = 1) -> (1 + 1) * 100,000 = 200,000
    // Tercer reclamo (dailyReward = 2) -> (2 + 1) * 100,000 = 300,000
    // y así sucesivamente...
    const baseReward = 100000;
    const reward = (user.dailyReward + 1) * baseReward;

    // 5) Dar recompensa y guardar cambios
    user.money += reward;
    user.lastDaily = now;
    user.dailyReward += 1; // 💡 Incrementar el contador de recompensas diarias
    global.db.setUser(senderId, user); // Guardar el usuario con los datos actualizados

    // 6) Enviar mensaje de confirmación
    return await message.reply(
      `✅ ¡Reclamado!\n\n` +
      `*🎉 Racha diaria:* ${user.dailyReward}\n` +
      `*💰 Recompensa:* ${reward.toLocaleString()} monedas\n` +
      `*💳 Saldo total:* ${user.money.toLocaleString()} monedas\n\n` +
      `📅 Vuelve mañana para tu próxima recompensa de ${(reward + baseReward).toLocaleString()} monedas.`,
      { mentions: [senderId] }
    );

  } catch (err) {
    console.error('[ERROR daily]:', err);
    return await message.reply('❌ Error al procesar la diaria.');
  }
};

// Comandos que activan esta función
handler.command = /^(cadadia|daily)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;