// handler-webcode.js
const axios = require('axios');

const JSONBIN_URL = "https://api.jsonbin.io/v3/b/68899a1bae596e708fbdef92/latest";
const MASTER_KEY = "$2a$10$mB99k0u.4sDlk03TnvSZ2uRGg9lsZOwAuJbbk.2pX3QQ/HBk0xvhu";
const SITE_URL = "https://robleuy.site/roblebot/webcodes";

// 🔹 Cooldown temporal en memoria (sin DB)
const cooldowns = {}; // { senderId: timestamp }

let handler = async (message, { args }) => {
  try {
    const senderId = message.author || message.from;
    const code = args[0];

    // 1️⃣ Validar formato del código
    if (!code || !/^\d{4}$/.test(code)) {
      return await message.reply(
        `❌ **Formato inválido.**\nUsa: \`/webcode 1234\` (4 dígitos).\n\n🌐 Códigos disponibles en:\n👉 ${SITE_URL}`
      );
    }

    // 2️⃣ Revisar cooldown (en memoria)
    const now = Date.now();
    const cooldown = 60 * 60 * 1000; // 1 hora
    if (cooldowns[senderId] && now - cooldowns[senderId] < cooldown) {
      const msLeft = cooldown - (now - cooldowns[senderId]);
      const m = Math.floor(msLeft / (60 * 1000));
      const s = Math.floor((msLeft % (60 * 1000)) / 1000);
      return await message.reply(
        `⏳ *Espera ${m}m ${s}s* antes de reclamar otro código.\n\n🌐 Puedes consultar nuevos códigos en:\n👉 ${SITE_URL}`
      );
    }

    // 3️⃣ Leer los datos desde JSONBin
    const res = await axios.get(JSONBIN_URL, {
      headers: { "X-Master-Key": MASTER_KEY }
    });

    let codes = res.data.record.codes || {};

    // 4️⃣ Validar existencia del código
    if (!codes[code]) {
      return await message.reply(
        `🚫 *Código no válido.*\nPuede que haya expirado o nunca existió.\n\n🔎 Busca nuevos códigos aquí:\n👉 ${SITE_URL}`
      );
    }

    // 5️⃣ Validar si ya fue reclamado
    if (codes[code].claimed) {
      return await message.reply(
        `⚠️ *Este código ya fue reclamado.*\nPrueba con otro disponible.\n\n🎁 Encuentra más códigos activos en:\n👉 ${SITE_URL}`
      );
    }

    // 6️⃣ Marcar el código como reclamado
    codes[code].claimed = true;
    await axios.put(JSONBIN_URL.replace("/latest", ""), { codes }, {
      headers: {
        "X-Master-Key": MASTER_KEY,
        "Content-Type": "application/json"
      }
    });

    // 7️⃣ Recompensa
    let user = global.db.getUser(senderId) || { money: 0 };
    const reward = codes[code].reward || 0;
    user.money += reward;
    global.db.setUser(senderId, user);

    cooldowns[senderId] = now; // guardar cooldown en memoria

    // 8️⃣ Mensaje final de éxito con invitación
    return await message.reply(
      `🎉 *¡Código válido!* 🎉\n\n💰 Has ganado: *${reward} monedas*\n💳 Tu saldo actual: *${user.money} monedas*\n\n⏰ Podrás reclamar otro código en *1 hora*.\n\n🌐 Invita a tus amigos a usar RobleBOT y ganar también códigos gratis:\n👉 ${SITE_URL}`
    );

  } catch (err) {
    console.error('[ERROR webcode]:', err.response?.data || err.message);
    return await message.reply(
      `❌ *Error al procesar el código o al conectar con el servidor.*\nInténtalo más tarde.\n\n📍 Revisa el sitio oficial:\n👉 ${SITE_URL}`
    );
  }
};

handler.command = /^webcode$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;