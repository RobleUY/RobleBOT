// handler-minar.js
let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener número real
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener usuario desde la DB
        let user = global.db.getUser(senderNumber);
        if (!user) {
            return await message.reply("❌ No se pudo cargar tu usuario en la base de datos.");
        }

        // Cooldown de minar
        let cooldown = 30000; // 30 segundos
        let timeDiff = Date.now() - (new Date(user.lastMining)).getTime();

        if (timeDiff < cooldown) {
            return await message.reply(`⏳ Debes esperar ${Math.ceil((cooldown - timeDiff) / 1000)} segundos antes de volver a minar.`);
        }

        // Probabilidades y cantidades de cada mineral
        let mineralesProb = [
            { nombre: "CARBON", prob: 40, min: 7, max: 10 },
            { nombre: "HIERRO", prob: 25, min: 6, max: 10 },
            { nombre: "PLATA", prob: 15, min: 5, max: 10 },
            { nombre: "ORO", prob: 10, min: 4, max: 10 },
            { nombre: "DIAMANTE", prob: 5, min: 3, max: 10 },
            { nombre: "ESMERALDA", prob: 3, min: 2, max: 10 },
            { nombre: "RUBI", prob: 2, min: 1, max: 10 }
        ];

        // Precios de minerales
        let precios = {
            CARBON: 10,
            HIERRO: 20,
            PLATA: 30,
            ORO: 40,
            DIAMANTE: 50,
            ESMERALDA: 60,
            RUBI: 70
        };

        // Selección según probabilidad
        let totalProb = mineralesProb.reduce((sum, m) => sum + m.prob, 0);
        let rand = Math.random() * totalProb;
        let acumulado = 0;
        let obtenido = null;

        for (let m of mineralesProb) {
            acumulado += m.prob;
            if (rand <= acumulado) {
                let cantidad = Math.floor(Math.random() * (m.max - m.min + 1)) + m.min;
                user.minerales[m.nombre] += cantidad;
                obtenido = { nombre: m.nombre, cantidad };
                break;
            }
        }

        // Calcular venta inmediata
        let totalGanancia = 0;
        let detalleVenta = [];
        for (let mineral in user.minerales) {
            let cantidad = user.minerales[mineral] || 0;
            if (cantidad > 0) {
                let valor = precios[mineral] * cantidad;
                totalGanancia += valor;
                detalleVenta.push(`${mineral}: ${cantidad} x ${precios[mineral]} = ${valor}`);
                user.minerales[mineral] = 0; // resetear inventario
            }
        }

        // Actualizar datos
        user.money += totalGanancia;
        user.lastMining = new Date();
        global.db.setUser(senderNumber, user);
        global.db.save();

        return await message.reply(
            `_Fuiste a minar y vendiste_ *${obtenido.cantidad}* _de_ *${obtenido.nombre}* _por:_ *$${totalGanancia.toLocaleString()}*\n` +
            `_Nuevo saldo:_ *$${user.money.toLocaleString()}*`
        );

    } catch (error) {
        console.error("[ERROR] Error en minería:", error);
        return await message.reply("❌ Ocurrió un error al procesar minería.");
    }
};

handler.help = ['minar'];
handler.tags = ['economy'];
handler.command = /^(minar|minerar|mine)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;