const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// Usar la carpeta data/ en lugar de dentro de plugins/
const USUARIOS_DIR = path.join(process.cwd(), 'data', 'NOTAS-VOZ-GUARDADAS');

// Crear directorio de usuarios si no existe
if (!fs.existsSync(USUARIOS_DIR)) {
    fs.mkdirSync(USUARIOS_DIR, { recursive: true });
}

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

// 🟢 COMANDO PRINCIPAL - Maneja todos los subcomandos de nvoz
let handler = async (message, { args }) => {
    try {
        const subcomando = args[0]?.toLowerCase();
        
        // Si no hay subcomando, mostrar ayuda
        if (!subcomando) {
            return await message.reply(
                '🎤 *COMANDOS DE NOTAS DE VOZ*\n\n' +
                '📝 *Guardar:*\n' +
                '  .nvoz save <nombre>\n' +
                '  .nvoz guardar <nombre>\n\n' +
                '📤 *Enviar:*\n' +
                '  .nvoz send <nombre>\n' +
                '  .nvoz enviar <nombre>\n\n' +
                '📋 *Ver lista:*\n' +
                '  .nvoz list\n' +
                '  .nvoz lista\n\n' +
                '🗑️ *Eliminar:*\n' +
                '  .nvoz delete <nombre>\n' +
                '  .nvoz borrar <nombre>\n\n' +
                '⚠️ *Límites:*\n' +
                '  • Máximo 10 minutos de duración\n' +
                '  • Máximo 10 MB de tamaño\n\n' +
                '_Responde a un audio con .nvoz save para guardarlo._'
            );
        }

        const sock = global.conn;
        if (!sock) {
            return await message.reply('❌ Error: Conexión no disponible.');
        }

        const sender = message.from;
        const userId = sender.split('@')[0];
        const userDir = path.join(USUARIOS_DIR, userId);

        // Crear directorio del usuario si no existe
        if (!fs.existsSync(userDir)) {
            fs.mkdirSync(userDir, { recursive: true });
        }

        // SUBCOMANDO: LIST / LISTA
        if (['list', 'lista'].includes(subcomando)) {
            const files = fs.readdirSync(userDir);
            const audioFiles = files.filter(f => f.endsWith('.opus') || f.endsWith('.ogg') || f.endsWith('.mp3'));

            if (audioFiles.length === 0) {
                return await message.reply('📭 No tienes notas de voz guardadas.');
            }

            let lista = '🎵 *TUS NOTAS DE VOZ GUARDADAS:*\n\n';
            
            audioFiles.forEach((file, index) => {
                const filePath = path.join(userDir, file);
                const stats = fs.statSync(filePath);
                const sizeKB = (stats.size / 1024).toFixed(2);
                const nombre = file.replace(/\.(opus|ogg|mp3)$/, '');
                
                lista += `${index + 1}. 🎤 *${nombre}*\n`;
                lista += `   📦 Tamaño: ${sizeKB} KB\n\n`;
            });

            lista += '_Usa .nvoz delete <nombre> para eliminar una nota._';
            return await message.reply(lista);
        }

        // SUBCOMANDO: DELETE / BORRAR
        if (['delete', 'borrar', 'eliminar'].includes(subcomando)) {
            const nombre = args[1];
            if (!nombre) {
                return await message.reply(
                    '❌ Debes proporcionar el nombre de la nota de voz a eliminar.\n\n' +
                    '*Uso:* .nvoz delete nombredelanota\n\n' +
                    '_Usa .nvoz list para ver tus notas guardadas._'
                );
            }

            const files = fs.readdirSync(userDir);
            const audioFiles = files.filter(f => 
                (f.endsWith('.opus') || f.endsWith('.ogg') || f.endsWith('.mp3')) &&
                f.replace(/\.(opus|ogg|mp3)$/, '').toLowerCase() === nombre.toLowerCase()
            );

            if (audioFiles.length === 0) {
                return await message.reply(
                    `❌ No se encontró ninguna nota de voz con el nombre *${nombre}*.\n\n` +
                    '_Usa .nvoz list para ver tus notas guardadas._'
                );
            }

            const filePath = path.join(userDir, audioFiles[0]);
            fs.unlinkSync(filePath);

            return await message.reply(
                `✅ *Nota de voz eliminada exitosamente!*\n\n` +
                `🗑️ *Nombre:* ${nombre}\n\n` +
                `_Usa .nvoz list para ver tus notas restantes._`
            );
        }

        // SUBCOMANDO: SEND / ENVIAR - Enviar una nota de voz guardada
        if (['send', 'enviar'].includes(subcomando)) {
            const nombre = args[1];
            if (!nombre) {
                return await message.reply(
                    '❌ Debes proporcionar el nombre de la nota de voz a enviar.\n\n' +
                    '*Uso:* .nvoz send nombredelanota\n\n' +
                    '_Usa .nvoz list para ver tus notas guardadas._'
                );
            }

            // Buscar el archivo con cualquier extensión
            const files = fs.readdirSync(userDir);
            const audioFiles = files.filter(f => 
                (f.endsWith('.opus') || f.endsWith('.ogg') || f.endsWith('.mp3')) &&
                f.replace(/\.(opus|ogg|mp3)$/, '').toLowerCase() === nombre.toLowerCase()
            );

            if (audioFiles.length === 0) {
                return await message.reply(
                    `❌ No se encontró ninguna nota de voz con el nombre *${nombre}*.\n\n` +
                    '_Usa .nvoz list para ver tus notas guardadas._'
                );
            }

            // Leer el archivo y enviarlo como respuesta al mensaje
            const filePath = path.join(userDir, audioFiles[0]);
            const audioBuffer = fs.readFileSync(filePath);

            try {
                await sock.sendMessage(sender, {
                    audio: audioBuffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true
                }, { quoted: message._baileyMessage });

                console.log(`✅ Nota de voz "${nombre}" enviada a ${userId}`);
            } catch (error) {
                console.error('❌ Error al enviar nota de voz:', error);
                return await message.reply('❌ Error al enviar la nota de voz.');
            }
            return;
        }

        // SUBCOMANDO: SAVE / GUARDAR
        if (['save', 'guardar'].includes(subcomando)) {
            const nombre = args[1];
            if (!nombre) {
                return await message.reply(
                    '❌ Debes proporcionar un nombre para el audio.\n\n' +
                    '*Uso:* .nvoz save nombredelaudio\n\n' +
                    '_Responde a un audio con este comando._'
                );
            }

            // Validar que el nombre solo contenga letras y números
            if (!/^[a-zA-Z0-9]+$/.test(nombre)) {
                return await message.reply(
                    '❌ El nombre debe contener solo letras y números, sin espacios ni caracteres especiales.\n\n' +
                    '*Ejemplo:* .nvoz save minotadevoz123'
                );
            }

            // Obtener el mensaje citado
            const baileyMsg = global.lastBaileyMessage;
            if (!baileyMsg) {
                return await message.reply('❌ Error al obtener el mensaje.');
            }

            const contextInfo = baileyMsg.message?.extendedTextMessage?.contextInfo;
            if (!contextInfo?.quotedMessage) {
                return await message.reply(
                    '❌ Debes responder a un audio para guardarlo.\n\n' +
                    '*Uso:* Responde a un audio con .nvoz save nombredelaudio'
                );
            }

            const quotedMessage = contextInfo.quotedMessage;
            const audioMsg = quotedMessage.audioMessage;

            // Verificar que sea un audio (PTT o normal)
            if (!audioMsg) {
                return await message.reply(
                    '❌ Debes responder a un audio (nota de voz o audio normal) para guardarlo.'
                );
            }

            // Verificar tamaño (máximo 10 MB = 10485760 bytes)
            const fileSize = audioMsg.fileLength || 0;
            const maxSize = 10 * 1024 * 1024; // 10 MB en bytes
            if (fileSize > maxSize) {
                const sizeMB = (fileSize / (1024 * 1024)).toFixed(2);
                return await message.reply(
                    `❌ El audio es muy pesado (${sizeMB} MB).\n\n` +
                    '📦 Solo puedes guardar audios de máximo 10 MB.'
                );
            }

            // Verificar duración (máximo 10 minutos = 600 segundos)
            const duracion = audioMsg.seconds || 0;
            if (duracion > 600) {
                const minutos = Math.floor(duracion / 60);
                const segundos = duracion % 60;
                return await message.reply(
                    `❌ El audio es muy largo (${minutos}:${segundos.toString().padStart(2, '0')}).\n\n` +
                    '⏱️ Solo puedes guardar audios de máximo 10 minutos.'
                );
            }

            // Verificar si ya existe
            const extension = audioMsg.mimetype?.includes('ogg') ? 'ogg' : 'opus';
            const fileName = `${nombre}.${extension}`;
            const filePath = path.join(userDir, fileName);

            if (fs.existsSync(filePath)) {
                return await message.reply(
                    `❌ Ya tienes una nota de voz guardada con el nombre *${nombre}*.\n\n` +
                    'Elige otro nombre o elimina la anterior con .nvoz delete nombredelanota'
                );
            }

            // Descargar el audio
            await message.reply('⏳ Guardando audio...');

            try {
                const stream = await downloadContentFromMessage(audioMsg, 'audio');
                const buffer = await streamToBuffer(stream);

                // Guardar el archivo
                fs.writeFileSync(filePath, buffer);

                const duracion = audioMsg.seconds || 0;
                const minutos = Math.floor(duracion / 60);
                const segundos = duracion % 60;
                const duracionTexto = minutos > 0 
                    ? `${minutos}:${segundos.toString().padStart(2, '0')}` 
                    : `${segundos}s`;

                return await message.reply(
                    `✅ *Audio guardado exitosamente!*\n\n` +
                    `🎤 *Nombre:* ${nombre}\n` +
                    `⏱️ *Duración:* ${duracionTexto}\n\n` +
                    `_Usa .nvoz list para ver todos tus audios guardados._`
                );

            } catch (error) {
                console.error('❌ Error al descargar/guardar audio:', error);
                return await message.reply('❌ Error al guardar el audio. Intenta nuevamente.');
            }
        }

        // Si el subcomando no es reconocido
        return await message.reply(
            '❌ Subcomando no reconocido.\n\n' +
            'Usa .nvoz sin argumentos para ver los comandos disponibles.'
        );

    } catch (error) {
        console.error('❌ Error general en handler nvoz:', error);
        await message.reply('❌ Ocurrió un error al procesar el comando.');
    }
};

handler.help = ['nvoz', 'notavoz', 'notadevoz', 'notasdevoz'];
handler.tags = ['tools'];
handler.command = /^(nvoz|notavoz|notadevoz|notasdevoz)$/i;

module.exports = handler;
