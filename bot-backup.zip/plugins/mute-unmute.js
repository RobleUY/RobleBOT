/**
 * Comando .unmute - Desmutear usuario en grupo
 * Requiere: Sistema MuteSystem global
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar que el sistema de muteo esté disponible
        if (!global.muteSystem) {
            return await message.reply('❌ Sistema de muteo no disponible. Reinicia el bot.');
        }

        // Delegar todo el procesamiento al sistema global
        await global.muteSystem.handleUnmuteCommand(message);

    } catch (error) {
        console.error('[Plugin Unmute] Error:', error);
        await message.reply('❌ Error al procesar el comando.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
    }
};

handler.help = ['unmute'];
handler.tags = ['admin'];
handler.command = /^(unmute|desmutear|dessilenciar)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;