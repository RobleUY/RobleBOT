let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            // Este log de error ayudará si hay problemas futuros
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let targetJid = null;
        let extraText = text.trim();

        // Obtener las menciones directamente del objeto message compatible
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            // Si hay menciones, el primer mencionado es el objetivo
            targetJid = mentionedJids[0];
            // Se limpia el texto para eliminar todas las menciones
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // Si no hay objetivo (mención o texto), enviar un error
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar un objetivo, ya sea mencionando a un usuario o colocando un texto. Ejemplo: .follar @juan o .follar al sol');
        }

        const kissMessages = [
            "te follaste bien duro a",
            "le diste como cajón que no cierra a",
            "le rompiste el culo a",
            "invitaste al bot y entre los 2 se cojieron a",
            "Disfrutaste follarle el culo a",
            "Despues de una follada salvaje dejaste en silla de ruedas a"
        ];
        let randomIndex = Math.floor(Math.random() * kissMessages.length);
        let kissMessageText = kissMessages[randomIndex];

        let kissMessage = `🥵 *Sexo* 💋\n\n`;
        let mentions = [senderJid]; // La lista de menciones siempre incluye al remitente

        if (targetJid) {
            // Si el objetivo es una mención
            const targetNumber = targetJid.split('@')[0];
            kissMessage += `εつ▄█▀█● *@${senderNumber} ${kissMessageText}* *@${targetNumber}*.`;
            mentions.push(targetJid);
        } else {
            // Si el objetivo es solo texto
            kissMessage += `εつ▄█▀█● *@${senderNumber} ${kissMessageText}* *${extraText}*.`;
        }

        // Añadir el texto adicional si existe y el objetivo fue una mención
        if (extraText && targetJid) {
            kissMessage += `\n\npd: ${extraText}`;
        }

        // Enviar el mensaje con la lista de menciones
        await message.reply(kissMessage, { mentions: mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el beso:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar el beso.');
    }
};

handler.help = ['follar'];
handler.tags = ['fun'];
handler.command = /^(follar)$/i;

module.exports = handler;