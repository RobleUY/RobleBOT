const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF a un MP4 ligero compatible con WhatsApp
 * Incluye filtro para forzar dimensiones pares y evitar errores de libx264
 */
const { convertGifToMp4 } = require('../../lib/convertGifToMp4');

/**
 * 🎯 Handler .follar - Envía la animación con el GIF nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Ruta: carpeta 'gifs' dentro del directorio del plugin
        const gifPath = path.join(__dirname, 'gifs', 'follar.gif');
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *follar.gif* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay un objetivo
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar un objetivo. Ejemplo: *.follar @juan* o *.follar a la vida*');
        }

        // 📝 Mensajes aleatorios y dinámicos para la acción
        const actionMessages = [
            "se la metió doblada a",
            "le dio contra el muro a",
            "dejó sin piernas a",
            "le dio una noche inolvidable a"
        ];
        let randomIndex = Math.floor(Math.random() * actionMessages.length);
        let actionMessageText = actionMessages[randomIndex];

        let actionMessage = ``;
        let mentions = [senderJid];

        // Construir el texto final de manera compacta
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            actionMessage += `*@${senderNumber} ${actionMessageText}* *@${targetNumber}* 🥵👉👌`;
            mentions.push(targetJid);
        } else {
            actionMessage += `*@${senderNumber} ${actionMessageText}* *${extraText}* 🥵👉👌`;
        }

        if (extraText && targetJid) {
            actionMessage += `\n\n*pd: ${extraText}*`;
        }

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el GIF nativo con el texto en el pie del archivo
        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: actionMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el comando:', error, '\x1b[0m');
        if (error && error.code === 'ENOSPC') {
            await message.reply('❌ Espacio insuficiente en disco para procesar el archivo. Libera espacio e intenta nuevamente.');
        } else {
            await message.reply('❌ Ocurrió un error al procesar el comando.');
        }
    }
};

handler.help = ['follar'];
handler.tags = ['fun'];
handler.command = /^(follar|fuck)$/i;

module.exports = handler;
