let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let targetJid = null;
        let extraText = text.trim();

        // Obtener las menciones directamente del objeto message
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim();
        }

        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar un objetivo, ya sea mencionando a un usuario o colocando un texto. Ejemplo: .love @juana o .love al sol');
        }

        const lovePercentage = Math.floor(Math.random() * 101); // Número aleatorio entre 0 y 100

        // Seleccionar mensaje basado en el porcentaje
        let loveMessageText = '';
        if (lovePercentage < 10) {
            loveMessageText = "La conexión es casi inexistente. Quizás sea mejor ser amigos.";
        } else if (lovePercentage < 20) {
            loveMessageText = "El amor apenas se asoma, pero podría crecer con el tiempo.";
        } else if (lovePercentage < 30) {
            loveMessageText = "Hay una chispa tenue, se nota un pequeño interés.";
        } else if (lovePercentage < 40) {
            loveMessageText = "La compatibilidad es baja, pero nunca se sabe lo que puede pasar.";
        } else if (lovePercentage < 50) {
            loveMessageText = "No está mal, aunque aún hay espacio para mejorar.";
        } else if (lovePercentage < 60) {
            loveMessageText = "Una conexión moderada, con potencial de desarrollo.";
        } else if (lovePercentage < 70) {
            loveMessageText = "Se percibe un vínculo especial, sigue cultivándolo.";
        } else if (lovePercentage < 80) {
            loveMessageText = "La química es buena, hay algo de magia en el aire.";
        } else if (lovePercentage < 90) {
            loveMessageText = "¡Son el uno para el otro! El amor se siente en el ambiente.";
        } else {
            loveMessageText = "Una unión perfecta, el amor incondicional reina entre ustedes.";
        }

        let loveMessage = `💖 *Porcentaje de Amor* 💖\n\n`;
        let mentions = [senderJid];

        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            loveMessage += `*Entre @${senderNumber} y @${targetNumber}:* ❤️ *${lovePercentage}%* ❤️\n\n`;
            mentions.push(targetJid);
        } else {
            loveMessage += `*Entre @${senderNumber} y ${extraText}:* ❤️ *${lovePercentage}%* ❤️\n\n`;
        }

        loveMessage += loveMessageText;

        if (extraText && targetJid) {
            loveMessage += `\n\n*pd: ${extraText}*`;
        }

        await message.reply(loveMessage, { mentions: mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al calcular el porcentaje de amor:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al calcular el porcentaje de amor.');
    }
};

handler.help = ['love'];
handler.tags = ['fun'];
handler.command = /^(love)$/i;

module.exports = handler;