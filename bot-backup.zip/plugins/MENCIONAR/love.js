const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const baseArgs = [
      '-y', '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-pix_fmt', 'yuv420p', '-c:v', 'libx264', '-movflags', '+faststart', '-an',
      outputPath
    ];
    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const gifPath = path.join(__dirname, 'gifs', 'love.gif');
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *love.gif* en la ruta: \n_${gifPath}_`);
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

        let targetText = text ? text.trim() : '';
        if (!targetText) {
            return await message.reply('❌ Especifica una persona o texto. Ejemplo: *.love @juan* o *.love pepe*');
        }

        const mentionedJids = message?.mentions || [];
        let targetFormatted = mentionedJids.length > 0 ? `@${mentionedJids[0].split('@')[0]}` : `*${targetText}*`;
        let mentions = [senderJid, ...mentionedJids];

        const lovePercentage = Math.floor(Math.random() * 101);
        const senderFormatted = `@${senderJid.split('@')[0]}`;

        // Texto corto personalizado solicitado
        let loveMessage = `Entre ${senderFormatted} y ${targetFormatted} hay un *${lovePercentage}%* de compatibilidad amorosa ❤️`;

        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        await sock.sendMessage(
            message.from, 
            { video: mp4Buffer, gifPlayback: true, caption: loveMessage, mentions: mentions }, 
            { quoted: message._baileyMessage || message }
        );
    } catch (error) {
        console.error('[ERROR love]:', error);
        await message.reply('❌ Ocurrió un error al calcular el amor.');
    }
};

handler.help = ['love'];
handler.tags = ['fun'];
handler.command = /^(love|amor)$/i;

module.exports = handler;
