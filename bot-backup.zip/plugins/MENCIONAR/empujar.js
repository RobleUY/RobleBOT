const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-pix_fmt', 'yuv420p',
      '-c:v', 'libx264',
      '-movflags', '+faststart',
      '-an',
      outputPath
    ];
    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const gifName = 'empujar.gif';
    const gifPath = path.join(__dirname, 'gifs', gifName);
    
    if (!fsSync.existsSync(gifPath)) {
        return await message.reply(`❌ No se encontró el archivo *${gifName}* en la carpeta de gifs.`);
    }

    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const senderNumber = senderJid.split('@')[0];
    const mentionedJids = message?.mentions || [];
    
    let targetJid = mentionedJids[0] || null;
    let extraText = text ? text.replace(/@\d+/g, "").trim() : '';

    if (!targetJid && !extraText) {
        return await message.reply('❌ ¿A quién quieres empujar? Ejemplo: *.empujar @usuario*');
    }

    const pushPhrases = [
        "le dio un empujoncito juguetón a",
        "empujó suavemente a",
        "hizo que se moviera un poco al empujar a",
        "le dio un ligero empujón a"
    ];
    
    const hugMessageText = pushPhrases[Math.floor(Math.random() * pushPhrases.length)];
    let mentions = [senderJid];
    let caption = `*@${senderNumber} ${hugMessageText}* `;

    if (targetJid) {
        caption += `*@${targetJid.split('@')[0]}* 👊💥`;
        mentions.push(targetJid);
    } else {
        caption += `*${extraText}* 👊💥`;
    }

    try {
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: caption,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );
    } catch (e) {
        console.error(e);
        await message.reply('❌ Hubo un error al procesar el gif.');
    }
};

handler.help = ['empujar'];
handler.tags = ['fun'];
handler.command = /^(empujar|push)$/i;

module.exports = handler;