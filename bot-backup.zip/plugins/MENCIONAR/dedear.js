const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const NSFW_FILE = path.join(__dirname, '..', 'NSFW', 'GRUPOS', 'nsfw.json');

function isNsfwEnabled(groupJid) {
    try {
        if (fsSync.existsSync(NSFW_FILE)) {
            const parsed = JSON.parse(fsSync.readFileSync(NSFW_FILE, 'utf8'));
            const groups = Array.isArray(parsed) ? parsed : [];
            const cleanJid = groupJid.split('@')[0];
            return groups.includes(cleanJid);
        }
    } catch (_) {}
    return false;
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF a un MP4 ligero compatible con WhatsApp (Arreglado para dimensiones impares)
 */
async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', // ✨ Fuerza a que el ancho y alto sean pares redondeando hacia abajo
      '-pix_fmt', 'yuv420p',
      '-c:v', 'libx264',
      '-movflags', '+faststart',
      '-an',
      outputPath
    ];

    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * 🎯 Handler .dedear - Envía un piquete de ojos / dedazo con el GIF animado nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Elegir GIF según si el grupo tiene NSFW activado
        const chatId = message.from || message.key?.remoteJid;
        const nsfwOn = isNsfwEnabled(chatId);
        const gifName = nsfwOn ? 'dedear_nsfw.gif' : 'dedear.gif';
        const gifPath = path.join(__dirname, 'gifs', gifName);
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *${gifName}* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay a quién dedear
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién dedear. Ejemplo: *.dedear @juan* o *.dedear a todos*');
        }

        // 📝 Mensajes aleatorios de dedazos
        const pokeMessages = [
            "le metió los dedos a",
            "le dio una dedeada a",
            "andaba con ganas de meterle los dedos a",
            "le introdujo muy fuerte sus dedos a"
        ];
        let randomIndex = Math.floor(Math.random() * pokeMessages.length);
        let pokeMessageText = pokeMessages[randomIndex];

        let pokeMessage = ``;
        let mentions = [senderJid];

        // Construir el texto
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            pokeMessage += `*@${senderNumber} ${pokeMessageText}* *@${targetNumber}* 👉💥`;
            mentions.push(targetJid);
        } else {
            pokeMessage += `*@${senderNumber} ${pokeMessageText}* *${extraText}* 👉💥`;
        }

        if (extraText && targetJid) {
            pokeMessage += `\n\n*pd: ${extraText}*`;
        }

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el GIF nativo con el texto limpio
        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: pokeMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el dedazo:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al ejecutar el comando.');
    }
};

handler.help = ['dedear'];
handler.tags = ['fun'];
handler.command = /^(dedear|poke)$/i;

module.exports = handler;