let handler = async (message, { text }) => {
    try {
        // Get the sender's JID securely
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID not found in message object:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let targetJid = null;
        let extraText = text.trim();

        // Get mentions directly from the compatible message object
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            // If there are mentions, the first one is the target
            targetJid = mentionedJids[0];
            // Clear the text to remove all mentions
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // If no target (mention or text) is provided, send an error
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar un objetivo, ya sea mencionando a un usuario o colocando un texto. Ejemplo: .golpear @juan o .golpear al sol');
        }

        const fightMessages = [
            "enviaste al hospital luego de una paliza a",
            "intentaste armar una pelea pero fuiste abusado sexualmente por",
            "no fue suficiente golpearlo entonces tambien violaste a",
            "lograste conectar algunos golpes pero al final recibiste una eyaculacion de"
        ];
        let randomIndex = Math.floor(Math.random() * fightMessages.length);
        let fightMessageText = fightMessages[randomIndex];

        let fightMessage = `🥊 *PELEAAA* 🥊\n\n`;
        let mentions = [senderJid]; // The list of mentions always includes the sender

        if (targetJid) {
            // If the target is a mention
            const targetNumber = targetJid.split('@')[0];
            fightMessage += `*@${senderNumber} ${fightMessageText}* *@${targetNumber}*.`;
            mentions.push(targetJid);
        } else {
            // If the target is just text
            fightMessage += `*@${senderNumber} ${fightMessageText}* *${extraText}*.`;
        }

        // Add additional text if it exists and the target was a mention
        if (extraText && targetJid) {
            fightMessage += `\n\n*pd: ${extraText}*`;
        }

        // Send the message with the list of mentions
        await message.reply(fightMessage, { mentions: mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el golpe:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar el golpe.');
    }
};

handler.help = ['golpear'];
handler.tags = ['fun'];
handler.command = /^(golpear)$/i;

module.exports = handler;