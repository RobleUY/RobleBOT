const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF a un MP4 ligero compatible con WhatsApp (Arreglado para dimensiones impares)
 */
const { convertGifToMp4 } = require('../../lib/convertGifToMp4');

/**
 * 🎯 Handler .nalguear - Envía una nalgada con el GIF animado nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Ruta: carpeta 'gifs' dentro del directorio del plugin, buscando 'nalguear.gif'
        const gifPath = path.join(__dirname, 'gifs', 'nalguear.gif');
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *nalguear.gif* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay a quién nalguear
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién nalguear. Ejemplo: *.nalguear @juan* o *.nalguear a todos*');
        }

        // 📝 Mensajes aleatorios de nalgadas
        const spankMessages = [
            "le dio una buena nalgada a",
            "le arrimó un correctivo en las pompis a",
            "le dio un fuerte azote a",
            "dejó marcado a"
        ];
        let randomIndex = Math.floor(Math.random() * spankMessages.length);
        let spankMessageText = spankMessages[randomIndex];

        let spankMessage = ``;
        let mentions = [senderJid];

        // Construir el texto final
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            spankMessage += `*@${senderNumber} ${spankMessageText}* *@${targetNumber}* 🍑💥`;
            mentions.push(targetJid);
        } else {
            spankMessage += `*@${senderNumber} ${spankMessageText}* *${extraText}* 🍑💥`;
        }

        if (extraText && targetJid) {
            spankMessage += `\n\n*pd: ${extraText}*`;
        }

            const { convertGifToMp4 } = require('../../lib/convertGifToMp4');
handler.command = /^(nalguear|spank|nalgear)$/i;

module.exports = handler;