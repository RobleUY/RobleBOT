const axios = require('axios');
const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-pix_fmt', 'yuv420p', '-c:v', 'libx264', '-movflags', '+faststart', '-an', outputPath], { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

async function getReactionFromDelirius(endpoint) {
  try {
    const res = await axios.get(`https://api.delirius.online/reactions/${endpoint}`, { timeout: 10000 });
    const videoUrl = res.data?.data?.url;
    if (!videoUrl) return null;
    const vidRes = await axios.get(videoUrl, { responseType: 'arraybuffer', timeout: 15000 });
    const buf = Buffer.from(vidRes.data);
    if (buf.length < 5000) return null;
    return buf;
  } catch (e) {
    console.warn(`[MATAR] Delirius falló:`, e.message);
    return null;
  }
}
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente del mensaje.');

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim();
        }

        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién matar. Ejemplo: *.matar @juan* o *.matar a todos*');
        }

        const killMessages = [
            "eliminó brutalmente a", "asesinó sin piedad a",
            "acabó con la vida de", "liquidó de forma épica a",
            "mandó al otro mundo a", "hizo desaparecer a"
        ];
        const killMessageText = killMessages[Math.floor(Math.random() * killMessages.length)];
        let killMessage = '';
        const mentions = [senderJid];

        if (targetJid) {
            killMessage += `*@${senderNumber} ${killMessageText}* *@${targetJid.split('@')[0]}* 💀`;
            mentions.push(targetJid);
        } else {
            killMessage += `*@${senderNumber} ${killMessageText}* *${extraText}* 💀`;
        }
        if (extraText && targetJid) killMessage += `\n\n*pd: ${extraText}*`;

        // 🌐 Intentar Delirius primero, fallback al GIF local
        let mp4Buffer = await getReactionFromDelirius('kill');
        if (!mp4Buffer) {
            console.log('[MATAR] Usando GIF local...');
            const gifPath = path.join(__dirname, 'gifs', 'matar.gif');
            if (!fsSync.existsSync(gifPath)) return await message.reply('❌ No se encontró el GIF de matar.');
            mp4Buffer = await convertGifToMp4(await fs.readFile(gifPath));
        }

        await sock.sendMessage(message.from, { video: mp4Buffer, gifPlayback: true, caption: killMessage, mentions }, { quoted: message._baileyMessage || message });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar la acción de matar:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar la acción.');
    }
};

handler.help = ['matar'];
handler.tags = ['fun'];
handler.command = /^(matar|kill)$/i;

module.exports = handler;
