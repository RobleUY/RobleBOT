// acciones-multicomando.js
let handler = async (message, { text, command }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            console.error('Sender JID no encontrado:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text.trim();
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim();
        }

        if (!targetJid && !extraText) {
            return await message.reply(`❌ Debes especificar un objetivo. Ejemplo: /${command} @usuario o /${command} algo o alguien.`);
        }

        // Diccionario de acciones
        const actions = {
            petear: [
                "le hizo tremendo pete a",
                "le hizo una supermamamada a",
                "se metió los dedos en el culo mientras le daba sexo oral a",
                "le practicó sexo oral a"
            ],
            matar: [
                "asesinó sin piedad a",
                "mató a",
                "se acostó a dormir luego de asesinar a",
                "golpeó brutalmente y asesinó a"
            ],
            empujar: [
                "empujó desde un edificio a",
                "le dio un empujón desde un sexto piso a",
                "se rió luego de empujar al vacío a",
                "empujó e hizo que atropellaran a"
            ],
            insultar: [
                "le dijo hijo de puta a",
                "dijo que se va a violar a la familia de",
                "insultó en 47 idiomas diferentes a",
                "le gritó 'chupame la verga' en la cara a"
            ],
            acariciar: [
                "le dio un tierno abrazo a",
                "le dio una suave caricia a",
                "se durmió acariciando a",
                "le dio una caricia al pelo de"
            ],
            aniquilar: [
                "aniquiló brutalmente a",
                "enloqueció y le puso una bomba a",
                "se puso loco y lanzó a un río con cocodrilos a",
                "incineró por completo el cuerpo de"
            ],
            espiar: [
                "está espiando a lo lejos lo que hace",
                "se convirtió en espía para ver qué hace",
                "es un agente secreto infiltrado buscando información de",
                "trabaja en la CIA y está espiando a"
            ]
        };

        const actionTexts = actions[command.toLowerCase()] || ["interactuó con"];
        const randomText = actionTexts[Math.floor(Math.random() * actionTexts.length)];

        let messageText = "";
        let mentions = [senderJid];

        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            messageText = `*@${senderNumber} ${randomText}* *@${targetNumber}*`;
            mentions.push(targetJid);
        } else {
            messageText = `*@${senderNumber} ${randomText}* *${extraText}*`;
        }

        if (extraText && targetJid) messageText += `\n\n*PD:* ${extraText}`;

        await message.reply(messageText, { mentions });

    } catch (error) {
        console.error('[ERROR] Acción fallida:', error);
        await message.reply('❌ Ocurrió un error al ejecutar la acción.');
    }
};

// Comandos disponibles
handler.help = ['acciones'];
handler.tags = ['fun'];
handler.command = /^(petear|empujar|matar|insultar|acariciar|aniquilar|espiar)$/i;

module.exports = handler;
