const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF a un MP4 ligero compatible con WhatsApp (Arreglado para dimensiones impares)
 */
const { convertGifToMp4 } = require('../../lib/convertGifToMp4');

/**
 * 🎯 Handler .abrazar - Envía un abrazo con el GIF animado nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Ruta: carpeta 'gifs' dentro del directorio del plugin
        const gifPath = path.join(__dirname, 'gifs', 'abrazar.gif');
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *abrazar.gif* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay a quién abrazar
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién abrazar. Ejemplo: *.abrazar @juan* o *.abrazar a todos*');
        }

        // 📝 Mensajes aleatorios de abrazos
        const hugMessages = [
            "le dio un abrazo gigante y súper tierno a",
            "corrió y arropó con un abrazo cálido a",
            "le dio un abrazo reconfortante a",
            "apachurró con mucho cariño a"
        ];
        let randomIndex = Math.floor(Math.random() * hugMessages.length);
        let hugMessageText = hugMessages[randomIndex];

        let hugMessage = ``;
        let mentions = [senderJid];

        // Construir el texto sin la cabecera anterior
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            hugMessage += `*@${senderNumber} ${hugMessageText}* *@${targetNumber}* 🤗`;
            mentions.push(targetJid);
        } else {
            hugMessage += `*@${senderNumber} ${hugMessageText}* *${extraText}* 🤗`;
        }

        if (extraText && targetJid) {
            hugMessage += `\n\n*pd: ${extraText}*`;
        }

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el GIF nativo con el texto limpio
        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: hugMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el abrazo:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar el abrazo.');
    }
};

handler.help = ['abrazar'];
handler.tags = ['fun'];
handler.command = /^(abrazar|hug)$/i;

module.exports = handler;
