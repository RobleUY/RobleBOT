// mencionar-futuro.js
let handler = async (message, { text }) => {
    try {
        // Obtener el remitente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            console.error('Sender JID no encontrado:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text.trim();

        // Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim();
        }

        // Validar entrada
        if (!targetJid && !extraText) {
            return await message.reply('🔮 Debes mencionar a alguien o escribir algo para predecir su destino.\nEjemplo: *.futuro @juan* o *.futuro el país*');
        }

        // Frases de futuro (mezcla de humor, ironía y destino)
        const futures = [
            "ganará la lotería, pero perderá el boleto.",
            "descubrirá que el amor de su vida odia el mismo café que ama.",
            "vivirá 200 años, pero con WiFi lento.",
            "será famoso en un universo alterno... no en este.",
            "encontrará un gato callejero que lo convertirá en su esclavo personal.",
            "será millonario, justo después del apocalipsis.",
            "será recordado por haber dicho 'solo una partida más'.",
            "encontrará el sentido de la vida... en los créditos de una serie coreana.",
            "logrará sus sueños, pero olvidará para qué los quería.",
            "tendrá una cita tan mala que será mencionada en Reddit.",
            "será elegido para gobernar una colonia en Marte, si sobrevive al entrenamiento.",
            "será traicionado por su propio espejo.",
            "será el protagonista de una canción triste que se volverá viral.",
            "recibirá un mensaje misterioso a las 3:33 AM que cambiará su vida.",
            "descubrirá que todo era una simulación... pero ya será tarde.",
            "será feliz, pero solo los jueves.",
            "tendrá tanto éxito que olvidará cómo dormir.",
            "se convertirá en influencer de memes interdimensionales.",
            "será encontrado hablando con su tostadora sobre filosofía.",
            "descubrirá que el karma tiene buen sentido del humor... y no lo perdona fácil."
        ];

        const randomIndex = Math.floor(Math.random() * futures.length);
        const futureText = futures[randomIndex];

        let messageText = `🔮 *LECTURA DEL FUTURO* 🔮\n\n`;
        let mentions = [senderJid];

        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            messageText += `El futuro de *@${targetNumber}* fue revelado:\n\n*${futureText}*`;
            mentions.push(targetJid);
        } else {
            messageText += `El futuro de *${extraText}* fue revelado:\n\n*${futureText}*`;
        }

        // Extra comentario del "oráculo"
        const extraComments = [
            "✨ El universo habló. Tú sabrás si escuchas.",
            "🕯️ O tal vez todo esto fue un error del destino.",
            "🌙 Las estrellas se rieron mientras lo decían.",
            "🔔 Ten cuidado... o no.",
            "💫 El futuro cambia cada vez que lo miras."
        ];

        const randomComment = extraComments[Math.floor(Math.random() * extraComments.length)];
        messageText += `\n\n_${randomComment}_`;

        // Enviar mensaje final
        await message.reply(messageText, { mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el comando futuro:', error, '\x1b[0m');
        await message.reply('❌ El oráculo tuvo un mal día. Intenta de nuevo.');
    }
};

handler.help = ['futuro'];
handler.tags = ['fun'];
handler.command = /^(futuro|destino|profecia)$/i;

module.exports = handler;
