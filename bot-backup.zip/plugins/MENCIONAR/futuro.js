const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-pix_fmt', 'yuv420p',
      '-c:v', 'libx264',
      '-movflags', '+faststart',
      '-an',
      outputPath
    ];
    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const gifName = 'futuro.gif';
    const gifPath = path.join(__dirname, 'gifs', gifName);
    
    if (!fsSync.existsSync(gifPath)) {
        return await message.reply(`❌ No se encontró el archivo *${gifName}*.`);
    }

    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const mentionedJids = message?.mentions || [];
    const targetJid = mentionedJids[0];

    // Frases para el futuro
   const futurePhrases = [
        "pronto descubrirá que sus problemas actuales son solo el tutorial de lo que viene.",
        "tendrá éxito rotundo en todo, siempre y cuando deje de procrastinar y empiece a trabajar.",
        "un golpe de suerte llegará a su vida, pero lo arruinará por falta de atención.",
        "va a tomar una decisión cuestionable este fin de semana. Prepárese para las consecuencias.",
        "su futuro financiero depende más de la suerte que de su talento. Empiece a jugar a la lotería.",
        "pronto se dará cuenta de que la persona que cree que es su 'mejor amigo' le está robando el WiFi.",
        "tendrá una revelación existencial mientras está en el baño. No la desperdicie.",
        "va a recuperar ese dinero que daba por perdido, pero lo gastará en algo innecesario a los 5 minutos.",
        "recibirá un mensaje que cambiará su perspectiva, o quizás solo sea spam de un banco.",
        "su mayor enemigo será su propio espejo mañana por la mañana por culpa del alcohol.",
        "el universo conspira a su favor, pero usted se encarga de sabotearlo todo sistemáticamente.",
        "encontrará el amor verdadero, pero probablemente esté ocupado viendo series en Netflix."
    ];

    const randomPhrase = futurePhrases[Math.floor(Math.random() * futurePhrases.length)];
    let caption = "";
    let mentions = [senderJid];

    if (targetJid) {
        // Futuro de alguien más
        caption = `*🔮 Predicción para @${targetJid.split('@')[0]}:* \n\n${randomPhrase}. ✨`;
        mentions.push(targetJid);
    } else {
        // Futuro propio
        caption = `*🔮 Tu propio futuro, @${senderJid.split('@')[0]}:* \n\n${randomPhrase}. ✨`;
    }

    try {
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: caption,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );
    } catch (e) {
        console.error(e);
        await message.reply('❌ Ocurrió un error consultando el oráculo.');
    }
};

handler.help = ['futuro'];
handler.tags = ['fun'];
handler.command = /^(futuro)$/i;

module.exports = handler;