const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF de denuncia a un MP4 ligero compatible con WhatsApp
 * Incluye filtro para forzar dimensiones pares y evitar errores de libx264
 */
const { convertGifToMp4 } = require('../../lib/convertGifToMp4');

/**
 * 🎯 Handler .denunciar - Envía una denuncia con el GIF animado nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Ruta: carpeta 'gifs' dentro del directorio del plugin
        const gifPath = path.join(__dirname, 'gifs', 'denunciar.gif');
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *denunciar.gif* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay un objetivo
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién denunciar. Ejemplo: *.denunciar @juan* o *.denunciar al administrador*');
        }

        // 📝 Mensajes aleatorios de denuncias cómicas
        const reportMessages = [
            "fue corriendo a la comisaría a denunciar a",
            "llamó al FBI de inmediato para reportar el comportamiento de",
            "firmó una denuncia formal en contra de",
            "acusó formalmente ante las autoridades correspondientes a"
        ];
        let randomIndex = Math.floor(Math.random() * reportMessages.length);
        let reportMessageText = reportMessages[randomIndex];

        let reportMessage = ``;
        let mentions = [senderJid];

        // Construir el texto final
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            reportMessage += `*@${senderNumber} ${reportMessageText}* *@${targetNumber}* 📜👮‍♂️`;
            mentions.push(targetJid);
        } else {
            reportMessage += `*@${senderNumber} ${reportMessageText}* *${extraText}* 📜👮‍♂️`;
        }

        if (extraText && targetJid) {
            reportMessage += `\n\n*pd: ${extraText}*`;
        }

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el GIF nativo con el texto en el pie del archivo
        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: reportMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar la denuncia:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar la denuncia.');
    }
};

handler.help = ['denunciar'];
handler.tags = ['fun'];
handler.command = /^(denunciar|report)$/i;

module.exports = handler;
