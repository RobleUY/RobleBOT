// denunciar.js
let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let targetJid = null;
        let extraText = text.trim();

        // Obtener las menciones directamente del objeto message
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // Si no hay objetivo ni texto
        if (!targetJid && !extraText) {
            return await message.reply('⚠️ Debes especificar a quién o qué denunciar.\nEjemplo: *.denunciar @usuario* o *.denunciar comportamiento inapropiado*');
        }

        const reportMessages = [
            "ha presentado una denuncia contra",
            "acaba de denunciar a",
            "acusó de acoso a",
            "alertó a las autoridades sobre",
            "ha hecho una queja formal en contra de"
        ];
        const randomIndex = Math.floor(Math.random() * reportMessages.length);
        const reportMessageText = reportMessages[randomIndex];

        let reportMessage = `🚨 *DENUNCIA REALIZADA* 🚨\n\n`;
        let mentions = [senderJid];

        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            reportMessage += `*@${senderNumber} ${reportMessageText}* *@${targetNumber}*.`;
            mentions.push(targetJid);
        } else {
            reportMessage += `*@${senderNumber} ${reportMessageText}* *${extraText}*.`;
        }

        if (extraText && targetJid) {
            reportMessage += `\n\n📝 *Motivo:* ${extraText}`;
        }

        await message.reply(reportMessage, { mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al ejecutar el comando denunciar:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al procesar la denuncia.');
    }
};

handler.help = ['denunciar'];
handler.tags = ['fun'];
handler.command = /^(denunciar)$/i;

module.exports = handler;
