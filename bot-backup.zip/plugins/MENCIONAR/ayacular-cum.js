//mencionar-abrazar.js
let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid; 
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let targetJid = null;
        let extraText = text.trim();

        // Obtener las menciones directamente del objeto message compatible
        const mentionedJids = message?.mentions;

        if (mentionedJids && mentionedJids.length > 0) {
            // Si hay menciones, el primer mencionado es el objetivo
            targetJid = mentionedJids[0];
            // Se limpia el texto para eliminar todas las menciones
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // Si no hay objetivo (mención o texto), enviar un error
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar un objetivo, ya sea mencionando a un usuario o colocando un texto. Ejemplo: .cum @juan o .cum al sol');
        }

        const kissMessages = [
            "le cumeaste toda la cara a",
            "dejaste toda tu leche en el ano de",
            "te hiciste una paja en tu casa viendo videos de maduras calientes y el cum volo hasta la boca de",
            "eyaculaste a gran velocidad e impactaste en el ojo izquierdo de"
        ];
        let randomIndex = Math.floor(Math.random() * kissMessages.length);
        let kissMessageText = kissMessages[randomIndex];

        let kissMessage = `🥱 *Lechasoooooo*\n\n`;
        let mentions = [senderJid]; // La lista de menciones siempre incluye al remitente

        if (targetJid) {
            // Si el objetivo es una mención
            const targetNumber = targetJid.split('@')[0];
            kissMessage += `*@${senderNumber} ${kissMessageText}* *@${targetNumber}*.`;
            mentions.push(targetJid);
        } else {
            // Si el objetivo es solo texto
            kissMessage += `*@${senderNumber} ${kissMessageText}* *${extraText}*.`;
        }

        // Añadir el texto adicional si existe y el objetivo fue una mención
        if (extraText && targetJid) {
            kissMessage += `\n\n*pd: ${extraText}*`;
        }

        // Enviar el mensaje con la lista de menciones
        await message.reply(kissMessage, { mentions: mentions });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el abrazo:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar el cum.');
    }
};

handler.help = ['cum'];
handler.tags = ['fun'];
handler.command = /^(cum)$/i;

module.exports = handler;