const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF a un MP4 ligero compatible con WhatsApp (Arreglado para dimensiones impares)
 */
async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', // ✨ Fuerza a que el ancho y alto sean pares redondeando hacia abajo
      '-pix_fmt', 'yuv420p',
      '-c:v', 'libx264',
      '-movflags', '+faststart',
      '-an',
      outputPath
    ];

    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * 🎯 Handler .cagar - Envía una cagada con el GIF animado nativo
 */
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // 📁 Ruta: carpeta 'gifs' dentro del directorio del plugin
        const gifPath = path.join(__dirname, 'gifs', 'cagar.gif');
        
        // 🔍 Validar existencia del archivo
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *cagar.gif* en la ruta: \n_${gifPath}_`);
        }

        // 👤 Obtener JID del emisor de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        let extraText = text ? text.trim() : '';

        // 🔍 Obtener menciones
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            extraText = text.replace(/@\d+/g, "").trim(); 
        }

        // ❌ Error si no hay a quién cagar
        if (!targetJid && !extraText) {
            return await message.reply('❌ Debes especificar a quién cagar. Ejemplo: *.cagar @juan* o *.cagar encima de todos*');
        }

        // 📝 Mensajes aleatorios de cagar
        const cagMessages = [
            "se cagó encima de",
            "le hizo una cagada épica a",
            "se descargó completamente sobre",
            "le dejó un regalito maloliente a"
        ];
        let randomIndex = Math.floor(Math.random() * cagMessages.length);
        let cagMessageText = cagMessages[randomIndex];

        let cagMessage = ``;
        let mentions = [senderJid];

        // Construir el texto sin la cabecera anterior
        if (targetJid) {
            const targetNumber = targetJid.split('@')[0];
            cagMessage += `*@${senderNumber} ${cagMessageText}* *@${targetNumber}* 💩`;
            mentions.push(targetJid);
        } else {
            cagMessage += `*@${senderNumber} ${cagMessageText}* *${extraText}* 💩`;
        }

        if (extraText && targetJid) {
            cagMessage += `\n\n*pd: ${extraText}*`;
        }

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el GIF nativo con el texto limpio
        await sock.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: cagMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar la cagada:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar la cagada.');
    }
};

handler.help = ['cagar'];
handler.tags = ['fun'];
handler.command = /^(cagar|cagarme)$/i;

module.exports = handler;