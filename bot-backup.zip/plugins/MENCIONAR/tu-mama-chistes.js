const fs = require('fs');
const path = require('path');

let handler = async (message, { text }) => {
    try {
        // Obtener el ID del remitente de forma segura
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado en el objeto message:', message);
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        let targetJid = null;
        
        // Obtener las menciones directamente del objeto message
        const mentionedJids = message?.mentions;
        
        if (mentionedJids && mentionedJids.length > 0) {
            // Si hay menciones, el primer mencionado es el objetivo
            targetJid = mentionedJids[0];
        }
        
        // Si no hay mención, enviar un error
        if (!targetJid) {
            return await message.reply('❌ Debes mencionar a un usuario. Ejemplo: .tumama @juan');
        }
        
        // Cargar los chistes desde el archivo JSON
        const jokesPath = path.join(__dirname, 'tu-mama.json');
        let jokes = [];
        
        try {
            const jokesData = fs.readFileSync(jokesPath, 'utf-8');
            jokes = JSON.parse(jokesData);
        } catch (error) {
            console.error('\x1b[31m[ERROR] Error al cargar tu-mama.json:', error, '\x1b[0m');
            return await message.reply('❌ No se pudieron cargar los chistes.');
        }
        
        // Seleccionar un chiste aleatorio
        const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
        
        // Obtener el número del objetivo
        const targetNumber = targetJid.split('@')[0];
        
        // Construir el mensaje
        let jokeMessage = `😂 Oye *@${targetNumber}*\n`;
        jokeMessage += `${randomJoke}`;
        
        // Lista de menciones
        const mentions = [targetJid];
        
        // Enviar el mensaje con la mención
        await message.reply(jokeMessage, { mentions: mentions });
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el chiste:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al enviar el chiste.');
    }
};

handler.help = ['tumama', 'tumadre', 'yourmom'];
handler.tags = ['fun'];
handler.command = /^(tumama|tumadre|yourmom|tumamá|túmama|túmamá)$/i;

module.exports = handler;