let handler = async (message, { text }) => {
  try {
    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

    let targetJid = null;
    let secondTargetJid = null;
    let extraText = text.trim();

    const mentionedJids = message?.mentions;
    if (mentionedJids && mentionedJids.length > 0) {
      targetJid = mentionedJids[0];
      if (mentionedJids.length > 1) secondTargetJid = mentionedJids[1];
      extraText = text.replace(/@\d+/g, "").trim();
    }

    if (!targetJid && !extraText) {
      return await message.reply('❌ Debes indicar dos objetivos. Ejemplo: .ship @pepe y @juana');
    }

    const shipPercentage = Math.floor(Math.random() * 101);

    let shipMessage = '';
    let mentions = [senderJid];

    if (targetJid && secondTargetJid) {
      const t1 = targetJid.split('@')[0];
      const t2 = secondTargetJid.split('@')[0];
      shipMessage = `💖 Entre @${t1} y @${t2} hay un *${shipPercentage}%* de compatibilidad amorosa ❤️`;
      mentions.push(targetJid, secondTargetJid);
    } else if (targetJid) {
      const t1 = targetJid.split('@')[0];
      shipMessage = `💖 Entre @${t1} y *${extraText}* hay un *${shipPercentage}%* de compatibilidad amorosa ❤️`;
      mentions.push(targetJid);
    } else {
      const parts = extraText.split(/\s+y\s+/i);
      if (parts.length < 2) {
        return await message.reply('❌ Debes indicar dos nombres separados por "y". Ejemplo: .ship pepe y juana');
      }
      shipMessage = `💖 Entre *${parts[0].trim()}* y *${parts[1].trim()}* hay un *${shipPercentage}%* de compatibilidad ❤️`;
    }

    await message.reply(shipMessage, { mentions });

  } catch (error) {
    console.error('[ERROR] Error al calcular el ship:', error);
    await message.reply('❌ Ocurrió un error al calcular la compatibilidad.');
  }
};

handler.help = ['ship'];
handler.tags = ['fun'];
handler.command = /^(ship)$/i;

module.exports = handler;
