const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const baseArgs = [
      '-y', '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-pix_fmt', 'yuv420p', '-c:v', 'libx264', '-movflags', '+faststart', '-an',
      outputPath
    ];
    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

let handler = async (message, { text, conn }) => {
    try {
        const gifPath = path.join(__dirname, 'gifs', 'ship.gif');
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *ship.gif* en la ruta: \n_${gifPath}_`);
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

        let groupMetadata = {};
        let participants = [];
        try {
            groupMetadata = await conn.groupMetadata(message.from);
            participants = groupMetadata.participants.map(p => p.id);
        } catch {
            return await message.reply('❌ Este comando solo se puede usar en grupos.');
        }

        const mentionedJids = message?.mentions || [];
        let target1Text = '';
        let target2Text = '';
        let mentions = [];
        let cleanText = text ? text.trim().replace(/\s+/g, ' ') : '';
        let parts = cleanText.split(/\s+(?:y|X)\s+/i);
        if (parts.length < 2) parts = cleanText.split(' ');

        if (mentionedJids.length >= 2) {
            target1Text = `@${mentionedJids[0].split('@')[0]}`;
            target2Text = `@${mentionedJids[1].split('@')[0]}`;
            mentions = [mentionedJids[0], mentionedJids[1]];
        } 
        else if (mentionedJids.length === 1) {
            mentions = [mentionedJids[0]];
            const mentionTag = `@${mentionedJids[0].split('@')[0]}`;
            let remainingText = cleanText.replace(/@\d+/g, '').replace(/\b(y|X)\b/gi, '').trim().replace(/\s+/g, ' ');

            if (cleanText.startsWith('@')) {
                target1Text = mentionTag;
                target2Text = `*${remainingText}*`;
            } else {
                target1Text = `*${remainingText}*`;
                target2Text = mentionTag;
            }
        } 
        else if (parts.length >= 2 && parts[0] && parts[1]) {
            target1Text = `*${parts[0].trim()}*`;
            target2Text = `*${parts[1].trim()}*`;
        } 
        else if (cleanText.length > 0) {
            target1Text = `@${senderJid.split('@')[0]}`;
            target2Text = `*${cleanText}*`;
            mentions = [senderJid];
        } 
        else {
            const filteredParticipants = participants.filter(p => p !== senderJid);
            const randomParticipant = filteredParticipants.length > 0 
                ? filteredParticipants[Math.floor(Math.random() * filteredParticipants.length)]
                : senderJid;

            target1Text = `@${senderJid.split('@')[0]}`;
            target2Text = `@${randomParticipant.split('@')[0]}`;
            mentions = [senderJid, randomParticipant];
        }

        if (mentions.length > 0) mentions = [...new Set([...mentions, senderJid])];

        const lovePercentage = Math.floor(Math.random() * 101);

        // Texto corto personalizado solicitado
        let shipMessage = `Entre ${target1Text} y ${target2Text} hay un *${lovePercentage}%* de probabilidades de que se gusten 💕`;

        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        await conn.sendMessage(
            message.from, 
            { video: mp4Buffer, gifPlayback: true, caption: shipMessage, mentions: mentions }, 
            { quoted: message._baileyMessage || message }
        );
    } catch (error) {
        console.error('[ERROR ship]:', error);
        await message.reply('❌ Ocurrió un error al calcular el shippeo.');
    }
};

handler.help = ['ship'];
handler.tags = ['fun'];
handler.command = /^(ship|shippear)$/i;

module.exports = handler;