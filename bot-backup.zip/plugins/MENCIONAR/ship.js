const fs = require('fs').promises;
const fsSync = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

/**
 * Convierte el GIF de ship a un MP4 ligero compatible con WhatsApp
 */
async function convertGifToMp4(inputBuffer) {
  const inputPath = tmpFileName('gif');
  const outputPath = tmpFileName('mp4');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    const baseArgs = [
      '-y',
      '-i', inputPath,
      '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
      '-pix_fmt', 'yuv420p',
      '-c:v', 'libx264',
      '-movflags', '+faststart',
      '-an',
      outputPath
    ];

    await execFileAsync('ffmpeg', baseArgs, { windowsHide: true, timeout: 30_000 });
    return await fs.readFile(outputPath);
  } finally {
    Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * 🎯 Handler .ship - Empareja usuarios bajo cualquier combinación de texto/mención
 */
let handler = async (message, { text, conn }) => {
    try {
        const gifPath = path.join(__dirname, 'gifs', 'ship.gif');
        
        if (!fsSync.existsSync(gifPath)) {
            return await message.reply(`❌ No se encontró el archivo *ship.gif* en la ruta: \n_${gifPath}_`);
        }

        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        let groupMetadata = {};
        let participants = [];
        try {
            groupMetadata = await conn.groupMetadata(message.from);
            participants = groupMetadata.participants.map(p => p.id);
        } catch {
            return await message.reply('❌ Este comando solo se puede usar en grupos.');
        }

        const mentionedJids = message?.mentions || [];
        
        // Variables finales para el formateo del texto
        let target1Text = '';
        let target2Text = '';
        let mentions = [];

        // Limpiar el texto para procesarlo (quitar espacios extras)
        let cleanText = text ? text.trim().replace(/\s+/g, ' ') : '';

        // Separar usando " y " o simplemente un espacio como alternativa si hay dos bloques de texto
        // Esta regex busca separar el texto en dos partes ignorando el conector "y"
        let parts = cleanText.split(/\s+(?:y|X)\s+/i);
        if (parts.length < 2) {
            // Si no usó "y", intentamos separar por el espacio entre dos menciones o palabras
            parts = cleanText.split(' ');
        }

        // --- LÓGICA DE DETECCIÓN INTELIGENTE ---
        
        if (mentionedJids.length >= 2) {
            // 1️⃣ CASO: Dos menciones directas (@user1 @user2 o @user1 y @user2)
            target1Text = `@${mentionedJids[0].split('@')[0]}`;
            target2Text = `@${mentionedJids[1].split('@')[0]}`;
            mentions = [mentionedJids[0], mentionedJids[1]];
        } 
        else if (mentionedJids.length === 1) {
            // 2️⃣ CASO: Una mención y un texto mixto (@user y pepe / pepe y @user)
            mentions = [mentionedJids[0]];
            const mentionTag = `@${mentionedJids[0].split('@')[0]}`;
            
            // Averiguar qué parte es el texto libre limpiando la mención escrita
            let remainingText = cleanText.replace(/@\d+/g, '').replace(/\b(y|X)\b/gi, '').trim().replace(/\s+/g, ' ');

            if (cleanText.startsWith('@')) {
                // @user y pepe -> El primero es la mención, el segundo es el texto
                target1Text = mentionTag;
                target2Text = `*${remainingText}*`;
            } else {
                // pepe y @user -> El primero es el texto, el segundo es la mención
                target1Text = `*${remainingText}*`;
                target2Text = mentionTag;
            }
        } 
        else if (parts.length >= 2 && parts[0] && parts[1]) {
            // 3️⃣ CASO: Dos textos puros sin arrobas (pepe y maria / juan carlos)
            target1Text = `*${parts[0].trim()}*`;
            target2Text = `*${parts[1].trim()}*`;
        } 
        else if (cleanText.length > 0) {
            // 4️⃣ CASO: Un solo texto o una sola palabra (shippear un objeto o una persona)
            target1Text = `@${senderJid.split('@')[0]}`;
            target2Text = `*${cleanText}*`;
            mentions = [senderJid];
        } 
        else {
            // 5️⃣ CASO: .ship solo -> El emisor con alguien random del grupo
            const filteredParticipants = participants.filter(p => p !== senderJid);
            const randomParticipant = filteredParticipants.length > 0 
                ? filteredParticipants[Math.floor(Math.random() * filteredParticipants.length)]
                : senderJid;

            target1Text = `@${senderJid.split('@')[0]}`;
            target2Text = `@${randomParticipant.split('@')[0]}`;
            mentions = [senderJid, randomParticipant];
        }

        // Asegurar que el emisor esté en la lista de menciones para que WhatsApp procese los tags si se usaron
        if (mentions.length > 0) {
            mentions = [...new Set([...mentions, senderJid])];
        }

        // 🎲 Procesamiento del porcentaje y diseño
        const lovePercentage = Math.floor(Math.random() * 101);
        const barLength = 10;
        const filledLength = Math.round((lovePercentage / 100) * barLength);
        const bar = '❤️'.repeat(filledLength) + '🖤'.repeat(barLength - filledLength);

        let comment = '';
        if (lovePercentage >= 85) comment = '¡Boda asegurada! Destinados a estar juntos. 💍💖';
        else if (lovePercentage >= 60) comment = 'Hay mucha química aquí, ¡lo intentaría! 👀✨';
        else if (lovePercentage >= 35) comment = 'Podrían ser buenos amigos... o algo más si insisten. 🔥';
        else comment = 'Es mejor que sigan siendo desconocidos. 💀';

        let shipMessage = `❤️ *SHIPPEO* ❤️\n\n`;
        shipMessage += `${target1Text}  X  ${target2Text}\n\n`;
        shipMessage += `*Porcentaje:* ${lovePercentage}%\n`;
        shipMessage += `[${bar}]\n\n`;
        shipMessage += `_${comment}_`;

        // 🔄 Procesar el GIF local a MP4
        const mediaBuffer = await fs.readFile(gifPath);
        const mp4Buffer = await convertGifToMp4(mediaBuffer);

        // 📤 Enviar el resultado
        await conn.sendMessage(
            message.from, 
            { 
                video: mp4Buffer, 
                gifPlayback: true, 
                caption: shipMessage,
                mentions: mentions
            }, 
            { quoted: message._baileyMessage || message }
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al enviar el ship:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al calcular el shippeo.');
    }
};

handler.help = ['ship'];
handler.tags = ['fun'];
handler.command = /^(ship|shippear)$/i;

module.exports = handler;