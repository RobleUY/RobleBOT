/**
 * Comando para ver la prioridad de bots en un grupo
 * Muestra qué bot tiene prioridad para responder
 */

const { getGroupBotPriority } = require('../botPrioritySystem');

let handler = async (message, { conn }) => {
    try {
        const chatJid = message.from;
        
        // Solo funciona en grupos
        if (!chatJid.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }
        
        await message.reply('🔍 Analizando prioridad de bots en este grupo...');
        
        const priorityInfo = await getGroupBotPriority(chatJid);
        
        if (priorityInfo.error) {
            return await message.reply(`❌ Error: ${priorityInfo.error}`);
        }
        
        let response = '🤖 *PRIORIDAD DE BOTS EN ESTE GRUPO*\n\n';
        
        // Bot oficial
        response += '👑 *BOT OFICIAL*\n';
        if (priorityInfo.mainBot.present) {
            response += `   ✅ Presente: +${priorityInfo.mainBot.number}\n`;
            response += `   ${priorityInfo.mainBot.canSend ? '✅' : '❌'} Puede enviar mensajes: ${priorityInfo.mainBot.canSend ? 'SÍ' : 'NO'}\n`;
        } else {
            response += '   ❌ No está en el grupo\n';
        }
        
        response += '\n';
        
        // Subbots
        if (priorityInfo.subbots.length > 0) {
            response += '🤖 *SUBBOTS*\n';
            priorityInfo.subbots.forEach((subbot, index) => {
                const priority = index + 1;
                response += `   ${priority}. SubBot #${subbot.number} (+${subbot.botNumber})\n`;
                response += `      ${subbot.canSend ? '✅' : '❌'} Puede enviar: ${subbot.canSend ? 'SÍ' : 'NO'}\n`;
            });
        } else {
            response += '🤖 *SUBBOTS*\n';
            response += '   ❌ No hay subbots en el grupo\n';
        }
        
        response += '\n';
        
        // Bot activo con prioridad
        response += '⚡ *BOT ACTIVO CON PRIORIDAD*\n';
        response += `   ${priorityInfo.activeBotPriority}\n\n`;
        
        // Explicación
        response += '📋 *REGLAS DE PRIORIDAD*\n';
        response += '1️⃣ Bot oficial tiene prioridad máxima\n';
        response += '2️⃣ Si el bot oficial no puede responder, responde el SubBot con menor número\n';
        response += '3️⃣ Si ese SubBot tampoco puede, intenta con el siguiente\n';
        
        await message.reply(response);
        
    } catch (error) {
        console.error('Error en comando bot-priority:', error);
        await message.reply('❌ Error al obtener información de prioridad.');
    }
};

handler.help = ['botpriority', 'prioridadbots'];
handler.tags = ['info'];
handler.command = /^(botpriority|prioridadbots|prioridad)$/i;
handler.group = true;

module.exports = handler;
