const fs = require('fs');
const path = require('path');
const { loadStats } = require('../botStatsRecorder');

const more = String.fromCharCode(8206);
const readMore = more.repeat(4000);

// 📋 1. ORDEN DE LAS CATEGORÍAS (Cambia el orden aquí para alterar el menú)
const CATEGORIAS_LISTA = [
    'SubBots',
    'Juegos',
    'Herramientas'
];

// 🎨 2. ICONOS DE CADA CATEGORÍA
const CATEGORIAS_ICONOS = {
    'SubBots': '🤖',
    'Juegos': '🎮',
    'Herramientas': '🛠️'
};

// 📜 3. COMANDOS DE CADA CATEGORÍA (En el orden que se mostrarán dentro de cada categoría)
const CATEGORIAS_COMANDOS = {
    'SubBots': [
        { cmd: 'code', desc: 'Obtener código de vinculación para subbot' },
        { cmd: 'qr', desc: 'Obtener código QR para subbot' }
    ],
    'Juegos': [
        { cmd: 'trivia', desc: 'Juego de preguntas y respuestas' },
        { cmd: 'ppt', desc: 'Piedra, papel o tijeras' }
    ],
    'Herramientas': [
        { cmd: 'ia', desc: 'Consulta a la Inteligencia Artificial' },
        { cmd: 'sticker', desc: 'Crear sticker a partir de imagen o video' },
        { cmd: 'tradai', desc: 'Traducción de textos con IA' }
    ]
};

// 🔨 Función que construye dinámicamente el mensaje del menú en el orden de CATEGORIAS_LISTA
function construirMenu(usedPrefix = '.') {
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const activeSubBots = (global.subConns || []).filter(c => c?.user).length;
    let totalUsersDisplay = 0;
    try {
        if (global.db?.data?.users) totalUsersDisplay = Object.keys(global.db.data.users).length;
    } catch (_) {}

    let botStats = { totalCommandsExecuted: 0 };
    try {
        botStats = loadStats();
    } catch (_) {}
    const totalCommandsExecuted = botStats.totalCommandsExecuted || botStats.totalCommands || 0;

    let menu = `╔═════ ≪ 🤖 ≫ ═════\n`;
    menu += `║   *ROBLEBOT MENÚ 2*\n`;
    menu += `║\n`;
    menu += `║  👑 *Creador:* RobleUY\n`;
    menu += `║  ⏳ *Bot activo hace:* _${uptimeFormatted}_\n`;
    menu += `║  🤖 *Subbots:* _${activeSubBots}_\n`;
    menu += `║  👥 *Usuarios:* _${totalUsersDisplay}_\n`;
    menu += `║  ⚡ *Comandos ejecutados:* _${totalCommandsExecuted}_\n`;
    menu += `╚═════ ≪ 🤖 ≫ ═════\n`;
    menu += `*¡Hola!* Usa el prefijo \`${usedPrefix}\` para cualquier comando.\n`;
    menu += `*Ejemplo:* ${usedPrefix}menu2\n${readMore}\n`;

    // 🔄 CONSTRUCCIÓN DINÁMICA: Recorre CATEGORIAS_LISTA en el orden configurado
    for (const catName of CATEGORIAS_LISTA) {
        const icono = CATEGORIAS_ICONOS[catName] || '🔹';
        const comandos = CATEGORIAS_COMANDOS[catName] || [];

        menu += `╔═════ ≪ ${icono} ≫ ═════\n`;
        menu += `║   *${catName.toUpperCase()}*\n`;
        menu += `╚══════════════\n`;

        if (comandos.length === 0) {
            menu += `_Próximamente más comandos..._\n`;
        } else {
            for (const item of comandos) {
                const cmdStr = typeof item === 'string' ? item : item.cmd;
                const descStr = typeof item === 'object' && item.desc ? item.desc : null;

                menu += `_${usedPrefix}${cmdStr}_\n`;
                if (descStr) {
                    menu += `> *Propósito:* ${descStr}\n`;
                }
            }
        }
        menu += `──────────────\n\n`;
    }

    return menu.trim();
}

// 🎮 Handler del comando .menu2
async function handler(message, { conn }) {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = construirMenu(usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al generar el menú2:', error.message, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al generar el Menú 2.');
    }
}

module.exports = {
    command: /^(menu2)$/i,
    handler,
    help: 'Muestra el nuevo menú dinámico ordenado por categorías.',
    tags: ['main']
};
