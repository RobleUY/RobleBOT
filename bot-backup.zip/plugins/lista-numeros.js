/**
 * Comando: listanumeros
 * Descripción: Muestra todos los números del grupo con su nombre y si son admins.
 * Uso: .listanumeros
 */

let handler = async (message, { conn }) => {
  try {
    if (!message.isGroup) {
      return message.reply('❗ Este comando solo puede usarse dentro de grupos.');
    }

    const groupId = message.key.remoteJid;
    const metadata = await conn.groupMetadata(groupId);
    const participants = metadata.participants || [];

    if (participants.length === 0) {
      return message.reply('⚠️ No se encontraron participantes en este grupo.');
    }

    let texto = `📋 *Lista de números del grupo:*\n> ${metadata.subject}\n\n`;

    for (let i = 0; i < participants.length; i++) {
      const p = participants[i];
      const jid = p.id || p.jid || '';
      const numero = jid.split('@')[0] || 'Desconocido';

      // 🔒 Evitar errores si el contacto no existe en caché
      let contacto = {};
      try {
        contacto = conn.contacts?.[jid] || {};
      } catch {
        contacto = {};
      }

      const nombre = contacto.notify || contacto.vname || contacto.name || '—';
      const admin = p.admin ? '👑' : '';
      texto += `${i + 1}. +${numero} — ${nombre} ${admin}\n`;
    }

    texto += `\n👥 Total: ${participants.length} miembros`;

    await conn.sendMessage(groupId, {
      text: texto,
      quoted: message
    });

  } catch (error) {
    console.error('Error en listanumeros:', error);
    return message.reply('❌ Ocurrió un error al listar los números del grupo.');
  }
};

handler.help = ['listanumeros'];
handler.tags = ['grupo'];
handler.command = /^listanumeros$/i;
handler.group = true;

module.exports = handler;
