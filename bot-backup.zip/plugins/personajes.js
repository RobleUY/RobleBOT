const axios = require('axios');
const db = require('../database.js');
const premium = require('../premium');
const botConfig = require('../config.js');

const PRECIO_BASE_POR_ESTRELLA = 10000;
const COOLDOWN_RECLAMAR = 60 * 60 * 1000;

const imageCache = new Map();

function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.personajes) db.data.personajes = {};
    if (!db.data.intercambiosAnime) db.data.intercambiosAnime = {};
}

function guardarCambios() {
    if (db && typeof db.save === 'function') {
        db.save();
    }
}

async function buscarImagenPersonaje(nombrePersonaje, anime) {
    const query = `${nombrePersonaje} ${anime} anime`;

    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://robleuy.vercel.app/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 8000 });

        if (!data?.ok || !data?.images?.length) return null;

        const random = data.images[Math.floor(Math.random() * data.images.length)];
        const imageUrl = random?.large || random?.small;
        if (!imageUrl) return null;

        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`Error buscando imagen para ${nombrePersonaje}:`, error.message);
        return null;
    }
}

const PERSONAJES_BASE = [
    { nombre: 'Goku', anime: 'Dragon Ball', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/af/09/ba/af09badf32819ff23782bf8d130d4caf.jpg' },
    { nombre: 'Vegeta', anime: 'Dragon Ball', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/38/70/53/387053d3b7b8d6063b4cb10df8dfbaf2.jpg' },
    { nombre: 'Gohan', anime: 'Dragon Ball', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/51/4b/83/514b83b6c58723e5794fc02335848bca.jpg' },
    { nombre: 'Trunks', anime: 'Dragon Ball', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/d8/e9/12/d8e912a9dd6f7f613f0aa998ac55197a.jpg' },
    { nombre: 'Naruto Uzumaki', anime: 'Naruto', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/ca/c6/d8/cac6d852725aa673ffe24f9f955e6ba1.jpg' },
    { nombre: 'Sasuke Uchiha', anime: 'Naruto', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/cf/2e/3f/cf2e3f3615cbcc7cd5521b7421ae50c4.jpg' },
    { nombre: 'Kakashi Hatake', anime: 'Naruto', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/6a/71/88/6a718888d46ee5d914fef894a72aef5c.jpg' },
    { nombre: 'Luffy', anime: 'One Piece', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/35/d4/42/35d44263fa4bac83874b53e431ecb9a8.jpg' },
    { nombre: 'Zoro', anime: 'One Piece', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/df/70/55/df70557bd33d44381a486fbe9d6eb8f1.jpg' },
    { nombre: 'Sanji', anime: 'One Piece', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/43/0a/95/430a9585d9c15bb8c8edc423abc28d92.jpg' },
    { nombre: 'Nami', anime: 'One Piece', calidad: '☆☆', imagen: 'https://i.pinimg.com/736x/ae/60/76/ae607673ca5a12fa09c795cb5abc5451.jpg' },
    { nombre: 'Tanjiro Kamado', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/36/2c/00/362c00f49cf1a052d77f5b85cd7670b7.jpg' },
    { nombre: 'Nezuko Kamado', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/06/cd/5e/06cd5e6030adfcd3ddcfb3e3701ce386.jpg' },
    { nombre: 'Inosuke Hashibira', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/48/bd/4a/48bd4adfa4fc42bd37cc4056de44570d.jpg' },
    { nombre: 'Zenitsu Agatsuma', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/a9/33/58/a93358ca66ad9c9b39dafdca9c249b4e.jpg' },
    { nombre: 'Eren Yeager', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/0d/8f/72/0d8f72aff003bfd5970d7f8c46355cce.jpg' },
    { nombre: 'Mikasa Ackerman', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/26/87/69/268769889ffd00e27bf184a7c1e2a1ac.jpg' },
    { nombre: 'Levi Ackerman', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/8e/98/a8/8e98a8870451371ef83bd3c84070d804.jpg' },
    { nombre: 'Armin Arlert', anime: 'Shingeki no Kyojin', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/cb/c8/34/cbc8340f8f3177b7aa2812e2c7fa6e9b.jpg' },
    { nombre: 'Saitama', anime: 'One Punch Man', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/35/fb/66/35fb669fd3d93d70cea64b8a8f15e6e7.jpg' },
    { nombre: 'Genos', anime: 'One Punch Man', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/af/88/4f/af884f700880c3c935e59d2af75a7a1a.jpg' },
    { nombre: 'Tatsumaki', anime: 'One Punch Man', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/b8/42/a8/b842a8c6f201e06d2e75df6015f46be9.jpg' },
    { nombre: 'Deku', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/55/93/5e/55935e9be43efd3b9c8fef76fc7bb112.jpg' },
    { nombre: 'All Might', anime: 'My Hero Academia', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/ff/f6/fc/fff6fc55b117108f3e10a77500cf95a6.jpg' },
    { nombre: 'Bakugo', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/12/4d/9f/124d9f32309533b98e19f1f151af2f30.jpg' },
    { nombre: 'Todoroki', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/c6/e9/7c/c6e97c541f4adfdb10873b9e6b8958bc.jpg' },
    { nombre: 'Gojo Satoru', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/20/4b/3a/204b3afc5502ded15b37468b326a7429.jpg' },
    { nombre: 'Yuji Itadori', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/9c/68/d6/9c68d673bb3aade436b396aa3f88d67c.jpg' },
    { nombre: 'Megumi Fushiguro', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/cd/b1/36/cdb1363f1b5a9e2161c490e5ed030643.jpg' },
    { nombre: 'Nobara Kugisaki', anime: 'Jujutsu Kaisen', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/0c/4c/8d/0c4c8d8d8abbb0bc57e09e16aa568e72.jpg' },
    { nombre: 'Edward Elric', anime: 'Fullmetal Alchemist', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/07/15/d8/0715d8cca64c5c12112f03afc71e7903.jpg' },
    { nombre: 'Alphonse Elric', anime: 'Fullmetal Alchemist', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/01/02/e7/0102e7b3811cc3a3feff6db97dbc6922.jpg' },
    { nombre: 'Kenshin Himura', anime: 'Rurouni Kenshin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/e7/1e/64/e71e6453a01d860573faf01ff02ee5ad.jpg' },
    { nombre: 'Light Yagami', anime: 'Death Note', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/99/0f/a3/990fa31af6df1bdc7ec61633eb1bdc30.jpg' },
    { nombre: 'L', anime: 'Death Note', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/3b/0a/c1/3b0ac15f51de8be95927bd13426101f3.jpg' },
    { nombre: 'Ichigo Kurosaki', anime: 'Bleach', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/e9/a0/a1/e9a0a1ec757627a02a1e21d5eadad1f4.jpg' },
    { nombre: 'Rukia Kuchiki', anime: 'Bleach', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/1200x/db/12/d7/db12d7c02adcd151ce86cc9547335648.jpg' },
    { nombre: 'Natsu Dragneel', anime: 'Fairy Tail', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/c9/5f/78/c95f780d8377aba54cadfd9309a21d77.jpg' },
    { nombre: 'Erza Scarlet', anime: 'Fairy Tail', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/dd/52/11/dd521138e82a3bc1c913d6dc54083a40.jpg' },
    { nombre: 'Lucy Heartfilia', anime: 'Fairy Tail', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/65/cf/3a/65cf3a29fa7bf1e2340f93beea11186a.jpg' },
    { nombre: 'Gintoki Sakata', anime: 'Gintama', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/38/a3/1f/38a31f49313667d0cf6a6cd887172102.jpg' },
    { nombre: 'Killua Zoldyck', anime: 'Hunter x Hunter', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/6c/99/b5/6c99b5492a6950ca1413246beb804662.jpg' },
    { nombre: 'Gon Freecss', anime: 'Hunter x Hunter', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/f7/c8/fd/f7c8fd78d9a9df448db9d4b1ce10f653.jpg' },
    { nombre: 'Kurapika', anime: 'Hunter x Hunter', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/e8/6b/6d/e86b6d0fb495bd922c180241d1286828.jpg' },
];

const LISTA_PERSONAJES = PERSONAJES_BASE.map(pb => ({
    ...pb,
    nombreFormateado: pb.nombre,
    nombre: pb.nombre.replace(/\s/g, '').toLowerCase()
}));

function formatoNombre(nombreSimple) {
    const pbData = LISTA_PERSONAJES.find(pb => pb.nombre === nombreSimple);
    if (!pbData) return nombreSimple.toUpperCase();
    return pbData.nombreFormateado.replace(/\s/g, '_');
}

function obtenerPrecioVenta(calidadString) {
    const estrellas = calidadString.length;
    return estrellas * PRECIO_BASE_POR_ESTRELLA;
}

function obtenerPersonajesData(numero, senderJid) {
    ensureDatabaseCollections();
    const cleanNumber = String(numero).replace(/[^0-9]/g, '');
    if (!db.data.personajes[cleanNumber]) {
        db.data.personajes[cleanNumber] = {
            personajes: [],
            ultimoClaim: 0,
            jid: senderJid || `${cleanNumber}@s.whatsapp.net`
        };
        guardarCambios();
    }
    return db.data.personajes[cleanNumber];
}

function obtenerIntercambiosAnime() {
    ensureDatabaseCollections();
    return db.data.intercambiosAnime;
}

function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

async function restarMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return false;
    const user = await global.db.getUser(jid, groupId);
    let restante = cantidad;

    if (user.money >= restante) {
        user.money -= restante;
    } else {
        restante -= (user.money || 0);
        user.money = 0;

        if (user.bank >= restante) {
            user.bank -= restante;
        } else {
            return false;
        }
    }
    return true;
}

function obtenerPersonajeAleatorio() {
    const totalPeso = LISTA_PERSONAJES.reduce((sum, pb) => {
        const pesoBase = 6 - pb.calidad.length;
        return sum + pesoBase;
    }, 0);

    let random = Math.floor(Math.random() * totalPeso);
    for (const pb of LISTA_PERSONAJES) {
        const pesoBase = 6 - pb.calidad.length;
        if (random < pesoBase) {
            return pb;
        }
        random -= pesoBase;
    }
    return LISTA_PERSONAJES[Math.floor(Math.random() * LISTA_PERSONAJES.length)];
}

function normalizarTexto(str) {
    if (!str) return '';
    return str
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '');
}

function buscarPersonajePorNombre(nombreSimple) {
    if (!nombreSimple) return null;
    const targetNorm = normalizarTexto(nombreSimple);
    return LISTA_PERSONAJES.find(pb => 
        normalizarTexto(pb.nombreFormateado) === targetNorm || 
        normalizarTexto(pb.nombre) === targetNorm
    );
}

let handler = async (message, { text, command, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = senderJid?.split('@')[0];

        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const personajesData = db.data.personajes;
        const intercambiosAnime = db.data.intercambiosAnime;

        if (!personajesData[senderNumber]) {
            personajesData[senderNumber] = {
                personajes: [],
                bloqueados: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            guardarCambios();
        }
        if (!personajesData[senderNumber].bloqueados) {
            personajesData[senderNumber].bloqueados = [];
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        if (command.match(/^pj$/i) && !subCommand) {
            return await message.reply(
                '👾 *COMANDOS DE PERSONAJES DE ANIME* 👾\n' +
                '━━━━━━━━━━\n\n' +
                '*/pj reclamar* / *claim* - _Reclama un personaje aleatorio (1 por hora)._\n' +
                '*/mypj* - _Ver tu colección de personajes._\n' +
                '*/mypj ver [personaje]* - _Ver la imagen de un personaje._\n' +
                '*/pj regalar @user [personaje]* - _Regala un personaje._\n' +
                '*/pj intercambio @user [mi_pj] [su_pj]* - _Propone intercambio._\n' +
                '*/pj intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*/pj intercambio rechazar @user* - _Rechazar intercambio._\n' +
                '*/pj vender [personaje] [cantidad]* - _Vende personajes._\n' +
                '*/pj vender all* - _Vende todos tus personajes (excepto bloqueados)._\n' +
                '*/pj block [personaje] [número]* - _Bloquea una copia (no se vende con all)._\n' +
                '*/pj block all* - _Bloquea todos tus personajes._\n' +
                '*/pj unlock [personaje] [número]* - _Desbloquea una copia._\n' +
                '*/pj unlock all* - _Desbloquea todos tus personajes._\n'
            );
        }

        // SUBCOMANDO: block / bloquear
        if (subCommand === 'block' || subCommand === 'bloquear') {
            const objetivo = args[1]?.toLowerCase();
            const inventario = personajesData[senderNumber].personajes;
            const bloqueados = personajesData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj block [personaje] [número]_ o _/pj block all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                const nuevos = inventario.filter(n => !bloqueados.includes(n + '_slot_' + inventario.indexOf(n)));
                // Bloquear todos los no bloqueados aún
                const aBloqear = [];
                const conteo = {};
                for (const n of inventario) {
                    conteo[n] = (conteo[n] || 0) + 1;
                    const key = n + '_' + conteo[n];
                    if (!bloqueados.includes(key)) aBloqear.push(key);
                }
                personajesData[senderNumber].bloqueados = [...new Set([...bloqueados, ...aBloqear])];
                guardarCambios();
                return await message.reply(`🔒 *Todos tus personajes han sido bloqueados.* No se venderán con \`/pj vender all\`.`);
            }

            const personaje = buscarPersonajePorNombre(objetivo);
            if (!personaje) return await message.reply('❌ *Personaje no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `/pj block Goku 1`');

            const copias = inventario.filter(n => n === personaje.nombre).length;
            if (numero > copias) return await message.reply(`❌ Solo tienes *${copias}x ${formatoNombre(personaje.nombre)}*.`);

            const key = personaje.nombre + '_' + numero;
            if (bloqueados.includes(key)) return await message.reply(`🔒 La copia #${numero} de *${formatoNombre(personaje.nombre)}* ya está bloqueada.`);

            bloqueados.push(key);
            guardarCambios();
            return await message.reply(`🔒 *${formatoNombre(personaje.nombre)} #${numero}* bloqueado. No se venderá con \`/pj vender all\`.`);
        }

        // SUBCOMANDO: unlock / desbloquear
        if (subCommand === 'unlock' || subCommand === 'desbloquear') {
            const objetivo = args[1]?.toLowerCase();
            const bloqueados = personajesData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj unlock [personaje] [número]_ o _/pj unlock all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                personajesData[senderNumber].bloqueados = [];
                guardarCambios();
                return await message.reply('🔓 *Todos tus personajes han sido desbloqueados.*');
            }

            const personaje = buscarPersonajePorNombre(objetivo);
            if (!personaje) return await message.reply('❌ *Personaje no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `/pj unlock Goku 1`');

            const key = personaje.nombre + '_' + numero;
            const idx = bloqueados.indexOf(key);
            if (idx === -1) return await message.reply(`🔓 La copia #${numero} de *${formatoNombre(personaje.nombre)}* no está bloqueada.`);

            bloqueados.splice(idx, 1);
            guardarCambios();
            return await message.reply(`🔓 *${formatoNombre(personaje.nombre)} #${numero}* desbloqueado.`);
        }

        if (subCommand === 'vender' || subCommand === 'sell') {
            const comandoVender = args[1]?.toLowerCase();
            let totalMonedasGanadas = 0;
            let personajesVendidos = 0;
            const inventarioUsuario = personajesData[senderNumber].personajes;
            const bloqueados = personajesData[senderNumber].bloqueados || [];

            if (comandoVender === 'all' || comandoVender === 'todo' || comandoVender === 'todos') {
                if (inventarioUsuario.length === 0) {
                    return await message.reply('❌ *Tu colección está vacía.*');
                }

                // Calcular qué copias están bloqueadas (por nombre y número de copia)
                const copiasBloqueadas = {}; // nombre -> cuántas copias están bloqueadas
                for (const key of bloqueados) {
                    const partes = key.split('_');
                    const num = parseInt(partes[partes.length - 1]);
                    const nombre = partes.slice(0, partes.length - 1).join('_');
                    if (!isNaN(num)) {
                        copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                    }
                }

                const quedan = []; // los que NO se venden (bloqueados + no reconocidos)

                // Contar inventario
                const conteoTotal = {};
                for (const n of inventarioUsuario) {
                    conteoTotal[n] = (conteoTotal[n] || 0) + 1;
                }

                for (const nameSimple in conteoTotal) {
                    const totalCopias = conteoTotal[nameSimple];
                    const bloqCopias = copiasBloqueadas[nameSimple] || 0;
                    const vendibles = totalCopias - bloqCopias;
                    const pbData = buscarPersonajePorNombre(nameSimple);

                    if (pbData && vendibles > 0) {
                        const precioPorUnidad = obtenerPrecioVenta(pbData.calidad);
                        totalMonedasGanadas += precioPorUnidad * vendibles;
                        personajesVendidos += vendibles;
                    }

                    // Guardar los bloqueados (o no reconocidos) en quedan
                    const aGuardar = pbData ? bloqCopias : totalCopias;
                    for (let i = 0; i < aGuardar; i++) quedan.push(nameSimple);
                }

                if (personajesVendidos === 0) {
                    return await message.reply('❌ *No tienes personajes vendibles.* (Todos están bloqueados o vacíos)');
                }

                personajesData[senderNumber].personajes = quedan;

            } else {
                const nombrePersonajeEntrada = args[1];
                const cantidadAVender = parseInt(args[2] || 1);

                if (!nombrePersonajeEntrada || isNaN(cantidadAVender) || cantidadAVender < 1) {
                    return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj vender [NombrePersonaje] [cantidad]_ o _/pj vender all_');
                }

                const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

                if (!personaje) {
                    return await message.reply(`❌ *Personaje no encontrado.*`);
                }

                const nombreSimple = personaje.nombre;
                const conteoEnInventario = inventarioUsuario.filter(name => name === nombreSimple).length;

                if (conteoEnInventario < cantidadAVender) {
                    return await message.reply(`❌ Solo tienes *${conteoEnInventario}x ${formatoNombre(nombreSimple)}*`);
                }

                const precioPorUnidad = obtenerPrecioVenta(personaje.calidad);
                totalMonedasGanadas = precioPorUnidad * cantidadAVender;
                personajesVendidos = cantidadAVender;

                let eliminados = 0;
                personajesData[senderNumber].personajes = inventarioUsuario.filter(name => {
                    if (name === nombreSimple && eliminados < cantidadAVender) {
                        eliminados++;
                        return false;
                    }
                    return true;
                });
            }

            if (personajesVendidos > 0) {
                await añadirMonedas(senderJid, groupJid, totalMonedasGanadas);
                guardarCambios();

                userDb = await global.db.getUser(senderJid, groupJid);
                const saldoFinal = obtenerMonedas(userDb).toLocaleString();

                const mensaje =
                    `💰 *¡Venta Exitosa!* 💰\n` +
                    '━━━━━━━━━━\n\n' +
                    `Has vendido *${personajesVendidos} personajes* por *${totalMonedasGanadas.toLocaleString()} monedas*.\n` +
                    `Tu saldo total: *${saldoFinal} monedas*.\n\n` +
                    '_¡Sigue coleccionando!_ 👾';

                return await message.reply(mensaje, { mentions: [senderJid] });
            }

            return await message.reply('❌ *Error al procesar la venta.*');
        }

        if (command.match(/^mypj$/i) && subCommand === 'ver') {
            const nombrePersonajeEntrada = args.slice(1).join('');
            if (!nombrePersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /mypj ver [NombrePersonaje]_');
            }

            const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

            if (!personaje) {
                return await message.reply(`❌ *Personaje no reconocido.*`);
            }

            const tienePersonaje = personajesData[senderNumber].personajes.some(pjName => pjName === personaje.nombre);

            if (!tienePersonaje) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(personaje.nombre)}* en tu colección.`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            await message.reply('🔍 *Buscando imagen del personaje...*');
            const imagenUrl = await buscarImagenPersonaje(personaje.nombreFormateado, personaje.anime);

            const caption =
                `👾 *PERSONAJE EN COLECCIÓN* 👾\n` +
                `━━━━━━━━━━\n\n` +
                `*Personaje:* ${formatoNombre(personaje.nombre)}\n` +
                `*Anime:* ${personaje.anime}\n` +
                `*Calidad:* ${personaje.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(personaje.calidad).toLocaleString()} monedas\n\n` +
                `_Este personaje es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }

            return;
        }

        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const ultimaVez = personajesData[senderNumber].ultimoClaim || 0;
            const isPremiumUser = premium.isPremium(senderJid);
            const cooldown = isPremiumUser ? COOLDOWN_RECLAMAR / 2 : COOLDOWN_RECLAMAR;
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Puedes reclamar otro personaje en *${minutos}m ${segundos}s*`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const personajeReclamado = obtenerPersonajeAleatorio();
            personajesData[senderNumber].personajes.push(personajeReclamado.nombre);
            personajesData[senderNumber].ultimoClaim = ahora;
            guardarCambios();

            await message.reply('🔍 *Buscando tu nuevo personaje...*');
            const imagenUrl = await buscarImagenPersonaje(personajeReclamado.nombreFormateado, personajeReclamado.anime);

            const caption =
                `🎉 *¡Has reclamado un personaje!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Personaje:* ${formatoNombre(personajeReclamado.nombre)}\n` +
                `*Anime:* ${personajeReclamado.anime}\n` +
                `*Calidad:* ${personajeReclamado.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(personajeReclamado.calidad).toLocaleString()} monedas\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclama de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }

            return;
        }

        if (subCommand === 'give' || subCommand === 'dar') {
            const isOwner = botConfig.owners.some(o => o.includes(senderNumber));
            if (!isOwner) {
                return await message.reply('❌ *Este comando es solo para creadores/owners.*');
            }

            const mentionedJids = message?.mentions;
            let receptorJid = mentionedJids?.[0];
            let receptorNumber = receptorJid ? receptorJid.split('@')[0] : null;

            if (!receptorNumber && args[1]) {
                const query = args[1].replace(/^@/, '').trim().toLowerCase();
                for (const [key, u] of Object.entries(global.db?.data?.users || {})) {
                    if (u?.apodo && u.apodo.toLowerCase() === query) {
                        receptorNumber = key.split('@')[0].split(':')[0];
                        receptorJid = `${receptorNumber}@s.whatsapp.net`;
                        break;
                    }
                }
                if (!receptorNumber && /^\d+$/.test(query)) {
                    receptorNumber = query;
                    receptorJid = `${query}@s.whatsapp.net`;
                }
            }

            const nombrePersonajeEntrada = args.slice(2).join('');
            let personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

            // Fallback: buscar el personaje en todo el texto del mensaje ignorando tildes, guiones y emojis
            if (!personaje && text) {
                const textNorm = normalizarTexto(text);
                personaje = LISTA_PERSONAJES.find(pb => {
                    const normPb = normalizarTexto(pb.nombreFormateado);
                    return normPb.length >= 3 && textNorm.includes(normPb);
                });
            }

            if (!receptorNumber || !personaje) {
                return await message.reply('❌ *Personaje no reconocido.*\n\n_Ejemplo: .pj give @usuario goku_');
            }

            if (!personajesData[receptorNumber]) {
                personajesData[receptorNumber] = { personajes: [], bloqueados: [], ultimoClaim: 0, jid: receptorJid };
            }

            personajesData[receptorNumber].personajes.push(personaje.nombre);
            guardarCambios();

            const nombreOtorgado = formatoNombre(personaje.nombre);
            return await message.reply(
                `🎁 *¡PERSONAJE OTORGADO!* 🎁\n` +
                '━━━━━━━━━━\n\n' +
                `Se le ha otorgado *${nombreOtorgado}* (${personaje.calidad}) de *${personaje.anime}* a @${receptorNumber}.\n\n` +
                `*Cantidad:* +1`,
                { mentions: [receptorJid] }
            );
        }

        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombrePersonajeEntrada = args.slice(2).join('');

            if (!mentionedJids || mentionedJids.length === 0 || !nombrePersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj regalar @usuario [Nombre_Personaje]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

            if (!personaje) {
                return await message.reply(`❌ *Personaje no reconocido.*`);
            }

            const indexEnInventario = personajesData[senderNumber].personajes.findIndex(pjName => pjName === personaje.nombre);

            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(personaje.nombre)}* para regalar.`);
            }

            if (!personajesData[receptorNumber]) {
                personajesData[receptorNumber] = { personajes: [], ultimoClaim: 0, jid: receptorJid };
            }

            personajesData[senderNumber].personajes.splice(indexEnInventario, 1);
            personajesData[receptorNumber].personajes.push(personaje.nombre);
            guardarCambios();

            const nombreRegalado = formatoNombre(personaje.nombre);

            const mensaje =
                `🎁 *¡REGALO DE PERSONAJE!* 🎁\n` +
                '━━━━━━━━━━\n\n' +
                `@${senderNumber} le ha regalado su *${nombreRegalado}* (${personaje.calidad}) de *${personaje.anime}* a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miPersonajeEntrada = args[2];
            const suPersonajeEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miPersonajeEntrada || !suPersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj intercambio @user [mi_personaje] [su_personaje]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];

            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No puedes intercambiar contigo mismo.*');
            }

            const miPJ = buscarPersonajePorNombre(miPersonajeEntrada);
            const suPJ = buscarPersonajePorNombre(suPersonajeEntrada);

            if (!miPJ || !suPJ) {
                return await message.reply('❌ *Personaje no reconocido.*');
            }

            const indexMiPJ = personajesData[senderNumber].personajes.findIndex(pjName => pjName === miPJ.nombre);
            if (indexMiPJ === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(miPJ.nombre)}* para ofrecer.`);
            }

            if (!personajesData[receptorNumber] || !personajesData[receptorNumber].personajes.includes(suPJ.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suPJ.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosAnime[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorPJ: miPJ.nombre,
                receptorPJ: suPJ.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            setTimeout(async () => {
                if (intercambiosAnime[tradeKey]) {
                    delete intercambiosAnime[tradeKey];
                    guardarCambios();

                    const mensajeCancelado = `⏳ *Intercambio Cancelado* ⏳\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} ha expirado.`;

                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: mensajeCancelado,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _propone:_ *${formatoNombre(miPJ.nombre)}* (${miPJ.calidad}) de *${miPJ.anime}*\n` +
                `_por el personaje de_ *@${receptorNumber}:* *${formatoNombre(suPJ.nombre)}* (${suPJ.calidad}) de *${suPJ.anime}*\n\n` +
                `*Para aceptar:*\n/pj intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n/pj intercambio rechazar @${senderNumber}\n\n` +
                `_Tienes 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: /pj intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;

            const propuesta = intercambiosAnime[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosAnime[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje =
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* ha rechazado la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será en otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            const miPJSimple = propuesta.receptorPJ;
            const suPJSimple = propuesta.emisorPJ;

            const indexMiPJ = personajesData[senderNumber].personajes.findIndex(pjName => pjName === miPJSimple);
            const indexSuPJ = personajesData[emisorNumber].personajes.findIndex(pjName => pjName === suPJSimple);

            if (indexMiPJ === -1) {
                return await message.reply(`❌ *ERROR: Ya no tienes a ${formatoNombre(miPJSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuPJ === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suPJSimple)}*`, { mentions: [emisorJid] });
            }

            personajesData[senderNumber].personajes.splice(indexMiPJ, 1);
            personajesData[emisorNumber].personajes.splice(indexSuPJ, 1);

            personajesData[senderNumber].personajes.push(suPJSimple);
            personajesData[emisorNumber].personajes.push(miPJSimple);

            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* recibe: *${formatoNombre(suPJSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(miPJSimple)}*\n\n` +
                '_¡Nuevos personajes para ambos!_ 👾';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        if (command.match(/^(mypj)$/i)) {
            const inventario = personajesData[senderNumber]?.personajes || [];
            const bloqueados = personajesData[senderNumber]?.bloqueados || [];

            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(`👾 *COLECCIÓN DE* @${senderNumber} 👾\n\n_No tienes personajes. Usa /pj reclamar para obtener uno._\n\n*Monedas Totales:* ${monedasActuales} 💰`, { mentions: [senderJid] });
            }

            const conteo = inventario.reduce((acc, name) => {
                acc[name] = (acc[name] || 0) + 1;
                return acc;
            }, {});

            // Calcular cuántas copias bloqueadas tiene cada personaje
            const copiasBloqueadas = {};
            for (const key of bloqueados) {
                const partes = key.split('_');
                const num = parseInt(partes[partes.length - 1]);
                const nombre = partes.slice(0, partes.length - 1).join('_');
                if (!isNaN(num)) {
                    copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                }
            }

            let mensaje = `👾 *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Personajes)_ 👾\n` +
                          `*Monedas Totales:* ${monedasActuales} 💰\n` +
                          '━━━━━━━━━━\n';

            const personajesUnicos = Object.keys(conteo).sort();

            personajesUnicos.forEach(nameSimple => {
                const pbData = buscarPersonajePorNombre(nameSimple);
                const count = conteo[nameSimple];
                const calidad = pbData ? pbData.calidad : '???';
                const anime = pbData ? pbData.anime : '???';
                const precio = pbData ? obtenerPrecioVenta(pbData.calidad).toLocaleString() : '???';
                const bloq = copiasBloqueadas[nameSimple] || 0;
                const bloqTexto = bloq > 0 ? ` 🔒x${bloq}` : '';

                mensaje += `\n*${formatoNombre(nameSimple)}* x${count}${bloqTexto}\n` +
                          `└ ${anime} • ${calidad}\n` +
                          `└ Venta: ${precio} c/u`;
            });

            if (bloqueados.length > 0) {
                mensaje += `\n\n🔒 *Bloqueados:* ${bloqueados.length} copia(s) protegida(s) del \`vender all\``;
            }

            mensaje += '\n\n_Usa /mypj ver [personaje] para ver su imagen._';

            return await message.reply(mensaje, { mentions: [senderJid] });
        }

        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usa /pj para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de personajes:', error.code || error.message, '\x1b[0m');

        let userMessage = '❌ *Error en el sistema*';
        if (error.code === 'EACCES') {
            userMessage += '\n\n_Error de permisos (EACCES). Contacta al administrador._';
        } else {
            userMessage += '\n\n_Ocurrió un error al procesar tu solicitud._';
        }

        return await message.reply(userMessage);
    }
};

handler.help = ['pj', 'pj give', 'pj reclamar', 'pj claim', 'mypj', 'mypj ver', 'pj regalar', 'pj intercambio', 'pj vender', 'pj vender all', 'pj sell', 'pj sell all', 'pj block', 'pj unlock', 'pj bloquear', 'pj desbloquear'];
handler.tags = ['juegos'];
handler.command = /^(pj|mypj)$/i;

module.exports = handler;
handler.group = false