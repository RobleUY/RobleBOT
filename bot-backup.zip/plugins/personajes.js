const axios = require('axios');
const db = require('../database.js');

// **IMPORTANTE:** Este código asume acceso a global.conn para @whiskeysockets/baileys
// y global.db para el sistema de monedas

// --- CONFIGURACIÓN DE PRECIOS ---
const PRECIO_BASE_POR_ESTRELLA = 15000; // 15,000 monedas por estrella
const COOLDOWN_RECLAMAR = 60 * 60 * 1000; // 1 hora
// ---

// 🧠 Cache simple para imágenes de Pinterest
const imageCache = new Map();

function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.personajes) db.data.personajes = {};
    if (!db.data.intercambiosAnime) db.data.intercambiosAnime = {};
}

function guardarCambios() {
    if (db && typeof db.save === 'function') {
        db.save();
    }
}

/**
 * 🔍 Buscar imagen de personaje en Pinterest
 */
async function buscarImagenPersonaje(nombrePersonaje, anime) {
    const query = `${nombrePersonaje} ${anime} anime`;

    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://www.robleuy.site/robleapi/buscador/pinterest?q=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 8000 });

        if (!data?.ok || !data?.images?.length) return null;

        const random = data.images[Math.floor(Math.random() * data.images.length)];
        const imageUrl = random?.large || random?.small;
        if (!imageUrl) return null;

        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`Error buscando imagen para ${nombrePersonaje}:`, error.message);
        return null;
    }
}

// --- DATOS DE PERSONAJES DE ANIME ---
// Nota: La imagen se toma de los datos base, no se usa Pinterest como en el de futbolistas.
const PERSONAJES_BASE = [
    { nombre: 'Goku', anime: 'Dragon Ball', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/af/09/ba/af09badf32819ff23782bf8d130d4caf.jpg' },
    { nombre: 'Vegeta', anime: 'Dragon Ball', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/38/70/53/387053d3b7b8d6063b4cb10df8dfbaf2.jpg' },
    { nombre: 'Gohan', anime: 'Dragon Ball', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/51/4b/83/514b83b6c58723e5794fc02335848bca.jpg' },
    { nombre: 'Trunks', anime: 'Dragon Ball', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/d8/e9/12/d8e912a9dd6f7f613f0aa998ac55197a.jpg' },
    { nombre: 'Naruto Uzumaki', anime: 'Naruto', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/ca/c6/d8/cac6d852725aa673ffe24f9f955e6ba1.jpg' },
    { nombre: 'Sasuke Uchiha', anime: 'Naruto', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/cf/2e/3f/cf2e3f3615cbcc7cd5521b7421ae50c4.jpg' },
    { nombre: 'Kakashi Hatake', anime: 'Naruto', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/6a/71/88/6a718888d46ee5d914fef894a72aef5c.jpg' },
    { nombre: 'Luffy', anime: 'One Piece', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/35/d4/42/35d44263fa4bac83874b53e431ecb9a8.jpg' },
    { nombre: 'Zoro', anime: 'One Piece', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/df/70/55/df70557bd33d44381a486fbe9d6eb8f1.jpg' },
    { nombre: 'Sanji', anime: 'One Piece', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/43/0a/95/430a9585d9c15bb8c8edc423abc28d92.jpg' },
    { nombre: 'Nami', anime: 'One Piece', calidad: '☆☆', imagen: 'https://i.pinimg.com/736x/ae/60/76/ae607673ca5a12fa09c795cb5abc5451.jpg' },
    { nombre: 'Tanjiro Kamado', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/36/2c/00/362c00f49cf1a052d77f5b85cd7670b7.jpg' },
    { nombre: 'Nezuko Kamado', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/06/cd/5e/06cd5e6030adfcd3ddcfb3e3701ce386.jpg' },
    { nombre: 'Inosuke Hashibira', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/48/bd/4a/48bd4adfa4fc42bd37cc4056de44570d.jpg' },
    { nombre: 'Zenitsu Agatsuma', anime: 'Kimetsu no Yaiba', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/a9/33/58/a93358ca66ad9c9b39dafdca9c249b4e.jpg' },
    { nombre: 'Eren Yeager', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/0d/8f/72/0d8f72aff003bfd5970d7f8c46355cce.jpg' },
    { nombre: 'Mikasa Ackerman', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/26/87/69/268769889ffd00e27bf184a7c1e2a1ac.jpg' },
    { nombre: 'Levi Ackerman', anime: 'Shingeki no Kyojin', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/8e/98/a8/8e98a8870451371ef83bd3c84070d804.jpg' },
    { nombre: 'Armin Arlert', anime: 'Shingeki no Kyojin', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/cb/c8/34/cbc8340f8f3177b7aa2812e2c7fa6e9b.jpg' },
    { nombre: 'Saitama', anime: 'One Punch Man', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/35/fb/66/35fb669fd3d93d70cea64b8a8f15e6e7.jpg' },
    { nombre: 'Genos', anime: 'One Punch Man', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/af/88/4f/af884f700880c3c935e59d2af75a7a1a.jpg' },
    { nombre: 'Tatsumaki', anime: 'One Punch Man', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/b8/42/a8/b842a8c6f201e06d2e75df6015f46be9.jpg' },
    { nombre: 'Deku', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/55/93/5e/55935e9be43efd3b9c8fef76fc7bb112.jpg' },
    { nombre: 'All Might', anime: 'My Hero Academia', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/ff/f6/fc/fff6fc55b117108f3e10a77500cf95a6.jpg' },
    { nombre: 'Bakugo', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/12/4d/9f/124d9f32309533b98e19f1f151af2f30.jpg' },
    { nombre: 'Todoroki', anime: 'My Hero Academia', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/c6/e9/7c/c6e97c541f4adfdb10873b9e6b8958bc.jpg' },
    { nombre: 'Gojo Satoru', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/20/4b/3a/204b3afc5502ded15b37468b326a7429.jpg' },
    { nombre: 'Yuji Itadori', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/9c/68/d6/9c68d673bb3aade436b396aa3f88d67c.jpg' },
    { nombre: 'Megumi Fushiguro', anime: 'Jujutsu Kaisen', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/cd/b1/36/cdb1363f1b5a9e2161c490e5ed030643.jpg' },
    { nombre: 'Nobara Kugisaki', anime: 'Jujutsu Kaisen', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/0c/4c/8d/0c4c8d8d8abbb0bc57e09e16aa568e72.jpg' },
    { nombre: 'Edward Elric', anime: 'Fullmetal Alchemist', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/07/15/d8/0715d8cca64c5c12112f03afc71e7903.jpg' },
    { nombre: 'Alphonse Elric', anime: 'Fullmetal Alchemist', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/01/02/e7/0102e7b3811cc3a3feff6db97dbc6922.jpg' },
    { nombre: 'Kenshin Himura', anime: 'Rurouni Kenshin', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/e7/1e/64/e71e6453a01d860573faf01ff02ee5ad.jpg' },
    { nombre: 'Light Yagami', anime: 'Death Note', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/99/0f/a3/990fa31af6df1bdc7ec61633eb1bdc30.jpg' },
    { nombre: 'L', anime: 'Death Note', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/3b/0a/c1/3b0ac15f51de8be95927bd13426101f3.jpg' },
    { nombre: 'Ichigo Kurosaki', anime: 'Bleach', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/e9/a0/a1/e9a0a1ec757627a02a1e21d5eadad1f4.jpg' },
    { nombre: 'Rukia Kuchiki', anime: 'Bleach', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/1200x/db/12/d7/db12d7c02adcd151ce86cc9547335648.jpg' },
    { nombre: 'Natsu Dragneel', anime: 'Fairy Tail', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/1200x/c9/5f/78/c95f780d8377aba54cadfd9309a21d77.jpg' },
    { nombre: 'Erza Scarlet', anime: 'Fairy Tail', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/dd/52/11/dd521138e82a3bc1c913d6dc54083a40.jpg' },
    { nombre: 'Lucy Heartfilia', anime: 'Fairy Tail', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/65/cf/3a/65cf3a29fa7bf1e2340f93beea11186a.jpg' },
    { nombre: 'Gintoki Sakata', anime: 'Gintama', calidad: '☆☆☆☆☆', imagen: 'https://i.pinimg.com/736x/38/a3/1f/38a31f49313667d0cf6a6cd887172102.jpg' },
    { nombre: 'Killua Zoldyck', anime: 'Hunter x Hunter', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/6c/99/b5/6c99b5492a6950ca1413246beb804662.jpg' },
    { nombre: 'Gon Freecss', anime: 'Hunter x Hunter', calidad: '☆☆☆☆', imagen: 'https://i.pinimg.com/736x/f7/c8/fd/f7c8fd78d9a9df448db9d4b1ce10f653.jpg' },
    { nombre: 'Kurapika', anime: 'Hunter x Hunter', calidad: '☆☆☆', imagen: 'https://i.pinimg.com/736x/e8/6b/6d/e86b6d0fb495bd922c180241d1286828.jpg' },
];

const LISTA_PERSONAJES = PERSONAJES_BASE.map(pb => ({
    ...pb,
    nombreFormateado: pb.nombre,
    nombre: pb.nombre.replace(/\s/g, '').toLowerCase() // Nombre simple (sin espacios, minúsculas)
}));

/**
 * Convierte el nombre simple al formato legible
 */
function formatoNombre(nombreSimple) {
    const pbData = LISTA_PERSONAJES.find(pb => pb.nombre === nombreSimple);
    if (!pbData) return nombreSimple.toUpperCase();
    return pbData.nombreFormateado.replace(/\s/g, '_');
}

/**
 * Obtiene el precio de venta basado en estrellas
 */
function obtenerPrecioVenta(calidadString) {
    const estrellas = calidadString.length;
    return estrellas * PRECIO_BASE_POR_ESTRELLA;
}

// --- Carga y Guardado de Datos ---

function obtenerPersonajesData(numero, senderJid) {
    ensureDatabaseCollections();
    const cleanNumber = String(numero).replace(/[^0-9]/g, '');
    if (!db.data.personajes[cleanNumber]) {
        db.data.personajes[cleanNumber] = {
            personajes: [],
            ultimoClaim: 0,
            jid: senderJid || `${cleanNumber}@s.whatsapp.net`
        };
        guardarCambios();
    }
    return db.data.personajes[cleanNumber];
}

function obtenerIntercambiosAnime() {
    ensureDatabaseCollections();
    return db.data.intercambiosAnime;
}

// --- FUNCIONES DE MANEJO DE MONEDAS ---
function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

async function restarMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return false;
    const user = await global.db.getUser(jid, groupId);
    let restante = cantidad;

    if (user.money >= restante) {
        user.money -= restante;
    } else {
        restante -= (user.money || 0);
        user.money = 0;

        if (user.bank >= restante) {
            user.bank -= restante;
        } else {
            return false;
        }
    }
    // Asume que global.db.saveUser existe y guarda el estado actualizado
    // await global.db.saveUser(user);
    return true;
}

// --- Otras Funciones de Utilidad ---
function obtenerPersonajeAleatorio() {
    // Implementación de peso inverso por calidad (mayor calidad, menor probabilidad)
    const totalPeso = LISTA_PERSONAJES.reduce((sum, pb) => {
        const pesoBase = 6 - pb.calidad.length;
        return sum + pesoBase;
    }, 0);

    let random = Math.floor(Math.random() * totalPeso);
    for (const pb of LISTA_PERSONAJES) {
        const pesoBase = 6 - pb.calidad.length;
        if (random < pesoBase) {
            return pb;
        }
        random -= pesoBase;
    }
    return LISTA_PERSONAJES[Math.floor(Math.random() * LISTA_PERSONAJES.length)];
}

function buscarPersonajePorNombre(nombreSimple) {
    const nombreLimpio = nombreSimple.replace(/\s/g, '').replace(/_/g, '').toLowerCase();
    return LISTA_PERSONAJES.find(pb => pb.nombre === nombreLimpio);
}

// --- Manejador Principal ---
let handler = async (message, { text, command, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = senderJid?.split('@')[0];

        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const personajesData = db.data.personajes;
        const intercambiosAnime = db.data.intercambiosAnime;

        if (!personajesData[senderNumber]) {
            personajesData[senderNumber] = {
                personajes: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            guardarCambios();
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        // COMANDO: /pj (sin subcomando) -> Muestra comandos
        if (command.match(/^pj$/i) && !subCommand) {
            return await message.reply(
                '👾 *COMANDOS DE PERSONAJES DE ANIME* 👾\n' +
                '━━━━━━━━━━\n\n' +
                '*/pj reclamar* / *claim* - _Reclama un personaje aleatorio (1 por hora)._\n' +
                '*/mypj* - _Ver tu colección de personajes._\n' +
                '*/mypj ver [personaje]* - _Ver la imagen de un personaje._\n' +
                '*/pj regalar @user [personaje]* - _Regala un personaje._\n' +
                '*/pj intercambio @user [mi_pj] [su_pj]* - _Propone intercambio._\n' +
                '*/pj intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*/pj intercambio rechazar @user* - _Rechazar intercambio._\n' +
                '*/pj vender [personaje] [cantidad]* - _Vende personajes._\n' +
                '*/pj vender all* - _Vende todos los duplicados._\n'
            );
        }

        // SUBCOMANDO: vender
        if (subCommand === 'vender') {
            const comandoVender = args[1]?.toLowerCase();
            let totalMonedasGanadas = 0;
            let personajesVendidos = 0;
            const inventarioUsuario = personajesData[senderNumber].personajes;

            if (comandoVender === 'all') {
                if (inventarioUsuario.length === 0) {
                    return await message.reply('❌ *Tu colección está vacía.*');
                }

                const conteo = inventarioUsuario.reduce((acc, name) => {
                    acc[name] = (acc[name] || 0) + 1;
                    return acc;
                }, {});

                const personajesAConservar = [];

                for (const nameSimple in conteo) {
                    const count = conteo[nameSimple];
                    const pbData = buscarPersonajePorNombre(nameSimple);

                    if (pbData) {
                        personajesAConservar.push(nameSimple);
                        const duplicadosAVender = count - 1;

                        if (duplicadosAVender > 0) {
                            const precioPorUnidad = obtenerPrecioVenta(pbData.calidad);
                            const ganancia = precioPorUnidad * duplicadosAVender;
                            totalMonedasGanadas += ganancia;
                            personajesVendidos += duplicadosAVender;
                        }
                    } else {
                        // Conservar personajes no reconocidos (por si acaso)
                        for (let i = 0; i < count; i++) {
                            personajesAConservar.push(nameSimple);
                        }
                    }
                }

                if (personajesVendidos === 0) {
                    return await message.reply('❌ *No tienes personajes duplicados.*');
                }

                personajesData[senderNumber].personajes = personajesAConservar;

            } else {
                const nombrePersonajeEntrada = args[1];
                const cantidadAVender = parseInt(args[2] || 1);

                if (!nombrePersonajeEntrada || isNaN(cantidadAVender) || cantidadAVender < 1) {
                    return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj vender [NombrePersonaje] [cantidad]_ o _/pj vender all_');
                }

                const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

                if (!personaje) {
                    return await message.reply(`❌ *Personaje no encontrado.*`);
                }

                const nombreSimple = personaje.nombre;
                const conteoEnInventario = inventarioUsuario.filter(name => name === nombreSimple).length;

                if (conteoEnInventario < cantidadAVender) {
                    return await message.reply(`❌ Solo tienes *${conteoEnInventario}x ${formatoNombre(nombreSimple)}*`);
                }

                const precioPorUnidad = obtenerPrecioVenta(personaje.calidad);
                totalMonedasGanadas = precioPorUnidad * cantidadAVender;
                personajesVendidos = cantidadAVender;

                let eliminados = 0;
                personajesData[senderNumber].personajes = inventarioUsuario.filter(name => {
                    if (name === nombreSimple && eliminados < cantidadAVender) {
                        eliminados++;
                        return false;
                    }
                    return true;
                });
            }

            if (personajesVendidos > 0) {
                await añadirMonedas(senderJid, groupJid, totalMonedasGanadas);
                guardarCambios();

                // Es necesario volver a obtener los datos del usuario para el saldo final
                userDb = await global.db.getUser(senderJid, groupJid);
                const saldoFinal = obtenerMonedas(userDb).toLocaleString();

                const mensaje =
                    `💰 *¡Venta Exitosa!* 💰\n` +
                    '━━━━━━━━━━\n\n' +
                    `Has vendido *${personajesVendidos} personajes* por *${totalMonedasGanadas.toLocaleString()} monedas*.\n` +
                    `Tu saldo total: *${saldoFinal} monedas*.\n\n` +
                    '_¡Sigue coleccionando!_ 👾';

                return await message.reply(mensaje, { mentions: [senderJid] });
            }

            return await message.reply('❌ *Error al procesar la venta.*');
        }

        // SUBCOMANDO: ver
        if (command.match(/^mypj$/i) && subCommand === 'ver') {
            const nombrePersonajeEntrada = args.slice(1).join('');
            if (!nombrePersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /mypj ver [NombrePersonaje]_');
            }

            const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

            if (!personaje) {
                return await message.reply(`❌ *Personaje no reconocido.*`);
            }

            const tienePersonaje = personajesData[senderNumber].personajes.some(pjName => pjName === personaje.nombre);

            if (!tienePersonaje) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(personaje.nombre)}* en tu colección.`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            await message.reply('🔍 *Buscando imagen del personaje...*');
            const imagenUrl = await buscarImagenPersonaje(personaje.nombreFormateado, personaje.anime);

            const caption =
                `👾 *PERSONAJE EN COLECCIÓN* 👾\n` +
                `━━━━━━━━━━\n\n` +
                `*Personaje:* ${formatoNombre(personaje.nombre)}\n` +
                `*Anime:* ${personaje.anime}\n` +
                `*Calidad:* ${personaje.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(personaje.calidad).toLocaleString()} monedas\n\n` +
                `_Este personaje es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }

            return;
        }

        // SUBCOMANDO: reclamar / claim
        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const ultimaVez = personajesData[senderNumber].ultimoClaim || 0;
            const cooldown = COOLDOWN_RECLAMAR; // 1 hora
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Puedes reclamar otro personaje en *${minutos}m ${segundos}s*`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const personajeReclamado = obtenerPersonajeAleatorio();
            personajesData[senderNumber].personajes.push(personajeReclamado.nombre);
            personajesData[senderNumber].ultimoClaim = ahora;
            guardarCambios();

            await message.reply('🔍 *Buscando tu nuevo personaje...*');
            const imagenUrl = await buscarImagenPersonaje(personajeReclamado.nombreFormateado, personajeReclamado.anime);

            const caption =
                `🎉 *¡Has reclamado un personaje!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Personaje:* ${formatoNombre(personajeReclamado.nombre)}\n` +
                `*Anime:* ${personajeReclamado.anime}\n` +
                `*Calidad:* ${personajeReclamado.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(personajeReclamado.calidad).toLocaleString()} monedas\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclama de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._', { mentions: [senderJid] });
            }

            return;
        }

        // SUBCOMANDO: regalar
        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombrePersonajeEntrada = args.slice(2).join('');

            if (!mentionedJids || mentionedJids.length === 0 || !nombrePersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj regalar @usuario [Nombre_Personaje]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const personaje = buscarPersonajePorNombre(nombrePersonajeEntrada);

            if (!personaje) {
                return await message.reply(`❌ *Personaje no reconocido.*`);
            }

            const indexEnInventario = personajesData[senderNumber].personajes.findIndex(pjName => pjName === personaje.nombre);

            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(personaje.nombre)}* para regalar.`);
            }

            if (!personajesData[receptorNumber]) {
                personajesData[receptorNumber] = { personajes: [], ultimoClaim: 0, jid: receptorJid };
            }

            personajesData[senderNumber].personajes.splice(indexEnInventario, 1);
            personajesData[receptorNumber].personajes.push(personaje.nombre);
            guardarCambios();

            const nombreRegalado = formatoNombre(personaje.nombre);

            const mensaje =
                `🎁 *¡REGALO DE PERSONAJE!* 🎁\n` +
                '━━━━━━━━━━\n\n' +
                `@${senderNumber} le ha regalado su *${nombreRegalado}* (${personaje.calidad}) de *${personaje.anime}* a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio (proponer)
        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miPersonajeEntrada = args[2];
            const suPersonajeEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miPersonajeEntrada || !suPersonajeEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /pj intercambio @user [mi_personaje] [su_personaje]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];

            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No puedes intercambiar contigo mismo.*');
            }

            const miPJ = buscarPersonajePorNombre(miPersonajeEntrada);
            const suPJ = buscarPersonajePorNombre(suPersonajeEntrada);

            if (!miPJ || !suPJ) {
                return await message.reply('❌ *Personaje no reconocido.*');
            }

            const indexMiPJ = personajesData[senderNumber].personajes.findIndex(pjName => pjName === miPJ.nombre);
            if (indexMiPJ === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(miPJ.nombre)}* para ofrecer.`);
            }

            if (!personajesData[receptorNumber] || !personajesData[receptorNumber].personajes.includes(suPJ.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suPJ.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosAnime[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorPJ: miPJ.nombre,
                receptorPJ: suPJ.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            // Configurar el tiempo de expiración (40 segundos)
            setTimeout(async () => {
                if (intercambiosAnime[tradeKey]) {
                    delete intercambiosAnime[tradeKey];
                    guardarCambios();

                    const mensajeCancelado = `⏳ *Intercambio Cancelado* ⏳\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} ha expirado.`;

                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: mensajeCancelado,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _propone:_ *${formatoNombre(miPJ.nombre)}* (${miPJ.calidad}) de *${miPJ.anime}*\n` +
                `_por el personaje de_ *@${receptorNumber}:* *${formatoNombre(suPJ.nombre)}* (${suPJ.calidad}) de *${suPJ.anime}*\n\n` +
                `*Para aceptar:*\n/pj intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n/pj intercambio rechazar @${senderNumber}\n\n` +
                `_Tienes 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio aceptar/rechazar
        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: /pj intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;

            const propuesta = intercambiosAnime[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosAnime[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje =
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* ha rechazado la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será en otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            // Aceptar Intercambio
            const miPJSimple = propuesta.receptorPJ;
            const suPJSimple = propuesta.emisorPJ;

            const indexMiPJ = personajesData[senderNumber].personajes.findIndex(pjName => pjName === miPJSimple);
            const indexSuPJ = personajesData[emisorNumber].personajes.findIndex(pjName => pjName === suPJSimple);

            if (indexMiPJ === -1) {
                return await message.reply(`❌ *ERROR: Ya no tienes a ${formatoNombre(miPJSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuPJ === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suPJSimple)}*`, { mentions: [emisorJid] });
            }

            // Realizar el intercambio
            personajesData[senderNumber].personajes.splice(indexMiPJ, 1);
            personajesData[emisorNumber].personajes.splice(indexSuPJ, 1);

            personajesData[senderNumber].personajes.push(suPJSimple);
            personajesData[emisorNumber].personajes.push(miPJSimple);

            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* recibe: *${formatoNombre(suPJSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(miPJSimple)}*\n\n` +
                '_¡Nuevos personajes para ambos!_ 👾';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        // COMANDO: /mypj
        if (command.match(/^(mypj)$/i)) {
            const inventario = personajesData[senderNumber]?.personajes || [];

            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(`👾 *COLECCIÓN DE* @${senderNumber} 👾\n\n_No tienes personajes. Usa /pj reclamar para obtener uno._\n\n*Monedas Totales:* ${monedasActuales} 💰`, { mentions: [senderJid] });
            }

            const conteo = inventario.reduce((acc, name) => {
                acc[name] = (acc[name] || 0) + 1;
                return acc;
            }, {});

            let mensaje = `👾 *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Personajes)_ 👾\n` +
                          `*Monedas Totales:* ${monedasActuales} 💰\n` +
                          '━━━━━━━━━━\n';

            const personajesUnicos = Object.keys(conteo).sort();

            personajesUnicos.forEach(nameSimple => {
                const pbData = buscarPersonajePorNombre(nameSimple);
                const count = conteo[nameSimple];
                const calidad = pbData ? pbData.calidad : '???';
                const anime = pbData ? pbData.anime : '???';
                const precio = pbData ? obtenerPrecioVenta(pbData.calidad).toLocaleString() : '???';

                mensaje += `\n*${formatoNombre(nameSimple)}* x${count}\n` +
                          `└ ${anime} • ${calidad}\n` +
                          `└ Venta: ${precio} c/u`;
            });

            mensaje += '\n\n_Usa /mypj ver [personaje] para ver su imagen._';

            return await message.reply(mensaje, { mentions: [senderJid] });
        }

        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usa /pj para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de personajes:', error.code || error.message, '\x1b[0m');

        let userMessage = '❌ *Error en el sistema*';
        if (error.code === 'EACCES') {
            userMessage += '\n\n_Error de permisos (EACCES). Contacta al administrador._';
        } else {
            userMessage += '\n\n_Ocurrió un error al procesar tu solicitud._';
        }

        return await message.reply(userMessage);
    }
};

handler.help = ['pj', 'pj reclamar', 'pj claim', 'mypj', 'mypj ver', 'pj regalar', 'pj intercambio', 'pj vender', 'pj vender all'];
handler.tags = ['juegos'];
handler.command = /^(pj|mypj)$/i;

module.exports = handler;
handler.group = false