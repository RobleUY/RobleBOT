const fs = require('fs');
const path = require('path');

// 📂 Rutas de archivos
const palabrasPath = path.join(__dirname, 'palabras_wordle.json');
const partidasPath = path.join(__dirname, 'wordle_partidas.json');

// 🔤 Cargar palabras desde palabras.json
let palabras = [];

function cargarPalabras() {
    try {
        if (fs.existsSync(palabrasPath)) {
            delete require.cache[palabrasPath];
            const data = fs.readFileSync(palabrasPath, 'utf8');
            const listaBruta = JSON.parse(data);
            palabras = listaBruta
                .map(p => limpiarTexto(p))
                .filter(p => p.length >= 4 && p.length <= 8);
            console.log(`\x1b[32m[WORDLE] ✅ Cargadas ${palabras.length} palabras desde palabras.json\x1b[0m`);
            return true;
        }
    } catch (error) {
        console.error('\x1b[31m[WORDLE] ❌ Error al cargar palabras.json:', error.message, '\x1b[0m');
    }
    palabras = ['roble', 'fuego', 'cielo', 'perro', 'arena', 'tigre', 'nube', 'reloj', 'barco', 'selva', 'piano', 'puente', 'camino', 'guerra', 'volcan', 'otoño', 'montaña'];
    return false;
}

cargarPalabras();

// 💾 Sistema de Persistencia de Partidas en wordle_partidas.json
let estadoGlobal = {
    partidas: {}
};

function cargarEstado() {
    try {
        if (fs.existsSync(partidasPath)) {
            const rawData = fs.readFileSync(partidasPath, 'utf8');
            const data = JSON.parse(rawData);
            estadoGlobal.partidas = data.partidas || {};
        }
    } catch (err) {
        console.error('\x1b[31m[WORDLE] Error al leer wordle_partidas.json:', err.message, '\x1b[0m');
        estadoGlobal = { partidas: {} };
    }
}

function guardarEstado() {
    try {
        fs.writeFileSync(partidasPath, JSON.stringify(estadoGlobal, null, 2), 'utf8');
    } catch (err) {
        console.error('\x1b[31m[WORDLE] Error al guardar wordle_partidas.json:', err.message, '\x1b[0m');
    }
}

// Cargar estado inicial
cargarEstado();

// 🆔 Limpiar ID de usuario
function obtenerCleanUser(sender) {
    if (!sender) return '';
    return String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

// 🔢 Normalizar número (para comparar/indexar en el ranking, igual que topcoins.js)
function normalizeNumber(jidPart) {
    return String(jidPart || '').split('@')[0].replace(/[^0-9]/g, '').trim();
}

// 🧹 Limpieza y normalización de texto (preserva la Ñ)
function limpiarTexto(str) {
    return (str || '')
        .replace(/ñ/g, '__n_tilde__')
        .replace(/Ñ/g, '__N_tilde__')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/__n_tilde__/g, 'ñ')
        .replace(/__N_tilde__/g, 'ñ')
        .replace(/[^a-zA-ZñÑ]/g, '')
        .toLowerCase()
        .trim();
}

// 📊 Base de datos (database.json via global.db) para Estadísticas
function obtenerStatsUser(userId) {
    let stats = {
        jugadas: 0,
        ganadas: 0,
        perdidas: 0,
        intentosTotales: 0,
        racha: 0,
        maxRacha: 0,
        monedasGanadas: 0
    };

    try {
        if (global.db) {
            const user = global.db.getUser(userId);
            if (user && user.wordle) {
                stats = { ...stats, ...user.wordle };
            }
        }
    } catch (e) {
        console.error('[WORDLE DB READ STATS ERROR]', e.message);
    }
    return stats;
}

function actualizarStatsUser(userId, esVictoria, intentosCount, premio = 0) {
    try {
        if (!global.db) return;
        let user = global.db.getUser(userId);
        if (!user) user = { money: 0 };

        if (!user.wordle) {
            user.wordle = {
                jugadas: 0,
                ganadas: 0,
                perdidas: 0,
                intentosTotales: 0,
                racha: 0,
                maxRacha: 0,
                monedasGanadas: 0
            };
        }

        const st = user.wordle;
        st.jugadas = (st.jugadas || 0) + 1;
        st.intentosTotales = (st.intentosTotales || 0) + intentosCount;

        if (esVictoria) {
            st.ganadas = (st.ganadas || 0) + 1;
            st.racha = (st.racha || 0) + 1;
            if (st.racha > (st.maxRacha || 0)) st.maxRacha = st.racha;
            st.monedasGanadas = (st.monedasGanadas || 0) + premio;
            user.money = (Number(user.money) || 0) + premio;
        } else {
            st.perdidas = (st.perdidas || 0) + 1;
            st.racha = 0;
        }

        global.db.setUser(userId, user);
        if (typeof global.db.save === 'function') global.db.save();
    } catch (e) {
        console.error('[WORDLE DB SAVE STATS ERROR]', e.message);
    }
}

// 🎯 Algoritmo oficial Wordle (2 pasadas para manejo exacto de letras duplicadas)
function evaluarIntento(palabraSecreta, intento) {
    const len = palabraSecreta.length;
    const resultado = new Array(len).fill('⬛');
    const conteoNoEmparejados = {};

    for (let i = 0; i < len; i++) {
        if (intento[i] !== palabraSecreta[i]) {
            const char = palabraSecreta[i];
            conteoNoEmparejados[char] = (conteoNoEmparejados[char] || 0) + 1;
        }
    }

    // Paso 1: Verdes (🟩)
    for (let i = 0; i < len; i++) {
        if (intento[i] === palabraSecreta[i]) {
            resultado[i] = '🟩';
        }
    }

    // Paso 2: Amarillos (🟨)
    for (let i = 0; i < len; i++) {
        if (resultado[i] !== '🟩') {
            const char = intento[i];
            if (conteoNoEmparejados[char] && conteoNoEmparejados[char] > 0) {
                resultado[i] = '🟨';
                conteoNoEmparejados[char]--;
            }
        }
    }

    return resultado;
}

// ⌨️ Estado del teclado
function obtenerEstadoTeclado(intentos) {
    const estadoLetras = {};

    for (const item of intentos) {
        const palabra = item.palabra;
        const res = item.resultado;
        for (let i = 0; i < palabra.length; i++) {
            const char = palabra[i].toUpperCase();
            const emoji = res[i];

            if (emoji === '🟩') {
                estadoLetras[char] = '🟩';
            } else if (emoji === '🟨') {
                if (estadoLetras[char] !== '🟩') {
                    estadoLetras[char] = '🟨';
                }
            } else if (emoji === '⬛') {
                if (!estadoLetras[char]) {
                    estadoLetras[char] = '⬛';
                }
            }
        }
    }

    const correctas = [];
    const presentes = [];
    const descartadas = [];

    for (const [char, status] of Object.entries(estadoLetras)) {
        if (status === '🟩') correctas.push(char);
        else if (status === '🟨') presentes.push(char);
        else if (status === '⬛') descartadas.push(char);
    }

    return {
        correctas: correctas.sort().join(', ') || 'Ninguna',
        presentes: presentes.sort().join(', ') || 'Ninguna',
        descartadas: descartadas.sort().join(', ') || 'Ninguna'
    };
}

// 🎨 Renderizar tablero visual
function renderizarTablero(partida, estadoJuego = 'EN_PROGRESO') {
    const emojisNumeros = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];
    const maxIntentos = partida.maxIntentos || 6;
    const len = partida.longitud;
    let gridText = '';

    for (let i = 0; i < maxIntentos; i++) {
        const num = emojisNumeros[i] || `${i + 1}️⃣`;
        if (i < partida.intentos.length) {
            const item = partida.intentos[i];
            const bloques = item.resultado.join(' ');
            const letrasSpaced = item.palabra.toUpperCase().split('').join(' ');
            gridText += `${num} ${bloques}  \`(${letrasSpaced})\`\n`;
        } else {
            const vacios = new Array(len).fill('⬛').join(' ');
            gridText += `${num} ${vacios}\n`;
        }
    }

    const teclado = obtenerEstadoTeclado(partida.intentos);
    const creadorClean = partida.creador ? partida.creador.split('@')[0] : 'Jugador';
    const tipoModo = partida.esPublico
        ? '🌐 *PÚBLICA* (Todo el chat puede participar)'
        : `🔒 *PRIVADA* (Solo @${creadorClean})`;

    let header = `🟩 *RobleBOT WORDLE* 🟩\n`;
    header += `━━━━━━━━━━━━━━━━━━━━━\n`;
    header += `🎮 *Modo:* ${tipoModo}\n`;
    header += `🎯 *Palabra de:* ${len} letras\n`;
    header += `👤 *Creador:* @${creadorClean}\n`;
    header += `🔢 *Intentos:* ${partida.intentos.length}/${maxIntentos}\n\n`;

    let footer = `\n🔡 *TECLADO DE LETRAS:*\n`;
    footer += `🟢 *Correctas:* ${teclado.correctas}\n`;
    footer += `🟡 *Otra posición:* ${teclado.presentes}\n`;
    footer += `❌ *Descartadas:* ${teclado.descartadas}\n\n`;

    if (estadoJuego === 'EN_PROGRESO') {
        footer += `💡 *¿Cómo responder?*\n`;
        footer += `• Responde a este mensaje con una palabra de *${len} letras*.\n`;
        footer += `• O escribe: *.wordle <palabra>*\n`;
        footer += `• Si deseas rendirte: *.wordle rendirse*`;
    }

    return `${header}${gridText}${footer}`;
}

// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 🔍 Obtener información completa del mensaje citado (Baileys multi-device / subbots)
function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

// 📞 Comparar JIDs normalizando el número de teléfono (ignora sufijo de dispositivo :N y dominios @)
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    // Normalización prefijo Argentina 549 → 54
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    // Coincidencia por sufijo (mínimo 8 dígitos)
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function esCitaValida(message, partida, quotedInfo = null) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    // En privados: siempre válido si hay partida activa
    if (!isGroup) return true;

    const qInfo = quotedInfo || obtenerQuotedInfo(message);
    const userId = message.author || message.from;

    if (qInfo.hasQuote) {
        // 1. Verificar por ID del mensaje
        if (qInfo.quotedId) {
            const ids = Array.isArray(partida.botMsgIds) ? partida.botMsgIds : [];
            if (partida.botMsgId) ids.push(partida.botMsgId);
            if (ids.includes(qInfo.quotedId)) return true;
        }

        // 2. Verificar por texto del tablero citado
        if (qInfo.quotedText && /wordle|teclado|🟩|🟨/i.test(qInfo.quotedText)) {
            return true;
        }

        // 3. Verificar si citó un mensaje enviado por un bot
        if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) {
            return true;
        }

        // 4. Si es partida privada del propio usuario
        if (!partida.esPublico && partida.creador && mismoNumero(partida.creador, userId)) {
            return true;
        }

        return false;
    }

    // Sin cita: permitir si es partida privada del propio usuario
    if (!partida.esPublico && partida.creador && mismoNumero(partida.creador, userId)) return true;

    return false;
}

// 🕹️ Buscar partida correspondiente para el usuario / chat
function buscarPartida(chatId, userId, quotedInfo = null) {
    cargarEstado();

    const qInfo = quotedInfo || {};

    // 1. Si citó un mensaje, buscar por ID de mensaje
    if (qInfo.quotedId) {
        for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
            const ids = Array.isArray(p.botMsgIds) ? p.botMsgIds : [];
            if (p.botMsgId) ids.push(p.botMsgId);
            if (ids.includes(qInfo.quotedId)) {
                return { key, partida: p };
            }
        }
    }

    // 2. Si citó un mensaje con texto de Wordle, buscar en el chat
    if (qInfo.quotedText && /wordle|teclado|🟩|🟨/i.test(qInfo.quotedText)) {
        // Primero buscar partida privada del usuario en este chat
        for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
            if (key.startsWith(chatId + ':') && mismoNumero(p.creador, userId)) {
                return { key, partida: p };
            }
        }
        // Luego pública
        if (estadoGlobal.partidas[chatId]) {
            return { key: chatId, partida: estadoGlobal.partidas[chatId] };
        }
    }

    // 3. Buscar partida privada del usuario en este chat por creador / clave
    const cleanUser = obtenerCleanUser(userId);
    const privateKey = `${chatId}:${cleanUser}`;
    if (estadoGlobal.partidas[privateKey]) {
        return { key: privateKey, partida: estadoGlobal.partidas[privateKey] };
    }
    for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
        if (key.startsWith(chatId + ':') && mismoNumero(p.creador, userId)) {
            return { key, partida: p };
        }
    }

    // 4. Buscar partida pública del chat
    const publicKey = chatId;
    if (estadoGlobal.partidas[publicKey]) {
        return { key: publicKey, partida: estadoGlobal.partidas[publicKey] };
    }

    return { key: null, partida: null };
}

// 🎮 Procesar intento de Wordle
async function procesarIntento(gameKey, partida, message, intentoBruto) {
    const intentoLimpio = limpiarTexto(intentoBruto);
    const sock = getSock(message);
    const chatId = message.from;
    const userId = message.author || message.from;

    if (!intentoLimpio) return;

    // Verificar si la partida es privada y pertenece a otro usuario
    if (!partida.esPublico && !mismoNumero(partida.creador, userId)) {
        const creadorClean = String(partida.creador).split('@')[0].split(':')[0];
        return await message.reply(
            `⚠️ Esta partida de Wordle es *PRIVADA* de @${creadorClean}.\n\n💡 Usa *.wordle* para crear tu propia partida privada o *.wordle publico* para iniciar una partida pública para todo el chat.`,
            { mentions: [partida.creador] }
        );
    }

    // Validación de longitud
    if (intentoLimpio.length !== partida.longitud) {
        return await message.reply(
            `⚠️ La palabra secreta tiene *${partida.longitud} letras*. Tu intento "*${intentoBruto.toUpperCase()}*" tiene ${intentoLimpio.length} letras.`
        );
    }

    // Evaluar intento
    const resEval = evaluarIntento(partida.palabraLimpia, intentoLimpio);
    partida.intentos.push({
        palabra: intentoLimpio,
        resultado: resEval,
        jugador: userId,
        fecha: Date.now()
    });

    const esVictoria = intentoLimpio === partida.palabraLimpia;
    const esFinIntentos = partida.intentos.length >= (partida.maxIntentos || 6);
    const userTag = String(userId).split('@')[0].split(':')[0];

    if (esVictoria) {
        const intentosUsados = partida.intentos.length;
        const basePremio = 1500;
        const bonusIntentos = (6 - intentosUsados) * 500;
        const bonusPerfecto = intentosUsados === 1 ? 2000 : 0;
        const premioTotal = basePremio + bonusIntentos + bonusPerfecto;

        // Actualizar estadísticas personales en database.json (global.db)
        actualizarStatsUser(userId, true, intentosUsados, premioTotal);
        const statsUser = obtenerStatsUser(userId);

        delete estadoGlobal.partidas[gameKey];
        guardarEstado();

        const tableroFinal = renderizarTablero(partida, 'VICTORIA');
        const mensajeVictoria = `${tableroFinal}\n\n🎉 *¡VICTORIA ESPECTACULAR!* @${userTag}\n\n✅ Palabra secreta: *${partida.palabra.toUpperCase()}*\n🎯 Adivinada en: *${intentosUsados}/${partida.maxIntentos}* intentos\n💰 Premio: *$${premioTotal.toLocaleString()}*\n🔥 Racha actual: *${statsUser.racha} victoria(s)*`;

        return await sock.sendMessage(chatId, {
            text: mensajeVictoria,
            mentions: [userId, partida.creador].filter(Boolean)
        });
    } else if (esFinIntentos) {
        // Enviar estadísticas de derrota a la DB para el jugador
        actualizarStatsUser(userId, false, partida.intentos.length, 0);

        delete estadoGlobal.partidas[gameKey];
        guardarEstado();

        const tableroFinal = renderizarTablero(partida, 'DERROTA');
        const mensajeDerrota = `${tableroFinal}\n\n💀 *¡GAME OVER!* Se agotaron los intentos.\n\n📖 La palabra correcta era: *${partida.palabra.toUpperCase()}*\n💡 Usa *.wordle* para volver a jugar.`;

        return await sock.sendMessage(chatId, {
            text: mensajeDerrota,
            mentions: [userId, partida.creador].filter(Boolean)
        });
    } else {
        // En progreso -> guardar y enviar tablero actualizado
        guardarEstado();
        const tableroActual = renderizarTablero(partida, 'EN_PROGRESO');
        const sent = await sock.sendMessage(chatId, {
            text: tableroActual,
            mentions: [partida.creador, userId].filter(Boolean)
        });

        if (sent?.key?.id) {
            partida.botMsgId = sent.key.id;
            if (!Array.isArray(partida.botMsgIds)) partida.botMsgIds = [];
            partida.botMsgIds.push(sent.key.id);
            guardarEstado();
        }
    }
}

// 🏗️ Construir entrada del ranking a partir de la data del usuario
function construirEntradaRanking(userKey, userData) {
    if (!userData) return null;
    const st = userData.wordle || {};
    const ganadas = st.ganadas || 0;
    if (ganadas <= 0) return null;

    const jugadas = st.jugadas || 0;
    const winRate = jugadas > 0 ? ((ganadas / jugadas) * 100).toFixed(1) : '0.0';
    const promedio = ganadas > 0 ? ((st.intentosTotales || 0) / ganadas).toFixed(1) : '0.0';

    const apodoRaw = (userData.apodo || '').trim();
    const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
        ? '👤 Sin Apodo'
        : apodoRaw;

    return {
        number: normalizeNumber(userKey),
        ganadas,
        jugadas,
        winRate,
        promedio,
        maxRacha: st.maxRacha || 0,
        monedasGanadas: st.monedasGanadas || 0,
        apodo
    };
}

// 🏆 Subcomando: Top / Ranking de jugadores (.wordle top | .wordle top g/global | + página)
async function mostrarTop(message, sock, argTokens) {
    try {
        if (!global.db?.data?.users) {
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        }

        const chatId = message.from;
        const userId = message.author || message.from;
        const currentUserNumber = normalizeNumber(userId);
        const isGroupChat = typeof chatId === 'string' && chatId.endsWith('@g.us');

        const isGlobal = argTokens[1] && /^(g|global)$/i.test(argTokens[1]);

        if (!isGlobal && !isGroupChat) {
            return await message.reply('❌ Este comando solo puede usarse en grupos.\n💡 Usa *.wordle top global* para ver el top mundial.');
        }

        let jugadores = [];

        if (isGlobal) {
            const aliases = global.db.data.aliases || {};
            const seenNumbers = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (aliases[userKey] && aliases[userKey] !== userKey) continue;
                const num = normalizeNumber(userKey);
                if (!num || seenNumbers.has(num)) continue;
                seenNumbers.add(num);
                const entrada = construirEntradaRanking(userKey, userData);
                if (entrada) jugadores.push(entrada);
            }
        } else {
            const participants = (await sock.groupMetadata(chatId)).participants.map(p => p.id);
            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                const userData = global.db.getUser(userNumber);
                const entrada = construirEntradaRanking(participant, userData);
                if (entrada) jugadores.push(entrada);
            }
        }

        if (jugadores.length === 0) {
            return await message.reply('📊 Todavía no hay jugadores con victorias en el ranking.');
        }

        // Ordenar por victorias (desempate: menor promedio de intentos = adivina más rápido)
        jugadores.sort((a, b) => b.ganadas - a.ganadas || parseFloat(a.promedio) - parseFloat(b.promedio));

        // ===== CALCULAR POSICIÓN GLOBAL SIEMPRE =====
        const jugadoresGlobal = [];
        {
            const _aliases = global.db.data.aliases || {};
            const _seen = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (_aliases[userKey] && _aliases[userKey] !== userKey) continue;
                const _num = normalizeNumber(userKey);
                if (!_num || _seen.has(_num)) continue;
                _seen.add(_num);
                const entrada = construirEntradaRanking(userKey, userData);
                if (entrada) jugadoresGlobal.push(entrada);
            }
        }
        jugadoresGlobal.sort((a, b) => b.ganadas - a.ganadas || parseFloat(a.promedio) - parseFloat(b.promedio));

        const itemsPerPage = 10;
        const globalPos = jugadoresGlobal.findIndex(u => u.number === currentUserNumber) + 1;
        const globalTotal = jugadoresGlobal.length;
        const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;
        // =============================================

        // Posición del usuario en la lista actual
        const userIndex = jugadores.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        // Paginación
        const totalPages = Math.max(1, Math.ceil(jugadores.length / itemsPerPage));
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        const pageArg = isGlobal ? argTokens[2] : argTokens[1];
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = jugadores.slice(start, end);

        // ===== CONSTRUIR MENSAJE =====
        let rankingText = isGlobal
            ? `*🌍 TOP WORDLE GLOBAL 🟩*\n\n`
            : `*🏆 TOP WORDLE DEL GRUPO 🟩*\n\n`;

        if (!isGlobal) {
            rankingText += `👥 *En este grupo:* ${jugadores.length} jugadores en el top\n`;
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = jugadores[userIndex];
                rankingText += `📍 *Tu pos. en el grupo:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *.wordle top ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. en el grupo:* No estás en el ranking\n`;
            }

            if (globalPos > 0) {
                rankingText += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                rankingText += `   ↳ Usa *.wordle top global ${globalUserPage}* para verlo\n`;
            } else {
                rankingText += `🌐 *Tu pos. global:* No estás en el ranking\n`;
            }

        } else {
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = jugadores[userIndex];
                rankingText += `📍 *Tu pos. global:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *.wordle top global ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. global:* No estás en el ranking\n`;
            }
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            const modeArg = isGlobal ? ' global' : '';

            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *.wordle top${modeArg} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *.wordle top${modeArg} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        // ===== LISTA DE JUGADORES =====
        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;

            let medal;
            if (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else medal = `${pos}.`;

            rankingText += `${medal} *${u.apodo}*\n`;
            rankingText += `🏆 Victorias: *${u.ganadas}*\n👌 Promedio: *${u.promedio}* intentos\n📈 % de victoria: *${u.winRate}%*\n\n`;
        });

        if (!isGlobal) {
            rankingText += `💡 _Usa *.wordle top global* para el top mundial_`;
        }

        await message.reply(rankingText);

    } catch (error) {
        console.error('[ERROR EN WORDLE TOP]:', error);
        await message.reply('⚠️ Error al obtener el top de Wordle.');
    }
}

// 🕹️ Handler del comando principal (.wordle)
async function handler(message, { text, conn }) {
    try {
        cargarEstado();
        const sock = conn || message._sock || global.conn;
        const chatId = message.from;
        const userId = message.author || message.from;
        const cleanUser = obtenerCleanUser(userId);
        const arg = (text || '').trim();
        const argLower = arg.toLowerCase();
        const argTokens = arg.split(/\s+/).filter(Boolean);

        // 🏆 Subcomando: Top / Ranking (.wordle top | .wordle top g/global | + página)
        if (argTokens[0] && argTokens[0].toLowerCase() === 'top') {
            return await mostrarTop(message, sock, argTokens);
        }

        // 🔄 Subcomando: Reload (solo owner)
        if (argLower === 'reload') {
            const ok = cargarPalabras();
            return await message.reply(
                ok
                    ? `✅ *Wordle:* Palabras recargadas desde palabras.json.\n📘 Total palabras válidas: ${palabras.length}`
                    : '❌ Error al recargar palabras.json'
            );
        }

        // 📊 Subcomando: Stats / Perfil
        if (argLower === 'stats' || argLower === 'perfil' || argLower === 'estadisticas') {
            const st = obtenerStatsUser(userId);
            const winRate = st.jugadas > 0 ? ((st.ganadas / st.jugadas) * 100).toFixed(1) : '0.0';
            const promIntentos = st.jugadas > 0 ? (st.intentosTotales / st.jugadas).toFixed(1) : '0.0';
            const userTag = userId.split('@')[0];

            const msgStats = `📊 *ESTADÍSTICAS WORDLE* 📊\n━━━━━━━━━━━━━━━━━━━━━\n👤 *Jugador:* @${userTag}\n\n🎮 *Partidas jugadas:* ${st.jugadas}\n🏆 *Victorias:* ${st.ganadas}\n💀 *Derrotas:* ${st.perdidas}\n📈 *Porcentaje de victorias:* ${winRate}%\n🎯 *Intentos totales probados:* ${st.intentosTotales}\n📊 *Promedio intentos / partida:* ${promIntentos}\n🔥 *Racha actual:* ${st.racha}\n⭐ *Mejor racha:* ${st.maxRacha}\n💰 *Total dinero ganado:* $${(st.monedasGanadas || 0).toLocaleString()}`;

            return await sock.sendMessage(chatId, {
                text: msgStats,
                mentions: [userId]
            });
        }

        // 🏳️ Subcomando: Rendirse
        if (argLower === 'rendirse' || argLower === 'rendirme' || argLower === 'surrender') {
            const { key: gameKey, partida: partidaActiva } = buscarPartida(chatId, userId);
            if (!partidaActiva) {
                return await message.reply('❌ No tienes ninguna partida de Wordle activa.');
            }

            if (!partidaActiva.esPublico && partidaActiva.creador !== userId) {
                return await message.reply('❌ No puedes rendirte en una partida privada de otro usuario.');
            }

            actualizarStatsUser(userId, false, partidaActiva.intentos.length, 0);
            const palabraCorrecta = partidaActiva.palabra.toUpperCase();
            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            return await message.reply(
                `🏳️ *¡TE HAS RENDIDO!*\n\n📖 La palabra secreta era: *${palabraCorrecta}*\n💡 Usa *.wordle* para iniciar un nuevo juego.`
            );
        }

        // ❓ Subcomando: Ayuda / Rules
        if (argLower === 'ayuda' || argLower === 'help' || argLower === 'reglas') {
            const msgHelp = `🟩 *¿CÓMO JUGAR WORDLE?* 🟩\n━━━━━━━━━━━━━━━━━━━━━\n\n🎯 *Objetivo:* Adivina la palabra secreta de 5 letras en 6 intentos.\n\n🔒 *Modos de juego:*\n• *.wordle* → Inicia una partida *PRIVADA* (solo tú puedes jugar).\n• *.wordle publico* → Inicia una partida *PÚBLICA* (todos en el chat pueden adivinar).\n\n*Otros comandos:*\n• *.wordle <palabra>* → Probar una palabra.\n• *.wordle rendirse* → Rendirse y ver la solución.\n• *.wordle stats* → Ver tus estadísticas guardadas en database.json.\n• *.wordle top* → Top de jugadores del grupo (o *.wordle top global* para el top mundial).\n\n*Significado de los emojis:*\n🟩 *Verde:* Letra en la posición correcta.\n🟨 *Amarillo:* Letra en la palabra pero en otra posición.\n⬛ *Gris:* Letra no presente en la palabra.`;
            return await message.reply(msgHelp);
        }

        // 💬 Si se proporciona una palabra como intento (ej. .wordle cielo)
        if (arg && arg.length >= 4 && arg.length <= 8 && !['iniciar', 'start', 'jugar', 'publico', 'public', 'grupo'].includes(argLower)) {
            const { key: gameKey, partida: partidaActiva } = buscarPartida(chatId, userId);
            if (!partidaActiva) {
                return await message.reply('❌ No hay ninguna partida activa. Usa *.wordle* para iniciar una nueva.');
            }
            return await procesarIntento(gameKey, partidaActiva, message, arg);
        }

        // 🎲 Decidir si es pública o privada
        const esCrearPublico = ['publico', 'public', 'grupo'].includes(argLower);
        const targetKey = esCrearPublico ? chatId : `${chatId}:${cleanUser}`;

        // Si ya existe la partida del modo solicitado -> Mostrar tablero actual
        if (estadoGlobal.partidas[targetKey]) {
            const partidaExistente = estadoGlobal.partidas[targetKey];
            const tablero = renderizarTablero(partidaExistente, 'EN_PROGRESO');
            const modoTxt = esCrearPublico ? 'pública en este chat' : 'privada activa';
            const sent = await sock.sendMessage(chatId, {
                text: `⚠️ *Ya tienes una partida ${modoTxt}:*\n\n${tablero}`,
                mentions: [partidaExistente.creador].filter(Boolean)
            });
            if (sent?.key?.id) {
                partidaExistente.botMsgId = sent.key.id;
                guardarEstado();
            }
            return;
        }

        // 🆕 Crear una nueva partida
        if (!palabras.length) cargarPalabras();
        if (!palabras.length) return await message.reply('❌ No hay palabras disponibles para jugar.');

        const palabras5 = palabras.filter(p => p.length === 5);
        const bancoElegido = palabras5.length >= 10 ? palabras5 : palabras;
        const palabraElegida = bancoElegido[Math.floor(Math.random() * bancoElegido.length)];
        const palabraLimpia = limpiarTexto(palabraElegida);

        const nuevaPartida = {
            palabra: palabraElegida,
            palabraLimpia: palabraLimpia,
            longitud: palabraLimpia.length,
            intentos: [],
            maxIntentos: 6,
            creador: userId,
            esPublico: esCrearPublico,
            tiempoInicio: Date.now(),
            botMsgId: null
        };

        estadoGlobal.partidas[targetKey] = nuevaPartida;
        guardarEstado();

        const tableroInicial = renderizarTablero(nuevaPartida, 'EN_PROGRESO');
        const sent = await message.reply(tableroInicial);

        if (sent?.key?.id) {
            nuevaPartida.botMsgId = sent.key.id;
            nuevaPartida.botMsgIds = [sent.key.id];
            guardarEstado();
        }

    } catch (err) {
        console.error('\x1b[31m[WORDLE HANDLER ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al procesar el comando Wordle.');
    }
}

// 💬 Manejador de respuestas de texto
async function textReplyHandler(message) {
    try {
        const chatId = message.from;
        const userId = message.author || message.from;
        const body = (message.body || '').trim();

        // Evitar procesar comandos que inicien con prefijo
        if (/^[./#❤️👅😎]/.test(body)) return;

        const quotedInfo = obtenerQuotedInfo(message);
        const { key: gameKey, partida } = buscarPartida(chatId, userId, quotedInfo);
        if (!partida) return;

        const isGroup = chatId.endsWith('@g.us');
        if (isGroup && !esCitaValida(message, partida, quotedInfo)) return;

        const textoLimpio = limpiarTexto(body);
        if (!textoLimpio) return;

        if (textoLimpio.length === partida.longitud) {
            await procesarIntento(gameKey, partida, message, textoLimpio);
        }

        // Actualizar historial de IDs del tablero tras cada intento
        // (ya se guarda en procesarIntento al enviar el nuevo tablero)
    } catch (err) {
        console.error('\x1b[31m[WORDLE TEXT REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(wordle|word)$/i,
    handler,
    textReplyHandler,
    help: '🎮 Juego de Wordle en español.\n• .wordle -> Iniciar partida privada personal.\n• .wordle publico -> Iniciar partida pública para todo el chat.\n• Responde al tablero o usa .wordle <palabra> para adivinar.\n• .wordle rendirse -> Rendirse y revelar la palabra.\n• .wordle stats -> Ver tus estadísticas personales.\n• .wordle top / .wordle top global -> Ver el ranking de jugadores (con páginas: .wordle top 2, .wordle top global 2).',
    tags: ['juegos', 'diversion']
};

module.exports.apodo = true;