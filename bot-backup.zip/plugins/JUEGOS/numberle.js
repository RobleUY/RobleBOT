const fs = require('fs');
const path = require('path');

// 📂 Ruta de archivo de partidas
const partidasPath = path.join(__dirname, 'numberle_partidas.json');

// 💾 Sistema de Persistencia
let estadoGlobal = {
    partidas: {}
};

function cargarEstado() {
    try {
        if (fs.existsSync(partidasPath)) {
            const rawData = fs.readFileSync(partidasPath, 'utf8');
            const data = JSON.parse(rawData);
            estadoGlobal.partidas = data.partidas || {};
        }
    } catch (err) {
        console.error('\x1b[31m[NUMBERLE] Error al leer numberle_partidas.json:', err.message, '\x1b[0m');
        estadoGlobal = { partidas: {} };
    }
}

function guardarEstado() {
    try {
        fs.writeFileSync(partidasPath, JSON.stringify(estadoGlobal, null, 2), 'utf8');
    } catch (err) {
        console.error('\x1b[31m[NUMBERLE] Error al guardar numberle_partidas.json:', err.message, '\x1b[0m');
    }
}

cargarEstado();

// 🆔 Limpiar ID de usuario
function obtenerCleanUser(sender) {
    if (!sender) return '';
    return String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

// 🔢 Normalizar número para ranking
function normalizeNumber(jidPart) {
    return String(jidPart || '').split('@')[0].replace(/[^0-9]/g, '').trim();
}

// 🎲 Generar número aleatorio de N dígitos (sin ceros iniciales, puede tener dígitos repetidos)
function generarNumeroAleatorio(longitud = 5) {
    let num = '';
    // El primer dígito no puede ser 0
    num += String(Math.floor(Math.random() * 9) + 1);
    for (let i = 1; i < longitud; i++) {
        num += String(Math.floor(Math.random() * 10));
    }
    return num;
}

// ✅ Validar que el intento sea un número puro de la longitud correcta
function esNumeroValido(str) {
    return /^\d+$/.test(str);
}

// 📊 Stats desde global.db
function obtenerStatsUser(userId) {
    let stats = {
        jugadas: 0,
        ganadas: 0,
        perdidas: 0,
        intentosTotales: 0,
        racha: 0,
        maxRacha: 0,
        monedasGanadas: 0
    };
    try {
        if (global.db) {
            const user = global.db.getUser(userId);
            if (user && user.numberle) {
                stats = { ...stats, ...user.numberle };
            }
        }
    } catch (e) {
        console.error('[NUMBERLE DB READ STATS ERROR]', e.message);
    }
    return stats;
}

function actualizarStatsUser(userId, esVictoria, intentosCount, premio = 0) {
    try {
        if (!global.db) return;
        let user = global.db.getUser(userId);
        if (!user) user = { money: 0 };

        if (!user.numberle) {
            user.numberle = {
                jugadas: 0,
                ganadas: 0,
                perdidas: 0,
                intentosTotales: 0,
                racha: 0,
                maxRacha: 0,
                monedasGanadas: 0
            };
        }

        const st = user.numberle;
        st.jugadas = (st.jugadas || 0) + 1;
        st.intentosTotales = (st.intentosTotales || 0) + intentosCount;

        if (esVictoria) {
            st.ganadas = (st.ganadas || 0) + 1;
            st.racha = (st.racha || 0) + 1;
            if (st.racha > (st.maxRacha || 0)) st.maxRacha = st.racha;
            st.monedasGanadas = (st.monedasGanadas || 0) + premio;
            user.money = (Number(user.money) || 0) + premio;
        } else {
            st.perdidas = (st.perdidas || 0) + 1;
            st.racha = 0;
        }

        global.db.setUser(userId, user);
        if (typeof global.db.save === 'function') global.db.save();
    } catch (e) {
        console.error('[NUMBERLE DB SAVE STATS ERROR]', e.message);
    }
}

// 🎯 Algoritmo de evaluación (mismo que Wordle: 2 pasadas para dígitos duplicados)
function evaluarIntento(secreto, intento) {
    const len = secreto.length;
    const resultado = new Array(len).fill('⬛');
    const conteoNoEmparejados = {};

    // Contar dígitos del secreto que NO son exactos
    for (let i = 0; i < len; i++) {
        if (intento[i] !== secreto[i]) {
            const d = secreto[i];
            conteoNoEmparejados[d] = (conteoNoEmparejados[d] || 0) + 1;
        }
    }

    // Paso 1: Verdes 🟩
    for (let i = 0; i < len; i++) {
        if (intento[i] === secreto[i]) {
            resultado[i] = '🟩';
        }
    }

    // Paso 2: Amarillos 🟨
    for (let i = 0; i < len; i++) {
        if (resultado[i] !== '🟩') {
            const d = intento[i];
            if (conteoNoEmparejados[d] && conteoNoEmparejados[d] > 0) {
                resultado[i] = '🟨';
                conteoNoEmparejados[d]--;
            }
        }
    }

    return resultado;
}

// 🔢 Estado del "teclado numérico" (0-9)
function obtenerEstadoNumerico(intentos) {
    const estadoDigitos = {};

    for (const item of intentos) {
        const num = item.numero;
        const res = item.resultado;
        for (let i = 0; i < num.length; i++) {
            const d = num[i];
            const emoji = res[i];
            if (emoji === '🟩') {
                estadoDigitos[d] = '🟩';
            } else if (emoji === '🟨') {
                if (estadoDigitos[d] !== '🟩') estadoDigitos[d] = '🟨';
            } else if (emoji === '⬛') {
                if (!estadoDigitos[d]) estadoDigitos[d] = '⬛';
            }
        }
    }

    const correctos = [];
    const presentes = [];
    const descartados = [];

    for (const [d, status] of Object.entries(estadoDigitos)) {
        if (status === '🟩') correctos.push(d);
        else if (status === '🟨') presentes.push(d);
        else if (status === '⬛') descartados.push(d);
    }

    return {
        correctos: correctos.sort().join(', ') || 'Ninguno',
        presentes: presentes.sort().join(', ') || 'Ninguno',
        descartados: descartados.sort().join(', ') || 'Ninguno'
    };
}

// 🎨 Renderizar tablero
function renderizarTablero(partida, estadoJuego = 'EN_PROGRESO') {
    const emojisNumeros = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];
    const maxIntentos = partida.maxIntentos || 6;
    const len = partida.longitud;
    let gridText = '';

    for (let i = 0; i < maxIntentos; i++) {
        const num = emojisNumeros[i] || `${i + 1}️⃣`;
        if (i < partida.intentos.length) {
            const item = partida.intentos[i];
            const bloques = item.resultado.join('');
            gridText += `${num} ${bloques} \`${item.numero}\`\n`;
        } else {
            const vacios = new Array(len).fill('⬛').join('');
            gridText += `${num} ${vacios}\n`;
        }
    }

    const estadoNum = obtenerEstadoNumerico(partida.intentos);
    const creadorClean = partida.creador ? partida.creador.split('@')[0] : 'Jugador';
    const modoIcon = partida.esPublico ? '🌐' : '🔒';

    let header = `� *NUMBERLE* ${modoIcon} @${creadorClean} — ${partida.intentos.length}/${maxIntentos}\n\n`;

    let footer = `\n🔢 *DÍGITOS:*\n`;
    footer += `🟢 *Correctos:* ${estadoNum.correctos}\n`;
    footer += `🟡 *Otra posición:* ${estadoNum.presentes}\n`;
    footer += `❌ *Descartados:* ${estadoNum.descartados}\n`;

    if (estadoJuego === 'EN_PROGRESO') {
        footer += `\n_Responde con un número de ${len} dígitos o_ *.numberle rendirse*`;
    }

    return `${header}${gridText}${footer}`;
}

// 🔍 Obtener ID del mensaje citado
function obtenerQuotedId(message) {
    const ctx = message._baileyMessage?.message?.contextInfo
        || message._baileyMessage?.message?.extendedTextMessage?.contextInfo
        || message._baileyMessage?.message?.extendedTextMessageV2?.contextInfo
        || message._baileyMessage?.message?.buttonsResponseMessage?.contextInfo
        || message._baileyMessage?.message?.listResponseMessage?.contextInfo
        || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
        || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
        || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
        || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
        || null;

    return message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;
}

function esCitaValida(message, partida) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    if (!isGroup) return true;

    const quotedId = obtenerQuotedId(message);
    if (!quotedId) return false;
    if (partida.botMsgId && quotedId === partida.botMsgId) return true;

    const ctx = message._baileyMessage?.message?.contextInfo
        || message._baileyMessage?.message?.extendedTextMessage?.contextInfo
        || message._baileyMessage?.message?.extendedTextMessageV2?.contextInfo
        || null;

    const quotedSender = message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const selfSender = message.author || message.from;
    const botJid = message._sock?.user?.id || message._sock?.user?.jid
        || global.conn?.user?.id || global.conn?.user?.jid || null;

    if (quotedSender && botJid && quotedSender === botJid) return true;
    if (!partida.botMsgId && quotedSender && quotedSender !== selfSender) return true;
    return false;
}

// 🕹️ Buscar partida activa
function buscarPartida(chatId, userId, quotedMsgId = null) {
    cargarEstado();

    if (quotedMsgId) {
        for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
            if (p.botMsgId && p.botMsgId === quotedMsgId) {
                return { key, partida: p };
            }
        }
    }

    const privateKey = `${chatId}:${obtenerCleanUser(userId)}`;
    if (estadoGlobal.partidas[privateKey]) {
        return { key: privateKey, partida: estadoGlobal.partidas[privateKey] };
    }

    const publicKey = chatId;
    if (estadoGlobal.partidas[publicKey]) {
        return { key: publicKey, partida: estadoGlobal.partidas[publicKey] };
    }

    return { key: null, partida: null };
}

// 🎮 Procesar intento
async function procesarIntento(gameKey, partida, message, intentoBruto) {
    const intento = String(intentoBruto).trim();
    const sock = message._sock || message.conn || global.conn;
    const chatId = message.from;
    const userId = message.author || message.from;

    if (!intento) return;

    // Verificar partida privada de otro usuario
    if (!partida.esPublico && partida.creador !== userId) {
        const creadorClean = partida.creador.split('@')[0];
        return await message.reply(
            `⚠️ Esta partida de Numberle es *PRIVADA* de @${creadorClean}.\n\n💡 Usa *.numberle* para crear tu propia partida privada o *.numberle publico* para iniciar una partida pública.`,
            { mentions: [partida.creador] }
        );
    }

    // Solo dígitos
    if (!esNumeroValido(intento)) {
        return await message.reply(`⚠️ Solo se aceptan *dígitos numéricos* (0-9). Ejemplo: \`${partida.secreto}\`.`);
    }

    // Validar longitud
    if (intento.length !== partida.longitud) {
        return await message.reply(
            `⚠️ El número secreto tiene *${partida.longitud} dígitos*. Tu intento "*${intento}*" tiene ${intento.length} dígito(s).`
        );
    }

    // Evaluar
    const resEval = evaluarIntento(partida.secreto, intento);
    partida.intentos.push({
        numero: intento,
        resultado: resEval,
        jugador: userId,
        fecha: Date.now()
    });

    const esVictoria = intento === partida.secreto;
    const esFinIntentos = partida.intentos.length >= (partida.maxIntentos || 6);
    const userTag = userId.split('@')[0];

    if (esVictoria) {
        const intentosUsados = partida.intentos.length;
        const basePremio = 1500;
        const bonusIntentos = (6 - intentosUsados) * 500;
        const bonusPerfecto = intentosUsados === 1 ? 2000 : 0;
        const premioTotal = basePremio + bonusIntentos + bonusPerfecto;

        actualizarStatsUser(userId, true, intentosUsados, premioTotal);
        const statsUser = obtenerStatsUser(userId);

        delete estadoGlobal.partidas[gameKey];
        guardarEstado();

        const tableroFinal = renderizarTablero(partida, 'VICTORIA');
        const mensajeVictoria = `${tableroFinal}\n\n🎉 *¡VICTORIA ESPECTACULAR!* @${userTag}\n\n✅ Número secreto: *${partida.secreto}*\n🎯 Adivinado en: *${intentosUsados}/${partida.maxIntentos}* intentos\n💰 Premio: *$${premioTotal.toLocaleString()}*\n🔥 Racha actual: *${statsUser.racha} victoria(s)*`;

        return await sock.sendMessage(chatId, {
            text: mensajeVictoria,
            mentions: [userId, partida.creador].filter(Boolean)
        });
    } else if (esFinIntentos) {
        actualizarStatsUser(userId, false, partida.intentos.length, 0);

        delete estadoGlobal.partidas[gameKey];
        guardarEstado();

        const tableroFinal = renderizarTablero(partida, 'DERROTA');
        const mensajeDerrota = `${tableroFinal}\n\n💀 *¡GAME OVER!* Se agotaron los intentos.\n\n🔢 El número correcto era: *${partida.secreto}*\n💡 Usa *.numberle* para volver a jugar.`;

        return await sock.sendMessage(chatId, {
            text: mensajeDerrota,
            mentions: [userId, partida.creador].filter(Boolean)
        });
    } else {
        guardarEstado();
        const tableroActual = renderizarTablero(partida, 'EN_PROGRESO');
        const sent = await sock.sendMessage(chatId, {
            text: tableroActual,
            mentions: [partida.creador, userId].filter(Boolean)
        });

        if (sent?.key?.id) {
            partida.botMsgId = sent.key.id;
            guardarEstado();
        }
    }
}

// 🏗️ Construir entrada del ranking
function construirEntradaRanking(userKey, userData) {
    if (!userData) return null;
    const st = userData.numberle || {};
    const ganadas = st.ganadas || 0;
    if (ganadas <= 0) return null;

    const jugadas = st.jugadas || 0;
    const winRate = jugadas > 0 ? ((ganadas / jugadas) * 100).toFixed(1) : '0.0';
    const promedio = ganadas > 0 ? ((st.intentosTotales || 0) / ganadas).toFixed(1) : '0.0';

    const apodoRaw = (userData.apodo || '').trim();
    const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
        ? '👤 Sin Apodo'
        : apodoRaw;

    return {
        number: normalizeNumber(userKey),
        ganadas,
        jugadas,
        winRate,
        promedio,
        maxRacha: st.maxRacha || 0,
        monedasGanadas: st.monedasGanadas || 0,
        apodo
    };
}

// 🏆 Subcomando: Top / Ranking
async function mostrarTop(message, sock, argTokens) {
    try {
        if (!global.db?.data?.users) {
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        }

        const chatId = message.from;
        const userId = message.author || message.from;
        const currentUserNumber = normalizeNumber(userId);
        const isGroupChat = typeof chatId === 'string' && chatId.endsWith('@g.us');

        const isGlobal = argTokens[1] && /^(g|global)$/i.test(argTokens[1]);

        if (!isGlobal && !isGroupChat) {
            return await message.reply('❌ Este comando solo puede usarse en grupos.\n💡 Usa *.numberle top global* para ver el top mundial.');
        }

        let jugadores = [];

        if (isGlobal) {
            const aliases = global.db.data.aliases || {};
            const seenNumbers = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (aliases[userKey] && aliases[userKey] !== userKey) continue;
                const num = normalizeNumber(userKey);
                if (!num || seenNumbers.has(num)) continue;
                seenNumbers.add(num);
                const entrada = construirEntradaRanking(userKey, userData);
                if (entrada) jugadores.push(entrada);
            }
        } else {
            const participants = (await sock.groupMetadata(chatId)).participants.map(p => p.id);
            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                const userData = global.db.getUser(userNumber);
                const entrada = construirEntradaRanking(participant, userData);
                if (entrada) jugadores.push(entrada);
            }
        }

        if (jugadores.length === 0) {
            return await message.reply('📊 Todavía no hay jugadores con victorias en el ranking.');
        }

        jugadores.sort((a, b) => b.ganadas - a.ganadas || parseFloat(a.promedio) - parseFloat(b.promedio));

        // Calcular posición global siempre
        const jugadoresGlobal = [];
        {
            const _aliases = global.db.data.aliases || {};
            const _seen = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (_aliases[userKey] && _aliases[userKey] !== userKey) continue;
                const _num = normalizeNumber(userKey);
                if (!_num || _seen.has(_num)) continue;
                _seen.add(_num);
                const entrada = construirEntradaRanking(userKey, userData);
                if (entrada) jugadoresGlobal.push(entrada);
            }
        }
        jugadoresGlobal.sort((a, b) => b.ganadas - a.ganadas || parseFloat(a.promedio) - parseFloat(b.promedio));

        const itemsPerPage = 10;
        const globalPos = jugadoresGlobal.findIndex(u => u.number === currentUserNumber) + 1;
        const globalTotal = jugadoresGlobal.length;
        const globalUserPage = globalPos > 0 ? Math.ceil(globalPos / itemsPerPage) : 0;

        const userIndex = jugadores.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;

        const totalPages = Math.max(1, Math.ceil(jugadores.length / itemsPerPage));
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let page = 1;
        const pageArg = isGlobal ? argTokens[2] : argTokens[1];
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, parseInt(pageArg));
        if (page > totalPages) page = totalPages;

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const pageUsers = jugadores.slice(start, end);

        let rankingText = isGlobal
            ? `*🌍 TOP NUMBERLE GLOBAL 🔢*\n\n`
            : `*🏆 TOP NUMBERLE DEL GRUPO 🔢*\n\n`;

        if (!isGlobal) {
            rankingText += `👥 *En este grupo:* ${jugadores.length} jugadores en el top\n`;
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = jugadores[userIndex];
                rankingText += `📍 *Tu pos. en el grupo:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *.numberle top ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. en el grupo:* No estás en el ranking\n`;
            }

            if (globalPos > 0) {
                rankingText += `🌐 *Tu pos. global:* #${globalPos} de ${globalTotal} (Pág. ${globalUserPage})\n`;
                rankingText += `   ↳ Usa *.numberle top global ${globalUserPage}* para verlo\n`;
            } else {
                rankingText += `🌐 *Tu pos. global:* No estás en el ranking\n`;
            }
        } else {
            rankingText += `🌍 *Global:* ${globalTotal} jugadores en el top\n\n`;

            if (userPosition > 0) {
                const cu = jugadores[userIndex];
                rankingText += `📍 *Tu pos. global:* #${userPosition} — *${cu.apodo}* (Pág. ${userPage})\n`;
                if (userPage !== page)
                    rankingText += `   ↳ Usa *.numberle top global ${userPage}* para ir a tu página\n`;
            } else {
                rankingText += `📍 *Tu pos. global:* No estás en el ranking\n`;
            }
        }

        rankingText += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const nextPage = page < totalPages ? page + 1 : null;
            const prevPage = page > 1 ? page - 1 : null;
            const modeArg = isGlobal ? ' global' : '';
            rankingText += `\n`;
            if (prevPage) rankingText += `⬅️ *.numberle top${modeArg} ${prevPage}* página anterior\n`;
            if (nextPage) rankingText += `➡️ *.numberle top${modeArg} ${nextPage}* siguiente página\n`;
        }

        rankingText += `\n`;

        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;
            let medal;
            if (pos === 1) medal = '🥇';
            else if (pos === 2) medal = '🥈';
            else if (pos === 3) medal = '🥉';
            else medal = `${pos}.`;

            rankingText += `${medal} *${u.apodo}*\n`;
            rankingText += `🏆 Victorias: *${u.ganadas}*\n👌 Promedio: *${u.promedio}* intentos\n📈 % de victoria: *${u.winRate}%*\n\n`;
        });

        if (!isGlobal) {
            rankingText += `💡 _Usa *.numberle top global* para el top mundial_`;
        }

        await message.reply(rankingText);

    } catch (error) {
        console.error('[ERROR EN NUMBERLE TOP]:', error);
        await message.reply('⚠️ Error al obtener el top de Numberle.');
    }
}

// 🕹️ Handler principal
async function handler(message, { text, conn }) {
    try {
        cargarEstado();
        const sock = conn || message._sock || global.conn;
        const chatId = message.from;
        const userId = message.author || message.from;
        const cleanUser = obtenerCleanUser(userId);
        const arg = (text || '').trim();
        const argLower = arg.toLowerCase();
        const argTokens = arg.split(/\s+/).filter(Boolean);

        // 🏆 Top / Ranking
        if (argTokens[0] && argTokens[0].toLowerCase() === 'top') {
            return await mostrarTop(message, sock, argTokens);
        }

        // 📊 Stats / Perfil
        if (argLower === 'stats' || argLower === 'perfil' || argLower === 'estadisticas') {
            const st = obtenerStatsUser(userId);
            const winRate = st.jugadas > 0 ? ((st.ganadas / st.jugadas) * 100).toFixed(1) : '0.0';
            const promIntentos = st.jugadas > 0 ? (st.intentosTotales / st.jugadas).toFixed(1) : '0.0';
            const userTag = userId.split('@')[0];

            const msgStats = `📊 *ESTADÍSTICAS NUMBERLE* 🔢\n━━━━━━━━━━━━━━━━━━━━━\n👤 *Jugador:* @${userTag}\n\n🎮 *Partidas jugadas:* ${st.jugadas}\n🏆 *Victorias:* ${st.ganadas}\n💀 *Derrotas:* ${st.perdidas}\n📈 *Porcentaje de victorias:* ${winRate}%\n🎯 *Intentos totales probados:* ${st.intentosTotales}\n📊 *Promedio intentos / partida:* ${promIntentos}\n🔥 *Racha actual:* ${st.racha}\n⭐ *Mejor racha:* ${st.maxRacha}\n💰 *Total dinero ganado:* $${(st.monedasGanadas || 0).toLocaleString()}`;

            return await sock.sendMessage(chatId, {
                text: msgStats,
                mentions: [userId]
            });
        }

        // 🏳️ Rendirse
        if (argLower === 'rendirse' || argLower === 'rendirme' || argLower === 'surrender') {
            const { key: gameKey, partida: partidaActiva } = buscarPartida(chatId, userId);
            if (!partidaActiva) {
                return await message.reply('❌ No tienes ninguna partida de Numberle activa.');
            }

            if (!partidaActiva.esPublico && partidaActiva.creador !== userId) {
                return await message.reply('❌ No puedes rendirte en una partida privada de otro usuario.');
            }

            actualizarStatsUser(userId, false, partidaActiva.intentos.length, 0);
            const numCorrecto = partidaActiva.secreto;
            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            return await message.reply(
                `🏳️ *¡TE HAS RENDIDO!*\n\n🔢 El número secreto era: *${numCorrecto}*\n💡 Usa *.numberle* para iniciar un nuevo juego.`
            );
        }

        // ❓ Ayuda / Reglas
        if (argLower === 'ayuda' || argLower === 'help' || argLower === 'reglas') {
            const msgHelp = `🔢 *¿CÓMO JUGAR NUMBERLE?* 🔢\n━━━━━━━━━━━━━━━━━━━━━\n\n🎯 *Objetivo:* Adivina el número secreto de 5 dígitos en 6 intentos.\nEl número puede contener dígitos del *0 al 9* (con posibles repetidos).\n\n🔒 *Modos de juego:*\n• *.numberle* → Inicia una partida *PRIVADA* (solo tú puedes jugar).\n• *.numberle publico* → Inicia una partida *PÚBLICA* (todos en el chat pueden adivinar).\n\n*Otros comandos:*\n• *.numberle <número>* → Probar un número de 5 dígitos.\n• *.numberle rendirse* → Rendirse y ver la solución.\n• *.numberle stats* → Ver tus estadísticas.\n• *.numberle top* → Top del grupo (o *.numberle top global*).\n\n*Significado de los emojis:*\n🟩 *Verde:* Dígito en la posición correcta.\n🟨 *Amarillo:* Dígito presente pero en otra posición.\n⬛ *Gris:* Dígito no presente en el número.\n\n*Ejemplo:* Número secreto \`40372\`\nIntento \`12345\` → ⬛ ⬛ 🟩 🟨 ⬛\n_(el 3 está en posición correcta, el 4 existe pero en otro lugar)_`;
            return await message.reply(msgHelp);
        }

        // 💬 Si se proporciona un número directamente (.numberle 12345)
        if (arg && esNumeroValido(arg) && arg.length >= 1) {
            const { key: gameKey, partida: partidaActiva } = buscarPartida(chatId, userId);
            if (!partidaActiva) {
                return await message.reply('❌ No hay ninguna partida activa. Usa *.numberle* para iniciar una nueva.');
            }
            return await procesarIntento(gameKey, partidaActiva, message, arg);
        }

        // 🎲 Decidir modo: privado o público
        const esCrearPublico = ['publico', 'public', 'grupo'].includes(argLower);
        const targetKey = esCrearPublico ? chatId : `${chatId}:${cleanUser}`;

        // Si ya existe partida del modo solicitado -> Mostrar tablero actual
        if (estadoGlobal.partidas[targetKey]) {
            const partidaExistente = estadoGlobal.partidas[targetKey];
            const tablero = renderizarTablero(partidaExistente, 'EN_PROGRESO');
            const modoTxt = esCrearPublico ? 'pública en este chat' : 'privada activa';
            const sent = await sock.sendMessage(chatId, {
                text: `⚠️ *Ya tienes una partida ${modoTxt}:*\n\n${tablero}`,
                mentions: [partidaExistente.creador].filter(Boolean)
            });
            if (sent?.key?.id) {
                partidaExistente.botMsgId = sent.key.id;
                guardarEstado();
            }
            return;
        }

        // 🆕 Crear nueva partida (siempre 5 dígitos)
        const secreto = generarNumeroAleatorio(5);

        const nuevaPartida = {
            secreto,
            longitud: secreto.length,
            intentos: [],
            maxIntentos: 6,
            creador: userId,
            esPublico: esCrearPublico,
            tiempoInicio: Date.now(),
            botMsgId: null
        };

        estadoGlobal.partidas[targetKey] = nuevaPartida;
        guardarEstado();

        const tableroInicial = renderizarTablero(nuevaPartida, 'EN_PROGRESO');
        const sent = await message.reply(tableroInicial);

        if (sent?.key?.id) {
            nuevaPartida.botMsgId = sent.key.id;
            guardarEstado();
        }

    } catch (err) {
        console.error('\x1b[31m[NUMBERLE HANDLER ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al procesar el comando Numberle.');
    }
}

// 💬 Manejador de respuestas de texto (responder al tablero)
async function textReplyHandler(message) {
    try {
        const chatId = message.from;
        const userId = message.author || message.from;
        const body = (message.body || '').trim();

        // Evitar procesar comandos con prefijo
        if (/^[./#❤️👅😎]/.test(body)) return;

        // Solo procesar si es un número puro
        if (!esNumeroValido(body)) return;

        const quotedId = obtenerQuotedId(message);
        const { key: gameKey, partida } = buscarPartida(chatId, userId, quotedId);
        if (!partida) return;

        const isGroup = chatId.endsWith('@g.us');
        if (isGroup && !esCitaValida(message, partida)) return;

        if (body.length === partida.longitud) {
            await procesarIntento(gameKey, partida, message, body);
        }
    } catch (err) {
        console.error('\x1b[31m[NUMBERLE TEXT REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(numberle|numle)$/i,
    handler,
    textReplyHandler,
    help: '🔢 Juego de Numberle — adivina el número secreto de 5 dígitos.\n• .numberle → Iniciar partida privada.\n• .numberle publico → Iniciar partida pública para todo el chat.\n• Responde al tablero o usa .numberle <número> para adivinar.\n• .numberle rendirse → Rendirse y revelar el número.\n• .numberle stats → Ver tus estadísticas.\n• .numberle top / .numberle top global → Ranking de jugadores.',
    tags: ['juegos', 'diversion']
};

module.exports.apodo = true;
