// 🧠 Juego: Adivina el Emoji
// Autor: RobleBOT ✨

const partidasActivas = new Map();

const TIEMPO_LIMITE = 15000; // 15s
const PREMIO_POR_SEGUNDO = 500;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// 🎯 Base de emojis con pistas ampliada (más de 100)
const listaEmojis = [
    // 🐾 Animales
    { emoji: "🐶", pista: "Animal doméstico que ladra" },
    { emoji: "🐱", pista: "Animal doméstico que maúlla" },
    { emoji: "🐭", pista: "Pequeño roedor amante del queso" },
    { emoji: "🐹", pista: "Roedor pequeño y tierno, vive en jaulas" },
    { emoji: "🐰", pista: "Animal con orejas largas que come zanahorias" },
    { emoji: "🦊", pista: "Animal astuto de color naranja" },
    { emoji: "🐻", pista: "Animal grande que hiberna" },
    { emoji: "🐼", pista: "Animal blanco y negro que come bambú" },
    { emoji: "🐨", pista: "Animal australiano que duerme en árboles" },
    { emoji: "🐯", pista: "Felino rayado y feroz" },
    { emoji: "🦁", pista: "Rey de la selva" },
    { emoji: "🐮", pista: "Animal que da leche" },
    { emoji: "🐷", pista: "Animal rosado que dice oink" },
    { emoji: "🐸", pista: "Animal verde que salta y croa" },
    { emoji: "🐵", pista: "Animal que sube árboles y come bananas" },
    { emoji: "🐔", pista: "Ave que pone huevos" },
    { emoji: "🦆", pista: "Ave que nada y dice cuac" },
    { emoji: "🦉", pista: "Ave nocturna que hace uuuh" },
    { emoji: "🐢", pista: "Animal lento con caparazón" },
    { emoji: "🐍", pista: "Reptil que se arrastra y sisea" },
    { emoji: "🦖", pista: "Dinosaurio carnívoro extinto" },
    { emoji: "🐠", pista: "Vive en el agua, tiene aletas" },
    { emoji: "🐙", pista: "Animal marino con ocho brazos" },
    { emoji: "🦈", pista: "Gran depredador del mar" },

    // 🍔 Comida y bebida
    { emoji: "🍎", pista: "Fruta roja o verde que crece en árboles" },
    { emoji: "🍌", pista: "Fruta amarilla favorita de los monos" },
    { emoji: "🍇", pista: "Fruta en racimo, usada para vino" },
    { emoji: "🍉", pista: "Fruta roja con semillas negras y cáscara verde" },
    { emoji: "🍓", pista: "Fruta roja pequeña con puntitos" },
    { emoji: "🍒", pista: "Fruta roja y pequeña, suelen venir en pares" },
    { emoji: "🍍", pista: "Fruta tropical con corona" },
    { emoji: "🥭", pista: "Fruta amarilla tropical con carozo" },
    { emoji: "🥑", pista: "Fruta verde cremosa, base del guacamole" },
    { emoji: "🍕", pista: "Comida italiana con queso y salsa" },
    { emoji: "🍔", pista: "Comida rápida con carne, pan y queso" },
    { emoji: "🌭", pista: "Comida con pan y salchicha" },
    { emoji: "🍟", pista: "Acompañan hamburguesas, se fríen en aceite" },
    { emoji: "🍿", pista: "Se come viendo películas" },
    { emoji: "🍰", pista: "Postre de cumpleaños" },
    { emoji: "🍩", pista: "Rosquilla dulce con glaseado" },
    { emoji: "🍪", pista: "Galleta con chispas de chocolate" },
    { emoji: "🍫", pista: "Dulce marrón hecho de cacao" },
    { emoji: "🍭", pista: "Dulce en forma de palo" },
    { emoji: "☕", pista: "Bebida caliente que despierta" },
    { emoji: "🥤", pista: "Bebida con sorbete" },
    { emoji: "🍺", pista: "Bebida alcohólica dorada y espumosa" },
    { emoji: "🍷", pista: "Bebida roja servida en copa" },

    // 💬 Emociones y personas
    { emoji: "😀", pista: "Cara sonriente feliz" },
    { emoji: "😂", pista: "Cara riéndose con lágrimas" },
    { emoji: "😍", pista: "Cara con ojos de corazón" },
    { emoji: "😎", pista: "Cara con gafas de sol" },
    { emoji: "🤔", pista: "Cara pensando" },
    { emoji: "😡", pista: "Cara muy enojada" },
    { emoji: "😭", pista: "Cara llorando mucho" },
    { emoji: "😱", pista: "Cara de terror o sorpresa" },
    { emoji: "😴", pista: "Cara durmiendo" },
    { emoji: "🤢", pista: "Cara con náuseas" },
    { emoji: "😈", pista: "Cara con cuernos morados" },
    { emoji: "👻", pista: "Espíritu blanco con cara divertida" },
    { emoji: "💀", pista: "Símbolo de muerte o peligro" },
    { emoji: "👽", pista: "Ser verde del espacio" },
    { emoji: "🤡", pista: "Personaje de circo con nariz roja" },
    { emoji: "💩", pista: "Emoji marrón muy usado en bromas" },

    // 🌳 Naturaleza y clima
    { emoji: "🌳", pista: "Da sombra y tiene hojas" },
    { emoji: "🌵", pista: "Planta del desierto con espinas" },
    { emoji: "🌸", pista: "Flor rosada del cerezo" },
    { emoji: "🌹", pista: "Flor roja del amor" },
    { emoji: "🍀", pista: "Símbolo de buena suerte" },
    { emoji: "🔥", pista: "Algo muy caliente o que arde" },
    { emoji: "💧", pista: "Cae del cielo cuando llueve" },
    { emoji: "🌈", pista: "Aparece después de la lluvia con muchos colores" },
    { emoji: "☀️", pista: "Brilla en el cielo durante el día" },
    { emoji: "🌙", pista: "Se ve de noche en el cielo" },
    { emoji: "⭐", pista: "Brilla en el cielo de noche" },
    { emoji: "⛄", pista: "Muñeco hecho de nieve" },
    { emoji: "🌪️", pista: "Fenómeno natural giratorio y destructivo" },

    // 🚗 Objetos y transporte
    { emoji: "🚗", pista: "Vehículo con cuatro ruedas" },
    { emoji: "🚕", pista: "Auto amarillo que transporta pasajeros" },
    { emoji: "🏍️", pista: "Vehículo de dos ruedas con motor" },
    { emoji: "✈️", pista: "Vuela en el cielo transportando personas" },
    { emoji: "🚀", pista: "Vehículo que va al espacio" },
    { emoji: "🚲", pista: "Vehículo de dos ruedas sin motor" },
    { emoji: "🚢", pista: "Medio de transporte acuático grande" },
    { emoji: "⛵", pista: "Barco con vela" },
    { emoji: "🚓", pista: "Vehículo usado por la policía" },
    { emoji: "🚌", pista: "Transporte urbano grande" },
    { emoji: "🚑", pista: "Vehículo de emergencia médica" },

    // 💎 Objetos
    { emoji: "💡", pista: "Objeto que da luz" },
    { emoji: "🔑", pista: "Sirve para abrir cerraduras" },
    { emoji: "🧭", pista: "Indica direcciones" },
    { emoji: "📱", pista: "Dispositivo con pantalla táctil" },
    { emoji: "💻", pista: "Herramienta para programar" },
    { emoji: "⌚", pista: "Objeto que indica la hora" },
    { emoji: "🎁", pista: "Lo das en cumpleaños o navidad" },
    { emoji: "💣", pista: "Explota" },
    { emoji: "🧨", pista: "Explosivo usado en celebraciones chinas" },
    { emoji: "🔮", pista: "Usado por adivinos" },
    { emoji: "💎", pista: "Piedra preciosa brillante" },
    { emoji: "🧸", pista: "Juguete tierno de peluche" },

    // 🏳️ Banderas
    { emoji: "🇺🇾", pista: "País pequeño de Sudamérica" },
    { emoji: "🇦🇷", pista: "País de Messi y Maradona" },
    { emoji: "🇧🇷", pista: "País de samba y carnaval" },
    { emoji: "🇲🇽", pista: "País del taco y el mariachi" },
    { emoji: "🇪🇸", pista: "País europeo del flamenco y la paella" },
    { emoji: "🇯🇵", pista: "País del sol naciente" },
    { emoji: "🇨🇳", pista: "País más poblado del mundo" },
    { emoji: "🇺🇸", pista: "País con la estatua de la libertad" },
    { emoji: "🇫🇷", pista: "País de la Torre Eiffel" },
    { emoji: "🇮🇹", pista: "País de la pizza y el Coliseo" }
];

// 🎮 Comando principal
async function handler(message, { text }) {
    try {
        console.log('\x1b[33m[EMOJI] Comando ejecutado\x1b[0m');

        if (!message.from.endsWith('@g.us'))
            return await message.reply('❌ Este comando solo funciona en grupos.');

        const chatId = message.from;
        if (partidasActivas.has(chatId))
            return await message.reply('❌ Ya hay una partida activa, espera a que termine.');

        const elegido = listaEmojis[Math.floor(Math.random() * listaEmojis.length)];

        const mensaje = `🤔 *ADIVINA EL EMOJI*\n\n💬 Pista: ${elegido.pista}\n\n⏱️ Tienes ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;
        await message.reply(mensaje);

        const partida = {
            emoji: elegido.emoji,
            tiempoInicio: Date.now(),
            timeout: null,
        };

        partidasActivas.set(chatId, partida);

        partida.timeout = setTimeout(async () => {
            const activa = partidasActivas.get(chatId);
            if (!activa) return;
            partidasActivas.delete(chatId);

            await global.conn.sendMessage(chatId, {
                text: `⏰ *¡TIEMPO AGOTADO!*\n\nEl emoji correcto era: ${activa.emoji}\n💡 Usa /emoji para jugar de nuevo.`,
            });
        }, TIEMPO_LIMITE);
    } catch (err) {
        console.error('\x1b[31m[EMOJI ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al iniciar el juego.');
    }
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
    try {
        if (!message.from.endsWith('@g.us')) return;

        const chatId = message.from;
        const partida = partidasActivas.get(chatId);
        if (!partida) return;

        const respuesta = message.body?.trim();
        if (!respuesta) return;

        // Se espera que el jugador envíe solo el emoji correcto
        const esCorrecta = respuesta === partida.emoji;
        const tiempoTranscurrido = Date.now() - partida.tiempoInicio;

        if (esCorrecta && tiempoTranscurrido <= TIEMPO_LIMITE) {
            const tiempoRestante = Math.max(0, (TIEMPO_LIMITE - tiempoTranscurrido) / 1000);
            const premio = Math.max(500, Math.floor(tiempoRestante * PREMIO_POR_SEGUNDO));

            // 💰 Lógica de base de datos ajustada para ser idéntica a los otros juegos
            try {
                const winnerJid = message.author || message.from;

                // 1) Cargar datos del usuario
                let user = global.db.getUser(winnerJid);
                if (!user) {
                    user = { money: 0 }; 
                }
                
                // 2) Actualizar dinero
                user.money = Number(user.money) || 0;
                user.money += premio;
                
                // 3) Guardar los cambios
                global.db.setUser(winnerJid, user);

            } catch (e) {
                console.error('\x1b[31m[EMOJI DB ERROR]\x1b[0m', e.message);
            }

            clearTimeout(partida.timeout);
            partidasActivas.delete(chatId);

            const ganador = (message.author || message.from).split('@')[0];
            await global.conn.sendMessage(chatId, {
                text: `🎉 *¡CORRECTO!* @${ganador}\n\nEmoji: ${partida.emoji}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s\n💰 Premio: $${premio.toLocaleString()}`,
                mentions: [message.author || message.from],
            });
        } else if (!esCorrecta && tiempoTranscurrido <= TIEMPO_LIMITE) {
            await message.reply(`❌ *Incorrecto*, intenta otra vez.`);
        }
    } catch (err) {
        console.error('\x1b[31m[EMOJI REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(emoji|adivinaemoji)$/i,
    handler,
    textReplyHandler,
    help: 'Juego de adivinar emojis.\n• Escribe /emoji para comenzar.\n• Responde con el emoji correcto.\n• Tienes 15s.\n• Premio máximo: $7.500.',
    tags: ['diversion', 'juegos'],
};

// Se agrega la propiedad group: true al módulo
module.exports.group = true;