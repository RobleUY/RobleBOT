// 🎭 Juego: Describe los Emojis
// Autor: RobleBOT ✨
// 🧠 Usa Groq (llama-3.3-70b) para analizar si la descripción del jugador tiene el mismo sentido que la frase oficial
// 🌍 Optimizado para respuestas profundas y contextuales

const axios = require('axios');
const partidasDescribe = new Map();

// ⚙️ Configuración general
const TIEMPO_LIMITE = 20000; // 20s
const PREMIO_POR_SEGUNDO = 50;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// 🔑 Configuración de API Groq (misma que ia.js)
const HARDCODED_FALLBACK_KEY = process.env.GROQ_API_KEY || process.env.groq_api_key || "";
const API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama-3.3-70b-versatile";
const TIMEOUT = 10000;

// 🎨 Base de emojis y respuestas oficiales
const baseEmojis = [
  // 👨‍🍳 Cocina
  { emojis: "👨‍🍳🍕", respuesta: "Un chef cocinando una pizza" },
  { emojis: "👩‍🍳🍔", respuesta: "Una cocinera preparando una hamburguesa" },
  { emojis: "🍳🥓", respuesta: "Desayuno con huevos y panceta" },
  { emojis: "🍰🎂", respuesta: "Alguien horneando o celebrando con torta" },
  { emojis: "🍽️🍷", respuesta: "Una cena elegante" },

  // 🐶 Animales
  { emojis: "🐶🚶‍♂️", respuesta: "Una persona paseando a su perro" },
  { emojis: "🐱🛏️", respuesta: "Un gato durmiendo" },
  { emojis: "🐦🎶", respuesta: "Un pájaro cantando" },
  { emojis: "🐠🌊", respuesta: "Un pez nadando en el mar" },
  { emojis: "🐴🏇", respuesta: "Alguien montando a caballo" },

  // 🚗 Transporte
  { emojis: "🚗💨", respuesta: "Un auto yendo rápido" },
  { emojis: "🚲👧", respuesta: "Una niña andando en bicicleta" },
  { emojis: "🚛📦", respuesta: "Un camión transportando paquetes" },
  { emojis: "🛫🌍", respuesta: "Un avión viajando por el mundo" },
  { emojis: "🚀🪐", respuesta: "Un cohete viajando al espacio" },

  // 🎓 Educación y trabajo
  { emojis: "🧑‍🏫📚", respuesta: "Un profesor enseñando" },
  { emojis: "🎓👩‍🎓", respuesta: "Una persona graduándose" },
  { emojis: "💻☕", respuesta: "Un programador trabajando" },
  { emojis: "🧑‍💻💡", respuesta: "Un programador teniendo una idea" },
  { emojis: "📖🕯️", respuesta: "Alguien leyendo de noche" },

  // ⚽ Deportes
  { emojis: "⚽🥅", respuesta: "Un jugador de fútbol pateando al arco" },
  { emojis: "🏀🏆", respuesta: "Un equipo ganando un torneo de baloncesto" },
  { emojis: "🏊‍♂️🏅", respuesta: "Un nadador ganando una medalla" },
  { emojis: "🏃‍♂️💨", respuesta: "Alguien corriendo rápido" },
  { emojis: "🥋👊", respuesta: "Alguien practicando artes marciales" },

  // ❤️ Familia y amor
  { emojis: "👨‍👩‍👧‍👦❤️", respuesta: "Una familia feliz" },
  { emojis: "👰🤵💍", respuesta: "Una boda o casamiento" },
  { emojis: "💌💕", respuesta: "Alguien enviando una carta de amor" },
  { emojis: "🌹💘", respuesta: "Un gesto romántico con flores" },
  { emojis: "👶🍼", respuesta: "Un bebé tomando leche" },

  // 🎮 Diversión
  { emojis: "🎮🕹️", respuesta: "Alguien jugando videojuegos" },
  { emojis: "🎬📽️", respuesta: "Grabando una película" },
  { emojis: "🎤🎶", respuesta: "Cantando o dando un concierto" },
  { emojis: "🎡🎢", respuesta: "Diversión en un parque de atracciones" },
  { emojis: "🪩💃", respuesta: "Gente bailando en una fiesta" },

  // 🌍 Lugares y viajes
  { emojis: "🏖️🌞", respuesta: "Vacaciones en la playa" },
  { emojis: "🏔️🎿", respuesta: "Esquiando en la montaña" },
  { emojis: "🏙️🌃", respuesta: "Una gran ciudad de noche" },
  { emojis: "🏕️🔥", respuesta: "Acampando al aire libre" },
  { emojis: "🏰👸", respuesta: "Una princesa en un castillo" },

  // 🧙 Fantasía y ficción
  { emojis: "🧙‍♂️✨", respuesta: "Un mago lanzando un hechizo" },
  { emojis: "🧛‍♀️🩸", respuesta: "Una vampiresa" },
  { emojis: "🦸‍♂️💥", respuesta: "Un superhéroe en acción" },
  { emojis: "👽🚀", respuesta: "Un extraterrestre viajando en una nave" },
  { emojis: "🐉🔥", respuesta: "Un dragón lanzando fuego" },

  // 🕵️ Misterio y acción
  { emojis: "🕵️‍♂️🔍", respuesta: "Un detective buscando pistas" },
  { emojis: "🔫🕶️", respuesta: "Un espía o agente secreto" },
  { emojis: "💣💥", respuesta: "Una explosión" },
  { emojis: "🚔👮‍♂️", respuesta: "Policías persiguiendo a alguien" },
  { emojis: "🧨🎆", respuesta: "Fuegos artificiales en el cielo" },
];

// 🤖 Validar con Groq si la descripción tiene el mismo sentido
async function validarConGroq(descripcionJugador, descripcionOficial) {
  try {
    const prompt = `Eres un experto en validación de descripciones de emojis. Tu trabajo es verificar si una descripción del usuario captura la ESENCIA de lo que representan los emojis.

REGLAS IMPORTANTES:
- Acepta cualquier descripción que capture la idea general/concepto principal
- Ignora pequeñas diferencias, typos, orden de palabras o detalles menores
- Acepta si el jugador describe el concepto correcto aunque le falten detalles
- Rechaza SOLO si la descripción describe algo completamente diferente

Descripción oficial (referencia): "${descripcionOficial}"
Descripción del jugador: "${descripcionJugador}"

Responde ÚNICAMENTE con SI o NO. Sin explicaciones.`;

    const envKeys = (function collectKeys() {
      const keys = new Set();
      const variations = [
        'groq_api_key', 'GROQ_API_KEY',
        'groq_api_key1', 'GROQ_API_KEY1',
        'groq_api_key2', 'GROQ_API_KEY2',
        'groq_api_key3', 'GROQ_API_KEY3',
        'groq_api_key4', 'GROQ_API_KEY4'
      ];
      for (const name of variations) {
        const v = process.env[name];
        if (v && v.trim()) keys.add(v.trim());
      }
      if (keys.size === 0 && HARDCODED_FALLBACK_KEY) keys.add(HARDCODED_FALLBACK_KEY);
      return Array.from(keys);
    })();

    let lastErr = null;
    for (let i = 0; i < envKeys.length; i++) {
      const key = envKeys[i];
      try {
        const res = await axios.post(API_URL, {
          model: MODEL,
          messages: [
            { role: 'system', content: 'Eres un validador justo y flexible. Validas si una descripción captura la esencia de los emojis, no la exactitud palabra por palabra.' },
            { role: 'user', content: prompt }
          ],
          temperature: 0.2,
          max_tokens: 5
        }, {
          headers: {
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
          },
          timeout: TIMEOUT
        });

        const texto = res.data?.choices?.[0]?.message?.content?.toUpperCase()?.trim() || "";
        return texto.startsWith("SI");
      } catch (err) {
        lastErr = err;
        const status = err.response?.status;
        const apiErrCode = err.response?.data?.error?.code;
        console.log(`[DESCRIBE] ⚠️ Key ${i + 1} failed (status=${status} code=${apiErrCode}). Trying next key.`);
        if (i === envKeys.length - 1) throw err;
        if (status && ![401,403,429].includes(status) && apiErrCode !== 'rate_limit_exceeded') throw err;
      }
    }
    if (lastErr) throw lastErr;
    return false;
  } catch (err) {
    console.error("[DESCRIBE GROQ ERROR]", err.message);
    return false;
  }
}

// 🎮 Comando principal: /describe
async function handler(message, { text, conn }) {
  try {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;
    if (partidasDescribe.has(chatId))
      return await message.reply('⚠️ Ya hay una partida activa. Espera a que termine.');

    const elegido = baseEmojis[Math.floor(Math.random() * baseEmojis.length)];

    const textoMensaje = `🎭 *JUEGO: Describe lo que ves*\n\n🧩 Observa estos emojis:\n${elegido.emojis}\n\n💬 *Cita (responde) este mensaje* con tu descripción.\nEjemplo: "Un chef cocinando una pizza"\n⏱️ Tiempo: ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;

    const botMsg = await message.reply(textoMensaje);
    const botMsgId = botMsg?.key?.id || botMsg?.id || null;

    const partida = {
      respuestaOficial: elegido.respuesta,
      tiempoInicio: Date.now(),
      timeout: null,
      messageInicial: message,
      botMsgId,
    };

    partidasDescribe.set(chatId, partida);

    partida.timeout = setTimeout(async () => {
      const activa = partidasDescribe.get(chatId);
      if (!activa) return;
      partidasDescribe.delete(chatId);
      await activa.messageInicial.reply(`⏰ *¡Tiempo agotado!*\n\nLa descripción correcta era:\n👉 "${activa.respuestaOficial}"\n\nUsa /describe para jugar otra vez.`);
    }, TIEMPO_LIMITE);
  } catch (err) {
    console.error('[DESCRIBE ERROR]', err);
    await message.reply('❌ Ocurrió un error al iniciar el juego.');
  }
}

// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
  if (message?._sock?.user) return message._sock;
  if (message?.conn?.user) return message.conn;
  if (global.conn?.user) return global.conn;
  if (Array.isArray(global.subConns)) {
    const active = global.subConns.find(c => c?.user);
    if (active) return active;
  }
  return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
  if (!jid) return false;
  const candidates = [];
  const currentSock = getSock(message);
  if (currentSock?.user) {
    if (currentSock.user.id) candidates.push(currentSock.user.id);
    if (currentSock.user.jid) candidates.push(currentSock.user.jid);
  }
  if (global.conn?.user) {
    if (global.conn.user.id) candidates.push(global.conn.user.id);
    if (global.conn.user.jid) candidates.push(global.conn.user.jid);
  }
  if (Array.isArray(global.subConns)) {
    for (const sc of global.subConns) {
      if (sc?.user) {
        if (sc.user.id) candidates.push(sc.user.id);
        if (sc.user.jid) candidates.push(sc.user.jid);
      }
    }
  }
  return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
  if (!jidA || !jidB) return false;
  const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
  const a = limpia(jidA);
  const b = limpia(jidB);
  if (!a || !b) return false;
  if (a === b) return true;
  const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
  if (norm(a) === norm(b)) return true;
  if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
  return false;
}

function obtenerQuotedInfo(message) {
  const baileyMsg = message._baileyMessage;
  const allCtx = [
    baileyMsg?.message?.contextInfo,
    baileyMsg?.message?.extendedTextMessage?.contextInfo,
    baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
    baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
    baileyMsg?.message?.listResponseMessage?.contextInfo,
    baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
    baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
    baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
    baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
    baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
    baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
  ];
  const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

  const quotedId = message.quoted?.key?.id
    || message.quoted?.id
    || message._data?.quotedMsg?.key?.id
    || message._data?.quotedMsg?.id
    || ctx?.quotedMessage?.key?.id
    || ctx?.quotedMessage?.id
    || ctx?.stanzaId
    || null;

  const quotedSender = message.quoted?.key?.participant
    || message.quoted?.sender
    || message._data?.quotedMsg?.sender
    || ctx?.participant
    || null;

  const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
  let quotedText = '';
  if (quotedMsgObj) {
    quotedText = quotedMsgObj.conversation
      || quotedMsgObj.extendedTextMessage?.text
      || quotedMsgObj.extendedTextMessageV2?.text
      || quotedMsgObj.imageMessage?.caption
      || quotedMsgObj.videoMessage?.caption
      || '';
  }

  const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

  return {
    quotedId,
    quotedSender,
    quotedText,
    isFromMe,
    hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
  };
}

function esCitaValida(message, partida) {
  const isGroup = message.from?.endsWith('@g.us');
  if (message.key?.fromMe) return true;
  if (!isGroup) return true;

  const qInfo = obtenerQuotedInfo(message);
  if (!qInfo.hasQuote) return false;

  if (partida.botMsgId && qInfo.quotedId && qInfo.quotedId === partida.botMsgId) return true;
  if (qInfo.quotedText && /describir|describe|adivina el personaje/i.test(qInfo.quotedText)) return true;
  if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) return true;

  return false;
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
  try {
    if (!message.from) return;
    const chatId = message.from;
    const isGroup = chatId.endsWith('@g.us');
    const partida = partidasDescribe.get(chatId);
    if (!partida) return;

    // En grupo solo procesar si la respuesta cita el mensaje del bot
    if (isGroup && !esCitaValida(message, partida)) return;

    const respuestaJugador = message.body?.trim();
    if (!respuestaJugador) return;

    const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
    if (tiempoTranscurrido > TIEMPO_LIMITE) return;

    const esCorrecta = await validarConGroq(respuestaJugador, partida.respuestaOficial);

    if (esCorrecta) {
      const tiempoRestante = Math.max(0, (TIEMPO_LIMITE - tiempoTranscurrido) / 1000);
      const premio = Math.max(500, Math.floor(tiempoRestante * PREMIO_POR_SEGUNDO));

      try {
        const winnerJid = message.author || message.from;
        let user = global.db.getUser(winnerJid);
        if (!user) user = { money: 0 };
        user.money = Number(user.money) || 0;
        user.money += premio;
        global.db.setUser(winnerJid, user);
      } catch (e) {
        console.error('\x1b[31m[DESCRIBE DB ERROR]\x1b[0m', e.message);
      }

      clearTimeout(partida.timeout);
      partidasDescribe.delete(chatId);

      const ganador = (message.author || message.from).split('@')[0];
      await message.reply(`✅ *¡Correcto!* @${ganador}\n\nTu descripción tiene sentido con:\n👉 "${partida.respuestaOficial}"\n\n💰 Premio: $${premio.toLocaleString()}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s`, {
        mentions: [message.author || message.from]
      });
    } else {
      await message.reply("❌ Tu descripción no coincide con lo que representan los emojis. Intenta con otra frase antes de que se acabe el tiempo.");
    }
  } catch (err) {
    console.error('[DESCRIBE REPLY ERROR]', err);
  }
}

// 📦 Exportación del comando
module.exports = {
  command: /^(describe|describir)$/i,
  handler,
  textReplyHandler,
  help: '🎭 Juego de emojis con IA.\n• Escribe /describe para comenzar.\n• Cita el mensaje del bot con tu descripción.\n• 20 segundos por ronda.\n• La IA analiza si tu respuesta tiene sentido.\n• ¡Gana dinero virtual si aciertas rápido!',
  tags: ['diversion', 'juegos', 'ia'],
};

module.exports.group = true;