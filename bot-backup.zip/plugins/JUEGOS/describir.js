// 🎭 Juego: Describe los Emojis
// Autor: RobleBOT ✨
// 🧠 Usa Groq (llama-3.3-70b) para analizar si la descripción del jugador tiene el mismo sentido que la frase oficial
// 🌍 Optimizado para respuestas profundas y contextuales

const axios = require('axios');
const partidasDescribe = new Map();

// ⚙️ Configuración general
const TIEMPO_LIMITE = 20000; // 20s
const PREMIO_POR_SEGUNDO = 400;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// 🔑 Configuración de API Groq (misma que ia.js)
const API_KEY = "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";
const API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama-3.3-70b-versatile";
const TIMEOUT = 10000;

// 🎨 Base de emojis y respuestas oficiales
const baseEmojis = [
  // 👨‍🍳 Cocina
  { emojis: "👨‍🍳🍕", respuesta: "Un chef cocinando una pizza" },
  { emojis: "👩‍🍳🍔", respuesta: "Una cocinera preparando una hamburguesa" },
  { emojis: "🍳🥓", respuesta: "Desayuno con huevos y panceta" },
  { emojis: "🍰🎂", respuesta: "Alguien horneando o celebrando con torta" },
  { emojis: "🍽️🍷", respuesta: "Una cena elegante" },

  // 🐶 Animales
  { emojis: "🐶🚶‍♂️", respuesta: "Una persona paseando a su perro" },
  { emojis: "🐱🛏️", respuesta: "Un gato durmiendo" },
  { emojis: "🐦🎶", respuesta: "Un pájaro cantando" },
  { emojis: "🐠🌊", respuesta: "Un pez nadando en el mar" },
  { emojis: "🐴🏇", respuesta: "Alguien montando a caballo" },

  // 🚗 Transporte
  { emojis: "🚗💨", respuesta: "Un auto yendo rápido" },
  { emojis: "🚲👧", respuesta: "Una niña andando en bicicleta" },
  { emojis: "🚛📦", respuesta: "Un camión transportando paquetes" },
  { emojis: "🛫🌍", respuesta: "Un avión viajando por el mundo" },
  { emojis: "🚀🪐", respuesta: "Un cohete viajando al espacio" },

  // 🎓 Educación y trabajo
  { emojis: "🧑‍🏫📚", respuesta: "Un profesor enseñando" },
  { emojis: "🎓👩‍🎓", respuesta: "Una persona graduándose" },
  { emojis: "💻☕", respuesta: "Un programador trabajando" },
  { emojis: "🧑‍💻💡", respuesta: "Un programador teniendo una idea" },
  { emojis: "📖🕯️", respuesta: "Alguien leyendo de noche" },

  // ⚽ Deportes
  { emojis: "⚽🥅", respuesta: "Un jugador de fútbol pateando al arco" },
  { emojis: "🏀🏆", respuesta: "Un equipo ganando un torneo de baloncesto" },
  { emojis: "🏊‍♂️🏅", respuesta: "Un nadador ganando una medalla" },
  { emojis: "🏃‍♂️💨", respuesta: "Alguien corriendo rápido" },
  { emojis: "🥋👊", respuesta: "Alguien practicando artes marciales" },

  // ❤️ Familia y amor
  { emojis: "👨‍👩‍👧‍👦❤️", respuesta: "Una familia feliz" },
  { emojis: "👰🤵💍", respuesta: "Una boda o casamiento" },
  { emojis: "💌💕", respuesta: "Alguien enviando una carta de amor" },
  { emojis: "🌹💘", respuesta: "Un gesto romántico con flores" },
  { emojis: "👶🍼", respuesta: "Un bebé tomando leche" },

  // 🎮 Diversión
  { emojis: "🎮🕹️", respuesta: "Alguien jugando videojuegos" },
  { emojis: "🎬📽️", respuesta: "Grabando una película" },
  { emojis: "🎤🎶", respuesta: "Cantando o dando un concierto" },
  { emojis: "🎡🎢", respuesta: "Diversión en un parque de atracciones" },
  { emojis: "🪩💃", respuesta: "Gente bailando en una fiesta" },

  // 🌍 Lugares y viajes
  { emojis: "🏖️🌞", respuesta: "Vacaciones en la playa" },
  { emojis: "🏔️🎿", respuesta: "Esquiando en la montaña" },
  { emojis: "🏙️🌃", respuesta: "Una gran ciudad de noche" },
  { emojis: "🏕️🔥", respuesta: "Acampando al aire libre" },
  { emojis: "🏰👸", respuesta: "Una princesa en un castillo" },

  // 🧙 Fantasía y ficción
  { emojis: "🧙‍♂️✨", respuesta: "Un mago lanzando un hechizo" },
  { emojis: "🧛‍♀️🩸", respuesta: "Una vampiresa" },
  { emojis: "🦸‍♂️💥", respuesta: "Un superhéroe en acción" },
  { emojis: "👽🚀", respuesta: "Un extraterrestre viajando en una nave" },
  { emojis: "🐉🔥", respuesta: "Un dragón lanzando fuego" },

  // 🕵️ Misterio y acción
  { emojis: "🕵️‍♂️🔍", respuesta: "Un detective buscando pistas" },
  { emojis: "🔫🕶️", respuesta: "Un espía o agente secreto" },
  { emojis: "💣💥", respuesta: "Una explosión" },
  { emojis: "🚔👮‍♂️", respuesta: "Policías persiguiendo a alguien" },
  { emojis: "🧨🎆", respuesta: "Fuegos artificiales en el cielo" },
];

// 🤖 Validar con Groq si la descripción tiene el mismo sentido
async function validarConGroq(descripcionJugador, descripcionOficial) {
  try {
    const prompt = `Eres un experto en validación de descripciones de emojis. Tu trabajo es verificar si una descripción del usuario captura la ESENCIA de lo que representan los emojis.

REGLAS IMPORTANTES:
- Acepta cualquier descripción que capture la idea general/concepto principal
- Ignora pequeñas diferencias, typos, orden de palabras o detalles menores
- Acepta si el jugador describe el concepto correcto aunque le falten detalles
- Rechaza SOLO si la descripción describe algo completamente diferente

Descripción oficial (referencia): "${descripcionOficial}"
Descripción del jugador: "${descripcionJugador}"

Responde ÚNICAMENTE con SI o NO. Sin explicaciones.`;

    const res = await axios.post(API_URL, {
      model: MODEL,
      messages: [
        { role: 'system', content: 'Eres un validador justo y flexible. Validas si una descripción captura la esencia de los emojis, no la exactitud palabra por palabra.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 5
    }, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      timeout: TIMEOUT
    });

    const texto = res.data?.choices?.[0]?.message?.content?.toUpperCase()?.trim() || "";
    return texto.startsWith("SI");
  } catch (err) {
    console.error("[DESCRIBE GROQ ERROR]", err.message);
    return false;
  }
}

// 🎮 Comando principal: /describe
async function handler(message, { text, conn }) {
  try {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;
    if (partidasDescribe.has(chatId))
      return await message.reply('⚠️ Ya hay una partida activa. Espera a que termine.');

    const elegido = baseEmojis[Math.floor(Math.random() * baseEmojis.length)];

    const textoMensaje = `🎭 *JUEGO: Describe lo que ves*\n\n🧩 Observa estos emojis:\n${elegido.emojis}\n\n💬 *Cita (responde) este mensaje* con tu descripción.\nEjemplo: "Un chef cocinando una pizza"\n⏱️ Tiempo: ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;

    const botMsg = await message.reply(textoMensaje);
    const botMsgId = botMsg?.key?.id || botMsg?.id || null;

    const partida = {
      respuestaOficial: elegido.respuesta,
      tiempoInicio: Date.now(),
      timeout: null,
      messageInicial: message,
      botMsgId,
    };

    partidasDescribe.set(chatId, partida);

    partida.timeout = setTimeout(async () => {
      const activa = partidasDescribe.get(chatId);
      if (!activa) return;
      partidasDescribe.delete(chatId);
      await activa.messageInicial.reply(`⏰ *¡Tiempo agotado!*\n\nLa descripción correcta era:\n👉 "${activa.respuestaOficial}"\n\nUsa /describe para jugar otra vez.`);
    }, TIEMPO_LIMITE);
  } catch (err) {
    console.error('[DESCRIBE ERROR]', err);
    await message.reply('❌ Ocurrió un error al iniciar el juego.');
  }
}

function obtenerQuotedId(message) {
  return message.quoted?.key?.id
    || message.quoted?.id
    || message._data?.quotedMsg?.key?.id
    || message._data?.quotedMsg?.id
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.key?.id
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.id
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo?.stanzaId
    || null;
}

function esCitaValida(message, partida) {
  const isGroup = message.from?.endsWith('@g.us');
  if (!isGroup) return true;

  const quotedId = obtenerQuotedId(message);
  if (!quotedId) return false;
  if (partida.botMsgId && quotedId === partida.botMsgId) return true;

  const quotedSender = message.quoted?.sender
    || message._data?.quotedMsg?.sender
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo?.participant
    || null;

  const selfSender = message.author || message.from;
  const botJid = message._sock?.user?.id || message._sock?.user?.jid
    || global.conn?.user?.id || global.conn?.user?.jid || null;

  if (quotedSender && botJid && quotedSender === botJid) return true;
  if (!partida.botMsgId && quotedSender && quotedSender !== selfSender) return true;
  return false;
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
  try {
    if (!message.from) return;
    const chatId = message.from;
    const isGroup = chatId.endsWith('@g.us');
    const partida = partidasDescribe.get(chatId);
    if (!partida) return;

    // En grupo solo procesar si la respuesta cita el mensaje del bot
    if (isGroup && !esCitaValida(message, partida)) return;

    const respuestaJugador = message.body?.trim();
    if (!respuestaJugador) return;

    const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
    if (tiempoTranscurrido > TIEMPO_LIMITE) return;

    const esCorrecta = await validarConGroq(respuestaJugador, partida.respuestaOficial);

    if (esCorrecta) {
      const tiempoRestante = Math.max(0, (TIEMPO_LIMITE - tiempoTranscurrido) / 1000);
      const premio = Math.max(500, Math.floor(tiempoRestante * PREMIO_POR_SEGUNDO));

      try {
        const winnerJid = message.author || message.from;
        let user = global.db.getUser(winnerJid);
        if (!user) user = { money: 0 };
        user.money = Number(user.money) || 0;
        user.money += premio;
        global.db.setUser(winnerJid, user);
      } catch (e) {
        console.error('\x1b[31m[DESCRIBE DB ERROR]\x1b[0m', e.message);
      }

      clearTimeout(partida.timeout);
      partidasDescribe.delete(chatId);

      const ganador = (message.author || message.from).split('@')[0];
      await message.reply(`✅ *¡Correcto!* @${ganador}\n\nTu descripción tiene sentido con:\n👉 "${partida.respuestaOficial}"\n\n💰 Premio: $${premio.toLocaleString()}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s`, {
        mentions: [message.author || message.from]
      });
    } else {
      await message.reply("❌ Tu descripción no coincide con lo que representan los emojis. Intenta con otra frase antes de que se acabe el tiempo.");
    }
  } catch (err) {
    console.error('[DESCRIBE REPLY ERROR]', err);
  }
}

// 📦 Exportación del comando
module.exports = {
  command: /^(describe|describir)$/i,
  handler,
  textReplyHandler,
  help: '🎭 Juego de emojis con IA.\n• Escribe /describe para comenzar.\n• Cita el mensaje del bot con tu descripción.\n• 20 segundos por ronda.\n• La IA analiza si tu respuesta tiene sentido.\n• ¡Gana dinero virtual si aciertas rápido!',
  tags: ['diversion', 'juegos', 'ia'],
};

module.exports.group = true;