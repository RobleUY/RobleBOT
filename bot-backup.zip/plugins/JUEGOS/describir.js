// 🎭 Juego: Describe los Emojis
// Autor: RobleBOT ✨
// 🧠 Usa Gemini para analizar si la descripción del jugador tiene el mismo sentido que la frase oficial
// 🌍 Optimizado para respuestas profundas y contextuales

const axios = require('axios');
const partidasDescribe = new Map();

// ⚙️ Configuración general
const TIEMPO_LIMITE = 20000; // 20s
const PREMIO_POR_SEGUNDO = 400;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// 🔑 Claves de API Gemini
const API_KEYS = [
  "AIzaSyBQEypmn1xwB-BMakw-ZgmIbH4A71D3diE",
  "AIzaSyAqad2qjoPDpNWFQg20_3tMpt8CL_Pqw_A",
  "AIzaSyBkHDP5FNjQKuhR-aCbmVkj9Mc7_tHuK3A",
  "AIzaSyAfeiA7ww0eiY-8ukElr7iAahue7BMwaw0"
];

const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

// 🎨 Base de emojis y respuestas oficiales
const baseEmojis = [
  // 👨‍🍳 Cocina
  { emojis: "👨‍🍳🍕", respuesta: "Un chef cocinando una pizza" },
  { emojis: "👩‍🍳🍔", respuesta: "Una cocinera preparando una hamburguesa" },
  { emojis: "🍳🥓", respuesta: "Desayuno con huevos y panceta" },
  { emojis: "🍰🎂", respuesta: "Alguien horneando o celebrando con torta" },
  { emojis: "🍽️🍷", respuesta: "Una cena elegante" },

  // 🐶 Animales
  { emojis: "🐶🚶‍♂️", respuesta: "Una persona paseando a su perro" },
  { emojis: "🐱🛏️", respuesta: "Un gato durmiendo" },
  { emojis: "🐦🎶", respuesta: "Un pájaro cantando" },
  { emojis: "🐠🌊", respuesta: "Un pez nadando en el mar" },
  { emojis: "🐴🏇", respuesta: "Alguien montando a caballo" },

  // 🚗 Transporte
  { emojis: "🚗💨", respuesta: "Un auto yendo rápido" },
  { emojis: "🚲👧", respuesta: "Una niña andando en bicicleta" },
  { emojis: "🚛📦", respuesta: "Un camión transportando paquetes" },
  { emojis: "🛫🌍", respuesta: "Un avión viajando por el mundo" },
  { emojis: "🚀🪐", respuesta: "Un cohete viajando al espacio" },

  // 🎓 Educación y trabajo
  { emojis: "🧑‍🏫📚", respuesta: "Un profesor enseñando" },
  { emojis: "🎓👩‍🎓", respuesta: "Una persona graduándose" },
  { emojis: "💻☕", respuesta: "Un programador trabajando" },
  { emojis: "🧑‍💻💡", respuesta: "Un programador teniendo una idea" },
  { emojis: "📖🕯️", respuesta: "Alguien leyendo de noche" },

  // ⚽ Deportes
  { emojis: "⚽🥅", respuesta: "Un jugador de fútbol pateando al arco" },
  { emojis: "🏀🏆", respuesta: "Un equipo ganando un torneo de baloncesto" },
  { emojis: "🏊‍♂️🏅", respuesta: "Un nadador ganando una medalla" },
  { emojis: "🏃‍♂️💨", respuesta: "Alguien corriendo rápido" },
  { emojis: "🥋👊", respuesta: "Alguien practicando artes marciales" },

  // ❤️ Familia y amor
  { emojis: "👨‍👩‍👧‍👦❤️", respuesta: "Una familia feliz" },
  { emojis: "👰🤵💍", respuesta: "Una boda o casamiento" },
  { emojis: "💌💕", respuesta: "Alguien enviando una carta de amor" },
  { emojis: "🌹💘", respuesta: "Un gesto romántico con flores" },
  { emojis: "👶🍼", respuesta: "Un bebé tomando leche" },

  // 🎮 Diversión
  { emojis: "🎮🕹️", respuesta: "Alguien jugando videojuegos" },
  { emojis: "🎬📽️", respuesta: "Grabando una película" },
  { emojis: "🎤🎶", respuesta: "Cantando o dando un concierto" },
  { emojis: "🎡🎢", respuesta: "Diversión en un parque de atracciones" },
  { emojis: "🪩💃", respuesta: "Gente bailando en una fiesta" },

  // 🌍 Lugares y viajes
  { emojis: "🏖️🌞", respuesta: "Vacaciones en la playa" },
  { emojis: "🏔️🎿", respuesta: "Esquiando en la montaña" },
  { emojis: "🏙️🌃", respuesta: "Una gran ciudad de noche" },
  { emojis: "🏕️🔥", respuesta: "Acampando al aire libre" },
  { emojis: "🏰👸", respuesta: "Una princesa en un castillo" },

  // 🧙 Fantasía y ficción
  { emojis: "🧙‍♂️✨", respuesta: "Un mago lanzando un hechizo" },
  { emojis: "🧛‍♀️🩸", respuesta: "Una vampiresa" },
  { emojis: "🦸‍♂️💥", respuesta: "Un superhéroe en acción" },
  { emojis: "👽🚀", respuesta: "Un extraterrestre viajando en una nave" },
  { emojis: "🐉🔥", respuesta: "Un dragón lanzando fuego" },

  // 🕵️ Misterio y acción
  { emojis: "🕵️‍♂️🔍", respuesta: "Un detective buscando pistas" },
  { emojis: "🔫🕶️", respuesta: "Un espía o agente secreto" },
  { emojis: "💣💥", respuesta: "Una explosión" },
  { emojis: "🚔👮‍♂️", respuesta: "Policías persiguiendo a alguien" },
  { emojis: "🧨🎆", respuesta: "Fuegos artificiales en el cielo" },
];

// ✨ Obtener una clave API aleatoria
function obtenerApiKey() {
  return API_KEYS[Math.floor(Math.random() * API_KEYS.length)];
}

// 🤖 Validar con Gemini si la descripción tiene el mismo sentido
async function validarConGemini(descripcionJugador, descripcionOficial) {
  try {
    const prompt = `
Eres un experto en interpretación semántica. 
Analiza si las dos frases tienen el mismo significado, contexto o intención general, aunque usen diferentes palabras, sinónimos o estructuras.

- Si las frases expresan lo mismo o algo muy parecido (aunque sea con distinto enfoque), responde únicamente con "SI".
- Si la frase del jugador no tiene sentido, está fuera de contexto o describe algo distinto, responde únicamente con "NO".
No incluyas ninguna explicación.

Frase oficial: "${descripcionOficial}"
Descripción del jugador: "${descripcionJugador}"
`;

    const apiKey = obtenerApiKey();
    const res = await axios.post(`${API_URL}?key=${apiKey}`, {
      contents: [{ parts: [{ text: prompt }] }]
    });

    const texto = res.data?.candidates?.[0]?.content?.parts?.[0]?.text?.toUpperCase()?.trim() || "";
    return texto.startsWith("SI");
  } catch (err) {
    console.error("[DESCRIBE GEMINI ERROR]", err.message);
    // En caso de error de API, dar por incorrecto para no regalar dinero.
    return false; 
  }
}

// 🎮 Comando principal: /describe
async function handler(message, { text }) {
  try {
    if (!message.from.endsWith('@g.us'))
      return await message.reply('❌ Este juego solo funciona en grupos.');

    const chatId = message.from;
    if (partidasDescribe.has(chatId))
      return await message.reply('⚠️ Ya hay una partida activa. Espera a que termine.');

    const elegido = baseEmojis[Math.floor(Math.random() * baseEmojis.length)];

    const mensaje = `🎭 *JUEGO: Describe lo que ves*\n\n🧩 Observa estos emojis:\n${elegido.emojis}\n\n💬 Escribe una frase que describa lo que representan.\nEjemplo: "Un chef cocinando una pizza"\n⏱️ Tiempo: ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;
    await message.reply(mensaje);

    const partida = {
      respuestaOficial: elegido.respuesta,
      tiempoInicio: Date.now(),
      timeout: null,
    };

    partidasDescribe.set(chatId, partida);

    partida.timeout = setTimeout(async () => {
      const activa = partidasDescribe.get(chatId);
      if (!activa) return;
      partidasDescribe.delete(chatId);

      await global.conn.sendMessage(chatId, {
        text: `⏰ *¡Tiempo agotado!*\n\nLa descripción correcta era:\n👉 "${activa.respuestaOficial}"\n\nUsa /describe para jugar otra vez.`,
      });
    }, TIEMPO_LIMITE);
  } catch (err) {
    console.error('[DESCRIBE ERROR]', err);
    await message.reply('❌ Ocurrió un error al iniciar el juego.');
  }
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
  try {
    if (!message.from.endsWith('@g.us')) return;

    const chatId = message.from;
    const partida = partidasDescribe.get(chatId);
    if (!partida) return;

    const respuestaJugador = message.body?.trim();
    if (!respuestaJugador) return;

    const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
    if (tiempoTranscurrido > TIEMPO_LIMITE) return;

    // **NOTA:** Aquí se recomienda verificar si es una respuesta al mensaje del bot,
    // para evitar que cualquier mensaje de texto active la validación de Gemini, 
    // lo cual consume la cuota de la API. (No modificado para mantener la estructura original).

    const esCorrecta = await validarConGemini(respuestaJugador, partida.respuestaOficial);

    if (esCorrecta) {
      const tiempoRestante = Math.max(0, (TIEMPO_LIMITE - tiempoTranscurrido) / 1000);
      const premio = Math.max(500, Math.floor(tiempoRestante * PREMIO_POR_SEGUNDO));

      // 💰 Lógica de base de datos ajustada para ser idéntica a 'daily' y 'trivia'
      try {
        const winnerJid = message.author || message.from;
        
        // 1) Cargar datos del usuario
        let user = global.db.getUser(winnerJid);
        if (!user) {
          user = { money: 0 }; 
        }

        // 2) Actualizar dinero
        user.money = Number(user.money) || 0;
        user.money += premio;
        
        // 3) Guardar los cambios
        global.db.setUser(winnerJid, user);

      } catch (e) {
        console.error('\x1b[31m[DESCRIBE DB ERROR]\x1b[0m', e.message);
      }

      clearTimeout(partida.timeout);
      partidasDescribe.delete(chatId);

      const ganador = (message.author || message.from).split('@')[0];
      await global.conn.sendMessage(chatId, {
        text: `✅ *¡Correcto!* @${ganador}\n\nTu descripción tiene sentido con:\n👉 "${partida.respuestaOficial}"\n\n💰 Premio: $${premio.toLocaleString()}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s`,
        mentions: [message.author || message.from],
      });
    } else {
      await message.reply("❌ Tu descripción no coincide con lo que representan los emojis. Intenta con otra frase antes de que se acabe el tiempo.");
    }
  } catch (err) {
    console.error('[DESCRIBE REPLY ERROR]', err);
  }
}

// 📦 Exportación del comando
module.exports = {
  command: /^(describe|describir)$/i,
  handler,
  textReplyHandler,
  help: '🎭 Juego de emojis con IA.\n• Escribe /describe para comenzar.\n• Describe lo que ves.\n• 20 segundos por ronda.\n• La IA analiza si tu respuesta tiene sentido.\n• ¡Gana dinero virtual si aciertas rápido!',
  tags: ['diversion', 'juegos', 'ia'],
};

// Se agrega la propiedad group: true al módulo
module.exports.group = true;