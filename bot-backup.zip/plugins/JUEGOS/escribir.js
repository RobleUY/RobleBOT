// ✍️ Juego: Escribe la Frase
// Autor: RobleBOT ✨
// ⏱️ Validación exacta de caracteres incluyendo tildes
// 💰 Premios basados en longitud de frase y velocidad

const partidasEscribir = new Map();

// ⚙️ Configuración general
const TIEMPO_LIMITE = 30000; // 30s
const PREMIO_BASE = 200; // Premio mínimo

// 📝 Base de frases variadas (sin IA, validación exacta con tildes)
const baseFrases = [
  // 🎯 Frases motivacionales
  "El tomate es una fruta.",
  "La paciencia es una virtud.",
  "El éxito requiere dedicación.",
  "La amistad es un tesoro.",
  "La esperanza nunca muere.",
  "La música es el alma del mundo.",
  "El conocimiento es poder.",
  "La bondad cura todas las heridas.",
  "El tiempo es oro.",
  "La verdad siempre prevalece.",
  "Cada momento es una oportunidad.",
  "La vida está llena de sorpresas.",
  "El trabajo en equipo hace el sueño realidad.",
  "La creatividad no tiene límites.",
  "La educación transforma vidas.",

  // 🌍 Frases sobre la naturaleza
  "Las flores son belleza pura.",
  "El mar nos enseña paciencia.",
  "Las montañas tocan el cielo.",
  "Los pájaros cantan al amanecer.",
  "El bosque guarda muchos secretos.",
  "La lluvia trae vida nueva.",
  "El sol ilumina cada día.",
  "Las estrellas guían el camino.",
  "La nieve cubre todo de blanco.",
  "Los árboles dan oxígeno.",
  "El río fluye hacia el mar.",
  "Las mariposas transforman sus alas.",
  "El cielo cambia colores constantemente.",
  "La naturaleza es nuestro hogar.",
  "Las aves migran buscando calor.",

  // 😄 Frases divertidas
  "Los gatos son más cool que los perros.",
  "El chocolate es medicina.",
  "Pizza es la razón de vivir.",
  "Los viernes son lo mejor.",
  "El café es un hug en una taza.",
  "La risa es el mejor remedio.",
  "Los memes curan el alma.",
  "Dormir es mi deporte favorito.",
  "Las papas fritas son perfectas.",
  "La pizza es una verdura.",
  "La música es bueno para el alma.",
  "Los tacos no son un meme.",
  "La procrastinación es un arte.",
  "El café es amor en una taza.",
  "Las cosas buenas llegan a quien espera.",

  // 🔬 Frases educativas
  "La gravedad mantiene los pies en tierra.",
  "El oxígeno es esencial para la vida.",
  "La fotosíntesis produce alimento.",
  "La energía no se crea ni se destruye.",
  "La matemática es el lenguaje del universo.",
  "El ADN es el código de la vida.",
  "Los átomos forman la materia.",
  "La física explica el movimiento.",
  "La química transforma sustancias.",
  "La biología estudia los seres vivos.",
  "El universo es infinitamente grande.",
  "La gravitación afecta todo en el espacio.",
  "El tiempo es relativo según Einstein.",
  "La tecnología evoluciona constantemente.",
  "La inteligencia artificial cambia el mundo.",

  // 💭 Frases sobre sentimientos
  "El amor lo conquista todo.",
  "La soledad duele en el pecho.",
  "La alegría es contagiosa.",
  "El miedo es solo una ilusión.",
  "La tristeza nos enseña valor.",
  "La ira nubla el juicio.",
  "La paz vive dentro de ti.",
  "El odio consume el alma.",
  "La fe mueve montañas.",
  "La esperanza brilla en la oscuridad.",
  "La pasión enciende el fuego.",
  "La gratitud abre el corazón.",
  "La envidia nos roba la felicidad.",
  "La nostalgia trae recuerdos bonitos.",
  "La ansiedad desaparece con calma.",

  // 🎮 Frases gamer
  "Los juegos son vida.",
  "Game Over es solo el inicio.",
  "Los altos scores son adictivos.",
  "Las consolas nunca envejecen.",
  "Los speedruns son arte.",
  "Los bugs a veces son features.",
  "Los RPG son historias épicas.",
  "Los shooters requieren reflejos.",
  "Los puzzle games entrenan la mente.",
  "Los retro games son nostálgia.",
  "Los controles importan mucho.",
  "La comunidad gamer es genial.",
  "Los logros dan satisfacción.",
  "Las campañas son adictivas.",
  "El multijugador crea amistades.",

  // 🎬 Frases sobre cine y series
  "Las películas transportan almas.",
  "Las series enganchan de verdad.",
  "El cine es magia en movimiento.",
  "Las tramas twist sorprenden.",
  "Los finales felices calientan corazones.",
  "Los villanos hacen buenas historias.",
  "Los efectos especiales asombran.",
  "Los clásicos nunca pasan de moda.",
  "Las comedias alivian tensiones.",
  "Los dramas tocan el alma.",
  "Las animaciones cuentan historias.",
  "Los documentales abren mentes.",
  "Las escenas de acción emocionan.",
  "Los romances hacen suspirar.",
  "Los thrillers mantienen despierto.",

  // 🏆 Frases motivacionales cortas
  "Nunca es tarde para intentar.",
  "Cada día es una oportunidad.",
  "La persistencia vence obstáculos.",
  "Los sueños se hacen realidad.",
  "Somos más fuertes juntos.",
  "El límite es la mente.",
  "La fe es el primer paso.",
  "La acción conquista miedos.",
  "El valor viene del corazón.",
  "La vida es un regalo precioso.",
  "Todo es posible con esfuerzo.",
  "La mente es muy poderosa.",
  "El éxito requiere disciplina.",
  "La salud es lo más importante.",
  "La familia es lo primero.",

  // 🌟 Frases extras inspiradoras
  "Hoy es el mejor día para empezar.",
  "Tu potencial es ilimitado.",
  "La vida sigue adelante siempre.",
  "Aprende de cada error cometido.",
  "La compasión cambia el mundo.",
  "Tu voz importa mucho aquí.",
  "Mereces ser feliz siempre.",
  "La paciencia trae recompensas.",
  "Ama lo que haces cada día.",
  "La vida es una aventura increíble.",
];

// ✍️ Validación exacta: la frase debe ser idéntica incluyendo tildes y puntuación
function validarFraseExacta(fraseJugador, fraseOficial) {
  return fraseJugador === fraseOficial;
}

// 💰 Calcular premio basado en longitud de frase y tiempo de respuesta
function calcularPremio(fraseOficial, tiempoMs) {
  const longitud = fraseOficial.length;
  const tiempoSeg = tiempoMs / 1000;
  
  // Factor por longitud (frases más largas dan más puntos base)
  const factorLongitud = 1 + (longitud / 100); // Va de 1 a ~2.5
  
  // Factor por tiempo (cuanto más rápido, más multiplicador)
  const velocidadEsperada = longitud / 15; // 15 caracteres por segundo es "normal"
  const factorVelocidad = Math.max(0.5, velocidadEsperada / (tiempoSeg + 0.1));
  
  // Fórmula final
  const premio = Math.floor(PREMIO_BASE * factorLongitud * factorVelocidad);
  return Math.min(premio, 2000); // Máximo 2000
}

// 🎮 Comando principal: .escribir
async function handler(message, { text, conn }) {
  try {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;
    if (partidasEscribir.has(chatId))
      return await message.reply('⚠️ Ya hay una partida activa. Espera a que termine.');

    const elegida = baseFrases[Math.floor(Math.random() * baseFrases.length)];
    const premioMaxEst = Math.min(2000, PREMIO_BASE * (1 + elegida.length / 100) * 2);

    const textoMensaje = `✍️ *JUEGO: Escribe la Frase*\n\n📝 Debes escribir exactamente:\n\n"${elegida}"\n\n⚠️ Incluye tildes, puntuación y mayúsculas.\n💬 *Cita este mensaje* con tu respuesta.\n⏱️ Tiempo: ${TIEMPO_LIMITE / 1000}s\n💰 Premio: Depende de velocidad y longitud`;

    const botMsg = await message.reply(textoMensaje);
    const botMsgId = botMsg?.key?.id || botMsg?.id || null;

    const partida = {
      fraseOficial: elegida,
      tiempoInicio: Date.now(),
      timeout: null,
      messageInicial: message,
      botMsgId,
    };

    partidasEscribir.set(chatId, partida);

    partida.timeout = setTimeout(async () => {
      const activa = partidasEscribir.get(chatId);
      if (!activa) return;
      partidasEscribir.delete(chatId);
      await activa.messageInicial.reply(`⏰ *¡Tiempo agotado!*\n\nLa frase correcta era:\n👉 "${activa.fraseOficial}"\n\nUsa .escribir para jugar otra vez.`);
    }, TIEMPO_LIMITE);
  } catch (err) {
    console.error('[ESCRIBIR ERROR]', err);
    await message.reply('❌ Ocurrió un error al iniciar el juego.');
  }
}

function obtenerQuotedId(message) {
  const ctx = message._baileyMessage?.message?.contextInfo
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.extendedTextMessageV2?.contextInfo
    || message._baileyMessage?.message?.buttonsResponseMessage?.contextInfo
    || message._baileyMessage?.message?.listResponseMessage?.contextInfo
    || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
    || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
    || null;

  return message.quoted?.key?.id
    || message.quoted?.id
    || message._data?.quotedMsg?.key?.id
    || message._data?.quotedMsg?.id
    || ctx?.quotedMessage?.key?.id
    || ctx?.quotedMessage?.id
    || ctx?.stanzaId
    || null;
}

function esCitaValida(message, partida) {
  const isGroup = message.from?.endsWith('@g.us');
  if (message.key?.fromMe) return true;
  if (!isGroup) return true;

  const quotedId = obtenerQuotedId(message);
  if (!quotedId) return false;
  if (partida.botMsgId && quotedId === partida.botMsgId) return true;

  const ctx = message._baileyMessage?.message?.contextInfo
    || message._baileyMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.extendedTextMessageV2?.contextInfo
    || message._baileyMessage?.message?.buttonsResponseMessage?.contextInfo
    || message._baileyMessage?.message?.listResponseMessage?.contextInfo
    || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
    || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
    || message._baileyMessage?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
    || null;

  const quotedSender = message.quoted?.sender
    || message._data?.quotedMsg?.sender
    || ctx?.participant
    || null;

  const selfSender = message.author || message.from;
  const botJid = message._sock?.user?.id || message._sock?.user?.jid
    || global.conn?.user?.id || global.conn?.user?.jid || null;

  if (quotedSender && botJid && quotedSender === botJid) return true;
  if (!partida.botMsgId && quotedSender && quotedSender !== selfSender) return true;
  return false;
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
  try {
    if (!message.from) return;
    const chatId = message.from;
    const isGroup = chatId.endsWith('@g.us');
    const partida = partidasEscribir.get(chatId);
    if (!partida) return;

    // En grupo solo procesar si la respuesta cita el mensaje del bot
    if (isGroup && !esCitaValida(message, partida)) return;

    const respuestaJugador = message.body?.trim();
    if (!respuestaJugador) return;

    const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
    if (tiempoTranscurrido > TIEMPO_LIMITE) return;

    const esCorrecta = validarFraseExacta(respuestaJugador, partida.fraseOficial);

    if (esCorrecta) {
      const premio = calcularPremio(partida.fraseOficial, tiempoTranscurrido);

      try {
        const winnerJid = message.author || message.from;
        let user = global.db.getUser(winnerJid);
        if (!user) user = { money: 0 };
        user.money = Number(user.money) || 0;
        user.money += premio;
        global.db.setUser(winnerJid, user);
      } catch (e) {
        console.error('\x1b[31m[ESCRIBIR DB ERROR]\x1b[0m', e.message);
      }

      clearTimeout(partida.timeout);
      partidasEscribir.delete(chatId);

      const ganador = (message.author || message.from).split('@')[0];
      await message.reply(`✅ *¡Correcto!* @${ganador}\n\n"${partida.fraseOficial}"\n\n💰 Premio: $${premio.toLocaleString()}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(2)}s`, {
        mentions: [message.author || message.from]
      });
    } else {
      await message.reply("❌ Incorrecto. Debe ser exactamente igual (incluye tildes, comas y puntos). Intenta de nuevo.");
    }
  } catch (err) {
    console.error('[ESCRIBIR REPLY ERROR]', err);
  }
}

// 📦 Exportación del comando
module.exports = {
  command: /^(escribir|escribe)$/i,
  handler,
  textReplyHandler,
  help: '✍️ Juego de escritura exacta.\n• Escribe .escribir para comenzar.\n• El bot te muestra una frase que debes escribir EXACTAMENTE igual (con tildes y puntuación).\n• Cita el mensaje del bot con tu respuesta.\n• 30 segundos máximo.\n• Validación exacta de caracteres.\n• Premio: depende de la longitud y velocidad de respuesta.',
  tags: ['diversion', 'juegos', 'escritura'],
};

module.exports.group = true;
