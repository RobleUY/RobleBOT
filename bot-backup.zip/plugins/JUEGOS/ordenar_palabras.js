const fs = require('fs');
const path = require('path');

// 📂 Cargar palabras desde el archivo JSON
let palabras = [];
const palabrasPath = path.join(__dirname, 'palabras.json');

try {
    const data = fs.readFileSync(palabrasPath, 'utf8');
    palabras = JSON.parse(data);
    console.log(`\x1b[32m[ORDENAR] ✅ Cargadas ${palabras.length} palabras desde palabras.json\x1b[0m`);
} catch (error) {
    console.error('\x1b[31m[ORDENAR] ❌ Error al cargar palabras.json:', error.message, '\x1b[0m');
    palabras = ['manzana', 'cielo', 'fuego', 'roble', 'dragon']; // respaldo
}

// 📦 Palabras activas por grupo
const partidasActivas = new Map();

const TIEMPO_LIMITE = 15000; // 15s
const PREMIO_POR_SEGUNDO = 500;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// 🔠 Función para desordenar letras de una palabra
function desordenar(palabra) {
    return palabra.split('').sort(() => Math.random() - 0.5).join('');
}

// ✨ Función para eliminar tildes y normalizar texto
function limpiarTexto(str) {
    return str
        .normalize('NFD') // separa caracteres acentuados
        .replace(/[\u0300-\u036f]/g, '') // elimina los diacríticos
        .replace(/[^a-zA-Z0-9]/g, '') // elimina caracteres raros si hay
        .toLowerCase()
        .trim();
}

// 🔄 Recargar palabras
function recargarPalabras() {
    try {
        delete require.cache[palabrasPath];
        const data = fs.readFileSync(palabrasPath, 'utf8');
        palabras = JSON.parse(data);
        console.log(`\x1b[32m[ORDENAR] ✅ Recargadas ${palabras.length} palabras\x1b[0m`);
        return true;
    } catch (error) {
        console.error('\x1b[31m[ORDENAR] ❌ Error al recargar palabras.json:', error.message, '\x1b[0m');
        return false;
    }
}

// 🎮 Comando principal
async function handler(message, { text, conn }) {
    try {
        console.log('\x1b[33m[ORDENAR] Comando ejecutado\x1b[0m');
        const sock = conn || message._sock || global.conn;

        // 🔁 Recargar palabras
        if (text && text.toLowerCase() === 'reload') {
            const ok = recargarPalabras();
            return await message.reply(
                ok
                    ? `✅ Palabras recargadas exitosamente.\n📘 Total: ${palabras.length}`
                    : '❌ Error al recargar palabras.json.'
            );
        }

        if (!palabras.length) return await message.reply('❌ No hay palabras cargadas.');

        const chatId = message.from;
        if (partidasActivas.has(chatId))
            return await message.reply('❌ Ya hay una palabra activa, espera a que termine.');

        // 🔤 Seleccionar palabra aleatoria
        const palabraCorrecta = palabras[Math.floor(Math.random() * palabras.length)];
        let palabraDesordenada = desordenar(palabraCorrecta);

        // Evitar que salga igual
        while (palabraDesordenada === palabraCorrecta)
            palabraDesordenada = desordenar(palabraCorrecta);

        // 💬 Mensaje del juego
        const mensaje = `🧩 *RobleBOT - ORDENAR*\n\n🔠 Palabra desordenada:\n*${palabraDesordenada.toUpperCase()}*\n\n💡 Ordena las letras y responde a este mensaje con la palabra correcta.\n⏱️ Tienes ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;

        const sentMsg = await message.reply(mensaje);

        const partida = {
            palabra: palabraCorrecta,
            palabraLimpia: limpiarTexto(palabraCorrecta), // versión sin tildes
            tiempoInicio: Date.now(),
            timeout: null,
        };

        partidasActivas.set(chatId, partida);

        partida.timeout = setTimeout(async () => {
            const activa = partidasActivas.get(chatId);
            if (!activa) return;

            partidasActivas.delete(chatId);
            await sock.sendMessage(chatId, {
                text: `⏰ *¡TIEMPO AGOTADO!*\n\nLa palabra era: *${activa.palabra.toUpperCase()}*\n💡 Usa /ordenar para jugar de nuevo.`,
            });
        }, TIEMPO_LIMITE);
    } catch (err) {
        console.error('\x1b[31m[ORDENAR ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al iniciar el juego.');
    }
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
    try {
        const sock = message._sock || message.conn || global.conn;
        if (!sock) {
            console.error('[ORDENAR REPLY] No socket disponible para enviar la respuesta');
            return;
        }

        const chatId = message.from;
        const partida = partidasActivas.get(chatId);
        if (!partida) return;

        const isGroup = chatId.endsWith('@g.us');
        let isReply = !isGroup;
        if (isGroup) {
            if (message.hasQuotedMsg || message._data?.quotedMsg) isReply = true;
            else if (typeof message.getQuotedMessage === 'function') {
                try {
                    if (await message.getQuotedMessage()) isReply = true;
                } catch {}
            }
        }

        if (!isReply) return;

        const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
        if (tiempoTranscurrido > TIEMPO_LIMITE) return;

        const respuesta = limpiarTexto(message.body || '');

        if (respuesta.length < 2) return;

        const esCorrecta = respuesta === partida.palabraLimpia;

        if (esCorrecta) {
            const tiempoRestanteMs = TIEMPO_LIMITE - tiempoTranscurrido;
            const segundosRestantes = Math.max(0, tiempoRestanteMs / 1000);
            const premio = Math.max(500, Math.floor(segundosRestantes * PREMIO_POR_SEGUNDO));

            // 💰 Otorgar dinero (usando la lógica de global.db consistente)
            try {
                const winnerJid = message.author || message.from;
                
                // 1) Cargar datos del usuario
                let user = global.db.getUser(winnerJid);
                if (!user) {
                    user = { money: 0 };
                }
                
                // 2) Actualizar dinero
                user.money = Number(user.money) || 0;
                user.money += premio;
                
                // 3) Guardar los cambios
                global.db.setUser(winnerJid, user);

            } catch (e) {
                console.error('\x1b[31m[ORDENAR DB ERROR]\x1b[0m', e.message);
            }

            clearTimeout(partida.timeout);
            partidasActivas.delete(chatId);

            const ganador = (message.author || message.from).split('@')[0];
            await sock.sendMessage(chatId, {
                text: `🎉 *¡CORRECTO!* @${ganador}\n\n✅ Palabra: *${partida.palabra.toUpperCase()}*\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s\n💰 Premio: $${premio.toLocaleString()}`,
                mentions: [message.author || message.from],
            });
        } else {
            // ❌ Incorrecto (no termina la ronda)
            await message.reply(`❌ *Incorrecto*, intenta otra vez.`);
        }
    } catch (err) {
        console.error('\x1b[31m[ORDENAR REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(ordenar)$/i,
    handler,
    textReplyHandler,
    help: 'Juego de ordenar palabras.\n• Escribe /ordenar para comenzar.\n• Responde al mensaje con la palabra ordenada.\n• Tienes 15s.\n• Premio máximo: $7.500.\n• /ordenar reload para recargar lista (solo owner)',
    tags: ['diversion', 'juegos'],
};

module.exports.group = true;