const fs   = require('fs');
const path = require('path');

// ── Rutas ────────────────────────────────────────────────────────────────────
const PARTIDAS_PATH = path.join(__dirname, 'tateti_partidas.json');

// ── Estado en memoria ────────────────────────────────────────────────────────
const jugadoresOcupados = new Map(); // número → chatId

const TIEMPO_ACEPTAR = 30000; // 30 segundos para aceptar

// ── Emojis del tablero ───────────────────────────────────────────────────────
const CELDAS  = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'];
const FICHA_X = '❎';
const FICHA_O = '⭕';

// ── Combinaciones ganadoras ──────────────────────────────────────────────────
const LINEAS_GANADORAS = [
    [0,1,2],[3,4,5],[6,7,8], // filas
    [0,3,6],[1,4,7],[2,5,8], // columnas
    [0,4,8],[2,4,6]          // diagonales
];

// ══════════════════════════════════════════════════════════════════════════════
// PERSISTENCIA — tateti_partidas.json
// ══════════════════════════════════════════════════════════════════════════════
function cargarPartidas() {
    try {
        if (fs.existsSync(PARTIDAS_PATH)) {
            const raw = fs.readFileSync(PARTIDAS_PATH, 'utf8');
            return JSON.parse(raw);
        }
    } catch (e) {
        console.error('[TATETI] Error cargando partidas:', e.message);
    }
    return {};
}

function guardarPartidas(partidas) {
    try {
        fs.writeFileSync(PARTIDAS_PATH, JSON.stringify(partidas, null, 2), 'utf8');
    } catch (e) {
        console.error('[TATETI] Error guardando partidas:', e.message);
    }
}

// Mapa en memoria sincronizado con JSON (sin timeouts serializados)
let partidasDB = cargarPartidas();
// timeouts activos en memoria (no se persisten)
const timeoutsMap = new Map();

function guardarPartida(chatId, datos) {
    // No guardar la función timeout en JSON
    const { timeout, ...sinTimeout } = datos;
    partidasDB[chatId] = sinTimeout;
    guardarPartidas(partidasDB);
}

function eliminarPartida(chatId) {
    const t = timeoutsMap.get(chatId);
    if (t) { clearTimeout(t); timeoutsMap.delete(chatId); }
    delete partidasDB[chatId];
    guardarPartidas(partidasDB);
}

function obtenerPartida(chatId) {
    return partidasDB[chatId] || null;
}

// ══════════════════════════════════════════════════════════════════════════════
// ESTADÍSTICAS — database.json via global.db
// ══════════════════════════════════════════════════════════════════════════════
function obtenerStats(userId) {
    const base = { jugadas: 0, victorias: 0, derrotas: 0, empates: 0, racha: 0, maxRacha: 0 };
    try {
        if (global.db) {
            const u = global.db.getUser(userId);
            if (u?.tateti) return { ...base, ...u.tateti };
        }
    } catch (e) { console.error('[TATETI DB READ]', e.message); }
    return base;
}

function guardarStats(userId, resultado) {
    // resultado: 'victoria' | 'derrota' | 'empate'
    try {
        if (!global.db) return;
        const u = global.db.getUser(userId) || {};
        if (!u.tateti) u.tateti = { jugadas: 0, victorias: 0, derrotas: 0, empates: 0, racha: 0, maxRacha: 0 };
        const st = u.tateti;
        st.jugadas = (st.jugadas || 0) + 1;
        if (resultado === 'victoria') {
            st.victorias = (st.victorias || 0) + 1;
            st.racha = (st.racha || 0) + 1;
            if (st.racha > (st.maxRacha || 0)) st.maxRacha = st.racha;
        } else if (resultado === 'derrota') {
            st.derrotas = (st.derrotas || 0) + 1;
            st.racha = 0;
        } else {
            st.empates = (st.empates || 0) + 1;
            st.racha = 0;
        }
        global.db.setUser(userId, u);
        if (typeof global.db.save === 'function') global.db.save();
    } catch (e) { console.error('[TATETI DB SAVE]', e.message); }
}

// ══════════════════════════════════════════════════════════════════════════════
// UTILIDADES
// ══════════════════════════════════════════════════════════════════════════════
// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function extraerNumero(jid) {
    return String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function compararJids(a, b) {
    return mismoNumero(a, b);
}

function normalizeNum(jid) {
    return String(jid || '').split('@')[0].replace(/[^0-9]/g, '').trim();
}

// 🔍 Obtener información completa del mensaje citado (Baileys multi-device / subbots)
function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

function verificarGanador(tablero, ficha) {
    return LINEAS_GANADORAS.some(combo => combo.every(i => tablero[i] === ficha));
}
function tableroLleno(tablero) {
    return tablero.every(c => c === FICHA_X || c === FICHA_O);
}

function dibujarTablero(tablero) {
    return [
        `${tablero[0]}${tablero[1]}${tablero[2]}`,
        `${tablero[3]}${tablero[4]}${tablero[5]}`,
        `${tablero[6]}${tablero[7]}${tablero[8]}`
    ].join('\n');
}

function mensajeTablero(partida, extra = '') {
    const turnoN   = extraerNumero(partida.turno);
    const fichaAct = compararJids(partida.turno, partida.jugador1) ? FICHA_X : FICHA_O;
    let msg = `🎮 *TAT-ETI* ${FICHA_X}${FICHA_O}\n`;
    msg += `━━━━━━━━━━━━━━━━━\n`;
    msg += `${FICHA_X} @${partida.num1}  vs  ${FICHA_O} @${partida.num2}\n\n`;
    msg += dibujarTablero(partida.tablero);
    msg += `\n\n${fichaAct} Turno de @${turnoN}\n`;
    msg += `💡 Responde con un número del *1 al 9* o usa .tateti <numero>`;
    if (extra) msg += `\n\n${extra}`;
    return msg;
}

// ══════════════════════════════════════════════════════════════════════════════
// TOP
// ══════════════════════════════════════════════════════════════════════════════
function construirEntradaTop(userKey, userData) {
    if (!userData?.tateti) return null;
    const st = userData.tateti;
    if ((st.victorias || 0) === 0) return null;
    const jugadas   = st.jugadas   || 0;
    const victorias = st.victorias || 0;
    const winRate   = jugadas > 0 ? ((victorias / jugadas) * 100).toFixed(1) : '0.0';
    const apodoRaw  = (userData.apodo || '').trim();
    const apodo     = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo') ? '👤 Sin Apodo' : apodoRaw;
    return {
        number: normalizeNum(userKey),
        victorias,
        jugadas,
        empates:  st.empates  || 0,
        derrotas: st.derrotas || 0,
        winRate,
        maxRacha: st.maxRacha || 0,
        apodo
    };
}

async function mostrarTop(message, sock, argTokens) {
    try {
        if (!global.db?.data?.users)
            return message.reply('❌ No se pudo acceder a la base de datos.');

        const chatId   = message.from;
        const userId   = message.author || message.from;
        const currNum  = normalizeNum(userId);
        const isGroup  = chatId.endsWith('@g.us');
        const isGlobal = argTokens[1] && /^(g|global)$/i.test(argTokens[1]);

        if (!isGlobal && !isGroup)
            return message.reply('❌ Usa *.tateti top global* para el ranking mundial.');

        let jugadores = [];

        if (isGlobal) {
            // Usar getUniqueUsers() para obtener usuarios sin duplicados
            const uniqueUsers = global.db.getUniqueUsers();
            for (const [userNumber, data] of uniqueUsers.entries()) {
                const entrada = construirEntradaTop(userNumber + '@s.whatsapp.net', data);
                if (entrada) jugadores.push(entrada);
            }
        } else {
            const meta = await sock.groupMetadata(chatId);
            for (const p of meta.participants) {
                const data   = global.db.getUser(p.id);
                const entrada = construirEntradaTop(p.id, data);
                if (entrada) jugadores.push(entrada);
            }
        }

        if (!jugadores.length)
            return message.reply('📊 Todavía nadie tiene victorias en el ranking de Tat-Eti.');

        jugadores.sort((a, b) => b.victorias - a.victorias || parseFloat(b.winRate) - parseFloat(a.winRate));

        // Posición global siempre
        let jugadoresG = [];
        {
            const uniqueUsers = global.db.getUniqueUsers();
            for (const [userNumber, data] of uniqueUsers.entries()) {
                const e = construirEntradaTop(userNumber + '@s.whatsapp.net', data);
                if (e) jugadoresG.push(e);
            }
            jugadoresG.sort((a, b) => b.victorias - a.victorias || parseFloat(b.winRate) - parseFloat(a.winRate));
        }

        const PER_PAGE   = 10;
        const totalPages = Math.max(1, Math.ceil(jugadores.length / PER_PAGE));
        const pageArg    = isGlobal ? argTokens[2] : argTokens[1];
        let   page       = Math.max(1, parseInt(pageArg) || 1);
        if (page > totalPages) page = totalPages;

        const start     = (page - 1) * PER_PAGE;
        const pageUsers = jugadores.slice(start, start + PER_PAGE);
        const userIdx   = jugadores.findIndex(u => u.number === currNum);
        const userPos   = userIdx + 1;
        const globalPos = jugadoresG.findIndex(u => u.number === currNum) + 1;

        let txt = isGlobal
            ? `🌍 *TOP TAT-ETI GLOBAL* ${FICHA_X}${FICHA_O}\n\n`
            : `🏆 *TOP TAT-ETI DEL GRUPO* ${FICHA_X}${FICHA_O}\n\n`;

        if (!isGlobal) {
            txt += `👥 *En este grupo:* ${jugadores.length} jugadores\n`;
            txt += `🌍 *Global:* ${jugadoresG.length} jugadores\n\n`;
            txt += userPos > 0
                ? `📍 *Tu pos. en el grupo:* #${userPos} — *${jugadores[userIdx].apodo}*\n`
                : `📍 *Tu pos. en el grupo:* No estás en el ranking\n`;
            txt += globalPos > 0
                ? `🌐 *Tu pos. global:* #${globalPos} de ${jugadoresG.length}\n`
                : `🌐 *Tu pos. global:* No estás en el ranking\n`;
        } else {
            txt += `🌍 *Global:* ${jugadoresG.length} jugadores\n\n`;
            txt += userPos > 0
                ? `📍 *Tu pos. global:* #${userPos} — *${jugadores[userIdx].apodo}*\n`
                : `📍 *Tu pos. global:* No estás en el ranking\n`;
        }

        txt += `\n_Página_ *${page}* _de_ *${totalPages}*\n\n`;

        pageUsers.forEach((u, i) => {
            const pos  = start + i + 1;
            const med  = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `${pos}.`;
            txt += `${med} *${u.apodo}*\n`;
            txt += `🏆 ${u.victorias} victorias  💀 ${u.derrotas} derrotas  🤝 ${u.empates} empates\n`;
            txt += `📈 ${u.winRate}% victoria  🔥 Mejor racha: ${u.maxRacha}\n\n`;
        });

        if (totalPages > 1) {
            const mode = isGlobal ? ' global' : '';
            if (page > 1) txt += `⬅️ *.tateti top${mode} ${page - 1}* — página anterior\n`;
            if (page < totalPages) txt += `➡️ *.tateti top${mode} ${page + 1}* — siguiente página\n`;
        }

        if (!isGlobal) txt += `\n💡 _Usa *.tateti top global* para el top mundial_`;

        await message.reply(txt);
    } catch (e) {
        console.error('[TATETI TOP ERROR]', e);
        message.reply('⚠️ Error al obtener el ranking.');
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HANDLER PRINCIPAL
// ══════════════════════════════════════════════════════════════════════════════
const handler = async (message, { text, conn }) => {
    try {
        const sock   = conn || global.conn;
        const chatId = message.from;
        const esGrupo = chatId.endsWith('@g.us');

        const senderJid = esGrupo
            ? message?.key?.participant || message?.author || message?.sender
            : message?.key?.remoteJid  || message?.author || message?.sender || message.from;

        if (!senderJid) return message.reply('❌ No se pudo identificar al remitente.');

        const senderN  = extraerNumero(senderJid);
        const args     = (text || '').trim().split(/\s+/);
        const subcmd   = args[0]?.toLowerCase() || '';

        // ─── STATS ────────────────────────────────────────────────────────────
        if (subcmd === 'stats' || subcmd === 'estadisticas' || subcmd === 'perfil') {
            const st       = obtenerStats(senderJid);
            const winRate  = st.jugadas > 0 ? ((st.victorias / st.jugadas) * 100).toFixed(1) : '0.0';
            const userTag  = senderN;
            await sock.sendMessage(chatId, {
                text:
                    `📊 *ESTADÍSTICAS TAT-ETI* ${FICHA_X}${FICHA_O}\n` +
                    `━━━━━━━━━━━━━━━━━━━━━\n` +
                    `👤 *Jugador:* @${userTag}\n\n` +
                    `🎮 *Partidas jugadas:* ${st.jugadas}\n` +
                    `🏆 *Victorias:* ${st.victorias}\n` +
                    `💀 *Derrotas:* ${st.derrotas}\n` +
                    `🤝 *Empates:* ${st.empates}\n` +
                    `📈 *% de victoria:* ${winRate}%\n` +
                    `🔥 *Racha actual:* ${st.racha}\n` +
                    `⭐ *Mejor racha:* ${st.maxRacha}`,
                mentions: [senderJid]
            });
            return;
        }

        // ─── TOP ──────────────────────────────────────────────────────────────
        if (subcmd === 'top' || subcmd === 'ranking') {
            return await mostrarTop(message, sock, args);
        }

        // ─── DESAFIAR (.tateti @usuario) ─────────────────────────────────────
        if (!subcmd || subcmd.startsWith('@') || (!['aceptar','rechazar','cancelar','stats','estadisticas','perfil','top','ranking'].includes(subcmd) && message?.mentions?.length)) {
            if (!esGrupo) return message.reply('❌ Solo puedes jugar en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length)
                return message.reply(
                    `❌ Menciona a alguien para desafiar.\n💡 Ej: *.tateti @usuario*`
                );

            const target  = mentioned[0];
            if (compararJids(senderJid, target))
                return message.reply('❌ No puedes desafiarte a ti mismo.');

            const targetN = extraerNumero(target);

            if (jugadoresOcupados.has(senderN))
                return message.reply('❌ Ya estás en una partida de tateti.');
            if (jugadoresOcupados.has(targetN))
                return message.reply(`❌ @${targetN} ya está en una partida.`, { mentions: [target] });
            if (obtenerPartida(chatId))
                return message.reply('❌ Ya hay una partida activa en este grupo.\nUsa *.tateti cancelar* si necesitas cancelarla.');

            const partida = {
                chatId,
                jugador1: senderJid,
                jugador2: target,
                num1: senderN,
                num2: targetN,
                tablero: [...CELDAS],
                turno: senderJid,
                estado: 'pendiente',
                creadoEn: Date.now()
            };

            guardarPartida(chatId, partida);
            jugadoresOcupados.set(senderN,  chatId);
            jugadoresOcupados.set(targetN, chatId);

            const t = setTimeout(async () => {
                const actual = obtenerPartida(chatId);
                if (actual?.estado === 'pendiente') {
                    jugadoresOcupados.delete(actual.num1);
                    jugadoresOcupados.delete(actual.num2);
                    eliminarPartida(chatId);
                    await sock.sendMessage(chatId, {
                        text: `⏰ Tiempo agotado. @${targetN} no aceptó el desafío de tateti.`,
                        mentions: [senderJid, target]
                    });
                }
            }, TIEMPO_ACEPTAR);
            timeoutsMap.set(chatId, t);

            await message.reply(
                `🎮 *¡DESAFÍO DE TAT-ETI!* ${FICHA_X}${FICHA_O}\n\n` +
                `${FICHA_X} @${senderN} desafió a ${FICHA_O} @${targetN}!\n\n` +
                `⏱️ @${targetN} tienes *30 segundos* para responder:\n` +
                `• *.tateti aceptar @${senderN}*\n` +
                `• *.tateti rechazar @${senderN}*`,
                { mentions: [senderJid, target] }
            );
            return;
        }

        // ─── ACEPTAR ─────────────────────────────────────────────────────────
        if (subcmd === 'aceptar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length)
                return message.reply('❌ Menciona al retador.\n💡 Ej: *.tateti aceptar @usuario*');

            const retadorN = extraerNumero(mentioned[0]);
            const partida  = obtenerPartida(chatId);

            if (!partida || partida.estado !== 'pendiente')
                return message.reply('❌ No hay ningún desafío pendiente en este grupo.');
            if (partida.num1 !== retadorN)
                return message.reply(`❌ El desafío pendiente no es de @${retadorN}.`);
            if (!compararJids(senderJid, partida.jugador2))
                return message.reply('❌ Este desafío no es para ti.');

            // Cancelar timeout de expiración
            const t = timeoutsMap.get(chatId);
            if (t) { clearTimeout(t); timeoutsMap.delete(chatId); }

            partida.estado = 'activo';
            guardarPartida(chatId, partida);

            const sent = await sock.sendMessage(chatId, {
                text: mensajeTablero(partida, `✅ *¡Partida iniciada!*\n${FICHA_X} @${partida.num1} empieza.`),
                mentions: [partida.jugador1, partida.jugador2]
            });
            if (sent?.key?.id) {
                partida.lastMsgId = sent.key.id;
                if (!Array.isArray(partida.lastMsgIds)) partida.lastMsgIds = [];
                partida.lastMsgIds.push(sent.key.id);
                guardarPartida(chatId, partida);
            }
            return;
        }

        // ─── RECHAZAR ────────────────────────────────────────────────────────
        if (subcmd === 'rechazar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length)
                return message.reply('❌ Menciona al retador.\n💡 Ej: *.tateti rechazar @usuario*');

            const retadorN = extraerNumero(mentioned[0]);
            const partida  = obtenerPartida(chatId);

            if (!partida || partida.estado !== 'pendiente')
                return message.reply('❌ No hay ningún desafío pendiente en este grupo.');
            if (partida.num1 !== retadorN)
                return message.reply(`❌ El desafío pendiente no es de @${retadorN}.`);
            if (!compararJids(senderJid, partida.jugador2))
                return message.reply('❌ Este desafío no es para ti.');

            jugadoresOcupados.delete(partida.num1);
            jugadoresOcupados.delete(partida.num2);
            eliminarPartida(chatId);

            await message.reply(
                `🚫 @${senderN} rechazó el desafío de @${partida.num1}.`,
                { mentions: [senderJid, partida.jugador1] }
            );
            return;
        }

        // ─── CANCELAR ────────────────────────────────────────────────────────
        if (subcmd === 'cancelar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            const partida = obtenerPartida(chatId);
            if (!partida)
                return message.reply('❌ No hay ninguna partida activa en este grupo.');

            const esParticipante =
                compararJids(senderJid, partida.jugador1) ||
                compararJids(senderJid, partida.jugador2);

            if (!esParticipante)
                return message.reply('❌ No estás participando en la partida activa.');

            jugadoresOcupados.delete(partida.num1);
            jugadoresOcupados.delete(partida.num2);
            eliminarPartida(chatId);

            await message.reply(
                `🚫 @${senderN} canceló la partida de tateti.`,
                { mentions: [senderJid] }
            );
            return;
        }

        // ─── JUGADA (1–9) ────────────────────────────────────────────────────
        if (/^[1-9]$/.test(subcmd)) {
            if (!esGrupo) return message.reply('❌ Solo se puede jugar en grupos.');

            const partida = obtenerPartida(chatId);
            if (!partida || partida.estado !== 'activo')
                return message.reply('❌ No hay ninguna partida activa en este grupo.');

            if (!compararJids(senderJid, partida.turno)) {
                const turnoN = extraerNumero(partida.turno);
                return message.reply(`⏳ No es tu turno. Es el turno de @${turnoN}.`, {
                    mentions: [partida.turno]
                });
            }

            const celda = parseInt(subcmd) - 1;
            if (partida.tablero[celda] === FICHA_X || partida.tablero[celda] === FICHA_O)
                return message.reply('❌ Esa casilla ya está ocupada. Elige otra del 1 al 9.');

            const fichaActual = compararJids(senderJid, partida.jugador1) ? FICHA_X : FICHA_O;
            partida.tablero[celda] = fichaActual;

            // ── Victoria ──
            if (verificarGanador(partida.tablero, fichaActual)) {
                const perdedorJid = compararJids(senderJid, partida.jugador1)
                    ? partida.jugador2 : partida.jugador1;

                guardarStats(senderJid,   'victoria');
                guardarStats(perdedorJid, 'derrota');

                jugadoresOcupados.delete(partida.num1);
                jugadoresOcupados.delete(partida.num2);
                eliminarPartida(chatId);

                await sock.sendMessage(chatId, {
                    text:
                        `${fichaActual} *¡@${senderN} GANÓ!* ${fichaActual}\n\n` +
                        `${FICHA_X} @${partida.num1}  vs  ${FICHA_O} @${partida.num2}\n\n` +
                        `${dibujarTablero(partida.tablero)}\n\n` +
                        `🏆 ¡Felicitaciones @${senderN}!\n` +
                        `💡 Usa *.tateti @usuario* para una nueva partida.`,
                    mentions: [partida.jugador1, partida.jugador2]
                });
                return;
            }

            // ── Empate ──
            if (tableroLleno(partida.tablero)) {
                guardarStats(partida.jugador1, 'empate');
                guardarStats(partida.jugador2, 'empate');

                jugadoresOcupados.delete(partida.num1);
                jugadoresOcupados.delete(partida.num2);
                eliminarPartida(chatId);

                await sock.sendMessage(chatId, {
                    text:
                        `🤝 *¡EMPATE!* 🤝\n\n` +
                        `${FICHA_X} @${partida.num1}  vs  ${FICHA_O} @${partida.num2}\n\n` +
                        `${dibujarTablero(partida.tablero)}\n\n` +
                        `💡 Usa *.tateti @usuario* para una revancha.`,
                    mentions: [partida.jugador1, partida.jugador2]
                });
                return;
            }

            // ── Siguiente turno ──
            partida.turno = compararJids(partida.turno, partida.jugador1)
                ? partida.jugador2
                : partida.jugador1;

            guardarPartida(chatId, partida);

            const sent = await sock.sendMessage(chatId, {
                text: mensajeTablero(partida),
                mentions: [partida.jugador1, partida.jugador2]
            });
            if (sent?.key?.id) {
                partida.lastMsgId = sent.key.id;
                if (!Array.isArray(partida.lastMsgIds)) partida.lastMsgIds = [];
                partida.lastMsgIds.push(sent.key.id);
                guardarPartida(chatId, partida);
            }
            return;
        }

        // ─── AYUDA ───────────────────────────────────────────────────────────
        await message.reply(
            `🎮 *TAT-ETI* ${FICHA_X}${FICHA_O}\n` +
            `━━━━━━━━━━━━━━━━━\n\n` +
            `*Comandos:*\n` +
            `• *.tateti @usuario* — Desafiar a alguien\n` +
            `• *.tateti aceptar @usuario* — Aceptar desafío\n` +
            `• *.tateti rechazar @usuario* — Rechazar desafío\n` +
            `• *.tateti cancelar* — Cancelar partida activa\n` +
            `• *.tateti <numero>* — Elegir posicion en la partida\n` +
            `• *.tateti stats* — Tus estadísticas\n` +
            `• *.tateti top* — Ranking del grupo\n` +
            `• *.tateti top global* — Ranking mundial\n\n` +
            `*Para jugar:*\n` +
            `Responde con un número del *1 al 9*:\n\n` +
            `1️⃣2️⃣3️⃣\n4️⃣5️⃣6️⃣\n7️⃣8️⃣9️⃣\n\n` +
            `${FICHA_X} = Retador   ${FICHA_O} = Retado\n` +
            `⏱️ *30 segundos* para aceptar el desafío`
        );
    } catch (err) {
        console.error('[TATETI ERROR]', err);
        message.reply('❌ Error interno en el comando.');
    }
};

handler.command = /^(tateti|ttt|tres.en.raya|tresraya)$/i;
handler.help    = ['tateti @usuario — Desafiar a alguien a Tat-Eti'];
handler.tags    = ['diversion', 'juegos'];

// 💬 Manejador de respuestas de texto (responder al tablero con un número)
async function textReplyHandler(message) {
    try {
        const chatId = message.from;
        if (!chatId?.endsWith('@g.us')) return; // tateti solo en grupos

        const body = (message.body || '').trim();

        // Solo procesar si es exactamente un dígito del 1 al 9
        if (!/^[1-9]$/.test(body)) return;

        // No procesar si es un comando con prefijo
        if (/^[./#❤️👅😎]/.test(body)) return;

        const partida = obtenerPartida(chatId);
        if (!partida || partida.estado !== 'activo') return;

        const sock = getSock(message);
        if (!sock) return;

        // Validar la cita si el usuario citó algún mensaje
        const quotedInfo = obtenerQuotedInfo(message);
        if (quotedInfo.hasQuote) {
            const ids = Array.isArray(partida.lastMsgIds) ? partida.lastMsgIds : [];
            if (partida.lastMsgId) ids.push(partida.lastMsgId);

            const esCitaTablero = (quotedInfo.quotedId && ids.includes(quotedInfo.quotedId))
                || (quotedInfo.quotedText && /tat-eti|turno de|❎|⭕/i.test(quotedInfo.quotedText))
                || quotedInfo.isFromMe
                || isBotJid(quotedInfo.quotedSender, message);

            if (!esCitaTablero) return;
        }

        // Identificar al emisor
        const senderJid = message?.key?.participant || message?.author || message?.sender;
        if (!senderJid) return;

        // Verificar turno
        if (!compararJids(senderJid, partida.turno)) return; // no es su turno, ignorar silenciosamente

        const celda = parseInt(body) - 1;
        if (partida.tablero[celda] === FICHA_X || partida.tablero[celda] === FICHA_O) {
            // Casilla ocupada: avisar
            return await message.reply('❌ Esa casilla ya está ocupada. Elige otra del 1 al 9.');
        }

        const fichaActual = compararJids(senderJid, partida.jugador1) ? FICHA_X : FICHA_O;
        partida.tablero[celda] = fichaActual;

        const senderN = extraerNumero(senderJid);

        // Victoria
        if (verificarGanador(partida.tablero, fichaActual)) {
            const perdedorJid = compararJids(senderJid, partida.jugador1)
                ? partida.jugador2 : partida.jugador1;

            guardarStats(senderJid,   'victoria');
            guardarStats(perdedorJid, 'derrota');

            jugadoresOcupados.delete(partida.num1);
            jugadoresOcupados.delete(partida.num2);
            eliminarPartida(chatId);

            await sock.sendMessage(chatId, {
                text:
                    `${fichaActual} *¡@${senderN} GANÓ!* ${fichaActual}\n\n` +
                    `${FICHA_X} @${partida.num1}  vs  ${FICHA_O} @${partida.num2}\n\n` +
                    `${dibujarTablero(partida.tablero)}\n\n` +
                    `🏆 ¡Felicitaciones @${senderN}!\n` +
                    `💡 Usa *.tateti @usuario* para una nueva partida.`,
                mentions: [partida.jugador1, partida.jugador2]
            });
            return;
        }

        // Empate
        if (tableroLleno(partida.tablero)) {
            guardarStats(partida.jugador1, 'empate');
            guardarStats(partida.jugador2, 'empate');

            jugadoresOcupados.delete(partida.num1);
            jugadoresOcupados.delete(partida.num2);
            eliminarPartida(chatId);

            await sock.sendMessage(chatId, {
                text:
                    `🤝 *¡EMPATE!* 🤝\n\n` +
                    `${FICHA_X} @${partida.num1}  vs  ${FICHA_O} @${partida.num2}\n\n` +
                    `${dibujarTablero(partida.tablero)}\n\n` +
                    `💡 Usa *.tateti @usuario* para una revancha.`,
                mentions: [partida.jugador1, partida.jugador2]
            });
            return;
        }

        // Siguiente turno
        partida.turno = compararJids(partida.turno, partida.jugador1)
            ? partida.jugador2
            : partida.jugador1;

        guardarPartida(chatId, partida);

        const sent = await sock.sendMessage(chatId, {
            text: mensajeTablero(partida),
            mentions: [partida.jugador1, partida.jugador2]
        });
        if (sent?.key?.id) {
            partida.lastMsgId = sent.key.id;
            if (!Array.isArray(partida.lastMsgIds)) partida.lastMsgIds = [];
            partida.lastMsgIds.push(sent.key.id);
            guardarPartida(chatId, partida);
        }

    } catch (err) {
        console.error('[TATETI TEXT REPLY ERROR]', err);
    }
}

module.exports = {
    command: handler.command,
    handler,
    textReplyHandler,
    help: handler.help,
    tags: handler.tags
};
