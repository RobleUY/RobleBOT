const fs = require('fs');
const path = require('path');

const COPERO_FILE = path.join(__dirname, 'copero.json');
const POSITIONS = ['portero', 'defensa', 'mediocampista', 'delantero'];
const STAGE_YEARS = [18, 23, 28, 33, 38];
const STAGE_LABELS = ['Juventud', 'Consolidación', 'Madurez', 'Veteranía'];
const STAGE_BASE_PLAYED = [20, 25, 25, 18];
const POSITION_GOAL_BASE = { defensa: 2, mediocampista: 6, delantero: 18 };

const DEFAULT_DATA = {
  activeGames: {},
  history: {}
};

// ---------------------------------------------------------------------------
// Sistema de "tiers" (calidad del tramo). Cada vez que jugás una etapa se
// sortea un tier con estos pesos, y ese tier define tanto las estadísticas
// como el pool de narrativa del que se elige el texto.
// ---------------------------------------------------------------------------
const TIERS = [
  { key: 'excelente', weight: 15, winFactor: 0.72, playedFactor: 1, quality: 1.45 },
  { key: 'bueno', weight: 30, winFactor: 0.58, playedFactor: 1, quality: 1.15 },
  { key: 'regular', weight: 28, winFactor: 0.45, playedFactor: 1, quality: 0.9 },
  { key: 'malo', weight: 17, winFactor: 0.32, playedFactor: 0.85, quality: 0.6 },
  { key: 'lesion', weight: 10, winFactor: 0.35, playedFactor: 0.4, quality: 0.5 }
];

const NARRATIVES = {
  portero: {
    excelente: [
      { title: 'Muro infranqueable', text: 'Tapaste todo lo que te tiraron. La hinchada empezó a cantar tu nombre en cada atajada.' },
      { title: 'Temporada de oro', text: 'Tu arco se volvió un fortín. Los rivales ya sabían que ante vos, casi nada entraba.' }
    ],
    bueno: [
      { title: 'Año de confianza', text: 'Jugaste con solidez y le diste seguridad a toda la defensa durante el tramo.' },
      { title: 'Consistencia bajo los tres palos', text: 'No fuiste espectacular, pero tampoco fallaste cuando el equipo te necesitó.' }
    ],
    regular: [
      { title: 'Altibajos en el arco', text: 'Tuviste partidos brillantes y otros para el olvido. El equipo convivió con eso.' },
      { title: 'Etapa despareja', text: 'Alternaste buenas atajadas con errores que te costaron puntos.' }
    ],
    malo: [
      { title: 'Crisis de confianza', text: 'Los errores se acumularon y la hinchada empezó a dudar de vos.' },
      { title: 'Tramo para el olvido', text: 'Nada te salió como esperabas y el técnico evaluó buscar un reemplazo.' }
    ],
    lesion: [
      { title: 'Golpe físico', text: 'Una lesión te dejó afuera gran parte del tramo. Volviste con lo justo.' },
      { title: 'Recuperación lenta', text: 'El cuerpo no acompañó y pasaste más tiempo en el gimnasio que en la cancha.' }
    ]
  },
  defensa: {
    excelente: [
      { title: 'Muralla indestructible', text: 'Cortaste cada pelota que pasó por tu zona. El rival no encontraba el camino al arco.' },
      { title: 'Líder de la zaga', text: 'Organizaste la línea con autoridad y hasta aportaste goles en pelota parada.' }
    ],
    bueno: [
      { title: 'Firmeza atrás', text: 'Cumpliste con solvencia, sin sobresaltos, dándole equilibrio al equipo.' },
      { title: 'Defensor confiable', text: 'No fuiste el más vistoso, pero el técnico siempre contó con vos.' }
    ],
    regular: [
      { title: 'Marca irregular', text: 'Algunos partidos fuiste sólido, en otros te ganaron la espalda con facilidad.' },
      { title: 'Etapa de aprendizaje', text: 'Cometiste errores de posicionamiento que el rival supo aprovechar.' }
    ],
    malo: [
      { title: 'Temporada para el olvido', text: 'La línea defensiva se desordenó y vos estuviste en el centro de las críticas.' },
      { title: 'Roja que dolió', text: 'Una expulsión clave te dejó afuera en fechas decisivas.' }
    ],
    lesion: [
      { title: 'Molestia muscular', text: 'Una lesión te sacó de la titularidad justo cuando mejor estabas jugando.' },
      { title: 'Vuelta prematura', text: 'Volviste antes de tiempo y eso condicionó tu rendimiento.' }
    ]
  },
  mediocampista: {
    excelente: [
      { title: 'Motor del equipo', text: 'Manejaste los tiempos del partido como nadie y repartiste asistencias a diestra y siniestra.' },
      { title: 'Cerebro futbolístico', text: 'Tu lectura del juego fue determinante y también aportaste goles importantes.' }
    ],
    bueno: [
      { title: 'Pieza clave', text: 'Fuiste una presencia constante en el mediocampo, recuperando y distribuyendo con criterio.' },
      { title: 'Regularidad en el medio', text: 'Sin ser figura, tu trabajo silencioso sostuvo al equipo.' }
    ],
    regular: [
      { title: 'Rendimiento parejo', text: 'Alternaste buenos pasajes con partidos donde te costó encontrar el juego.' },
      { title: 'Rotación constante', text: 'El técnico te fue probando en distintas posiciones del mediocampo.' }
    ],
    malo: [
      { title: 'Pérdida de protagonismo', text: 'Tu nivel bajó y el equipo empezó a jugar sin pasar por vos.' },
      { title: 'Etapa gris', text: 'Costó encontrar continuidad y los números resintieron.' }
    ],
    lesion: [
      { title: 'Lesión inoportuna', text: 'Justo cuando agarrabas ritmo, una molestia te frenó varios meses.' },
      { title: 'Tramo interrumpido', text: 'El cuerpo pidió freno y el club prefirió cuidarte.' }
    ]
  },
  delantero: {
    excelente: [
      { title: 'Máquina de goles', text: 'Convertiste en serie y te transformaste en la pesadilla de cualquier defensa.' },
      { title: 'Temporada de ensueño', text: 'Cada vez que tocabas la pelota en el área, olía a gol.' }
    ],
    bueno: [
      { title: 'Referente de área', text: 'Convertiste con regularidad y fuiste una pieza importante en ataque.' },
      { title: 'Buen tramo goleador', text: 'No paraste de aparecer entre los delanteros con más gol del torneo.' }
    ],
    regular: [
      { title: 'Efectividad irregular', text: 'Tuviste chances claras que no siempre pudiste convertir.' },
      { title: 'Altibajos arriba', text: 'Pasaste fechas enteras sin marcar y otras siendo decisivo.' }
    ],
    malo: [
      { title: 'Sequía goleadora', text: 'Te costó horrores encontrar el arco y la crítica se hizo sentir.' },
      { title: 'Bajón de nivel', text: 'El físico y la confianza no acompañaron durante el tramo.' }
    ],
    lesion: [
      { title: 'Lesión clave', text: 'Una molestia física te dejó afuera en el mejor momento de la temporada.' },
      { title: 'Recuperación incompleta', text: 'Volviste a jugar pero sin la explosividad habitual.' }
    ]
  }
};

const SPECIAL_EVENTS = [
  '📞 Fuiste convocado a la selección nacional para un amistoso.',
  '📰 Los rumores de fichaje por un club grande llenaron los titulares.',
  '🎖️ La hinchada te reconoció con una ovación especial en el estadio.',
  '🤝 Te ofrecieron la capitanía del equipo.',
  '📸 Firmaste tu primer contrato de sponsor personal.',
  '🗣️ El técnico te destacó en conferencia de prensa como pieza clave.'
];

// ---------------------------------------------------------------------------
// Utilidades generales
// ---------------------------------------------------------------------------

function loadData() {
  try {
    if (!fs.existsSync(COPERO_FILE)) {
      fs.writeFileSync(COPERO_FILE, JSON.stringify(DEFAULT_DATA, null, 2), 'utf8');
      return JSON.parse(JSON.stringify(DEFAULT_DATA));
    }
    const raw = fs.readFileSync(COPERO_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      activeGames: parsed.activeGames || {},
      history: parsed.history || {}
    };
  } catch (error) {
    console.error('[COPERO] Error cargando copero.json:', error.message);
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function saveData(data) {
  try {
    fs.writeFileSync(COPERO_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error('[COPERO] Error guardando copero.json:', error.message);
  }
}

function normalizeText(text) {
  return String(text || '').trim().toLowerCase();
}

function getSenderNumber(message) {
  const sender = message.key?.participant || message.author || message.from;
  return String(sender || '').split('@')[0];
}

function getPlayerName(number) {
  const user = global.db?.getUser ? global.db.getUser(number) : null;
  const apodo = user?.apodo?.trim();
  if (apodo && apodo.toLowerCase() !== 'sin apodo' && apodo !== '.') {
    return apodo;
  }
  return `Jugador ${number}`;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function jitter(min, max) {
  return min + Math.random() * (max - min);
}

function pickTier(trainBonus) {
  const weights = TIERS.map((t) => {
    let w = t.weight;
    if (trainBonus) {
      if (t.key === 'excelente') w += 18;
      if (t.key === 'bueno') w += 9;
      if (t.key === 'malo') w -= 7;
      if (t.key === 'lesion') w -= 4;
    }
    return Math.max(w, 1);
  });
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < TIERS.length; i++) {
    r -= weights[i];
    if (r <= 0) return TIERS[i];
  }
  return TIERS[TIERS.length - 1];
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ---------------------------------------------------------------------------
// Generación dinámica del resultado de cada etapa
// ---------------------------------------------------------------------------

function generateStageResult(game, trainBonus) {
  const tier = pickTier(trainBonus);
  const stageIndex = game.stage;
  const basePlayed = STAGE_BASE_PLAYED[stageIndex] || 20;

  let played = Math.round(basePlayed * tier.playedFactor * jitter(0.85, 1.1));
  played = clamp(played, 4, 30);

  let saves = 0;
  let goals = 0;

  if (game.position === 'portero') {
    const savesPerMatch = 3 * tier.quality * jitter(0.85, 1.15);
    saves = Math.max(0, Math.round(savesPerMatch * played));
  } else {
    const baseGoalsSeason = POSITION_GOAL_BASE[game.position] || 4;
    goals = Math.max(0, Math.round(baseGoalsSeason * (played / 22) * tier.quality * jitter(0.8, 1.2)));
  }

  const winRatio = clamp(tier.winFactor + jitter(-0.07, 0.07), 0.05, 0.9);
  let wins = Math.round(played * winRatio);
  let remaining = played - wins;
  let losses = Math.round(remaining * jitter(0.45, 0.65));
  losses = clamp(losses, 0, remaining);
  let draws = remaining - losses;

  wins = Math.max(0, wins);
  draws = Math.max(0, draws);
  losses = Math.max(0, losses);
  const diff = played - (wins + draws + losses);
  wins = Math.max(0, wins + diff);

  const narrativePool = NARRATIVES[game.position][tier.key];
  const narrative = pickRandom(narrativePool);

  let trophy = false;
  if (tier.key === 'excelente' && played > 0 && wins / played >= 0.6 && Math.random() < 0.45) {
    trophy = true;
  }

  let special = null;
  if (Math.random() < 0.22) {
    special = pickRandom(SPECIAL_EVENTS);
  }

  return {
    tier,
    narrative,
    trophy,
    special,
    stats: { played, goals, saves, wins, draws, losses }
  };
}

function computeRating(game) {
  const played = Math.max(game.totalMatches, 1);
  const winRate = game.wins / played;
  let base = 5 + winRate * 4;
  if (game.position === 'portero') {
    base += Math.min((game.saves / played / 3), 1);
  } else {
    base += Math.min((game.goals / played) * 1.6, 1.2);
  }
  base += Math.min((game.trophies || 0) * 0.25, 1.5);
  return clamp(base, 1, 10).toFixed(1);
}

function computeCareerScore(entry) {
  return (
    (entry.goals || 0) * 2 +
    (entry.saves || 0) * 1.2 +
    (entry.wins || 0) * 3 +
    (entry.trophies || 0) * 15
  );
}

// ---------------------------------------------------------------------------
// Construcción de mensajes
// ---------------------------------------------------------------------------

function buildCareerSummary(game) {
  const lines = [
    `🏁 *Resumen de tu carrera como ${game.position}*`,
    `*Nombre:* ${game.playerName}`,
    `*Club:* ${game.club}`,
    `*Edad de retiro:* ${game.age} años`,
    `*Rating de carrera:* ${computeRating(game)}/10`,
    `*Trofeos ganados:* ${game.trophies || 0} 🏆`,
    `*Partidos jugados:* ${game.totalMatches}`,
    `*Victorias:* ${game.wins}`,
    `*Empates:* ${game.draws}`,
    `*Derrotas:* ${game.losses}`
  ];

  if (game.position === 'portero') {
    lines.push(`*Atajadas:* ${game.saves}`);
  } else {
    lines.push(`*Goles:* ${game.goals}`);
  }

  lines.push('');
  lines.push(`*Momentos destacados:*`);
  if (game.moments.length) {
    game.moments.slice(-5).forEach((item, index) => {
      lines.push(`${index + 1}. ${item}`);
    });
  } else {
    lines.push('Aún no hay momentos destacados.');
  }

  return lines.join('\n');
}

function formatGameProgress(game) {
  return (
    `⚽ *Carrera en curso* ⚽\n` +
    `─`.repeat(30) + `\n` +
    `• *Jugador:* ${game.playerName}\n` +
    `• *Posición:* ${game.position}\n` +
    `• *Club:* ${game.club || 'Sin club todavía'}\n` +
    `• *Edad actual:* ${game.age}\n` +
    `• *Fase:* ${STAGE_LABELS[game.stage] || 'Final'} (${game.stage + 1}/4)\n` +
    `• *Rating:* ${computeRating(game)}/10\n` +
    `• *Trofeos:* ${game.trophies || 0} 🏆\n` +
    `• *Partidos:* ${game.totalMatches}\n` +
    `• *Goles:* ${game.goals}\n` +
    `• *Atajadas:* ${game.saves}\n` +
    `• *Victorias:* ${game.wins}\n` +
    `• *Empates:* ${game.draws}\n` +
    `• *Derrotas:* ${game.losses}\n` +
    `• *Entrenamiento disponible:* ${game.trained ? 'Ya usado esta etapa' : 'Sí ✅'}\n` +
    `─`.repeat(30) + `\n` +
    (game.club
      ? `*Comandos:* *.copero jugar* | *.copero entrenar* | *.copero transferir <club>*`
      : `*Antes:* *.copero club NombreDelClub*`)
  );
}

function buildHelp() {
  return (
    '*🎮 Copero - Carrera futbolística*\n' +
    'Inicia tu carrera con tu posición y luego elige club.\n\n' +
    '• *.copero portero|defensa|mediocampista|delantero* — comenzar carrera\n' +
    '• *.copero club NombreDelClub* — elegir tu primer club\n' +
    '• *.copero entrenar* — mejora tus chances antes de jugar la etapa (una vez por etapa)\n' +
    '• *.copero jugar* — avanza tu carrera a la siguiente etapa\n' +
    '• *.copero transferir NuevoClub* — cambiate de club\n' +
    '• *.copero estado* — ver tu progreso actual\n' +
    '• *.copero historial* — ver tus carreras retiradas\n' +
    '• *.copero ranking* — top jugadores del salón de la fama\n' +
    '• *.copero reiniciar* — abandonar la carrera actual\n'
  );
}

function buildStageCard(game) {
  return (
    `✨ *Etapa ${game.stage + 1}/4: ${STAGE_YEARS[game.stage]} → ${STAGE_YEARS[game.stage + 1]} años* ✨\n` +
    `• *Comando:* *.copero jugar* (o *.copero entrenar* antes para mejorar tus chances)\n` +
    `• Avanza tu carrera y descubrí qué pasa con tu jugador.`
  );
}

function buildRankingMessage(data) {
  const rows = [];
  for (const [number, entries] of Object.entries(data.history)) {
    entries.forEach((entry) => {
      rows.push({ number, ...entry, score: computeCareerScore(entry) });
    });
  }

  if (!rows.length) {
    return '📉 Todavía no hay carreras retiradas para armar un ranking. ¡Sé el primero en retirarte!';
  }

  rows.sort((a, b) => b.score - a.score);
  const top = rows.slice(0, 10);

  const lines = ['🏆 *Salón de la fama - Copero* 🏆', ''];
  top.forEach((row, index) => {
    const name = getPlayerName(row.number);
    const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
    lines.push(
      `${medal} *${name}* — ${row.club} (${row.position})\n` +
        `   Score: ${row.score} | Trofeos: ${row.trophies || 0} | PJ: ${row.totalMatches}`
    );
  });

  return lines.join('\n');
}

function buildHistoryMessage(number, data) {
  const entries = data.history[number] || [];
  if (!entries.length) {
    return 'Todavía no tenés carreras retiradas. Empieza una con *.copero portero|defensa|mediocampista|delantero*';
  }
  const lines = ['📜 *Tu historial de carreras* 📜', ''];
  entries.slice(-5).reverse().forEach((entry, index) => {
    lines.push(
      `${index + 1}. *${entry.club}* (${entry.position}) — retiro a los ${entry.age} años\n` +
        `   Trofeos: ${entry.trophies || 0} | PJ: ${entry.totalMatches} | ` +
        (entry.position === 'portero' ? `Atajadas: ${entry.saves}` : `Goles: ${entry.goals}`)
    );
  });
  return lines.join('\n');
}

// ---------------------------------------------------------------------------
// Lógica de juego
// ---------------------------------------------------------------------------

function createNewGame(number, position) {
  const playerName = getPlayerName(number);
  return {
    playerNumber: number,
    playerName,
    position,
    club: null,
    age: STAGE_YEARS[0],
    stage: 0,
    totalMatches: 0,
    goals: 0,
    saves: 0,
    wins: 0,
    draws: 0,
    losses: 0,
    trophies: 0,
    trained: false,
    moments: [],
    startedAt: Date.now(),
    lastUpdated: Date.now()
  };
}

function applyStats(game, result) {
  const stats = result.stats || {};
  game.totalMatches += stats.played || 0;
  game.goals += stats.goals || 0;
  game.saves += stats.saves || 0;
  game.wins += stats.wins || 0;
  game.draws += stats.draws || 0;
  game.losses += stats.losses || 0;
  game.age = STAGE_YEARS[game.stage + 1] || game.age;
  game.stage += 1;
  game.trained = false;

  if (result.narrative) {
    game.moments.push(`${result.narrative.title}: ${result.narrative.text}`);
  }
  if (result.trophy) {
    game.trophies += 1;
    game.moments.push(`🏆 Levantaste un título con ${game.club} a los ${game.age} años.`);
  }
  if (result.special) {
    game.moments.push(result.special);
  }
  game.lastUpdated = Date.now();
}

function endGame(data, game) {
  const retirementText =
    `🏆 *¡Te retiraste a los ${game.age} años!*\n` +
    `Gracias por jugar tu carrera en ${game.club}. Rating final: ${computeRating(game)}/10`;
  const summary = buildCareerSummary(game);
  const history = data.history[game.playerNumber] || [];
  history.push({
    finishedAt: Date.now(),
    position: game.position,
    club: game.club,
    age: game.age,
    totalMatches: game.totalMatches,
    goals: game.goals,
    saves: game.saves,
    wins: game.wins,
    draws: game.draws,
    losses: game.losses,
    trophies: game.trophies || 0,
    moments: game.moments
  });
  data.history[game.playerNumber] = history;
  delete data.activeGames[game.playerNumber];
  saveData(data);
  return `${retirementText}\n\n${summary}`;
}

// ---------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------

const handler = async (message, { text }) => {
  const senderNumber = getSenderNumber(message);
  const data = loadData();
  const userGame = data.activeGames[senderNumber];

  const rawArgs = String(text || '').trim().split(/\s+/).filter(Boolean);
  const subcmd = normalizeText(rawArgs[0] || '');

  if (!subcmd) {
    if (userGame) {
      return await message.reply(formatGameProgress(userGame));
    }
    return await message.reply(buildHelp());
  }

  if (subcmd === 'estado' || subcmd === 'perfil') {
    if (!userGame) {
      return await message.reply('No tenés una carrera activa. Empieza con .copero portero|defensa|mediocampista|delantero');
    }
    return await message.reply(formatGameProgress(userGame));
  }

  if (subcmd === 'historial') {
    return await message.reply(buildHistoryMessage(senderNumber, data));
  }

  if (subcmd === 'ranking' || subcmd === 'top') {
    return await message.reply(buildRankingMessage(data));
  }

  if (subcmd === 'reiniciar' || subcmd === 'resetear') {
    if (userGame) {
      delete data.activeGames[senderNumber];
      saveData(data);
      return await message.reply('✅ Carrera reiniciada. Podés comenzar una nueva con .copero portero, defensa, mediocampista o delantero.');
    }
    return await message.reply('No tenés ninguna carrera activa para reiniciar. Usa .copero portero para comenzar.');
  }

  if (POSITIONS.includes(subcmd)) {
    if (userGame) {
      return await message.reply('Ya tenés una carrera activa. Usa .copero estado para ver tu progreso o .copero reiniciar para empezar otra.');
    }
    const game = createNewGame(senderNumber, subcmd);
    data.activeGames[senderNumber] = game;
    saveData(data);
    return await message.reply(
      `⚽ *¡Carrera iniciada!*\n` +
        `• Posición: *${game.position}*\n` +
        `• Edad actual: *${game.age}*\n` +
        `• Jugador: *${game.playerName}*\n\n` +
        `Ahora elegí tu club con:\n` +
        `*.copero club NombreDelClub*\n\n` +
        `Después avanzá tu carrera con *.copero jugar* en cada etapa (o entrená antes con *.copero entrenar*).`
    );
  }

  if (subcmd === 'club') {
    if (!userGame) {
      return await message.reply('Primero comenzá tu carrera con .copero portero|defensa|mediocampista|delantero');
    }
    if (userGame.club) {
      return await message.reply(`Ya elegiste club: *${userGame.club}*. Usa *.copero transferir NuevoClub* si querés cambiarte.`);
    }
    const clubName = rawArgs.slice(1).join(' ').trim().slice(0, 40);
    if (!clubName) {
      return await message.reply('Usa: *.copero club NombreDelClub*\nEjemplo: *.copero club Peñarol*');
    }
    userGame.club = clubName;
    userGame.lastUpdated = Date.now();
    data.activeGames[senderNumber] = userGame;
    saveData(data);
    const nextCard = buildStageCard(userGame);
    return await message.reply(
      `🏟️ Club elegido: *${clubName}*\n` +
        `¡Tu carrera comienza ahora!\n\n` +
        `${nextCard}`
    );
  }

  if (subcmd === 'transferir' || subcmd === 'transferencia') {
    if (!userGame) {
      return await message.reply('No tenés ninguna carrera activa. Empieza con .copero portero|defensa|mediocampista|delantero');
    }
    if (!userGame.club) {
      return await message.reply('Primero elegí tu club inicial con *.copero club NombreDelClub*');
    }
    const newClub = rawArgs.slice(1).join(' ').trim().slice(0, 40);
    if (!newClub) {
      return await message.reply('Usa: *.copero transferir NuevoClub*\nEjemplo: *.copero transferir Nacional*');
    }
    if (normalizeText(newClub) === normalizeText(userGame.club)) {
      return await message.reply('Ya estás en ese club 🤔');
    }
    const oldClub = userGame.club;
    userGame.club = newClub;
    userGame.moments.push(`🔄 Transferencia: pasaste de ${oldClub} a ${newClub} a los ${userGame.age} años.`);
    userGame.lastUpdated = Date.now();
    data.activeGames[senderNumber] = userGame;
    saveData(data);
    return await message.reply(`🔄 *¡Transferencia confirmada!*\nAhora jugás en *${newClub}*. Seguí tu carrera con *.copero jugar*.`);
  }

  if (subcmd === 'entrenar') {
    if (!userGame) {
      return await message.reply('No tenés ninguna carrera activa. Empieza con .copero portero|defensa|mediocampista|delantero');
    }
    if (!userGame.club) {
      return await message.reply('Primero elegí un club con .copero club NombreDelClub');
    }
    if (userGame.trained) {
      return await message.reply('Ya entrenaste para esta etapa. Usa *.copero jugar* para ver los resultados.');
    }
    userGame.trained = true;
    userGame.lastUpdated = Date.now();
    data.activeGames[senderNumber] = userGame;
    saveData(data);
    return await message.reply(
      '🏋️ *¡Entrenamiento completado!*\n' +
        'Le metiste horas extra al gimnasio y a la táctica. Tus chances de tener un buen tramo subieron para la próxima etapa.\n\n' +
        'Ahora usá *.copero jugar* para ver los resultados.'
    );
  }

  if (subcmd === 'jugar') {
    if (!userGame) {
      return await message.reply('No tenés ninguna carrera activa. Empieza con .copero portero|defensa|mediocampista|delantero');
    }
    if (!userGame.club) {
      return await message.reply('Primero elegí un club con .copero club NombreDelClub');
    }

    const previousAge = userGame.age;
    const trainBonus = userGame.trained;
    const result = generateStageResult(userGame, trainBonus);

    applyStats(userGame, result);
    data.activeGames[senderNumber] = userGame;
    saveData(data);

    let messageText =
      `🎲 *Tu destino ha hablado* (${trainBonus ? 'con entrenamiento 💪' : 'sin entrenamiento'})\n` +
      `*${result.narrative.title}*\n` +
      `${result.narrative.text}\n\n` +
      `📊 PJ: ${result.stats.played} | ` +
      (userGame.position === 'portero' ? `Atajadas: ${result.stats.saves}` : `Goles: ${result.stats.goals}`) +
      ` | G-E-P: ${result.stats.wins}-${result.stats.draws}-${result.stats.losses}\n\n` +
      `➡️ Avanzás de ${previousAge} a ${userGame.age} años.`;

    if (result.trophy) {
      messageText += `\n\n🏆 *¡Ganaste un título con ${userGame.club}!*`;
    }
    if (result.special) {
      messageText += `\n\n${result.special}`;
    }

    const isRetirement = userGame.stage >= STAGE_YEARS.length - 1;
    if (isRetirement) {
      const finalSummary = endGame(data, userGame);
      return await message.reply(`${messageText}\n\n${finalSummary}`);
    }

    const nextCard = buildStageCard(userGame);
    return await message.reply(`${messageText}\n\n${nextCard}`);
  }

  return await message.reply(buildHelp());
};

handler.command = /^(copero)$/i;
handler.help = [
  'copero <posicion>',
  'copero club <club>',
  'copero entrenar',
  'copero jugar',
  'copero transferir <club>',
  'copero estado',
  'copero historial',
  'copero ranking',
  'copero reiniciar'
];
handler.tags = ['diversion', 'juegos'];
module.exports = handler;
module.exports.apodo = true;