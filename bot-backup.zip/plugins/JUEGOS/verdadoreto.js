const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON de Verdad o Reto
const VERDADORETO_FILE = path.join(__dirname, 'verdadoreto.json');

// Cargar las preguntas y retos desde el archivo JSON
let verdadOretoData = {
    verdades: [],
    retos: []
};
try {
    verdadOretoData = JSON.parse(fs.readFileSync(VERDADORETO_FILE, 'utf8'));
    if (!Array.isArray(verdadOretoData.verdades) || !Array.isArray(verdadOretoData.retos)) {
        console.error('❌ [ERROR VERDAD O RETO] El archivo verdadoreto.json no tiene el formato esperado (arrays "verdades" y "retos").');
        verdadOretoData = { verdades: [], retos: [] };
    }
} catch (error) {
    console.error('❌ [ERROR VERDAD O RETO] No se pudo cargar verdadoreto.json o el archivo no existe. Asegúrate de crearlo.', error.message);
}

// Ruta para almacenar el estado actual del juego
const VOR_STATE_FILE = path.join(__dirname, 'vor_state.json');

// Cargar estado del juego o inicializar
let vorState = {};
try {
    vorState = JSON.parse(fs.readFileSync(VOR_STATE_FILE, 'utf8'));
} catch (error) {
    vorState = {};
}

// Función para guardar el estado del juego
function guardarVorState() {
    fs.writeFileSync(VOR_STATE_FILE, JSON.stringify(vorState, null, 2));
}

// Mapa para asegurar que las preguntas/retos no se repitan inmediatamente
const usedItems = new Map();

/**
 * Obtiene un elemento aleatorio (Verdad o Reto) que no se haya usado recientemente.
 * @param {'verdad'|'reto'} type - El tipo de elemento a obtener.
 * @returns {string|null} El elemento seleccionado o null si no hay disponibles.
 */
function getVerdadOReto(type) {
    const list = verdadOretoData[type === 'verdad' ? 'verdades' : 'retos'];
    if (list.length === 0) return null;

    let available = list.filter(item => {
        // Mantiene solo los últimos 10 elementos usados por tipo
        const recent = usedItems.get(type) || [];
        return !recent.includes(item);
    });

    // Si se usaron todos los elementos, reinicia la lista de disponibles
    if (available.length === 0) {
        available = list;
        usedItems.set(type, []);
    }

    const item = available[Math.floor(Math.random() * available.length)];

    // Actualiza la lista de usados (mantiene solo los últimos 10)
    const currentUsed = usedItems.get(type) || [];
    currentUsed.push(item);
    if (currentUsed.length > 10) {
        currentUsed.shift();
    }
    usedItems.set(type, currentUsed);
    
    return item;
}


let handler = async (message, { text, command }) => {
    try {
        // Obtener el JID del remitente y del grupo
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const chatId = message?.key?.remoteJid;

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];

        // Normalizar el comando
        const cmd = (command || '').toLowerCase();
        
        // El estado del juego se guarda por chat (chatId)
        const chatState = vorState[chatId] || {};
        const isGameActive = !!chatState.target;

        // -----------------------------------------------------------
        // 1. Comando principal: /vor @user (o /verdadoreto @user)
        // -----------------------------------------------------------
        if (cmd === 'vor' || cmd === 'verdadoreto') {
            const mentionedJids = message?.mentions;
            const subCommand = (text.split(' ')[0] || '').toLowerCase();
            const targetJid = mentionedJids?.[0];

            // 1.1 Iniciar el juego
            if (!isGameActive && targetJid && !['reto', 'verdad'].includes(subCommand)) {
                
                const targetNumber = targetJid.split('@')[0];
                
                // No se puede iniciar a sí mismo
                if (targetNumber === senderNumber) {
                    return await message.reply('❌ No puedes retarte a ti mismo. ¡Menciona a otro usuario!');
                }
                
                // Guardar el estado de la partida
                vorState[chatId] = {
                    starter: senderNumber,
                    starterJid: senderJid,
                    target: targetNumber,
                    targetJid: targetJid,
                    startTime: Date.now()
                };
                guardarVorState();

                const mentions = [senderJid, targetJid];
                
                return await message.reply(
                    '🌟 *VERDAD O RETO* 😈\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `*¡@${targetNumber}*, has sido retado por *@${senderNumber}*!\n\n` +
                    '*Elige una opción respondiendo con:*\n' +
                    '👉 `/vor verdad @' + senderNumber + '` - *Para elegir una Verdad*\n' +
                    '👉 `/vor reto @' + senderNumber + '` - *Para elegir un Reto*',
                    { mentions }
                );
            }
            
            // 1.2 Sub-comando: /vor reto @user o /vor verdad @user
            else if (isGameActive && (subCommand === 'reto' || subCommand === 'verdad')) {
                
                const currentTargetNumber = chatState.target;
                const currentStarterNumber = chatState.starter;

                // Verificar que la persona que responde es la retada
                if (senderNumber !== currentTargetNumber) {
                    return await message.reply('❌ *Solo el usuario retado* (@' + currentTargetNumber + ') puede responder la elección.', { mentions: [chatState.targetJid] });
                }
                
                // Verificar que se haya mencionado al iniciador
                if (!targetJid || targetJid.split('@')[0] !== currentStarterNumber) {
                    return await message.reply(`❌ Debes mencionar al usuario que te retó: *@${currentStarterNumber}*`, { mentions: [chatState.starterJid] });
                }

                // Generar y enviar Verdad/Reto
                const choiceType = subCommand; // 'reto' o 'verdad'
                const item = getVerdadOReto(choiceType);
                const itemType = choiceType === 'verdad' ? 'Verdad' : 'Reto';
                
                // Eliminar el estado de la partida
                delete vorState[chatId];
                guardarVorState();

                if (!item) {
                     return await message.reply(`❌ Lo siento, no tengo ${choiceType}s disponibles en este momento.`);
                }
                
                const mentions = [senderJid, targetJid];

                return await message.reply(
                    `*¡HAS ELEGIDO ${itemType.toUpperCase()}!* 🎯\n` +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `*@${currentTargetNumber}, tu ${itemType} es:*\n\n` +
                    `_"${item}"_ \n\n` +
                    `_¡Ahora, @${currentTargetNumber}, responde o cumple tu castigo!_ 😈`,
                    { mentions }
                );

            }
            
            // 1.3 Mostrar estado del juego
            else if (isGameActive && !targetJid) {
                 const timeLimit = chatState.startTime + (1 * 60 * 60 * 1000); // 1 hora de tiempo limite
                 if (Date.now() > timeLimit) {
                     delete vorState[chatId];
                     guardarVorState();
                     return await message.reply('❌ La partida anterior de Verdad o Reto ha expirado. Puedes iniciar una nueva.');
                 }
                return await message.reply(
                    '⚠️ *PARTIDA ACTIVA* ⚠️\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `*Iniciador:* @${chatState.starter}\n` +
                    `*Retado:* @${chatState.target}\n\n` +
                    `*@${chatState.target}* debe responder con:\n` +
                    '👉 `/vor verdad @' + chatState.starter + '`\n' +
                    '👉 `/vor reto @' + chatState.starter + '`',
                    { mentions: [chatState.starterJid, chatState.targetJid] }
                );
            }
            
            // 1.4 Comando inválido o sin mención
            else {
                return await message.reply(
                    '🎲 *COMANDOS VERDAD O RETO* 🎲\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    '👉 */vor @usuario* o */verdadoreto @usuario* - _Inicia el juego retando a alguien_\n\n' +
                    '*Si eres el retado, responde con:*\n' +
                    '👉 */vor verdad @usuario_que_reto* - _Elige una Verdad_\n' +
                    '👉 */vor reto @usuario_que_reto* - _Elige un Reto_'
                );
            }
        }
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de Verdad o Reto:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['vor', 'verdadoreto', 'vor verdad', 'vor reto'];
handler.tags = ['juegos'];
handler.command = /^(vor|verdadoreto)$/i;

module.exports = handler;