const fs   = require('fs');
const path = require('path');

const duelosActivos = new Map();
const jugadoresOcupados = new Map();

const TIEMPO_ACEPTAR = 60000; // 60s para aceptar
const TIEMPO_JUGAR   = 90000; // 90s para registrar jugada
const opciones = ['piedra', 'papel', 'tijera'];

// ── Cargar configuración de subbots ─────────────────────────────────────
const SUBBOTS_DATA_DIR = path.join(__dirname, '..', 'SUBBOTS', 'data');
const RESPONDER_FILE = path.join(SUBBOTS_DATA_DIR, 'subbot-responder.json');
const ONOFF_FILE = path.join(SUBBOTS_DATA_DIR, 'subbot-onoff.json');

function loadResponderConfig() {
    try {
        if (fs.existsSync(RESPONDER_FILE)) {
            return JSON.parse(fs.readFileSync(RESPONDER_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[PPT] Error cargando responder.json:', e.message);
    }
    return {};
}

function loadOnOffConfig() {
    try {
        if (fs.existsSync(ONOFF_FILE)) {
            return JSON.parse(fs.readFileSync(ONOFF_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('[PPT] Error cargando onoff.json:', e.message);
    }
    return {};
}

// Verificar si el bot/subbot responde en privados
function canRespondInPrivate(botNum) {
    if (!botNum) return true; // Sin número = bot principal, siempre responde
    const data = loadResponderConfig();
    const config = data[String(botNum)];
    return !config || config.priv !== false;
}

// Verificar si el bot/subbot está apagado globalmente
function isGloballyEnabled(botNum) {
    if (!botNum) return true; // Sin número = bot principal, siempre está activo
    const data = loadOnOffConfig();
    return data[`global_${botNum}`] !== false;
}

// ── utilidades ─────────────────────────────────────────────────────────────
function extraerNumero(jid) {
    return jid?.split('@')[0].split(':')[0] || '';
}
function compararJids(a, b) {
    return extraerNumero(a) === extraerNumero(b);
}
function generarIdDuelo(chatId, r, o) {
    return `${chatId}_${r}_${o}`;
}
function determinarGanador(o1, o2) {
    if (o1 === o2) return 'empate';
    const gana = { piedra: 'tijera', papel: 'piedra', tijera: 'papel' };
    return gana[o1] === o2 ? 'jugador1' : 'jugador2';
}
const emojis = { piedra: '🪨', papel: '📄', tijera: '✂️' };

// ── handler ─────────────────────────────────────────────────────────────────
const handler = async (message, { text, conn }) => {
    try {
        const sock = conn || global.conn;
        const chatId = message.from;
        const esGrupo = chatId.endsWith('@g.us');

        const senderJid = esGrupo
            ? message?.key?.participant || message?.author || message?.sender
            : message?.key?.remoteJid || message?.author || message?.sender || message.from;

        if (!senderJid) return message.reply('❌ No se pudo identificar al remitente.');

        const args    = text?.trim().toLowerCase().split(/\s+/) || [];
        const subcmd  = args[0];
        const senderN = extraerNumero(senderJid);

        // ── DESAFIAR ─────────────────────────────────────────────────────────
        if (!subcmd || subcmd.startsWith('@')) {
            if (!esGrupo) return message.reply('❌ Solo puedes desafiar en grupos.');

            // ── VERIFICAR PRIVADOS Y ESTADO GLOBAL ────────────────────────────
            const botNum = sock?._subNum; // Número del subbot (undefined si es bot principal)
            
            if (!canRespondInPrivate(botNum)) {
                const instrs = botNum 
                    ? `El owner del subbot debe activar los privados:\n💬 *.bot priv on*`
                    : `El admin debe activar los privados.\n💬 Contacta con el owner del bot.`;
                
                return message.reply(
                    `❌ *No se puede iniciar el duelo.*\n\n` +
                    `📵 El bot tiene los chats privados desactivados.\n\n` +
                    `🔧 Solución:\n${instrs}\n\n` +
                    `ℹ️ Los jugadores necesitan enviar sus jugadas en privado.`
                );
            }

            if (!isGloballyEnabled(botNum)) {
                return message.reply(
                    `❌ *No se puede iniciar el duelo.*\n\n` +
                    `⚡ El bot está apagado globalmente.\n\n` +
                    `🔧 El owner del bot debe reactivarlo:\n💬 *.bot encender*`
                );
            }

            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona a alguien.\n💡 Ej: .ppt @usuario');
            const target = mentioned[0];
            if (compararJids(senderJid, target)) return message.reply('❌ No puedes desafiarte a ti mismo.');

            const retadorN  = senderN;
            const oponenteN = extraerNumero(target);

            if (jugadoresOcupados.has(retadorN))  return message.reply('❌ Ya estás en un duelo.');
            if (jugadoresOcupados.has(oponenteN))
                return message.reply(`❌ @${oponenteN} ya está en un duelo.`, { mentions: [target] });

            const dueloId = generarIdDuelo(chatId, retadorN, oponenteN);
            const duelo = {
                id: dueloId, chatId,
                retador: senderJid, oponente: target,
                retadorN, oponenteN,
                estado: 'pendiente',
                respuestas: new Map()
            };

            duelosActivos.set(dueloId, duelo);
            jugadoresOcupados.set(retadorN, chatId);
            jugadoresOcupados.set(oponenteN, chatId);

            await message.reply(
                `🎮 *DUELO DE PIEDRA, PAPEL O TIJERA*\n\n` +
                `@${retadorN} desafió a @${oponenteN}!\n\n` +
                `⏱️ @${oponenteN} tienes *60s* para responder:\n` +
                `• *.ppt aceptar @${retadorN}*\n` +
                `• *.ppt rechazar @${retadorN}*`,
                { mentions: [senderJid, target] }
            );

            duelo.timeout = setTimeout(async () => {
                if (duelo.estado === 'pendiente') {
                    jugadoresOcupados.delete(duelo.retadorN);
                    jugadoresOcupados.delete(duelo.oponenteN);
                    duelosActivos.delete(dueloId);
                    await sock.sendMessage(chatId, {
                        text: `⏰ Tiempo agotado. @${oponenteN} no aceptó el duelo.`,
                        mentions: [senderJid, target]
                    });
                }
            }, TIEMPO_ACEPTAR);
            return;
        }

        // ── ACEPTAR ──────────────────────────────────────────────────────────
        if (subcmd === 'aceptar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona al retador.\n💡 Ej: *.ppt aceptar @usuario*');

            const retadorN = extraerNumero(mentioned[0]);
            const dueloId  = generarIdDuelo(chatId, retadorN, senderN);
            const duelo    = duelosActivos.get(dueloId);

            if (!duelo) return message.reply(`❌ No tienes ningún duelo pendiente de @${retadorN}.`);
            if (duelo.estado !== 'pendiente') return message.reply('❌ Ya fue procesado.');

            duelo.estado = 'activo';
            clearTimeout(duelo.timeout);

            await message.reply(
                `✅ *¡Duelo aceptado!*\n\n` +
                `@${duelo.retadorN} ⚔️ @${duelo.oponenteN}\n\n` +
                `📲 Ambos vayan al *privado del bot* y registren su jugada:\n` +
                `• *.ppt piedra*\n` +
                `• *.ppt papel*\n` +
                `• *.ppt tijera*\n\n` +
                `⏱️ Tienen *90 segundos*. El resultado se anunciará aquí.`,
                { mentions: [duelo.retador, duelo.oponente] }
            );

            duelo.timeout = setTimeout(async () => {
                const r1 = duelo.respuestas.get(duelo.retadorN);
                const r2 = duelo.respuestas.get(duelo.oponenteN);
                let msg = '⏰ *Tiempo agotado*\n\n';

                if (!r1 && !r2) {
                    msg += 'Nadie registró su jugada. El duelo se cancela.';
                } else if (!r1) {
                    msg += `@${duelo.retadorN} no jugó. 🏆 Gana @${duelo.oponenteN}!`;
                } else {
                    msg += `@${duelo.oponenteN} no jugó. 🏆 Gana @${duelo.retadorN}!`;
                }

                jugadoresOcupados.delete(duelo.retadorN);
                jugadoresOcupados.delete(duelo.oponenteN);
                duelosActivos.delete(dueloId);

                await sock.sendMessage(chatId, { text: msg, mentions: [duelo.retador, duelo.oponente] });
            }, TIEMPO_JUGAR);
            return;
        }

        // ── RECHAZAR ─────────────────────────────────────────────────────────
        if (subcmd === 'rechazar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona al retador.\n💡 Ej: *.ppt rechazar @usuario*');

            const retadorN = extraerNumero(mentioned[0]);
            const dueloId  = generarIdDuelo(chatId, retadorN, senderN);
            const duelo    = duelosActivos.get(dueloId);

            if (!duelo) return message.reply(`❌ No tienes ningún duelo pendiente de @${retadorN}.`);

            clearTimeout(duelo.timeout);
            jugadoresOcupados.delete(duelo.retadorN);
            jugadoresOcupados.delete(duelo.oponenteN);
            duelosActivos.delete(dueloId);

            await message.reply(`🚫 @${senderN} rechazó el duelo.`, { mentions: [senderJid] });
            return;
        }

        // ── CANCELAR ─────────────────────────────────────────────────────────
        if (subcmd === 'cancelar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');

            let duelo = null, dueloId = null;
            for (const [id, d] of duelosActivos) {
                if (d.chatId === chatId && (d.retadorN === senderN || d.oponenteN === senderN)) {
                    duelo = d; dueloId = id; break;
                }
            }
            if (!duelo) return message.reply('❌ No tienes duelos activos en este grupo.');

            clearTimeout(duelo.timeout);
            jugadoresOcupados.delete(duelo.retadorN);
            jugadoresOcupados.delete(duelo.oponenteN);
            duelosActivos.delete(dueloId);

            await message.reply(`🚫 @${senderN} canceló el duelo.`, { mentions: [senderJid] });
            return;
        }

        // ── REGISTRAR JUGADA (en privado) ─────────────────────────────────────
        if (opciones.includes(subcmd)) {
            if (esGrupo) return message.reply('📲 Envía tu jugada al bot en *privado*, no en el grupo.');

            // Buscar duelo activo donde participe este usuario
            let duelo = null, dueloId = null;
            for (const [id, d] of duelosActivos) {
                if (d.estado === 'activo' && (d.retadorN === senderN || d.oponenteN === senderN)) {
                    duelo = d; dueloId = id; break;
                }
            }
            if (!duelo) return message.reply('❌ No estás en ningún duelo activo.');
            if (duelo.respuestas.has(senderN)) return message.reply('⚠️ Ya registraste tu jugada. Esperando al otro jugador...');

            duelo.respuestas.set(senderN, subcmd);
            const total = duelo.respuestas.size;

            message.reply(`✅ Jugada registrada: *${subcmd}* ${emojis[subcmd]}${total === 1 ? '\n⏳ Esperando al otro jugador...' : ''}`);

            // Ambos jugaron → anunciar resultado en el grupo
            if (total === 2) {
                clearTimeout(duelo.timeout);

                const r1 = duelo.respuestas.get(duelo.retadorN);
                const r2 = duelo.respuestas.get(duelo.oponenteN);
                const resultado = determinarGanador(r1, r2);

                let msg =
                    `🎮 *RESULTADO DEL DUELO*\n\n` +
                    `${emojis[r1]} @${duelo.retadorN}: *${r1}*\n` +
                    `${emojis[r2]} @${duelo.oponenteN}: *${r2}*\n\n`;

                if (resultado === 'empate')    msg += '🤝 ¡Empate!';
                else if (resultado === 'jugador1') msg += `🏆 ¡Gana @${duelo.retadorN}!`;
                else                           msg += `🏆 ¡Gana @${duelo.oponenteN}!`;

                jugadoresOcupados.delete(duelo.retadorN);
                jugadoresOcupados.delete(duelo.oponenteN);
                duelosActivos.delete(dueloId);

                await sock.sendMessage(duelo.chatId, {
                    text: msg,
                    mentions: [duelo.retador, duelo.oponente]
                });
            }
            return;
        }

        // ── AYUDA ─────────────────────────────────────────────────────────────
        await message.reply(
            `❓ Uso incorrecto.\n\n` +
            `*En el grupo:*\n` +
            `• *.ppt @usuario* — Desafiar\n` +
            `• *.ppt aceptar @usuario* — Aceptar duelo\n` +
            `• *.ppt rechazar @usuario* — Rechazar duelo\n` +
            `• *.ppt cancelar* — Cancelar tu duelo activo\n\n` +
            `*En privado (tras aceptar):*\n` +
            `• *.ppt piedra / papel / tijera*`
        );
    } catch (err) {
        console.error('[PPT ERROR]', err);
        message.reply('❌ Error interno en el comando.');
    }
};

handler.command = /^(ppt)$/i;
handler.help = [
    '🎮 *Piedra, Papel o Tijera*',
    '• .ppt @usuario — Desafiar en grupo',
    '• .ppt aceptar @usuario — Aceptar duelo',
    '• .ppt rechazar @usuario — Rechazar duelo',
    '• .ppt cancelar — Cancelar tu duelo activo',
    '• En privado: .ppt piedra | papel | tijera'
];
handler.tags = ['diversion', 'juegos'];

module.exports = handler;
