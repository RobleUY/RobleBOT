const fs = require('fs');
const path = require('path');

// Almacenar duelos activos por chat
const duelosActivos = new Map();
// Almacenar jugadores ocupados (solo 1 duelo a la vez)
const jugadoresOcupados = new Map();

const TIEMPO_ACEPTAR = 60000; // 60s
const TIEMPO_RESPONDER = 60000; // 60s
const opciones = ['piedra', 'papel', 'tijera'];

// Obtener número real desde jid o @lid
async function obtenerNumeroReal(jid, chatId, conn) {
    if (!jid) return '';
    const numeroBase = jid.split('@')[0].split(':')[0];
    if (!jid.includes('@lid')) return numeroBase;

    if (chatId && chatId.endsWith('@g.us')) {
        try {
            const groupMeta = await conn.groupMetadata(chatId);
            const participant = groupMeta.participants.find(p => p.id === jid);
            if (participant?.jid) return participant.jid.split('@')[0];
        } catch (error) {
            console.error('[REAL NUM] Error al buscar:', error.message);
        }
    }
    return numeroBase;
}

// Utilidades
function extraerNumero(jid) {
    return jid?.split('@')[0].split(':')[0] || '';
}
function compararJids(a, b) {
    return extraerNumero(a) === extraerNumero(b);
}
function estaJugadorOcupado(num) {
    return jugadoresOcupados.has(num);
}
function marcarJugadorOcupado(num, chatId) {
    jugadoresOcupados.set(num, chatId);
}
function liberarJugador(num) {
    jugadoresOcupados.delete(num);
}
function generarIdDuelo(chatId, r, o) {
    return `${chatId}_${r}_${o}`;
}
function determinarGanador(o1, o2) {
    if (o1 === o2) return 'empate';
    const gana = { piedra: 'tijera', papel: 'piedra', tijera: 'papel' };
    return gana[o1] === o2 ? 'jugador1' : 'jugador2';
}

// =============================
// HANDLER PRINCIPAL
// =============================
const handler = async (message, { text, command: cmd, conn }) => {
    try {
        const sock = conn || message._sock || global.conn;
        const chatId = message.from;
        const esGrupo = chatId.endsWith('@g.us');
        const senderJid = esGrupo
            ? message?.key?.participant || message?.author || message?.sender
            : message?.key?.remoteJid || message?.author || message?.sender || message.from;

        if (!senderJid) return message.reply('❌ No se pudo identificar al remitente.');
        const args = text?.trim().toLowerCase().split(/\s+/) || [];
        const subcomando = args[0];

        // DESAFIAR
        if (!subcomando || subcomando.startsWith('@')) {
            if (!esGrupo) return message.reply('❌ Solo puedes desafiar en grupos.');

            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona a alguien.\n💡 Ej: /ppt @usuario');
            const target = mentioned[0];
            if (compararJids(senderJid, target)) return message.reply('❌ No puedes desafiarte a ti mismo.');

            const retadorReal = await obtenerNumeroReal(senderJid, chatId, sock);
            const oponenteReal = await obtenerNumeroReal(target, chatId, sock);
            if (estaJugadorOcupado(retadorReal)) return message.reply('❌ Ya estás en un duelo.');
            if (estaJugadorOcupado(oponenteReal))
                return message.reply(`❌ @${oponenteReal} ya está en un duelo.`, { mentions: [target] });

            const dueloId = generarIdDuelo(chatId, retadorReal, oponenteReal);
            const duelo = {
                id: dueloId,
                chatId,
                retador: senderJid,
                oponente: target,
                retadorReal,
                oponenteReal,
                estado: 'pendiente',
                respuestas: new Map()
            };

            duelosActivos.set(dueloId, duelo);
            marcarJugadorOcupado(retadorReal, chatId);
            marcarJugadorOcupado(oponenteReal, chatId);

            const msg = `🎮 *DUELO DE PIEDRA, PAPEL O TIJERA*\n\n` +
                `@${extraerNumero(senderJid)} desafió a @${extraerNumero(target)}!\n\n` +
                `⏱️ Tiene 60s para responder:\n` +
                `• /ppt aceptar @${extraerNumero(senderJid)}\n` +
                `• /ppt rechazar @${extraerNumero(senderJid)}`;
            await message.reply(msg, { mentions: [senderJid, target] });

            duelo.timeout = setTimeout(async () => {
                if (duelo.estado === 'pendiente') {
                    liberarJugador(duelo.retadorReal);
                    liberarJugador(duelo.oponenteReal);
                    duelosActivos.delete(dueloId);
                    await sock.sendMessage(chatId, {
                        text: `⏰ Tiempo agotado, @${extraerNumero(target)} no aceptó.`,
                        mentions: [senderJid, target]
                    });
                }
            }, TIEMPO_ACEPTAR);
            return;
        }

        // ACEPTAR
        if (subcomando === 'aceptar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');
            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona al retador.');

            const retadorMencionado = mentioned[0];
            const senderReal = await obtenerNumeroReal(senderJid, chatId, sock);
            const retadorReal = await obtenerNumeroReal(retadorMencionado, chatId, sock);

            const dueloId = generarIdDuelo(chatId, retadorReal, senderReal);
            const duelo = duelosActivos.get(dueloId);
            if (!duelo) return message.reply('❌ No hay duelo pendiente.');
            if (duelo.estado !== 'pendiente') return message.reply('❌ Ya aceptado o rechazado.');

            duelo.estado = 'activo';
            clearTimeout(duelo.timeout);

            await message.reply(
                `✅ *Duelo aceptado*\n\n@${extraerNumero(duelo.retador)} vs @${extraerNumero(duelo.oponente)}\n\n📩 Ambos recibirán mensaje privado.`,
                { mentions: [duelo.retador, duelo.oponente] }
            );

            const mensajePrivado = `🎮 *Tu turno*\nUsa:\n• /ppt piedra\n• /ppt papel\n• /ppt tijera\n\n⏱️ 60s`;
            await sock.sendMessage(duelo.retador, { text: mensajePrivado });
            await sock.sendMessage(duelo.oponente, { text: mensajePrivado });

            duelo.timeout = setTimeout(async () => {
                const r1 = duelo.respuestas.get(duelo.retadorReal);
                const r2 = duelo.respuestas.get(duelo.oponenteReal);
                let msg = '⏰ *Tiempo agotado*\n\n';
                if (!r1 && !r2) msg += 'Nadie respondió.';
                else if (!r1) msg += `@${extraerNumero(duelo.retador)} no respondió. Gana @${extraerNumero(duelo.oponente)}!`;
                else msg += `@${extraerNumero(duelo.oponente)} no respondió. Gana @${extraerNumero(duelo.retador)}!`;

                liberarJugador(duelo.retadorReal);
                liberarJugador(duelo.oponenteReal);
                duelosActivos.delete(dueloId);

                await sock.sendMessage(chatId, { text: msg, mentions: [duelo.retador, duelo.oponente] });
            }, TIEMPO_RESPONDER);
            return;
        }

        // RECHAZAR
        if (subcomando === 'rechazar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');
            const mentioned = message?.mentions;
            if (!mentioned?.length) return message.reply('❌ Menciona al retador.');

            const retadorMencionado = mentioned[0];
            const senderReal = await obtenerNumeroReal(senderJid, chatId, sock);
            const retadorReal = await obtenerNumeroReal(retadorMencionado, chatId, sock);
            const dueloId = generarIdDuelo(chatId, retadorReal, senderReal);
            const duelo = duelosActivos.get(dueloId);
            if (!duelo) return message.reply('❌ No hay duelo pendiente.');
            if (duelo.estado !== 'pendiente') return message.reply('❌ Ya procesado.');

            clearTimeout(duelo.timeout);
            liberarJugador(duelo.retadorReal);
            liberarJugador(duelo.oponenteReal);
            duelosActivos.delete(dueloId);

            await message.reply(`🚫 @${extraerNumero(senderJid)} rechazó el duelo.`, { mentions: [senderJid] });
            return;
        }

        // CANCELAR
        if (subcomando === 'cancelar') {
            if (!esGrupo) return message.reply('❌ Solo en grupos.');
            const senderReal = await obtenerNumeroReal(senderJid, chatId, sock);
            let dueloEncontrado = null, dueloId = null;
            for (const [id, duelo] of duelosActivos) {
                if (duelo.chatId === chatId && (duelo.retadorReal === senderReal || duelo.oponenteReal === senderReal)) {
                    dueloEncontrado = duelo; dueloId = id; break;
                }
            }
            if (!dueloEncontrado) return message.reply('❌ No tienes duelos activos.');
            clearTimeout(dueloEncontrado.timeout);
            liberarJugador(dueloEncontrado.retadorReal);
            liberarJugador(dueloEncontrado.oponenteReal);
            duelosActivos.delete(dueloId);
            await message.reply(`🚫 @${extraerNumero(senderJid)} canceló el duelo.`, { mentions: [senderJid] });
            return;
        }

        // JUGADAS EN PRIVADO
        if (opciones.includes(subcomando)) {
            if (esGrupo) return message.reply('❌ Envía tu jugada al bot en privado.');
            const senderReal = extraerNumero(senderJid);
            let dueloEncontrado = null, dueloId = null;
            for (const [id, duelo] of duelosActivos) {
                if (duelo.estado === 'activo' && (senderReal === duelo.retadorReal || senderReal === duelo.oponenteReal)) {
                    dueloEncontrado = duelo; dueloId = id; break;
                }
            }
            if (!dueloEncontrado) return message.reply('❌ No estás en un duelo.');
            if (dueloEncontrado.respuestas.has(senderReal)) return message.reply('❌ Ya enviaste tu jugada.');

            dueloEncontrado.respuestas.set(senderReal, subcomando);
            const total = dueloEncontrado.respuestas.size;
            message.reply(`✅ Jugada registrada: *${subcomando}*${total === 1 ? '\n⏳ Esperando al otro...' : ''}`);

            if (total === 2) {
                clearTimeout(dueloEncontrado.timeout);
                const r1 = dueloEncontrado.respuestas.get(dueloEncontrado.retadorReal);
                const r2 = dueloEncontrado.respuestas.get(dueloEncontrado.oponenteReal);
                const resultado = determinarGanador(r1, r2);
                const emojis = { piedra: '🪨', papel: '📄', tijera: '✂️' };

                let msg = `🎮 *RESULTADO*\n\n${emojis[r1]} @${extraerNumero(dueloEncontrado.retador)}: *${r1}*\n${emojis[r2]} @${extraerNumero(dueloEncontrado.oponente)}: *${r2}*\n\n`;
                if (resultado === 'empate') msg += '🤝 ¡Empate!';
                else if (resultado === 'jugador1') msg += `🏆 Gana @${extraerNumero(dueloEncontrado.retador)}!`;
                else msg += `🏆 Gana @${extraerNumero(dueloEncontrado.oponente)}!`;

                liberarJugador(dueloEncontrado.retadorReal);
                liberarJugador(dueloEncontrado.oponenteReal);
                duelosActivos.delete(dueloId);

                await sock.sendMessage(dueloEncontrado.chatId, { text: msg, mentions: [dueloEncontrado.retador, dueloEncontrado.oponente] });
            }
            return;
        }

        await message.reply('❌ Comando inválido.\nUsa /ppt @usuario, /ppt aceptar @usuario, /ppt rechazar @usuario o /ppt cancelar.');
    } catch (err) {
        console.error('[PPT ERROR]', err);
        message.reply('❌ Error en el comando.');
    }
};

// ✅ Propiedades que el handler espera
handler.command = /^(ppt)$/i;
handler.help = [
  '🎮 *Piedra, Papel o Tijera*',
  '• /ppt @usuario - Desafiar',
  '• /ppt aceptar @usuario - Aceptar',
  '• /ppt rechazar @usuario - Rechazar',
  '• /ppt cancelar - Cancelar',
  '• En privado: /ppt piedra, /ppt papel o /ppt tijera'
];
handler.tags = ['diversion', 'juegos'];

module.exports = handler;
