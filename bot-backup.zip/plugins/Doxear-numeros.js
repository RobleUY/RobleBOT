let handler = async (message, { text }) => {
  try {
    if (!text || !text.trim()) {
      return await message.reply(
        '📱 *Información de número*\n\n' +
        'Uso:\n' +
        '*.infonum1 +598XXXXXXXX*'
      );
    }

    // Limpiar espacios, guiones y paréntesis
    const numero = text.trim().replace(/[\s()-]/g, '');

    // Debe contener solamente + y números
    if (!/^\+?[0-9]+$/.test(numero)) {
      return await message.reply(
        '❌ Número inválido.\n\n' +
        'Ejemplo: *.infonum1 +598XXXXXXXX*'
      );
    }

    // La API quiere el número sin el "+"
    const numeroAPI = numero.replace(/^\+/, '');

    await message.reply('🔎 Consultando información del número...');

    const url = `https://calltracer.io/api/lookup/${encodeURIComponent(numeroAPI)}`;

    const response = await fetch(url);

    if (!response.ok) {
      console.error(
        `[infonum1] API respondió HTTP ${response.status}`
      );

      return await message.reply(
        '❌ La API no pudo consultar ese número.'
      );
    }

    const data = await response.json();

    if (!data || data.is_valid === false) {
      return await message.reply(
        '❌ El número no parece ser válido.'
      );
    }

    // Datos principales
    const numeroMostrar =
      data.international ||
      data.number ||
      `+${numeroAPI}`;

    const pais =
      data.country ||
      'Desconocido';

    const codigoPais =
      data.country_iso ||
      'Desconocido';

    const tipo =
      data.number_type ||
      'Desconocido';

    const operador =
      data.carrier ||
      'No disponible';

    const ubicacion =
      data.location ||
      'No disponible';

    const zonas =
      Array.isArray(data.timezones) && data.timezones.length
        ? data.timezones.join(', ')
        : 'No disponible';

    // Información de reportes
    const reports = data.reports || {};

    const spamScore =
      typeof reports.spam_score === 'number'
        ? `${reports.spam_score}/100`
        : 'Sin datos';

    const totalReports =
      typeof reports.total === 'number'
        ? reports.total
        : 0;

    let mensaje =
      `📱 *INFORMACIÓN DEL NÚMERO*\n\n` +
      `☎️ *Número:* ${numeroMostrar}\n` +
      `🌎 *País:* ${pais}\n` +
      `🏳️ *Código:* ${codigoPais}\n` +
      `📞 *Tipo:* ${tipo}\n` +
      `📡 *Operador:* ${operador}\n` +
      `📍 *Ubicación:* ${ubicacion}\n` +
      `🕐 *Zona horaria:* ${zonas}\n\n` +
      `🛡️ *SPAM*\n` +
      `📊 *Puntuación:* ${spamScore}\n` +
      `🚨 *Reportes:* ${totalReports}`;

    return await message.reply(mensaje);

  } catch (error) {
    console.error('[infonum1] Error:', error);

    return await message.reply(
      '❌ Ocurrió un error al consultar el número.'
    );
  }
};

handler.help = ['infonum1 <número>'];
handler.tags = ['tools'];
handler.command = /^numdox$/i;

module.exports = handler;