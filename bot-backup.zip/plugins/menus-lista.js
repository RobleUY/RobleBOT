const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

if (!global.LastUpdate) {
    global.LastUpdate = {
        timestamp: Date.now(),
        getTimestamp() {
            return this.timestamp;
        },
        timeSince(timestamp) {
            const diff = Math.floor((Date.now() - timestamp) / 1000);
            if (diff < 60) return `${diff} segundos`;
            const mins = Math.floor(diff / 60);
            if (mins < 60) return `${mins} minutos`;
            const hrs = Math.floor(mins / 60);
            if (hrs < 24) return `${hrs} horas`;
            const days = Math.floor(hrs / 24);
            return `${days} días`;
        }
    };
}

const more = String.fromCharCode(8206);
const readMore = more.repeat(4000);

// === FUNCIÓN PARA OBTENER STATS DEL BOT ===
async function getBotStats(conn) {
    let totalGroups = 0;
    let totalParticipants = 0;

    try {
        let groups = [];
        let groupsData = {};

        if (typeof conn.groupFetchAllParticipating === 'function') {
            groupsData = await conn.groupFetchAllParticipating();
            groups = Object.keys(groupsData);
        } else if (conn.chats && typeof conn.chats === 'object') {
            groups = Object.entries(conn.chats)
                .filter(([jid, chat]) => jid.endsWith('@g.us'))
                .map(([jid]) => jid);
        }

        totalGroups = groups.length;
        for (const jid of groups) {
            const groupInfo = groupsData[jid];
            totalParticipants += groupInfo?.participants?.length || 0;
        }
    } catch (e) {
        console.error('[ERROR] No se pudo obtener stats:', e.message);
    }

    const lastTimestamp = LastUpdate.getTimestamp();
    const timeSince = LastUpdate.timeSince(lastTimestamp);
    
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    return {
        totalGroups,
        totalParticipants: totalParticipants + 100,
        timeSince,
        uptimeFormatted
    };
}

// === ENCABEZADO COMÚN PARA TODOS LOS MENÚS ===
function getMenuHeader(usedPrefix, stats) {
    return `
╔═════ ≪ 🤖 ≫ ═════
║   *ROBLEBOT*
║
║  👑 *Creador:* RobleUY
║  ⏰ *Última actualización:*
║          _Hace ${stats.timeSince}_
║  ⏳ *Bot activo hace:*
║          _${stats.uptimeFormatted}_
╚══════════════

*Prefijo:* \`${usedPrefix}\`
*Usa:* ${usedPrefix}menus _para ver todos los menús_
──────────────
${readMore}`;
}

// ============================================
// === MENÚ PRINCIPAL (LISTA DE MENÚS) ===
// ============================================
async function getMenusList(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    
    return `
╔═════ ≪ 📋 ≫ ═════
║   *LISTA DE MENÚS DISPONIBLES*
║
║  👑 *Creador:* RobleUY
║  ⏰ *Última actualización:*
║          _Hace ${stats.timeSince}_
║  ⏳ *Bot activo hace:*
║          _${stats.uptimeFormatted}_
╚══════════════

*Usa el prefijo \`${usedPrefix}\` + el comando del menú*

╔═════════════════
║  *📱 MENÚS PRINCIPALES*
╚═════════════════
*1️⃣ Menu Completo*
\`${usedPrefix}menu\`
> Ver el menu completo.

*1️⃣ Descargas*
\`${usedPrefix}menudownload\`
> Multimedia, YouTube, TikTok, Instagram, etc.

*2️⃣ Economía*
\`${usedPrefix}menueconomia\`
> Banco, trabajo, préstamos, transferencias

*3️⃣ Casino*
\`${usedPrefix}menucasino\`
> Juegos de azar, apuestas, ruleta, dados

*4️⃣ Perfil*
\`${usedPrefix}menuperfil\`
> Perfil, nivel, pareja, redes sociales, rankup

*5️⃣ Coleccionables*
\`${usedPrefix}menucoleccion\`
> Futbolistas y personajes de anime

*6️⃣ Juegos*
\`${usedPrefix}menujuegos\`
> Entretenimiento, duelos, adivinanzas

*7️⃣ Random*
\`${usedPrefix}menurandom\`
> Interacciones, calculadoras, diversión

*8️⃣ Imágenes*
\`${usedPrefix}menuimagen\`
> Generación IA, búsqueda, stickers

*9️⃣ NSFW +18*
\`${usedPrefix}menunsfW\`
> Contenido adulto (usar con responsabilidad)

*🔟 Herramientas*
\`${usedPrefix}menutools\`
> IA, edición, conversión, clima

*1️⃣1️⃣ Admin*
\`${usedPrefix}menuadmin\`
> Gestión de grupos (solo admins)

*1️⃣2️⃣ Ayuda*
\`${usedPrefix}menuayuda\`
> Soporte, reportes, sugerencias

──────────────
*✨ ROBLEBOT • v2.0*
_Developed BY: RobleUY_`;
}

// ============================================
// === MENÚ DESCARGAS ===
// ============================================
async function getMenuDownload(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ ⬇️ ≫ ═════
║   *MULTIMEDIA Y DESCARGAS*
╚══════════════

*🔗 Descarga General*
\`${usedPrefix}descargar <link>\`
> Descargá imagenes/videos de redes sociales

*🎬 YouTube*
\`${usedPrefix}ytvideo <título|link>\`
> Descargá videos de YouTube

\`${usedPrefix}ytaudio <título|link>\`
> Descargá audios (MP3) de YouTube

\`${usedPrefix}ytsearch <título>\`
> Buscá videos en YouTube

*🎶 TikTok*
\`${usedPrefix}tiktok <link>\`
> Descargá videos sin marca de agua

\`${usedPrefix}tiktoks <texto|random>\`
> Descargá hasta 5 videos

\`${usedPrefix}ttsearch <título>\`
> Buscá videos en TikTok

*📸 Otras Redes*
\`${usedPrefix}instagram <link>\`
> Descargá de Instagram

\`${usedPrefix}facebook <link>\`
> Descargá de Facebook

\`${usedPrefix}threads <link>\`
> Descargá de Threads

\`${usedPrefix}twitter <link>\`
> Descargá de Twitter

*📱 Apps*
\`${usedPrefix}apk <nombre>\`
> Buscá y descargá aplicaciones

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ ECONOMÍA ===
// ============================================
async function getMenuEconomia(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 💰 ≫ ═════
║   *ECONOMÍA Y BANCO*
╚══════════════

*💼 Cuentas*
\`${usedPrefix}saldo\`
> Verificá tu saldo actual

\`${usedPrefix}depositar <cant|all>\`
> Depositá coins al banco

\`${usedPrefix}retirar <cant|all>\`
> Retirá coins del banco

\`${usedPrefix}darcoins @user <cant>\`
> Transferí coins a otro usuario

*🛠️ Trabajo y Recompensas*
\`${usedPrefix}trabajar\`
> Realizá un trabajo

\`${usedPrefix}estudiar\`
> Estudia y recibe monedas

\`${usedPrefix}slut\`
> Vende tu cuerpo por monedas

\`${usedPrefix}minar\`
> Miná para obtener coins

\`${usedPrefix}cazar\`
> Salí de cacería

\`${usedPrefix}cadadia\`
> Recompensa diaria

*🏦 Préstamos*
\`${usedPrefix}prestamo <cant>\`
> Solicitá un préstamo

\`${usedPrefix}prestamo pagar <cant|todo>\`
> Pagá tu préstamo

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ CASINO ===
// ============================================
async function getMenuCasino(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🎰 ≫ ═════
║   *CASINO Y APUESTAS*
╚══════════════

*🃏 Juegos de Mesa*
\`${usedPrefix}caraocruz <cara|cruz> <cant|all>\`
> Cara o cruz clásico

\`${usedPrefix}bj <cant|all>\`
> BlackJack (21)

\`${usedPrefix}ruleta <color> <cant|all>\`
> Ruleta (rojo/negro/verde)

\`${usedPrefix}dados <tipo> <cant|all>\`
> Tirada de dados

*🎲 Azar*
\`${usedPrefix}apostar <cant|all>\`
> Apuesta contra el bot

\`${usedPrefix}apostar @user <cant>\`
> Duelo de apuestas

\`${usedPrefix}slot <cant|all>\`
> Máquina tragamonedas

\`${usedPrefix}race <cant|all>\`
> Carrera

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ PERFIL ===
// ============================================
async function getMenuPerfil(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 👤 ≫ ═════
║   *PERFIL Y SOCIAL*
╚══════════════

*✨ Perfil*
\`${usedPrefix}perfil\`
> Muestra tu perfil completo

\`${usedPrefix}nivel\`
> Muestra tu nivel y XP

\`${usedPrefix}genero <hombre|mujer>\`
> Cambia tu género

\`${usedPrefix}apodo <texto>\`
> Cambia tu apodo

*💪 Rankup*
\`${usedPrefix}rankup\`
> Sube de rango

\`${usedPrefix}ranks\`
> Lista de rangos

\`${usedPrefix}rank\`
> Tu rango actual

*❤️ Parejas*
\`${usedPrefix}pareja <estado|pedir|aceptar|rechazar|romper>\`
> Gestiona tu estado civil

*📱 Redes Sociales*
\`${usedPrefix}redes\`
> Muestra tus redes

\`${usedPrefix}redes tiktok|instagram <usuario>\`
> Registra tu usuario

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ COLECCIONABLES ===
// ============================================
async function getMenuColeccion(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ ⚽🧠 ≫ ═════
║   *COLECCIONABLES*
╚══════════════

*⚽ FUTBOLISTAS*

_Acciones:_
\`${usedPrefix}fpj reclamar\`
> Reclama futbolista diario

\`${usedPrefix}myfpj\`
> Tus futbolistas

_Comercio:_
\`${usedPrefix}fpj vender <nombre> <cant|all>\`
> Vende futbolistas

\`${usedPrefix}fpj regalar @user <nombre>\`
> Regala un futbolista

\`${usedPrefix}fpj intercambio @user <mi_fp> <su_fp>\`
> Propone intercambio

*🧠 PERSONAJES ANIME*

_Acciones:_
\`${usedPrefix}pj reclamar\`
> Reclama personaje diario

\`${usedPrefix}mypj\`
> Tus personajes

_Comercio:_
\`${usedPrefix}pj vender <nombre> <cant|all>\`
> Vende personajes

\`${usedPrefix}pj regalar @user <nombre>\`
> Regala un personaje

\`${usedPrefix}pj intercambio @user <mi_pj> <su_pj>\`
> Propone intercambio

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ JUEGOS ===
// ============================================
async function getMenuJuegos(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🎮 ≫ ═════
║   *JUEGOS Y ENTRETENIMIENTO*
╚══════════════

*⚔️ Duelos*
\`${usedPrefix}ppt @user\`
> Piedra, Papel o Tijera

*❓ Adivinanzas*
\`${usedPrefix}describe\`
> Adivina la palabra oculta

\`${usedPrefix}emoji\`
> Adivina por emojis

\`${usedPrefix}completar\`
> Completa la frase

\`${usedPrefix}ordenar\`
> Ordena la palabra

\`${usedPrefix}trivia\`
> Cultura general

*🔮 Oráculos*
\`${usedPrefix}quien <texto>\`
> Elige un usuario del grupo

\`${usedPrefix}siono <texto>\`
> Responde sí o no

\`${usedPrefix}elegir <op1> o <op2>\`
> Ayuda a elegir

\`${usedPrefix}kprefieres <op1 o op2>\`
> Dilema "Qué Prefieres"

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ RANDOM ===
// ============================================
async function getMenuRandom(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🤣 ≫ ═════
║   *RANDOM E INTERACCIONES*
╚══════════════

*💖 Interacciones*
\`${usedPrefix}love <@user>\`
> Calcula el amor

\`${usedPrefix}ship <@user1> y <@user2>\`
> Calcula el shippeo

\`${usedPrefix}abrazar @user\`
> Abraza a alguien

\`${usedPrefix}besar @user\`
> Besa a alguien

\`${usedPrefix}matar @user\`
> Mata a alguien

\`${usedPrefix}golpear @user\`
> Golpea a alguien

\`${usedPrefix}follar @user\`
> Acción +18

*🔢 Calculadoras*
\`${usedPrefix}calcular1|2|3 <texto>\`
> Calculadoras de humor

*🤪 Diversión*
\`${usedPrefix}ego\`
> Frase de ego

\`${usedPrefix}drama\`
> Frase de drama

\`${usedPrefix}quiero <texto>\`
> Pide algo gracioso

\`${usedPrefix}kprefieres\`
> Dilema aleatorio

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ IMÁGENES ===
// ============================================
async function getMenuImagen(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🖼️ ≫ ═════
║   *IMÁGENES Y STICKERS*
╚══════════════

*🎨 Generación y Búsqueda*
\`${usedPrefix}imagenia <texto>\`
> Crea imágenes con IA

\`${usedPrefix}imagen <texto>\`
> Busca en Google

\`${usedPrefix}pinterest <texto>\`
> Busca en Pinterest

*📦 Colecciones*
\`${usedPrefix}waifu\`
> Imagen waifu aleatoria

\`${usedPrefix}bts\`
> Imagen BTS aleatoria

\`${usedPrefix}blackpink\`
> Imagen BlackPink aleatoria

*🔄 Conversión*
\`${usedPrefix}toimg\`
> Sticker a imagen

*🪅 Stickers*
\`${usedPrefix}sticker\`
> Crea sticker (img/video)

\`${usedPrefix}brat <texto>\`
> Sticker Brat Style

\`${usedPrefix}emojimix <2 emojis>\`
> Combina emojis

\`${usedPrefix}tts <texto>\`
> Texto a sticker simple

\`${usedPrefix}tts <texto> <color> <fondo>\`
> Sticker personalizado

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ NSFW ===
// ============================================
async function getMenuNSFW(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🔞 ≫ ═════
║   *CONTENIDO +18 (NSFW)*
╚══════════════

⚠️ *Contenido para adultos*
_Usa bajo tu responsabilidad_

*🎥 Videos*
\`${usedPrefix}xnxx <título|link>\`
> Busca y descarga de XNXX

\`${usedPrefix}hentaiv\`
> Video Hentai aleatorio

*🔞 Imágenes*
\`${usedPrefix}tetas\`
> Imagen aleatoria

\`${usedPrefix}hotgirl\`
> Chica sexy aleatoria

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ HERRAMIENTAS ===
// ============================================
async function getMenuTools(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🔧 ≫ ═════
║   *HERRAMIENTAS Y UTILITIES*
╚══════════════

*🧠 Inteligencia Artificial*
\`${usedPrefix}ia <texto>\`
> Conversa con IA

\`${usedPrefix}iavoz <texto>\`
> Respuesta en voz

\`${usedPrefix}tradai <texto + idioma>\`
> Traduce con IA

*✂️ Edición*
\`${usedPrefix}efecto\`
> Efectos de audio

\`${usedPrefix}removebg\`
> Remueve fondo de imagen

\`${usedPrefix}leer\`
> Transcribe audio/documento

\`${usedPrefix}tav <texto>\`
> Texto a voz

*📡 Stalkers*
\`${usedPrefix}ytstalk <usuario>\`
> Info de YouTube

\`${usedPrefix}ttstalk <usuario>\`
> Info de TikTok

\`${usedPrefix}igstalk <usuario>\`
> Info de Instagram

*☁️ Otros*
\`${usedPrefix}clima <ciudad y país>\`
> Clima actual

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ ADMIN ===
// ============================================
async function getMenuAdmin(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 🛠️ ≫ ═════
║   *ADMINISTRACIÓN DE GRUPO*
╚══════════════

*ℹ️ Info y Links*
\`${usedPrefix}infog\`
> Info del grupo

\`${usedPrefix}link\`
> Enlace de invitación

*✍️ Edición*
\`${usedPrefix}nameg <texto>\`
> Cambia nombre del grupo

\`${usedPrefix}desc <texto>\`
> Cambia descripción

*👥 Miembros*
\`${usedPrefix}kick @user\`
> Expulsa un miembro

\`${usedPrefix}op @user\`
> Nombra administrador

\`${usedPrefix}deop @user\`
> Remueve admin

*🔒 Apertura/Cierre*
\`${usedPrefix}close\`
> Cierra el grupo

\`${usedPrefix}open\`
> Abre el grupo

──────────────
_Usa ${usedPrefix}menus para ver otros menús_`;
}

// ============================================
// === MENÚ AYUDA ===
// ============================================
async function getMenuAyuda(conn, usedPrefix = '.') {
    const stats = await getBotStats(conn);
    const header = getMenuHeader(usedPrefix, stats);
    
    return `${header}
╔═════ ≪ 💡 ≫ ═════
║   *AYUDA Y SOPORTE*
╚══════════════

*❓ Asistencia General*
\`${usedPrefix}ayuda <texto>\`
> Pregunta lo que necesites
_Ej: ${usedPrefix}ayuda como ganar dinero_

*🏘 Agregar Bot*
\`${usedPrefix}join <link>\`
> Solicitud para unir bot a grupo

*⚠️ Reportes*
\`${usedPrefix}reporte <texto>\`
> Reporta errores o bugs

*📝 Sugerencias*
\`${usedPrefix}sugerencia <texto>\`
> Envía ideas de mejora

──────────────
*✨ ROBLEBOT • v2.0*
_Developed BY: RobleUY_

_Usa ${usedPrefix}menus para ver todos los menús_`;
}

// ============================================
// === HANDLERS ===
// ============================================

// Handler menú principal (lista)
let handlerMenus = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenusList(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menus:', error);
        return await message.reply('❌ Error al mostrar menús.');
    }
};

handlerMenus.help = ['menus'];
handlerMenus.tags = ['info'];
handlerMenus.command = /^(menus|menús|listamenus)$/i;

// Handler descargas
let handlerDownload = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuDownload(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menudownload:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerDownload.help = ['menudownload'];
handlerDownload.tags = ['descargas'];
handlerDownload.command = /^(menudownload|menudescargas|menudl)$/i;

// Handler economía
let handlerEconomia = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuEconomia(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menueconomia:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerEconomia.help = ['menueconomia'];
handlerEconomia.tags = ['economia'];
handlerEconomia.command = /^(menueconomia|menuecon|menubank)$/i;

// Handler casino
let handlerCasino = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuCasino(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menucasino:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerCasino.help = ['menucasino'];
handlerCasino.tags = ['casino'];
handlerCasino.command = /^(menucasino|menuapuestas)$/i;

// Handler perfil
let handlerPerfil = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuPerfil(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menuperfil:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerPerfil.help = ['menuperfil'];
handlerPerfil.tags = ['perfil'];
handlerPerfil.command = /^(menuperfil|menusocial)$/i;

// Handler coleccionables
let handlerColeccion = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuColeccion(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menucoleccion:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerColeccion.help = ['menucoleccion'];
handlerColeccion.tags = ['coleccion'];
handlerColeccion.command = /^(menucoleccion|menucoleccionables)$/i;

// Handler juegos
let handlerJuegos = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuJuegos(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menujuegos:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerJuegos.help = ['menujuegos'];
handlerJuegos.tags = ['juegos'];
handlerJuegos.command = /^(menujuegos|menugames)$/i;

// Handler random
let handlerRandom = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuRandom(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menurandom:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerRandom.help = ['menurandom'];
handlerRandom.tags = ['random'];
handlerRandom.command = /^(menurandom|menufun)$/i;

// Handler imágenes
let handlerImagen = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuImagen(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menuimagen:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerImagen.help = ['menuimagen'];
handlerImagen.tags = ['imagen'];
handlerImagen.command = /^(menuimagen|menuimg|menusticker)$/i;

// Handler NSFW
let handlerNSFW = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuNSFW(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menunsfW:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerNSFW.help = ['menunsfW'];
handlerNSFW.tags = ['nsfw'];
handlerNSFW.command = /^(menunsfW|menu18|menuadult)$/i;

// Handler herramientas
let handlerTools = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuTools(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menutools:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerTools.help = ['menutools'];
handlerTools.tags = ['tools'];
handlerTools.command = /^(menutools|menuherramientas|menuutil)$/i;

// Handler admin
let handlerAdmin = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuAdmin(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menuadmin:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerAdmin.help = ['menuadmin'];
handlerAdmin.tags = ['admin'];
handlerAdmin.command = /^(menuadmin|menugroup)$/i;

// Handler ayuda
let handlerAyuda = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuAyuda(conn, usedPrefix);
        await message.reply(menuText);
    } catch (error) {
        console.error('[ERROR] menuayuda:', error);
        return await message.reply('❌ Error al mostrar menú.');
    }
};

handlerAyuda.help = ['menuayuda'];
handlerAyuda.tags = ['ayuda'];
handlerAyuda.command = /^(menuayuda|menuhelp|menusoporte)$/i;

// ============================================
// === EXPORTAR TODOS LOS HANDLERS ===
// ============================================

module.exports = {
    // Menú principal
    menus: handlerMenus,
    
    // Menús específicos
    download: handlerDownload,
    economia: handlerEconomia,
    casino: handlerCasino,
    perfil: handlerPerfil,
    coleccion: handlerColeccion,
    juegos: handlerJuegos,
    random: handlerRandom,
    imagen: handlerImagen,
    nsfw: handlerNSFW,
    tools: handlerTools,
    admin: handlerAdmin,
    ayuda: handlerAyuda
};