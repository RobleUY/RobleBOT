const { loadStats } = require('../botStatsRecorder');

let handler = async (message, { conn }) => {
    try {
        const stats = loadStats();
        const now = Date.now();
        const cutoff24h = now - 24 * 60 * 60 * 1000;

        // Comandos
        const totalCommands = stats.totalCommands || 0;
        const commandsLast24h = Array.isArray(stats.commandLog)
            ? stats.commandLog.filter(t => t > cutoff24h).length
            : 0;

        // Usuarios
        const usersObj = stats.users || {};
        const totalUsers = Object.keys(usersObj).length;
        const usersLast24h = Object.values(usersObj).filter(u => u.lastSeen > cutoff24h).length;

        // Grupos y participantes en tiempo real
        let totalGroups = 0;
        let totalParticipants = 0;
        try {
            const socket = conn || global.conn;
            if (socket) {
                const chats = await socket.groupFetchAllParticipating();
                const groupEntries = Object.values(chats);
                totalGroups = groupEntries.length;
                totalParticipants = groupEntries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
            }
        } catch (e) {
            const dbStats = global.db?.getStats?.() || {};
            totalGroups = dbStats.totalGroups || 0;
        }

        const text =
            `╔══════════════════════╗\n` +
            `║   📊 *ESTADÍSTICAS DEL BOT*   ║\n` +
            `╚══════════════════════╝\n\n` +
            `⚡ *Comandos ejecutados*\n` +
            `├ Total: *${totalCommands.toLocaleString()}*\n` +
            `└ Últimas 24h: *${commandsLast24h.toLocaleString()}*\n\n` +
            `👥 *Usuarios*\n` +
            `├ Total: *${totalUsers.toLocaleString()}*\n` +
            `└ Últimas 24h: *${usersLast24h.toLocaleString()}*\n\n` +
            `🏘️ *Grupos*\n` +
            `├ Grupos activos: *${totalGroups.toLocaleString()}*\n` +
            `└ Participantes totales: *${totalParticipants.toLocaleString()}*`;

        await message.reply(text);
    } catch (error) {
        console.error('[botstats] Error:', error.message);
        await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['stats', 'statsbot', 'botstats'];
handler.tags = ['info'];
handler.command = /^(stats|statsbot|botstats)$/i;

module.exports = handler;
