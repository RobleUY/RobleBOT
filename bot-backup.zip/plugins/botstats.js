const { loadStats } = require('../botStatsRecorder');

// Filtra solo grupos válidos de un mapa de chats
function filterGroups(chats) {
    return Object.values(chats).filter(g => {
        return g.id.endsWith('@g.us') &&
               !g.id.includes('@newsletter') &&
               g.announce !== true;
    });
}

let handler = async (message, { conn }) => {
    try {
        const stats = loadStats();

        // Comandos
        const totalCommands = stats.totalCommands || 0;

        // Usuarios
        let totalUsers = 0;
        if (global.db?.data?.users) {
            totalUsers = Object.keys(global.db.data.users).length;
        }

        // Usamos un Map<jid, participantCount> para deduplicar grupos entre bots
        // El primer bot que reporte un grupo "gana" el conteo de participantes
        const uniqueGroupsMap = new Map();

        // --- Bot principal ---
        let mainGroups = 0;
        let mainParticipants = 0;
        try {
            const socket = conn || global.conn;
            if (socket) {
                const chats = await socket.groupFetchAllParticipating();
                const entries = filterGroups(chats);
                mainGroups = entries.length;
                mainParticipants = entries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
                for (const g of entries) {
                    uniqueGroupsMap.set(g.id, g.participants?.length || 0);
                }
            }
        } catch (e) {
            console.error('[stats] Error obteniendo grupos bot principal:', e.message);
        }

        // --- Sub-bots ---
        const activeSubbots = (global.subConns || []).filter(c => c.user);
        const subbotsCount = activeSubbots.length;
        let subbotsGroups = 0;
        let subbotsParticipants = 0;

        for (const subbot of activeSubbots) {
            try {
                const chats = await subbot.groupFetchAllParticipating();
                const entries = filterGroups(chats);
                subbotsGroups += entries.length;
                subbotsParticipants += entries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
                for (const g of entries) {
                    // Solo agrega si no fue ya contado por otro bot
                    if (!uniqueGroupsMap.has(g.id)) {
                        uniqueGroupsMap.set(g.id, g.participants?.length || 0);
                    }
                }
            } catch (e) {
                console.error(`[stats] Error obteniendo grupos subbot #${subbot._subNum}:`, e.message);
            }
        }

        // Totales reales (sin duplicados entre bots)
        const totalGroups = uniqueGroupsMap.size;
        const totalParticipants = [...uniqueGroupsMap.values()].reduce((sum, n) => sum + n, 0);

        const text =
            `╔══════════════════════╗\n` +
            `║   📊 *ESTADÍSTICAS DEL BOT*   ║\n` +
            `╚══════════════════════╝\n\n` +
            `⚡ *Comandos ejecutados*\n` +
            `└ Total: *${totalCommands.toLocaleString()}*\n\n` +
            `👥 *Usuarios*\n` +
            `└ Total: *${totalUsers.toLocaleString()}*\n\n` +
            `🤖 *Bots activos*\n` +
            `├ Bot principal: *1*\n` +
            `└ Sub-bots: *${subbotsCount}*\n\n` +
            `🏘️ *Grupos*\n` +
            `├ Bot principal: *${mainGroups.toLocaleString()}*\n` +
            `├ Sub-bots: *${subbotsGroups.toLocaleString()}*\n` +
            `└ Total único: *${totalGroups.toLocaleString()}*\n\n` +
            `👥 *Participantes en grupos*\n` +
            `├ Bot principal: *${mainParticipants.toLocaleString()}*\n` +
            `├ Sub-bots: *${subbotsParticipants.toLocaleString()}*\n` +
            `└ Total único: *${totalParticipants.toLocaleString()}*`;

        await message.reply(text);
    } catch (error) {
        console.error('[botstats] Error:', error.message);
        await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['stats', 'statsbot', 'botstats'];
handler.tags = ['info'];
handler.command = /^(stats|statsbot|botstats)$/i;

module.exports = handler;
