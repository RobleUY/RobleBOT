const { loadStats } = require('../botStatsRecorder');

let handler = async (message, { conn }) => {
    try {
        const stats = loadStats();

        // Comandos
        const totalCommands = stats.totalCommands || 0;

        // Usuarios
        const usersObj = stats.users || {};
        const totalUsers = Object.keys(usersObj).length;

        // Grupos y participantes del bot principal
        let mainGroups = 0;
        let mainParticipants = 0;
        try {
            const socket = conn || global.conn;
            if (socket) {
                const chats = await socket.groupFetchAllParticipating();
                const groupEntries = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                });
                mainGroups = groupEntries.length;
                mainParticipants = groupEntries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
            }
        } catch (e) {
            console.error('[stats] Error obteniendo grupos bot principal:', e.message);
        }

        // Subbots activos y sus grupos
        const activeSubbots = (global.subConns || []).filter(c => c.user);
        const subbotsCount = activeSubbots.length;
        let subbotsGroups = 0;
        let subbotsParticipants = 0;

        for (const subbot of activeSubbots) {
            try {
                const chats = await subbot.groupFetchAllParticipating();
                const groupEntries = Object.values(chats).filter(g => {
                    const jid = g.id;
                    if (jid.includes('@newsletter')) return false;
                    if (g.announce === true) return false;
                    return jid.endsWith('@g.us');
                });
                subbotsGroups += groupEntries.length;
                subbotsParticipants += groupEntries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
            } catch (e) {
                console.error(`[stats] Error obteniendo grupos subbot #${subbot._subNum}:`, e.message);
            }
        }

        const totalGroups = mainGroups + subbotsGroups;
        const totalParticipants = mainParticipants + subbotsParticipants;

        const text =
            `╔══════════════════════╗\n` +
            `║   📊 *ESTADÍSTICAS DEL BOT*   ║\n` +
            `╚══════════════════════╝\n\n` +
            `⚡ *Comandos ejecutados*\n` +
            `└ Total: *${totalCommands.toLocaleString()}*\n\n` +
            `👥 *Usuarios*\n` +
            `└ Total: *${totalUsers.toLocaleString()}*\n\n` +
            `🤖 *Bots activos*\n` +
            `├ Bot principal: *1*\n` +
            `└ Sub-bots: *${subbotsCount}*\n\n` +
            `🏘️ *Grupos*\n` +
            `├ Bot principal: *${mainGroups.toLocaleString()}*\n` +
            `├ Sub-bots: *${subbotsGroups.toLocaleString()}*\n` +
            `└ Total: *${totalGroups.toLocaleString()}*\n\n` +
            `👥 *Participantes en grupos*\n` +
            `├ Bot principal: *${mainParticipants.toLocaleString()}*\n` +
            `├ Sub-bots: *${subbotsParticipants.toLocaleString()}*\n` +
            `└ Total: *${totalParticipants.toLocaleString()}*`;

        await message.reply(text);
    } catch (error) {
        console.error('[botstats] Error:', error.message);
        await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['stats', 'statsbot', 'botstats'];
handler.tags = ['info'];
handler.command = /^(stats|statsbot|botstats)$/i;

module.exports = handler;