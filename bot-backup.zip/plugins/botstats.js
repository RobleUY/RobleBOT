const { loadStats } = require('../botStatsRecorder');
const { getCachedGroups, getCachedUsers } = require('../statsCache');

let handler = async (message, { conn }) => {
    try {
        const stats = loadStats();

        // Comandos
        const totalCommands = stats.totalCommands || 0;

        // Usuarios desde caché (se refresca cada 5 min, lee global.db)
        const totalUsers = getCachedUsers();

        // Grupos desde caché (se refresca cada 10 min, sin llamadas a la API aquí)
        const { totalGroups, totalParticipants } = getCachedGroups();

        // Conteos individuales por bot (del caché no tenemos desglose, así que los
        // calculamos rápido desde los datos ya en memoria — sin fetch a la API)
        const activeSubbots = (global.subConns || []).filter(c => c.user);
        const subbotsCount = activeSubbots.length;

        const text =
            `╔══════════════════════╗\n` +
            `║   📊 *ESTADÍSTICAS DEL BOT*   ║\n` +
            `╚══════════════════════╝\n\n` +
            `⚡ *Comandos ejecutados*\n` +
            `└ Total: *${totalCommands.toLocaleString()}*\n\n` +
            `👥 *Usuarios*\n` +
            `└ Total: *${totalUsers.toLocaleString()}*\n\n` +
            `🤖 *Bots activos*\n` +
            `├ Bot principal: *1*\n` +
            `└ Sub-bots: *${subbotsCount}*\n\n` +
            `🏘️ *Grupos únicos*\n` +
            `└ Total: *${totalGroups.toLocaleString()}*\n\n` +
            `👥 *Participantes en grupos*\n` +
            `└ Total: *${totalParticipants.toLocaleString()}*`;

        await message.reply(text);
    } catch (error) {
        console.error('[botstats] Error:', error.message);
        await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['stats', 'statsbot', 'botstats'];
handler.tags = ['info'];
handler.command = /^(stats|statsbot|botstats)$/i;

module.exports = handler;
