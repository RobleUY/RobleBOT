const { getGroqApiKeys } = require('../lib/apiKeys.js');
const KEYS = getGroqApiKeys();

const ESTILOS = [
    'de suspenso', 'de fantasía', 'romántico', 'de terror ligero',
    'de ciencia ficción', 'costumbrista', 'de humor', 'melancólico',
    'de aventura', 'con un giro inesperado al final', 'onírico y surrealista',
    'de misterio'
];

let handler = async (message, { text }) => {
    try {
        const input = text?.trim();
        const estilo = ESTILOS[Math.floor(Math.random() * ESTILOS.length)];

        const userPrompt = input
            ? `Escribe un cuento corto ${estilo}, a partir de esto que te escribo (puede ser un tema, un personaje, un lugar, una idea suelta — interpretalo vos y usalo como base): "${input}".`
            : `Escribe un cuento corto ${estilo}, sobre cualquier tema que se te ocurra. Sorpréndeme, no repitas ideas obvias.`;

        const systemPrompt = `Eres un narrador creativo experto en escribir cuentos cortos originales.
Cada cuento debe tener un inicio, desarrollo y final claros, con buena narrativa, en español.
Extensión ideal: entre 150 y 300 palabras, nunca más de 350.
Interpretá libremente lo que el usuario escriba como punto de partida: tema, personaje, lugar, emoción, palabra suelta, etc.
Cada cuento debe ser distinto al anterior: variá personajes, ambientación, tono y estructura.
Ponele un título corto al cuento, en negrita usando doble asterisco, en la primera línea.
Responde ÚNICAMENTE con el título y el cuento, sin explicaciones antes ni después, sin comentarios meta como "aquí tienes tu cuento".`;

        let historia = '';
        try {
            const iaModule = require('./HERRAMIENTAS/ia/ia');
            const callIA = iaModule.callIA || iaModule;
            if (typeof callIA === 'function') {
                const res = await callIA(systemPrompt, userPrompt);
                if (res && res !== '_SILENT_FAIL_') historia = res;
            }
        } catch (e) {
            console.warn('[historias] callIA falló, probando Groq directo:', e.message);
        }

        if (!historia) {
            const apiKey = KEYS[Math.floor(Math.random() * KEYS.length)];
            const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'llama-3.3-70b-versatile',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userPrompt }
                    ],
                    temperature: 1.1,
                    top_p: 0.95,
                    max_tokens: 700
                })
            });

            const data = await res.json();
            if (!data.choices || data.choices.length === 0) {
                throw new Error('No se recibió respuesta válida de la API');
            }
            historia = data.choices[0].message.content.trim();
        }

        await message.reply(`📖 *HISTORIA*\n\n${historia.trim()}`);
    } catch (error) {
        console.error('[ERROR] historia:', error);
        await message.reply('❌ Ocurrió un error al generar la historia o el servicio está saturado.');
    }
};

handler.help = ['historia', 'historia <tema, personaje o lo que quieras>'];
handler.tags = ['fun'];
handler.command = /^(historia|historias|history|cuento)$/i;

module.exports = handler;