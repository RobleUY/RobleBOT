const fs = require('fs');
const path = require('path');

// Ruta del archivo para almacenar los datos
const MASCOTAS_FILE = path.join(__dirname, 'mascotas.json');
let mascotas = cargarMascotas();

// Cargar y guardar en tiempo real (sin reiniciar)
function cargarMascotas() {
    try {
        if (fs.existsSync(MASCOTAS_FILE)) {
            return JSON.parse(fs.readFileSync(MASCOTAS_FILE, 'utf8'));
        }
    } catch (e) {
        console.error('Error al cargar mascotas.json:', e);
    }
    return {};
}

function guardarMascotas() {
    try {
        const dir = path.dirname(MASCOTAS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(MASCOTAS_FILE, JSON.stringify(mascotas, null, 2));
    } catch (e) {
        console.error('Error al guardar mascotas.json:', e);
    }
}

// Diccionario de animales disponibles (Inglés y Español)
const ANIMALES_MAP = {
    // Perros y similares
    'perro': '🐶', 'dog': '🐶',
    'caniche': '🐩', 'poodle': '🐩',
    'lobo': '🐺', 'wolf': '🐺',
    'zorro': '🦊', 'fox': '🦊',

    // Gatos y felinos
    'gato': '🐱', 'cat': '🐱',
    'tigre': '🐯', 'tiger': '🐯',
    'leon': '🦁', 'lion': '🦁',
    'pantera': '🐆', 'panther': '🐆',
    'leopardo': '🐆', 'leopard': '🐆',
    'jaguar': '🐆',
    'guepardo': '🐆', 'cheetah': '🐆',

    // Roedores
    'raton': '🐭', 'mouse': '🐭',
    'rata': '🐀', 'rat': '🐀',
    'hamster': '🐹',
    'castor': '🦫', 'beaver': '🦫',
    'ardilla': '🐿️', 'squirrel': '🐿️',

    // Conejos
    'conejo': '🐰', 'rabbit': '🐰',

    // Osos
    'oso': '🐻', 'bear': '🐻',
    'panda': '🐼',
    'koala': '🐨',

    // Vacas y granja
    'vaca': '🐮', 'cow': '🐮',
    'buey': '🐂', 'ox': '🐂',
    'toro': '🐂', 'bull': '🐂',
    'bufalo': '🐃', 'buffalo': '🐃',
    'cerdo': '🐷', 'pig': '🐷',
    'chancho': '🐷',
    'jabali': '🐗', 'boar': '🐗',
    'oveja': '🐑', 'sheep': '🐑',
    'carnero': '🐏', 'ram': '🐏',
    'cabra': '🐐', 'goat': '🐐',
    'caballo': '🐴', 'horse': '🐴',
    'burro': '🫏', 'donkey': '🫏',
    'camello': '🐫', 'camel': '🐫',
    'llama': '🦙', 'alpaca': '🦙',

    // Monos
    'mono': '🐵', 'monkey': '🐵',
    'orangutan': '🦧',
    'gorila': '🦍', 'gorilla': '🦍',

    // Aves
    'pajaro': '🐦', 'bird': '🐦',
    'pollo': '🐔', 'chicken': '🐔',
    'gallina': '🐔', 'hen': '🐔',
    'gallo': '🐓', 'rooster': '🐓',
    'pato': '🦆', 'duck': '🦆',
    'cisne': '🦢', 'swan': '🦢',
    'pinguino': '🐧', 'penguin': '🐧',
    'paloma': '🕊️', 'dove': '🕊️',
    'aguila': '🦅', 'eagle': '🦅',
    'buho': '🦉', 'owl': '🦉',
    'flamenco': '🦩', 'flamingo': '🦩',
    'pavo': '🦃', 'turkey': '🦃',
    'loro': '🦜', 'parrot': '🦜',
    'pavo real': '🦚', 'peacock': '🦚',

    // Reptiles
    'tortuga': '🐢', 'turtle': '🐢',
    'serpiente': '🐍', 'snake': '🐍',
    'lagarto': '🦎', 'lizard': '🦎',
    'cocodrilo': '🐊', 'crocodile': '🐊',
    'dragon': '🐉',
    'dinosaurio': '🦖', 'dinosaur': '🦖',

    // Anfibios
    'rana': '🐸', 'frog': '🐸',

    // Marinos
    'pez': '🐟', 'fish': '🐟',
    'pez tropical': '🐠', 'tropical fish': '🐠',
    'blowfish': '🐡',
    'delfin': '🐬', 'dolphin': '🐬',
    'ballena': '🐋', 'whale': '🐋',
    'orca': '🐋',
    'tiburon': '🦈', 'shark': '🦈',
    'pulpo': '🐙', 'octopus': '🐙',
    'calamar': '🦑', 'squid': '🦑',
    'langosta': '🦞', 'lobster': '🦞',
    'cangrejo': '🦀', 'crab': '🦀',
    'camaron': '🦐', 'shrimp': '🦐',
    'foca': '🦭', 'seal': '🦭',

    // Insectos
    'abeja': '🐝', 'bee': '🐝',
    'mariposa': '🦋', 'butterfly': '🦋',
    'caracol': '🐌', 'snail': '🐌',
    'hormiga': '🐜', 'ant': '🐜',
    'mariquita': '🐞', 'ladybug': '🐞',
    'grillo': '🦗', 'cricket': '🦗',
    'cucaracha': '🪳', 'cockroach': '🪳',
    'araña': '🕷️', 'spider': '🕷️',
    'escorpion': '🦂', 'scorpion': '🦂',
    'mosquito': '🦟', 'mosquitoe': '🦟',
    'gusano': '🪱', 'worm': '🪱',

    // Otros mamiferos
    'elefante': '🐘', 'elephant': '🐘',
    'rinoceronte': '🦏', 'rhino': '🦏',
    'hipopotamo': '🦛', 'hippo': '🦛',
    'jirafa': '🦒', 'giraffe': '🦒',
    'cebra': '🦓', 'zebra': '🦓',
    'venado': '🦌', 'deer': '🦌',
    'ciervo': '🦌',
    'kanguro': '🦘', 'kangaroo': '🦘',
    'perezoso': '🦥', 'sloth': '🦥',
    'nutria': '🦦', 'otter': '🦦',
    'mofeta': '🦨', 'skunk': '🦨',
    'mapache': '🦝', 'raccoon': '🦝',
    'topo': '🦡', 'badger': '🦡'
};

const HORA_MS = 60 * 60 * 1000; // 1 Hora

function tiempoRestanteStr(ultimoTiempo) {
    const ahora = Date.now();
    const diferencia = ahora - ultimoTiempo;
    if (diferencia >= HORA_MS) return '¡Listo ahora! ✅';
    
    const faltante = HORA_MS - diferencia;
    const minutos = Math.floor(faltante / (1000 * 60));
    return `En ${minutos} min ⏳`;
}

function necesitaAccion(ultimoTiempo) {
    return (Date.now() - ultimoTiempo) >= HORA_MS; // Si pasó 1 hora, necesita la acción
}

let handler = async (message, { text, command }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');
        
        const senderNumber = senderJid.split('@')[0];
        const args = text ? text.trim().split(/\s+/) : [];
        const action = args[0] ? args[0].toLowerCase() : '';
        const actionArg = args[1] ? args[1].toLowerCase() : '';

        // Menú Principal si no ponen acción
        if (!action) {
            return await message.reply(
                '*🐾 SISTEMA DE MASCOTAS 🐾*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                '*.pet lista* - _Ver animales disponibles_\n' +
                '*.pet adoptar [animal]* - _Adoptar (Ej: .pet adoptar perro)_\n' +
                '*.pet info* - _Ver estadísticas, necesidades y ánimo_\n' +
                '*.pet name [Nombre]* - _Ponerle nombre (solo letras/números)_\n' +
                '*.pet alimentar* - _Darle de comer_\n' +
                '*.pet agua* - _Darle de beber_\n' +
                '*.pet jugar* - _Jugar con ella_\n' +
                '*.pet abandonar* - _Dejar a tu mascota para siempre_'
            );
        }

        // ==========================================
        // SISTEMA DE MUERTE POR DESCUIDO (3 DÍAS)
        // ==========================================
        if (mascotas[senderNumber]) {
            const m = mascotas[senderNumber];
            const TRES_DIAS_MS = 3 * 24 * 60 * 60 * 1000;
            const ahora = Date.now();
            let razonesMuerte = [];

            if (ahora - m.ultima_comida > TRES_DIAS_MS) razonesMuerte.push('hambre extrema 🥩');
            if (ahora - m.ultima_agua > TRES_DIAS_MS) razonesMuerte.push('deshidratación 💧');
            if (ahora - m.ultimo_juego > TRES_DIAS_MS) razonesMuerte.push('depresión y aburrimiento 🎾');

            if (razonesMuerte.length > 0) {
                const nombreMuerto = m.nombre || 'Tu mascota';
                const emojiMuerto = m.tipo;
                
                delete mascotas[senderNumber];
                guardarMascotas();
                
                return await message.reply(
                    `🪦 *¡${nombreMuerto.toUpperCase()} HA MUERTO!* 🪦\n` +
                    '━━━━━━━━━━━━━━━\n\n' +
                    `Has descuidado a tu ${emojiMuerto} por más de 3 días...\n` +
                    `Falleció a causa de: *${razonesMuerte.join(', ')}*.\n\n` +
                    '_Usa .pet adoptar [animal] si crees que puedes ser más responsable la próxima vez._'
                );
            }
        }

        // Ver Lista de Animales
        if (action === 'lista' || action === 'list') {
            let listaTexto = '🐾 *MASCOTAS DISPONIBLES PARA ADOPTAR* 🐾\n━━━━━━━━━━━━━━━\n\n_Usa .pet adoptar [nombre]_\n\n';
            // Extraer valores únicos para mostrarlos bonito
            const animalesUnicos = [...new Set(Object.values(ANIMALES_MAP))];
            
            // Agrupar claves por emoji
            animalesUnicos.forEach(emoji => {
                const nombres = Object.keys(ANIMALES_MAP).filter(k => ANIMALES_MAP[k] === emoji);
                listaTexto += `${emoji} - ${nombres.join(', ')}\n`;
            });
            return await message.reply(listaTexto);
        }

        // Adoptar (Claim)
        if (action === 'adoptar' || action === 'adopt' || action === 'claim') {
            if (mascotas[senderNumber]) {
                return await message.reply(`❌ Ya tienes una mascota (${mascotas[senderNumber].tipo}). Si deseas otra, primero debes usar *.pet abandonar*`);
            }

            if (!actionArg || !ANIMALES_MAP[actionArg]) {
                return await message.reply('❌ *Error:* Debes especificar qué animal quieres adoptar.\n\nEjemplo: *.pet adoptar perro* o *.pet adoptar dog*\n💡 _Para ver los disponibles usa: .pet lista_');
            }

            const emojiElegido = ANIMALES_MAP[actionArg];
            const ahora = Date.now();

            mascotas[senderNumber] = {
                tipo: emojiElegido,
                nombre: 'SinNombre',
                nivel: 1,
                // Progresos para subir nivel
                comida_progreso: 0, agua_progreso: 0, juego_progreso: 0,
                // Estadísticas totales
                total_comida: 0, total_agua: 0, total_juego: 0,
                // Tiempos
                ultima_comida: ahora, ultima_agua: ahora, ultimo_juego: ahora,
                fecha_adopcion: ahora
            };
            guardarMascotas();

            return await message.reply(
                `🎉 *¡NUEVA MASCOTA ADOPTADA!* 🎉\n\n` +
                `Has adoptado a tu nuevo ${emojiElegido}!\n\n` +
                `💡 *Primeros pasos:*\n` +
                `1️⃣ Ponle un nombre: *.pet name [nombre]*\n` +
                `2️⃣ Mira sus necesidades: *.pet info*`
            );
        }

        // Validar que tenga mascota para el resto de comandos
        if (!mascotas[senderNumber]) {
            return await message.reply('🐾 *No tienes mascota*\n_Adopta una usando: .pet adoptar [animal]_');
        }

        let m = mascotas[senderNumber];
        let interactuo = false;
        let mensajeExito = "";

        // Abandonar Mascota
        if (action === 'abandonar' || action === 'abandon') {
            const nombreMascota = m.nombre;
            const emojiMascota = m.tipo;
            delete mascotas[senderNumber];
            guardarMascotas();
            return await message.reply(`💔 Has abandonado a *${nombreMascota}* ${emojiMascota} en un refugio...\n\n_Esperemos que encuentre un dueño que sí la cuide._`);
        }

        // Poner Nombre
        if (action === 'nombre' || action === 'name') {
            if (!actionArg) return await message.reply('❌ Debes escribir un nombre. Ejemplo: *.pet name Firulais*');
            if (!/^[a-zA-Z0-9]+$/.test(args[1])) {
                return await message.reply('❌ El nombre debe estar **todo junto** y contener **solo letras y números** (sin espacios ni símbolos).');
            }
            m.nombre = args[1];
            guardarMascotas();
            return await message.reply(`✨ Tu mascota ${m.tipo} ahora se llama *${m.nombre}*!`);
        }

        // Información Avanzada de la Mascota
        if (['info', 'informacion', 'estado', 'status'].includes(action)) {
            const tieneHambre = necesitaAccion(m.ultima_comida);
            const tieneSed = necesitaAccion(m.ultima_agua);
            const quiereJugar = necesitaAccion(m.ultimo_juego);

            // Determinar estado de ánimo
            let estadoAnimo = "🌟 ¡Está muy feliz y contenta!";
            if (tieneHambre && tieneSed && quiereJugar) estadoAnimo = "😭 ¡Está sufriendo! Lo necesita todo.";
            else if (tieneHambre || tieneSed || quiereJugar) estadoAnimo = "🥺 Está algo triste, necesita de ti.";

            return await message.reply(
                `🐾 *INFORMACIÓN DE ${m.nombre.toUpperCase()}* ${m.tipo}\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `🏅 *Nivel Actual:* ${m.nivel}\n` +
                `🎭 *Estado de ánimo:* ${estadoAnimo}\n\n` +
                
                `*📊 NECESIDADES ACTUALES:*\n` +
                `🥩 Hambre: ${tieneHambre ? '🔴 ¡Tiene hambre!' : '🟢 Satisfecho'}\n` +
                `💧 Sed: ${tieneSed ? '🔴 ¡Tiene sed!' : '🟢 Satisfecho'}\n` +
                `🎾 Diversión: ${quiereJugar ? '🔴 ¡Quiere jugar!' : '🟢 Satisfecho'}\n\n` +
                
                `*📈 PROGRESO PARA NIVEL ${m.nivel + 1}:*\n` +
                `Comidas: [${m.comida_progreso}/${m.nivel}] | Bebidas: [${m.agua_progreso}/${m.nivel}] | Juegos: [${m.juego_progreso}/${m.nivel}]\n\n` +

                `*🏆 ESTADÍSTICAS TOTALES DE VIDA:*\n` +
                `🍽️ Veces alimentada: ${m.total_comida}\n` +
                `🥤 Veces que bebió: ${m.total_agua}\n` +
                `🪀 Veces que jugaron: ${m.total_juego}\n\n` +

                `*⏳ TIEMPO HASTA PRÓXIMA ACCIÓN:*\n` +
                `🥩 Alimentar: ${tiempoRestanteStr(m.ultima_comida)}\n` +
                `💧 Agua: ${tiempoRestanteStr(m.ultima_agua)}\n` +
                `🎾 Jugar: ${tiempoRestanteStr(m.ultimo_juego)}`
            );
        }

        // Acciones: Alimentar, Beber, Jugar
        if (['alimentar', 'feed'].includes(action)) {
            if (!necesitaAccion(m.ultima_comida)) return await message.reply(`Tu mascota no tiene hambre. 🥩\n_Podrás alimentarla: ${tiempoRestanteStr(m.ultima_comida)}_`);
            m.ultima_comida = Date.now();
            m.comida_progreso++;
            m.total_comida++;
            interactuo = true;
            mensajeExito = `Le has dado de comer a *${m.nombre}*. 🥩 ¡Se ve muy feliz!`;
        }
        else if (['agua', 'beber', 'water'].includes(action)) {
            if (!necesitaAccion(m.ultima_agua)) return await message.reply(`Tu mascota no tiene sed. 💧\n_Podrás darle agua: ${tiempoRestanteStr(m.ultima_agua)}_`);
            m.ultima_agua = Date.now();
            m.agua_progreso++;
            m.total_agua++;
            interactuo = true;
            mensajeExito = `Le has servido agua fresca a *${m.nombre}*. 💧 ¡Refrescante!`;
        }
        else if (['jugar', 'play'].includes(action)) {
            if (!necesitaAccion(m.ultimo_juego)) return await message.reply(`Tu mascota está cansada. 🎾\n_Podrán jugar: ${tiempoRestanteStr(m.ultimo_juego)}_`);
            m.ultimo_juego = Date.now();
            m.juego_progreso++;
            m.total_juego++;
            interactuo = true;
            mensajeExito = `Has jugado con *${m.nombre}*. 🎾 ¡Le encantó!`;
        }
        else {
            return await message.reply('❌ Comando inválido. Escribe *.pet* para ver la lista de comandos.');
        }

        // ==========================================
        // SISTEMA DE SUBIDA DE NIVEL
        // ==========================================
        if (interactuo) {
            let subioNivel = false;

            while (m.comida_progreso >= m.nivel && m.agua_progreso >= m.nivel && m.juego_progreso >= m.nivel) {
                m.comida_progreso -= m.nivel;
                m.agua_progreso -= m.nivel;
                m.juego_progreso -= m.nivel;
                m.nivel++;
                subioNivel = true;
            }

            guardarMascotas();

            if (subioNivel) {
                return await message.reply(
                    `${mensajeExito}\n\n` +
                    `⭐ *¡NIVEL AUMENTADO!* ⭐\n\n` +
                    `¡Gracias a tus excelentes cuidados, *${m.nombre}* ${m.tipo} ha subido al *Nivel ${m.nivel}*!\n\n` +
                    `_Usa .pet info para ver sus nuevas estadísticas._`
                );
            } else {
                return await message.reply(`${mensajeExito}\n\n_Progreso Nivel ${m.nivel + 1} -> 🥩:${m.comida_progreso}/${m.nivel} | 💧:${m.agua_progreso}/${m.nivel} | 🎾:${m.juego_progreso}/${m.nivel}_`);
            }
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de mascotas:\x1b[0m', error);
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud._');
    }
};

handler.help = ['pet', 'mascota'];
handler.tags = ['mascotas'];
handler.command = /^(pet|mascota|pets|mascotas)$/i;
handler.apodo = true;

module.exports = handler;