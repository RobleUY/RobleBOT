const KEYS = [
    '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',
    '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',
    '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'
];

let handler = async (message, { text }) => {
    try {
        const tema = text?.trim() || 'un tema al azar, bonito y emotivo';
        const apiKey = KEYS[Math.floor(Math.random() * KEYS.length)];

        const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'llama-3.1-8b-instant',
                messages: [
                    { role: 'system', content: 'Escribe solo un poema corto en español, sin notas ni explicaciones.' },
                    { role: 'user', content: `Escribe un poema sobre: ${tema}` }
                ],
                temperature: 0.7
            })
        });

        const data = await res.json();
        const poema = data.choices[0].message.content.trim();

        await message.reply(`📜 *${text?.trim() ? text.toUpperCase() : 'POEMA'}*\n\n${poema}`);
    } catch (error) {
        console.error('[ERROR] poema:', error);
        await message.reply('❌ Ocurrió un error al crear el poema.');
    }
};

handler.help = ['poema', 'poemas'];
handler.tags = ['fun'];
handler.command = /^(poema|poemas)$/i;

module.exports = handler;