const KEYS = [
    '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',
    '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',
    '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'
];

let handler = async (message, { text }) => {
    try {
        const tema = text?.trim() || 'un tema al azar, bonito y emotivo';
        const systemPrompt = 'Escribe solo un poema corto en español, sin notas ni explicaciones.';
        const userPrompt = `Escribe un poema sobre: ${tema}`;

        let poema = '';
        try {
            const iaModule = require('./HERRAMIENTAS/ia/ia');
            const callIA = iaModule.callIA || iaModule;
            if (typeof callIA === 'function') {
                const res = await callIA(systemPrompt, userPrompt);
                if (res && res !== '_SILENT_FAIL_') poema = res;
            }
        } catch (e) {
            console.warn('[poemas] callIA falló, usando fallback Groq directo:', e.message);
        }

        if (!poema) {
            const apiKey = KEYS[Math.floor(Math.random() * KEYS.length)];
            const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'llama-3.1-8b-instant',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userPrompt }
                    ],
                    temperature: 0.7
                })
            });

            const data = await res.json();
            poema = data.choices[0].message.content.trim();
        }

        await message.reply(`📜 *${text?.trim() ? text.toUpperCase() : 'POEMA'}*\n\n${poema.trim()}`);
    } catch (error) {
        console.error('[ERROR] poema:', error);
        await message.reply('❌ Ocurrió un error al crear el poema.');
    }
};

handler.help = ['poema', 'poemas'];
handler.tags = ['fun'];
handler.command = /^(poema|poemas)$/i;

module.exports = handler;