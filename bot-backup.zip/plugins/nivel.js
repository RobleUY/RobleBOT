const db = require('../database.js');
const achievements = require('../achievements');

// Función para calcular nivel y XP necesaria para siguiente nivel
function calculateLevel(comandos) {
    let level = 0;
    let acumulado = 0;

    while (true) {
        const xpNecesaria = (level + 1) * 10;
        if (acumulado + xpNecesaria > comandos) {
            return {
                level,
                xpActual: comandos - acumulado,
                xpTotal: xpNecesaria,
                xpFaltante: xpNecesaria - (comandos - acumulado)
            };
        }
        acumulado += xpNecesaria;
        level++;
    }
}

let handler = async (message, { text, args }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        const userData = db.getUser(senderNumber);
        
        if (!userData) {
            return await message.reply('❌ Error al obtener tus datos.');
        }
        
        // Calcular nivel y XP
        const comandosEjecutados = userData.ComandosEjecutados || 0;
        const levelInfo = Number(userData.exp || 0) > 0
            ? achievements.calculateLevel(userData.exp)
            : calculateLevel(comandosEjecutados);
        
        // Calcular porcentaje de progreso
        const porcentaje = ((levelInfo.xpActual / levelInfo.xpTotal) * 100).toFixed(1);
        
        // Crear barra de progreso visual
        const barLength = 20;
        const filledLength = Math.round((levelInfo.xpActual / levelInfo.xpTotal) * barLength);
        const progressBar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);
        
        // Mensaje de nivel
        let nivelMessage = `⭐ *TU NIVEL* ⭐\n\n`;
        nivelMessage += `🏆 Nivel actual: *${levelInfo.level}*\n\n`;
        nivelMessage += `✨ Experiencia:\n`;
        nivelMessage += `├ Actual: ${levelInfo.xpActual} XP\n`;
        nivelMessage += `├ Siguiente nivel: ${levelInfo.xpTotal} XP\n`;
        nivelMessage += `└ Faltante: *${levelInfo.xpFaltante} XP*\n\n`;
        nivelMessage += `📊 Progreso:\n`;
        nivelMessage += `[${progressBar}] ${porcentaje}%\n\n`;
        
        // Agregar motivación según el progreso
        if (porcentaje >= 90) {
            nivelMessage += `🔥 ¡Casi lo logras! ¡Un poco más!\n`;
        } else if (porcentaje >= 70) {
            nivelMessage += `💪 ¡Vas muy bien! ¡Sigue así!\n`;
        } else if (porcentaje >= 50) {
            nivelMessage += `📈 ¡Ya pasaste la mitad!\n`;
        } else if (porcentaje >= 25) {
            nivelMessage += `🌟 ¡Buen comienzo!\n`;
        } else {
            nivelMessage += `🚀 ¡Comienza tu camino!\n`;
        }
        
        await message.reply(nivelMessage);
        
    } catch (error) {
        console.error('Error en comando nivel:', error);
        await message.reply('❌ Ocurrió un error al mostrar tu nivel.');
    }
};

handler.help = ['nivel', 'level'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(nivel|level|lvl)$/i;
module.exports = handler;
handler.apodo = true;