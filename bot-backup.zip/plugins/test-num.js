let handler = async (message) => {
    try {
        const key = message.key || {};
        
        // 1. En grupos: el ID real suele estar en 'participantAlt'
        // 2. En privados: el ID real suele estar en 'remoteJidAlt'
        // 3. Fallback: usamos los IDs originales por si el mensaje no trae campos Alt
        const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid;
        
        // Limpiamos el número eliminando el sufijo '@s.whatsapp.net' o '@lid'
        const numeroReal = jidReal ? jidReal.split('@')[0] : 'Desconocido';

        await message.reply(
            `✅ *¡Identidad detectada!*\n\n` +
            `📱 *Número Real/JID:* ${numeroReal}\n` +
            `🔗 *Contexto:* ${message.isGroup ? 'Grupo' : 'Privado'}\n` +
            `🔍 *Fuente técnica:* ${key.participantAlt ? 'participantAlt' : (key.remoteJidAlt ? 'remoteJidAlt' : 'ID Directo')}`
        );
        
        console.log(`Número extraído correctamente: ${numeroReal}`);
        
    } catch (e) {
        await message.reply('❌ Error al procesar la identidad.');
        console.error(e);
    }
};

handler.command = /^testnum$/i;
module.exports = handler;