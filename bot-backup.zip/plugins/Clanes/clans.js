// Almacenamiento temporal de invitaciones (se pierde al reiniciar)
const pendingInvites = new Map(); // Key: userNumber, Value: { clanName, invitedBy, timestamp }

let handler = async (message, { conn, text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];
        let user = global.db.getUser(senderNumber);
        
        if (!user) {
            return await message.reply('❌ No estás registrado en la base de datos.');
        }

        // Verificar que tenga apodo
        if (!user.apodo || user.apodo.trim() === '' || user.apodo.trim().toLowerCase() === 'sin apodo') {
            return await message.reply('🚫 Necesitas un apodo para usar el sistema de clanes.\n\n💡 Usa: *.apodo TuApodo*');
        }

        const args = text ? text.trim().split(/\s+/) : [];
        const subCommand = args[0]?.toLowerCase();

        // Si no hay subcomando, mostrar ayuda
        if (!subCommand) {
            const hasPendingInvite = pendingInvites.has(senderNumber);
            let inviteText = '';
            
            if (hasPendingInvite) {
                const invite = pendingInvites.get(senderNumber);
                inviteText = `\n⚠️ *¡Tienes una invitación pendiente del clan "${invite.clanName}"!*\n` +
                            `💡 Usa: *.clan aceptar* o *.clan rechazar*\n`;
            }

            return await message.reply(
                `*🏰 SISTEMA DE CLANES*\n\n` +
                `*Comandos disponibles:*\n\n` +
                `• *.clan create/crear <nombre>* - Crear un clan\n` +
                `• *.clan delete/borrar* - Borrar tu clan\n` +
                `• *.clan delete/borrar confirm* - Confirmar borrado\n` +
                `• *.clan info* - Ver info de tu clan\n` +
                `• *.clan info <nombre>* - Ver info de otro clan\n` +
                `• *.clan invite/invitar @usuario* - Invitar a alguien\n` +
                `• *.clan aceptar/accept* - Aceptar invitación\n` +
                `• *.clan rechazar/decline* - Rechazar invitación\n` +
                `• *.clan kick/expulsar @usuario* - Expulsar miembro\n` +
                `• *.clan promote @usuario* - Promover a decano\n` +
                `• *.clan demote @usuario* - Degradar de decano\n` +
                `• *.clan transferir @usuario* - Transferir propiedad\n` +
                `• *.clan top* - Top clanes por dinero\n` +
                `• *.clan leave/salir* - Salir del clan\n\n` +
                `💡 Los nombres de clan no pueden tener espacios${inviteText}`
            );
        }

        // CREAR CLAN
        if (['create', 'crear'].includes(subCommand)) {
            if (!args[1]) {
                return await message.reply('❌ Debes especificar un nombre para el clan.\n\n💡 Uso: *.clan create NombreClan*');
            }

            const clanName = args[1].toLowerCase();

            // Validar nombre (sin espacios)
            if (clanName.includes(' ') || args.length > 2) {
                return await message.reply('❌ El nombre del clan no puede contener espacios.\n\n💡 Ejemplo: *.clan create LosTigres*');
            }

            if (clanName.length < 3 || clanName.length > 20) {
                return await message.reply('❌ El nombre del clan debe tener entre 3 y 20 caracteres.');
            }

            // Verificar si ya tiene clan
            if (user.clan) {
                return await message.reply('❌ Ya perteneces a un clan. Debes salir primero con *.clan leave*');
            }

            // Verificar si el clan ya existe
            const allClans = global.db.getAllClans();
            if (allClans[clanName]) {
                return await message.reply('❌ Ya existe un clan con ese nombre. Elige otro.');
            }

            // Crear el clan
            const newClan = {
                name: clanName,
                leader: senderNumber,
                members: [senderNumber],
                elders: [],
                createdAt: Date.now(),
                pendingDelete: false,
                deleteRequestTime: 0
            };

            global.db.createClan(clanName, newClan);
            
            // Actualizar usuario
            user.clan = clanName;
            global.db.setUser(senderNumber, user);

            return await message.reply(
                `✅ *¡Clan creado exitosamente!*\n\n` +
                `🏰 *Nombre:* ${clanName}\n` +
                `👑 *Líder:* ${user.apodo}\n\n` +
                `💡 Usa *.clan invite @usuario* para invitar miembros`
            );
        }

        // BORRAR CLAN
        if (['delete', 'borrar'].includes(subCommand)) {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo el líder puede borrar
            if (clan.leader !== senderNumber) {
                return await message.reply('❌ Solo el líder del clan puede borrarlo.');
            }

            const confirm = args[1]?.toLowerCase();

            if (confirm === 'confirm' || confirm === 'confirmar') {
                // Verificar que la solicitud sea reciente (5 minutos)
                if (!clan.pendingDelete || (Date.now() - clan.deleteRequestTime) > 300000) {
                    return await message.reply('❌ No hay solicitud de borrado pendiente o expiró.\n\n💡 Usa primero: *.clan delete*');
                }

                // Remover clan de todos los miembros
                for (const memberNumber of clan.members) {
                    const memberData = global.db.getUser(memberNumber);
                    if (memberData) {
                        memberData.clan = null;
                        global.db.setUser(memberNumber, memberData);
                    }
                }

                // Borrar clan
                global.db.deleteClan(user.clan);

                return await message.reply(
                    `✅ *Clan "${clan.name}" eliminado exitosamente*\n\n` +
                    `Todos los miembros han sido liberados.`
                );
            } else {
                // Primera solicitud de borrado
                clan.pendingDelete = true;
                clan.deleteRequestTime = Date.now();
                global.db.updateClan(user.clan, clan);

                return await message.reply(
                    `⚠️ *¿Estás seguro de borrar el clan?*\n\n` +
                    `🏰 *Clan:* ${clan.name}\n` +
                    `👥 *Miembros:* ${clan.members.length}\n\n` +
                    `⏱️ Tienes 5 minutos para confirmar con:\n` +
                    `*.clan delete confirm*`
                );
            }
        }

        // INFO CLAN
        if (subCommand === 'info') {
            let clanName = user.clan;

            // Si especificó un clan
            if (args[1]) {
                clanName = args[1].toLowerCase();
            }

            if (!clanName) {
                return await message.reply('❌ No perteneces a ningún clan.\n\n💡 Usa: *.clan info <nombre>* para ver info de otro clan');
            }

            const clan = global.db.getClan(clanName);
            if (!clan) {
                return await message.reply(`❌ No existe el clan "${clanName}"`);
            }

            // Obtener apodos
            const leaderData = global.db.getUser(clan.leader);
            const leaderName = leaderData?.apodo || 'Desconocido';

            let eldersList = '—';
            if (clan.elders.length > 0) {
                eldersList = clan.elders.map(elderNum => {
                    const elderData = global.db.getUser(elderNum);
                    return elderData?.apodo || 'Desconocido';
                }).join(', ');
            }

            // Calcular dinero total
            let totalMoney = 0;
            for (const memberNumber of clan.members) {
                const memberData = global.db.getUser(memberNumber);
                if (memberData) {
                    totalMoney += (memberData.money || 0) + (memberData.bank || 0);
                }
            }

            return await message.reply(
                `*🏰 INFORMACIÓN DEL CLAN*\n\n` +
                `*Nombre:* ${clan.name}\n` +
                `*👑 Líder:* ${leaderName}\n` +
                `*👥 Miembros:* ${clan.members.length}\n` +
                `*⭐ Decanos:* ${clan.elders.length}\n` +
                `*💰 Dinero Total:* ${totalMoney.toLocaleString()}\n\n` +
                `*Decanos:*\n${eldersList}`
            );
        }

        // TOP CLANES
        if (subCommand === 'top') {
            const allClans = global.db.getAllClans();
            const clansArray = Object.entries(allClans);

            if (clansArray.length === 0) {
                return await message.reply('📊 Aún no hay clanes creados.');
            }

            // Calcular dinero total de cada clan
            const clansWithMoney = clansArray.map(([clanName, clanData]) => {
                let totalMoney = 0;
                for (const memberNumber of clanData.members) {
                    const memberData = global.db.getUser(memberNumber);
                    if (memberData) {
                        totalMoney += (memberData.money || 0) + (memberData.bank || 0);
                    }
                }
                return {
                    name: clanName,
                    totalMoney,
                    memberCount: clanData.members.length,
                    leader: clanData.leader
                };
            });

            // Ordenar por dinero
            clansWithMoney.sort((a, b) => b.totalMoney - a.totalMoney);

            // Top 10
            const top10 = clansWithMoney.slice(0, 10);
            const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

            let topText = `*🏆 TOP CLANES POR DINERO 💰*\n\n`;

            top10.forEach((clan, index) => {
                const leaderData = global.db.getUser(clan.leader);
                const leaderName = leaderData?.apodo || 'Desconocido';
                
                topText += `${medals[index]} *${clan.name}*\n` +
                          `   👑 ${leaderName}\n` +
                          `   💰 ${clan.totalMoney.toLocaleString()}\n` +
                          `   👥 ${clan.memberCount} miembros\n\n`;
            });

            return await message.reply(topText);
        }

        // INVITAR (ahora solo envía la invitación)
        if (['invite', 'invitar'].includes(subCommand)) {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo líder y decanos pueden invitar
            if (clan.leader !== senderNumber && !clan.elders.includes(senderNumber)) {
                return await message.reply('❌ Solo el líder y decanos pueden invitar miembros.');
            }

            const mentionedJids = message?.mentions || [];
            if (mentionedJids.length === 0) {
                return await message.reply('❌ Debes mencionar al usuario que quieres invitar.\n\n💡 Uso: *.clan invite @usuario*');
            }

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];

            if (targetNumber === senderNumber) {
                return await message.reply('❌ No puedes invitarte a ti mismo.');
            }

            const targetUser = global.db.getUser(targetNumber);
            if (!targetUser) {
                return await message.reply('❌ El usuario no está registrado.');
            }

            // Verificar apodo
            if (!targetUser.apodo || targetUser.apodo.trim() === '' || targetUser.apodo.trim().toLowerCase() === 'sin apodo') {
                return await message.reply(`❌ @${targetNumber} necesita un apodo para unirse a un clan.`, { mentions: [targetJid] });
            }

            if (targetUser.clan) {
                return await message.reply(`❌ @${targetNumber} ya pertenece a otro clan.`, { mentions: [targetJid] });
            }

            // Verificar si ya tiene una invitación pendiente
            if (pendingInvites.has(targetNumber)) {
                return await message.reply(`❌ @${targetNumber} ya tiene una invitación pendiente de otro clan.`, { mentions: [targetJid] });
            }

            // Crear invitación temporal
            pendingInvites.set(targetNumber, {
                clanName: user.clan,
                invitedBy: senderNumber,
                invitedByNickname: user.apodo,
                timestamp: Date.now()
            });

            // Notificar al invitado
            await conn.sendMessage(targetJid, {
                text: `🏰 *¡Has sido invitado a un clan!*\n\n` +
                      `*Clan:* ${clan.name}\n` +
                      `*Invitado por:* ${user.apodo}\n` +
                      `*Miembros actuales:* ${clan.members.length}\n\n` +
                      `💡 Usa:\n` +
                      `• *.clan aceptar* - Para unirte\n` +
                      `• *.clan rechazar* - Para declinar\n\n` +
                      `⚠️ La invitación expirará al reiniciar el servidor.`
            });

            return await message.reply(
                `✅ *Invitación enviada a @${targetNumber}*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `El usuario debe usar *.clan aceptar* para unirse.`,
                { mentions: [targetJid] }
            );
        }

        // ACEPTAR INVITACIÓN
        if (['aceptar', 'accept'].includes(subCommand)) {
            // Verificar si tiene invitación pendiente
            if (!pendingInvites.has(senderNumber)) {
                return await message.reply('❌ No tienes ninguna invitación pendiente.');
            }

            if (user.clan) {
                return await message.reply('❌ Ya perteneces a un clan. Debes salir primero con *.clan leave*');
            }

            const invite = pendingInvites.get(senderNumber);
            const clan = global.db.getClan(invite.clanName);

            if (!clan) {
                pendingInvites.delete(senderNumber);
                return await message.reply('❌ El clan ya no existe. Invitación cancelada.');
            }

            // Agregar al clan
            clan.members.push(senderNumber);
            global.db.updateClan(invite.clanName, clan);

            user.clan = invite.clanName;
            global.db.setUser(senderNumber, user);

            // Eliminar invitación
            pendingInvites.delete(senderNumber);

            // Notificar al que invitó
            const inviterJid = invite.invitedBy + '@s.whatsapp.net';
            await conn.sendMessage(inviterJid, {
                text: `✅ *${user.apodo}* aceptó la invitación y se unió al clan *${clan.name}*!`
            }).catch(() => {});

            return await message.reply(
                `✅ *¡Te has unido al clan!*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `👥 *Miembros totales:* ${clan.members.length}\n\n` +
                `¡Bienvenido al clan!`
            );
        }

        // RECHAZAR INVITACIÓN
        if (['rechazar', 'decline'].includes(subCommand)) {
            // Verificar si tiene invitación pendiente
            if (!pendingInvites.has(senderNumber)) {
                return await message.reply('❌ No tienes ninguna invitación pendiente.');
            }

            const invite = pendingInvites.get(senderNumber);
            
            // Notificar al que invitó
            const inviterJid = invite.invitedBy + '@s.whatsapp.net';
            await conn.sendMessage(inviterJid, {
                text: `❌ *${user.apodo}* rechazó la invitación al clan *${invite.clanName}*.`
            }).catch(() => {});

            // Eliminar invitación
            pendingInvites.delete(senderNumber);

            return await message.reply(
                `✅ *Has rechazado la invitación*\n\n` +
                `🏰 *Clan:* ${invite.clanName}\n\n` +
                `La invitación ha sido cancelada.`
            );
        }

        // EXPULSAR
        if (['kick', 'expulsar'].includes(subCommand)) {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo líder y decanos pueden expulsar
            if (clan.leader !== senderNumber && !clan.elders.includes(senderNumber)) {
                return await message.reply('❌ Solo el líder y decanos pueden expulsar miembros.');
            }

            const mentionedJids = message?.mentions || [];
            if (mentionedJids.length === 0) {
                return await message.reply('❌ Debes mencionar al usuario que quieres expulsar.\n\n💡 Uso: *.clan kick @usuario*');
            }

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];

            if (targetNumber === clan.leader) {
                return await message.reply('❌ No puedes expulsar al líder del clan.');
            }

            if (!clan.members.includes(targetNumber)) {
                return await message.reply('❌ Ese usuario no es miembro del clan.');
            }

            // Remover de miembros
            clan.members = clan.members.filter(m => m !== targetNumber);
            
            // Remover de decanos si lo era
            if (clan.elders.includes(targetNumber)) {
                clan.elders = clan.elders.filter(e => e !== targetNumber);
            }

            global.db.updateClan(user.clan, clan);

            // Actualizar usuario
            const targetUser = global.db.getUser(targetNumber);
            if (targetUser) {
                targetUser.clan = null;
                global.db.setUser(targetNumber, targetUser);
            }

            return await message.reply(
                `✅ *@${targetNumber} ha sido expulsado del clan*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `👥 *Miembros restantes:* ${clan.members.length}`,
                { mentions: [targetJid] }
            );
        }

        // PROMOVER A DECANO
        if (subCommand === 'promote') {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo el líder puede promover
            if (clan.leader !== senderNumber) {
                return await message.reply('❌ Solo el líder del clan puede promover a decanos.');
            }

            const mentionedJids = message?.mentions || [];
            if (mentionedJids.length === 0) {
                return await message.reply('❌ Debes mencionar al usuario que quieres promover.\n\n💡 Uso: *.clan promote @usuario*');
            }

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];

            if (targetNumber === senderNumber) {
                return await message.reply('❌ Ya eres el líder del clan.');
            }

            if (!clan.members.includes(targetNumber)) {
                return await message.reply('❌ Ese usuario no es miembro del clan.');
            }

            if (clan.elders.includes(targetNumber)) {
                return await message.reply('❌ Ese usuario ya es decano.');
            }

            // Promover
            clan.elders.push(targetNumber);
            global.db.updateClan(user.clan, clan);

            const targetUser = global.db.getUser(targetNumber);
            const targetName = targetUser?.apodo || 'Desconocido';

            return await message.reply(
                `✅ *¡${targetName} ha sido promovido a decano!*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `⭐ *Decanos totales:* ${clan.elders.length}`,
                { mentions: [targetJid] }
            );
        }

        // DEGRADAR DE DECANO
        if (subCommand === 'demote') {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo el líder puede degradar
            if (clan.leader !== senderNumber) {
                return await message.reply('❌ Solo el líder del clan puede degradar decanos.');
            }

            const mentionedJids = message?.mentions || [];
            if (mentionedJids.length === 0) {
                return await message.reply('❌ Debes mencionar al usuario que quieres degradar.\n\n💡 Uso: *.clan demote @usuario*');
            }

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];

            if (!clan.elders.includes(targetNumber)) {
                return await message.reply('❌ Ese usuario no es decano.');
            }

            // Degradar
            clan.elders = clan.elders.filter(e => e !== targetNumber);
            global.db.updateClan(user.clan, clan);

            const targetUser = global.db.getUser(targetNumber);
            const targetName = targetUser?.apodo || 'Desconocido';

            return await message.reply(
                `✅ *${targetName} ha sido degradado de decano*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `⭐ *Decanos restantes:* ${clan.elders.length}`,
                { mentions: [targetJid] }
            );
        }

        // TRANSFERIR PROPIEDAD
        if (subCommand === 'transferir') {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // Solo el líder puede transferir
            if (clan.leader !== senderNumber) {
                return await message.reply('❌ Solo el líder del clan puede transferir la propiedad.');
            }

            const mentionedJids = message?.mentions || [];
            if (mentionedJids.length === 0) {
                return await message.reply('❌ Debes mencionar al usuario al que quieres transferir el clan.\n\n💡 Uso: *.clan transferir @usuario*');
            }

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];

            if (targetNumber === senderNumber) {
                return await message.reply('❌ Ya eres el líder del clan.');
            }

            if (!clan.members.includes(targetNumber)) {
                return await message.reply('❌ Ese usuario no es miembro del clan.');
            }

            // Transferir liderazgo
            const oldLeader = clan.leader;
            clan.leader = targetNumber;

            // Si el nuevo líder era decano, quitarlo de decanos
            if (clan.elders.includes(targetNumber)) {
                clan.elders = clan.elders.filter(e => e !== targetNumber);
            }

            // El viejo líder no se hace decano automáticamente
            global.db.updateClan(user.clan, clan);

            const targetUser = global.db.getUser(targetNumber);
            const targetName = targetUser?.apodo || 'Desconocido';

            return await message.reply(
                `✅ *¡Propiedad del clan transferida!*\n\n` +
                `🏰 *Clan:* ${clan.name}\n` +
                `👑 *Nuevo líder:* ${targetName}\n\n` +
                `El liderazgo ha sido transferido exitosamente.`,
                { mentions: [targetJid] }
            );
        }

        // SALIR DEL CLAN
        if (['leave', 'salir'].includes(subCommand)) {
            if (!user.clan) {
                return await message.reply('❌ No perteneces a ningún clan.');
            }

            const clan = global.db.getClan(user.clan);
            if (!clan) {
                return await message.reply('❌ Error al obtener información del clan.');
            }

            // El líder no puede salir, debe transferir o borrar
            if (clan.leader === senderNumber) {
                return await message.reply('❌ El líder no puede salir del clan.\n\n💡 Debes transferir el liderazgo con *.clan transferir @usuario* o borrar el clan con *.clan delete*');
            }

            // Remover de miembros
            clan.members = clan.members.filter(m => m !== senderNumber);
            
            // Remover de decanos si lo era
            if (clan.elders.includes(senderNumber)) {
                clan.elders = clan.elders.filter(e => e !== senderNumber);
            }

            global.db.updateClan(user.clan, clan);

            // Actualizar usuario
            const clanName = user.clan;
            user.clan = null;
            global.db.setUser(senderNumber, user);

            return await message.reply(
                `✅ *Has salido del clan "${clanName}"*\n\n` +
                `Ahora eres libre de unirte a otro clan.`
            );
        }

        // Comando no reconocido
        return await message.reply('❌ Comando no reconocido.\n\n💡 Usa *.clan* para ver todos los comandos disponibles.');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de clanes:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error en el sistema de clanes.');
    }
};

handler.help = ['clan'];
handler.tags = ['clans'];
handler.command = /^(clan|clanes)$/i;
handler.group = true;
handler.apodo = true;

module.exports = handler;