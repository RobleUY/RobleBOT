/**
 * Comando .listmutes - Ver usuarios muteados en el grupo
 * Requiere: Sistema MuteSystem global
 */

/*
let handler = async (message, { conn }) => {
    try {
        // Verificar que el sistema de muteo esté disponible
        if (!global.muteSystem) {
            return await message.reply('❌ Sistema de muteo no disponible. Reinicia el bot.');
        }

        // Delegar todo el procesamiento al sistema global
        await global.muteSystem.handleListMutesCommand(message);

    } catch (error) {
        console.error('[Plugin ListMutes] Error:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['listmutes'];
handler.tags = ['admin'];
handler.command = /^(listmutes|muteados|listamuteados)$/i;
handler.group = true;

module.exports = handler; */