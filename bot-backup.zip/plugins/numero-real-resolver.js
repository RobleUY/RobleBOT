let handler = async (message) => {
    try {
        const key = message.key || {};
        const sock = message._sock || global.conn;
        const isGroup = key.remoteJid?.endsWith('@g.us');

        // ── Determinar el JID real del remitente ──
        let jidLid;
        if (isGroup) {
            // En grupos, el remitente viene en participant/participantAlt
            jidLid = key.participant || key.participantAlt;
        } else if (key.fromMe) {
            // Chat privado y lo enviaste vos: el remitente sos vos mismo,
            // NO key.remoteJid (eso es el destinatario/con quien hablás)
            jidLid = sock?.user?.id;
        } else {
            // Chat privado, te escribieron: remoteJid es quien te escribió
            jidLid = key.remoteJid;
        }

        console.log('--- Info del mensaje (mynum) ---');
        console.log('key completo:', key);
        console.log('isGroup:', isGroup, '| fromMe:', key.fromMe);
        console.log('jidLid detectado:', jidLid);

        let numeroReal = 'Desconocido';

        if (jidLid && jidLid.endsWith('@lid') && sock) {
            try {
                if (sock.signalRepository?.lidMapping?.getPNForLID) {
                    const pn = await sock.signalRepository.lidMapping.getPNForLID(jidLid);
                    console.log('Resuelto vía lidMapping:', pn);
                    if (pn) numeroReal = pn.split('@')[0].split(':')[0];
                }
            } catch (err) {
                console.log('lidMapping no disponible o falló:', err.message);
            }

            if (numeroReal === 'Desconocido' && typeof sock.onWhatsApp === 'function') {
                try {
                    const [result] = await sock.onWhatsApp(jidLid);
                    console.log('Resultado onWhatsApp:', result);
                    if (result?.jid) numeroReal = result.jid.split('@')[0].split(':')[0];
                } catch (err) {
                    console.log('onWhatsApp falló:', err.message);
                }
            }
        } else if (jidLid) {
            numeroReal = jidLid.split('@')[0].split(':')[0];
        }

        console.log('numeroReal (final):', numeroReal);
        console.log('---------------------------------');

        await message.reply(
            `✅ *¡Número detectado!*\n\n` +
            `📱 *Número:* ${numeroReal}\n`
        );

    } catch (e) {
        console.error('Error al procesar la identidad:', e);
        await message.reply('❌ Error al procesar la identidad.');
    }
};

handler.command = /^mynum$/i;
module.exports = handler;