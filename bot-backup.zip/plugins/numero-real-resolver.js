'use strict';

/**
 * Plugin: .mynum
 * Resuelve y muestra el número de teléfono real del usuario, decodificando incluso LIDs ocultos.
 * Versión 2.0 (Arreglado el error de desestructuración de jidDecode)
 */

let handler = async (m, { conn = global.conn, text }) => {
    const sock = m._sock || conn;

    try {
        let targetJid = null;

        // 1. Detectar si el mensaje menciona a alguien
        const mentionedJids = m?.mentions || m?.message?.extendedTextMessage?.contextInfo?.mentionedJid;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
        } 
        // 2. Detectar si está respondiendo a un mensaje de otra persona
        else if (m?.quoted || m?.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const contextInfo = m?.message?.extendedTextMessage?.contextInfo;
            // Evaluamos opciones del mensaje citado de forma estricta
            targetJid = m.quoted?.sender || contextInfo?.participant || contextInfo?.remoteJid;
        } 
        // 3. Si no hay mención ni respuesta, usar el emisor actual del comando
        else {
            targetJid = m.sender || m.from || m.author;
        }

        if (!targetJid || typeof targetJid !== 'string') {
            targetJid = m.sender; // Respaldo definitivo
        }

        // Obtener de forma robusta la sala/chat donde se debe responder
        const chatToReply = m.chat || m.from || m.key?.remoteJid;
        if (!chatToReply) {
            console.error('[MyNum] No se encontró un JID de chat válido para responder.');
            return;
        }

        // Limpiar el JID base para extraer el identificador numérico
        let userNumber = targetJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        let isLid = userNumber.length >= 15;
        let originalId = userNumber;
        let resolved = false;

        // 🎯 Lógica de resolución inversa si se detecta una LID
        if (isLid && global.mainAuthState?.keys?.get) {
            try {
                const mapped = global.mainAuthState.keys.get('lid-mapping', [`${userNumber}_reverse`]);
                const realNumber = mapped?.[`${userNumber}_reverse`];
                
                if (realNumber) {
                    userNumber = String(realNumber).replace(/[^0-9]/g, '');
                    resolved = true;
                    console.log(`[MyNum] LID ${originalId} resuelta exitosamente a: ${userNumber}`);
                } else {
                    console.log(`[MyNum] LID ${originalId} no se pudo mapear (sin registro inverso activo)`);
                }
            } catch (err) {
                console.error('[MyNum] Error mapeando la LID:', err.message);
            }
        }

        // Formatear la respuesta estética en texto plano sin usar menciones que rompan jidDecode
        let responseText = '';
        const myOwnSender = m.sender || m.from;
        
        if (targetJid.split('@')[0] === myOwnSender?.split('@')[0]) {
            responseText = isLid && resolved
                ? `📱 *Tu ID de WhatsApp está oculta (LID), pero tu número real es:* \n\n\`\`\`+${userNumber}\`\`\``
                : `📱 *Tu número de teléfono real es:* \n\n\`\`\`+${userNumber}\`\`\``;
        } else {
            responseText = isLid && resolved
                ? `✨ *El número real del usuario seleccionado es:* \n\n\`\`\`+${userNumber}\`\`\`\n\n_(Nota: Tenía su número real protegido mediante ID oculta)_`
                : `✨ *El número de teléfono de ese usuario es:* \n\n\`\`\`+${userNumber}\`\`\``;
        }

        // Estructura del mensaje limpia de sub-propiedades problemáticas
        const messagePayload = { text: responseText };

        // Intentar usar quoted solo si está bien estructurado
        const quotedOption = m._baileyMessage || m.message ? { quoted: m._baileyMessage || m } : {};

        // Enviar el resultado al chat de forma segura
        await sock.sendMessage(chatToReply, messagePayload, quotedOption);

    } catch (e) {
        console.error('[MyNum] Error general en el comando:', e.message);
        
        // Intento de emergencia en texto plano directo en caso de fallo crítico catastrófico
        try {
            const emergencyChat = m.chat || m.from;
            if (emergencyChat) {
                await sock.sendMessage(emergencyChat, { 
                    text: '❌ Ocurrió un error al procesar o estructurar los identificadores de WhatsApp de este usuario.' 
                });
            }
        } catch {}
    }
};

handler.help = ['mynum', 'mynum @user'];
handler.tags = ['tools', 'utils'];
handler.command = /^(mynum|numero|realnum)$/i;

module.exports = handler;