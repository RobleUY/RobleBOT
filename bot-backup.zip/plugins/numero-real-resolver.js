let handler = async (message) => {
    try {
        const key = message.key || {};
        
        // 1. En grupos: el ID real suele estar en 'participantAlt'
        // 2. En privados: el ID real suele estar en 'remoteJidAlt'
        // 3. Fallback: usamos los IDs originales por si el mensaje no trae campos Alt
        const jidReal = key.participantAlt || key.remoteJidAlt || key.participant || key.remoteJid;
        
        // Limpiamos el número eliminando el sufijo '@s.whatsapp.net' o '@lid'
        const numeroReal = jidReal ? jidReal.split('@')[0] : 'Desconocido';

        await message.reply(
            `✅ *¡Numero detectado!*\n\n` +
            `📱 *Número:* ${numeroReal}\n`
        );
        
        console.log(`Número extraído correctamente: ${numeroReal}`);
        
    } catch (e) {
        await message.reply('❌ Error al procesar la identidad.');
        console.error(e);
    }
};

handler.command = /^mynum$/i;
module.exports = handler;