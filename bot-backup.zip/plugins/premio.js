const db       = require('../database.js');
const premium  = require('../premium');

// Lazy require para evitar problemas de orden de carga entre plugins.
// Las variables se resuelven la primera vez que se usan, no al arrancar el bot.
let _personajes, _jugadores, _famosos, _rankup;

function getPersonajes() {
    if (!_personajes) _personajes = require('./personajes.js');
    return _personajes;
}
function getJugadores() {
    if (!_jugadores) _jugadores = require('./jugadores.js');
    return _jugadores;
}
function getFamosos() {
    if (!_famosos) _famosos = require('./famosos.js');
    return _famosos;
}
function getRankup() {
    if (!_rankup) _rankup = require('./rankup.js');
    return _rankup;
}

const CALIDAD_5 = '☆☆☆☆☆';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function randomFrom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function formatTime(ms) {
    const h = Math.floor(ms / (60 * 60 * 1000));
    const m = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
    const s = Math.floor((ms % (60 * 1000)) / 1000);
    return `${h}h ${m}m ${s}s`;
}

/**
 * Filtra la lista recibida y devuelve elementos de cualquier rareza.
 * Elige uno al azar de toda la lista (más común), o aumenta probabilidad de 5☆.
 */
function getRandomCalidad(lista) {
    // Probabilidades: 40% 1☆, 25% 2☆, 20% 3☆, 10% 4☆, 5% 5☆
    const rand = Math.random() * 100;
    let estrellasFiltro;
    
    if (rand < 40) estrellasFiltro = '☆';
    else if (rand < 65) estrellasFiltro = '☆☆';
    else if (rand < 85) estrellasFiltro = '☆☆☆';
    else if (rand < 95) estrellasFiltro = '☆☆☆☆';
    else estrellasFiltro = '☆☆☆☆☆';
    
    const filtrada = lista.filter(item => item.calidad === estrellasFiltro);
    return filtrada.length > 0 ? randomFrom(filtrada) : randomFrom(lista);
}

/**
 * Elige el tipo de premio al azar.
 * Si el usuario ya tiene el rango máximo, 'rango' directamente no entra al pool.
 */
function elegirTipoPremio(tieneRangoMax) {
    const pool = [
        'dinero', 'dinero', 'dinero',
        'personaje', 'personaje',
        'futbolista', 'futbolista',
        'famoso', 'famoso',
    ];
    if (!tieneRangoMax) {
        pool.push('rango', 'rango');
    }
    return randomFrom(pool);
}

/**
 * Asegura que el registro de coleccionables del usuario exista en db.data.
 */
function ensureColeccion(coleccion, number) {
    // Asegurar que db.data existe
    if (!db || !db.data) {
        console.error('[premio] db.data no está disponible');
        return false;
    }
    
    // Inicializar la colección si no existe
    if (!db.data[coleccion]) {
        db.data[coleccion] = {};
    }
    
    // Inicializar el usuario en la colección si no existe
    if (!db.data[coleccion][number]) {
        db.data[coleccion][number] = {
            [coleccion]: [],
            bloqueados: [],
            ultimoClaim: 0,
            jid: number
        };
    }
    
    return true;
}

// ─── Handler principal ────────────────────────────────────────────────────────

let handler = async (message, { args, sock }) => {
    try {
        const subCmd = (args[0] || '').toLowerCase();

        if (subCmd !== 'claim') {
            return await message.reply(
                `🎁 *PREMIO DIARIO*\n\n` +
                `Usa *.premio claim* para reclamar tu premio.\n\n` +
                `• Usuarios normales: cada *24 horas*\n` +
                `• Usuarios premium ⭐: cada *12 horas*\n\n` +
                `Posibles premios:\n` +
                `💰 Dinero ($5.000 / $10.000 / $20.000)\n` +
                `⚽ Un futbolista (☆ a ☆☆☆☆☆)\n` +
                `🎭 Un personaje (☆ a ☆☆☆☆☆)\n` +
                `🌟 Un famoso (☆ a ☆☆☆☆☆)\n` +
                `🏅 Ascenso de rango gratis (si no tienes el máximo)`
            );
        }

        // ── Identificar usuario ──────────────────────────────────────────────
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const number = db.cleanNumber(senderJid) || (senderJid ? senderJid.split('@')[0] : null);
        if (!number) return await message.reply('❌ No se pudo identificar tu número.');

        const connSock = sock || global.conn;

        const isPremiumUser = premium.isPremium(senderJid) || premium.isPremium(number);
        const COOLDOWN = isPremiumUser
            ? 12 * 60 * 60 * 1000   // 12 horas premium
            : 24 * 60 * 60 * 1000;  // 24 horas normal

        // ── Verificar cooldown ───────────────────────────────────────────────
        const user = db.getUser(number);
        if (!user) return await message.reply('❌ Error al obtener tus datos.');

        const ahora        = Date.now();
        const ultimoPremio = Number(user.lastPremio) || 0;
        const tiempoRestante = COOLDOWN - (ahora - ultimoPremio);

        if (tiempoRestante > 0) {
            return await message.reply(
                `⏳ *¡Todavía no puedes reclamar!*\n\n` +
                `Podrás reclamar tu próximo premio en: *${formatTime(tiempoRestante)}*\n` +
                (isPremiumUser ? `⭐ _Cooldown premium: 12 horas_` : `_Cooldown normal: 24 horas_`)
            );
        }

        // ── Determinar si ya tiene el rango máximo ───────────────────────────
        const rangoActual   = user.rango || '🌱 Novato';
        const maxRango      = getRankup().getMaxRango();
        const tieneRangoMax = rangoActual === maxRango || premium.hasPremiumMaxRank(senderJid);
        const tipoPremio    = elegirTipoPremio(tieneRangoMax);

        // Marcar timestamp antes de entregar (evita doble claim si algo falla)
        user.lastPremio = ahora;

        // ── DINERO ───────────────────────────────────────────────────────────
        if (tipoPremio === 'dinero') {
            const cantidad = randomFrom([5000, 10000, 20000]);
            user.money = (user.money || 0) + cantidad;
            db.setUser(number, user);

            return await message.reply(
                `🎁 *¡PREMIO RECLAMADO!*\n` +
                `━━━━━━━━━━\n\n` +
                `💰 *Premio:* Dinero\n` +
                `🤑 *Cantidad:* $${cantidad.toLocaleString()} monedas\n\n` +
                `💵 *Saldo actual:* $${user.money.toLocaleString()}\n\n` +
                (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`)
            );
        }

        // ── RANGO ────────────────────────────────────────────────────────────
        if (tipoPremio === 'rango') {
            const siguiente = getRankup().getSiguienteRango(rangoActual);
            // getSiguienteRango solo devuelve null si ya es el máximo,
            // pero elegirTipoPremio ya excluye 'rango' en ese caso.
            // Por seguridad ante race condition, si siguiente es null damos dinero silenciosamente.
            if (!siguiente) {
                const cantidad = randomFrom([5000, 10000, 20000]);
                user.money = (user.money || 0) + cantidad;
                db.setUser(number, user);
                return await message.reply(
                    `🎁 *¡PREMIO RECLAMADO!*\n` +
                    `━━━━━━━━━━\n\n` +
                    `💰 *Premio:* Dinero\n` +
                    `🤑 *Cantidad:* $${cantidad.toLocaleString()} monedas\n\n` +
                    `💵 *Saldo actual:* $${user.money.toLocaleString()}\n\n` +
                    (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`)
                );
            }

            user.rango   = siguiente.nombre;
            user.respeto = (user.respeto || 0) + 5;
            db.setUser(number, user);
            return await message.reply(
                `🎁 *¡PREMIO RECLAMADO!*\n` +
                `━━━━━━━━━━\n\n` +
                `🏅 *Premio:* Ascenso de Rango\n` +
                `📈 *Rango anterior:* ${rangoActual}\n` +
                `✨ *Nuevo rango:* ${siguiente.nombre}\n` +
                `💪 *Bonus:* +5 Respeto\n\n` +
                (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`)
            );
        }

        // ── PERSONAJE (cualquier rareza) ────────────────────────────────────────────────
        if (tipoPremio === 'personaje') {
            const modPersonajes = getPersonajes();
            const PERSONAJES_BASE = modPersonajes.PERSONAJES_BASE;
            const buscarImagenPersonaje = modPersonajes.buscarImagenPersonaje;
            if (!PERSONAJES_BASE) {
                console.error('[premio] PERSONAJES_BASE undefined, exports:', Object.keys(modPersonajes));
                return await message.reply('❌ Error interno al obtener personajes. Reportalo al admin.');
            }
            const personaje = getRandomCalidad(PERSONAJES_BASE);
            
            // Asegurar que la colección existe
            if (!ensureColeccion('personajes', number)) {
                console.error('[premio] No se pudo acceder a db.data para personajes');
                return await message.reply('❌ Error en la base de datos. Intenta de nuevo.');
            }
            
            // Verificar que se inicializó correctamente
            if (!db.data.personajes || !db.data.personajes[number]) {
                console.error('[premio] No se pudo inicializar personajes para:', number);
                return await message.reply('❌ Error al inicializar colección. Intenta de nuevo.');
            }
            
            // Guardar con el mismo formato que usa personajes.js (nombre en minúsculas sin espacios)
            const nombreKey = personaje.nombre.replace(/\s/g, '').toLowerCase();
            db.data.personajes[number].personajes.push(nombreKey);
            db.setPersonajes(number, db.data.personajes[number]);
            db.setUser(number, user);
            db.save();

            const caption =
                `🎁 *¡PREMIO RECLAMADO!*\n` +
                `━━━━━━━━━━\n\n` +
                `🎭 *Premio:* Personaje de Anime ${personaje.calidad}\n` +
                `✨ *Personaje:* ${personaje.nombre}\n` +
                `📺 *Anime:* ${personaje.anime}\n` +
                `⭐ *Calidad:* ${personaje.calidad}\n\n` +
                `_El personaje fue agregado a tu colección._\n\n` +
                (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`);

            // Intentar mandar con imagen (misma API que usa personajes.js)
            const imagenUrl = personaje.imagen || await buscarImagenPersonaje(personaje.nombre, personaje.anime);
            if (imagenUrl && connSock) {
                const groupJid = message?.key?.remoteJid;
                try {
                    await connSock.sendMessage(groupJid, {
                        image: { url: imagenUrl },
                        caption,
                        mentions: [senderJid]
                    });
                    return;
                } catch (_) { /* Si falla la imagen, caemos al reply de texto */ }
            }
            return await message.reply(caption);
        }

        // ── FUTBOLISTA (cualquier rareza) ────────────────────────────────────────────────
        if (tipoPremio === 'futbolista') {
            const modJugadores = getJugadores();
            const FUTBOLISTAS_BASE = modJugadores.FUTBOLISTAS_BASE;
            const buscarImagenFutbolista = modJugadores.buscarImagenFutbolista;
            if (!FUTBOLISTAS_BASE) {
                console.error('[premio] FUTBOLISTAS_BASE undefined, exports:', Object.keys(modJugadores));
                return await message.reply('❌ Error interno al obtener futbolistas. Reportalo al admin.');
            }
            const futbolista = getRandomCalidad(FUTBOLISTAS_BASE);
            
            // Asegurar que la colección existe
            if (!ensureColeccion('futbolistas', number)) {
                console.error('[premio] No se pudo acceder a db.data para futbolistas');
                return await message.reply('❌ Error en la base de datos. Intenta de nuevo.');
            }
            
            // Verificar que se inicializó correctamente
            if (!db.data.futbolistas || !db.data.futbolistas[number]) {
                console.error('[premio] No se pudo inicializar futbolistas para:', number);
                return await message.reply('❌ Error al inicializar colección. Intenta de nuevo.');
            }
            
            const nombreKey = futbolista.nombre.replace(/\s/g, '').toLowerCase();
            db.data.futbolistas[number].futbolistas.push(nombreKey);
            db.setFutbolistas(number, db.data.futbolistas[number]);
            db.setUser(number, user);
            db.save();

            const caption =
                `🎁 *¡PREMIO RECLAMADO!*\n` +
                `━━━━━━━━━━\n\n` +
                `⚽ *Premio:* Futbolista ${futbolista.calidad}\n` +
                `🌟 *Jugador:* ${futbolista.nombre}\n` +
                `🚩 *País:* ${futbolista.pais}\n` +
                `🏃 *Posición:* ${futbolista.posicion}\n` +
                `⭐ *Calidad:* ${futbolista.calidad}\n\n` +
                `_El futbolista fue agregado a tu colección._\n\n` +
                (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`);

            const imagenUrl = await buscarImagenFutbolista(futbolista.nombre, futbolista.pais);
            if (imagenUrl && connSock) {
                const groupJid = message?.key?.remoteJid;
                try {
                    await connSock.sendMessage(groupJid, {
                        image: { url: imagenUrl },
                        caption,
                        mentions: [senderJid]
                    });
                    return;
                } catch (_) { /* fallback texto */ }
            }
            return await message.reply(caption);
        }

        // ── FAMOSO (cualquier rareza) ────────────────────────────────────────────────────
        if (tipoPremio === 'famoso') {
            const modFamosos = getFamosos();
            const FAMOSOS_BASE = modFamosos.FAMOSOS_BASE;
            const buscarImagenFamoso = modFamosos.buscarImagenFamoso;
            if (!FAMOSOS_BASE) {
                console.error('[premio] FAMOSOS_BASE undefined, exports:', Object.keys(modFamosos));
                return await message.reply('❌ Error interno al obtener famosos. Reportalo al admin.');
            }
            const famoso = getRandomCalidad(FAMOSOS_BASE);
            
            // Asegurar que la colección existe
            if (!ensureColeccion('famosos', number)) {
                console.error('[premio] No se pudo acceder a db.data para famosos');
                return await message.reply('❌ Error en la base de datos. Intenta de nuevo.');
            }
            
            // Verificar que se inicializó correctamente
            if (!db.data.famosos || !db.data.famosos[number]) {
                console.error('[premio] No se pudo inicializar famosos para:', number);
                return await message.reply('❌ Error al inicializar colección. Intenta de nuevo.');
            }
            
            const nombreKey = famoso.nombre.replace(/\s/g, '').toLowerCase();
            db.data.famosos[number].famosos.push(nombreKey);
            db.setFamosos(number, db.data.famosos[number]);
            db.setUser(number, user);
            db.save();

            const caption =
                `🎁 *¡PREMIO RECLAMADO!*\n` +
                `━━━━━━━━━━\n\n` +
                `🌟 *Premio:* Famoso ${famoso.calidad}\n` +
                `👤 *Famoso:* ${famoso.nombre}\n` +
                `🎬 *Categoría:* ${famoso.categoria}\n` +
                `📝 *Descripción:* ${famoso.descripcion}\n` +
                `⭐ *Calidad:* ${famoso.calidad}\n\n` +
                `_El famoso fue agregado a tu colección._\n\n` +
                (isPremiumUser ? `⭐ _Próximo claim en 12 horas._` : `_Próximo claim en 24 horas._`);

            const imagenUrl = await buscarImagenFamoso(famoso.nombre, famoso.categoria);
            if (imagenUrl && connSock) {
                const groupJid = message?.key?.remoteJid;
                try {
                    await connSock.sendMessage(groupJid, {
                        image: { url: imagenUrl },
                        caption,
                        mentions: [senderJid]
                    });
                    return;
                } catch (_) { /* fallback texto */ }
            }
            return await message.reply(caption);
        }

    } catch (err) {
        console.error('[ERROR premio]:', err);
        return await message.reply('❌ Ocurrió un error al reclamar tu premio.');
    }
};

handler.help = ['premio'];
handler.tags = ['economia', 'rpg'];
handler.command = /^premio$/i;
handler.apodo = true;

module.exports = handler;
