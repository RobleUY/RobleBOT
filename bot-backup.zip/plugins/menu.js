const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

if (!global.LastUpdate) {
    global.LastUpdate = {
        timestamp: Date.now(),
        getTimestamp() {
            return this.timestamp;
        },
        timeSince(timestamp) {
            const diff = Math.floor((Date.now() - timestamp) / 1000);
            if (diff < 60) return `${diff} segundos`;
            const mins = Math.floor(diff / 60);
            if (mins < 60) return `${mins} minutos`;
            const hrs = Math.floor(mins / 60);
            if (hrs < 24) return `${hrs} horas`;
            const days = Math.floor(hrs / 24);
            return `${days} días`;
        }
    };
}


const more = String.fromCharCode(8206);
const readMore = more.repeat(4000);

// === FUNCION PRINCIPAL DEL MENÚ ===
async function getMenuContent(conn, usedPrefix = '.') {

    let totalGroups = 0;
    let totalParticipants = 0;

    try {
        let groups = [];
        let groupsData = {};

        if (typeof conn.groupFetchAllParticipating === 'function') {
            groupsData = await conn.groupFetchAllParticipating();
            groups = Object.keys(groupsData);
        } else if (conn.chats && typeof conn.chats === 'object') {
            groups = Object.entries(conn.chats)
                .filter(([jid, chat]) => jid.endsWith('@g.us'))
                .map(([jid]) => jid);
        }

        totalGroups = groups.length;
        for (const jid of groups) {
            const groupInfo = groupsData[jid];
            totalParticipants += groupInfo?.participants?.length || 0;
        }

    } catch (e) {
        console.error('[ERROR] No se pudo obtener stats para el menú:', e.message);
    }

    const totalUsersDisplay = totalParticipants + 100;
    const lastTimestamp = LastUpdate.getTimestamp();
    const timeSince = LastUpdate.timeSince(lastTimestamp);
    
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;


    const menu = `
╔═════ ≪ 🤖 ≫ ═════
║   *ROBLEBOT MENÚ PRINCIPAL*
║
║  👑 *Creador:* RobleUY
║     _wa.me/+59893900470_
║  ⏰ *Última actualización:*
║          _Hace ${timeSince}_
║  ⏳ *Bot activo hace:*
║          _${uptimeFormatted}_
╚══════════════
*¡Hola!* Usa el prefijo \`${usedPrefix}\` para
cualquier comando.
*Ejemplo:* ${usedPrefix}menu

${readMore}
╔═════ ≪ ⬇️ ≫ ═════
║   *MULTIMEDIA Y DESCARGAS*
_Descargá audios, videos e imágenes de distintas fuentes y redes sociales de forma directa._
╚══════════════
*🔗 Descarga General*
\_${usedPrefix}descargar <link>\_
> *Propósito:* Descargá imagenes/videos de redes sociales solo con el enlace.
${' '.repeat(10)}
*🎬 YouTube*
\_${usedPrefix}ytvideo <título|link>\_
> *Propósito:* Descargá videos de YouTube por título o enlace.

\_${usedPrefix}ytaudio <título|link>\_
> *Propósito:* Descargá audios (MP3) de YouTube por título o enlace.
${' '.repeat(10)}
*🎶 TikTok*
\_${usedPrefix}tiktok <link>\_
> *Propósito:* Descargá videos de TikTok sin marca de agua.

\_${usedPrefix}tiktoks <texto|random>\_
> *Propósito:* Descargá hasta 5 videos sobre el texto que escribas o usa "random" para categorías al azar.
${' '.repeat(10)}
*📸 Otras Redes*
\_${usedPrefix}instagram <link>\_
> *Propósito:* Descargá imagenes/videos de Instagram.

\_${usedPrefix}facebook <link>\_
> *Propósito:* Descargá imagenes/videos de FaceBook.

\_${usedPrefix}threads <link>\_
> *Propósito:* Descargá imágenes de Threads.

\_${usedPrefix}twitter <link>\_
> *Propósito:* Descargá imágenes/videos de Twitter.
${' '.repeat(10)}
*📱 Apps y Otros*
\_${usedPrefix}apk <nombre>\_
> *Propósito:* Buscá y descargá archivos de aplicaciones.
──────────────

╔═════ ≪ 🔎 ≫ ═════
║   *BUSCADORES*
_Realizá búsquedas rápidas en distintas plataformas de video._
╚══════════════
*▶️ YouTube*
\_${usedPrefix}ytsearch <título>\_
> *Propósito:* Buscá videos en YouTube y obtené resultados.
${' '.repeat(10)}
*🎵 TikTok*
\_${usedPrefix}ttsearch <título>\_
> *Propósito:* Buscá videos en TikTok y obtené resultados.
──────────────

╔═════ ≪ 💰 ≫ ═════
║   *ECONOMÍA Y BANCO*
_Gestioná tu dinero virtual: ahorrá, retirará y trabajá para conseguir más coins._
╚══════════════
*💼 Cuentas*
\_${usedPrefix}saldo\_
> *Propósito:* Verificá el saldo actual de tu cuenta.

\_${usedPrefix}depositar <cant|all>\_
> *Propósito:* Depositá coins al banco desde tu cartera.

\_${usedPrefix}retirar <cant|all>\_
> *Propósito:* Retirá coins del banco a tu cartera.

\_${usedPrefix}darcoins @user <cant>\_
> *Propósito:* Transferí coins a otro usuario.
${' '.repeat(10)}
*🛠️ Trabajo y Recompensas*
\_${usedPrefix}trabajar\_
> *Propósito:* Realizá un trabajo para ganar monedas.

\_${usedPrefix}estudiar\_
> *Propósito:* Estudia y recibe monedas.

\_${usedPrefix}slut\_
> *Propósito:* Vende tu cuerpo a cambio de monedas.

\_${usedPrefix}minar\_
> *Propósito:* Miná para obtener coins desde las minas.

\_${usedPrefix}cazar\_
> *Propósito:* Salí de cacería para ganar recompensas.

\_${usedPrefix}cadadia\_
> *Propósito:* Reclamá tu recompensa diaria.
${' '.repeat(10)}
*🏦 Préstamos*
\_${usedPrefix}prestamo <cant>\_
> *Propósito:* Solicitá un préstamo al banco.

\_${usedPrefix}prestamo pagar <cant|todo>\_
> *Propósito:* Pagá tu préstamo o la deuda completa.
──────────────

╔═════ ≪ 🎰 ≫ ═════
║   *CASINO Y APUESTAS*
_Probá tu suerte en juegos de azar y duelos contra otros usuarios._
╚══════════════
*🃏 Juegos de Mesa*
\_${usedPrefix}caraocruz <cara|cruz> <cant|all>\_
> *Propósito:* Apostá en el clásico cara o cruz.

\_${usedPrefix}bj <cant|all>\_
> *Propósito:* Jugá BlackJack (21) contra el bot.

\_${usedPrefix}ruleta <color> <cant|all>\_
> *Propósito:* Apostá a un color en la ruleta (rojo/negro/verde).

\_${usedPrefix}dados <tipo> <cant|all>\_
> *Propósito:* Tirada de dados con distintos tipos de apuestas.
${' '.repeat(10)}
*🎲 Azar*
\_${usedPrefix}apostar <cant|all>\_
> *Propósito:* Iniciá una apuesta contra el bot.

\_${usedPrefix}apostar @user <cant>\_ (Duelo)
> *Propósito:* Desafiá a otro usuario a un duelo de apuestas.

\_${usedPrefix}slot <cant|all>\_
> *Propósito:* Jugá a la máquina tragamonedas.

\_${usedPrefix}race <cant|all>\_
> *Propósito:* Participá en una carrera.
──────────────

╔═════ ≪ 👤 ≫ ═════
║   *RANKUP*
_Sube de rango y demuestra quien manda._
╚══════════════
*💪 Rankup*
\_${usedPrefix}rankup\_
> *Propósito:* Sube de rango gastando dinero.

*💪 Rangos*
\_${usedPrefix}ranks\_
> *Propósito:* Muestra la lista de rangos disponibles y su precio.

*💪 Rango*
\_${usedPrefix}rank\_
> *Propósito:* Muestra tu rango actual, el siguiente, el precio y cuanto te falta.

╔═════ ≪ 👤 ≫ ═════
║   *PERFIL Y SOCIAL*
_Personalizá tu perfil, gestioná amistades y compartí información social._
╚══════════════
*✨ Perfil*
\_${usedPrefix}perfil\_
> *Propósito:* Muestra tu perfil completo y estadísticas.

*⬆ Nivel*
\_${usedPrefix}nivel\_
> *Propósito:* Muestra tu nivel y xp faltante para el siguiente.

*✨ Genero*
\_${usedPrefix}genero <hombre/mujer>\_
> *Propósito:* Cambia tu genero entre hombre o mujer.

\_${usedPrefix}apodo <texto>\_
> *Propósito:* Cambiá tu apodo.

${' '.repeat(10)}
*❤️ Parejas*
\_${usedPrefix}pareja <estado|pedir|aceptar|rechazar|romper>\_
> *Propósito:* Gestioná tu estado civil (pedir matrimonio, aceptar, etc.).
${' '.repeat(10)}
*📱 Redes Sociales (Compartir)*
\_${usedPrefix}redes\_
> *Propósito:* Muestra las redes sociales registradas.

\_${usedPrefix}redes tiktok|instagram <usuario>\_
> *Propósito:* Registrá tu usuario de red social.
${' '.repeat(10)}
──────────────

╔═════ ≪ ⚽ ≫ ═════
║   *FUTBOLISTAS (COLECCIONABLES)*
_Coleccioná, reclamá e intercambiá futbolistas con otros usuarios._
╚══════════════
*🎁 Acciones*
_${usedPrefix}fpj reclamar_
> *Propósito:* Reclamá tu futbolista coleccionable diario.

_${usedPrefix}myfpj_
> *Propósito:* Muestra los futbolistas coleccionables que posees.
${' '.repeat(10)}
*🔄 Comercio*
_${usedPrefix}fpj vender <nombre> <cant|all>_
> *Propósito:* Vendé futbolistas coleccionables.

_${usedPrefix}fpj regalar @user <nombre>_
> *Propósito:* Regalá un futbolista a otro usuario.

_${usedPrefix}fpj intercambio @user <mi_fp> <su_fp>_
> *Propósito:* Proponé un intercambio de futbolistas.
──────────────

╔═════ ≪ 🧠 ≫ ═════
║   *PERSONAJES (COLECCIONABLES DE ANIME)*
_Coleccioná, reclamá e intercambiá personajes de anime con otros usuarios._
╚══════════════
*🎁 Acciones*
_${usedPrefix}pj reclamar_
> *Propósito:* Reclamá tu personaje coleccionable diario.

_${usedPrefix}mypj_
> *Propósito:* Muestra los personajes coleccionables que posees.
${' '.repeat(10)}
*🔄 Comercio*
_${usedPrefix}pj vender <nombre> <cant|all>_
> *Propósito:* Vendé personajes coleccionables.

_${usedPrefix}pj regalar @user <nombre>_
> *Propósito:* Regalá un personaje a otro usuario.

_${usedPrefix}pj intercambio @user <mi_pj> <su_pj>_
> *Propósito:* Proponé un intercambio de personajes.
──────────────

╔═════ ≪ 🎮 ≫ ═════
║   *JUEGOS Y ENTRETENIMIENTO*
_Diversión con duelos, adivinanzas y oráculos para pasar el rato._
╚══════════════
*⚔️ Duelos*
\_${usedPrefix}ppt @user\_
> *Propósito:* Jugá Piedra, Papel o Tijera contra otro usuario.
${' '.repeat(10)}
*❓ Adivinanzas*
\_${usedPrefix}describe\_
> *Propósito:* Adiviná la palabra oculta.

\_${usedPrefix}emoji\_
> *Propósito:* Adiviná la palabra representada por los emojis.

\_${usedPrefix}completar\_
> *Propósito:* Completá la frase.

\_${usedPrefix}ordenar\_
> *Propósito:* Ordená la palabra o frase revuelta.

\_${usedPrefix}trivia\_
> *Propósito:* Preguntas de cultura general.
${' '.repeat(10)}
*🔮 Oráculos y Decisiones*
\_${usedPrefix}quien <texto>\_
> *Propósito:* El bot elegirá un usuario del grupo.

\_${usedPrefix}siono <texto>\_
> *Propósito:* El bot responde con un "sí" o un "no" a tu pregunta.

\_${usedPrefix}elegir <opcion1> o <opcion2>\_
> *Propósito:* El bot te ayuda a elegir una opción.

\_${usedPrefix}kprefieres <opcion1 o opcion2>\_
> *Propósito:* Responde a un dilema de "Qué Prefieres".
──────────────

╔═════ ≪ 🤣 ≫ ═════
║   *RANDOM E INTERACCIONES*
_Comandos para interactuar con otros, medir tu amor o simplemente reír._
╚══════════════
*💖 Interacciones (con @usuario)*
\_${usedPrefix}love <@user>\_
> *Propósito:* Calculá el porcentaje de amor entre dos personas.

\_${usedPrefix}ship <@user1> y <@user2>\_
> *Propósito:* Calculá el "shippeo" entre dos usuarios.

\_${usedPrefix}abrazar | besar | matar | golpear | follar <@user>\_
> *Propósito:* Realizá una interacción con otro usuario.
${' '.repeat(10)}
*🔢 Calculadoras (Divertidas)*
\_${usedPrefix}calcular1|2|3 <texto>\_
> *Propósito:* Calculadoras de humor con resultados aleatorios.
${' '.repeat(10)}
*🤪 Ego y Drama*
\_${usedPrefix}ego\_
> *Propósito:* Muestra una frase de "ego".

\_${usedPrefix}drama\_
> *Propósito:* Muestra una frase de "drama".

\_${usedPrefix}quiero <texto>\_
> *Propósito:* Pide algo al bot de forma graciosa.

\_${usedPrefix}kprefieres\_ (Aleatorio)
> *Propósito:* Obtiene un dilema aleatorio de "Qué Prefieres".
──────────────

╔═════ ≪ 🖼️ ≫ ═════
║   *IMÁGENES Y STICKERS*
_Generá imágenes con IA, buscá contenido y creá stickers divertidos._
╚══════════════
*🎨 Generación y Búsqueda*
\_${usedPrefix}imagenia <texto>\_ (IA)
> *Propósito:* Creá imágenes con Inteligencia Artificial.

\_${usedPrefix}imagen <texto>\_ (Google)
> *Propósito:* Buscá imágenes en Google.

\_${usedPrefix}pinterest <texto>\_
> *Propósito:* Buscá imágenes en Pinterest.
${' '.repeat(10)}
*📦 Colecciones*
\_${usedPrefix}waifu | bts | blackpink\_
> *Propósito:* Obtené una imagen aleatoria de estas colecciones.
${' '.repeat(10)}
*🔄 Conversión*
\_${usedPrefix}toimg\_ (Sticker a Imagen)
> *Propósito:* Convertí un sticker a formato de imagen.
${' '.repeat(10)}
*🪅 Stickers*
\_${usedPrefix}sticker\_ (Imagen/Video)
> *Propósito:* Convertí una imagen, GIF o video corto en sticker.

\_${usedPrefix}brat <texto>\_
> *Propósito:* Creá un sticker con texto tipo "Brat Style".

\_${usedPrefix}emojimix <2 emojis>\_
> *Propósito:* Combiná dos emojis en un sticker.

\_${usedPrefix}tts <texto>\_ (Texto a Sticker)
> *Propósito:* Creá un sticker simple con texto.

\_${usedPrefix}tts <texto> <color> <fondo>\_ (Personalizado)
> *Propósito:* Creá un sticker con texto, color de texto y color de fondo personalizados.
──────────────

╔═════ ≪ 🔧 ≫ ═════
║   *HERRAMIENTAS Y UTILITIES*
_Funciones útiles para el día a día, inteligencia artificial, edición y más._
╚══════════════
*🧠 Inteligencia Artificial*
\_${usedPrefix}ia <texto>\_ (Texto)
> *Propósito:* Conversá con el bot de forma inteligente.

\_${usedPrefix}iavoz <texto>\_ (Voz)
> *Propósito:* Enviá una nota de voz y recibí respuesta de la IA.

\_${usedPrefix}tradai <texto + idioma>\_
> *Propósito:* Traducí texto usando IA (ej: tradai Hola mundo inglés).

\_${usedPrefix}rs | reportepsicologico [@usuario|me]\_
> *Propósito:* Generá un reporte psicológico basado en los mensajes del usuario.

\_${usedPrefix}sobre [@usuario] <pregunta>\_
> *Propósito:* Hacé una pregunta sobre alguien basándose en sus mensajes (ej: está feliz?).
${' '.repeat(10)}
*✂️ Edición y Conversión*
\_${usedPrefix}efecto\_ (Audio)
> *Propósito:* Aplicá efectos a audios (subí la nota de voz y usá el comando).

\_${usedPrefix}removebg\_ (Imagen)
> *Propósito:* Remové el fondo de una imagen (enviá la imagen y usá el comando).

\_${usedPrefix}leer\_ (Transcribir Audio/Doc)
> *Propósito:* Transcribí el texto de un audio o documento.

\_${usedPrefix}tav <texto>\_ (Texto a Voz)
> *Propósito:* Convertí texto a audio (voz).
${' '.repeat(10)}
*📡 Stalkers*
\_${usedPrefix}ytstalk | ttstalk | igstalk <usuario>\_
> *Propósito:* Obtené información de un perfil de red social.

\_${usedPrefix}xstalk | tgstalk | thstalk <usuario>\_
> *Propósito:* Stalk de Twitter/X, Telegram o Threads.

\_${usedPrefix}ghstalk | ptstalk | steamstalk <usuario>\_
> *Propósito:* Stalk de GitHub, Pinterest o Steam.

\_${usedPrefix}mcstalk <usuario>\_
> *Propósito:* Información de un perfil de Minecraft.
${' '.repeat(10)}
*☁️ Otros*
\_${usedPrefix}clima <ciudad y pais>\_
> *Propósito:* Obtené el clima actual de una ubicación específica.
──────────────

╔═════ ≪ 🛠️ ≫ ═════
║   *ADMINISTRACIÓN DE GRUPO*
_Comandos esenciales para moderadores y administradores de grupos._
╚══════════════
*ℹ️ Info y Links*
\_${usedPrefix}infog\_
> *Propósito:* Muestra la información del grupo.

\_${usedPrefix}link\_
> *Propósito:* Obtené el enlace de invitación del grupo.
${' '.repeat(10)}
*✍️ Edición*
\_${usedPrefix}nameg <texto>\_
> *Propósito:* Cambiá el nombre del grupo.

\_${usedPrefix}desc <texto>\_
> *Propósito:* Cambiá la descripción del grupo.
${' '.repeat(10)}
*👥 Miembros*
\_${usedPrefix}kick @user\_
> *Propósito:* Expulsá a un miembro del grupo.

\_${usedPrefix}op @user\_
> *Propósito:* Nombrá a un miembro como administrador.

\_${usedPrefix}deop @user\_
> *Propósito:* Remové el estado de administrador de un miembro.
${' '.repeat(10)}
*🔒 Apertura/Cierre*
\_${usedPrefix}close\_
> *Propósito:* Cerrá el grupo (solo admins pueden escribir).

\_${usedPrefix}open\_
> *Propósito:* Abrí el grupo (todos pueden escribir).
──────────────

╔═════ ≪ 🔞 ≫ ═════
║   *CONTENIDO +18 (NSFW)*
_Sección de contenido adulto y explícito. *Úsala bajo tu propia responsabilidad*._
╚══════════════
*🎥 Videos*
\_${usedPrefix}xnxx <título|link>\_
> *Propósito:* Buscá y descargá videos de XNXX.

\_${usedPrefix}hentaiv\_
> *Propósito:* Obtené un video Hentai aleatorio.
${' '.repeat(10)}
*🔞 Imágenes*
\_${usedPrefix}tetas\_
> *Propósito:* Obtené una imagen aleatoria de "tetas".

\_${usedPrefix}hotgirl\_
> *Propósito:* Obtené una imagen de "chica sexy" aleatoria.
──────────────

╔═════════════════
║  *📱 MENÚS PRINCIPALES*
╚═════════════════
*1️⃣ Menus Lista*
\`${usedPrefix}menus\`
> Ver lista de menus.

*1️⃣ Menu - Descargas*
\`${usedPrefix}menudownload\`
> Multimedia, YouTube, TikTok, Instagram, etc.

*2️⃣ Menu - Economía*
\`${usedPrefix}menueconomia\`
> Banco, trabajo, préstamos, transferencias

*3️⃣ Menu - Casino*
\`${usedPrefix}menucasino\`
> Juegos de azar, apuestas, ruleta, dados

*4️⃣ Menu - Perfil*
\`${usedPrefix}menuperfil\`
> Perfil, nivel, pareja, redes sociales, rankup

*5️⃣ Menu - Coleccionables*
\`${usedPrefix}menucoleccion\`
> Futbolistas y personajes de anime

*6️⃣ Menu - Juegos*
\`${usedPrefix}menujuegos\`
> Entretenimiento, duelos, adivinanzas

*7️⃣ Menu - Random*
\`${usedPrefix}menurandom\`
> Interacciones, calculadoras, diversión

*8️⃣ Menu - Imágenes*
\`${usedPrefix}menuimagen\`
> Generación IA, búsqueda, stickers

*9️⃣ Menu - NSFW +18*
\`${usedPrefix}menunsfW\`
> Contenido adulto (usar con responsabilidad)

*🔟 Menu - Herramientas*
\`${usedPrefix}menutools\`
> IA, edición, conversión, clima

*1️⃣1️⃣ Menu - Admin*
\`${usedPrefix}menuadmin\`
> Gestión de grupos (solo admins)

*1️⃣2️⃣ Menu - Ayuda*
\`${usedPrefix}menuayuda\`
> Soporte, reportes, sugerencias

╔═════ ≪ 💡 ≫ ═════
║   *AYUDA Y SOPORTE*
_Recursos para asistencia, reporte de errores y sugerencias al creador._
╚══════════════
*🏘 Agregar bot:* \_${usedPrefix}join <link>\_
> *Propósito:* Enviá la solicitud para unir el bot a tu grupo.

*⚠️ Reportes:* \_${usedPrefix}reporte <texto>\_
> *Propósito:* Informá al creador sobre un error o mal funcionamiento.

*📝 Sugerencias:* \_${usedPrefix}sugerencia <texto>\_
> *Propósito:* Enviá ideas y sugerencias de mejora.
╚══════════════
*✨ ROBLEBOT • v2.0*
_Developed BY: RobleUY_
`;

    return menu.trim();
}

// === GUARDA AUTOMÁTICAMENTE EL MENÚ EN UN ARCHIVO ===
async function saveMenuFile(menuText) {
    try {
        const menuFilePath = path.join(__dirname, '..', 'menu.txt');
        // Limpiar antes de guardar: quitar readMore (chars invisibles) y líneas solo decorativas
        const limpio = menuText
            .split('\n')
            .filter(l => {
                const t = l.trim();
                if (!t) return false;
                // línea gigante de chars invisibles/de control (el readMore)
                if (/^[\u200b-\u200f\u202a-\u202e\u2066-\u2069\u200e\ufeff\s]+$/.test(t)) return false;
                // líneas solo decorativas
                if (/^[╔╗╚╝║═─━\-=*_~^▬▪•·]{4,}$/.test(t)) return false;
                // líneas de solo espacios (${' '.repeat(10)})
                if (/^\s+$/.test(l)) return false;
                return true;
            })
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
        fs.writeFileSync(menuFilePath, limpio, 'utf8');
        console.log('✅ menu.txt actualizado automáticamente.');
    } catch (error) {
        console.error('❌ Error al guardar menu.txt:', error);
    }
}

// === HANDLER DEL COMANDO ===
let handler = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuContent(conn, usedPrefix);

        // Envía el menú al chat
        await message.reply(menuText);

        // Lo guarda automáticamente en /menu.txt
        await saveMenuFile(menuText);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al mostrar el menú:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al mostrar el menú.');
    }
};

handler.help = ['menu', 'menú'];
handler.tags = ['info'];
handler.command = /^(menu|menú|comandos|juegos)$/i;
handler.getMenuContent = getMenuContent;

module.exports = handler;
