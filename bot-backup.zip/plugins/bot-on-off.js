const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const BOT_STATUS_FILE = path.join(GRUPOS_DIR, 'bot-on-off.json');

// Asegurar que el directorio existe
if (!fs.existsSync(GRUPOS_DIR)) {
    fs.mkdirSync(GRUPOS_DIR, { recursive: true });
}

// ── Caché en memoria ─────────────────────────────────────────────────────────
// Evita leer el JSON del disco en cada mensaje de grupo (se llama 6 veces por
// mensaje con bot principal + 5 subbots). El archivo solo se relee cuando
// se escribe (setBotStatus) o cuando el módulo se recarga.
let _configCache = null;
let _configMtime = 0;

function loadBotConfig() {
    try {
        // Verificar si el archivo cambió desde la última lectura
        if (fs.existsSync(BOT_STATUS_FILE)) {
            const mtime = fs.statSync(BOT_STATUS_FILE).mtimeMs;
            if (_configCache !== null && mtime === _configMtime) {
                return _configCache; // devolver caché sin leer disco
            }
            const data = fs.readFileSync(BOT_STATUS_FILE, 'utf8');
            _configCache = JSON.parse(data);
            _configMtime = mtime;
            return _configCache;
        }
    } catch (error) {
        console.error('Error cargando bot-on-off.json:', error.message);
    }
    _configCache = {};
    return _configCache;
}

// Guardar configuración del bot
function saveBotConfig(config) {
    try {
        fs.writeFileSync(BOT_STATUS_FILE, JSON.stringify(config, null, 2), 'utf8');
        // Invalidar caché para que la próxima lectura tome el archivo nuevo
        _configCache = config;
        _configMtime = fs.statSync(BOT_STATUS_FILE).mtimeMs;
        return true;
    } catch (error) {
        console.error('Error guardando bot-on-off.json:', error.message);
        return false;
    }
}

// Verificar si el bot está encendido en un grupo
function isBotEnabled(groupJid) {
    const config = loadBotConfig();
    const cleanJid = groupJid.split('@')[0];
    
    // Por defecto el bot está encendido (true)
    // Retorna false solo si está explícitamente en false
    // Retorna 'admins' si está en modo solo admins
    const status = config[cleanJid];
    if (status === false) return false;
    if (status === 'admins') return 'admins';
    return true;
}

// Activar/desactivar bot en un grupo
function setBotStatus(groupJid, mode) {
    const config = loadBotConfig();
    const cleanJid = groupJid.split('@')[0];
    
    if (mode === 'on' || mode === true) {
        // Si se enciende, eliminamos la entrada (por defecto está on)
        delete config[cleanJid];
    } else if (mode === 'admins') {
        // Modo solo admins
        config[cleanJid] = 'admins';
    } else if (mode === 'off' || mode === false) {
        // Solo guardamos cuando está apagado
        config[cleanJid] = false;
    }
    
    return saveBotConfig(config);
}

// Comando .bot
let handler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener argumentos del comando
        const args = message.body.split(/\s+/).slice(1);

        // Si no hay argumentos, mostrar estado actual
        if (args.length === 0) {
            const status = isBotEnabled(chatId);
            let statusText, emoji, icon;
            
            if (status === false) {
                statusText = '❌ Apagado';
                emoji = '🔴';
                icon = '❌';
            } else if (status === 'admins') {
                statusText = '🔒 Solo Administradores';
                emoji = '🟡';
                icon = '🔒';
            } else {
                statusText = '✅ Encendido';
                emoji = '🟢';
                icon = '✅';
            }
            
            let texto = `${emoji} *ESTADO DEL BOT*\n\n`;
            texto += `📊 *Estado actual:* ${statusText}\n\n`;
            texto += `💡 *Uso:*\n`;
            texto += `   • .bot on - Encender el bot (todos)\n`;
            texto += `   • .bot off - Apagar el bot\n`;
            texto += `   • .bot admins - Solo admins pueden usarlo\n\n`;
            
            if (status === false) {
                texto += `ℹ️ El bot está apagado y no responderá a ningún comando (excepto .bot on)`;
            } else if (status === 'admins') {
                texto += `ℹ️ Solo los administradores del grupo pueden usar el bot`;
            } else {
                texto += `ℹ️ El bot está disponible para todos los miembros del grupo`;
            }
            
            return await message.reply(texto);
        }

        // Procesar comando on/off/admins
        const action = args[0]?.toLowerCase();

        if (!['on', 'off', 'admins', 'encender', 'apagar'].includes(action)) {
            return await message.reply('⚠️ Usa: .bot on/off/admins');
        }

        let mode;
        if (['on', 'encender'].includes(action)) {
            mode = 'on';
        } else if (['off', 'apagar'].includes(action)) {
            mode = 'off';
        } else if (action === 'admins') {
            mode = 'admins';
        }
        
        // Guardar configuración
        if (setBotStatus(chatId, mode)) {
            let emoji, status, icon, mensaje;
            
            if (mode === 'on') {
                emoji = '✅';
                status = 'encendido para todos';
                icon = '🟢';
                mensaje = `${icon} *Bot ${status}*\n\n`;
                mensaje += `Todos los miembros del grupo pueden usar el bot ahora.`;
            } else if (mode === 'off') {
                emoji = '❌';
                status = 'apagado';
                icon = '🔴';
                mensaje = `${icon} *Bot ${status}*\n\n`;
                mensaje += `El bot dejará de responder a comandos en este grupo.\n\n`;
                mensaje += `💡 Para volver a encenderlo, usa: *.bot on*`;
            } else if (mode === 'admins') {
                emoji = '🔒';
                status = 'modo solo administradores';
                icon = '🟡';
                mensaje = `${icon} *Bot en ${status}*\n\n`;
                mensaje += `Solo los administradores del grupo pueden usar el bot ahora.\n\n`;
                mensaje += `💡 Para permitir a todos, usa: *.bot on*`;
            }
            
            await message.reply(mensaje);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando bot:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['bot'];
handler.tags = ['admin'];
handler.command = /^(bot)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.isBotEnabled = isBotEnabled;
module.exports.setBotStatus = setBotStatus;