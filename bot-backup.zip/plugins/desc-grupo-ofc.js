// descfijo.js

/**
 * Comando: descfijo / desofc
 * Descripción: Actualiza la descripción de un GRUPO OBJETIVO predefinido.
 * Uso: .descfijo <texto>
 */

let handler = async (message, { conn }) => {
    
    // ⚠️ CONFIGURACIÓN CLAVE ⚠️
    // =========================================================================
    // 1. JID del Grupo que se va a modificar (¡Usamos el que nos diste!)
    const GRUPO_OBJETIVO_JID = '120363421753468722@g.us'; 
    
    // 2. JIDs AUTORIZADOS
    const JIDS_AUTORIZADOS = [
        '59893900470@s.whatsapp.net',
        '149078365237384@lid',
        '59892099606@s.whatsapp.net',
        '106502773850321@lid'
    ];
    // =========================================================================

    try {
        // --- 1. Verificar Permisos (JIDs Autorizados) ---
        const senderJid = message.sender; 
        const isAuthorized = JIDS_AUTORIZADOS.includes(senderJid);

        if (!isAuthorized) {
            return await message.reply('❌ No tienes permiso para usar este comando.');
        }

        // --- 2. Obtener el nuevo texto de la descripción ---
        const text = message.body.split(' ').slice(1).join(' ').trim();

        if (!text) {
            return await message.reply('⚠️ Debes escribir la *nueva descripción* para el grupo fijo.\n\n*Ejemplo:*\n`.descfijo Nueva Descripción Oficial del Grupo`');
        }

        const newDescription = text.substring(0, 1024); 

        // --- 3. Verificar si el bot tiene permisos en el grupo objetivo ---

        let groupMetadata;
        try {
            groupMetadata = await conn.groupMetadata(GRUPO_OBJETIVO_JID);
        } catch (e) {
            return await message.reply(`❌ El bot no pudo obtener los metadatos de ese grupo. Asegúrate de que el bot esté en el grupo: \`${GRUPO_OBJETIVO_JID}\``);
        }

        // --- Lógica Mejorada para encontrar el JID del Bot (Adaptada de tu código) ---
        const botJid = conn.user.id;
        
        // Extraer solo la parte numérica (ID) del JID del bot, manejando formatos con y sin ':'.
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            // Fallback: buscar por el formato de ID de los participantes admin (ej. @lid)
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }
        
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        // --- FIN Lógica Mejorada ---

        if (!botIsAdmin) {
            // Si tu bot es admin, este mensaje es la clave. Si aun así falla,
            // significa que conn.groupMetadata no está reportando el bot como admin.
            return await message.reply(`❌ No puedo cambiar la descripción en el grupo objetivo porque *no soy administrador* allí. (Verificación fallida)`);
        }

        // --- 4. Acción de cambiar la descripción ---

        await conn.groupUpdateDescription(GRUPO_OBJETIVO_JID, newDescription);

        await message.reply(`✅ *Descripción del grupo oficial actualizada correctamente.*`);

    } catch (error) {
        console.error(`[ERROR] Error en comando descfijo para ${GRUPO_OBJETIVO_JID}:`, error.message);
        
        let errorMsg = '❌ Ocurrió un error inesperado al intentar cambiar la descripción.';
        if (error.toString().includes('forbidden') || error.toString().includes('403')) {
            errorMsg = '❌ El bot tiene un error de permisos API. Asegúrate de que el bot sea administrador y tenga el permiso de "Editar info. del grupo".';
        }
        
        return await message.reply(errorMsg);
    }
};

// --- Configuración del Handler ---
handler.help = ['descfijo <texto>', 'desofc <texto>'];
handler.tags = ['admin'];
handler.command = /^(descfijo|desofc)$/i;

module.exports = handler;