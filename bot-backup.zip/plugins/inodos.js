const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

let handler = async (message, { }) => {
    try {
        const tmpDir = os.tmpdir();

        // Contar archivos en /tmp
        let tmpFiles = [];
        try {
            tmpFiles = fs.readdirSync(tmpDir);
        } catch (e) {
            tmpFiles = [];
        }

        const total = tmpFiles.length;

        // Contar por extensión
        const byExt = {};
        for (const f of tmpFiles) {
            const ext = path.extname(f).toLowerCase() || '(sin ext)';
            byExt[ext] = (byExt[ext] || 0) + 1;
        }

        // Ordenar por cantidad
        const extSorted = Object.entries(byExt)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .map(([ext, count]) => `  ${ext}: ${count}`)
            .join('\n');

        // Tamaño total de /tmp
        let tmpSizeMB = '?';
        try {
            const { stdout } = await execFileAsync('du', ['-sm', tmpDir]);
            tmpSizeMB = stdout.split('\t')[0] + ' MB';
        } catch (_) {}

        // Info de disco con df
        let diskInfo = '?';
        try {
            const { stdout } = await execFileAsync('df', ['-h', tmpDir]);
            const lines = stdout.trim().split('\n');
            if (lines[1]) {
                const parts = lines[1].split(/\s+/);
                diskInfo = `Tamaño: ${parts[1]} | Usado: ${parts[2]} | Libre: ${parts[3]} | Uso: ${parts[4]}`;
            }
        } catch (_) {}

        // Info de inodos con df -i
        let inodeInfo = '?';
        try {
            const { stdout } = await execFileAsync('df', ['-i', tmpDir]);
            const lines = stdout.trim().split('\n');
            if (lines[1]) {
                const parts = lines[1].split(/\s+/);
                inodeInfo = `Total: ${parts[1]} | Usados: ${parts[2]} | Libres: ${parts[3]} | Uso: ${parts[4]}`;
            }
        } catch (_) {}

        const msg = `*🔍 Info del sistema de archivos*\n\n` +
                    `*📁 Archivos en /tmp:* ${total}\n` +
                    `*💾 Tamaño de /tmp:* ${tmpSizeMB}\n\n` +
                    `*📊 Por extensión (top 10):*\n${extSorted || '  (vacío)'}\n\n` +
                    `*💿 Disco:*\n  ${diskInfo}\n\n` +
                    `*🗂️ Inodos:*\n  ${inodeInfo}`;

        return await message.reply(msg);

    } catch (error) {
        console.error('[inodos] Error:', error);
        return await message.reply('❌ Error al obtener la información.');
    }
};

handler.help = ['inodos'];
handler.tags = ['owner'];
handler.command = /^(inodos|tmpinfo|diskinfo)$/i;
handler.owner = true;

module.exports = handler;