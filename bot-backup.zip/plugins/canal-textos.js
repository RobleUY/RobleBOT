// info.js

/**
 * Comando: info
 * Descripción: Cambia la información del perfil del bot (nombre, descripción, foto)
 * Uso: 
 *   /info nombre <texto> - Cambia el nombre del bot
 *   /info bio <texto> - Cambia la descripción/bio del bot
 *   /info foto (responder a imagen) - Cambia la foto de perfil
 *   /info - Muestra la info actual del bot
 */

const fs = require('fs');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// Números autorizados para usar el comando
const AUTHORIZED_NUMBERS = [
    '59893900470',
    '149078365237384'
];

let handler = async (message, { conn, text, args, command }) => {
    try {
        // Obtener el número del usuario (sin @s.whatsapp.net)
        const userNumber = message.key.remoteJid.split('@')[0];
        
        // Verificar que el usuario esté autorizado
        if (!AUTHORIZED_NUMBERS.includes(userNumber)) {
            return await message.reply('❌ No tenés permisos para cambiar la información del bot.');
        }

        const action = args[0]?.toLowerCase();

        // CASO 1: Ver información actual del bot
        if (!action) {
            try {
                const botNumber = conn.user.id.split(':')[0];
                const status = await conn.fetchStatus(botNumber);
                const profilePic = await conn.profilePictureUrl(conn.user.id, 'image').catch(() => null);
                
                let info = '📱 *INFORMACIÓN DEL BOT*\n';
                info += '━━━━━━━━━━━━━━━\n\n';
                info += `👤 *Nombre:* ${conn.user.name || 'Sin nombre'}\n`;
                info += `📝 *Bio:* ${status?.status || 'Sin descripción'}\n`;
                info += `📞 *Número:* +${botNumber}\n`;
                info += `🖼️ *Foto:* ${profilePic ? 'Configurada ✅' : 'Sin foto ❌'}\n\n`;
                info += '━━━━━━━━━━━━━━━\n';
                info += '*Comandos disponibles:*\n';
                info += '• /info nombre <texto>\n';
                info += '• /info bio <texto>\n';
                info += '• /info foto (responder a imagen)';
                
                return await message.reply(info);
            } catch (error) {
                console.error('Error al obtener info:', error);
                return await message.reply('❌ Error al obtener la información del bot.');
            }
        }

        // CASO 2: Cambiar nombre
        if (action === 'nombre' || action === 'name') {
            const nuevoNombre = text.replace(/^(nombre|name)\s+/i, '').trim();
            
            if (!nuevoNombre) {
                return await message.reply('⚠️ *Uso incorrecto*\n\nEscribí el nuevo nombre:\n\n*Ejemplo:*\n/info nombre RobleBot 2.0');
            }

            if (nuevoNombre.length > 25) {
                return await message.reply('❌ El nombre no puede tener más de 25 caracteres.');
            }

            try {
                await conn.updateProfileName(nuevoNombre);
                console.log(`✅ Nombre cambiado a: ${nuevoNombre}`);
                return await message.reply(`✅ *Nombre actualizado*\n\n👤 Nuevo nombre: *${nuevoNombre}*`);
            } catch (error) {
                console.error('Error al cambiar nombre:', error);
                return await message.reply('❌ Error al cambiar el nombre. Intentá de nuevo en unos minutos.');
            }
        }

        // CASO 3: Cambiar bio/descripción
        if (action === 'bio' || action === 'desc' || action === 'descripcion') {
            const nuevaBio = text.replace(/^(bio|desc|descripcion)\s+/i, '').trim();
            
            if (!nuevaBio) {
                return await message.reply('⚠️ *Uso incorrecto*\n\nEscribí la nueva descripción:\n\n*Ejemplo:*\n/info bio Bot multiusos para WhatsApp');
            }

            if (nuevaBio.length > 139) {
                return await message.reply('❌ La descripción no puede tener más de 139 caracteres.');
            }

            try {
                await conn.updateProfileStatus(nuevaBio);
                console.log(`✅ Bio cambiada a: ${nuevaBio}`);
                return await message.reply(`✅ *Descripción actualizada*\n\n📝 Nueva bio: _${nuevaBio}_`);
            } catch (error) {
                console.error('Error al cambiar bio:', error);
                return await message.reply('❌ Error al cambiar la descripción. Intentá de nuevo en unos minutos.');
            }
        }

        // CASO 4: Cambiar foto de perfil
        if (action === 'foto' || action === 'pfp' || action === 'pp' || action === 'imagen') {
            const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            if (!quotedMessage?.imageMessage) {
                return await message.reply('⚠️ *Uso incorrecto*\n\nRespondé a una imagen con:\n\n*Ejemplo:*\n/info foto');
            }

            try {
                console.log('📸 Descargando imagen...');
                const media = await downloadMediaMessage(
                    message.message.extendedTextMessage.contextInfo,
                    'buffer',
                    {},
                    { 
                        logger: console,
                        reuploadRequest: conn.updateMediaMessage
                    }
                );

                console.log('📤 Actualizando foto de perfil...');
                await conn.updateProfilePicture(conn.user.id, media);
                
                console.log('✅ Foto de perfil actualizada');
                return await message.reply('✅ *Foto de perfil actualizada*\n\n🖼️ La nueva foto ya está visible en el perfil del bot.');
            } catch (error) {
                console.error('Error al cambiar foto:', error);
                return await message.reply('❌ Error al cambiar la foto de perfil. Asegurate de que sea una imagen válida.');
            }
        }

        // Si la acción no es válida
        return await message.reply('⚠️ *Acción no válida*\n\n*Opciones disponibles:*\n• /info nombre <texto>\n• /info bio <texto>\n• /info foto (responder a imagen)\n• /info (ver info actual)');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando info:', error, '\x1b[0m');
        
        let errorMsg = '❌ Ocurrió un error al procesar el comando.\n\n';
        errorMsg += `🐛 Error: ${error.message}`;
        
        return await message.reply(errorMsg);
    }
};

handler.help = ['info'];
handler.tags = ['owner'];
handler.command = /^(zzinfo)$/i;

module.exports = handler;