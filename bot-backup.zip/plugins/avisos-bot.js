/**
 * Comando: avisar / anuncio
 * Descripción: Envía un mensaje de aviso a TODOS LOS GRUPOS donde está el bot.
 * Uso: .avisar <texto>
 */
let handler = async (message, { conn }) => {
    
    // ⚠️ CONFIGURACIÓN CLAVE ⚠️
    // =========================================================================
    // JIDs AUTORIZADOS
    const JIDS_AUTORIZADOS = [
        '59893900470@s.whatsapp.net',
        '149078365237384@lid',
        '59892099606@s.whatsapp.net',
        '106502773850321@lid'
    ];
    // =========================================================================
    
    try {
        // --- 1. Verificar Permisos (JIDs Autorizados) ---
        const senderJid = message.sender; 
        const isAuthorized = JIDS_AUTORIZADOS.includes(senderJid);
        
        if (!isAuthorized) {
            return await message.reply('❌ No tienes permiso para usar este comando.');
        }
        
        // --- 2. Obtener el texto del mensaje ---
        const text = message.body.split(' ').slice(1).join(' ').trim();
        
        if (!text) {
            return await message.reply('⚠️ Debes escribir el *mensaje* que quieres enviar a todos los grupos.\n\n*Ejemplo:*\n`.avisar Reunión importante hoy a las 8 PM`');
        }
        
        // --- 3. Obtener todos los grupos ---
        let groups = [];
        
        // Método 1: Intentar usar conn.chats (si existe)
        if (conn.chats && typeof conn.chats === 'object') {
            groups = Object.entries(conn.chats)
                .filter(([jid, chat]) => jid.endsWith('@g.us'))
                .map(([jid]) => jid);
        }
        
        // Método 2: Intentar usar conn.groupFetchAllParticipating() (@whiskeysockets/baileys)
        if (groups.length === 0 && typeof conn.groupFetchAllParticipating === 'function') {
            try {
                const groupsObj = await conn.groupFetchAllParticipating();
                groups = Object.keys(groupsObj);
            } catch (e) {
                console.error('[ERROR] No se pudo obtener grupos con groupFetchAllParticipating:', e.message);
            }
        }
        
        // Método 3: Intentar usar conn.groupMetadata() con lista de grupos conocidos
        if (groups.length === 0 && global.db?.data?.chats) {
            groups = Object.keys(global.db.data.chats)
                .filter(jid => jid.endsWith('@g.us'));
        }
        
        if (groups.length === 0) {
            return await message.reply('❌ No se pudieron obtener los grupos. El bot no está en ningún grupo o hay un problema de conexión.');
        }
        
        // --- 4. Enviar el mensaje a todos los grupos ---
        const mensajeFormateado = `${text}`;
        
        let enviados = 0;
        let fallidos = 0;
        
        await message.reply(`⏳ Enviando mensaje a ${groups.length} grupos...`);
        
        for (const jid of groups) {
            try {
                await conn.sendMessage(jid, { 
                    text: mensajeFormateado 
                });
                enviados++;
                
                // Pequeña pausa para evitar spam/ban
                await new Promise(resolve => setTimeout(resolve, 1000));
                
            } catch (error) {
                console.error(`[ERROR] No se pudo enviar a ${jid}:`, error.message);
                fallidos++;
            }
        }
        
        // Confirmar al usuario que envió el comando
        await message.reply(
            `✅ *Mensaje enviado a los grupos:*\n\n` +
            `✔️ Enviados: ${enviados}\n` +
            `❌ Fallidos: ${fallidos}\n` +
            `📊 Total grupos: ${groups.length}`
        );
        
    } catch (error) {
        console.error(`[ERROR] Error en comando avisar:`, error.message);
        console.error(error.stack);
        
        return await message.reply(
            `❌ Ocurrió un error inesperado:\n\n` +
            `\`\`\`${error.message}\`\`\`\n\n` +
            `Por favor, contacta al desarrollador del bot.`
        );
    }
};

// --- Configuración del Handler ---
handler.help = ['avisar <texto>', 'anuncio <texto>'];
handler.tags = ['admin'];
handler.command = /^(avisar|anuncio)$/i;

module.exports = handler;