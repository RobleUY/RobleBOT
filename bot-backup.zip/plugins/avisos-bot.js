/**
 * Comandos de avisos masivos a grupos
 * .avisar bot <texto>      → solo grupos del bot principal
 * .avisar subbots <texto>  → solo grupos de los subbots
 * .avisar all <texto>      → todos (bot principal + subbots)
 */

const JIDS_AUTORIZADOS = [
    '59893900470@s.whatsapp.net',
    '149078365237384@lid',
    '59892099606@s.whatsapp.net',
    '106502773850321@lid'
];

const IGNORED_GROUP = '120363203689229697@g.us';
const DELAY_MS = 1200; // pausa entre grupos para no saturar

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

/**
 * Obtiene los grupos de un socket dado.
 * Intenta groupFetchAllParticipating primero, luego chats, luego db.
 */
async function getGroupsFromSock(sock) {
    // Método 1: groupFetchAllParticipating (más confiable)
    if (typeof sock.groupFetchAllParticipating === 'function') {
        try {
            const obj = await sock.groupFetchAllParticipating();
            const jids = Object.keys(obj);
            if (jids.length > 0) return jids;
        } catch (e) {
            console.error('[avisar] groupFetchAllParticipating falló:', e.message);
        }
    }

    // Método 2: sock.chats
    if (sock.chats && typeof sock.chats === 'object') {
        const jids = Object.keys(sock.chats).filter(j => j.endsWith('@g.us'));
        if (jids.length > 0) return jids;
    }

    // Método 3: db global (solo para bot principal)
    if (global.db?.data?.chats) {
        return Object.keys(global.db.data.chats).filter(j => j.endsWith('@g.us'));
    }

    return [];
}

function filterIgnoredGroups(groups) {
    return [...new Set(groups)]
        .filter(jid => jid.endsWith('@g.us'))
        .filter(jid => jid !== IGNORED_GROUP);
}

async function isAdminInGroup(sock, groupJid) {
    if (!sock || typeof sock.groupMetadata !== 'function') return false;
    try {
        const metadata = await sock.groupMetadata(groupJid);
        const botId = sock?.user?.id;
        if (!botId || !metadata?.participants) return false;
        const participant = metadata.participants.find(p => p.id === botId);
        return !!participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch (e) {
        return false;
    }
}

async function selectSubbotForGroup(groupJid, subbots) {
    if (subbots.length === 1) return subbots[0];

    const checks = await Promise.all(subbots.map(async (sock) => ({
        sock,
        isAdmin: await isAdminInGroup(sock, groupJid)
    })));

    const adminChecks = checks
        .filter(c => c.isAdmin)
        .sort((a, b) => (Number(a.sock._subNum ?? 9999) - Number(b.sock._subNum ?? 9999)));
    if (adminChecks.length > 0) return adminChecks[0].sock;

    return checks.sort((a, b) => {
        const aNum = Number(a.sock._subNum ?? 9999);
        const bNum = Number(b.sock._subNum ?? 9999);
        return aNum - bNum;
    })[0].sock;
}

/**
 * Envía un texto a una lista de grupos usando el socket dado.
 * Devuelve { enviados, fallidos }.
 */
async function broadcastToGroups(sock, groups, text, label) {
    let enviados = 0;
    let fallidos = 0;
    const total  = groups.length;
    const REPORT_EVERY = 10;

    for (let i = 0; i < groups.length; i++) {
        const jid = groups[i];
        try {
            await sock.sendMessage(jid, { text });
            enviados++;
        } catch (e) {
            console.error(`[avisar] Error enviando a ${jid}:`, e.message);
            fallidos++;
        }
        await sleep(DELAY_MS);

        // Log cada 10 grupos (o al terminar si son menos de 10)
        const procesados = i + 1;
        if (procesados % REPORT_EVERY === 0 || procesados === total) {
            console.log(
                `[avisar] ${label} — ${procesados}/${total} procesados` +
                ` | ✔️ ${enviados} enviados | ❌ ${fallidos} fallidos` +
                ` | ⏳ faltan ${total - procesados}`
            );
        }
    }

    return { enviados, fallidos };
}

// ─── Handler principal ────────────────────────────────────────────────────────

let handler = async (message, { conn }) => {
    try {
        // Permisos
        if (!JIDS_AUTORIZADOS.includes(message.sender)) {
            return await message.reply('❌ No tienes permiso para usar este comando.');
        }

        // Parsear: .avisar <modo> <texto>
        // body ejemplo: ".avisar bot Hola a todos"
        const parts = message.body.trim().split(/\s+/);
        // parts[0] = ".avisar", parts[1] = modo, parts[2..] = texto
        const modo  = (parts[1] || '').toLowerCase();
        const text  = parts.slice(2).join(' ').trim();

        const modosValidos = ['bot', 'subbots', 'all'];

        if (!modosValidos.includes(modo) || !text) {
            return await message.reply(
                `⚠️ *Uso correcto:*\n\n` +
                `• \`.avisar bot <texto>\` — Solo grupos del bot principal\n` +
                `• \`.avisar subbots <texto>\` — Solo grupos de los subbots\n` +
                `• \`.avisar all <texto>\` — Todos los grupos (bot + subbots)`
            );
        }

        // ── Recolectar sockets y grupos según modo ────────────────────────────

        // Bot principal
        const mainSock   = global.conn;
        const subConns   = (global.subConns || []).filter(s => s?.user);

        let tareas = []; // [{ label, sock, groups }]

        if (modo === 'bot' || modo === 'all') {
            const groups = filterIgnoredGroups(await getGroupsFromSock(mainSock));
            if (groups.length > 0) {
                tareas.push({ label: '🤖 Bot principal', sock: mainSock, groups });
            }
        }

        if (modo === 'subbots' || modo === 'all') {
            const groupToSubbots = new Map();

            for (const sub of subConns) {
                const groups = filterIgnoredGroups(await getGroupsFromSock(sub));
                for (const group of groups) {
                    const list = groupToSubbots.get(group) || [];
                    list.push(sub);
                    groupToSubbots.set(group, list);
                }
            }

            const subbotTasks = new Map();
            for (const [group, socks] of groupToSubbots.entries()) {
                const selectedSock = await selectSubbotForGroup(group, socks);
                const key = selectedSock.user?.id || selectedSock._subNum || Math.random();
                if (!subbotTasks.has(key)) {
                    const num = selectedSock._subNum ?? '?';
                    subbotTasks.set(key, {
                        label: `🔹 SubBot #${num}`,
                        sock: selectedSock,
                        groups: []
                    });
                }
                subbotTasks.get(key).groups.push(group);
            }

            for (const task of subbotTasks.values()) {
                tareas.push(task);
            }
        }

        if (tareas.length === 0) {
            return await message.reply('❌ No se encontraron grupos para enviar el mensaje.');
        }

        const totalGrupos = tareas.reduce((acc, t) => acc + t.groups.length, 0);
        await message.reply(
            `⏳ Enviando a *${totalGrupos} grupos* en *${tareas.length} bot(s)*...\n` +
            `_(puede tardar un momento)_`
        );

        // ── Enviar de a uno por bot, en secuencia ─────────────────────────────
        let resumen = `✅ *Aviso enviado*\n\n`;

        for (const tarea of tareas) {
            console.log(`[avisar] Iniciando envío — ${tarea.label} (${tarea.groups.length} grupos)`);
            const { enviados, fallidos } = await broadcastToGroups(tarea.sock, tarea.groups, text, tarea.label);
            resumen +=
                `${tarea.label}\n` +
                `   ✔️ ${enviados} enviados  ❌ ${fallidos} fallidos  📊 ${tarea.groups.length} total\n\n`;
        }

        await message.reply(resumen.trim());

    } catch (error) {
        console.error('[ERROR] avisar:', error.message, error.stack);
        return await message.reply(`❌ Error inesperado:\n\`\`\`${error.message}\`\`\``);
    }
};

handler.help = [
    'avisar bot <texto>',
    'avisar subbots <texto>',
    'avisar all <texto>'
];
handler.tags  = ['admin'];
handler.command = /^(avisar|anuncio)$/i;

module.exports = handler;
