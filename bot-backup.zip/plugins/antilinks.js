const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones en la raíz del proyecto
const DATA_DIR = path.join(__dirname, '..', 'data');
const ANTILINKS_FILE = path.join(DATA_DIR, 'antilinks.json');

// Asegurar que el directorio y el archivo existen
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(ANTILINKS_FILE)) {
    fs.writeFileSync(ANTILINKS_FILE, JSON.stringify({}, null, 2), 'utf8');
}

// Cargar configuración de antilinks
function loadAntilinksConfig() {
    try {
        if (fs.existsSync(ANTILINKS_FILE)) {
            const data = fs.readFileSync(ANTILINKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando antilinks.json:', error.message);
    }
    return {};
}

// Guardar configuración de antilinks
function saveAntilinksConfig(config) {
    try {
        fs.writeFileSync(ANTILINKS_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando antilinks.json:', error.message);
        return false;
    }
}

// Verificar si antilinks está activado en un grupo
function isAntilinksEnabled(groupJid) {
    const config = loadAntilinksConfig();
    const cleanJid = groupJid.split('@')[0];
    return config[cleanJid] === true;
}

// Activar/desactivar antilinks en un grupo
function setAntilinks(groupJid, enabled) {
    const config = loadAntilinksConfig();
    const cleanJid = groupJid.split('@')[0];
    
    if (enabled) {
        config[cleanJid] = true;
    } else {
        delete config[cleanJid];
    }
    
    return saveAntilinksConfig(config);
}

// Regex para detectar enlaces
const LINK_REGEX = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9-]+\.(com|net|org|io|co|xyz|me|tk|ml|ga|cf|gq|info|online|site|website|tech|store|app|dev|bot|gg|tv|fm|edu|gov|mil|int|us|uk|es|de|fr|it|br|ar|mx|cl|pe|ve|ec|py|uy|bo|gt|hn|ni|cr|pa|do|cu|jm|tt|bs|bb|gd|lc|vc|ag|dm|kn|sx|aw|cw|bq|sr|gy|fk)[^\s]*)/gi;

// Comando .join debe ser ignorado
const JOIN_COMMAND_REGEX = /^[./#❤️]\s*(josin|unirse|entrar)/i;

// Handler automático para eliminar enlaces
async function antilinksHandler(message) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Solo procesar en grupos
        if (!chatId || !chatId.endsWith('@g.us')) {
            return;
        }

        // Verificar si antilinks está activado en este grupo
        if (!isAntilinksEnabled(chatId)) {
            return;
        }

        // Extraer texto del mensaje
        let text = '';
        
        if (message.body) {
            text = typeof message.body === 'string' ? message.body : 
                   (message.body.caption || message.body.text || '');
        }
        
        if (!text && message.message) {
            const msg = message.message;
            text = msg.conversation || 
                   msg.extendedTextMessage?.text || 
                   msg.imageMessage?.caption || 
                   msg.videoMessage?.caption || 
                   msg.documentMessage?.caption || 
                   '';
        }

        if (!text || typeof text !== 'string') {
            return;
        }

        // Ignorar si es el comando .join
        if (JOIN_COMMAND_REGEX.test(text.trim())) {
            return;
        }

        // Verificar si el mensaje contiene enlaces
        const hasLink = LINK_REGEX.test(text);
        
        if (!hasLink) {
            return;
        }

        // Obtener conexión
        const sock = message._sock || global.conn;
        if (!conn) {
            console.error('Conexión no disponible para antilinks');
            return;
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // Verificar si el bot es admin (MISMO MÉTODO QUE close.js)
        const botJid = conn.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        let botParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(participantNumber) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });
        
        if (!botParticipant) {
            botParticipant = participants.find(p => {
                return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
            });
        }
        
        const isBotAdmin = botParticipant && 
                          (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!isBotAdmin) {
            return;
        }

        // Verificar si el usuario es admin
        const userId = message.author || message.sender || message.key?.participant;
        const userNumber = userId.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const isUserAdmin = userParticipant && 
                           (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        // Si el usuario es admin, permitir enlaces
        if (isUserAdmin) {
            return;
        }

        // Eliminar el mensaje
        const messageKey = message.key;
        
        if (messageKey) {
            try {
                await sock.sendMessage(chatId, { delete: messageKey });
                console.log(`🗑️ Mensaje con enlace eliminado en ${chatId}`);
                
            } catch (error) {
                console.error('Error eliminando mensaje con enlace:', error.message);
            }
        }

    } catch (error) {
        console.error('Error en antilinks handler:', error.message);
    }
}

// Comando .antilinks
let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener argumentos del comando
        const args = message.body.split(/\s+/).slice(1);

        // Si no hay argumentos, mostrar estado actual
        if (args.length === 0) {
            const isEnabled = isAntilinksEnabled(chatId);
            const status = isEnabled ? '✅ Activado' : '❌ Desactivado';
            
            let texto = '🔗 *ANTILINKS*\n\n';
            texto += `📊 *Estado actual:* ${status}\n\n`;
            texto += `💡 *Uso:*\n`;
            texto += `   • .antilinks on - Activar\n`;
            texto += `   • .antilinks off - Desactivar\n\n`;
            texto += `ℹ️ Cuando está activado, el bot eliminará automáticamente mensajes con enlaces (excepto de admins y el comando .join)`;
            
            return await message.reply(texto);
        }

        // Procesar comando on/off
        const action = args[0]?.toLowerCase();

        if (!['on', 'off', 'activar', 'desactivar'].includes(action)) {
            return await message.reply('⚠️ Usa: .antilinks on/off');
        }

        const enable = ['on', 'activar'].includes(action);
        
        // Verificar si el bot es admin (solo cuando se intenta activar)
        if (enable) {
            // --- Verificación de permisos del Bot (MISMO MÉTODO QUE close.js) ---
            const botJid = conn.user.id;
            const possibleBotNumbers = [
                botJid.split(':')[0].split('@')[0],
                botJid.split('@')[0].split(':')[0]
            ];
            
            let botParticipant = participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return possibleBotNumbers.includes(participantNumber) ||
                       p.id.includes(possibleBotNumbers[0]) ||
                       p.id.includes(possibleBotNumbers[1]);
            });
            
            if (!botParticipant) {
                botParticipant = participants.find(p => {
                    return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
                });
            }
            
            const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

            if (!botIsAdmin) {
                return await message.reply('❌ No puedo activar antilinks porque *no soy administrador* del grupo.\n\n💡 Hazme admin del grupo e intenta de nuevo.');
            }
        }

        // Guardar configuración
        if (setAntilinks(chatId, enable)) {
            const emoji = enable ? '✅' : '❌';
            const status = enable ? 'activado' : 'desactivado';
            await message.reply(`${emoji} *Antilinks* ha sido ${status} en este grupo.`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando antilinks:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['antilinks'];
handler.tags = ['admin'];
handler.command = /^(antilinks|antilink|antienlaces)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.textReplyHandler = antilinksHandler;
