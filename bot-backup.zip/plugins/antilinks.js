const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones en la raíz del proyecto
const DATA_DIR = path.join(__dirname, '..', 'data');
const ANTILINKS_FILE = path.join(DATA_DIR, 'antilinks.json');

// Asegurar que el directorio y el archivo existen
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(ANTILINKS_FILE)) {
    fs.writeFileSync(ANTILINKS_FILE, JSON.stringify({}, null, 2), 'utf8');
}

// Cargar configuración de antilinks
function loadAntilinksConfig() {
    try {
        if (fs.existsSync(ANTILINKS_FILE)) {
            const data = fs.readFileSync(ANTILINKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando antilinks.json:', error.message);
    }
    return {};
}

// Guardar configuración de antilinks
function saveAntilinksConfig(config) {
    try {
        fs.writeFileSync(ANTILINKS_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando antilinks.json:', error.message);
        return false;
    }
}

// Verificar si antilinks está activado en un grupo
function isAntilinksEnabled(groupJid) {
    const config = loadAntilinksConfig();
    const cleanJid = groupJid.split('@')[0];
    return config[cleanJid] === true;
}

// Activar/desactivar antilinks en un grupo
function setAntilinks(groupJid, enabled) {
    const config = loadAntilinksConfig();
    const cleanJid = groupJid.split('@')[0];
    
    if (enabled) {
        config[cleanJid] = true;
    } else {
        delete config[cleanJid];
    }
    
    return saveAntilinksConfig(config);
}

// Regex para detectar enlaces
const LINK_REGEX = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9-]+\.(com|net|org|io|co|xyz|me|tk|ml|ga|cf|gq|info|online|site|website|tech|store|app|dev|bot|gg|tv|fm|edu|gov|mil|int|us|uk|es|de|fr|it|br|ar|mx|cl|pe|ve|ec|py|uy|bo|gt|hn|ni|cr|pa|do|cu|jm|tt|bs|bb|gd|lc|vc|ag|dm|kn|sx|aw|cw|bq|sr|gy|fk)[^\s]*)/gi;

// Comando .join debe ser ignorado
const JOIN_COMMAND_REGEX = /^[./#❤️]\s*(josin|unirse|entrar)/i;

// Handler automático para eliminar enlaces (llamado desde textReplyHandler de plugins)
async function antilinksHandler(message) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Solo procesar en grupos
        if (!chatId || !chatId.endsWith('@g.us')) {
            return;
        }

        // Verificar si antilinks está activado en este grupo
        if (!isAntilinksEnabled(chatId)) {
            return;
        }

        // Extraer texto del mensaje
        let text = '';
        
        if (message.body) {
            text = typeof message.body === 'string' ? message.body : 
                   (message.body.caption || message.body.text || '');
        }
        
        if (!text && message.message) {
            const msg = message.message;
            text = msg.conversation || 
                   msg.extendedTextMessage?.text || 
                   msg.imageMessage?.caption || 
                   msg.videoMessage?.caption || 
                   msg.documentMessage?.caption || 
                   '';
        }

        if (!text || typeof text !== 'string') {
            return;
        }

        // Ignorar si es el comando .join
        if (JOIN_COMMAND_REGEX.test(text.trim())) {
            return;
        }

        // Verificar si el mensaje contiene enlaces
        const hasLink = LINK_REGEX.test(text);
        
        if (!hasLink) {
            return;
        }

        // Obtener conexión (usar la del mensaje primero, luego global)
        const sock = message._sock || global.conn;
        if (!sock || !sock.user) {
            console.error('[AntiLinks] Conexión no disponible');
            return;
        }

        await _performAntilinksDelete(chatId, baileyMsgFromWrapped(message), sock);

    } catch (error) {
        console.error('Error en antilinks handler:', error.message);
    }
}

/**
 * Extrae la key de baileys desde un mensaje wrapeado o desde message._baileyMessage
 */
function baileyMsgFromWrapped(message) {
    return message._baileyMessage || {
        key: message.key,
        message: message.message
    };
}

/**
 * Función principal de verificación antilinks para ser llamada desde index.js.
 * Recibe el mensaje de Baileys crudo y el socket activo.
 * Retorna true si eliminó el mensaje.
 */
async function checkAntilinks(baileyMessage, sock) {
    try {
        if (!sock || !sock.user) return false;

        const chatId = baileyMessage.key.remoteJid;
        if (!chatId?.endsWith('@g.us')) return false;
        if (!isAntilinksEnabled(chatId)) return false;

        // Extraer texto del mensaje de Baileys
        const msg = baileyMessage.message;
        if (!msg) return false;

        const text = msg.conversation ||
                     msg.extendedTextMessage?.text ||
                     msg.imageMessage?.caption ||
                     msg.videoMessage?.caption ||
                     msg.documentMessage?.caption ||
                     '';

        if (!text || typeof text !== 'string') return false;

        // Ignorar comando .join
        if (JOIN_COMMAND_REGEX.test(text.trim())) return false;

        LINK_REGEX.lastIndex = 0;
        if (!LINK_REGEX.test(text)) return false;

        return await _performAntilinksDelete(chatId, baileyMessage, sock);
    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[AntiLinks] Error en checkAntilinks:', error.message);
        }
        return false;
    }
}

/**
 * Verifica permisos y elimina el mensaje si corresponde.
 * Retorna true si eliminó.
 */
async function _performAntilinksDelete(chatId, baileyMessage, sock) {
    try {
        // Obtener metadata del grupo
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        // Verificar si el bot es admin
        const botJid = sock.user.id;
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];

        let botParticipant = participants.find(p => {
            const pNum = p.id.split('@')[0].split(':')[0];
            return possibleBotNumbers.includes(pNum) ||
                   p.id.includes(possibleBotNumbers[0]) ||
                   p.id.includes(possibleBotNumbers[1]);
        });

        if (!botParticipant) {
            botParticipant = participants.find(p =>
                p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin')
            );
        }

        const isBotAdmin = botParticipant &&
                          (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

        if (!isBotAdmin) return false;

        // Verificar si el usuario es admin
        const userId = baileyMessage.key.participant || baileyMessage.key.remoteJid;
        const userNumber = userId.split('@')[0].split(':')[0];

        const userParticipant = participants.find(p => {
            const pNum = p.id.split('@')[0].split(':')[0];
            return pNum === userNumber;
        });

        const isUserAdmin = userParticipant &&
                           (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (isUserAdmin) return false;

        // Verificar si es owner del bot
        try {
            const botConfig = require('../config');
            if (botConfig.isOwner(userNumber) || botConfig.isOwner(`${userNumber}@s.whatsapp.net`)) {
                return false;
            }
        } catch (_) {}

        // Eliminar el mensaje
        try {
            await sock.sendMessage(chatId, { delete: baileyMessage.key });
            console.log(`[AntiLinks] 🗑️ Enlace eliminado de @${userNumber} en ${chatId}`);
            return true;
        } catch (deleteError) {
            if (!deleteError.message?.includes('Connection Closed')) {
                console.error('[AntiLinks] Error eliminando mensaje:', deleteError.message);
            }
            return false;
        }
    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[AntiLinks] Error en _performAntilinksDelete:', error.message);
        }
        return false;
    }
}

// Comando .antilinks
let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener argumentos del comando
        const args = message.body.split(/\s+/).slice(1);

        // Si no hay argumentos, mostrar estado actual
        if (args.length === 0) {
            const isEnabled = isAntilinksEnabled(chatId);
            const status = isEnabled ? '✅ Activado' : '❌ Desactivado';
            
            let texto = '🔗 *ANTILINKS*\n\n';
            texto += `📊 *Estado actual:* ${status}\n\n`;
            texto += `💡 *Uso:*\n`;
            texto += `   • .antilinks on - Activar\n`;
            texto += `   • .antilinks off - Desactivar\n\n`;
            texto += `ℹ️ Cuando está activado, el bot eliminará automáticamente mensajes con enlaces (excepto de admins y el comando .join)`;
            
            return await message.reply(texto);
        }

        // Procesar comando on/off
        const action = args[0]?.toLowerCase();

        if (!['on', 'off', 'activar', 'desactivar'].includes(action)) {
            return await message.reply('⚠️ Usa: .antilinks on/off');
        }

        const enable = ['on', 'activar'].includes(action);
        
        // Verificar si el bot es admin (solo cuando se intenta activar)
        if (enable) {
            // --- Verificación de permisos del Bot (MISMO MÉTODO QUE close.js) ---
            const botJid = conn.user.id;
            const possibleBotNumbers = [
                botJid.split(':')[0].split('@')[0],
                botJid.split('@')[0].split(':')[0]
            ];
            
            let botParticipant = participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return possibleBotNumbers.includes(participantNumber) ||
                       p.id.includes(possibleBotNumbers[0]) ||
                       p.id.includes(possibleBotNumbers[1]);
            });
            
            if (!botParticipant) {
                botParticipant = participants.find(p => {
                    return p.id.includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
                });
            }
            
            const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

            if (!botIsAdmin) {
                return await message.reply('❌ No puedo activar antilinks porque *no soy administrador* del grupo.\n\n💡 Hazme admin del grupo e intenta de nuevo.');
            }
        }

        // Guardar configuración
        if (setAntilinks(chatId, enable)) {
            const emoji = enable ? '✅' : '❌';
            const status = enable ? 'activado' : 'desactivado';
            await message.reply(`${emoji} *Antilinks* ha sido ${status} en este grupo.`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando antilinks:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['antilinks'];
handler.tags = ['admin'];
handler.command = /^(antilinks|antilink|antienlaces)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.textReplyHandler = antilinksHandler;
module.exports.isAntilinksEnabled = isAntilinksEnabled;
module.exports.checkAntilinks = checkAntilinks;
