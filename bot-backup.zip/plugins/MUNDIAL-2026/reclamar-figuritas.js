const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Rutas de archivos
const FIGURITAS_FILE = path.join(__dirname, 'figuritas.json');

// URL del endpoint
const API_URL = 'https://www.robleuy.site/robleapi/mundial2026/players';

// Cache de datos del API
let cachedData = null;
let lastFetch = 0;
const CACHE_DURATION = 60 * 60 * 1000; // 1 hora

/**
 * Obtener datos del API con cache
 */
async function obtenerDatosAPI() {
    const ahora = Date.now();
    
    if (cachedData && (ahora - lastFetch) < CACHE_DURATION) {
        return cachedData;
    }

    try {
        const { data } = await axios.get(API_URL, { timeout: 10000 });
        
        if (data?.success && data?.countries) {
            cachedData = data;
            lastFetch = ahora;
            return data;
        }
        
        return null;
    } catch (error) {
        console.error('Error obteniendo datos del API:', error.message);
        return cachedData;
    }
}

/**
 * Obtener figurita aleatoria
 */
async function obtenerFiguritaAleatoria() {
    const datos = await obtenerDatosAPI();
    
    if (!datos || !datos.countries) return null;

    const paises = Object.keys(datos.countries);
    const paisAleatorio = paises[Math.floor(Math.random() * paises.length)];
    const paisData = datos.countries[paisAleatorio];
    
    if (!paisData.players || paisData.players.length === 0) return null;

    const jugadorAleatorio = paisData.players[Math.floor(Math.random() * paisData.players.length)];
    
    return {
        pais: paisAleatorio,
        numero: jugadorAleatorio.number,
        imageUrl: jugadorAleatorio.imageUrl,
        downloadUrl: jugadorAleatorio.downloadUrl
    };
}

// --- Carga y Guardado de Datos ---
let figuritasData = {};
try {
    figuritasData = JSON.parse(fs.readFileSync(FIGURITAS_FILE, 'utf8'));
} catch (error) {
    if (error.code !== 'ENOENT') {
        console.error(`Error al cargar ${FIGURITAS_FILE}:`, error.code);
    }
    figuritasData = {};
}

function guardarFiguritas() {
    fs.writeFileSync(FIGURITAS_FILE, JSON.stringify(figuritasData, null, 2));
}

// Manejador Principal
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const senderId = message.author || message.from;
        const senderNumber = senderId.split('@')[0].split(':')[0];

        // Inicializar datos del usuario
        if (!figuritasData[senderNumber]) {
            figuritasData[senderNumber] = {
                figuritas: [],
                ultimoClaim: 0,
                jid: senderId,
            };
        }

        const args = text ? text.trim().split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        // COMANDO: .figurita (sin argumentos) - Mostrar lista
        if (!subCommand) {
            const totalFiguritas = figuritasData[senderNumber].figuritas.length;
            
            if (totalFiguritas === 0) {
                return await message.reply(
                    '📋 *TU ÁLBUM DEL MUNDIAL 2026* 📋\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    '❌ *¡Tu álbum está vacío!*\n\n' +
                    '🎯 *Para reclamar tu primera figurita:*\n' +
                    '`.figurita claim`\n' +
                    '`.figurita reclamar`\n\n' +
                    '⏰ _Puedes reclamar 1 figurita cada hora_'
                );
            }

            // Organizar por país
            const porPais = {};
            figuritasData[senderNumber].figuritas.forEach(fig => {
                if (!porPais[fig.pais]) {
                    porPais[fig.pais] = [];
                }
                porPais[fig.pais].push(fig.numero);
            });

            const datos = await obtenerDatosAPI();
            const totalPosibles = datos?.totalPlayers || '???';
            
            let mensaje = 
                '📋 *TU ÁLBUM DEL MUNDIAL 2026* 📋\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `🏆 *Total de figuritas:* ${totalFiguritas}/${totalPosibles}\n` +
                `🌍 *Países coleccionados:* ${Object.keys(porPais).length}\n\n` +
                '━━━━━━━━━━━━━━━\n\n';

            // Listar por país con total de figuritas disponibles
            const paisesOrdenados = Object.keys(porPais).sort();
            
            for (const pais of paisesOrdenados) {
                const cantidadTengo = porPais[pais].length;
                const totalDelPais = datos?.countries?.[pais]?.totalPlayers || '?';
                mensaje += `🇺🇳 *${pais}* ${cantidadTengo}/${totalDelPais}\n`;
            }

            mensaje += 
                '\n━━━━━━━━━━━━━━━\n\n' +
                '🎯 *Comandos disponibles:*\n' +
                '`.figurita claim` - Reclamar nueva\n' +
                '`.figurita ver [país] [número]` - Ver figurita\n\n' +
                '⏰ _Reclama 1 figurita cada hora_';

            return await message.reply(mensaje);
        }

        // SUBCOMANDO: claim / reclamar
        if (['claim', 'reclamar'].includes(subCommand)) {
            const ultimaVez = figuritasData[senderNumber].ultimoClaim || 0;
            const cooldown = 60 * 60 * 1000; // 1 hora
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(
                    `⏳ *¡Aún estás en cooldown!*\n\n` +
                    `Puedes reclamar otra figurita en:\n` +
                    `*${minutos}m ${segundos}s*`
                );
            }

            if (!conn) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            await message.reply('🔍 *Buscando tu nueva figurita...*');

            let intentos = 0;
            let figuritaNueva = null;
            const maxIntentos = 50;

            // Intentar obtener una figurita que no tenga
            while (intentos < maxIntentos) {
                const figurita = await obtenerFiguritaAleatoria();
                
                if (!figurita) {
                    return await message.reply('❌ *Error al obtener figurita del servidor.*');
                }

                const yaLaTiene = figuritasData[senderNumber].figuritas.some(
                    fig => fig.pais === figurita.pais && fig.numero === figurita.numero
                );

                if (!yaLaTiene) {
                    figuritaNueva = figurita;
                    break;
                }
                
                intentos++;
            }

            // Si después de 50 intentos no encontró una nueva, dar una aleatoria
            if (!figuritaNueva) {
                figuritaNueva = await obtenerFiguritaAleatoria();
            }

            if (!figuritaNueva) {
                return await message.reply('❌ *Error al obtener figurita del servidor.*');
            }

            // Agregar a la colección
            figuritasData[senderNumber].figuritas.push({
                pais: figuritaNueva.pais,
                numero: figuritaNueva.numero,
                imageUrl: figuritaNueva.imageUrl,
                downloadUrl: figuritaNueva.downloadUrl,
                fecha: ahora
            });
            
            figuritasData[senderNumber].ultimoClaim = ahora;
            guardarFiguritas();

            const esDuplicada = intentos >= maxIntentos;
            const totalFiguritas = figuritasData[senderNumber].figuritas.length;

            const caption =
                `🎉 *¡NUEVA FIGURITA!* 🎉\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `🌍 *País:* ${figuritaNueva.pais}\n` +
                `📊 *Total en tu álbum:* ${totalFiguritas}\n\n` +
                (esDuplicada ? '⚠️ _¡Figurita duplicada!_\n\n' : '') +
                `_¡Felicidades!_\n` +
                `_Reclama de nuevo en 1 hora._ ⏰`;

            try {
                await sock.sendMessage(message.from, {
                    image: { url: figuritaNueva.imageUrl },
                    caption: caption
                });
            } catch (error) {
                console.error('Error enviando imagen:', error);
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._');
            }

            return;
        }

        // SUBCOMANDO: ver [país] [número]
        if (subCommand === 'ver') {
            const paisBuscado = args[1];
            const numeroBuscado = parseInt(args[2]);

            if (!paisBuscado || isNaN(numeroBuscado)) {
                return await message.reply(
                    '❌ *Formato inválido*\n\n' +
                    '_Usa: .figurita ver [país] [número]_\n\n' +
                    '*Ejemplo:*\n' +
                    '`.figurita ver Uruguay 1`'
                );
            }

            // Buscar el país (case insensitive)
            const datos = await obtenerDatosAPI();
            
            if (!datos || !datos.countries) {
                return await message.reply('❌ *Error al obtener datos del servidor.*');
            }

            const paisEncontrado = Object.keys(datos.countries).find(
                p => p.toLowerCase() === paisBuscado.toLowerCase()
            );

            if (!paisEncontrado) {
                return await message.reply(`❌ *País "${paisBuscado}" no encontrado.*`);
            }

            const figurita = figuritasData[senderNumber].figuritas.find(
                fig => fig.pais === paisEncontrado && fig.numero === numeroBuscado
            );

            if (!figurita) {
                return await message.reply(
                    `❌ *No tienes la figurita #${numeroBuscado} de ${paisEncontrado}*\n\n` +
                    '_Usa `.figurita` para ver tu colección._'
                );
            }

            if (!conn) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const caption =
                `📋 *FIGURITA EN TU ÁLBUM* 📋\n` +
                `━━━━━━━━━━━━━━━\n\n` +
                `🌍 *País:* ${figurita.pais}\n\n` +
                `_Esta figurita es parte de tu colección._ ✨`;

            try {
                await sock.sendMessage(message.from, {
                    image: { url: figurita.imageUrl },
                    caption: caption
                });
            } catch (error) {
                console.error('Error enviando imagen:', error);
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen._');
            }

            return;
        }

        // Comando no reconocido
        return await message.reply(
            '❓ *Comando no reconocido*\n\n' +
            '🎯 *Comandos disponibles:*\n' +
            '`.figurita` - Ver tu álbum\n' +
            '`.figurita claim` - Reclamar figurita\n' +
            '`.figurita reclamar` - Reclamar figurita\n' +
            '`.figurita ver [país] [número]` - Ver figurita específica\n\n' +
            '*Ejemplo:*\n' +
            '`.figurita ver Uruguay 1`'
        );

    } catch (error) {
        console.error('Error en handler de figuritas:', error);
        return await message.reply('❌ *Error interno del comando.*');
    }
};

handler.help = ['figurita', 'figurita claim', 'figurita ver [país] [número]'];
handler.tags = ['juegos', 'mundial'];
handler.command = /^(figurita|figuritas|cromo|cromos|mundial|mundial2026|mundial26)$/i;
handler.group = false;
handler.apodo = true;

module.exports = handler;

