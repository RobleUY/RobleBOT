let handler = async (message, { conn, text }) => {
    const sock = conn || message._sock || global.conn;
    try {
        // Obtener el ID real del remitente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si se proporcionó una cantidad
        if (!text) {
            return await message.reply(
                '❌ *Cantidad no especificada*\n\n' +
                '📋 *Uso correcto:*\n' +
                '`.penal <cantidad>` - _Apostar una cantidad_\n' +
                '`.penal all` - _Apostar todo tu saldo_\n\n' +
                '⚽ _¡Patea el penal y gana el doble si metes gol!_'
            );
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    '❌ *No tienes dinero para apostar*\n\n' +
                    '💡 _Trabaja para ganar dinero usando_ `.work`'
                );
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    '❌ *Cantidad inválida*\n\n' +
                    '💡 _Ingresa un número mayor a 0 o usa_ `all`'
                );
            }
        }

        // Verificar si tiene suficiente saldo
        if (user.money <= 0) {
            return await message.reply(
                '❌ *No tienes dinero para apostar*\n\n' +
                '💡 _Trabaja para ganar dinero usando_ `.work`'
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                '❌ *Saldo insuficiente*\n\n' +
                `💰 *Tu saldo:* $${user.money}\n` +
                `💸 *Intentaste apostar:* $${cantidad}`
            );
        }

        // Decidir resultado al azar: 50% gol, 50% atajada
        const esGol = Math.random() < 0.5;

        // ─── FRAMES COMUNES (toma de carrera + patada) ───
        const framesComunes = [
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅              ⚽  🏃‍♂️\n_Toma carrera..._`,
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅              ⚽ 🏃‍♂️\n_Se acerca..._`,
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅              ⚽🏃‍\n_¡Impacto!_`,
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅          ⚽💨  🧍‍♂️\n_El balón sale disparado..._`,
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅      ⚽💨      🧍‍♂️\n_Mitad de camino..._`,
            `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅  ⚽💨          🧍‍♂️\n_¡A punto de entrar!_`,
        ];

        // ─── FRAMES SEGÚN RESULTADO ───
        let frames;

        if (esGol) {
            // Caso 1: GOL — la pelota entra
            frames = [
                ...framesComunes,
                `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🥅⚽💨            🧍‍♂️\n_¡Entrando al arco!_`,
                // Frame final gol
                `*🎉 ¡GOOOOOOOOL! 🎉*\n` +
                `━━━━━━━━━━━\n` +
                `💥🥅              🧍‍♂️\n\n` +
                `💰 *Ganancia:* +$${cantidad}\n` +
                `💵 *Saldo actual:* $${user.money + cantidad}\n\n` +
                `🏆 _¡Qué cañonazo imparable!_ 🔥`
            ];
        } else {
            // Caso 2: ATAJADA — el 🤲 aparece en el penúltimo slot (antes del arco)
            frames = [
                ...framesComunes,
                // Penúltimo: el arquero levanta las manos ANTES de que llegue la pelota
                `*⚽ TIRO PENAL ⚽*\n━━━━━━━━━━━\n💰 *Apuesta:* $${cantidad}\n\n🤲🥅⚽💨          🧍‍♂️\n_¡El arquero se lanza!_`,
                // Frame final atajada
                `*🧤 ¡ATAJADA! 🧤*\n` +
                `━━━━━━━━━━━\n` +
                `🤲🥅              🧍‍♂️\n\n` +
                `💸 *Pérdida:* -$${cantidad}\n` +
                `💵 *Saldo actual:* $${Math.max(0, user.money - cantidad)}\n\n` +
                `😔 _¡El arquero lo atajó con las dos manos!_ 🫳`
            ];
        }

        // Actualizar saldo según resultado
        if (esGol) {
            user.money += cantidad;
        } else {
            user.money = Math.max(0, user.money - cantidad);
        }
        global.db.setUser(senderNumber, user);

        // ─── ENVIAR PRIMER FRAME ───
        const sentMsg = await sock.sendMessage(message.from, {
            text: frames[0],
            mentions: [senderJid]
        });

        // Esperar antes de animar
        await new Promise(resolve => setTimeout(resolve, 700));

        // ─── ANIMAR EDITANDO EL MENSAJE ───
        for (let i = 1; i < frames.length; i++) {
            // Más rápido durante la volada, más lento en el resultado final
            const delay = i < frames.length - 1 ? 450 : 2500;

            await sock.sendMessage(message.from, {
                text: frames[i],
                edit: sentMsg.key,
                mentions: [senderJid]
            });

            await new Promise(resolve => setTimeout(resolve, delay));
        }

        console.log('\x1b[32m[SUCCESS] Penal completado - Resultado:', esGol ? 'GOL' : 'ATAJADA', '\x1b[0m');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando penal:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al ejecutar la animación.');
    }
};

handler.help = ['penal <cantidad/all>'];
handler.tags = ['economy'];
handler.command = /^(penal)$/i;

module.exports = handler;