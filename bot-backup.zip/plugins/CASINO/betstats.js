// Comando para ver estadísticas de apuestas
let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        let targetNumber = senderJid.split('@')[0];
        let targetJid = senderJid;
        let targetUser = null;
        
        // --- LÓGICA DE BÚSQUEDA DE USUARIO ---
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0];
            targetUser = global.db.getUser(targetNumber);
        } 
        else if (text && text.trim()) {
            const query = text.trim().toLowerCase();
            let foundUser = null;
            let foundNumber = null;
            
            // Buscar por apodo en la DB
            for (const [userNumber, userData] of Object.entries(global.db.data.users)) {
                if (userData.apodo && userData.apodo.toLowerCase() === query) {
                    foundUser = userData;
                    foundNumber = userNumber;
                    break;
                }
            }
            
            if (foundUser) {
                targetNumber = foundNumber;
                targetJid = `${foundNumber}@s.whatsapp.net`;
                targetUser = foundUser;
            } else {
                return await message.reply(`❌ *Usuario no encontrado*\nNo se encontró a nadie con el apodo: *${text.trim()}*`);
            }
        } else {
            targetUser = global.db.getUser(targetNumber);
        }
        
        if (!targetUser) {
            return await message.reply('❌ Usuario no encontrado en la base de datos.');
        }

        // --- DEFINIR NOMBRE A MOSTRAR (Sin @) ---
        // Prioridad: Apodo > Nombre de DB > Número
        const displayUsername = targetUser.apodo || targetUser.name || targetNumber;
        
        // Inicializar betStats si no existe
        if (!targetUser.betStats) {
            return await message.reply(
                '📊 *ESTADÍSTICAS DE APUESTAS*\n\n' +
                `👤 *Jugador:* ${displayUsername}\n\n` +
                '❌ _Este usuario aún no ha realizado ninguna apuesta._\n\n' +
                '💡 _Usa_ `.apostar <cantidad>` _para empezar_',
                { mentions: [targetJid] }
            );
        }
        
        const stats = targetUser.betStats;
        
        // --- CÁLCULOS ---
        const winRate = stats.totalBets > 0 ? ((stats.totalWins / stats.totalBets) * 100).toFixed(1) : 0;
        const lossRate = stats.totalBets > 0 ? ((stats.totalLosses / stats.totalBets) * 100).toFixed(1) : 0;
        const netProfit = stats.totalWonAmount - stats.totalLostAmount;
        const avgBet = stats.totalBets > 0 ? Math.round(stats.totalBetAmount / stats.totalBets) : 0;
        
        let streakText = stats.currentStreak > 0 ? `🔥 ${stats.currentStreak} victoria(s)` : 
                         stats.currentStreak < 0 ? `💔 ${Math.abs(stats.currentStreak)} derrota(s)` : '➖ Sin racha';
        
        let performanceEmoji = netProfit > 0 ? '💰' : netProfit < 0 ? '📉' : '📊';
        
        const formatNumber = (num) => {
            if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
            if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
            return num.toLocaleString();
        };
        
        // --- CONSTRUCCIÓN DEL REPORTE ---
        let report = `🎰 *ESTADÍSTICAS DE APUESTAS*\n\n`;
        report += `👤 *Jugador:* ${displayUsername}\n`;
        report += `🪙 *Saldo actual:* ${targetUser.money.toLocaleString()}\n\n`;
        
        report += `📊 *HISTORIAL:*\n`;
        report += `   • Total apostado: ${formatNumber(stats.totalBetAmount)}\n`;
        report += `   • Total ganado: ${formatNumber(stats.totalWonAmount)}\n`;
        report += `   • Total perdido: ${formatNumber(stats.totalLostAmount)}\n`;
        report += `   • Ganancia neta: ${performanceEmoji} ${netProfit >= 0 ? '+' : ''}${formatNumber(netProfit)}\n\n`;
        
        report += `🎯 *RENDIMIENTO:*\n`;
        report += `   • Apuestas totales: ${stats.totalBets}\n`;
        report += `   • Victorias: ${stats.totalWins} (${winRate}%)\n`;
        report += `   • Derrotas: ${stats.totalLosses} (${lossRate}%)\n`;
        report += `   • Apuesta promedio: ${formatNumber(avgBet)}\n\n`;
        
        report += `🔥 *RACHAS:*\n`;
        report += `   • Racha actual: ${streakText}\n`;
        report += `   • Mejor racha: 🏆 ${stats.bestWinStreak}\n`;
        report += `   • Peor racha: 💀 ${stats.worstLoseStreak}\n\n`;
        
        report += `🏆 *RÉCORDS:*\n`;
        report += `   • Mayor apuesta: ${formatNumber(stats.biggestBet)}\n`;
        report += `   • Mayor ganancia: ${formatNumber(stats.biggestWin)}\n`;
        report += `   • Mayor pérdida: ${formatNumber(stats.biggestLoss)}\n\n`;
        
        if (stats.lastBetTime > 0) {
            const minutesAgo = Math.floor((Date.now() - stats.lastBetTime) / 60000);
            const hoursAgo = Math.floor(minutesAgo / 60);
            const daysAgo = Math.floor(hoursAgo / 24);
            
            let timeText = daysAgo > 0 ? `hace ${daysAgo} día(s)` : 
                           hoursAgo > 0 ? `hace ${hoursAgo} hora(s)` : 
                           minutesAgo > 0 ? `hace ${minutesAgo} min` : 'hace instantes';
            report += `⏰ *Última apuesta:* ${timeText}\n\n`;
        }
        
        // Consejos
        if (stats.totalBets >= 10) {
            report += winRate >= 60 ? `💡 _¡Estás imparable!_` : 
                      winRate <= 40 ? `💡 _Cuidado, la casa siempre gana..._` : 
                      `💡 _Buen ritmo, sigue así._`;
        } else {
            report += `💡 _Juega más para ver estadísticas avanzadas._`;
        }
        
        await message.reply(report, { mentions: [targetJid] });
        
    } catch (error) {
        console.error('[betstats] Error:', error.message);
        return await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['betstats', 'betstats <apodo>'];
handler.tags = ['economy'];
handler.command = /^(betstats|estadisticasapuestas|statsbet)$/i;
handler.group = false;

module.exports = handler;