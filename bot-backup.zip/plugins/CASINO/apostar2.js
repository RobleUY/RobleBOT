// Sistema simple de apuestas

let cooldowns = new Map();

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            return await message.reply('Error al obtener el usuario.');
        }

        const senderNumber = senderJid.split('@')[0];

        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0
            };
            global.db.setUser(senderNumber, user);
        }

        if (!text) {
            return await message.reply(
                'Uso:\n' +
                '.apostar 100\n' +
                '.apostar 50%\n' +
                '.apostar all'
            );
        }

        // Cooldown
        const now = Date.now();
        const cooldown = 3000;

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);

            if (remaining > 0) {
                return await message.reply(
                    `Espera ${Math.ceil(remaining / 1000)} segundos antes de volver a apostar.`
                );
            }
        }

        cooldowns.set(senderNumber, now);

        let cantidad;

        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
        } else if (text.includes('%')) {
            const porcentaje = parseFloat(text.replace('%', ''));

            if (isNaN(porcentaje) || porcentaje <= 0 || porcentaje > 100) {
                return await message.reply('Porcentaje inválido.');
            }

            cantidad = Math.floor((user.money * porcentaje) / 100);
        } else {
            cantidad = parseInt(text);
        }

        if (isNaN(cantidad) || cantidad <= 0) {
            return await message.reply('Cantidad inválida.');
        }

        if (user.money < cantidad) {
            return await message.reply(
                `No tienes suficiente dinero.\n\n` +
                `Saldo: $${user.money}`
            );
        }

        // 50% de probabilidad
        const win = Math.random() < 0.5;

        if (win) {
            user.money += cantidad;

            await message.reply(
                `Ganaste.\n\n` +
                `+ $${cantidad}\n` +
                `Saldo: $${user.money}`
            );
        } else {
            user.money -= cantidad;

            if (user.money < 0) user.money = 0;

            await message.reply(
                `Perdiste.\n\n` +
                `- $${cantidad}\n` +
                `Saldo: $${user.money}`
            );
        }

        global.db.setUser(senderNumber, user);

    } catch (e) {
        console.error(e);
        return await message.reply('Ocurrió un error.');
    }
};

handler.help = ['apostar <cantidad>'];
handler.tags = ['economy'];
handler.command = /^(apostarx|betx)$/i;

handler.owner = true;
handler.group = false;

module.exports = handler;