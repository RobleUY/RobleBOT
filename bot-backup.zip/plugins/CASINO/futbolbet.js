const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'futbolbet.json');

// ── Persistencia ──────────────────────────────────────────────────────────────

function loadDB() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            const empty = { apuestas: {} };
            fs.writeFileSync(DB_PATH, JSON.stringify(empty, null, 2));
            return empty;
        }
        return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    } catch (e) {
        console.error('[FutbolBet] Error cargando DB:', e.message);
        return { apuestas: {} };
    }
}

function saveDB(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[FutbolBet] Error guardando DB:', e.message);
    }
}

// ── Cálculo de multiplicadores ────────────────────────────────────────────────
// El multiplicador se calcula siempre con los totales actuales del pool.
// NO se bloquea al apostar — se bloquea al CERRAR la apuesta.
//
// Fórmula: (poolRival / poolPropio + 1) * RAKE
// Si no hay pool rival → 2.0x (neutro)
// Mínimo 1.10x, máximo 20x

const RAKE = 0.92;

function calcularTotales(ap) {
    const t1 = Object.values(ap.equipo1.apostadores).reduce((s, a) => s + a.cantidad, 0);
    const t2 = Object.values(ap.equipo2.apostadores).reduce((s, a) => s + a.cantidad, 0);
    return { total1: t1, total2: t2, totalPool: t1 + t2 };
}

/**
 * Sistema parimutuel puro (como las apuestas deportivas reales).
 * El pool total menos rake se reparte entre los ganadores proporcionalmente.
 *
 * multi = (totalPool * RAKE) / poolPropio
 *
 * Ejemplos:
 *   Pool A=$700k, Pool B=$300k, total=$1M, rake=8%
 *   → multi A = 920k/700k = 1.31x   (favorito, poca ganancia)
 *   → multi B = 920k/300k = 3.07x   (underdog, más ganancia)
 *
 * Si nadie apostó aún → 2.0x neutro (se ajustará cuando haya apuestas).
 * Si solo hay apuestas en un lado → el otro muestra el multi proyectado
 * asumiendo que alguien apostará (no se puede calcular sin rival real).
 */
function calcularMulti(poolPropio, poolRival) {
    const total = poolPropio + poolRival;
    if (total === 0) return 2.0;   // sin apuestas en ningún lado
    if (poolPropio === 0) return 2.0; // sin apuestas propias, no hay multi real aún
    return parseFloat(((total * RAKE) / poolPropio).toFixed(2));
}

function getMultiActual(ap, lado) {
    const { total1, total2 } = calcularTotales(ap);
    return lado === 1
        ? calcularMulti(total1, total2)
        : calcularMulti(total2, total1);
}

// ── Formateo ──────────────────────────────────────────────────────────────────

function barra(pct, n = 10) {
    const f = Math.round(pct / 100 * n);
    return '█'.repeat(f) + '░'.repeat(n - f);
}

function fmtApuesta(ap) {
    const { total1, total2, totalPool } = calcularTotales(ap);
    const pct1 = totalPool > 0 ? Math.round(total1 / totalPool * 100) : 50;
    const pct2 = 100 - pct1;
    const multi1 = getMultiActual(ap, 1);
    const multi2 = getMultiActual(ap, 2);
    const n1 = Object.keys(ap.equipo1.apostadores).length;
    const n2 = Object.keys(ap.equipo2.apostadores).length;
    const estadoEmoji = ap.estado === 'abierta' ? '🟢' : ap.estado === 'cerrada' ? '🔴' : '✅';
    const multiTexto = ap.estado === 'cerrada'
        ? '🔒 *(multiplicadores fijos)*'
        : '_(varía hasta el cierre)_';

    return (
        `${estadoEmoji} *${ap.nombre}*\n` +
        `🆔 \`${ap.id}\`\n\n` +
        `⚽ *${ap.equipo1.nombre}*\n` +
        `   💰 Pool: $${total1.toLocaleString()}  •  👥 ${n1} apostador(es)\n` +
        `   📊 ${barra(pct1)} ${pct1}%\n` +
        `   ✨ Multi actual: *${multi1}x*\n\n` +
        `⚽ *${ap.equipo2.nombre}*\n` +
        `   💰 Pool: $${total2.toLocaleString()}  •  👥 ${n2} apostador(es)\n` +
        `   📊 ${barra(pct2)} ${pct2}%\n` +
        `   ✨ Multi actual: *${multi2}x*\n\n` +
        `🏦 Pool total: *$${totalPool.toLocaleString()}*\n` +
        `${multiTexto}`
    );
}

// ── Detectar a qué equipo apunta el texto ─────────────────────────────────────

function detectarLado(ap, texto) {
    const t = texto.toLowerCase().trim();
    const e1 = ap.equipo1.nombre.toLowerCase();
    const e2 = ap.equipo2.nombre.toLowerCase();
    // Coincidencia parcial: el texto incluye alguna palabra clave del equipo
    const match1 = e1.split(' ').some(w => w.length > 2 && t.includes(w));
    const match2 = e2.split(' ').some(w => w.length > 2 && t.includes(w));
    if (match1 && !match2) return 'equipo1';
    if (match2 && !match1) return 'equipo2';
    // Fallback exacto
    if (e1.includes(t) || t.includes(e1)) return 'equipo1';
    if (e2.includes(t) || t.includes(e2)) return 'equipo2';
    return null;
}

// ── Subcomandos ───────────────────────────────────────────────────────────────

async function cmdList(message) {
    const db  = loadDB();
    const ids = Object.keys(db.apuestas);
    if (ids.length === 0) return message.reply('⚽ No hay apuestas de fútbol disponibles.');

    let msg = `⚽🏆 *APUESTAS DE FÚTBOL* 🏆⚽\n━━━━━━━━━━━━━━━━━━━\n\n`;
    ids.forEach((id, i) => {
        msg += fmtApuesta(db.apuestas[id]);
        if (i < ids.length - 1) msg += '\n\n' + '─'.repeat(19) + '\n\n';
    });
    msg += '\n\n━━━━━━━━━━━━━━━━━━━\n';
    msg += '`.betfut <id> <equipo> <cant>` — Apostar\n';
    msg += '`.betfut close <id>` — Cerrar _(owner)_\n';
    msg += '`.betfut win <id> <equipo>` — Ganador _(owner)_';

    return message.reply(msg);
}

async function cmdBet(message, parts, senderNum) {
    // parts = [id, ...equipo, cantidad]
    if (parts.length < 3) {
        return message.reply(
            '❌ *Uso:* `.betfut <id> <equipo> <cantidad>`\n' +
            '_Ej: .betfut mexico-vs-inglaterra México 500_'
        );
    }

    const db          = loadDB();
    const id          = parts[0];
    const cantidadRaw = parts[parts.length - 1];
    const textoEquipo = parts.slice(1, parts.length - 1).join(' ');
    const ap          = db.apuestas[id];

    if (!ap) return message.reply(`❌ No existe apuesta \`${id}\`. Usa \`.betfut list\` para ver las disponibles.`);
    if (ap.estado !== 'abierta') return message.reply(`🔴 La apuesta *${ap.nombre}* ya no está abierta (${ap.estado}).`);

    const ladoKey = detectarLado(ap, textoEquipo);
    if (!ladoKey) {
        return message.reply(
            `❌ Equipo no reconocido: *${textoEquipo}*\n\n` +
            `Equipos válidos:\n• ⚽ ${ap.equipo1.nombre}\n• ⚽ ${ap.equipo2.nombre}`
        );
    }

    const user = global.db.getUser(senderNum);
    if (!user) return message.reply('❌ No se pudo obtener tu perfil.');
    user.money = Number(user.money) || 0;

    let cantidad;
    const cr = cantidadRaw.toLowerCase();
    if (cr === 'all') {
        cantidad = user.money;
    } else if (cr.endsWith('%')) {
        const pct = parseFloat(cr);
        if (isNaN(pct) || pct <= 0 || pct > 100) return message.reply('❌ Porcentaje inválido (1-100).');
        cantidad = Math.floor(user.money * pct / 100);
    } else {
        cantidad = parseInt(cr);
    }

    if (isNaN(cantidad) || cantidad <= 0) return message.reply('❌ Cantidad inválida.');
    if (user.money < cantidad) {
        return message.reply(`❌ Saldo insuficiente.\n💰 Tienes: $${user.money.toLocaleString()}\n💸 Intentaste apostar: $${cantidad.toLocaleString()}`);
    }

    const lado = ap[ladoKey];

    // Acumular si ya apostó
    if (lado.apostadores[senderNum]) {
        user.money -= cantidad;
        lado.apostadores[senderNum].cantidad += cantidad;
        // multiplicador: aún no fijo, se asigna al cerrar
        lado.apostadores[senderNum].multiplicador = null;
        global.db.setUser(senderNum, user);
        saveDB(db);

        const { total1, total2, totalPool } = calcularTotales(ap);
        const multiShow = getMultiActual(ap, ladoKey === 'equipo1' ? 1 : 2);

        return message.reply(
            `✅ *Apuesta adicional registrada*\n` +
            `━━━━━━━━━━━━━━━━━━━\n\n` +
            `🏟️ *${ap.nombre}*\n` +
            `⚽ Equipo: *${lado.nombre}*\n` +
            `💸 Añadido: *$${cantidad.toLocaleString()}*\n` +
            `💰 Total tuyo: *$${lado.apostadores[senderNum].cantidad.toLocaleString()}*\n` +
            `📊 Multi actual: *${multiShow}x* _(se fija al cerrar)_\n` +
            `💵 Saldo restante: *$${user.money.toLocaleString()}*`
        );
    }

    // Primera apuesta
    user.money -= cantidad;
    lado.apostadores[senderNum] = { cantidad, multiplicador: null, fecha: Date.now() };
    global.db.setUser(senderNum, user);
    saveDB(db);

    const multiShow = getMultiActual(ap, ladoKey === 'equipo1' ? 1 : 2);

    return message.reply(
        `⚽ *¡Apuesta registrada!*\n` +
        `━━━━━━━━━━━━━━━━━━━\n\n` +
        `🏟️ *${ap.nombre}*\n` +
        `⚽ Equipo: *${lado.nombre}*\n` +
        `💸 Apostado: *$${cantidad.toLocaleString()}*\n` +
        `📊 Multi actual: *${multiShow}x* _(se fija al cerrar)_\n` +
        `💵 Saldo restante: *$${user.money.toLocaleString()}*\n\n` +
        `_El multiplicador quedará fijo cuando el owner cierre la apuesta._`
    );
}

async function cmdClose(message, args) {
    if (!args[0]) return message.reply('❌ Uso: `.betfut close <id>`');

    const db = loadDB();
    const id = args[0];
    const ap = db.apuestas[id];

    if (!ap) return message.reply(`❌ No existe apuesta \`${id}\`.`);
    if (ap.estado !== 'abierta') return message.reply(`❌ La apuesta ya está ${ap.estado}.`);

    // ── CONGELAR MULTIPLICADORES ──────────────────────────────────────────────
    // Se calculan con el pool final justo antes de cerrar
    const { total1, total2 } = calcularTotales(ap);
    const multi1Final = calcularMulti(total1, total2);
    const multi2Final = calcularMulti(total2, total1);

    for (const num of Object.keys(ap.equipo1.apostadores)) {
        ap.equipo1.apostadores[num].multiplicador = multi1Final;
    }
    for (const num of Object.keys(ap.equipo2.apostadores)) {
        ap.equipo2.apostadores[num].multiplicador = multi2Final;
    }

    ap.estado = 'cerrada';
    saveDB(db);

    const totalPool = total1 + total2;
    const n1 = Object.keys(ap.equipo1.apostadores).length;
    const n2 = Object.keys(ap.equipo2.apostadores).length;

    return message.reply(
        `🔴 *¡Apuesta cerrada!*\n` +
        `━━━━━━━━━━━━━━━━━━━\n\n` +
        `🏟️ *${ap.nombre}*\n\n` +
        `⚽ *${ap.equipo1.nombre}*\n` +
        `   💰 Pool: $${total1.toLocaleString()}  •  👥 ${n1} apostador(es)\n` +
        `   🔒 Multiplicador fijo: *${multi1Final}x*\n\n` +
        `⚽ *${ap.equipo2.nombre}*\n` +
        `   💰 Pool: $${total2.toLocaleString()}  •  👥 ${n2} apostador(es)\n` +
        `   🔒 Multiplicador fijo: *${multi2Final}x*\n\n` +
        `🏦 Pool total: *$${totalPool.toLocaleString()}*\n\n` +
        `_Ya no se pueden hacer apuestas. Multiplicadores congelados.\n` +
        `Declara el ganador con:_ \`.betfut win ${id} <equipo>\``
    );
}

async function cmdWin(message, args) {
    if (args.length < 2) return message.reply('❌ Uso: `.betfut win <id> <equipo-ganador>`');

    const db   = loadDB();
    const id   = args[0];
    const texto = args.slice(1).join(' ');
    const ap   = db.apuestas[id];

    if (!ap)                          return message.reply(`❌ No existe apuesta \`${id}\`.`);
    if (ap.estado === 'finalizada')   return message.reply('❌ Esta apuesta ya fue finalizada.');
    if (ap.estado === 'abierta')      return message.reply(`⚠️ Cierra primero la apuesta con \`.betfut close ${id}\``);

    const ladoGanador = detectarLado(ap, texto);
    if (!ladoGanador) {
        return message.reply(
            `❌ Equipo no reconocido: *${texto}*\n\n` +
            `Equipos válidos:\n• ⚽ ${ap.equipo1.nombre}\n• ⚽ ${ap.equipo2.nombre}`
        );
    }

    const ganador  = ap[ladoGanador];
    const perdedor = ladoGanador === 'equipo1' ? ap.equipo2 : ap.equipo1;

    let totalEntregado = 0;
    let ganadores = 0;

    for (const [num, apU] of Object.entries(ganador.apostadores)) {
        const multi   = apU.multiplicador || 2.0;
        const ganancia = Math.floor(apU.cantidad * multi);
        const u = global.db.getUser(num);
        if (u) {
            u.money = (Number(u.money) || 0) + ganancia;
            global.db.setUser(num, u);
            totalEntregado += ganancia;
            ganadores++;
        }
    }

    ap.estado  = 'finalizada';
    ap.ganador = ganador.nombre;
    saveDB(db);

    const perdedores   = Object.keys(perdedor.apostadores).length;
    const totalPerdido = Object.values(perdedor.apostadores).reduce((s, a) => s + a.cantidad, 0);

    return message.reply(
        `🏆⚽ *¡PARTIDO FINALIZADO!* ⚽🏆\n` +
        `━━━━━━━━━━━━━━━━━━━\n\n` +
        `🏟️ *${ap.nombre}*\n\n` +
        `🥇 *GANADOR:* ⚽ *${ganador.nombre}*\n` +
        `💀 *PERDEDOR:* ⚽ ${perdedor.nombre}\n\n` +
        `👑 *${ganadores}* ganador(es) — 💰 Total entregado: *$${totalEntregado.toLocaleString()}*\n` +
        `😢 *${perdedores}* perdedor(es) — 🔥 Total perdido: *$${totalPerdido.toLocaleString()}*\n\n` +
        `_Premios acreditados automáticamente según multiplicadores fijos._`
    );
}

// ── Handlers exportados ───────────────────────────────────────────────────────

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return message.reply('❌ No se pudo identificar al remitente.');
        const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');

        if (!text || !text.trim()) {
            return message.reply(
                '⚽ *FutbolBet*\n━━━━━━━━━━━━━━━━━━━\n\n' +
                '`.betfut list` — Ver partidos\n' +
                '`.betfut <id> <equipo> <cantidad>` — Apostar\n' +
                '`.betfut close <id>` — Cerrar _(owner)_\n' +
                '`.betfut win <id> <equipo>` — Ganador _(owner)_'
            );
        }

        const parts  = text.trim().split(/\s+/);
        const sub    = parts[0].toLowerCase();
        const rest   = parts.slice(1);

        const botCfg  = global.botConfig || require('../../config');
        const isOwner = botCfg?.isOwner?.(senderNum) || botCfg?.isOwner?.(`${senderNum}@s.whatsapp.net`);

        if (sub === 'list')  return await cmdList(message);

        if (sub === 'close') {
            if (!isOwner) return message.reply('🚫 Solo los *owners* pueden cerrar apuestas.');
            return await cmdClose(message, rest);
        }

        if (sub === 'win') {
            if (!isOwner) return message.reply('🚫 Solo los *owners* pueden declarar el ganador.');
            return await cmdWin(message, rest);
        }

        return await cmdBet(message, parts, senderNum);

    } catch (err) {
        console.error('[FutbolBet] Error:', err);
        return message.reply('❌ Error interno en FutbolBet.');
    }
};

handler.help    = ['betfut list', 'betfut <id> <equipo> <cant>', 'betfut close <id>', 'betfut win <id> <equipo>'];
handler.tags    = ['casino', 'economy'];
handler.command = /^betfut$/i;
handler.group   = false;

module.exports = handler;
