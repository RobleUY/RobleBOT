let jugadoresEnPartida = new Map();

// Emojis para las cartas
const SUIT_EMOJIS = ['♠️', '♥️', '♣️', '♦️']; 
const CARD_BACK = '🎴';

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Función para obtener una carta aleatoria con emoji
        const getCarta = () => {
            const cartas = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
            const carta = cartas[Math.floor(Math.random() * cartas.length)];
            const suit = SUIT_EMOJIS[Math.floor(Math.random() * SUIT_EMOJIS.length)];
            return carta + suit;
        };

        // Función para calcular el valor de una mano
        const calcularValor = (mano) => {
            let valor = 0;
            let ases = 0;

            for (let carta of mano) {
                // Obtenemos el valor eliminando el emoji del palo (se asume que el emoji ocupa 2 caracteres)
                const valorCarta = carta.slice(0, -2);
                if (valorCarta === 'A') {
                    ases++;
                } else if (['J', 'Q', 'K'].includes(valorCarta)) {
                    valor += 10;
                } else {
                    valor += parseInt(valorCarta);
                }
            }

            // Manejar los ases (pueden valer 1 u 11)
            for (let i = 0; i < ases; i++) {
                if (valor + 11 <= 21) {
                    valor += 11;
                } else {
                    valor += 1;
                }
            }

            return valor;
        };

        // Verificar si el jugador está en una partida
        let partida = jugadoresEnPartida.get(senderNumber);

        // Si no hay texto, mostrar ayuda
        if (!text) {
            return await message.reply(
                '*🎮 BLACKJACK - AYUDA*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Para jugar:*\n' +
                '`.bj <cantidad>` - _Apostar una cantidad_\n' +
                '`.bj all` - _Apostar todo tu saldo_\n\n' +
                '*Durante el juego:*\n' +
                '`.bj pedir` - _Pedir otra carta_\n' +
                '`.bj plantarse` - _Mantener tus cartas_'
            );
        }

        // Si el jugador ya está en una partida, manejar comandos de juego
        if (partida) {
            const comando = text.toLowerCase().trim();

            if (/^(pedir|hit)$/.test(comando)) {
                // Dar nueva carta al jugador
                partida.manoJugador.push(getCarta());
                const valorJugador = calcularValor(partida.manoJugador);

                if (valorJugador > 21) {
                    // Jugador se pasó, pierde
                    let user = global.db.getUser(senderNumber);
                    // Asegurarse de que el saldo no sea negativo
                    user.money = Math.max(0, user.money - partida.apuesta);
                    global.db.setUser(senderNumber, user);
                    jugadoresEnPartida.delete(senderNumber);
                    return await message.reply(`*💥 ¡Te pasaste!* \n\n📋 *Resumen de la partida:*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer.join(' ')}\n\n💸 *Perdiste:* $${partida.apuesta}\n💰 *Saldo actual:* $${user.money}`);
                }

                return await message.reply(`*🎮 Blackjack en curso*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer[0]} ${CARD_BACK}\n\n*¿Qué deseas hacer?*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_`);

            } else if (/^(plantarse|stand)$/.test(comando)) {
                let valorJugador = calcularValor(partida.manoJugador);
                let valorDealer = calcularValor(partida.manoDealer);

                // El dealer pide cartas hasta tener 17 o más
                while (valorDealer < 17) {
                    partida.manoDealer.push(getCarta());
                    valorDealer = calcularValor(partida.manoDealer);
                }

                let user = global.db.getUser(senderNumber);
                let mensaje = `*🎰 Resultado final*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer.join(' ')} *(${valorDealer})*\n\n`;

                if (valorDealer > 21) {
                    user.money += partida.apuesta;
                    mensaje += `*🎉 ¡GANASTE!*\n_El dealer se pasó_\n\n💰 *Ganancia:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}`;
                } else if (valorJugador > valorDealer) {
                    user.money += partida.apuesta;
                    mensaje += `*🎉 ¡GANASTE!*\n\n💰 *Ganancia:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}`;
                } else if (valorJugador < valorDealer) {
                    user.money = Math.max(0, user.money - partida.apuesta);
                    mensaje += `*💔 ¡Perdiste!*\n\n💸 *Pérdida:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}`;
                } else {
                    mensaje += `*🤝 ¡Empate!*\n\n💱 _Recuperas tu apuesta_\n💵 *Saldo actual:* $${user.money}`;
                }

                global.db.setUser(senderNumber, user);
                jugadoresEnPartida.delete(senderNumber);
                return await message.reply(mensaje);

            } else {
                // Comando no reconocido, mostrar ayuda
                return await message.reply(
                    '❌ *Comando inválido*\n\n' +
                    '*Comandos disponibles:*\n' +
                    '`.bj pedir` - _Pedir otra carta_\n' +
                    '`.bj plantarse` - _Mantener tus cartas_\n\n' +
                    '💡 _Asegúrate de escribir el comando exactamente como se muestra_'
                );
            }
        }

        // Si el jugador no tiene una partida activa, intentar iniciar una nueva

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);
        // Si el usuario no existe o no tiene saldo, no se le permite apostar
        if (!user || user.money <= 0) {
            return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ *Cantidad inválida*\n\n💡 _Ingresa un número mayor a 0 o usa_ `all`');
            }
        }

        // Verificar si el usuario tiene saldo suficiente
        if (cantidad > user.money) {
            return await message.reply(`❌ *Saldo insuficiente*\n\n💰 *Tu saldo:* $${user.money}\n💸 *Intentaste apostar:* $${cantidad}`);
        }

        // Iniciar nueva partida
        const manoJugador = [getCarta(), getCarta()];
        const manoDealer = [getCarta(), getCarta()];
        const valorJugador = calcularValor(manoJugador);
        const valorDealer = calcularValor(manoDealer);

        // Verificar Blackjack natural
        if (valorJugador === 21) {
            // Blackjack: gana 2.5x la apuesta
            const ganancia = Math.floor(cantidad * 2.5);
            user.money += ganancia;
            await message.reply(`*🎰 ¡¡BLACKJACK!!*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${manoJugador.join(' ')} *(21)*\n\n🎉 *¡Victoria instantánea!*\n💰 *Ganancia:* $${ganancia}\n💵 *Saldo actual:* $${user.money}`);
            global.db.setUser(senderNumber, user);
            return;
        }

        // Guardar estado de la partida
        jugadoresEnPartida.set(senderNumber, {
            manoJugador,
            manoDealer,
            apuesta: cantidad
        });

        await message.reply(`*🎮 Nueva partida de Blackjack*\n━━━━━━━━━━━━━━━\n💰 *Tu apuesta:* $${cantidad}\n\n🎯 *Tus cartas:* ${manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${manoDealer[0]} ${CARD_BACK}\n\n*¿Qué deseas hacer?*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_`);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de blackjack:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el juego*\n\n_Ocurrió un error al procesar tu juego._');
    }
};

handler.help = ['bj <cantidad/all>', 'bj pedir', 'bj plantarse'];
handler.tags = ['economy'];
handler.command = /^(bj)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;