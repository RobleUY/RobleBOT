const fs = require('fs');
const path = require('path');
const achievements = require('../../achievements');

// 📁 Ruta del archivo JSON donde se guardan las partidas en curso.
// __dirname asegura que quede en la MISMA carpeta que este archivo .js
const PARTIDAS_PATH = path.join(__dirname, 'bj_partidas.json');

let jugadoresEnPartida = new Map();

// 🔄 Cargar partidas guardadas al iniciar el bot (por si se reinició/apagó)
function cargarPartidas() {
    try {
        if (fs.existsSync(PARTIDAS_PATH)) {
            const data = fs.readFileSync(PARTIDAS_PATH, 'utf-8');
            const obj = JSON.parse(data);
            jugadoresEnPartida = new Map(Object.entries(obj));
            console.log(`[BJ] Se cargaron ${jugadoresEnPartida.size} partida(s) en curso desde bj_partidas.json`);
        }
    } catch (error) {
        console.error('[BJ] Error al cargar bj_partidas.json:', error);
        jugadoresEnPartida = new Map();
    }
}

// 💾 Guardar el estado actual de todas las partidas en el JSON
function guardarPartidas() {
    try {
        const obj = Object.fromEntries(jugadoresEnPartida);
        fs.writeFileSync(PARTIDAS_PATH, JSON.stringify(obj, null, 2), 'utf-8');
    } catch (error) {
        console.error('[BJ] Error al guardar bj_partidas.json:', error);
    }
}

// Cargar al iniciar el módulo
cargarPartidas();

// 📊 Actualizar estadísticas de apuestas (betStats) — compatible con .betstats
// perdio: true = derrota, false = victoria, null = empate
function registrarBetStats(user, apuesta, ganancia, perdio) {
    if (!user.betStats) {
        user.betStats = {
            totalBets: 0, totalWins: 0, totalLosses: 0, totalBetAmount: 0,
            totalWonAmount: 0, totalLostAmount: 0, biggestBet: 0, biggestWin: 0,
            biggestLoss: 0, currentStreak: 0, bestWinStreak: 0, worstLoseStreak: 0, lastBetTime: 0
        };
    }
    const s = user.betStats;
    s.totalBets++;
    s.totalBetAmount += apuesta;
    s.lastBetTime = Date.now();
    if (apuesta > s.biggestBet) s.biggestBet = apuesta;

    if (perdio === false) {
        // Victoria: gananciaReal = lo ganado por encima de la apuesta
        const gananciaReal = Math.max(0, ganancia);
        s.totalWins++;
        s.totalWonAmount += gananciaReal;
        if (gananciaReal > s.biggestWin) s.biggestWin = gananciaReal;
        if (s.currentStreak >= 0) { s.currentStreak++; } else { s.currentStreak = 1; }
        if (s.currentStreak > s.bestWinStreak) s.bestWinStreak = s.currentStreak;
    } else if (perdio === true) {
        s.totalLosses++;
        s.totalLostAmount += apuesta;
        if (apuesta > s.biggestLoss) s.biggestLoss = apuesta;
        if (s.currentStreak <= 0) { s.currentStreak--; } else { s.currentStreak = -1; }
        if (Math.abs(s.currentStreak) > s.worstLoseStreak) s.worstLoseStreak = Math.abs(s.currentStreak);
    }
    // empate (perdio === null): solo suma totalBets/totalBetAmount, no afecta racha
}

// Emojis para las cartas
const SUIT_EMOJIS = ['♠️', '♥️', '♣️', '♦️'];
const CARD_BACK = '🎴';

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Función para obtener una carta aleatoria con emoji
        const getCarta = () => {
            const cartas = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
            const carta = cartas[Math.floor(Math.random() * cartas.length)];
            const suit = SUIT_EMOJIS[Math.floor(Math.random() * SUIT_EMOJIS.length)];
            return carta + suit;
        };

        // Función para calcular el valor de una mano
        const calcularValor = (mano) => {
            let valor = 0;
            let ases = 0;

            for (let carta of mano) {
                const valorCarta = carta.slice(0, -2);
                if (valorCarta === 'A') {
                    ases++;
                } else if (['J', 'Q', 'K'].includes(valorCarta)) {
                    valor += 10;
                } else {
                    valor += parseInt(valorCarta);
                }
            }

            for (let i = 0; i < ases; i++) {
                if (valor + 11 <= 21) {
                    valor += 11;
                } else {
                    valor += 1;
                }
            }

            return valor;
        };

        // Verificar si el jugador está en una partida (persistida)
        let partida = jugadoresEnPartida.get(senderNumber);

        // Si no hay texto, mostrar ayuda (o la partida en curso si existe)
        if (!text) {
            if (partida) {
                const valorJugador = calcularValor(partida.manoJugador);
                return await message.reply(
                    `*⚠️ Ya tienes una partida en curso*\n━━━━━━━━━━━━━━━\n` +
                    `💰 *Tu apuesta:* $${partida.apuesta}\n\n` +
                    `🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n` +
                    `👥 *Dealer:* ${partida.manoDealer[0]} ${CARD_BACK}\n\n` +
                    `*¿Qué deseas hacer?*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_`
                );
            }
            return await message.reply(
                '*🎮 BLACKJACK - AYUDA*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Para jugar:*\n' +
                '`.bj <cantidad>` - _Apostar una cantidad_\n' +
                '`.bj all` - _Apostar todo tu saldo_\n\n' +
                '*Durante el juego:*\n' +
                '`.bj pedir` - _Pedir otra carta_\n' +
                '`.bj plantarse` - _Mantener tus cartas_'
            );
        }

        // Si el jugador ya está en una partida, manejar comandos de juego
        if (partida) {
            const comando = text.toLowerCase().trim();

            // Si intenta iniciar otra partida estando en una, avisarle y mostrar el estado actual
            if (!/^(pedir|hit|plantarse|stand)$/.test(comando)) {
                const valorJugador = calcularValor(partida.manoJugador);
                return await message.reply(
                    `*⚠️ Ya tienes una partida en curso*\n━━━━━━━━━━━━━━━\n` +
                    `💰 *Tu apuesta:* $${partida.apuesta}\n\n` +
                    `🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n` +
                    `👥 *Dealer:* ${partida.manoDealer[0]} ${CARD_BACK}\n\n` +
                    `*Comandos disponibles:*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_\n\n` +
                    `💡 _Debes terminar tu partida actual antes de iniciar otra_`
                );
            }

            if (/^(pedir|hit)$/.test(comando)) {
                // Dar nueva carta al jugador
                partida.manoJugador.push(getCarta());
                const valorJugador = calcularValor(partida.manoJugador);

                if (valorJugador > 21) {
                    let user = global.db.getUser(senderNumber) || {};
                    if (typeof user.money !== 'number' || isNaN(user.money)) user.money = 0;
                    // 📊 Registrar derrota (pasarse) en betStats
                    registrarBetStats(user, partida.apuesta, 0, true);
                    const achievementMsgBust = achievements.addAchievementProgress(user, 'betting');
                    global.db.setUser(senderNumber, user);
                    if (achievementMsgBust) await message.reply(achievementMsgBust).catch(() => {});
                    jugadoresEnPartida.delete(senderNumber);
                    guardarPartidas();
                    return await message.reply(`*💥 ¡Te pasaste!* \n\n📋 *Resumen de la partida:*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer.join(' ')}\n\n💸 *Perdiste:* $${partida.apuesta}\n💰 *Saldo actual:* $${user.money}\n*.betstats* _para ver tus estadísticas_`);
                }

                // Guardar el nuevo estado de la mano (aún en curso)
                jugadoresEnPartida.set(senderNumber, partida);
                guardarPartidas();

                return await message.reply(`*🎮 Blackjack en curso*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer[0]} ${CARD_BACK}\n\n*¿Qué deseas hacer?*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_`);

            } else if (/^(plantarse|stand)$/.test(comando)) {
                let valorJugador = calcularValor(partida.manoJugador);
                let valorDealer = calcularValor(partida.manoDealer);

                while (valorDealer < 17) {
                    partida.manoDealer.push(getCarta());
                    valorDealer = calcularValor(partida.manoDealer);
                }

                let user = global.db.getUser(senderNumber) || {};
                if (typeof user.money !== 'number' || isNaN(user.money)) user.money = 0;
                let mensaje = `*🎰 Resultado final*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${partida.manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${partida.manoDealer.join(' ')} *(${valorDealer})*\n\n`;

                if (valorDealer > 21) {
                    const gananciaReal = partida.apuesta;
                    user.money += partida.apuesta * 2;
                    registrarBetStats(user, partida.apuesta, gananciaReal, false);
                    mensaje += `*🎉 ¡GANASTE!*\n_El dealer se pasó_\n\n💰 *Ganancia:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}\n*.betstats* _para ver tus estadísticas_`;
                } else if (valorJugador > valorDealer) {
                    const gananciaReal = partida.apuesta;
                    user.money += partida.apuesta * 2;
                    registrarBetStats(user, partida.apuesta, gananciaReal, false);
                    mensaje += `*🎉 ¡GANASTE!*\n\n💰 *Ganancia:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}\n*.betstats* _para ver tus estadísticas_`;
                } else if (valorJugador < valorDealer) {
                    registrarBetStats(user, partida.apuesta, 0, true);
                    mensaje += `*💔 ¡Perdiste!*\n\n💸 *Pérdida:* $${partida.apuesta}\n💵 *Saldo actual:* $${user.money}\n*.betstats* _para ver tus estadísticas_`;
                } else {
                    user.money += partida.apuesta;
                    registrarBetStats(user, partida.apuesta, 0, null);
                    mensaje += `*🤝 ¡Empate!*\n\n💱 _Recuperas tu apuesta_\n💵 *Saldo actual:* $${user.money}`;
                }

                const achievementMessage = achievements.addAchievementProgress(user, 'betting');
                global.db.setUser(senderNumber, user);
                jugadoresEnPartida.delete(senderNumber);
                guardarPartidas();
                if (achievementMessage) await message.reply(achievementMessage).catch(() => {});
                return await message.reply(mensaje);
            }
        }

        // Si el jugador no tiene una partida activa, intentar iniciar una nueva

        let user = global.db.getUser(senderNumber);
        if (!user || user.money <= 0) {
            return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
        }

        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ *Cantidad inválida*\n\n💡 _Ingresa un número mayor a 0 o usa_ `all`');
            }
        }

        if (cantidad > user.money) {
            return await message.reply(`❌ *Saldo insuficiente*\n\n💰 *Tu saldo:* $${user.money}\n💸 *Intentaste apostar:* $${cantidad}`);
        }

        // Descontar la apuesta INMEDIATAMENTE, antes de repartir cartas
        user.money -= cantidad;
        global.db.setUser(senderNumber, user);

        // Iniciar nueva partida
        const manoJugador = [getCarta(), getCarta()];
        const manoDealer = [getCarta(), getCarta()];
        const valorJugador = calcularValor(manoJugador);

        // Verificar Blackjack natural
        if (valorJugador === 21) {
            const ganancia = Math.floor(cantidad * 2.5);
            const gananciaReal = ganancia - cantidad;
            user.money += ganancia;
            // 📊 Registrar BJ natural como victoria
            registrarBetStats(user, cantidad, gananciaReal, false);
            const achievementMsgBJ = achievements.addAchievementProgress(user, 'betting');
            global.db.setUser(senderNumber, user);
            if (achievementMsgBJ) await message.reply(achievementMsgBJ).catch(() => {});
            return await message.reply(`*🎰 ¡¡BLACKJACK!!*\n━━━━━━━━━━━━━━━\n🎯 *Tus cartas:* ${manoJugador.join(' ')} *(21)*\n\n🎉 *¡Victoria instantánea!*\n💰 *Ganancia:* $${ganancia - cantidad}\n💵 *Saldo actual:* $${user.money}\n*.betstats* _para ver tus estadísticas_`);
        }

        // Guardar estado de la partida (la apuesta ya fue descontada del saldo) y persistir en JSON
        jugadoresEnPartida.set(senderNumber, {
            manoJugador,
            manoDealer,
            apuesta: cantidad
        });
        guardarPartidas();

        await message.reply(`*🎮 Nueva partida de Blackjack*\n━━━━━━━━━━━━━━━\n💰 *Tu apuesta:* $${cantidad}\n\n🎯 *Tus cartas:* ${manoJugador.join(' ')} *(${valorJugador})*\n👥 *Dealer:* ${manoDealer[0]} ${CARD_BACK}\n\n*¿Qué deseas hacer?*\n📥 *.bj pedir* _para otra carta_\n🛑 *.bj plantarse* _para mantener_`);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de blackjack:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el juego*\n\n_Ocurrió un error al procesar tu juego._');
    }
};

handler.help = ['bj <cantidad/all>', 'bj pedir', 'bj plantarse'];
handler.tags = ['economy'];
handler.command = /^(bj)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;