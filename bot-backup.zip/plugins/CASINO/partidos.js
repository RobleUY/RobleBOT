// Si usás Node.js versión antigua (menor a 18), descomentá la siguiente línea:
// const fetch = require('node-fetch');
const handler = async (m) => {
    try {
        // Tu API Key real
        const API_KEY = '076ad3857f3f4af18c1888f8ddc27f6c'; 

        await m.reply('⏳ *Buscando el resultado del partido...*');

        // Buscamos en una fecha del pasado donde sabemos que hay partidos grandes terminados
        const dateFrom = '2026-06-26';
        const dateTo = '2026-06-26';

        // Petición con el rango de fechas pasadas
        const url = `https://api.football-data.org/v4/matches?dateFrom=${dateFrom}&dateTo=${dateTo}`;
        
        const res = await fetch(url, {
            headers: { 'X-Auth-Token': API_KEY }
        });

        if (!res.ok) {
            return await m.reply('❌ *Error de conexión:* Verificá que la API Key sea correcta o el límite de la API.');
        }

        const data = await res.json();
        const partidos = data.matches || [];

        // Filtramos la lista para agarrar el primer partido que tenga estado 'FINISHED'
        const partidoTerminado = partidos.find(p => p.status === 'FINISHED');

        if (!partidoTerminado) {
            return await m.reply(`❌ *No se encontró ningún partido terminado en esa fecha.*`);
        }

        // 📌 EXTRAEMOS LA INFO DEL PARTIDO
        const local = partidoTerminado.homeTeam.name;
        const visitante = partidoTerminado.awayTeam.name;
        
        // Goles
        const golesLocal = partidoTerminado.score.fullTime.home;
        const golesVisitante = partidoTerminado.score.fullTime.away;
        
        // Quién ganó (HOME_TEAM, AWAY_TEAM o DRAW)
        const ganador = partidoTerminado.score.winner; 

        // Lógica para mostrar el ganador en texto
        let resultadoTexto = '';
        if (ganador === 'HOME_TEAM') {
            resultadoTexto = `🏆 *¡Ganó ${local}!*`;
        } else if (ganador === 'AWAY_TEAM') {
            resultadoTexto = `🏆 *¡Ganó ${visitante}!*`;
        } else {
            resultadoTexto = `🤝 *¡Fue un Empate!*`;
        }

        // Armamos el mensaje final
        let msg = `⚽ *RESULTADO DEL PARTIDO* ⚽\n━━━━━━━━━━━━━━━\n\n`;
        msg += `*${local}*  ${golesLocal} - ${golesVisitante}  *${visitante}*\n\n`;
        msg += `${resultadoTexto}\n`;
        msg += `🏆 Torneo: _${partidoTerminado.competition.name}_\n`;
        msg += `🆔 ID del partido: ${partidoTerminado.id}\n\n`;
        msg += `━━━━━━━━━━━━━━━\n💡 _RobleBOT_`;

        return await m.reply(msg.trim());

    } catch (e) {
        // Se eliminaron los logs para mantener la consola limpia
        return await m.reply(`❌ *Ocurrió un error al obtener la información del partido.*`);
    }
};

handler.help = ['partidos'];
handler.tags = ['info'];
//handler.command = /^(partidos|matches)$/i; 
handler.group = false;

module.exports = handler;