// ⚙️ CONFIGURACIÓN — Probabilidad de que el jugador GANE contra la casa (0 a 1)
// 0.55 = 55% de probabilidad de ganar. Solo aplica cuando NO retas a otro usuario
// (los retos entre usuarios siempre son 50/50, como .apostar).
const WIN_CHANCE = 0.55;

// ⚙️ CONFIGURACIÓN DE VELOCIDAD DE ANIMACIÓN (en milisegundos)
// El total ronda ~3 segundos con estos valores.
const DELAY_ENTRE_FRAMES = 350;   // delay entre cada frame de movimiento
const DELAY_FRAME_FINAL = 600;    // delay antes de mostrar el resultado final

// Emojis y constantes para decoración
const EMOJIS = {
    WIN: ['🎰', '🏆', '🐎', '🎯', '🎪'],
    LOSE: ['💔', '💨', '🌪️', '💫', '🌙']
};

// Nombres de caballos disponibles
const AVAILABLE_HORSES = [
    'Relámpago', 'Furia', 'Trueno', 'Viento Negro', 'Estrella Fugaz',
    'Rayo Dorado', 'Sombra', 'Huracán', 'Fantasma'
];

const TRACK_LENGTH = 6;
const MAX_FRAMES = 6;

// Mapa para almacenar las apuestas/retos pendientes entre jugadores
let apuestasPendientes = new Map();

// Mapa para almacenar el cooldown de cada usuario
let cooldowns = new Map();

// 🧹 LIMPIEZA AUTOMÁTICA DE MEMORIA
setInterval(() => {
    const now = Date.now();
    const cooldownTime = 2000; // 2 segundos

    for (const [key, timestamp] of cooldowns.entries()) {
        if (now - timestamp > cooldownTime * 10) {
            cooldowns.delete(key);
        }
    }

    for (const [key, apuesta] of apuestasPendientes.entries()) {
        if (now - apuesta.timestamp > 120000) { // 2 minutos
            if (apuesta.timeout) {
                clearTimeout(apuesta.timeout);
            }
            apuestasPendientes.delete(key);
        }
    }

    const cooldownSize = cooldowns.size;
    const apuestasSize = apuestasPendientes.size;
    if (cooldownSize > 100 || apuestasSize > 50) {
        console.log(`[HRACE] Limpieza: ${cooldownSize} cooldowns, ${apuestasSize} apuestas pendientes`);
    }
}, 5 * 60 * 1000);

// Elige 2 nombres de caballo aleatorios distintos
function elegirCaballos() {
    const shuffled = [...AVAILABLE_HORSES].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 2);
}

// Genera los frames de texto de la carrera, forzando que "winnerIndex" (0 o 1) gane
function construirFramesCarrera({ cantidad, nombreA, nombreB, winnerIndex, headerInicial, headerCurso }) {
    const horseEmoji = '🐎';
    const loserIndex = winnerIndex === 0 ? 1 : 0;
    const nombres = [nombreA, nombreB];

    let positions = [0, 0];
    let frames = [];

    frames.push(
        `${headerInicial}\n` +
        `━━━━━━━━━━━\n` +
        `💰 *Apuesta:* $${cantidad}\n` +
        `🐎 *${nombres[0]}*  🆚  🐴 *${nombres[1]}*\n\n` +
        `🚦 ¡Preparados... Listos... YA!`
    );

    for (let frame = 0; frame < MAX_FRAMES; frame++) {
        // Avanzar al ganador predeterminado con normalidad
        if (positions[winnerIndex] < TRACK_LENGTH) {
            const advance = Math.floor(Math.random() * 2) + 1;
            positions[winnerIndex] = Math.min(positions[winnerIndex] + advance, TRACK_LENGTH);
        }

        // Avanzar al perdedor, sin dejar que llegue antes que el ganador
        if (positions[loserIndex] < TRACK_LENGTH) {
            const advance = Math.floor(Math.random() * 2) + 1;
            const limite = positions[winnerIndex] >= TRACK_LENGTH
                ? TRACK_LENGTH
                : TRACK_LENGTH - 1;
            positions[loserIndex] = Math.min(positions[loserIndex] + advance, limite);
        }

        let frameText = `${headerCurso}\n💰 Apuesta: $${cantidad}\n\n`;
        for (let i = 0; i < 2; i++) {
            const remainingTrack = '·'.repeat(TRACK_LENGTH - positions[i]);
            const track = `${remainingTrack}${horseEmoji}`;
            frameText += `🏁 ${track} _${nombres[i]}_\n`;
        }
        frames.push(frameText.trim());

        if (positions[winnerIndex] >= TRACK_LENGTH) break;
    }

    return frames;
}

// Envía el frame inicial y va editando el mensaje con el resto de frames + frame final
async function ejecutarAnimacion(sock, chatId, frames, finalFrame, mentions) {
    const sentMsg = await sock.sendMessage(chatId, { text: frames[0], mentions });

    for (let i = 1; i < frames.length; i++) {
        await new Promise(resolve => setTimeout(resolve, DELAY_ENTRE_FRAMES));
        try {
            await sock.sendMessage(chatId, { text: frames[i], edit: sentMsg.key, mentions });
        } catch (err) {
            console.warn('[HRACE] Error editando frame (animación cancelada):', err?.message || err);
            return sentMsg;
        }
    }

    await new Promise(resolve => setTimeout(resolve, DELAY_FRAME_FINAL));
    try {
        await sock.sendMessage(chatId, { text: finalFrame, edit: sentMsg.key, mentions });
    } catch (err) {
        console.warn('[HRACE] Error editando frame final:', err?.message || err);
    }

    return sentMsg;
}

let handler = async (message, { conn, text }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        const senderNumber = senderJid.split('@')[0];

        let user = global.db.getUser(senderNumber);
        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Sin texto -> ayuda
        if (!text) {
            return await message.reply(
                '❌ *Cantidad no especificada*\n\n' +
                '📋 *Uso correcto:*\n' +
                '━━━━━━━━━━━━━━━\n' +
                '`.hrace <cantidad>` - _Apostar contra la casa_\n' +
                '`.hrace all` - _Apostar todo tu saldo_\n' +
                '`.hrace @usuario <cantidad>` - _Retar a un usuario_\n' +
                '`.hrace aceptar @usuario` - _Aceptar un reto_\n' +
                '`.hrace rechazar @usuario` - _Rechazar un reto_\n\n' +
                '🐎 _Compite contra 1 caballo rival y gana el doble si llegas primero_'
            );
        }

        // ── RECHAZAR RETO ──────────────────────────────
        if (text.toLowerCase().startsWith('rechazar')) {
            const mentionedJids = message?.mentions;
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar al retador. Ejemplo: .hrace rechazar @usuario_');
            }

            const retadorJid = mentionedJids[0];
            const retador = retadorJid.split('@')[0];
            const claveApuesta = `${retador}_${senderNumber}`;

            if (!apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *No hay ningún reto pendiente de ese usuario*');
            }

            const apuestaPendiente = apuestasPendientes.get(claveApuesta);
            if (apuestaPendiente.timeout) clearTimeout(apuestaPendiente.timeout);
            apuestasPendientes.delete(claveApuesta);

            return await message.reply(
                '*❌ RETO DE CARRERA RECHAZADO*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `@${senderNumber} ha rechazado la carrera de @${retador}\n\n` +
                `💰 *Cantidad:* $${apuestaPendiente.cantidad}\n\n` +
                '😔 _Mejor suerte la próxima vez_',
                { mentions: [retadorJid, senderJid] }
            );
        }

        // ── ACEPTAR RETO ───────────────────────────────
        if (text.toLowerCase().startsWith('aceptar')) {
            const mentionedJids = message?.mentions;
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar al retador. Ejemplo: .hrace aceptar @usuario_');
            }

            const retadorJid = mentionedJids[0];
            const retador = retadorJid.split('@')[0];
            const claveApuesta = `${retador}_${senderNumber}`;

            if (!apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *No hay ningún reto pendiente de ese usuario*');
            }

            const apuestaPendiente = apuestasPendientes.get(claveApuesta);
            const cantidad = apuestaPendiente.cantidad;
            if (apuestaPendiente.timeout) clearTimeout(apuestaPendiente.timeout);

            let userRetador = global.db.getUser(retador);
            if (!userRetador) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply('❌ *Error: No se pudo obtener los datos del retador*');
            }

            if (userRetador.money < cantidad) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply(
                    '❌ *El retador ya no tiene suficiente saldo*\n\n' +
                    `💰 *Saldo del retador:* $${userRetador.money}\n` +
                    `💸 *Apuesta:* $${cantidad}\n\n` +
                    '🚫 _La carrera ha sido cancelada_'
                );
            }

            if (user.money < cantidad) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply(
                    '❌ *No tienes suficiente saldo para aceptar el reto*\n\n' +
                    `💰 *Tu saldo:* $${user.money}\n` +
                    `💸 *Apuesta:* $${cantidad}\n\n` +
                    '🚫 _La carrera ha sido cancelada_'
                );
            }

            apuestasPendientes.delete(claveApuesta);

            // Reto entre usuarios: siempre 50/50
            const ganaRetador = Math.random() < 0.5;
            const winnerIndex = ganaRetador ? 0 : 1; // 0 = retador, 1 = retado (tú)
            const [nombreA, nombreB] = elegirCaballos();

            const frames = construirFramesCarrera({
                cantidad,
                nombreA: `@${retador}`,
                nombreB: `@${senderNumber}`,
                winnerIndex,
                headerInicial: '*🏇 CARRERA DE CABALLOS INICIADA 🏇*',
                headerCurso: '*🏇 CARRERA EN CURSO*'
            });

            const emoji = ganaRetador
                ? EMOJIS.WIN[Math.floor(Math.random() * EMOJIS.WIN.length)]
                : EMOJIS.LOSE[Math.floor(Math.random() * EMOJIS.LOSE.length)];

            let finalFrame;
            if (ganaRetador) {
                userRetador.money += cantidad;
                user.money = Math.max(0, user.money - cantidad);
                global.db.setUser(retador, userRetador);
                global.db.setUser(senderNumber, user);

                finalFrame =
                    `*${emoji} ¡RESULTADO DE LA CARRERA!*\n` +
                    '━━━━━━━━━━━━━━━\n' +
                    `🐎 *Apuesta:* $${cantidad}\n\n` +
                    `🏆 *Ganador:* @${retador}\n` +
                    `💰 *Ganancia:* +$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${userRetador.money}\n\n` +
                    `😢 *Perdedor:* @${senderNumber}\n` +
                    `💸 *Pérdida:* -$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${user.money}\n\n` +
                    '🍀 _¡La suerte está echada!_';
            } else {
                user.money += cantidad;
                userRetador.money = Math.max(0, userRetador.money - cantidad);
                global.db.setUser(senderNumber, user);
                global.db.setUser(retador, userRetador);

                finalFrame =
                    `*${emoji} ¡RESULTADO DE LA CARRERA!*\n` +
                    '━━━━━━━━━━━━━━━\n' +
                    `🐎 *Apuesta:* $${cantidad}\n\n` +
                    `🏆 *Ganador:* @${senderNumber}\n` +
                    `💰 *Ganancia:* +$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${user.money}\n\n` +
                    `😢 *Perdedor:* @${retador}\n` +
                    `💸 *Pérdida:* -$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${userRetador.money}\n\n` +
                    '🍀 _¡La suerte está echada!_';
            }

            await ejecutarAnimacion(sock, message.from, frames, finalFrame, [retadorJid, senderJid]);
            console.log('\x1b[32m[SUCCESS] Carrera PvP completada\x1b[0m');
            return;
        }

        // ── COOLDOWN (no aplica a aceptar/rechazar) ────
        {
            const ahora = Date.now();
            const cooldownTime = 2000;

            if (cooldowns.has(senderNumber)) {
                const ultima = cooldowns.get(senderNumber);
                const restante = cooldownTime - (ahora - ultima);
                if (restante > 0) {
                    const segundos = Math.ceil(restante / 1000);
                    return await message.reply(
                        '⏳ *Cooldown activo*\n\n' +
                        `_Espera ${segundos} segundo${segundos > 1 ? 's' : ''} antes de correr de nuevo_`
                    );
                }
            }
            cooldowns.set(senderNumber, ahora);
        }

        // ── RETAR A OTRO USUARIO ────────────────────────
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            const retadoJid = mentionedJids[0];
            const retado = retadoJid.split('@')[0];

            const cantidadMatch = text.replace(/@\d+/g, '').trim().match(/(\d+)/);
            if (!cantidadMatch) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes especificar una cantidad. Ejemplo: .hrace @usuario 100_');
            }

            const cantidad = parseInt(cantidadMatch[1]);

            if (retado === senderNumber) {
                return await message.reply('❌ *No puedes retarte a ti mismo*');
            }
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ *Cantidad inválida*\n\n_Ingresa un número mayor a 0_');
            }
            if (user.money < cantidad) {
                return await message.reply(
                    '❌ *Saldo insuficiente*\n\n' +
                    `💰 *Tu saldo:* $${user.money}\n` +
                    `💸 *Intentaste apostar:* $${cantidad}`
                );
            }

            let userRetado = global.db.getUser(retado);
            if (!userRetado) {
                return await message.reply('❌ *El usuario mencionado no existe en la base de datos*');
            }
            if (userRetado.money < cantidad) {
                return await message.reply(
                    '❌ *El usuario retado no tiene suficiente saldo*\n\n' +
                    `💰 *Saldo de @${retado}:* $${userRetado.money}\n` +
                    `💸 *Cantidad de apuesta:* $${cantidad}`
                );
            }

            const claveApuesta = `${senderNumber}_${retado}`;
            if (apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *Ya tienes un reto pendiente con este usuario*\n\n_Espera a que responda o que expire_');
            }

            const timeout = setTimeout(async () => {
                if (apuestasPendientes.has(claveApuesta)) {
                    apuestasPendientes.delete(claveApuesta);
                    await message.reply(
                        '*⏰ RETO EXPIRADO*\n' +
                        '━━━━━━━━━━━━━━━\n\n' +
                        `La carrera entre @${senderNumber} y @${retado} ha sido cancelada por falta de respuesta\n\n` +
                        `💰 *Cantidad:* $${cantidad}\n\n` +
                        '⏱️ _El tiempo de 30 segundos ha expirado_',
                        { mentions: [senderJid, retadoJid] }
                    ).catch(() => {});
                }
            }, 30000);

            apuestasPendientes.set(claveApuesta, {
                retador: senderNumber,
                retado: retado,
                cantidad: cantidad,
                timestamp: Date.now(),
                timeout: timeout
            });

            return await message.reply(
                '*🏇 RETO DE CARRERA 🏇*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `@${retado} has sido retado a una carrera de caballos por @${senderNumber}\n\n` +
                `💰 *Cantidad:* $${cantidad}\n` +
                `🎮 *Probabilidad:* 50/50\n` +
                `🏆 *Ganador duplica su dinero*\n\n` +
                `📝 *Responde con:*\n` +
                `✅ .hrace aceptar @${senderNumber}\n` +
                `❌ .hrace rechazar @${senderNumber}\n\n` +
                '⏳ _Tienes 30 segundos para responder_',
                { mentions: [senderJid, retadoJid] }
            );
        }

        // ── APUESTA SOLITARIA (contra la casa) ──────────
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    '❌ *No tienes dinero para apostar*\n\n' +
                    '💡 _Trabaja para ganar dinero usando_ `.work`'
                );
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    '❌ *Cantidad inválida*\n\n' +
                    '💡 _Ingresa un número mayor a 0 o usa_ `all`'
                );
            }
        }

        if (user.money <= 0) {
            return await message.reply(
                '❌ *No tienes dinero para apostar*\n\n' +
                '💡 _Trabaja para ganar dinero usando_ `.work`'
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                '❌ *Saldo insuficiente*\n\n' +
                `💰 *Tu saldo:* $${user.money}\n` +
                `💸 *Intentaste apostar:* $${cantidad}`
            );
        }

        const [nombreJugador, nombreRival] = elegirCaballos();
        const playerWon = Math.random() < WIN_CHANCE;
        const winnerIndex = playerWon ? 0 : 1;

        const frames = construirFramesCarrera({
            cantidad,
            nombreA: nombreJugador,
            nombreB: nombreRival,
            winnerIndex,
            headerInicial: '*🏇 CARRERA DE CABALLOS INICIADA 🏇*',
            headerCurso: '*🏇 CARRERA EN CURSO*'
        });

        let finalFrame;
        if (playerWon) {
            user.money += cantidad;
            global.db.setUser(senderNumber, user);

            finalFrame =
                `*🎉 ¡GANASTE LA CARRERA! 🎉*\n` +
                `━━━━━━━━━━━\n` +
                `🏆 *Tu caballo:* ${nombreJugador}\n` +
                `💰 *Ganancia:* +$${cantidad}\n` +
                `💵 *Saldo actual:* $${user.money}`;
        } else {
            user.money = Math.max(0, user.money - cantidad);
            global.db.setUser(senderNumber, user);

            finalFrame =
                `*💨 PERDISTE LA CARRERA*\n` +
                `━━━━━━━━━━━\n` +
                `🐎 *Tu caballo:* ${nombreJugador}\n` +
                `🏆 *Ganador:* ${nombreRival}\n` +
                `💸 *Pérdida:* -$${cantidad}\n` +
                `💵 *Saldo actual:* $${user.money}`;
        }

        await ejecutarAnimacion(sock, message.from, frames, finalFrame, []);
        console.log('\x1b[32m[SUCCESS] Carrera completada\x1b[0m');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando hrace:', error?.message || error, '\x1b[0m');
        if (!error?.message?.includes('Rate limit') && !error?.message?.includes('rate-overlimit')) {
            await message.reply('❌ Ocurrió un error al ejecutar la carrera de caballos.').catch(() => {});
        }
    }
};

handler.help = ['hrace <cantidad/all>', 'hrace @usuario <cantidad>', 'hrace aceptar @usuario', 'hrace rechazar @usuario'];
handler.tags = ['economy'];
handler.command = /^(hrace|crace|carreracaballos|horserace)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;