// Emojis y constantes para decoración
const EMOJIS = {
    ROJO: '🔴',
    NEGRO: '⚫',
    VERDE: '🟢', 
    RULETA: '🎡',
    DINERO: '💰',
    PERDIDA: '💸',
    GANANCIA: '💵',
    ERROR: '❌',
    INFO: '💡',
    TIEMPO: '⏱️'
};

// Probabilidades y multiplicadores
const OPCIONES = {
    rojo: { probabilidad: 45, multiplicador: 2, emoji: EMOJIS.ROJO },
    negro: { probabilidad: 45, multiplicador: 2, emoji: EMOJIS.NEGRO },
    verde: { probabilidad: 10, multiplicador: 5, emoji: EMOJIS.VERDE }
};

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Si no hay texto, mostrar ayuda
        if (!text) {
            return await message.reply(
                `${EMOJIS.RULETA} *RULETA - AYUDA* ${EMOJIS.RULETA}\n` +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Cómo jugar:*\n' +
                `${EMOJIS.ROJO} .ruleta rojo <cantidad> - _Apostar al rojo (x2)_\n` +
                `${EMOJIS.NEGRO} .ruleta negro <cantidad> - _Apostar al negro (x2)_\n` +
                `${EMOJIS.VERDE} .ruleta verde <cantidad> - _Apostar al verde (x5)_\n\n` +
                '*Ejemplos:*\n' +
                '`.ruleta rojo 100` - _Apostar 100 monedas al rojo_\n' +
                '`.ruleta verde all` - _Apostar todo tu saldo al verde_\n\n' +
                `${EMOJIS.INFO} *Probabilidades:*\n` +
                `${EMOJIS.ROJO} Rojo: 45% (x2)\n` +
                `${EMOJIS.NEGRO} Negro: 45% (x2)\n` +
                `${EMOJIS.VERDE} Verde: 10% (x5)`
            );
        }

        // Separar el color y la cantidad
        const args = text.toLowerCase().split(' ');
        const color = args[0];
        const cantidadText = args[1];

        // Verificar que el color sea válido
        if (!OPCIONES[color]) {
            return await message.reply(
                `${EMOJIS.ERROR} *Color inválido*\n\n` +
                '*Colores disponibles:*\n' +
                `${EMOJIS.ROJO} rojo\n` +
                `${EMOJIS.NEGRO} negro\n` +
                `${EMOJIS.VERDE} verde`
            );
        }

        // Verificar que se proporcionó una cantidad
        if (!cantidadText) {
            return await message.reply(
                `${EMOJIS.ERROR} *Cantidad no especificada*\n\n` +
                `${EMOJIS.INFO} *Uso correcto:*\n` +
                `\.ruleta ${color} <cantidad> o \.ruleta ${color} all`
            );
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (cantidadText.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                    `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
                );
            }
        } else {
            cantidad = parseInt(cantidadText);
            // Validar que sea un número válido y mayor a 0
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *Cantidad inválida*\n\n` +
                    `${EMOJIS.INFO} _Ingresa un número mayor a 0 o usa_ \`all\``
                );
            }
        }

        // Verificar si tiene suficiente saldo
        if (user.money <= 0) {
            return await message.reply(
                `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                `${EMOJIS.ERROR} *Saldo insuficiente*\n\n` +
                `${EMOJIS.DINERO} *Tu saldo:* $${user.money}\n` +
                `${EMOJIS.PERDIDA} *Intentaste apostar:* $${cantidad}`
            );
        }

        // Generar un número aleatorio entre 1 y 100
        const numeroAleatorio = Math.floor(Math.random() * 100) + 1;
        
        // Determinar el resultado
        let resultado = null;
        let acumulado = 0;
        
        for (const [opcion, datos] of Object.entries(OPCIONES)) {
            acumulado += datos.probabilidad;
            if (numeroAleatorio <= acumulado) {
                resultado = opcion;
                break;
            }
        }

        // Verificar si ganó
        const gano = resultado === color;
        const opcionElegida = OPCIONES[color];
        const opcionResultado = OPCIONES[resultado];

        // Calcular ganancias o pérdidas
        let mensaje;
        if (gano) {
            // Calcular ganancia (cantidad * multiplicador - cantidad apostada)
            const ganancia = cantidad * opcionElegida.multiplicador - cantidad;
            user.money += ganancia;
            
            mensaje = 
                `${EMOJIS.RULETA} *¡RULETA - GANASTE!* ${opcionElegida.emoji}\n` +
                '━━━━━━━━━━━━━━━\n' +
                `${opcionElegida.emoji} *Apostaste a:* ${color}\n` +
                `${opcionResultado.emoji} *Resultado:* ${resultado}\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad}\n` +
                `${EMOJIS.GANANCIA} *Ganancia:* $${ganancia}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🍀 _¡La suerte está de tu lado!_';
        } else {
            // Perder lo apostado
            user.money = Math.max(0, user.money - cantidad);
            
            mensaje = 
                `${EMOJIS.RULETA} *¡RULETA - PERDISTE!* ${opcionResultado.emoji}\n` +
                '━━━━━━━━━━━━━━━\n' +
                `${opcionElegida.emoji} *Apostaste a:* ${color}\n` +
                `${opcionResultado.emoji} *Resultado:* ${resultado}\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad}\n` +
                `${EMOJIS.PERDIDA} *Pérdida:* $${cantidad}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🎯 _¡Inténtalo de nuevo!_';
        }

        // Guardar los cambios en la base de datos
        global.db.setUser(senderNumber, user);

        // Enviar mensaje con el resultado
        return await message.reply(mensaje);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de ruleta:', error, '\x1b[0m');
        return await message.reply(`${EMOJIS.ERROR} *Error en el juego*\n\n_Ocurrió un error al procesar tu apuesta._`);
    }
};

handler.help = ['ruleta <color> <cantidad/all>'];
handler.tags = ['economy'];
handler.command = /^(ruleta)$/i;

module.exports = handler;
handler.group = true;