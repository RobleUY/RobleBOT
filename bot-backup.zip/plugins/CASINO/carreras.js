let handler = async (message, { conn, text }) => {
    try {
        // Obtener el ID real del remitente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si se proporcionó una cantidad
        if (!text) {
            return await message.reply(
                '❌ *Cantidad no especificada*\n\n' +
                '📋 *Uso correcto:*\n' +
                '`.carrera <cantidad>` - _Apostar una cantidad_\n' +
                '`.carrera all` - _Apostar todo tu saldo_\n\n' +
                '🏎️ _Compite contra 2 autos y gana el doble si llegas primero_'
            );
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    '❌ *No tienes dinero para apostar*\n\n' +
                    '💡 _Trabaja para ganar dinero usando_ `.work`'
                );
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    '❌ *Cantidad inválida*\n\n' +
                    '💡 _Ingresa un número mayor a 0 o usa_ `all`'
                );
            }
        }

        // Verificar si tiene suficiente saldo
        if (user.money <= 0) {
            return await message.reply(
                '❌ *No tienes dinero para apostar*\n\n' +
                '💡 _Trabaja para ganar dinero usando_ `.work`'
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                '❌ *Saldo insuficiente*\n\n' +
                `💰 *Tu saldo:* $${user.money}\n` +
                `💸 *Intentaste apostar:* $${cantidad}`
            );
        }

        // Lista de autos disponibles
        const availableCars = ['🚗', '🚙', '🚕', '🚓', '🏎️', '🚐', '🚑', '🚒', '🚚'];
        
        // Seleccionar 3 autos aleatorios
        const shuffled = availableCars.sort(() => Math.random() - 0.5);
        const selectedCars = shuffled.slice(0, 3);
        
        // El jugador es siempre el primer auto
        const playerCar = selectedCars[0];
        
        // Posiciones iniciales (todos empiezan en 0)
        let positions = [0, 0, 0];
        const trackLength = 10; // Longitud de la pista
        const maxFrames = 30; // Máximo de frames
        
        let frames = [];
        let winner = null;
        
        // Frame inicial indicando el auto del jugador
        const initialFrame = 
            `*🏁 CARRERA INICIADA 🏁*\n` +
            `━━━━━━━━━━━\n` +
            `💰 *Apuesta:* $${cantidad}\n` +
            `🏎️ *Tu auto:* ${playerCar}\n\n` +
            `🚦 ¡Preparados... Listos... YA!`;
        
        frames.push(initialFrame);
        
        // Generar frames hasta que alguien gane
        for (let frame = 0; frame < maxFrames; frame++) {
            // Mover cada auto aleatoriamente (0, 1 o 2 posiciones)
            for (let i = 0; i < 3; i++) {
                if (positions[i] < trackLength) {
                    const advance = Math.floor(Math.random() * 3); // 0, 1 o 2
                    positions[i] = Math.min(positions[i] + advance, trackLength);
                }
            }
            
            // Crear el frame visual
            let frameText = `*🏁 CARRERA EN CURSO*\n💰 Apuesta: $${cantidad} | 🏎️ Tu auto: ${playerCar}\n\n`;
            for (let i = 0; i < 3; i++) {
                const carPos = positions[i];
                const remainingTrack = '='.repeat(trackLength - carPos); 
                const track = `${remainingTrack}${selectedCars[i]}`;
                
                // Indicar cuál es el auto del jugador
                const indicator = i === 0 ? ' ⭐' : '';
                frameText += `🏁 ${track}${indicator}\n`; 
            }
            
            frames.push(frameText.trim());
            
            // Verificar si algún auto llegó a la meta
            for (let i = 0; i < 3; i++) {
                if (positions[i] >= trackLength && winner === null) {
                    winner = i;
                    break;
                }
            }
            
            // Si hay ganador, salir del loop
            if (winner !== null) break;
        }
        
        // Crear frame final con resultados
        if (winner !== null) {
            const playerWon = winner === 0; // El jugador es siempre el auto en índice 0
            
            // Ordenar posiciones finales
            const results = positions.map((pos, idx) => ({ pos, idx, car: selectedCars[idx] }))
                .sort((a, b) => b.pos - a.pos);
            
            const medals = ['🥇', '🥈', '🥉'];
            
            let finalFrame = '';
            
            if (playerWon) {
                // El jugador ganó
                user.money += cantidad;
                global.db.setUser(senderNumber, user);
                
                finalFrame = 
                    `*🎉 ¡GANASTE LA CARRERA! 🎉*\n` +
                    `━━━━━━━━━━━\n` +
                    `🏆 *Tu auto:* ${playerCar}\n` +
                    `💰 *Ganancia:* +$${cantidad}\n` +
                    `💵 *Saldo actual:* $${user.money}\n\n` +
                    `*Posiciones finales:*\n`;
            } else {
                // El jugador perdió
                user.money = Math.max(0, user.money - cantidad);
                global.db.setUser(senderNumber, user);
                
                finalFrame = 
                    `*💨 PERDISTE LA CARRERA*\n` +
                    `━━━━━━━━━━━\n` +
                    `🏎️ *Tu auto:* ${playerCar}\n` +
                    `🏆 *Ganador:* ${results[0].car}\n` +
                    `💸 *Pérdida:* -$${cantidad}\n` +
                    `💵 *Saldo actual:* $${user.money}\n\n` +
                    `*Posiciones finales:*\n`;
            }
            
            // Añadir posiciones
            results.forEach((result, idx) => {
                const isPlayer = result.idx === 0 ? ' ⭐ (TÚ)' : '';
                finalFrame += `${medals[idx]} ${result.car}${isPlayer}\n`; 
            });
            
            frames.push(finalFrame);
        } else {
            frames.push('\n⏱️ ¡Tiempo agotado! Empate técnico.');
        }
        
        // Enviar el mensaje inicial con el primer frame
        const sentMsg = await conn.sendMessage(message.from, { 
            text: frames[0]
        });
        
        // Esperar un momento antes de empezar a editar
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Editar el mensaje para cada frame
        for (let i = 1; i < frames.length; i++) {
            await conn.sendMessage(message.from, {
                text: frames[i],
                edit: sentMsg.key
            });
            
            // Velocidad: más rápido durante la carrera, más lento en el resultado
            const delay = i < frames.length - 1 ? 300 : 3000;
            await new Promise(resolve => setTimeout(resolve, delay));
        }
        
        console.log('\x1b[32m[SUCCESS] Carrera completada\x1b[0m');
        
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en comando carrera:', error, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al ejecutar la carrera.');
    }
};

handler.help = ['carrera <cantidad/all>'];
handler.tags = ['economy'];
handler.command = /^(carrera|carreras|race)$/i;

module.exports = handler;
handler.group = true;