const fs = require('fs');
const path = require('path');

// 📁 Ruta del archivo JSON donde se guardan las partidas en curso.
// __dirname asegura que quede en la MISMA carpeta que este archivo .js
const PARTIDAS_PATH = path.join(__dirname, 'bomba_partidas.json');

let jugadoresEnPartida = new Map();

// 🔄 Cargar partidas guardadas al iniciar el bot (por si se reinició/apagó)
function cargarPartidas() {
    try {
        if (fs.existsSync(PARTIDAS_PATH)) {
            const data = fs.readFileSync(PARTIDAS_PATH, 'utf-8');
            const obj = JSON.parse(data);
            jugadoresEnPartida = new Map(Object.entries(obj));
            console.log(`[BOMBA] Se cargaron ${jugadoresEnPartida.size} partida(s) en curso desde bomba_partidas.json`);
        }
    } catch (error) {
        console.error('[BOMBA] Error al cargar bomba_partidas.json:', error);
        jugadoresEnPartida = new Map();
    }
}

// 💾 Guardar el estado actual de todas las partidas en el JSON
function guardarPartidas() {
    try {
        const obj = Object.fromEntries(jugadoresEnPartida);
        fs.writeFileSync(PARTIDAS_PATH, JSON.stringify(obj, null, 2), 'utf-8');
    } catch (error) {
        console.error('[BOMBA] Error al guardar bomba_partidas.json:', error);
    }
}

// Cargar al iniciar el módulo
cargarPartidas();

// ⚙️ ═══════════════════════════════════════════════════════
// CONFIGURACIÓN - PROBABILIDAD DE GANAR AL USAR .bomb
// Valor entre 0 y 1. Ejemplo: 0.5 = 50%, 0.4 = 40%, 0.6 = 60%
// ═══════════════════════════════════════════════════════
const PROBABILIDAD_DE_GANAR = 0.6;
// ═══════════════════════════════════════════════════════

// 💣 Multiplicador que se aplica EN CADA RONDA sobre el valor acumulado (interés compuesto)
// Ronda 1 = x1.5, Ronda 2 = x2.0, Ronda 3 = x2.5, etc.
function calcularMultiplicadorRonda(nivel) {
    return parseFloat((1 + 0.5 * nivel).toFixed(2));
}

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Verificar si el jugador está en una partida (persistida)
        let partida = jugadoresEnPartida.get(senderNumber);

        const comando = text ? text.toLowerCase().trim() : '';
        const esRetiro = /^(retirar|retiro|retire)$/.test(comando);

        // ═══════════════════════════════════════════
        // SIN TEXTO
        // ═══════════════════════════════════════════
        if (!text) {
            // Si hay partida activa, sin texto = "jugar" (intentar subir el multiplicador)
            if (partida) {
                const gano = Math.random() < PROBABILIDAD_DE_GANAR;

                if (!gano) {
                    // 💥 Explotó: se pierde todo lo apostado
                    const multiplicadorTotalPerdido = parseFloat((partida.valorActual / partida.apuesta).toFixed(2));
                    jugadoresEnPartida.delete(senderNumber);
                    guardarPartidas();
                    return await message.reply(
                        `💥 Explotó en ronda ${partida.nivel} · x${multiplicadorTotalPerdido}\n` +
                        `💸 Perdiste $${partida.apuesta}`
                    );
                }

                // ✅ Sobrevivió: sube de nivel y se aplica el multiplicador de esta ronda
                // sobre el valor acumulado (interés compuesto)
                partida.nivel += 1;
                const multiplicadorRonda = calcularMultiplicadorRonda(partida.nivel);
                partida.valorActual = Math.floor(partida.valorActual * multiplicadorRonda);
                jugadoresEnPartida.set(senderNumber, partida);
                guardarPartidas();

                const multiplicadorTotal = parseFloat((partida.valorActual / partida.apuesta).toFixed(2));

                return await message.reply(
                    `💣 Ronda ${partida.nivel} · x${multiplicadorTotal}\n` +
                    `💰 $${partida.apuesta} → $${partida.valorActual}\n\n` +
                    `.bomb para seguir | .bomb retirar para cobrar`
                );
            }

            // Sin partida activa y sin texto = mostrar ayuda
            return await message.reply(
                '*💣 BOMBA - AYUDA*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Para jugar:*\n' +
                '`.bomb <cantidad>` - _Apostar una cantidad_\n' +
                '`.bomb all` - _Apostar todo tu saldo_\n\n' +
                '*Durante el juego:*\n' +
                '`.bomb` - _Arriesgar y subir el multiplicador (50/50)_\n' +
                '`.bomb retirar` - _Cobrar tu ganancia actual_\n\n' +
                '_Cada ronda que sobrevives sube tu multiplicador, pero si la bomba explota pierdes toda tu apuesta._'
            );
        }

        // ═══════════════════════════════════════════
        // CON TEXTO Y PARTIDA ACTIVA
        // ═══════════════════════════════════════════
        if (partida) {
            if (esRetiro) {
                // 🚫 No se puede retirar sin haber arriesgado al menos una vez
                if (partida.nivel <= 0) {
                    return await message.reply(
                        `⚠️ Aún no arriesgaste ninguna ronda\n` +
                        `.bomb para jugar tu primera ronda`
                    );
                }

                const ganancia = partida.valorActual;
                const multiplicadorTotal = parseFloat((partida.valorActual / partida.apuesta).toFixed(2));
                let user = global.db.getUser(senderNumber) || {};
                if (typeof user.money !== 'number' || isNaN(user.money)) {
                    user.money = 0;
                }
                user.money += ganancia;
                global.db.setUser(senderNumber, user);

                jugadoresEnPartida.delete(senderNumber);
                guardarPartidas();

                return await message.reply(
                    `💸 Retiraste · Ronda ${partida.nivel} · x${multiplicadorTotal}\n` +
                    `💰 $${partida.apuesta} → $${ganancia}\n` +
                    `💵 Saldo: $${user.money}`
                );
            }

            // Cualquier otro texto estando en partida: avisar y mostrar estado
            if (partida.nivel <= 0) {
                return await message.reply(
                    `⚠️ Bomba en curso · $${partida.apuesta} · sin arriesgar aún\n` +
                    `.bomb para jugar tu primera ronda`
                );
            }

            const ganancia = partida.valorActual;
            const multiplicadorTotal = parseFloat((partida.valorActual / partida.apuesta).toFixed(2));
            return await message.reply(
                `⚠️ Bomba en curso · Ronda ${partida.nivel} · x${multiplicadorTotal}\n` +
                `💰 $${partida.apuesta} → $${ganancia}\n\n` +
                `.bomb para seguir | .bomb retirar para cobrar`
            );
        }

        // ═══════════════════════════════════════════
        // CON TEXTO Y SIN PARTIDA ACTIVA → CREAR NUEVA APUESTA
        // ═══════════════════════════════════════════

        let user = global.db.getUser(senderNumber) || {};
        if (typeof user.money !== 'number' || isNaN(user.money)) {
            user.money = 0;
        }
        if (user.money <= 0) {
            return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
        }

        let cantidad;
        if (comando === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply('❌ *No tienes dinero para apostar*\n\n💡 _Trabaja para ganar dinero usando_ `.work`');
            }
        } else {
            cantidad = parseInt(text);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ *Cantidad inválida*\n\n💡 _Ingresa un número mayor a 0 o usa_ `all`');
            }
        }

        if (cantidad > user.money) {
            return await message.reply(`❌ *Saldo insuficiente*\n\n💰 *Tu saldo:* $${user.money}\n💸 *Intentaste apostar:* $${cantidad}`);
        }

        // Descontar la apuesta INMEDIATAMENTE, antes de empezar
        user.money -= cantidad;
        global.db.setUser(senderNumber, user);

        // Iniciar nueva partida (nivel 0 = todavía no jugó ninguna ronda, no es retirable)
        // valorActual arranca igual a la apuesta; cada ronda se multiplica sobre este valor
        const nuevaPartida = {
            apuesta: cantidad,
            nivel: 0,
            valorActual: cantidad
        };

        jugadoresEnPartida.set(senderNumber, nuevaPartida);
        guardarPartidas();

        await message.reply(
            `💣 Bomba activada · $${cantidad}\n` +
            `.bomb para arriesgar (x1.5)`
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de la bomba:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el juego*\n\n_Ocurrió un error al procesar tu juego._');
    }
};

handler.help = ['bomba <cantidad/all>', 'bomba', 'bomba retirar'];
handler.tags = ['economy'];
handler.command = /^(bomba|bomb)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;