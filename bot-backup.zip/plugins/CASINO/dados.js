// Emojis y constantes para decoración
const EMOJIS = {
    DADOS: '🎲',
    DINERO: '💰',
    PERDIDA: '💸',
    GANANCIA: '💵',
    ERROR: '❌',
    INFO: '💡',
    TIEMPO: '⏱️',
    VICTORIA: '🎉',
    DERROTA: '💔'
};

// Tipos de apuestas y sus multiplicadores
const APUESTAS = {
    // Apuesta a un número específico (2-12)
    numero: { multiplicador: 6, descripcion: 'Apuesta a un número específico (2-12)' },
    
    // Apuesta a par o impar
    par: { multiplicador: 2, descripcion: 'Apuesta a que saldrá un número par' },
    impar: { multiplicador: 2, descripcion: 'Apuesta a que saldrá un número impar' },
    
    // Apuesta a rango
    bajo: { multiplicador: 2, descripcion: 'Apuesta a números bajos (2-6)' },
    alto: { multiplicador: 2, descripcion: 'Apuesta a números altos (8-12)' },
    
    // Apuesta a 7
    siete: { multiplicador: 5, descripcion: 'Apuesta al número 7 (más común)' }
};

// Función para lanzar los dados
const lanzarDados = () => {
    const dado1 = Math.floor(Math.random() * 6) + 1;
    const dado2 = Math.floor(Math.random() * 6) + 1;
    return { dado1, dado2, suma: dado1 + dado2 };
};

// Función para verificar si una apuesta es ganadora
const verificarApuesta = (tipoApuesta, valorApuesta, resultado) => {
    const suma = resultado.suma;
    
    // Verificar apuesta a número específico
    if (!isNaN(parseInt(tipoApuesta))) {
        const numeroApostado = parseInt(tipoApuesta);
        return suma === numeroApostado;
    }
    
    // Verificar otros tipos de apuestas
    switch (tipoApuesta) {
        case 'par':
            return suma % 2 === 0;
        case 'impar':
            return suma % 2 !== 0;
        case 'bajo':
            return suma >= 2 && suma <= 6;
        case 'alto':
            return suma >= 8 && suma <= 12;
        case 'siete':
            return suma === 7;
        default:
            return false;
    }
};

// Función para obtener el multiplicador de una apuesta
const obtenerMultiplicador = (tipoApuesta) => {
    // Si es un número específico
    if (!isNaN(parseInt(tipoApuesta))) {
        return APUESTAS.numero.multiplicador;
    }
    
    // Si es otro tipo de apuesta
    return APUESTAS[tipoApuesta]?.multiplicador || 0;
};

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Si no hay texto, mostrar ayuda
        if (!text) {
            return await message.reply(
                `${EMOJIS.DADOS} *DADOS - AYUDA* ${EMOJIS.DADOS}\n` +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Cómo jugar:*\n' +
                `${EMOJIS.DINERO} .dados <tipo> <cantidad> - _Apostar una cantidad_\n\n` +
                '*Tipos de apuestas:*\n' +
                `${EMOJIS.DADOS} 2-12 - _Número específico (x6)_\n` +
                `${EMOJIS.DADOS} par - _Número par (x2)_\n` +
                `${EMOJIS.DADOS} impar - _Número impar (x2)_\n` +
                `${EMOJIS.DADOS} bajo - _Números 2-6 (x2)_\n` +
                `${EMOJIS.DADOS} alto - _Números 8-12 (x2)_\n` +
                `${EMOJIS.DADOS} siete - _Número 7 (x5)_\n\n` +
                '*Ejemplos:*\n' +
                '`.dados 7 100` - _Apostar 100 monedas al número 7_\n' +
                '`.dados par all` - _Apostar todo tu saldo a número par_'
            );
        }

        // Separar el tipo de apuesta y la cantidad
        const args = text.toLowerCase().split(' ');
        const tipoApuesta = args[0];
        const cantidadText = args[1];

        // Verificar que el tipo de apuesta sea válido
        const esNumero = !isNaN(parseInt(tipoApuesta)) && parseInt(tipoApuesta) >= 2 && parseInt(tipoApuesta) <= 12;
        const esApuestaValida = esNumero || Object.keys(APUESTAS).includes(tipoApuesta);

        if (!esApuestaValida) {
            return await message.reply(
                `${EMOJIS.ERROR} *Tipo de apuesta inválido*\n\n` +
                '*Tipos de apuestas disponibles:*\n' +
                `${EMOJIS.DADOS} 2-12 - _Número específico_\n` +
                `${EMOJIS.DADOS} par/impar - _Paridad_\n` +
                `${EMOJIS.DADOS} bajo/alto - _Rango_\n` +
                `${EMOJIS.DADOS} siete - _Número 7_`
            );
        }

        // Verificar que se proporcionó una cantidad
        if (!cantidadText) {
            return await message.reply(
                `${EMOJIS.ERROR} *Cantidad no especificada*\n\n` +
                `${EMOJIS.INFO} *Uso correcto:*\n` +
                `\.dados ${tipoApuesta} <cantidad> o \.dados ${tipoApuesta} all`
            );
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (cantidadText.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                    `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
                );
            }
        } else {
            cantidad = parseInt(cantidadText);
            // Validar que sea un número válido y mayor a 0
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *Cantidad inválida*\n\n` +
                    `${EMOJIS.INFO} _Ingresa un número mayor a 0 o usa_ \`all\``
                );
            }
        }

        // Verificar si tiene suficiente saldo
        if (user.money <= 0) {
            return await message.reply(
                `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                `${EMOJIS.ERROR} *Saldo insuficiente*\n\n` +
                `${EMOJIS.DINERO} *Tu saldo:* $${user.money}\n` +
                `${EMOJIS.PERDIDA} *Intentaste apostar:* $${cantidad}`
            );
        }

        // Lanzar los dados
        const resultado = lanzarDados();
        const { dado1, dado2, suma } = resultado;

        // Verificar si ganó
        const gano = verificarApuesta(tipoApuesta, null, resultado);
        const multiplicador = obtenerMultiplicador(tipoApuesta);

        // Calcular ganancias o pérdidas
        let mensaje;
        if (gano) {
            // Calcular ganancia (cantidad * multiplicador - cantidad apostada)
            const ganancia = cantidad * multiplicador;
            user.money += ganancia - cantidad; // Restamos la cantidad apostada porque ya se descontó
            
            mensaje = 
                `${EMOJIS.DADOS} *¡DADOS - GANASTE!* ${EMOJIS.VICTORIA}\n` +
                '━━━━━━━━━━━━━━━\n' +
                `${EMOJIS.DADOS} *Dados:* ${dado1} + ${dado2} = ${suma}\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad} a ${esNumero ? `número ${tipoApuesta}` : tipoApuesta}\n` +
                `${EMOJIS.GANANCIA} *Multiplicador:* x${multiplicador}\n` +
                `${EMOJIS.GANANCIA} *Ganancia:* $${ganancia - cantidad}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🍀 _¡La suerte está de tu lado!_';
        } else {
            // Perder lo apostado
            user.money = Math.max(0, user.money - cantidad);
            
            mensaje = 
                `${EMOJIS.DADOS} *¡DADOS - PERDISTE!* ${EMOJIS.DERROTA}\n` +
                '━━━━━━━━━━━━━━━\n' +
                `${EMOJIS.DADOS} *Dados:* ${dado1} + ${dado2} = ${suma}\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad} a ${esNumero ? `número ${tipoApuesta}` : tipoApuesta}\n` +
                `${EMOJIS.PERDIDA} *Pérdida:* $${cantidad}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🎯 _¡Inténtalo de nuevo!_';
        }

        // Guardar los cambios en la base de datos
        global.db.setUser(senderNumber, user);

        // Enviar mensaje con el resultado
        return await message.reply(mensaje);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de dados:', error, '\x1b[0m');
        return await message.reply(`${EMOJIS.ERROR} *Error en el juego*\n\n_Ocurrió un error al procesar tu apuesta._`);
    }
};

handler.help = ['dados <tipo> <cantidad/all>'];
handler.tags = ['economy'];
handler.command = /^(dados|dice)$/i;

module.exports = handler;
handler.group = true;
handler.apodo = true;