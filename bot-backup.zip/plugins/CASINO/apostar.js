// Emojis y constantes para decoración
const achievements = require('../../achievements');

const EMOJIS = {
    WIN: ['🎰', '💎', '🎲', '🎯', '🎪'],
    LOSE: ['💔', '💨', '🌪️', '💫', '🌙'] 
};

// ⚙️ CONFIGURACIÓN DE PROBABILIDAD
const PROBABILIDAD_VICTORIA = 60; // Cambia este valor entre 1-100 para ajustar la probabilidad de ganar

// Mapa para almacenar las apuestas pendientes entre jugadores
let apuestasPendientes = new Map();

// Mapa para almacenar el cooldown de cada usuario
let cooldowns = new Map();

// 🧹 LIMPIEZA AUTOMÁTICA DE MEMORIA
// Limpiar cooldowns expirados cada 5 minutos
setInterval(() => {
    const now = Date.now();
    const cooldownTime = 2000; // 2 segundos
    
    for (const [key, timestamp] of cooldowns.entries()) {
        if (now - timestamp > cooldownTime * 10) { // Limpiar después de 20 segundos (10x el cooldown)
            cooldowns.delete(key);
        }
    }
    
    // Limpiar apuestas muy antiguas (más de 2 minutos sin respuesta)
    for (const [key, apuesta] of apuestasPendientes.entries()) {
        if (now - apuesta.timestamp > 120000) { // 2 minutos
            if (apuesta.timeout) {
                clearTimeout(apuesta.timeout);
            }
            apuestasPendientes.delete(key);
        }
    }
    
    // Log de limpieza si se eliminaron entradas
    const cooldownSize = cooldowns.size;
    const apuestasSize = apuestasPendientes.size;
    if (cooldownSize > 100 || apuestasSize > 50) {
        console.log(`[APOSTAR] Limpieza: ${cooldownSize} cooldowns, ${apuestasSize} apuestas pendientes`);
    }
}, 5 * 60 * 1000); // Cada 5 minutos

let handler = async (message, { text }) => {
    try {
        // Obtener el ID real del remitente
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si se proporcionó una cantidad o un comando
        if (!text) {
            return await message.reply(
                '❌ *Cantidad no especificada*\n' +
                '\n📋 *Uso correcto:*\n' +
                '━━━━━━━━━━━━━━━\n' +
                '`.apostar <cantidad>` - _Apostar una cantidad específica_\n' +
                '`.apostar <porcentaje>%` - _Apostar un porcentaje de tu saldo_\n' +
                '`.apostar all` - _Apostar todo tu saldo_\n' +
                '`.apostar @usuario <cantidad>` - _Retar a un usuario_\n' +
                '`.apostar aceptar @usuario` - _Aceptar un reto_\n' +
                '`.apostar rechazar @usuario` - _Rechazar un reto_\n\n' +
                '💡 _Tienes posibilidad de duplicar tu apuesta_'
            );
        }
        
        // Procesar RECHAZO de apuesta
        if (text.toLowerCase().startsWith('rechazar')) {
            const mentionedJids = message?.mentions;
            
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar al retador. Ejemplo: .apostar rechazar @usuario_');
            }

            const retadorJid = mentionedJids[0];
            const retador = retadorJid.split('@')[0];
            
            // Verificar si existe una apuesta pendiente de ese usuario
            const claveApuesta = `${retador}_${senderNumber}`;
            
            if (!apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *No hay ninguna apuesta pendiente de ese usuario*');
            }
            
            const apuestaPendiente = apuestasPendientes.get(claveApuesta);
            
            // Cancelar el timeout
            if (apuestaPendiente.timeout) {
                clearTimeout(apuestaPendiente.timeout);
            }
            
            // Eliminar la apuesta pendiente
            apuestasPendientes.delete(claveApuesta);
            
            // Enviar mensaje de rechazo
            const profileMessage = 
                '*❌ APUESTA RECHAZADA*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `@${senderNumber} ha rechazado la apuesta de @${retador}\n\n` +
                `💰 *Cantidad:* $${apuestaPendiente.cantidad}\n\n` +
                '😔 _Mejor suerte la próxima vez_';
            
            return await message.reply(profileMessage, { mentions: [retadorJid, senderJid] });
        }
        
        // Procesar ACEPTACIÓN de apuesta
        if (text.toLowerCase().startsWith('aceptar')) {
            const mentionedJids = message?.mentions;
            
            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes mencionar al retador. Ejemplo: .apostar aceptar @usuario_');
            }

            const retadorJid = mentionedJids[0];
            const retador = retadorJid.split('@')[0];
            
            // Verificar si existe una apuesta pendiente de ese usuario
            const claveApuesta = `${retador}_${senderNumber}`;
            
            if (!apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *No hay ninguna apuesta pendiente de ese usuario*');
            }
            
            const apuestaPendiente = apuestasPendientes.get(claveApuesta);
            const cantidad = apuestaPendiente.cantidad;
            
            // Cancelar el timeout de expiración
            if (apuestaPendiente.timeout) {
                clearTimeout(apuestaPendiente.timeout);
            }
            
            // Verificar que el retador tenga suficiente saldo
            let userRetador = global.db.getUser(retador);
            
            if (!userRetador) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply('❌ *Error: No se pudo obtener los datos del retador*');
            }
            
            if (userRetador.money < cantidad) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply(
                    '❌ *El retador ya no tiene suficiente saldo*\n\n' +
                    `💰 *Saldo del retador:* $${userRetador.money}\n` +
                    `💸 *Apuesta:* $${cantidad}\n\n` +
                    '🚫 _La apuesta ha sido cancelada_'
                );
            }
            
            // Verificar que el retado (tú) tenga suficiente saldo
            if (user.money < cantidad) {
                apuestasPendientes.delete(claveApuesta);
                return await message.reply(
                    '❌ *No tienes suficiente saldo para aceptar la apuesta*\n\n' +
                    `💰 *Tu saldo:* $${user.money}\n` +
                    `💸 *Apuesta:* $${cantidad}\n\n` +
                    '🚫 _La apuesta ha sido cancelada_'
                );
            }
            
            // Generar un número aleatorio entre 1 y 100
            const numeroAleatorio = Math.floor(Math.random() * 100) + 1;
            
            // 50% de probabilidad de ganar para cada jugador (retos siempre 50/50)
            const ganoRetador = numeroAleatorio <= 50;
            
            // Seleccionar un emoji aleatorio según el resultado
            const emoji = ganoRetador ? 
                EMOJIS.WIN[Math.floor(Math.random() * EMOJIS.WIN.length)] :
                EMOJIS.LOSE[Math.floor(Math.random() * EMOJIS.LOSE.length)];
            
            // Actualizar saldos según el resultado
            if (ganoRetador) {
                // El retador gana, el retado pierde
                userRetador.money += cantidad;
                user.money = Math.max(0, user.money - cantidad);
                
                // Añadir progreso de logro ANTES de guardar
                const achievementMessage = achievements.addAchievementProgress(user, 'betting');
                // Guardar los cambios en la base de datos
                global.db.setUser(retador, userRetador);
                global.db.setUser(senderNumber, user);
                if (achievementMessage) {
                    await message.reply(achievementMessage).catch(() => {});
                }
                
                // Eliminar la apuesta pendiente
                apuestasPendientes.delete(claveApuesta);
                
                // Enviar mensaje con el resultado
                const resultMessage = 
                    `*${emoji} ¡RESULTADO DE LA APUESTA!*\n` +
                    '━━━━━━━━━━━━━━━\n' +
                    `🎲 *Apuesta:* $${cantidad}\n\n` +
                    `🏆 *Ganador:* @${retador}\n` +
                    `💰 *Ganancia:* +$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${userRetador.money}\n\n` +
                    `😢 *Perdedor:* @${senderNumber}\n` +
                    `💸 *Pérdida:* -$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${user.money}\n\n` +
                    '🍀 _¡La suerte está echada!_';
                
                return await message.reply(resultMessage, { mentions: [retadorJid, senderJid] });
            } else {
                // El retado gana, el retador pierde
                user.money += cantidad;
                userRetador.money = Math.max(0, userRetador.money - cantidad);
                
                // Añadir progreso de logro ANTES de guardar
                const achievementMessage = achievements.addAchievementProgress(user, 'betting');
                // Guardar los cambios en la base de datos
                global.db.setUser(senderNumber, user);
                global.db.setUser(retador, userRetador);
                if (achievementMessage) {
                    await message.reply(achievementMessage).catch(() => {});
                }
                
                // Eliminar la apuesta pendiente
                apuestasPendientes.delete(claveApuesta);
                
                // Enviar mensaje con el resultado
                const resultMessage = 
                    `*${emoji} ¡RESULTADO DE LA APUESTA!*\n` +
                    '━━━━━━━━━━━━━━━\n' +
                    `🎲 *Apuesta:* $${cantidad}\n\n` +
                    `🏆 *Ganador:* @${senderNumber}\n` +
                    `💰 *Ganancia:* +$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${user.money}\n\n` +
                    `😢 *Perdedor:* @${retador}\n` +
                    `💸 *Pérdida:* -$${cantidad}\n` +
                    `💵 *Nuevo saldo:* $${userRetador.money}\n\n` +
                    '🍀 _¡La suerte está echada!_';
                
                return await message.reply(resultMessage, { mentions: [senderJid, retadorJid] });
            }
        }
        
        // Verificar cooldown (excepto para aceptar/rechazar apuestas)
        if (!text.toLowerCase().startsWith('aceptar') && !text.toLowerCase().startsWith('rechazar')) {
            const ahora = Date.now();
            const cooldownTime = 2000; // 2 segundos
            
            if (cooldowns.has(senderNumber)) {
                const ultimaApuesta = cooldowns.get(senderNumber);
                const tiempoRestante = cooldownTime - (ahora - ultimaApuesta);
                
                if (tiempoRestante > 0) {
                    const segundosRestantes = Math.ceil(tiempoRestante / 1000);
                    return await message.reply(
                        '⏳ *Cooldown activo*\n\n' +
                        `_Espera ${segundosRestantes} segundo${segundosRestantes > 1 ? 's' : ''} antes de apostar nuevamente_`
                    );
                }
            }
            
            // Actualizar el cooldown
            cooldowns.set(senderNumber, ahora);
        }
        
        // Procesar apuesta a otro usuario (RETO)
        const mentionedJids = message?.mentions;
        if (mentionedJids && mentionedJids.length > 0) {
            const retadoJid = mentionedJids[0];
            const retado = retadoJid.split('@')[0];
            
            // Extraer la cantidad del texto (eliminar menciones y obtener el número)
            const cantidadMatch = text.replace(/@\d+/g, '').trim().match(/(\d+)/);
            
            if (!cantidadMatch) {
                return await message.reply('❌ *Formato inválido*\n\n_Debes especificar una cantidad. Ejemplo: .apostar @usuario 100_');
            }
            
            const cantidad = parseInt(cantidadMatch[1]);
            
            // Verificar que no se rete a sí mismo
            if (retado === senderNumber) {
                return await message.reply('❌ *No puedes retarte a ti mismo*');
            }
            
            // Verificar que la cantidad sea válida
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply('❌ *Cantidad inválida*\n\n_Ingresa un número mayor a 0_');
            }
            
            // Verificar si tiene suficiente saldo
            if (user.money < cantidad) {
                return await message.reply(
                    '❌ *Saldo insuficiente*\n\n' +
                    `💰 *Tu saldo:* $${user.money}\n` +
                    `💸 *Intentaste apostar:* $${cantidad}`
                );
            }
            
            // Verificar que el retado exista en la base de datos
            let userRetado = global.db.getUser(retado);
            if (!userRetado) {
                return await message.reply('❌ *El usuario mencionado no existe en la base de datos*');
            }
            
            // Verificar que el retado tenga suficiente saldo
            if (userRetado.money < cantidad) {
                return await message.reply(
                    '❌ *El usuario retado no tiene suficiente saldo*\n\n' +
                    `💰 *Saldo de @${retado}:* $${userRetado.money}\n` +
                    `💸 *Cantidad de apuesta:* $${cantidad}`
                );
            }
            
            // Verificar si ya hay una apuesta pendiente con este usuario
            const claveApuesta = `${senderNumber}_${retado}`;
            if (apuestasPendientes.has(claveApuesta)) {
                return await message.reply('❌ *Ya tienes una apuesta pendiente con este usuario*\n\n_Espera a que responda o que expire_');
            }
            
            // Crear timeout para cancelar la apuesta después de 30 segundos
            const timeout = setTimeout(async () => {
                if (apuestasPendientes.has(claveApuesta)) {
                    apuestasPendientes.delete(claveApuesta);
                    
                    const expiredMessage = 
                        '*⏰ APUESTA EXPIRADA*\n' +
                        '━━━━━━━━━━━━━━━\n\n' +
                        `La apuesta entre @${senderNumber} y @${retado} ha sido cancelada por falta de respuesta\n\n` +
                        `💰 *Cantidad:* $${cantidad}\n\n` +
                        '⏱️ _El tiempo de 30 segundos ha expirado_';
                    
                    await message.reply(expiredMessage, { mentions: [senderJid, retadoJid] });
                }
            }, 30000); // 30 segundos
            
            // Guardar la apuesta pendiente
            apuestasPendientes.set(claveApuesta, {
                retador: senderNumber,
                retado: retado,
                cantidad: cantidad,
                timestamp: Date.now(),
                timeout: timeout
            });
            
            // Enviar mensaje de reto
            const retoMessage = 
                '*🎲 RETO DE APUESTA 🎲*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                `@${retado} has sido retado a una apuesta por @${senderNumber}\n\n` +
                `💰 *Cantidad:* $${cantidad}\n` +
                `🎮 *Probabilidad:* 50/50\n` +
                `🏆 *Ganador duplica su dinero*\n\n` +
                `📝 *Responde con:*\n` +
                `✅ .apostar aceptar @${senderNumber}\n` +
                `❌ .apostar rechazar @${senderNumber}\n\n` +
                '⏳ _Tienes 30 segundos para responder_';
            
            return await message.reply(retoMessage, { mentions: [senderJid, retadoJid] });
        }

        // Determinar la cantidad a apostar (apuesta individual)
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    '❌ *No tienes dinero para apostar*\n\n' +
                    '💡 _Trabaja para ganar dinero usando_ `.work`'
                );
            }
        } else if (text.includes('%')) {
            // Procesar porcentaje
            const porcentajeMatch = text.match(/(\d+(?:\.\d+)?)\s*%/);
            if (!porcentajeMatch) {
                return await message.reply(
                    '❌ *Formato de porcentaje inválido*\n\n' +
                    '💡 _Ejemplo: .apostar 10%_'
                );
            }
            
            const porcentaje = parseFloat(porcentajeMatch[1]);
            
            // Validar que el porcentaje sea válido
            if (isNaN(porcentaje) || porcentaje <= 0 || porcentaje > 100) {
                return await message.reply(
                    '❌ *Porcentaje inválido*\n\n' +
                    '💡 _Ingresa un porcentaje entre 1 y 100_'
                );
            }
            
            // Calcular la cantidad y redondear
            cantidad = Math.round((user.money * porcentaje) / 100);
            
            // Asegurar que la cantidad sea al menos 1 si el usuario tiene dinero
            if (cantidad <= 0 && user.money > 0) {
                cantidad = 1;
            }
        } else {
            cantidad = parseInt(text);
            // Validar que sea un número válido y mayor a 0
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    '❌ *Cantidad inválida*\n\n' +
                    '💡 _Ingresa un número mayor a 0, usa_ `all` _o un porcentaje como_ `10%`'
                );
            }
        }

        // Verificar si tiene suficiente saldo y que no sea 0
        if (user.money <= 0) {
            return await message.reply(
                '❌ *No tienes dinero para apostar*\n\n' +
                '💡 _Trabaja para ganar dinero usando_ `.work`'
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                '❌ *Saldo insuficiente*\n\n' +
                `💰 *Tu saldo:* $${user.money}\n` +
                `💸 *Intentaste apostar:* $${cantidad}`
            );
        }

        // Generar un número aleatorio entre 1 y 100
        const numeroAleatorio = Math.floor(Math.random() * 100) + 1;
        
        // Determinar si ganó según la probabilidad configurada
        const gano = numeroAleatorio <= PROBABILIDAD_VICTORIA;

        // Seleccionar un emoji aleatorio según el resultado
        const emoji = gano ? 
            EMOJIS.WIN[Math.floor(Math.random() * EMOJIS.WIN.length)] :
            EMOJIS.LOSE[Math.floor(Math.random() * EMOJIS.LOSE.length)];

        if (gano) {
            // Ganar el doble de lo apostado
            user.money += cantidad;
            
            // 📊 ACTUALIZAR ESTADÍSTICAS DE VICTORIA
            if (!user.betStats) {
                user.betStats = {
                    totalBets: 0, totalWins: 0, totalLosses: 0, totalBetAmount: 0,
                    totalWonAmount: 0, totalLostAmount: 0, biggestBet: 0, biggestWin: 0,
                    biggestLoss: 0, currentStreak: 0, bestWinStreak: 0, worstLoseStreak: 0, lastBetTime: 0
                };
            }
            user.betStats.totalBets++;
            user.betStats.totalWins++;
            user.betStats.totalBetAmount += cantidad;
            user.betStats.totalWonAmount += cantidad;
            user.betStats.lastBetTime = Date.now();
            if (cantidad > user.betStats.biggestBet) user.betStats.biggestBet = cantidad;
            if (cantidad > user.betStats.biggestWin) user.betStats.biggestWin = cantidad;
            if (user.betStats.currentStreak >= 0) {
                user.betStats.currentStreak++;
            } else {
                user.betStats.currentStreak = 1;
            }
            if (user.betStats.currentStreak > user.betStats.bestWinStreak) {
                user.betStats.bestWinStreak = user.betStats.currentStreak;
            }
            
            await message.reply(
                `_Desafiaste al azar y ganaste_ *$${cantidad}*
_Nuevo saldo:_ *$${user.money}*
*.betstats* _para ver tus estadísticas_`
            );
        } else {
            // Perder lo apostado, asegurando que no quede negativo
            user.money = Math.max(0, user.money - cantidad);
            
            // 📊 ACTUALIZAR ESTADÍSTICAS DE DERROTA
            if (!user.betStats) {
                user.betStats = {
                    totalBets: 0, totalWins: 0, totalLosses: 0, totalBetAmount: 0,
                    totalWonAmount: 0, totalLostAmount: 0, biggestBet: 0, biggestWin: 0,
                    biggestLoss: 0, currentStreak: 0, bestWinStreak: 0, worstLoseStreak: 0, lastBetTime: 0
                };
            }
            user.betStats.totalBets++;
            user.betStats.totalLosses++;
            user.betStats.totalBetAmount += cantidad;
            user.betStats.totalLostAmount += cantidad;
            user.betStats.lastBetTime = Date.now();
            if (cantidad > user.betStats.biggestBet) user.betStats.biggestBet = cantidad;
            if (cantidad > user.betStats.biggestLoss) user.betStats.biggestLoss = cantidad;
            if (user.betStats.currentStreak <= 0) {
                user.betStats.currentStreak--;
            } else {
                user.betStats.currentStreak = -1;
            }
            if (Math.abs(user.betStats.currentStreak) > user.betStats.worstLoseStreak) {
                user.betStats.worstLoseStreak = Math.abs(user.betStats.currentStreak);
            }
            
            await message.reply(
                `_Desafiaste al azar y perdiste_ *$${cantidad}*
_Nuevo saldo:_ *$${user.money}*
*.betstats* _para ver tus estadísticas_`
            );
        }

        // Guardar los cambios en la base de datos
        const achievementMessage = achievements.addAchievementProgress(user, 'betting');
        global.db.setUser(senderNumber, user);
        if (achievementMessage) {
            await message.reply(achievementMessage).catch(() => {});
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al procesar la apuesta:', error, '\x1b[0m');
        return await message.reply('❌ *Error en la apuesta*\n\n_Ocurrió un error al procesar tu apuesta._');
    }
};

handler.help = ['apostar <cantidad/all/%>', 'apostar @usuario <cantidad>', 'apostar aceptar @usuario', 'apostar rechazar @usuario'];
handler.tags = ['economy'];
handler.command = /^(apostar|bet)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;