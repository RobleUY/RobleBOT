// Emojis y constantes para decoración
const EMOJIS = {
    SLOT: '🎰',
    DINERO: '💰',
    PERDIDA: '💸',
    GANANCIA: '💵',
    ERROR: '❌',
    INFO: '💡', 
    TIEMPO: '⏱️',
    JACKPOT: '🌟'
};

// Símbolos del tragamonedas y sus valores
const SIMBOLOS = [
    { emoji: '🍒', valor: 1 },   // Cereza
    { emoji: '🍊', valor: 2 },   // Naranja
    { emoji: '🍋', valor: 3 },   // Limón
    { emoji: '🍇', valor: 4 },   // Uvas
    { emoji: '🍉', valor: 5 },   // Sandía
    { emoji: '💎', valor: 10 },  // Diamante
    { emoji: '7️⃣', valor: 15 }   // Siete (mayor valor)
];

// Multiplicadores según combinaciones
const MULTIPLICADORES = {
    TRES_IGUALES_7: 20,     // Tres sietes
    TRES_IGUALES_DIAMANTE: 15, // Tres diamantes
    TRES_IGUALES_OTROS: 10,    // Tres símbolos iguales (excepto 7 y diamante)
    DOS_IGUALES: 2,            // Dos símbolos iguales
    NADA: 0                    // Sin combinación
};

let handler = async (message, { text }) => {
    try {
        const sender = message.from;
        let senderNumber = sender;

        // Obtener el ID real del remitente
        if (message.author) {
            senderNumber = message.author.split('@')[0];
        } else if (sender.endsWith('@c.us')) {
            senderNumber = sender.split('@')[0];
        }

        // Obtener datos del usuario
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Si no hay texto, mostrar ayuda
        if (!text) {
            return await message.reply(
                `${EMOJIS.SLOT} *TRAGAMONEDAS - AYUDA* ${EMOJIS.SLOT}\n` +
                '━━━━━━━━━━━━━━━\n\n' +
                '*Cómo jugar:*\n' +
                `${EMOJIS.DINERO} .slot <cantidad> - _Apostar una cantidad específica_\n` +
                `${EMOJIS.DINERO} .slot all - _Apostar todo tu saldo_\n\n` +
                '*Combinaciones:*\n' +
                `7️⃣7️⃣7️⃣ - _x20 tu apuesta_\n` +
                `💎💎💎 - _x15 tu apuesta_\n` +
                `🍒🍒🍒 - _x10 tu apuesta (igual para otros símbolos)_\n` +
                `XX-- - _x2 tu apuesta (dos símbolos iguales)_\n\n` +
                `${EMOJIS.INFO} _¡Prueba tu suerte en las máquinas!_`
            );
        }

        // Determinar la cantidad a apostar
        let cantidad;
        if (text.toLowerCase() === 'all') {
            cantidad = user.money;
            if (cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                    `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
                );
            }
        } else {
            cantidad = parseInt(text);
            // Validar que sea un número válido y mayor a 0
            if (isNaN(cantidad) || cantidad <= 0) {
                return await message.reply(
                    `${EMOJIS.ERROR} *Cantidad inválida*\n\n` +
                    `${EMOJIS.INFO} _Ingresa un número mayor a 0 o usa_ \`all\``
                );
            }
        }

        // Verificar si tiene suficiente saldo
        if (user.money <= 0) {
            return await message.reply(
                `${EMOJIS.ERROR} *No tienes dinero para apostar*\n\n` +
                `${EMOJIS.INFO} _Trabaja para ganar dinero usando_ \.work`
            );
        }
        if (cantidad > user.money) {
            return await message.reply(
                `${EMOJIS.ERROR} *Saldo insuficiente*\n\n` +
                `${EMOJIS.DINERO} *Tu saldo:* $${user.money}\n` +
                `${EMOJIS.PERDIDA} *Intentaste apostar:* $${cantidad}`
            );
        }

        // Restar la apuesta del saldo del usuario
        user.money -= cantidad;

        // Generar los tres símbolos aleatorios
        const resultados = [];
        for (let i = 0; i < 3; i++) {
            resultados.push(SIMBOLOS[Math.floor(Math.random() * SIMBOLOS.length)]);
        }

        // Verificar combinaciones ganadoras
        let multiplicador = 0;
        let mensajeResultado = '';

        // Verificar si hay tres símbolos iguales
        if (resultados[0].emoji === resultados[1].emoji && resultados[1].emoji === resultados[2].emoji) {
            // Tres símbolos iguales
            if (resultados[0].emoji === '7️⃣') {
                multiplicador = MULTIPLICADORES.TRES_IGUALES_7;
                mensajeResultado = `${EMOJIS.JACKPOT} ¡JACKPOT! ${EMOJIS.JACKPOT}`;
            } else if (resultados[0].emoji === '💎') {
                multiplicador = MULTIPLICADORES.TRES_IGUALES_DIAMANTE;
                mensajeResultado = `${EMOJIS.JACKPOT} ¡GRAN PREMIO! ${EMOJIS.JACKPOT}`;
            } else {
                multiplicador = MULTIPLICADORES.TRES_IGUALES_OTROS;
                mensajeResultado = `${EMOJIS.GANANCIA} ¡TRIPLE! ${EMOJIS.GANANCIA}`;
            }
        }
        // Verificar si hay dos símbolos iguales
        else if (
            resultados[0].emoji === resultados[1].emoji ||
            resultados[1].emoji === resultados[2].emoji ||
            resultados[0].emoji === resultados[2].emoji
        ) {
            multiplicador = MULTIPLICADORES.DOS_IGUALES;
            mensajeResultado = `${EMOJIS.GANANCIA} ¡PAR! ${EMOJIS.GANANCIA}`;
        } else {
            mensajeResultado = `${EMOJIS.PERDIDA} ¡SIN SUERTE! ${EMOJIS.PERDIDA}`;
        }

        // Calcular ganancias
        const ganancia = cantidad * multiplicador;
        user.money += ganancia;

        // Crear mensaje de resultado
        let mensaje;
        if (multiplicador > 0) {
            mensaje = 
                `${EMOJIS.SLOT} *¡TRAGAMONEDAS*\n*${mensajeResultado}* ${EMOJIS.SLOT}\n` +
                '━━━━━━━━━━━━━━━\n\n' +
                `[ ${resultados[0].emoji} | ${resultados[1].emoji} | ${resultados[2].emoji} ]\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad}\n` +
                `${EMOJIS.GANANCIA} *Multiplicador:* x${multiplicador}\n` +
                `${EMOJIS.GANANCIA} *Ganancia:* $${ganancia}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🍀 _¡La suerte está de tu lado!_';
        } else {
            mensaje = 
                `${EMOJIS.SLOT} *¡TRAGAMONEDAS*\n*${mensajeResultado}* ${EMOJIS.SLOT}\n` +
                '━━━━━━━━━━━━━━━\n\n' +
                `[ ${resultados[0].emoji} | ${resultados[1].emoji} | ${resultados[2].emoji} ]\n\n` +
                `${EMOJIS.DINERO} *Apuesta:* $${cantidad}\n` +
                `${EMOJIS.PERDIDA} *Pérdida:* $${cantidad}\n` +
                `${EMOJIS.DINERO} *Nuevo saldo:* $${user.money}\n\n` +
                '🎯 _¡Inténtalo de nuevo!_';
        }

        // Guardar los cambios en la base de datos
        global.db.setUser(senderNumber, user);

        // Enviar mensaje con el resultado
        return await message.reply(mensaje);

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el juego de tragamonedas:', error, '\x1b[0m');
        return await message.reply(`${EMOJIS.ERROR} *Error en el juego*\n\n_Ocurrió un error al procesar tu apuesta._`);
    }
};

handler.help = ['slot <cantidad/all>'];
handler.tags = ['economy'];
handler.command = /^(slot|tragamonedas)$/i;

module.exports = handler;
handler.group = true;