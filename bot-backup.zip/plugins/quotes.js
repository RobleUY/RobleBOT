const KEYS = [
    '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',
    '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',
    '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'
];

const ANGULOS = [
    'con tono reflexivo', 'con tono inspirador', 'con un toque poético',
    'directa y contundente', 'melancólica', 'motivadora', 'filosófica',
    'con humor sutil', 'breve y potente', 'profunda y calmada'
];

let handler = async (message, { text }) => {
    try {
        const input = text?.trim();
        const angulo = ANGULOS[Math.floor(Math.random() * ANGULOS.length)];

        const userPrompt = input
            ? `Dame una frase ${angulo} relacionada con esto que te escribo (puede ser un tema, una persona, una idea, lo que sea — interpretalo vos): "${input}". Puede ser una cita real que exista, o una que inventes vos si no hay ninguna que encaje bien.`
            : `Dame una frase ${angulo}, sobre cualquier tema que se te ocurra. Puede ser una cita real y célebre, o una que inventes vos. Sorpréndeme, no repitas frases obvias o muy usadas.`;

        const systemPrompt = `Eres un generador creativo de frases.
Puedes usar frases reales y célebres, o inventar frases originales cuando no encuentres una real que encaje bien con lo que te piden.
Interpretá libremente lo que el usuario escriba: puede ser un tema, un nombre de persona, una emoción, una palabra suelta, etc. Adaptate a eso.
Cada respuesta debe ser distinta a la anterior: varía tema, estilo y longitud.
Responde SIEMPRE y ÚNICAMENTE con la frase entre comillas, sin autor, sin explicaciones, sin texto adicional antes o después. Ejemplo de formato exacto:
"Frase aquí."`;

        let quote = '';
        try {
            const iaModule = require('./HERRAMIENTAS/ia/ia');
            const callIA = iaModule.callIA || iaModule;
            if (typeof callIA === 'function') {
                const res = await callIA(systemPrompt, userPrompt);
                if (res && res !== '_SILENT_FAIL_') quote = res;
            }
        } catch (e) {
            console.warn('[quotes] callIA falló, probando Groq directo:', e.message);
        }

        if (!quote) {
            const apiKey = KEYS[Math.floor(Math.random() * KEYS.length)];
            const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'llama-3.3-70b-versatile',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userPrompt }
                    ],
                    temperature: 1.15,
                    top_p: 0.95,
                    max_tokens: 150
                })
            });

            const data = await res.json();
            if (!data.choices || data.choices.length === 0) {
                throw new Error('No se recibió respuesta válida de la API');
            }
            quote = data.choices[0].message.content.trim();
        }

        await message.reply(`💬 *FRASE*\n\n${quote.trim()}`);
    } catch (error) {
        console.error('[ERROR] frase:', error);
        await message.reply('❌ Ocurrió un error al generar la frase o el servicio está saturado.');
    }
};

handler.help = ['frase', 'frase <tema, persona o lo que quieras>'];
handler.tags = ['fun'];
handler.command = /^(frase|frases)$/i;

module.exports = handler;