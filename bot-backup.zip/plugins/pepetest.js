const path = require('path');
const fs = require('fs');

let handler = async (message, { conn }) => {
    try {
        const jid = message.from;
        const baileyMessage = message._baileyMessage;

        const thumbnail = fs.readFileSync(path.join(__dirname, 'bot.jpeg'));

        await conn.sendMessage(jid, {
            text: '¡Únete a nuestro canal! 🐸',
            contextInfo: {
                externalAdReply: {
                    title: '📢 Canal Oficial',
                    body: 'Toca para unirte al canal de WhatsApp',
                    thumbnail: thumbnail,
                    sourceUrl: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
                    mediaType: 1,
                    renderLargerThumbnail: true,
                }
            }
        }, { quoted: baileyMessage });

    } catch (err) {
        console.error('[ERROR pepetest]:', err);
        await message.reply('⚠️ Error: ' + err.message);
    }
};

handler.help = ['pepetest'];
handler.tags = ['fun'];
handler.command = /^pepetest$/i;

module.exports = handler;