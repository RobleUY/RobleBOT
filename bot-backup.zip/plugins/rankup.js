const db = require('../database.js');

// 📈 Rangos con precios de 100k en 100k
const RANGOS = [
  { nombre: '🌱 Novato',            precio: 0 },
  { nombre: '🪶 Aprendiz',          precio: 100000 },
  { nombre: '🪵 Recluta',           precio: 200000 },
  { nombre: '🔰 Principiante',      precio: 300000 },
  { nombre: '⚙️ Obrero',            precio: 400000 },
  { nombre: '⚔️ Guerrero',          precio: 500000 },
  { nombre: '🎯 Experto',           precio: 600000 },
  { nombre: '🦾 Maestro',           precio: 700000 },
  { nombre: '🔥 Leyenda',           precio: 800000 },
  { nombre: '💎 Élite',             precio: 900000 },
  { nombre: '👑 Campeón',           precio: 1000000 },
  { nombre: '🐉 Dragón',            precio: 1100000 },
  { nombre: '🦅 Águila',            precio: 1200000 },
  { nombre: '🦁 Titán',             precio: 1300000 },
  { nombre: '🌌 Supremo',           precio: 1400000 },
  { nombre: '💫 Dios',              precio: 1500000 },
  { nombre: '🌠 Inmortal',          precio: 1600000 },
  { nombre: '🪐 Cósmico',           precio: 1700000 },
  { nombre: '🧠 Sabio',             precio: 1800000 },
  { nombre: '🌈 Celestial',         precio: 1900000 },
  { nombre: '⚡ Divino',            precio: 2000000 },
  { nombre: '💀 Espectro',          precio: 2100000 },
  { nombre: '🔥 Fénix',             precio: 2200000 },
  { nombre: '💣 Destructor',        precio: 2300000 },
  { nombre: '🌍 Dominador',         precio: 2400000 },
  { nombre: '🩸 Ángel Caído',       precio: 2500000 },
  { nombre: '🕊️ Redentor',          precio: 2600000 },
  { nombre: '🌕 Guardián Lunar',    precio: 2700000 },
  { nombre: '☀️ Señor Solar',       precio: 2800000 },
  { nombre: '🌌 Entidad Suprema',   precio: 2900000 },
  { nombre: '🧬 Dios Universal',    precio: 3000000 },
  { nombre: '👑 Legends Team',      precio: 3100000 },
];

let handler = async (message, { args, command }) => {
  try {
    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const number = senderJid.split('@')[0];
    let user = db.getUser(number);
    if (!user) return await message.reply('❌ No se encontraron tus datos.');

    const rangoActual = user.rango || '🌱 Novato';
    const indexActual = RANGOS.findIndex(r => r.nombre === rangoActual);
    const siguiente = RANGOS[indexActual + 1];
    const dinero = user.money || 0;

    // -----------------------------
    // 🔹 .rank → muestra rango y progreso
    // -----------------------------
    if (command === 'rank') {
      let msg = `🏅 Tu rango actual: ${rangoActual}\n`;

      if (siguiente) {
        const falta = siguiente.precio - dinero;
        const puedeSubir = falta <= 0;
        const emoji = puedeSubir ? '✅' : '❌';
        const textoFalta = puedeSubir
          ? '¡Tienes suficiente dinero para subir de rango!'
          : `Te faltan ${falta.toLocaleString()} monedas.`;

        msg += `➡️ Próximo rango: ${siguiente.nombre}\n`;
        msg += `💰 Precio: ${siguiente.precio.toLocaleString()} monedas\n`;
        msg += `${emoji} ${textoFalta}`;
      } else {
        msg += `🏆 ¡Ya alcanzaste el rango máximo!`;
      }

      return await message.reply(msg);
    }

    // -----------------------------
    // 🔹 .rankup → sube de rango
    // -----------------------------
    if (command === 'rankup') {
      if (!siguiente)
        return await message.reply('🏆 Ya estás en el rango máximo.');

      if (dinero < siguiente.precio)
        return await message.reply(
          `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
        );

      // Actualizar usuario
      user.money -= siguiente.precio;
      user.rango = siguiente.nombre;
      user.respeto = (user.respeto || 0) + 5;
      db.setUser(number, user);

      return await message.reply(
        `🎉 ¡Felicidades!\n\n` +
        `🏅 Ascendiste a: *${siguiente.nombre}*\n` +
        `💵 Coste: ${siguiente.precio.toLocaleString()} monedas\n` +
        `💪 Has ganado +5 Respeto por tu avance.`
      );
    }

    // -----------------------------
    // 🔹 .ranks → lista completa
    // -----------------------------
    if (command === 'ranks') {
      let texto = '🏆 *Lista de Rangos y Precios*\n\n';
      for (let i = 0; i < RANGOS.length; i++) {
        let actual = RANGOS[i];
        texto += `${i + 1}. ${actual.nombre} — 💰 ${actual.precio.toLocaleString()}\n`;
      }
      texto += `\nUsa *.rankup* para subir de rango.`;
      return await message.reply(texto);
    }

  } catch (err) {
    console.error('Error en comando rank:', err);
    await message.reply('❌ Error al ejecutar el comando de rangos.');
  }
};

handler.help = ['rank', 'rankup', 'ranks'];
handler.tags = ['rpg', 'usuarios', 'economía'];
handler.command = /^(rank|rankup|ranks)$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;