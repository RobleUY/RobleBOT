const db = require('../database.js');

// 📈 Rangos con precios elevados (inicio en 100.000)
const RANGOS = [
  { nombre: '🌱 Novato', precio: 0 },
  { nombre: '🪶 Aprendiz', precio: 10000000 },
  { nombre: '🪵 Recluta', precio: 25000000 },
  { nombre: '🔰 Principiante', precio: 50000000 },
  { nombre: '⚙️ Obrero', precio: 100000000 },
  { nombre: '⚔️ Guerrero', precio: 250000000 },
  { nombre: '🎯 Experto', precio: 500000000 },
  { nombre: '🦾 Maestro', precio: 750000000 },
  { nombre: '🔥 Leyenda', precio: 1000000000 },
  { nombre: '💎 Élite', precio: 1500000000 },
  { nombre: '👑 Campeón', precio: 2000000000 },
  { nombre: '🐉 Dragón', precio: 3000000000 },
  { nombre: '🦅 Águila', precio: 5000000000 },
  { nombre: '🦁 Titán', precio: 7500000000 },
  { nombre: '🌌 Supremo', precio: 10000000000 },
  { nombre: '💫 Dios', precio: 15000000000 },
  { nombre: '🌠 Inmortal', precio: 25000000000 },
  { nombre: '🪐 Cósmico', precio: 50000000000 },
  { nombre: '🧠 Sabio', precio: 75000000000 },
  { nombre: '🌈 Celestial', precio: 100000000000 },
  { nombre: '⚡ Divino', precio: 150000000000 },
  { nombre: '💀 Espectro', precio: 250000000000 },
  { nombre: '🔥 Fénix', precio: 400000000000 },
  { nombre: '💣 Destructor', precio: 600000000000 },
  { nombre: '🌍 Dominador', precio: 800000000000 },
  { nombre: '🩸 Ángel Caído', precio: 1000000000000 },
  { nombre: '🕊️ Redentor', precio: 1500000000000 },
  { nombre: '🌕 Guardián Lunar', precio: 2000000000000 },
  { nombre: '☀️ Señor Solar', precio: 3000000000000 },
  { nombre: '🌌 Entidad Suprema', precio: 5000000000000 },
  { nombre: '🧬 Dios Universal', precio: 10000000000000 },
  { nombre: '👑 Legends Team', precio: 500000000000000 }
];

let handler = async (message, { args, command }) => {
  try {
    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const number = senderJid.split('@')[0];
    let user = db.getUser(number);
    if (!user) return await message.reply('❌ No se encontraron tus datos.');

    const rangoActual = user.rango || '🌱 Novato';
    const indexActual = RANGOS.findIndex(r => r.nombre === rangoActual);
    const siguiente = RANGOS[indexActual + 1];
    const dinero = user.money || 0;

    // -----------------------------
    // 🔹 .rank → muestra rango y progreso
    // -----------------------------
    if (command === 'rank') {
      let msg = `🏅 Tu rango actual: ${rangoActual}\n`;

      if (siguiente) {
        const falta = siguiente.precio - dinero;
        const puedeSubir = falta <= 0;
        const emoji = puedeSubir ? '✅' : '❌';
        const textoFalta = puedeSubir
          ? '¡Tienes suficiente dinero para subir de rango!'
          : `Te faltan ${falta.toLocaleString()} monedas.`;

        msg += `➡️ Próximo rango: ${siguiente.nombre}\n`;
        msg += `💰 Precio: ${siguiente.precio.toLocaleString()} monedas\n`;
        msg += `${emoji} ${textoFalta}`;
      } else {
        msg += `🏆 ¡Ya alcanzaste el rango máximo!`;
      }

      return await message.reply(msg);
    }

    // -----------------------------
    // 🔹 .rankup → sube de rango
    // -----------------------------
    if (command === 'rankup') {
      if (!siguiente)
        return await message.reply('🏆 Ya estás en el rango máximo.');

      if (dinero < siguiente.precio)
        return await message.reply(
          `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
        );

      // Actualizar usuario
      user.money -= siguiente.precio;
      user.rango = siguiente.nombre;
      user.respeto = (user.respeto || 0) + 5;
      db.setUser(number, user);

      return await message.reply(
        `🎉 ¡Felicidades!\n\n` +
        `🏅 Ascendiste a: *${siguiente.nombre}*\n` +
        `💵 Coste: ${siguiente.precio.toLocaleString()} monedas\n` +
        `💪 Has ganado +5 Respeto por tu avance.`
      );
    }

    // -----------------------------
    // 🔹 .ranks → lista completa
    // -----------------------------
    if (command === 'ranks') {
      let texto = '🏆 *Lista de Rangos y Precios Elevados*\n\n';
      for (let i = 0; i < RANGOS.length; i++) {
        let actual = RANGOS[i];
        texto += `${i + 1}. ${actual.nombre} — 💰 ${actual.precio.toLocaleString()}\n`;
      }
      texto += `\nUsa *.rankup* para subir de rango.`;
      return await message.reply(texto);
    }

  } catch (err) {
    console.error('Error en comando rank:', err);
    await message.reply('❌ Error al ejecutar el comando de rangos.');
  }
};

handler.help = ['rank', 'rankup', 'ranks'];
handler.tags = ['rpg', 'usuarios', 'economía'];
handler.command = /^(rank|rankup|ranks)$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;