const db = require('../database.js');

const RANGOS = [
  { nombre: '🌱 Novato', precio: 0 },
  { nombre: '🪶 Aprendiz', precio: 250000 },
  { nombre: '🪵 Recluta', precio: 500000 },
  { nombre: '🔰 Principiante', precio: 750000 },
  { nombre: '⚙️ Obrero', precio: 1000000 },
  { nombre: '🛠️ Artesano', precio: 1250000 },
  { nombre: '🗡️ Combatiente', precio: 1500000 },
  { nombre: '⚔️ Guerrero', precio: 1750000 },
  { nombre: '🛡️ Defensor', precio: 2000000 },
  { nombre: '🎯 Experto', precio: 2250000 },

  { nombre: '🏹 Veterano', precio: 2500000 },
  { nombre: '🔥 Conquistador', precio: 2750000 },
  { nombre: '🦾 Maestro', precio: 3000000 },
  { nombre: '🥇 Maestro Avanzado', precio: 3250000 },
  { nombre: '💎 Élite', precio: 3500000 },
  { nombre: '💠 Élite Superior', precio: 3750000 },
  { nombre: '🏆 Campeón', precio: 4000000 },
  { nombre: '👑 Gran Campeón', precio: 4250000 },
  { nombre: '🦅 Águila Imperial', precio: 4500000 },
  { nombre: '🐺 Alfa', precio: 4750000 },

  { nombre: '🦁 Titán', precio: 5000000 },
  { nombre: '⚡ Señor de Guerra', precio: 5250000 },
  { nombre: '🐉 Dragón', precio: 5500000 },
  { nombre: '🐲 Dragón Antiguo', precio: 5750000 },
  { nombre: '🔥 Fénix', precio: 6000000 },
  { nombre: '🌋 Fénix Eterno', precio: 6250000 },
  { nombre: '💀 Espectro', precio: 6500000 },
  { nombre: '👻 Fantasma Supremo', precio: 6750000 },
  { nombre: '☠️ Segador', precio: 7000000 },
  { nombre: '🩸 Ángel Caído', precio: 7250000 },

  { nombre: '🕊️ Redentor', precio: 7500000 },
  { nombre: '🌕 Guardián Lunar', precio: 7750000 },
  { nombre: '☀️ Guardián Solar', precio: 8000000 },
  { nombre: '🌠 Guardián Estelar', precio: 8250000 },
  { nombre: '🌌 Guardián Galáctico', precio: 8500000 },
  { nombre: '🪐 Guardián Cósmico', precio: 8750000 },
  { nombre: '⚜️ Noble Supremo', precio: 9000000 },
  { nombre: '🏛️ Gran Noble', precio: 9250000 },
  { nombre: '🧠 Sabio', precio: 9500000 },
  { nombre: '📜 Gran Sabio', precio: 9750000 },

  { nombre: '🔮 Oráculo', precio: 10000000 },
  { nombre: '✨ Místico', precio: 10250000 },
  { nombre: '🌟 Ascendido', precio: 10500000 },
  { nombre: '🌈 Celestial', precio: 10750000 },
  { nombre: '🌠 Celestial Mayor', precio: 11000000 },
  { nombre: '⚡ Divino', precio: 11250000 },
  { nombre: '🙏 Elegido Divino', precio: 11500000 },
  { nombre: '💫 Semidiós', precio: 11750000 },
  { nombre: '👼 Arcángel', precio: 12000000 },
  { nombre: '👼 Arcángel Supremo', precio: 12250000 },

  { nombre: '🌌 Ser Divino', precio: 12500000 },
  { nombre: '💫 Dios Menor', precio: 12750000 },
  { nombre: '💫 Dios', precio: 13000000 },
  { nombre: '💫 Dios Supremo', precio: 13250000 },
  { nombre: '🌠 Inmortal', precio: 13500000 },
  { nombre: '♾️ Inmortal Supremo', precio: 13750000 },
  { nombre: '🌍 Dominador', precio: 14000000 },
  { nombre: '🌎 Dominador Mundial', precio: 14250000 },
  { nombre: '🌐 Dominador Universal', precio: 14500000 },
  { nombre: '🚀 Conquistador Estelar', precio: 14750000 },

  { nombre: '🪐 Cósmico', precio: 15000000 },
  { nombre: '🌌 Cósmico Superior', precio: 15250000 },
  { nombre: '🌌 Señor Galáctico', precio: 15500000 },
  { nombre: '🌌 Emperador Galáctico', precio: 15750000 },
  { nombre: '🛸 Soberano Estelar', precio: 16000000 },
  { nombre: '🌠 Emperador Estelar', precio: 16250000 },
  { nombre: '🌌 Entidad Suprema', precio: 16500000 },
  { nombre: '🧬 Dios Universal', precio: 16750000 },
  { nombre: '🧬 Dios Multiversal', precio: 17000000 },
  { nombre: '♾️ Entidad Multiversal', precio: 17250000 },

  { nombre: '🌌 Arquitecto Cósmico', precio: 17500000 },
  { nombre: '⚛️ Forjador Universal', precio: 17750000 },
  { nombre: '🪐 Creador Estelar', precio: 18000000 },
  { nombre: '🌠 Creador Galáctico', precio: 18250000 },
  { nombre: '🌌 Creador Universal', precio: 18500000 },
  { nombre: '✨ Ser Primordial', precio: 18750000 },
  { nombre: '🔥 Primordial Supremo', precio: 19000000 },
  { nombre: '🌟 Eterno', precio: 19250000 },
  { nombre: '♾️ Eterno Supremo', precio: 19500000 },
  { nombre: '🌌 Trascendente', precio: 19750000 },

  { nombre: '🚪 Trascendente Mayor', precio: 20000000 },
  { nombre: '🌠 Ser Absoluto', precio: 20250000 },
  { nombre: '👁️ Vigilante Eterno', precio: 20500000 },
  { nombre: '⚜️ Rey del Cosmos', precio: 20750000 },
  { nombre: '👑 Emperador del Cosmos', precio: 21000000 },
  { nombre: '🌌 Soberano Absoluto', precio: 21250000 },
  { nombre: '♾️ Amo del Tiempo', precio: 21500000 },
  { nombre: '🌀 Amo del Espacio', precio: 21750000 },
  { nombre: '⚛️ Amo de la Realidad', precio: 22000000 },
  { nombre: '🌌 Amo de las Dimensiones', precio: 22250000 },

  { nombre: '💠 Nexus Universal', precio: 22500000 },
  { nombre: '🌠 Nexus Multiversal', precio: 22750000 },
  { nombre: '♾️ Entidad Eterna', precio: 23000000 },
  { nombre: '✨ Entidad Absoluta', precio: 23250000 },
  { nombre: '🌌 Alfa Universal', precio: 23500000 },
  { nombre: '🌌 Omega Universal', precio: 23750000 },
  { nombre: '🌟 Alfa Omega', precio: 24000000 },
  { nombre: '⚜️ Deidad Suprema', precio: 24250000 },
  { nombre: '👑 Rey de Reyes', precio: 24500000 },
  { nombre: '👑 Legends Team', precio: 25000000 }
];

let handler = async (message, { args, command }) => {
  try {
    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const number = senderJid.split('@')[0];
    let user = db.getUser(number);
    if (!user) return await message.reply('❌ No se encontraron tus datos.');

    const rangoActual = user.rango || '🌱 Novato';
    const indexActual = RANGOS.findIndex(r => r.nombre === rangoActual);
    const siguiente = RANGOS[indexActual + 1];
    const dinero = user.money || 0;

    // -----------------------------
    // 🔹 .rank → muestra rango y progreso
    // -----------------------------
    if (command === 'rank') {
      let msg = `🏅 Tu rango actual: ${rangoActual}\n`;

      if (siguiente) {
        const falta = siguiente.precio - dinero;
        const puedeSubir = falta <= 0;
        const emoji = puedeSubir ? '✅' : '❌';
        const textoFalta = puedeSubir
          ? '¡Tienes suficiente dinero para subir de rango!'
          : `Te faltan ${falta.toLocaleString()} monedas.`;

        msg += `➡️ Próximo rango: ${siguiente.nombre}\n`;
        msg += `💰 Precio: ${siguiente.precio.toLocaleString()} monedas\n`;
        msg += `${emoji} ${textoFalta}`;
      } else {
        msg += `🏆 ¡Ya alcanzaste el rango máximo!`;
      }

      return await message.reply(msg);
    }

    // -----------------------------
    // 🔹 .rankup → sube de rango
    // -----------------------------
    if (command === 'rankup') {
      if (!siguiente)
        return await message.reply('🏆 Ya estás en el rango máximo.');

      if (dinero < siguiente.precio)
        return await message.reply(
          `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
        );

      // Actualizar usuario
      user.money -= siguiente.precio;
      user.rango = siguiente.nombre;
      user.respeto = (user.respeto || 0) + 5;
      db.setUser(number, user);

      return await message.reply(
        `🎉 ¡Felicidades!\n\n` +
        `🏅 Ascendiste a: *${siguiente.nombre}*\n` +
        `💵 Coste: ${siguiente.precio.toLocaleString()} monedas\n` +
        `💪 Has ganado +5 Respeto por tu avance.`
      );
    }

    // -----------------------------
    // 🔹 .ranks → lista completa
    // -----------------------------
    if (command === 'ranks') {
      let texto = '🏆 *Lista de Rangos y Precios*\n\n';
      for (let i = 0; i < RANGOS.length; i++) {
        let actual = RANGOS[i];
        texto += `${i + 1}. ${actual.nombre} — 💰 ${actual.precio.toLocaleString()}\n`;
      }
      texto += `\nUsa *.rankup* para subir de rango.`;
      return await message.reply(texto);
    }

  } catch (err) {
    console.error('Error en comando rank:', err);
    await message.reply('❌ Error al ejecutar el comando de rangos.');
  }
};

handler.help = ['rank', 'rankup', 'ranks'];
handler.tags = ['rpg', 'usuarios', 'economía'];
handler.command = /^(rank|rankup|ranks)$/i;
handler.group = true;

module.exports = handler;
handler.apodo = true;