const fs = require('fs');
const path = require('path');

// Ruta del archivo JSON de temporadas (mismo directorio que el plugin)
const TEMPORADAS_FILE = path.join(__dirname, 'temporadas_coins.json');

// Función para cargar datos de temporadas
function loadTemporadas() {
    try {
        if (fs.existsSync(TEMPORADAS_FILE)) {
            const data = fs.readFileSync(TEMPORADAS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error al cargar temporadas:', error);
    }
    return null;
}

// Función para obtener el apodo actual de un usuario
function getApodoActual(userNumber) {
    const allUsers = global.db.data.users || {};
    const userData = allUsers[userNumber];
    return (userData && userData.apodo && userData.apodo.trim() !== '') 
        ? userData.apodo 
        : 'Sin apodo';
}

// Función para calcular posición actual en la temporada que está corriendo
function calcularPosicionEnTemporadaActual(targetNumber) {
    try {
        const temporadasData = loadTemporadas();
        
        // La temporada actual es la siguiente que se finalizará
        const temporadaActualCorriendo = temporadasData ? temporadasData.temporadaActual + 1 : 1;
        
        const allUsers = global.db.data.users || {};
        
        // Crear array con todos los usuarios y sus coins actuales
        const usersWithCoins = [];
        for (let [number, userData] of Object.entries(allUsers)) {
            const totalCoins = (userData.money || 0) + (userData.bank || 0);
            usersWithCoins.push({
                number: number,
                totalCoins: totalCoins
            });
        }
        
        // Ordenar por coins (mayor a menor)
        usersWithCoins.sort((a, b) => b.totalCoins - a.totalCoins);
        
        // Encontrar la posición del usuario
        const posicion = usersWithCoins.findIndex(u => u.number === targetNumber) + 1;
        
        return { 
            posicion, 
            temporada: temporadaActualCorriendo
        };
    } catch (error) {
        console.error('Error al calcular posición actual:', error);
        return null;
    }
}

// Función para obtener el ganador de una temporada
function getGanadorTemporada(numTemporada) {
    const temporadasData = loadTemporadas();
    if (!temporadasData || !temporadasData.temporadas || !temporadasData.temporadas[numTemporada]) {
        return null;
    }
    
    const usuarios = temporadasData.temporadas[numTemporada];
    
    // Buscar el usuario con posición 1
    for (let [userNumber, userData] of Object.entries(usuarios)) {
        if (userData.posicion === 1) {
            // Obtener el apodo ACTUAL del ganador (no guardado)
            const apodoActual = getApodoActual(userNumber);
            return {
                apodo: apodoActual,
                coins: userData.coins
            };
        }
    }
    
    return null;
}

// Función para obtener las temporadas del usuario desde el JSON
function getTemporadasDelUsuario(userNumber) {
    const temporadasData = loadTemporadas();
    if (!temporadasData || !temporadasData.temporadas) {
        return [];
    }
    
    const temporadasDelUsuario = [];
    
    // Recorrer todas las temporadas en el JSON
    for (let [numTemporada, usuarios] of Object.entries(temporadasData.temporadas)) {
        // Ver si el usuario participó en esta temporada
        if (usuarios[userNumber]) {
            temporadasDelUsuario.push({
                numero: parseInt(numTemporada),
                posicion: usuarios[userNumber].posicion,
                coins: usuarios[userNumber].coins
            });
        }
    }
    
    // Ordenar por número de temporada (de menor a mayor)
    temporadasDelUsuario.sort((a, b) => a.numero - b.numero);
    
    return temporadasDelUsuario;
}

// Función para normalizar texto (eliminar tildes y convertir a minúsculas)
function normalizeText(text) {
    if (!text) return '';
    return text
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ');
}

// Función para buscar usuario por apodo
function findUserByApodo(apodo) {
    const normalizedApodo = normalizeText(apodo);
    const allUsers = global.db.data.users || {};
    
    // Primera pasada: búsqueda exacta
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo === normalizedApodo) {
                return { number, userData };
            }
        }
    }
    
    // Segunda pasada: búsqueda parcial (contiene)
    for (let [number, userData] of Object.entries(allUsers)) {
        if (userData.apodo && userData.apodo.trim() !== '') {
            const normalizedUserApodo = normalizeText(userData.apodo);
            
            if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                return { number, userData };
            }
        }
    }
    
    return null;
}

let handler = async (message, { text, args }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        
        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        
        const senderNumber = senderJid.split('@')[0];
        let targetJid = senderJid;
        let targetNumber = senderNumber;
        let searchedByApodo = false;
        let targetApodo = '';
        
        const mentionedJids = message?.mentions;
        
        // Verificar si mencionaron a alguien
        if (mentionedJids && mentionedJids.length > 0) {
            targetJid = mentionedJids[0];
            targetNumber = targetJid.split('@')[0];
            
            // Obtener apodo ACTUAL del usuario mencionado
            targetApodo = getApodoActual(targetNumber);
        } 
        // Verificar si buscaron por apodo
        else if ((text && text.trim() !== '') || (args && args.length > 0)) {
            const apodoQuery = args && args.length > 0 ? args.join(' ') : text.trim();
            
            const foundUser = findUserByApodo(apodoQuery);
            
            if (foundUser) {
                targetNumber = foundUser.number;
                targetJid = targetNumber + '@s.whatsapp.net';
                searchedByApodo = true;
                targetApodo = getApodoActual(targetNumber);
            } else {
                return await message.reply(`❌ No se encontró ningún usuario con el apodo "${apodoQuery}".\n\nℹ️ Usa: .temporadas, .temporadas @usuario o .temporadas <apodo>`);
            }
        } else {
            // Ver sus propias temporadas
            targetApodo = getApodoActual(senderNumber);
        }
        
        // Obtener temporadas del usuario SOLO DEL JSON
        const temporadasDelUsuario = getTemporadasDelUsuario(targetNumber);
        
        // Crear mensaje
        let mensaje = `🏆 *HISTORIAL DE TEMPORADAS*\n`;
        
        if (targetNumber === senderNumber) {
            mensaje += `👤 Tus temporadas\n\n`;
        } else if (searchedByApodo) {
            mensaje += `👤 Temporadas de ${targetApodo}\n\n`;
        } else {
            mensaje += `👤 Temporadas de @${targetNumber}\n\n`;
        }
        
        // Mostrar historial de temporadas pasadas
        if (temporadasDelUsuario.length > 0) {
            mensaje += `━━━━━━━━━━━━━━━━\n`;
            mensaje += `📜 *Temporadas finalizadas:*\n\n`;
            
            // Mostrar todas las temporadas en orden inverso (más reciente primero)
            const todasReverse = [...temporadasDelUsuario].reverse();
            for (let temp of todasReverse) {
                let posEmoji = '';
                if (temp.posicion === 1) posEmoji = '🥇';
                else if (temp.posicion === 2) posEmoji = '🥈';
                else if (temp.posicion === 3) posEmoji = '🥉';
                else posEmoji = `${temp.posicion}º`;
                
                mensaje += `Temporada #${temp.numero}: ${posEmoji}\n`;
                mensaje += `💰 ${temp.coins.toLocaleString()} coins\n`;
                
                // Mostrar ganador de esa temporada (con apodo ACTUAL)
                const ganador = getGanadorTemporada(temp.numero);
                if (ganador) {
                    mensaje += `👑 Ganador: ${ganador.apodo} (${ganador.coins.toLocaleString()} coins)\n`;
                }
                mensaje += `\n`;
            }
        } else {
            mensaje += `📭 Sin participación en temporadas finalizadas\n\n`;
        }
        
        // Mostrar posición en la temporada ACTUAL (la que está corriendo)
        mensaje += `━━━━━━━━━━━━━━━━\n`;
        const posActual = calcularPosicionEnTemporadaActual(targetNumber);
        if (posActual) {
            let emojiPos = '';
            if (posActual.posicion === 1) emojiPos = '🥇';
            else if (posActual.posicion === 2) emojiPos = '🥈';
            else if (posActual.posicion === 3) emojiPos = '🥉';
            else emojiPos = `${posActual.posicion}º`;
            
            mensaje += `📍 *Temporada actual: #${posActual.temporada}*\n`;
            mensaje += `Posición: ${emojiPos}`;
        }
        
        let mentions = [targetJid];
        
        await message.reply(mensaje, { mentions: mentions });
        
    } catch (error) {
        console.error('Error en comando temporadas:', error);
        await message.reply('❌ Ocurrió un error al mostrar las temporadas.');
    }
};

handler.help = ['temporadas', 'temporadas @usuario', 'temporadas <apodo>'];
handler.tags = ['info'];
handler.command = /^(temporadas?|temps?)$/i;
handler.group = true;

module.exports = handler;