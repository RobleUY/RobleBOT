let handler = async (message) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente.');
        }

        const senderNumber = senderJid.split('@')[0];

        // 🚨 Mensaje estilo denuncia automática
        const denunciaMsg = `
🚨 *ALERTA* 🚨

Se ha registrado una denuncia formal contra *@${senderNumber}*

📄 *Motivo:* Solicitud de contenido ilegal catalogado como "CP"
⚖️ *Estado:* Investigación en curso

📡 Sistema de monitoreo activado...

🚓 Las autoridades ya han sido notificadas
y se encuentran en camino a su ubicación.

📍 Se recomienda permanecer en el lugar.

❗ *Advertencia:* Este tipo de actividad está penada por la ley.

👮‍♂️ *Unidad de Cibercrimen en camino...*
        `;

        await message.reply(denunciaMsg, {
            mentions: [senderJid]
        });

    } catch (error) {
        console.error('❌ Error en comando poli:', error);
        await message.reply('❌ Error al ejecutar el comando.');
    }
};

handler.help = ['cp'];
handler.tags = ['fun'];
handler.command = /^(cp)$/i;

module.exports = handler;