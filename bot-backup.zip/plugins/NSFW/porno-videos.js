const axios = require('axios');
const fs = require('fs');
const path = require('path');

const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// Configuración de timeouts
const SEARCH_TIMEOUT = 15000; // 15 segundos para búsquedas
const DOWNLOAD_TIMEOUT = 120000; // 2 minutos para descargas

function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

function isNsfwEnabled(groupJid, sock) {
    if (sock && sock._subNum) {
        try {
            const subBotModule = require('../SUBBOTS/subbots-onoff.js');
            if (typeof subBotModule.isSubBotNsfwEnabled === 'function') {
                if (!subBotModule.isSubBotNsfwEnabled(sock._subNum)) return false;
            }
        } catch (_) {}
    }
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

async function checkNsfwPermission(message, conn, chatId) {
    const isGroup = chatId && chatId.endsWith('@g.us');
    if (!isGroup) {
        const sock = conn || message?._sock;
        if (sock && sock._subNum) {
            try {
                const subBotModule = require('../SUBBOTS/subbots-onoff.js');
                if (typeof subBotModule.isSubBotNsfwEnabled === 'function') {
                    if (!subBotModule.isSubBotNsfwEnabled(sock._subNum)) return { canUse: false, isAdmin: false };
                }
            } catch (_) {}
        }
        return { canUse: true, isAdmin: false };
    }

    try {
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        const userJid = message.author || message.sender || message.key?.participant;
        const userNumber = userJid.split('@')[0].split(':')[0];
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (isNsfwEnabled(chatId, conn || message?._sock)) return { canUse: true, isAdmin: userIsAdmin };
        return { canUse: userIsAdmin, isAdmin: userIsAdmin };
    } catch (error) {
        if (error?.data === 403 || error?.message?.includes('forbidden')) {
            console.log(`⚠️ Sin permisos para obtener metadata del grupo ${chatId}`);
            throw new Error('NO_PERMISSIONS');
        }
        throw error;
    }
}

function extractDuration(info) {
    if (!info) return 'N/A';
    const match = info.match(/(\d+min)/);
    return match ? match[1] : 'N/A';
}

// ──────────────────────────────────────────────────────────────
// TRADUCCIÓN DE TÍTULOS AL ESPAÑOL
// ──────────────────────────────────────────────────────────────
async function translateToSpanish(text) {
    if (!text) return text;
    
    // Si ya está en español o es muy corto, no traducir
    if (text.length < 5) return text;
    
    try {
        // Usar API de MyMemory (gratuita, sin API key)
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|es`;
        const response = await axios.get(url, { timeout: 5000 });
        
        if (response.data?.responseData?.translatedText) {
            return response.data.responseData.translatedText;
        }
    } catch (error) {
        console.log('Error en traducción, usando título original:', error.message);
    }
    
    return text; // Si falla, devolver el texto original
}

// Traducir múltiples títulos en paralelo
async function translateTitles(titles) {
    const promises = titles.map(title => translateToSpanish(title));
    const results = await Promise.allSettled(promises);
    
    return results.map((result, index) => {
        if (result.status === 'fulfilled') {
            return result.value;
        }
        return titles[index]; // Si falla, devolver el original
    });
}

// ──────────────────────────────────────────────────────────────
// DETECCIÓN AUTOMÁTICA DE PLATAFORMA POR LINK
// ──────────────────────────────────────────────────────────────
function detectPlatform(url) {
    if (url.includes('xvideos.com')) return 'xvideos';
    if (url.includes('pornhub.com')) return 'pornhub';
    if (url.includes('xnxx.com') || url.includes('xnxx.es')) return 'xnxx';
    return null;
}

// Descarga video según plataforma detectada automáticamente
async function downloadByPlatform(url) {
    const platform = detectPlatform(url);

    if (platform === 'xvideos') {
        // Intentar primera API (Delirius)
        try {
            const res = await axios.get(`http://api.delirius.online/download/xvideos?url=${encodeURIComponent(url)}`, {
                timeout: DOWNLOAD_TIMEOUT
            });
            const data = res.data;
            if (data.status && data.data?.download) {
                return {
                    downloadUrl: data.data.download,
                    caption: `🎬 *${data.data.title || 'Video'}*\n⏱️ ${data.data.duration || 'N/A'} | 👁️ ${data.data.views || 'N/A'} | 👍 ${data.data.likes || 'N/A'}`
                };
            }
        } catch (err) {
            console.log('API Delirius falló, intentando backup...');
        }
        
        // Backup API
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/nsfw/xvideos?url=${encodeURIComponent(url)}`, {
            timeout: DOWNLOAD_TIMEOUT
        });
        const data = res.data;
        if (!data.ok) throw new Error('No se pudo obtener el video de Xvideos.');
        return {
            downloadUrl: data.download_url,
            caption: `🎬 *${data.title || 'Video'}*\n⏱️ ${data.duration || 'N/A'} | 👁️ ${data.views || 'N/A'} | 👍 ${data.likes || 'N/A'}`
        };
    }

    if (platform === 'pornhub') {
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/nsfw/pornhub?url=${encodeURIComponent(url)}`, {
            timeout: DOWNLOAD_TIMEOUT
        });
        const data = res.data;
        if (!data.ok || !data.qualities || data.qualities.length === 0) throw new Error('No se pudo obtener el video de Pornhub.');
        // Elegir la calidad más baja para enviar más rápido
        const file = data.qualities[data.qualities.length - 1];
        return {
            downloadUrl: file.download_url,
            caption: `🎬 *${data.title || 'Video'}*\n📺 Calidad: ${file.quality} | 💾 ${file.size}`
        };
    }

    if (platform === 'xnxx') {
        // Intentar primera API (Sanka Vollerei)
        try {
            const dlRes = await axios.get(`https://www.sankavollerei.web.id/download/xnxx?apikey=planaai&url=${encodeURIComponent(url)}`, {
                timeout: DOWNLOAD_TIMEOUT
            });
            const data = dlRes.data;
            if (data.status && data.result?.files?.low) {
                return {
                    downloadUrl: data.result.files.low,
                    caption: `🎬 *${data.result.title || 'Video de XNXX'}*\n⏱️ ${data.result.duration || 'N/A'}`
                };
            }
        } catch (err) {
            console.log('API Sanka Vollerei falló, intentando Delirius...');
        }

        // Backup API (Delirius)
        const dlRes = await axios.get(`https://api.delirius.online/download/xnxxdl?url=${encodeURIComponent(url)}`, {
            timeout: DOWNLOAD_TIMEOUT
        });
        const data = dlRes.data;
        if (!data.status || !data.data?.download?.low) throw new Error('No se pudo obtener el video de XNXX.');
        return {
            downloadUrl: data.data.download.low,
            caption: `🎬 *${data.data.title || 'Video de XNXX'}*\n⏱️ ${data.data.duration || 'N/A'} | 👁️ ${data.data.views || 'N/A'}`
        };
    }

    throw new Error('Plataforma no reconocida. Usá links de xvideos.com, pornhub.com o xnxx.com');
}

// ──────────────────────────────────────────────────────────────
// HELPER: verificar permisos NSFW con mensajes de error
// ──────────────────────────────────────────────────────────────
async function verifyNsfw(message, conn, chatId) {
    try {
        const { canUse } = await checkNsfwPermission(message, conn, chatId);
        if (!canUse) {
            await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
            return false;
        }
        return true;
    } catch (error) {
        if (error.message === 'NO_PERMISSIONS') {
            await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💡 Asegúrate de que el bot sea administrador del grupo.');
            return false;
        }
        throw error;
    }
}

// ──────────────────────────────────────────────────────────────
// BÚSQUEDA ESPECÍFICA EN XNXX
// ──────────────────────────────────────────────────────────────
async function searchXnxx(query) {
    // Intentar Sanka Vollerei primero
    try {
        const res = await axios.get(`https://www.sankavollerei.web.id/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        });
        if (res.data.status && res.data.result?.length > 0) {
            const validResult = res.data.result.find(item => item.link && !item.link.includes('undefined'));
            if (validResult) {
                return { url: validResult.link, title: validResult.title, platform: 'xnxx' };
            }
        }
    } catch (err) {
        console.log('XNXX Sanka falló, intentando Delirius...');
    }

    // Backup: Delirius
    try {
        const res = await axios.get(`https://api.delirius.online/search/xnxxsearch?query=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        });
        if (res.data.status && res.data.data?.length > 0) {
            const validResult = res.data.data.find(item => item.link && !item.link.includes('undefined'));
            if (validResult) {
                return { url: validResult.link, title: validResult.title, platform: 'xnxx' };
            }
        }
    } catch (err) {
        console.log('XNXX Delirius falló');
    }

    return null;
}

// ──────────────────────────────────────────────────────────────
// BÚSQUEDA ESPECÍFICA EN XVIDEOS
// ──────────────────────────────────────────────────────────────
async function searchXvideos(query) {
    // Intentar Delirius primero
    try {
        const res = await axios.get(`https://api.delirius.online/search/xvideos?query=${encodeURIComponent(query)}&page=0`, {
            timeout: SEARCH_TIMEOUT
        });
        if (res.data.status && res.data.data?.length > 0) {
            const validResult = res.data.data.find(v => v.url && !v.url.includes('undefined'));
            if (validResult) {
                return { url: validResult.url, title: validResult.title, platform: 'xvideos' };
            }
        }
    } catch (err) {
        console.log('Xvideos Delirius falló, intentando Roble...');
    }

    // Backup: Roble
    try {
        const res = await axios.get(`https://robleuy.vercel.app/robleapi/buscador/xvideossearch?q=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        });
        if (res.data.ok && res.data.videos?.length > 0) {
            const validResult = res.data.videos.find(v => v.url && !v.url.includes('undefined'));
            if (validResult) {
                return { url: validResult.url, title: validResult.title, platform: 'xvideos' };
            }
        }
    } catch (err) {
        console.log('Xvideos Roble falló');
    }

    return null;
}

// ──────────────────────────────────────────────────────────────
// BÚSQUEDA RÁPIDA: Lanza todas las APIs en paralelo y toma la primera
// ──────────────────────────────────────────────────────────────
async function fastSearchAllPlatforms(query) {
    const searches = [
        // Búsqueda en XNXX (Sanka Vollerei)
        axios.get(`https://www.sankavollerei.web.id/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        }).then(res => {
            if (res.data.status && res.data.result?.length > 0) {
                const first = res.data.result.find(item => item.link && !item.link.includes('undefined'));
                if (first) {
                    return { url: first.link, title: first.title, platform: 'xnxx' };
                }
            }
            return null;
        }).catch(() => null),

        // Búsqueda en XNXX (Delirius backup)
        axios.get(`https://api.delirius.online/search/xnxxsearch?query=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        }).then(res => {
            if (res.data.status && res.data.data?.length > 0) {
                const first = res.data.data.find(item => item.link && !item.link.includes('undefined'));
                if (first) {
                    return { url: first.link, title: first.title, platform: 'xnxx' };
                }
            }
            return null;
        }).catch(() => null),

        // Búsqueda en Xvideos (Delirius)
        axios.get(`https://api.delirius.online/search/xvideos?query=${encodeURIComponent(query)}&page=0`, {
            timeout: SEARCH_TIMEOUT
        }).then(res => {
            if (res.data.status && res.data.data?.length > 0) {
                const validResult = res.data.data.find(v => v.url && !v.url.includes('undefined'));
                if (validResult) {
                    return { url: validResult.url, title: validResult.title, platform: 'xvideos' };
                }
            }
            return null;
        }).catch(() => null),

        // Búsqueda en Xvideos (Roble backup)
        axios.get(`https://robleuy.vercel.app/robleapi/buscador/xvideossearch?q=${encodeURIComponent(query)}`, {
            timeout: SEARCH_TIMEOUT
        }).then(res => {
            if (res.data.ok && res.data.videos?.length > 0) {
                const first = res.data.videos.find(v => v.url && !v.url.includes('undefined'));
                if (first) {
                    return { url: first.url, title: first.title, platform: 'xvideos' };
                }
            }
            return null;
        }).catch(() => null)
    ];

    // Promise.allSettled para obtener resultados de todos
    const results = await Promise.allSettled(searches);
    
    // Buscar el primer resultado válido
    for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
            return result.value;
        }
    }
    
    return null;
}

// ──────────────────────────────────────────────────────────────
// HANDLER ESPECÍFICO: .xnxx (solo busca en XNXX)
// ──────────────────────────────────────────────────────────────
async function handlerXnxxSpecific(message, conn) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            const helpMsg = `✅ *Cómo usar .xnxx*\n\n*Con link directo:*\n.xnxx https://www.xnxx.com/video...\n\n*Buscar por título:*\n.xnxx mia khalifa\n\n💡 Este comando busca SOLO en XNXX.\n\n🌐 Para buscar en todas las plataformas usa: .porno <título>`;
            return await message.reply(helpMsg);
        }

        // Si es un link, descargar directamente
        if (arg.startsWith('http')) {
            const platform = detectPlatform(arg);
            if (!platform) {
                return await message.reply('❌ Link no reconocido. Usá links de xvideos.com, pornhub.com o xnxx.com');
            }
            await message.reply('⏳ *Descargando video...*\n\nEsto puede tardar entre 30-60 segundos. Por favor, espera.');
            
            const { downloadUrl, caption } = await downloadByPlatform(arg);
            const videoResponse = await axios.get(downloadUrl, { 
                responseType: 'arraybuffer', 
                timeout: DOWNLOAD_TIMEOUT,
                maxContentLength: 100 * 1024 * 1024
            });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            
            await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
            return;
        }

        // Si es texto, buscar solo en XNXX
        await message.reply('🔍 *Buscando en XNXX...*');

        const result = await searchXnxx(arg);
        
        if (!result) {
            return await message.reply('❌ No se encontraron resultados en XNXX.\n\n💡 Intenta con otros términos o usa .porno para buscar en todas las plataformas.');
        }

        // Descargar el video encontrado
        await message.reply(`✅ *Video encontrado en XNXX*\n\n⏳ Descargando...\nEsto puede tardar 30-60 segundos.`);
        
        const { downloadUrl, caption } = await downloadByPlatform(result.url);
        const videoResponse = await axios.get(downloadUrl, { 
            responseType: 'arraybuffer', 
            timeout: DOWNLOAD_TIMEOUT,
            maxContentLength: 100 * 1024 * 1024
        });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');
        
        await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error(`Error en handler XNXX:`, error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud. Intenta nuevamente o usa un link directo.');
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLER ESPECÍFICO: .xvideos (solo busca en Xvideos)
// ──────────────────────────────────────────────────────────────
async function handlerXvideosSpecific(message, conn) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            const helpMsg = `✅ *Cómo usar .xvideos*\n\n*Con link directo:*\n.xvideos https://www.xvideos.com/video...\n\n*Buscar por título:*\n.xvideos mia khalifa\n\n💡 Este comando busca SOLO en Xvideos.\n\n🌐 Para buscar en todas las plataformas usa: .porno <título>`;
            return await message.reply(helpMsg);
        }

        // Si es un link, descargar directamente
        if (arg.startsWith('http')) {
            const platform = detectPlatform(arg);
            if (!platform) {
                return await message.reply('❌ Link no reconocido. Usá links de xvideos.com, pornhub.com o xnxx.com');
            }
            await message.reply('⏳ *Descargando video...*\n\nEsto puede tardar entre 30-60 segundos. Por favor, espera.');
            
            const { downloadUrl, caption } = await downloadByPlatform(arg);
            const videoResponse = await axios.get(downloadUrl, { 
                responseType: 'arraybuffer', 
                timeout: DOWNLOAD_TIMEOUT,
                maxContentLength: 100 * 1024 * 1024
            });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            
            await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
            return;
        }

        // Si es texto, buscar solo en Xvideos
        await message.reply('🔍 *Buscando en Xvideos...*');

        const result = await searchXvideos(arg);
        
        if (!result) {
            return await message.reply('❌ No se encontraron resultados en Xvideos.\n\n💡 Intenta con otros términos o usa .porno para buscar en todas las plataformas.');
        }

        // Descargar el video encontrado
        await message.reply(`✅ *Video encontrado en Xvideos*\n\n⏳ Descargando...\nEsto puede tardar 30-60 segundos.`);
        
        const { downloadUrl, caption } = await downloadByPlatform(result.url);
        const videoResponse = await axios.get(downloadUrl, { 
            responseType: 'arraybuffer', 
            timeout: DOWNLOAD_TIMEOUT,
            maxContentLength: 100 * 1024 * 1024
        });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');
        
        await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error(`Error en handler Xvideos:`, error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud. Intenta nuevamente o usa un link directo.');
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLER: .xnxxsearch <titulo>
// ──────────────────────────────────────────────────────────────
let handlerXnxxSearch = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (!query) return await message.reply('❌ Proporciona un título. Ejemplo: .xnxxsearch milf');

        await message.reply('🔍 *Buscando en XNXX...*');

        // Intentar API Sanka Vollerei primero
        try {
            const res = await axios.get(`https://www.sankavollerei.web.id/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`, {
                timeout: SEARCH_TIMEOUT
            });
            const data = res.data;

            if (data.status && data.result?.length > 0) {
                // Filtrar solo los que tienen link válido
                const validResults = data.result.filter(item => item.link && !item.link.includes('undefined'));
                
                if (validResults.length > 0) {
                    const resultsToShow = validResults.slice(0, 10);
                    
                    // Traducir títulos al español
                    const titles = resultsToShow.map(item => item.title || 'Sin título');
                    const translatedTitles = await translateTitles(titles);
                    
                    let msg = `🔍 *Resultados para "${query}":*\n\n`;
                    resultsToShow.forEach((item, i) => {
                        msg += `*${i + 1}.* ${translatedTitles[i]}\n`;
                        msg += `⏱️ ${extractDuration(item.info)}\n`;
                        msg += `🔗 ${item.link}\n`;
                        msg += `─────────────────\n\n`;
                    });
                    msg += `💡 *Para descargar:*\nCopia el link y usa: .xnxx <link>`;
                    return await message.reply(msg);
                }
            }
        } catch (err) {
            console.error('Error con API Sanka:', err.message);
        }

        // Intentar API Delirius como backup
        try {
            const res = await axios.get(`https://api.delirius.online/search/xnxxsearch?query=${encodeURIComponent(query)}`, {
                timeout: SEARCH_TIMEOUT
            });
            const data = res.data;

            if (data.status && data.data?.length > 0) {
                // Filtrar solo los que tienen link válido
                const validResults = data.data.filter(item => item.link && !item.link.includes('undefined'));
                
                if (validResults.length > 0) {
                    const resultsToShow = validResults.slice(0, 10);
                    
                    // Traducir títulos al español
                    const titles = resultsToShow.map(item => item.title || 'Sin título');
                    const translatedTitles = await translateTitles(titles);
                    
                    let msg = `🔍 *Resultados para "${query}":*\n\n`;
                    resultsToShow.forEach((item, i) => {
                        msg += `*${i + 1}.* ${translatedTitles[i]}\n`;
                        msg += `⏱️ ${item.duration || 'N/A'} | 👁️ ${item.views || 'N/A'}\n`;
                        msg += `🔗 ${item.link}\n`;
                        msg += `─────────────────\n\n`;
                    });
                    msg += `💡 *Para descargar:*\nCopia el link y usa: .xnxx <link>`;
                    return await message.reply(msg);
                }
            }
        } catch (err) {
            console.error('Error con API Delirius:', err.message);
        }

        await message.reply('❌ No se encontraron resultados.');
    } catch (error) {
        console.error('Error en xnxxsearch:', error);
        await message.reply('❌ Error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXnxxSearch.help = ['xnxxsearch <titulo>'];
handlerXnxxSearch.tags = ['videos', 'nsfw'];
handlerXnxxSearch.command = /^(xnxxsearch)$/i;

// ──────────────────────────────────────────────────────────────
// HANDLER: .xvideossearch / .xvsearch <titulo>
// ──────────────────────────────────────────────────────────────
let handlerXvideosSearch = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (!query) return await message.reply('❌ Proporciona un título. Ejemplo: .xvsearch milf');

        await message.reply('🔍 *Buscando en Xvideos...*');

        // Intentar API Delirius primero
        try {
            const res = await axios.get(`https://api.delirius.online/search/xvideos?query=${encodeURIComponent(query)}&page=0`, {
                timeout: SEARCH_TIMEOUT
            });
            const data = res.data;

            if (data.status && data.data?.length > 0) {
                // Filtrar solo los que tienen URL válida
                const validResults = data.data.filter(v => v.url && !v.url.includes('undefined'));
                
                if (validResults.length > 0) {
                    const resultsToShow = validResults.slice(0, 10);
                    
                    // Traducir títulos al español
                    const titles = resultsToShow.map(v => v.title || 'Sin título');
                    const translatedTitles = await translateTitles(titles);
                    
                    let msg = `🔍 *Resultados para "${query}" en Xvideos:*\n\n`;
                    resultsToShow.forEach((v, i) => {
                        msg += `*${i + 1}.* ${translatedTitles[i]}\n`;
                        msg += `⏱️ ${v.duration || 'N/A'} | 📺 ${v.quality || 'N/A'}\n`;
                        msg += `🔗 ${v.url}\n`;
                        msg += `─────────────────\n\n`;
                    });
                    msg += `💡 *Para descargar:*\nCopia el link y usa: .xvideos <link>`;
                    return await message.reply(msg);
                }
            }
        } catch (err) {
            console.error('Error con API Delirius:', err.message);
        }

        // Intentar API Roble como backup
        try {
            const res = await axios.get(`https://robleuy.vercel.app/robleapi/buscador/xvideossearch?q=${encodeURIComponent(query)}`, {
                timeout: SEARCH_TIMEOUT
            });
            const data = res.data;

            if (data.ok && data.videos?.length > 0) {
                const resultsToShow = data.videos.slice(0, 10);
                
                // Traducir títulos al español
                const titles = resultsToShow.map(v => v.title || 'Sin título');
                const translatedTitles = await translateTitles(titles);
                
                let msg = `🔍 *Resultados para "${query}" en Xvideos:*\n\n`;
                resultsToShow.forEach((v, i) => {
                    msg += `*${i + 1}.* ${translatedTitles[i]}\n`;
                    msg += `⏱️ ${v.duration || 'N/A'} | 👤 ${v.author || 'N/A'} | 📺 ${v.quality || 'N/A'}\n`;
                    msg += `🔗 ${v.url}\n`;
                    msg += `─────────────────\n\n`;
                });
                msg += `💡 *Para descargar:*\nCopia el link y usa: .xvideos <link>`;
                return await message.reply(msg);
            }
        } catch (err) {
            console.error('Error con API Roble:', err.message);
        }

        await message.reply('❌ No se encontraron resultados en Xvideos.');
    } catch (error) {
        console.error('Error en xvideossearch:', error);
        await message.reply('❌ Error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXvideosSearch.help = ['xvideossearch <titulo>', 'xvsearch <titulo>'];
handlerXvideosSearch.tags = ['videos', 'nsfw'];
handlerXvideosSearch.command = /^(xvideossearch|xvsearch)$/i;

// ──────────────────────────────────────────────────────────────
// HANDLER UNIVERSAL: .porno / .vporno / .pornov (busca en todas)
// ──────────────────────────────────────────────────────────────
async function handlerPornoUniversal(message, conn) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            const helpMsg = `✅ *Cómo usar .porno*\n\n*Con link directo:*\n.porno https://www.xvideos.com/video...\n\n*Buscar por título:*\n.porno mia khalifa\n\n💡 Este comando busca en TODAS las plataformas (XNXX, Xvideos, Pornhub) y descarga el primer resultado disponible.\n\n🎯 Para buscar en plataformas específicas:\n• .xnxx <título> (solo XNXX)\n• .xvideos <título> (solo Xvideos)\n• .pornhub <link> (solo Pornhub)`;
            return await message.reply(helpMsg);
        }

        // Si es un link, descargar directamente
        if (arg.startsWith('http')) {
            const platform = detectPlatform(arg);
            if (!platform) {
                return await message.reply('❌ Link no reconocido. Usá links de xvideos.com, pornhub.com o xnxx.com');
            }
            await message.reply('⏳ *Descargando video...*\n\nEsto puede tardar entre 30-60 segundos. Por favor, espera.');
            
            const { downloadUrl, caption } = await downloadByPlatform(arg);
            const videoResponse = await axios.get(downloadUrl, { 
                responseType: 'arraybuffer', 
                timeout: DOWNLOAD_TIMEOUT,
                maxContentLength: 100 * 1024 * 1024
            });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            
            await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
            return;
        }

        // Si es texto, buscar en TODAS las plataformas en paralelo
        await message.reply('🔍 *Buscando en todas las plataformas...*\n\n⚡ Usando la API más rápida disponible...');

        const result = await fastSearchAllPlatforms(arg);
        
        if (!result) {
            return await message.reply('❌ No se encontraron resultados en ninguna plataforma.\n\n💡 Intenta con otros términos de búsqueda.');
        }

        // Descargar el video encontrado
        await message.reply(`✅ *Video encontrado en ${result.platform.toUpperCase()}*\n\n⏳ Descargando...\nEsto puede tardar 30-60 segundos.`);
        
        const { downloadUrl, caption } = await downloadByPlatform(result.url);
        const videoResponse = await axios.get(downloadUrl, { 
            responseType: 'arraybuffer', 
            timeout: DOWNLOAD_TIMEOUT,
            maxContentLength: 100 * 1024 * 1024
        });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');
        
        await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error(`Error en handler porno universal:`, error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud. Intenta nuevamente o usa un link directo.');
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLER: .pornhub (solo links)
// ──────────────────────────────────────────────────────────────
async function handlerPornhub(message, conn) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            const helpMsg = `✅ *Cómo usar .pornhub*\n\n*Con link directo:*\n.pornhub https://www.pornhub.com/view_video.php?viewkey=...\n\n⚠️ Pornhub solo acepta links directos (no soporta búsqueda por título).\n\n🌐 Para buscar por título usa: .porno <título>`;
            return await message.reply(helpMsg);
        }

        // Solo acepta links
        if (!arg.startsWith('http')) {
            return await message.reply('❌ Pornhub solo acepta links directos.\n\n💡 Para buscar por título usa: .porno <título>');
        }

        const platform = detectPlatform(arg);
        if (platform !== 'pornhub') {
            return await message.reply('❌ Este no es un link de Pornhub válido.');
        }

        await message.reply('⏳ *Descargando video de Pornhub...*\n\nEsto puede tardar entre 30-60 segundos. Por favor, espera.');
        
        const { downloadUrl, caption } = await downloadByPlatform(arg);
        const videoResponse = await axios.get(downloadUrl, { 
            responseType: 'arraybuffer', 
            timeout: DOWNLOAD_TIMEOUT,
            maxContentLength: 100 * 1024 * 1024
        });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');
        
        await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error(`Error en handler Pornhub:`, error);
        await message.reply('❌ Ocurrió un error al descargar el video de Pornhub. Verifica que el link sea válido.');
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLERS INDIVIDUALES
// ──────────────────────────────────────────────────────────────
let handlerXnxx = async (message, { conn }) => handlerXnxxSpecific(message, conn);
handlerXnxx.help = ['xnxx <titulo o link>'];
handlerXnxx.tags = ['videos', 'nsfw'];
handlerXnxx.command = /^(xnxx)$/i;

let handlerXvideos = async (message, { conn }) => handlerXvideosSpecific(message, conn);
handlerXvideos.help = ['xvideos <titulo o link>'];
handlerXvideos.tags = ['videos', 'nsfw'];
handlerXvideos.command = /^(xvideos)$/i;

let handlerPornhubCmd = async (message, { conn }) => handlerPornhub(message, conn);
handlerPornhubCmd.help = ['pornhub <link>'];
handlerPornhubCmd.tags = ['videos', 'nsfw'];
handlerPornhubCmd.command = /^(pornhub)$/i;

let handlerPorno = async (message, { conn }) => handlerPornoUniversal(message, conn);
handlerPorno.help = ['porno <titulo o link>', 'vporno <titulo o link>', 'pornov <titulo o link>'];
handlerPorno.tags = ['videos', 'nsfw'];
handlerPorno.command = /^(porno|vporno|pornov)$/i;

// ──────────────────────────────────────────────────────────────
// EXPORTS
// ──────────────────────────────────────────────────────────────
module.exports.xnxxsearch = handlerXnxxSearch;
module.exports.xvideossearch = handlerXvideosSearch;
module.exports.xvsearch = handlerXvideosSearch;

module.exports.xnxx = handlerXnxx;
module.exports.xvideos = handlerXvideos;
module.exports.pornhub = handlerPornhubCmd;

module.exports.porno = handlerPorno;
module.exports.vporno = handlerPorno;
module.exports.pornov = handlerPorno;