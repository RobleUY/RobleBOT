const axios = require('axios');
const fs = require('fs');
const path = require('path');

const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

async function checkNsfwPermission(message, conn, chatId) {
    const isGroup = chatId && chatId.endsWith('@g.us');
    if (!isGroup) return { canUse: true, isAdmin: false };

    try {
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        const userJid = message.author || message.sender || message.key?.participant;
        const userNumber = userJid.split('@')[0].split(':')[0];
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

        if (isNsfwEnabled(chatId)) return { canUse: true, isAdmin: userIsAdmin };
        return { canUse: userIsAdmin, isAdmin: userIsAdmin };
    } catch (error) {
        if (error?.data === 403 || error?.message?.includes('forbidden')) {
            console.log(`⚠️ Sin permisos para obtener metadata del grupo ${chatId}`);
            throw new Error('NO_PERMISSIONS');
        }
        throw error;
    }
}

function extractDuration(info) {
    if (!info) return 'N/A';
    const match = info.match(/(\d+min)/);
    return match ? match[1] : 'N/A';
}

// ──────────────────────────────────────────────────────────────
// DETECCIÓN AUTOMÁTICA DE PLATAFORMA POR LINK
// ──────────────────────────────────────────────────────────────
function detectPlatform(url) {
    if (url.includes('xvideos.com')) return 'xvideos';
    if (url.includes('pornhub.com')) return 'pornhub';
    if (url.includes('xnxx.com')) return 'xnxx';
    return null;
}

// Descarga video según plataforma detectada automáticamente
async function downloadByPlatform(url) {
    const platform = detectPlatform(url);

    if (platform === 'xvideos') {
        const res = await axios.get(`https://www.robleuy.site/robleapi/nsfw/xvideos?url=${encodeURIComponent(url)}`);
        const data = res.data;
        if (!data.ok) throw new Error('No se pudo obtener el video de Xvideos.');
        return {
            downloadUrl: data.download_url,
            caption: `🎬 *${data.title || 'Video'}*\n⏱️ ${data.duration || 'N/A'} | 👁️ ${data.views || 'N/A'} | 👍 ${data.likes || 'N/A'}`
        };
    }

    if (platform === 'pornhub') {
        const res = await axios.get(`https://www.robleuy.site/robleapi/nsfw/pornhub?url=${encodeURIComponent(url)}`);
        const data = res.data;
        if (!data.ok || !data.qualities || data.qualities.length === 0) throw new Error('No se pudo obtener el video de Pornhub.');
        // Elegir la calidad más baja para enviar más rápido
        const file = data.qualities[data.qualities.length - 1];
        return {
            downloadUrl: file.download_url,
            caption: `🎬 *${data.title || 'Video'}*\n📺 Calidad: ${file.quality} | 💾 ${file.size}`
        };
    }

    if (platform === 'xnxx') {
        const dlRes = await axios.get(`https://www.sankavollerei.com/download/xnxx?apikey=planaai&url=${encodeURIComponent(url)}`);
        const data = dlRes.data;
        if (!data.status || !data.result?.files?.low) throw new Error('No se pudo obtener el video de XNXX.');
        return {
            downloadUrl: data.result.files.low,
            caption: `🎬 *Video de XNXX*`
        };
    }

    throw new Error('Plataforma no reconocida. Usá links de xvideos.com, pornhub.com o xnxx.com');
}

// ──────────────────────────────────────────────────────────────
// HELPER: verificar permisos NSFW con mensajes de error
// ──────────────────────────────────────────────────────────────
async function verifyNsfw(message, conn, chatId) {
    try {
        const { canUse } = await checkNsfwPermission(message, conn, chatId);
        if (!canUse) {
            await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
            return false;
        }
        return true;
    } catch (error) {
        if (error.message === 'NO_PERMISSIONS') {
            await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💡 Asegúrate de que el bot sea administrador del grupo.');
            return false;
        }
        throw error;
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLER UNIVERSAL: .xnxx / .xvideos / .pornhub + link o título
// ──────────────────────────────────────────────────────────────
async function universalVideoHandler(message, conn, defaultPlatform) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            const examples = {
                xnxx: '.xnxx milf  o  .xnxx https://www.xnxx.com/video-abc123/...',
                xvideos: '.xvideos milf  o  .xvideos https://www.xvideos.com/video.abc123/...',
                pornhub: '.pornhub https://www.pornhub.com/view_video.php?viewkey=abc123'
            };
            return await message.reply(`❌ Proporciona un título o link.\n\nEjemplo: ${examples[defaultPlatform]}`);
        }

        // Si es un link, detectar plataforma automáticamente
        if (arg.startsWith('http')) {
            const platform = detectPlatform(arg);
            if (!platform) {
                return await message.reply('❌ Link no reconocido. Usá links de xvideos.com, pornhub.com o xnxx.com');
            }
            await message.reply('⏳ *Descargando video...*\nPor favor, espera unos segundos.');
            const { downloadUrl, caption } = await downloadByPlatform(arg);
            const videoResponse = await axios.get(downloadUrl, { responseType: 'arraybuffer', timeout: 90000 });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            return await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
        }

        // Si es texto (título), buscar según plataforma del comando
        if (defaultPlatform === 'xvideos') {
            const searchRes = await axios.get(`https://www.robleuy.site/robleapi/buscador/xvideossearch?q=${encodeURIComponent(arg)}`);
            const searchData = searchRes.data;
            if (!searchData.ok || !searchData.videos?.length) {
                return await message.reply('❌ No se encontraron videos para ese título en Xvideos.');
            }
            const first = searchData.videos[0];
            await message.reply('⏳ *Descargando video...*\nPor favor, espera unos segundos.');
            const { downloadUrl, caption } = await downloadByPlatform(first.url);
            const videoResponse = await axios.get(downloadUrl, { responseType: 'arraybuffer', timeout: 90000 });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            return await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
        }

        if (defaultPlatform === 'xnxx' || defaultPlatform === 'pornhub') {
            // Para xnxx y pornhub buscar por xnxx (API disponible)
            const searchUrl = `https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(arg)}`;
            const searchResponse = await axios.get(searchUrl);
            const searchData = searchResponse.data;
            if (!searchData.status || !searchData.result?.length) {
                return await message.reply('❌ No se encontraron videos para ese título.');
            }
            const firstResult = searchData.result[0];
            await message.reply('⏳ *Descargando video...*\nPor favor, espera unos segundos.');
            const { downloadUrl, caption } = await downloadByPlatform(firstResult.link);
            const videoResponse = await axios.get(downloadUrl, { responseType: 'arraybuffer', timeout: 90000 });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            return await conn.sendMessage(chatId, { video: videoBuffer, caption }, { quoted: message._baileyMessage });
        }

    } catch (error) {
        console.error(`Error en handler de video:`, error);
        await message.reply('❌ Ocurrió un error al obtener o enviar el video. Intenta nuevamente.');
    }
}

// ──────────────────────────────────────────────────────────────
// HANDLER: .xnxxsearch <titulo>
// ──────────────────────────────────────────────────────────────
let handlerXnxxSearch = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (!query) return await message.reply('❌ Proporciona un título. Ejemplo: .xnxxsearch milf');

        const res = await axios.get(`https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`);
        const data = res.data;

        if (data.status && data.result?.length > 0) {
            let msg = `🔍 *Resultados para "${query}":*\n\n`;
            data.result.slice(0, 10).forEach((item, i) => {
                msg += `*${i + 1}.* ${item.title || 'Sin título'}\n`;
                msg += `⏱️ ${extractDuration(item.info)} | 🔗 ${item.link || 'N/A'}\n`;
                msg += `─────────────────\n\n`;
            });
            await message.reply(msg);
        } else {
            await message.reply('❌ No se encontraron resultados.');
        }
    } catch (error) {
        console.error('Error en xnxxsearch:', error);
        await message.reply('❌ Error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXnxxSearch.help = ['xnxxsearch <titulo>'];
handlerXnxxSearch.tags = ['videos', 'nsfw'];
handlerXnxxSearch.command = /^(xnxxsearch)$/i;

// ──────────────────────────────────────────────────────────────
// HANDLER: .xvideossearch / .xvsearch <titulo>
// ──────────────────────────────────────────────────────────────
let handlerXvideosSearch = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        if (!await verifyNsfw(message, conn, chatId)) return;

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (!query) return await message.reply('❌ Proporciona un título. Ejemplo: .xvsearch milf');

        const res = await axios.get(`https://www.robleuy.site/robleapi/buscador/xvideossearch?q=${encodeURIComponent(query)}`);
        const data = res.data;

        if (data.ok && data.videos?.length > 0) {
            let msg = `🔍 *Resultados para "${query}" en Xvideos:*\n\n`;
            data.videos.slice(0, 10).forEach((v, i) => {
                msg += `*${i + 1}.* ${v.title || 'Sin título'}\n`;
                msg += `⏱️ ${v.duration || 'N/A'} | 👤 ${v.author || 'N/A'} | 📺 ${v.quality || 'N/A'}\n`;
                msg += `🔗 ${v.url}\n`;
                msg += `─────────────────\n\n`;
            });
            await message.reply(msg);
        } else {
            await message.reply('❌ No se encontraron resultados en Xvideos.');
        }
    } catch (error) {
        console.error('Error en xvideossearch:', error);
        await message.reply('❌ Error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXvideosSearch.help = ['xvideossearch <titulo>', 'xvsearch <titulo>'];
handlerXvideosSearch.tags = ['videos', 'nsfw'];
handlerXvideosSearch.command = /^(xvideossearch|xvsearch)$/i;

// ──────────────────────────────────────────────────────────────
// HANDLERS INDIVIDUALES (delegan al universal)
// ──────────────────────────────────────────────────────────────
let handlerXnxx = async (message, { conn }) => universalVideoHandler(message, conn, 'xnxx');
handlerXnxx.help = ['xnxx <titulo o link>'];
handlerXnxx.tags = ['videos', 'nsfw'];
handlerXnxx.command = /^(xnxx)$/i;

let handlerXvideos = async (message, { conn }) => universalVideoHandler(message, conn, 'xvideos');
handlerXvideos.help = ['xvideos <titulo o link>'];
handlerXvideos.tags = ['videos', 'nsfw'];
handlerXvideos.command = /^(xvideos)$/i;

let handlerPornhub = async (message, { conn }) => universalVideoHandler(message, conn, 'pornhub');
handlerPornhub.help = ['pornhub <link>'];
handlerPornhub.tags = ['videos', 'nsfw'];
handlerPornhub.command = /^(pornhub)$/i;

// ──────────────────────────────────────────────────────────────
// EXPORTS
// ──────────────────────────────────────────────────────────────
module.exports.xnxxsearch = handlerXnxxSearch;
module.exports.xnxx = handlerXnxx;
module.exports.xvideos = handlerXvideos;
module.exports.pornhub = handlerPornhub;
module.exports.xvideossearch = handlerXvideosSearch;
module.exports.xvsearch = handlerXvideosSearch;