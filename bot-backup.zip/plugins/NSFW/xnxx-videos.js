const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Directorio de configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

// Verificar si NSFW está activado (si el grupo está en la lista)
function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

// Verificar permisos NSFW - retorna { canUse: boolean, isAdmin: boolean }
async function checkNsfwPermission(message, conn, chatId) {
    const isGroup = chatId && chatId.endsWith('@g.us');
    
    // En privado siempre permitido
    if (!isGroup) {
        return { canUse: true, isAdmin: false };
    }
    
    try {
        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // Obtener ID del usuario (mismo método que antilinks.js)
        const userJid = message.author || message.sender || message.key?.participant;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        // Buscar si el usuario es admin
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        // Si el grupo está en la lista = NSFW activado = todos pueden
        if (isNsfwEnabled(chatId)) {
            return { canUse: true, isAdmin: userIsAdmin };
        }
        
        // NSFW desactivado, solo admins pueden
        return { canUse: userIsAdmin, isAdmin: userIsAdmin };
    } catch (error) {
        // Error 403 = sin permisos para obtener metadata del grupo
        if (error?.data === 403 || error?.message?.includes('forbidden')) {
            console.log(`⚠️ Sin permisos para obtener metadata del grupo ${chatId}`);
            throw new Error('NO_PERMISSIONS');
        }
        // Otros errores, re-lanzar
        throw error;
    }
}

// Función para extraer solo la duración del campo info
function extractDuration(info) {
    if (!info) return 'N/A';
    const match = info.match(/(\d+min)/);
    return match ? match[1] : 'N/A';
}

// Handler para /xnxxsearch <titulo>
let handlerXnxxSearch = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Verificar permisos NSFW
        try {
            const { canUse } = await checkNsfwPermission(message, conn, chatId);
            if (!canUse) {
                return await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
            }
        } catch (error) {
            if (error.message === 'NO_PERMISSIONS') {
                return await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💡 Asegúrate de que el bot sea administrador del grupo.');
            }
            throw error;
        }

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const query = args.join(' ');

        if (!query) {
            return await message.reply('❌ Proporciona un título para buscar. Ejemplo: /xnxxsearch milf');
        }

        const apiUrl = `https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status && data.result && data.result.length > 0) {
            let msg = '🔍 *Resultados de búsqueda para "' + query + '":*\n\n';
            data.result.slice(0, 10).forEach((item, index) => {
                msg += `*${index + 1}.*\n`;
                msg += `📌 *Título:* ${item.title || 'Sin título'}\n`;
                msg += `⏱️ *Duración:* ${extractDuration(item.info)}\n`;
                msg += `🔗 *Link:* ${item.link || 'N/A'}\n`;
                msg += `─────────────────\n\n`;
            });
            await message.reply(msg);
        } else {
            await message.reply('❌ No se encontraron resultados para esa búsqueda.');
        }
    } catch (error) {
        console.error('Error en xnxxsearch:', error);
        await message.reply('❌ Ocurrió un error en la búsqueda. Intenta nuevamente.');
    }
};

handlerXnxxSearch.help = ['xnxxsearch <titulo>'];
handlerXnxxSearch.tags = ['videos', 'nsfw'];
handlerXnxxSearch.command = /^(xnxxsearch)$/i;

// Handler para /xnxx <titulo o link>
let handlerXnxx = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Verificar permisos NSFW
        const { canUse } = await checkNsfwPermission(message, conn, chatId);
        if (!canUse) {
            return await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
        }

        const fullText = message.text || message.body || '';
        const args = fullText.trim().split(/\s+/).slice(1);
        const arg = args.join(' ');

        if (!arg) {
            return await message.reply('❌ Proporciona un título o link. Ejemplo: /xnxx milf o /xnxx https://www.xnxx.com/video-abc123');
        }

        let videoUrl;
        if (arg.startsWith('http')) {
            const downloadApiUrl = `https://www.sankavollerei.com/download/xnxx?apikey=planaai&url=${encodeURIComponent(arg)}`;
            const downloadResponse = await axios.get(downloadApiUrl);
            const data = downloadResponse.data;
            if (data.status && data.result && data.result.files && data.result.files.low) {
                videoUrl = data.result.files.low;
            } else {
                return await message.reply('❌ No se pudo obtener el video desde ese link.');
            }
        } else {
            const searchUrl = `https://www.sankavollerei.com/search/xnxx?apikey=planaai&q=${encodeURIComponent(arg)}`;
            const searchResponse = await axios.get(searchUrl);
            const searchData = searchResponse.data;
            if (!searchData.status || !searchData.result || searchData.result.length === 0) {
                return await message.reply('❌ No se encontraron videos para ese título.');
            }
            const firstResult = searchData.result[0];
            const downloadApiUrl = `https://www.sankavollerei.com/download/xnxx?apikey=planaai&url=${encodeURIComponent(firstResult.link)}`;
            const downloadResponse = await axios.get(downloadApiUrl);
            const data = downloadResponse.data;
            if (data.status && data.result && data.result.files && data.result.files.low) {
                videoUrl = data.result.files.low;
            } else {
                return await message.reply('❌ No se pudo obtener el video del primer resultado.');
            }
        }

        await message.reply('⏳ *Buscando y descargando video...*\nPor favor, espera unos segundos.');

        const videoResponse = await axios.get(videoUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000
        });
        const videoBuffer = Buffer.from(videoResponse.data, 'binary');

        await conn.sendMessage(chatId, {
            video: videoBuffer,
            caption: '🔞 *Aquí tienes tu video.* 😏'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en xnxx:', error);
        await message.reply('❌ Ocurrió un error al obtener o enviar el video. Intenta nuevamente.');
    }
};

handlerXnxx.help = ['xnxx <titulo o link>'];
handlerXnxx.tags = ['videos', 'nsfw'];
handlerXnxx.command = /^(xnxx)$/i;

module.exports.xnxxsearch = handlerXnxxSearch;
module.exports.xnxx = handlerXnxx;