﻿const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Directorio de configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

// ðŸ”‘ Claves API de Google
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];

// ðŸ” ID del motor de bÃºsqueda (Custom Search Engine)
const GOOGLE_CX = '635e6b14f7cf84f2c';

// ðŸ• TÃ©rminos de bÃºsqueda (NSFW, con mÃ¡s Ã©nfasis en contenido explÃ­cito)
const COMIDA_TERMS = [
    'MUJERES COMPLETAMENTE DESNUDAS',
    'VAGINA DESNUDA Y PERFECTA',
    'NALGAS DE MUJERES SEXY Y DESNUDAS',
    'MUJERES NUDE CON CUERPOS PERFECTOS',
    'PACKS DE MUJERES DESNUDAS COMPLETAS CON VAGINA Y NALGAS',
    'FOTOS DE VAGINA Y NALGAS EN POSES SEXY',
    'MUJERES CON VAGINA ABIERTA Y NALGAS PERFECTAS',
    'IMÃGENES DE MUJERES TOTALMENTE DESNUDAS Y EXPLICITAS',
    'PACKS XXX DE CUERPOS PERFECTOS DESNUDOS',
    'MUJERES SEXY CON VAGINA Y NALGAS AL AIRE',
    'TETAS DESNUDAS',
    'TETAS hot Y DESNUDAS', 
    'TETAS DE MUJER DESNUDA', 
    'MUJER MOSTRANDO LAS TETAS DESNUDAS', 
    'TETAS XXX HOT', 
    'SENOS DESNUDOS Y HOT', 
    'SENOS DE MUJERES SEXY Y DESNUDAS', 
    'PECHOS GRANDES Y DESNUDOS CALIENTES', 
    'PECHOS CALIENTES DE MUJERES DESNUDAS', 
    'MUJERES DESNUDAS MOSTRANDO TETAS HOT', 
    'TETAS EN POSE SEXY Y DESNUDA', 
    'TETAS XXX HOT Y DESNUDAS', 
    'SENOS EROTICOS Y DESNUDOS CALIENTES', 
    'MUJERES CON TETAS GRATIS Y DESNUDAS HOT', 
    'TETAS DE PORNO DESNUDAS', 
    'TETAS CALIENTES Y SEXY DESNUDAS', 
    'SENOS DE ESTRELLAS PORNO DESNUDAS', 
    'MUJERES HOT CON TETAS GRANDES Y DESNUDAS', 
    'TETAS EN FOTOS HOT Y DESNUDAS',
    'PECHOS DE MUJERES ATRACTIVAS Y DESNUDAS SEXY',
    'MUJERES HERMOSAS DESNUDAS COMPLETAS', 
    'PACKS DE MUJERES DESNUDAS CON TETAS VAGINA COLA', 
    'MUJERES SEXY DESNUDAS TODO AL AIRE', 
    'MUJERES DESNUDAS CON TODO VISIBLE', 
    'PACKS XXX DE MUJERES HERMOSAS DESNUDAS', 
    'MUJERES CALIENTES CON TETAS VAGINA Y COLA', 
    'FOTOS DE MUJERES DESNUDAS TOTALES', 
    'PACKS DE MUJERES NUDE CON TODO', 
    'MUJERES HERMOSAS DESNUDAS Y EXPLICITAS', 
    'MUJERES CON VAGINA TETAS Y COLA AL DESCUBIERTO', 
    'PACKS HOT DE MUJERES DESNUDAS COMPLETAS', 
    'MUJERES SEXY CON TODO EXPUESTO', 
    'FOTOS XXX DE MUJERES DESNUDAS', 
    'MUJERES DESNUDAS CON PACKS DE TODO TIPO', 
    'PACKS DE MUJERES HERMOSAS CON VAGINA Y TETAS', 
    'MUJERES CALIENTES DESNUDAS CON COLA VISIBLE', 
    'MUJERES NUDE COMPLETAS Y EXPLICITAS', 
    'PACKS DE FOTOS DE MUJERES CON TODO', 
    'MUJERES DESNUDAS HERMOSAS CON DETALLES EXPLICITOS', 
    'FOTOS DE MUJERES SEXY CON TETAS VAGINA Y COLA'
];

// ðŸ§  Cache simple + delay para evitar exceso de peticiones
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Palabras clave explÃ­citas actualizadas (mÃ¡s enfocadas en tu solicitud)
const explicitKeywords = [
    'hot', 'sexy', 'desnuda', 'caliente', 'xxx', 'erotic', 'desnudo', 'packs',
    'vagina', 'nalgas', 'perfectas', 'completas', 'nude', 'totalmente desnudas',
    'cuerpos perfectos', 'abierta', 'expuestas', 'explicitas'
];

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

// Verificar si NSFW estÃ¡ activado (si el grupo estÃ¡ en la lista)
function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

async function buscarImagen(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];

    // Usa cache si ya existe una imagen para ese tÃ©rmino
    if (imageCache.has(randomTerm)) return imageCache.get(randomTerm);
    if (keyIndex >= GOOGLE_API_KEYS.length) return null;

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=off`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => 
                item.link && item.mime && item.mime.startsWith('image/') &&
                explicitKeywords.some(keyword => 
                    item.title?.toLowerCase().includes(keyword) || 
                    item.snippet?.toLowerCase().includes(keyword)
                )
            );
            if (validImages.length > 0) {
                const randomImage = validImages[Math.floor(Math.random() * validImages.length)];
                imageCache.set(randomTerm, randomImage.link);
                return randomImage.link;
            }
        }
    } catch (error) {
        // Si la API key se agota, pasa a la siguiente
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`âš ï¸ Clave de API agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarImagen(termsArray, keyIndex + 1, retries - 1);
        }
        console.error('Error en la bÃºsqueda de imÃ¡genes:', error.message);
    }

    return null;
}

// ðŸ” Handler principal del comando /hotgirl
let handlerComida = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Verificar si el mensaje proviene del grupo bloqueado
        if (chatId === GRUPO_BLOQUEADO) {
            return await message.reply('âŒ Este comando no estÃ¡ disponible en este grupo.');
        }
        
        // Verificar si es un grupo
        const isGroup = chatId && chatId.endsWith('@g.us');
        
        // Si es grupo, verificar permisos NSFW
        if (isGroup) {
            try {
                // Obtener metadata del grupo
                const groupMetadata = await conn.groupMetadata(chatId);
                const participants = groupMetadata.participants;
                
                // Obtener ID del usuario (mismo mÃ©todo que antilinks.js)
                const userJid = message.author || message.sender || message.key?.participant;
                const userNumber = userJid.split('@')[0].split(':')[0];
                
                // Buscar si el usuario es admin
                const userParticipant = participants.find(p => {
                    const participantNumber = p.id.split('@')[0].split(':')[0];
                    return participantNumber === userNumber;
                });
                
                const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                
                // Si el grupo NO estÃ¡ en la lista = NSFW desactivado
                if (!isNsfwEnabled(chatId)) {
                    // Si NO es admin, bloquear
                    if (!userIsAdmin) {
                        return await message.reply('ðŸ”’ *NSFW Desactivado*\n\nEl contenido NSFW estÃ¡ desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\nðŸ’¡ Un admin puede activarlo con: .nsfw on');
                    }
                }
                // Si estÃ¡ en la lista = NSFW activado, todos pueden usar
            } catch (error) {
                // Error 403 = sin permisos para obtener metadata del grupo
                if (error?.data === 403 || error?.message?.includes('forbidden')) {
                    console.log(`âš ï¸ Sin permisos para obtener metadata del grupo ${chatId}`);
                    return await message.reply('âš ï¸ El bot no tiene permisos suficientes en este grupo.\n\nðŸ’¡ AsegÃºrate de que el bot sea administrador del grupo.');
                }
                // Otros errores, re-lanzar
                throw error;
            }
        }

        const imageUrl = await buscarImagen(COMIDA_TERMS);
        if (!imageUrl) return message.reply('âŒ No se encontraron imÃ¡genes explÃ­citas. Intenta de nuevo mÃ¡s tarde.');

        // Descargar imagen
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // Enviar al chat como respuesta
        await conn.sendMessage(chatId, {
            image: imageBuffer,
            caption: 'ðŸ¥µðŸ¥µ'
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /hotgirl:', error);
        await message.reply('âŒ OcurriÃ³ un error al obtener la imagen. Intenta de nuevo mÃ¡s tarde.');
    }
};

// ðŸ“¦ ExportaciÃ³n del comando
handlerComida.command = /^hotgirl|girls/i;
handlerComida.help = ['hotgirl|girls'];
handlerComida.tags = ['fun', 'nsfw'];

module.exports = handlerComida;

