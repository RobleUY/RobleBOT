const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Directorio de configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

function isNsfwEnabled(groupJid, sock) {
    if (sock && sock._subNum) {
        try {
            const subBotModule = require('../SUBBOTS/subbots-onoff.js');
            if (typeof subBotModule.isSubBotNsfwEnabled === 'function') {
                if (!subBotModule.isSubBotNsfwEnabled(sock._subNum)) return false;
            }
        } catch (_) {}
    }
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

// 🖼️ Fetch imagen desde Delirius girls
async function fetchDeliriusGirls() {
    const res = await axios.get('https://api.delirius.online/nsfw/girls', {
        responseType: 'arraybuffer',
        timeout: 15000
    });
    return Buffer.from(res.data);
}

// 🎬 Fetch video desde Delirius tiktok
async function fetchDeliriusTiktok() {
    const res = await axios.get('https://api.delirius.online/nsfw/tiktok', {
        responseType: 'arraybuffer',
        timeout: 20000
    });
    return Buffer.from(res.data);
}

// 🔍 Handler del comando .hotgirl / .girls
let handlerComida = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;

        if (chatId === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }

        const isGroup = chatId && chatId.endsWith('@g.us');

        if (isGroup) {
            try {
                const groupMetadata = await conn.groupMetadata(chatId);
                const participants = groupMetadata.participants;

                const userJid = message.author || message.sender || message.key?.participant;
                const userNumber = userJid.split('@')[0].split(':')[0];

                const userParticipant = participants.find(p => {
                    const participantNumber = p.id.split('@')[0].split(':')[0];
                    return participantNumber === userNumber;
                });

                const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');

                if (!isNsfwEnabled(chatId, conn || message?._sock)) {
                    if (!userIsAdmin) {
                        return await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💥 Un admin puede activarlo con: .nsfw on');
                    }
                }
            } catch (error) {
                if (error?.data === 403 || error?.message?.includes('forbidden')) {
                    return await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💥 Asegúrate de que el bot sea administrador del grupo.');
                }
                throw error;
            }
        }

        await message.reply('Enviando... 🥵');

        // 🎲 50/50: imagen o video
        const elegirVideo = Math.random() < 0.5;

        if (elegirVideo) {
            // 🎬 Video desde tiktok de Delirius
            const videoBuffer = await fetchDeliriusTiktok();
            await conn.sendMessage(chatId, {
                video: videoBuffer,
                caption: '🥵🥵',
                gifPlayback: false
            }, { quoted: message._baileyMessage });
        } else {
            // 🖼️ Imagen desde girls de Delirius
            const imageBuffer = await fetchDeliriusGirls();
            await conn.sendMessage(chatId, {
                image: imageBuffer,
                caption: '🥵🥵'
            }, { quoted: message._baileyMessage });
        }

    } catch (error) {
        console.error('Error en .hotgirl:', error);
        await message.reply('❌ Ocurrió un error al obtener el contenido. Intenta de nuevo más tarde.');
    }
};

handlerComida.command = /^hotgirl|girls/i;
handlerComida.help = ['hotgirl|girls'];
handlerComida.tags = ['fun', 'nsfw'];

module.exports = handlerComida;
