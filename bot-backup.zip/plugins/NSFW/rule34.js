const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Directorio de configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// ID del grupo donde NO debe funcionar
const GRUPO_BLOQUEADO = '120363203689229697@g.us';

// Array de claves API
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];

const GOOGLE_CX = '635e6b14f7cf84f2c';

// Cache simple para resultados frecuentes (ahora almacena arrays de links para variar)
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

// Verificar si NSFW está activado (si el grupo está en la lista)
function isNsfwEnabled(groupJid, sock) {
    if (sock && sock._subNum) {
        try {
            const subBotModule = require('../SUBBOTS/subbots-onoff.js');
            if (typeof subBotModule.isSubBotNsfwEnabled === 'function') {
                if (!subBotModule.isSubBotNsfwEnabled(sock._subNum)) return false;
            }
        } catch (_) {}
    }
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

async function buscarImagenGoogle(text, keyIndex = 0, retries = 3) {
    if (imageCache.has(text)) {
        const cachedLinks = imageCache.get(text);
        if (cachedLinks.length > 0) {
            return cachedLinks[Math.floor(Math.random() * cachedLinks.length)];
        }
    }

    if (keyIndex >= GOOGLE_API_KEYS.length) return null;

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(text)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5`;

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => item.fileFormat && item.fileFormat.startsWith('image/'));
            if (validImages.length > 0) {
                const links = validImages.map(item => item.link);
                imageCache.set(text, links);
                return links[Math.floor(Math.random() * links.length)];
            }
        }
    } catch (error) {
        if (error.response) {
            if ((error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
                console.warn(`Clave actual agotada o 429. Probando siguiente clave... (${GOOGLE_API_KEYS[keyIndex]})`);
                await sleep(2000);
                return buscarImagenGoogle(text, keyIndex + 1, 3);
            } else {
                console.error('Error HTTP:', error.response.status, error.response.data);
            }
        } else {
            console.error('Error al buscar imagen en Google:', error.message);
        }
    }

    return null;
}

// ============================
// COMANDO .rule34 o .r34
// ============================

let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Verificar si el mensaje proviene del grupo bloqueado
        if (chatId === GRUPO_BLOQUEADO) {
            return await message.reply('❌ Este comando no está disponible en este grupo.');
        }
        
        // Verificar si es un grupo
        const isGroup = chatId && chatId.endsWith('@g.us');
        
        // Si es grupo, verificar permisos NSFW
        if (isGroup) {
            try {
                // Obtener metadata del grupo
                const groupMetadata = await conn.groupMetadata(chatId);
                const participants = groupMetadata.participants;
                
                // Obtener ID del usuario (mismo método que antilinks.js)
                const userJid = message.author || message.sender || message.key?.participant;
                const userNumber = userJid.split('@')[0].split(':')[0];
                
                // Buscar si el usuario es admin
                const userParticipant = participants.find(p => {
                    const participantNumber = p.id.split('@')[0].split(':')[0];
                    return participantNumber === userNumber;
                });
                
                const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                
                // Si el grupo NO está en la lista = NSFW desactivado
                if (!isNsfwEnabled(chatId, sock)) {
                    // Si NO es admin, bloquear
                    if (!userIsAdmin) {
                        return await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
                    }
                }
                // Si está en la lista = NSFW activado, todos pueden usar
            } catch (error) {
                // Error 403 = sin permisos para obtener metadata del grupo
                if (error?.data === 403 || error?.message?.includes('forbidden')) {
                    console.log(`⚠️ Sin permisos para obtener metadata del grupo ${chatId}`);
                    return await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💡 Asegúrate de que el bot sea administrador del grupo.');
                }
                // Otros errores, re-lanzar
                throw error;
            }
        }

        if (!text) return await message.reply('❌ Debes escribir algo. Ejemplo: .rule34 Dora La Exploradora');

        // TEXTO ESPECIAL FIJO:
        const textoFinal = `Sin censura RULE 34 ${text}`;

        const imageUrl = await buscarImagenGoogle(textoFinal);
        if (!imageUrl) return await message.reply('❌ No se encontraron imágenes o se agotaron las claves API.');

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await sock.sendMessage(
            message.from,
            {
                image: imageBuffer,
                caption: `🥵`
            },
            { quoted: message._baileyMessage }
        );

    } catch (error) {
        console.error('Error en el comando .rule34:', error);
        return await message.reply('❌ Error al procesar la imagen.');
    }
};

handler.help = ['rule34 <texto>', 'r34 <texto>'];
handler.tags = ['imagenes', 'busqueda'];
handler.command = /^r34|rule34$/i;

module.exports = handler;
