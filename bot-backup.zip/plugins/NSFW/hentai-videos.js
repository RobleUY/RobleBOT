const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Directorio de configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

// Verificar si NSFW está activado (si el grupo está en la lista)
function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

let handlerHentaiv = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Verificar si es un grupo
        const isGroup = chatId && chatId.endsWith('@g.us');
        
        // Si es grupo, verificar permisos NSFW
        if (isGroup) {
            // Obtener metadata del grupo
            const groupMetadata = await conn.groupMetadata(chatId);
            const participants = groupMetadata.participants;
            
            // Obtener ID del usuario (mismo método que antilinks.js)
            const userJid = message.author || message.sender || message.key?.participant;
            const userNumber = userJid.split('@')[0].split(':')[0];
            
            // Buscar si el usuario es admin
            const userParticipant = participants.find(p => {
                const participantNumber = p.id.split('@')[0].split(':')[0];
                return participantNumber === userNumber;
            });
            
            const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
            
            // Si el grupo NO está en la lista = NSFW desactivado
            if (!isNsfwEnabled(chatId)) {
                // Si NO es admin, bloquear
                if (!userIsAdmin) {
                    return await message.reply('🔒 *NSFW Desactivado*\n\nEl contenido NSFW está desactivado en este grupo.\n\n_Solo los administradores pueden usar estos comandos._\n\n💡 Un admin puede activarlo con: .nsfw on');
                }
            }
            // Si está en la lista = NSFW activado, todos pueden usar
        }

        const apiUrl = 'https://delirius-apiofc.vercel.app/anime/hentaivid';
        
        // Mensaje inicial de descarga
        await message.reply('⏳ *Buscando y descargando video...*\nPor favor, espera unos segundos.');
        
        const response = await axios.get(apiUrl);
        const videos = response.data;
        
        if (videos && videos.length > 0) {
            const randomIndex = Math.floor(Math.random() * videos.length);
            const randomVideo = videos[randomIndex];
            const videoUrl = randomVideo.video_1;
            
            // Descargar el video
            const videoResponse = await axios.get(videoUrl, { 
                responseType: 'arraybuffer',
                timeout: 60000
            });
            const videoBuffer = Buffer.from(videoResponse.data, 'binary');
            
            // Enviar el video
            await conn.sendMessage(chatId, {
                video: videoBuffer,
                caption: '🔞 *Aquí tienes tu video de hentai.* 😏'
            }, { quoted: message._baileyMessage });
            
        } else {
            await message.reply('❌ No se encontraron videos disponibles en la API.');
        }
    } catch (error) {
        console.error('Error en el comando hentaiv:', error);
        return await message.reply('❌ Ocurrió un error al obtener o enviar el video. Intenta nuevamente más tarde.');
    }
};

handlerHentaiv.help = ['hentaiv'];
handlerHentaiv.tags = ['videos', 'nsfw'];
handlerHentaiv.command = /^(hentaiv)$/i;

module.exports = handlerHentaiv;