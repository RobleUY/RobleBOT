const axios = require('axios');
const fs = require('fs');
const path = require('path');

const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

let handlerHentaiv = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        const isGroup = chatId && chatId.endsWith('@g.us');
        
        // ✅ Verificación NSFW en grupos
        if (isGroup) {
            try {
                const groupMetadata = await conn.groupMetadata(chatId);
                const participants = groupMetadata.participants;
                const userJid = message.author || message.sender || message.key?.participant;
                const userNumber = userJid?.split('@')[0]?.split(':')[0];
                
                if (userNumber) {
                    const userParticipant = participants.find(p => {
                        const participantNumber = p.id.split('@')[0].split(':')[0];
                        return participantNumber === userNumber;
                    });
                    
                    const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                    
                    if (!isNsfwEnabled(chatId) && !userIsAdmin) {
                        return message.reply('🔒 *NSFW Desactivado*\n\nSolo administradores pueden usar este comando.\n\n💡 `.nsfw on` para activar.');
                    }
                }
            } catch (e) {
                // Error 403 = sin permisos para obtener metadata del grupo
                if (e?.data === 403 || e?.message?.includes('forbidden')) {
                    console.log(`⚠️ Sin permisos para obtener metadata del grupo ${chatId}`);
                    return await message.reply('⚠️ El bot no tiene permisos suficientes en este grupo.\n\n💡 Asegúrate de que el bot sea administrador del grupo.');
                }
                console.log('⚠️ Skip grupo check:', e.message);
            }
        }

        // 🎬 Mensaje inicial
        await message.reply('⏳ *Buscando video hentai aleatorio...*');
        
        // 🌐 API Request
        const apiUrl = 'https://api.delirius.store/anime/hentaivid';
        const response = await axios.get(apiUrl, { 
            timeout: 20000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        const videos = response.data;
        
        // 🛡️ Validaciones estrictas
        if (!Array.isArray(videos) || videos.length === 0) {
            return message.reply('❌ *Sin videos disponibles*\nIntenta en unos minutos.');
        }
        
        // 🎲 Video aleatorio
        const randomVideo = videos[Math.floor(Math.random() * videos.length)];
        const videoUrl = randomVideo?.video_1;
        
        if (!videoUrl) {
            return message.reply('❌ *Error de video*\nNo se encontró URL válida.');
        }
        
        // 📥 Progreso descarga
        await message.reply('📥 *Descargando video NSFW...*\n⏳ Espera 30-60 segundos');
        
        console.log(`🔍 Debug - chatId: ${chatId}`);
        console.log(`🔍 Debug - videoUrl: ${videoUrl}`);
        
        // 💾 Descargar video
        const videoResponse = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        const videoBuffer = Buffer.from(videoResponse.data);
        
        // 📏 Verificar tamaño (WhatsApp: 50MB)
        const sizeMB = (videoBuffer.length / (1024 * 1024)).toFixed(1);
        console.log(`📦 Video descargado: ${sizeMB}MB`);
        
        if (videoBuffer.length > 50 * 1024 * 1024) {
            return message.reply(`❌ *Video muy grande*\n📏 ${sizeMB}MB (máx 50MB)`);
        }
        
        // 🎥 Caption optimizado
        const caption = `🔞 *${randomVideo.title || 'Hentai Video'}*
╭─❑「 ${randomVideo.category || 'NSFW'} 」
├─ 👀 ${randomVideo.views_count || 'N/A'}
├─ 📤 ${randomVideo.share_count || 'N/A'}
╰─ 🔗 ${randomVideo.link || 'sfmcompile.club'}

😈 *¡Disfruta tu hentai!*`;

        // 🚀 Enviar video - Corregido para evitar el error
        try {
            // Intentar con diferentes formatos de quoted
            let quotedMessage = null;
            if (message._baileyMessage) {
                quotedMessage = message._baileyMessage;
            } else if (message.key) {
                quotedMessage = message;
            }
            
            if (quotedMessage) {
                await sock.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                }, { quoted: quotedMessage });
            } else {
                await sock.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                });
            }
            
            console.log(`✅ hentaiv OK: ${randomVideo.title} (${sizeMB}MB)`);
            
        } catch (sendError) {
            console.error('Error sendMessage [1]:', sendError.message);
            
            // Intentar envío sin quoted
            try {
                await sock.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                });
                console.log(`✅ hentaiv OK (sin quoted): ${randomVideo.title} (${sizeMB}MB)`);
                
            } catch (fallbackError) {
                console.error('Error sendMessage [2]:', fallbackError.message);
                
                // Último intento: solo el video sin caption
                try {
                    await sock.sendMessage(chatId, { video: videoBuffer });
                    await message.reply(caption);
                    console.log(`✅ hentaiv OK (separado): ${randomVideo.title} (${sizeMB}MB)`);
                    
                } catch (finalError) {
                    console.error('Error sendMessage [3]:', finalError.message);
                    return message.reply('❌ *Error al enviar video*\nIntenta de nuevo.');
                }
            }
        }
        
    } catch (error) {
        console.error('hentaiv ERROR:', error.message);
        
        let errorMsg = '❌ *Error al procesar*';
        
        if (error.code === 'ECONNABORTED') {
            errorMsg = '⏰ *Timeout*\nLa conexión tardó demasiado.';
        } else if (error.response?.status === 404) {
            errorMsg = '❌ *API caída*';
        } else if (error.response?.status === 429) {
            errorMsg = '🚫 *Rate limit* - Espera 1 min';
        } else if (error.message.includes('ENOTFOUND')) {
            errorMsg = '🌐 *Sin internet*';
        }
        
        await message.reply(`${errorMsg}\n\n*Intenta de nuevo en unos segundos.*`);
    }
};

handlerHentaiv.help = ['hentaiv', 'hentai'];
handlerHentaiv.tags = ['nsfw', 'videos', 'hentai'];
handlerHentaiv.command = /^(hentaiv|hentai)$/i;
handlerHentaiv.nsfw = true;

module.exports = handlerHentaiv;
