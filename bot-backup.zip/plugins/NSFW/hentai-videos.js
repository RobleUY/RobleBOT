﻿const axios = require('axios');
const fs = require('fs');
const path = require('path');

const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

let handlerHentaiv = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        const isGroup = chatId && chatId.endsWith('@g.us');
        
        // âœ… VerificaciÃ³n NSFW en grupos
        if (isGroup) {
            try {
                const groupMetadata = await conn.groupMetadata(chatId);
                const participants = groupMetadata.participants;
                const userJid = message.author || message.sender || message.key?.participant;
                const userNumber = userJid?.split('@')[0]?.split(':')[0];
                
                if (userNumber) {
                    const userParticipant = participants.find(p => {
                        const participantNumber = p.id.split('@')[0].split(':')[0];
                        return participantNumber === userNumber;
                    });
                    
                    const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
                    
                    if (!isNsfwEnabled(chatId) && !userIsAdmin) {
                        return message.reply('ðŸ”’ *NSFW Desactivado*\n\nSolo administradores pueden usar este comando.\n\nðŸ’¡ `.nsfw on` para activar.');
                    }
                }
            } catch (e) {
                // Error 403 = sin permisos para obtener metadata del grupo
                if (e?.data === 403 || e?.message?.includes('forbidden')) {
                    console.log(`âš ï¸ Sin permisos para obtener metadata del grupo ${chatId}`);
                    return await message.reply('âš ï¸ El bot no tiene permisos suficientes en este grupo.\n\nðŸ’¡ AsegÃºrate de que el bot sea administrador del grupo.');
                }
                console.log('âš ï¸ Skip grupo check:', e.message);
            }
        }

        // ðŸŽ¬ Mensaje inicial
        await message.reply('â³ *Buscando video hentai aleatorio...*');
        
        // ðŸŒ API Request
        const apiUrl = 'https://api.delirius.store/anime/hentaivid';
        const response = await axios.get(apiUrl, { 
            timeout: 20000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        const videos = response.data;
        
        // ðŸ›¡ï¸ Validaciones estrictas
        if (!Array.isArray(videos) || videos.length === 0) {
            return message.reply('âŒ *Sin videos disponibles*\nIntenta en unos minutos.');
        }
        
        // ðŸŽ² Video aleatorio
        const randomVideo = videos[Math.floor(Math.random() * videos.length)];
        const videoUrl = randomVideo?.video_1;
        
        if (!videoUrl) {
            return message.reply('âŒ *Error de video*\nNo se encontrÃ³ URL vÃ¡lida.');
        }
        
        // ðŸ“¥ Progreso descarga
        await message.reply('ðŸ“¥ *Descargando video NSFW...*\nâ³ Espera 30-60 segundos');
        
        console.log(`ðŸ” Debug - chatId: ${chatId}`);
        console.log(`ðŸ” Debug - videoUrl: ${videoUrl}`);
        
        // ðŸ’¾ Descargar video
        const videoResponse = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        const videoBuffer = Buffer.from(videoResponse.data);
        
        // ðŸ“ Verificar tamaÃ±o (WhatsApp: 50MB)
        const sizeMB = (videoBuffer.length / (1024 * 1024)).toFixed(1);
        console.log(`ðŸ“¦ Video descargado: ${sizeMB}MB`);
        
        if (videoBuffer.length > 50 * 1024 * 1024) {
            return message.reply(`âŒ *Video muy grande*\nðŸ“ ${sizeMB}MB (mÃ¡x 50MB)`);
        }
        
        // ðŸŽ¥ Caption optimizado
        const caption = `ðŸ”ž *${randomVideo.title || 'Hentai Video'}*
â•­â”€â‘ã€Œ ${randomVideo.category || 'NSFW'} ã€
â”œâ”€ ðŸ‘€ ${randomVideo.views_count || 'N/A'}
â”œâ”€ ðŸ“¤ ${randomVideo.share_count || 'N/A'}
â•°â”€ ðŸ”— ${randomVideo.link || 'sfmcompile.club'}

ðŸ˜ˆ *Â¡Disfruta tu hentai!*`;

        // ðŸš€ Enviar video - Corregido para evitar el error
        try {
            // Intentar con diferentes formatos de quoted
            let quotedMessage = null;
            if (message._baileyMessage) {
                quotedMessage = message._baileyMessage;
            } else if (message.key) {
                quotedMessage = message;
            }
            
            if (quotedMessage) {
                await conn.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                }, { quoted: quotedMessage });
            } else {
                await conn.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                });
            }
            
            console.log(`âœ… hentaiv OK: ${randomVideo.title} (${sizeMB}MB)`);
            
        } catch (sendError) {
            console.error('Error sendMessage [1]:', sendError.message);
            
            // Intentar envÃ­o sin quoted
            try {
                await conn.sendMessage(chatId, { 
                    video: videoBuffer, 
                    caption: caption 
                });
                console.log(`âœ… hentaiv OK (sin quoted): ${randomVideo.title} (${sizeMB}MB)`);
                
            } catch (fallbackError) {
                console.error('Error sendMessage [2]:', fallbackError.message);
                
                // Ãšltimo intento: solo el video sin caption
                try {
                    await conn.sendMessage(chatId, { video: videoBuffer });
                    await message.reply(caption);
                    console.log(`âœ… hentaiv OK (separado): ${randomVideo.title} (${sizeMB}MB)`);
                    
                } catch (finalError) {
                    console.error('Error sendMessage [3]:', finalError.message);
                    return message.reply('âŒ *Error al enviar video*\nIntenta de nuevo.');
                }
            }
        }
        
    } catch (error) {
        console.error('hentaiv ERROR:', error.message);
        
        let errorMsg = 'âŒ *Error al procesar*';
        
        if (error.code === 'ECONNABORTED') {
            errorMsg = 'â° *Timeout*\nLa conexiÃ³n tardÃ³ demasiado.';
        } else if (error.response?.status === 404) {
            errorMsg = 'âŒ *API caÃ­da*';
        } else if (error.response?.status === 429) {
            errorMsg = 'ðŸš« *Rate limit* - Espera 1 min';
        } else if (error.message.includes('ENOTFOUND')) {
            errorMsg = 'ðŸŒ *Sin internet*';
        }
        
        await message.reply(`${errorMsg}\n\n*Intenta de nuevo en unos segundos.*`);
    }
};

handlerHentaiv.help = ['hentaiv', 'hentai'];
handlerHentaiv.tags = ['nsfw', 'videos', 'hentai'];
handlerHentaiv.command = /^(hentaiv|hentai)$/i;
handlerHentaiv.nsfw = true;

module.exports = handlerHentaiv;

