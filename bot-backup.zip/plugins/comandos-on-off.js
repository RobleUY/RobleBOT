const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones (mismo que bot-on-off)
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const COMANDOS_STATUS_FILE = path.join(GRUPOS_DIR, 'comandos-on-off.json');

// Asegurar que el directorio existe
if (!fs.existsSync(GRUPOS_DIR)) {
    fs.mkdirSync(GRUPOS_DIR, { recursive: true });
}

// Cargar configuración de comandos
function loadComandosConfig() {
    try {
        if (fs.existsSync(COMANDOS_STATUS_FILE)) {
            const data = fs.readFileSync(COMANDOS_STATUS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando comandos-on-off.json:', error.message);
    }
    return {};
}

// Guardar configuración de comandos
function saveComandosConfig(config) {
    try {
        fs.writeFileSync(COMANDOS_STATUS_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando comandos-on-off.json:', error.message);
        return false;
    }
}

/**
 * Verificar el estado de un comando en un grupo
 * @param {string} groupJid - JID del grupo
 * @param {string} commandName - Nombre del comando
 * @returns {true|false|'admins'} - true = habilitado, false = deshabilitado, 'admins' = solo admins
 */
function isCommandEnabled(groupJid, commandName) {
    const config = loadComandosConfig();
    const cleanJid = groupJid.split('@')[0];
    const normalizedCmd = commandName.toLowerCase().trim();
    
    // Si no hay configuración para este grupo, el comando está habilitado
    if (!config[cleanJid]) return true;
    
    // Si no hay configuración para este comando, está habilitado
    const cmdStatus = config[cleanJid][normalizedCmd];
    if (cmdStatus === undefined) return true;
    
    // Retornar el estado
    if (cmdStatus === false) return false;
    if (cmdStatus === 'admins') return 'admins';
    return true;
}

/**
 * Establecer el estado de un comando en un grupo
 * @param {string} groupJid - JID del grupo
 * @param {string} commandName - Nombre del comando
 * @param {string} mode - 'on', 'off', 'admins'
 * @returns {boolean} - true si se guardó correctamente
 */
function setCommandStatus(groupJid, commandName, mode) {
    const config = loadComandosConfig();
    const cleanJid = groupJid.split('@')[0];
    const normalizedCmd = commandName.toLowerCase().trim();
    
    // Inicializar objeto del grupo si no existe
    if (!config[cleanJid]) {
        config[cleanJid] = {};
    }
    
    if (mode === 'on' || mode === true) {
        // Si se activa, eliminamos la entrada
        delete config[cleanJid][normalizedCmd];
        // Si el grupo queda vacío, eliminamos el grupo
        if (Object.keys(config[cleanJid]).length === 0) {
            delete config[cleanJid];
        }
    } else if (mode === 'admins') {
        config[cleanJid][normalizedCmd] = 'admins';
    } else if (mode === 'off' || mode === false) {
        config[cleanJid][normalizedCmd] = false;
    }
    
    return saveComandosConfig(config);
}

/**
 * Obtener lista de comandos desactivados/restringidos en un grupo
 * @param {string} groupJid - JID del grupo
 * @returns {object} - { off: [], admins: [] }
 */
function getDisabledCommands(groupJid) {
    const config = loadComandosConfig();
    const cleanJid = groupJid.split('@')[0];
    
    const result = { off: [], admins: [] };
    
    if (!config[cleanJid]) return result;
    
    for (const [cmd, status] of Object.entries(config[cleanJid])) {
        if (status === false) {
            result.off.push(cmd);
        } else if (status === 'admins') {
            result.admins.push(cmd);
        }
    }
    
    return result;
}

// Comandos que NO se pueden desactivar (protegidos)
const PROTECTED_COMMANDS = [
    'bot', 'offcomando', 'oncomando', 'comandooff', 'comandoon',
    'menu', 'help', 'owner'
];

function isProtectedCommand(cmd) {
    return PROTECTED_COMMANDS.includes(cmd.toLowerCase().trim());
}

// ==================== HANDLER DEL COMANDO ====================

let handler = async (message, { args, conn, usedPrefix }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // Verificación de permisos del Usuario
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && 
            (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener el texto del mensaje para determinar la acción
        const bodyText = message.body || '';
        const commandUsed = bodyText.split(/\s+/)[0].toLowerCase().replace(/^[./#!]/, '');
        
        // Determinar la acción basada en el comando usado
        let action;
        if (['offcomando', 'comandooff'].includes(commandUsed)) {
            action = 'off';
        } else if (['oncomando', 'comandoon'].includes(commandUsed)) {
            action = 'on';
        } else if (['adminscomando', 'comandoadmins'].includes(commandUsed)) {
            action = 'admins';
        } else if (['listacomandos', 'comandosoff'].includes(commandUsed)) {
            action = 'list';
        }

        // Si es listar comandos desactivados
        if (action === 'list') {
            const disabled = getDisabledCommands(chatId);
            
            if (disabled.off.length === 0 && disabled.admins.length === 0) {
                return await message.reply('✅ No hay comandos desactivados o restringidos en este grupo.');
            }
            
            let texto = '📋 *COMANDOS RESTRINGIDOS EN ESTE GRUPO*\n\n';
            
            if (disabled.off.length > 0) {
                texto += '🔴 *Desactivados:*\n';
                disabled.off.forEach(cmd => {
                    texto += `   • ${usedPrefix}${cmd}\n`;
                });
                texto += '\n';
            }
            
            if (disabled.admins.length > 0) {
                texto += '🟡 *Solo Admins:*\n';
                disabled.admins.forEach(cmd => {
                    texto += `   • ${usedPrefix}${cmd}\n`;
                });
            }
            
            return await message.reply(texto);
        }

        // Verificar que se proporcionó un comando
        if (args.length === 0) {
            let texto = '📌 *GESTIÓN DE COMANDOS*\n\n';
            texto += '💡 *Uso:*\n';
            texto += `   • ${usedPrefix}offcomando <comando> - Desactivar\n`;
            texto += `   • ${usedPrefix}oncomando <comando> - Activar\n`;
            texto += `   • ${usedPrefix}adminscomando <comando> - Solo admins\n`;
            texto += `   • ${usedPrefix}listacomandos - Ver restringidos\n\n`;
            texto += `📝 *Ejemplo:*\n`;
            texto += `   ${usedPrefix}offcomando apostar\n`;
            texto += `   ${usedPrefix}adminscomando ban\n`;
            texto += `   ${usedPrefix}oncomando apostar`;
            return await message.reply(texto);
        }

        // Obtener el nombre del comando a modificar
        let targetCommand = args[0].toLowerCase().trim();
        
        // Remover prefijo si lo tiene
        if (targetCommand.startsWith('.') || targetCommand.startsWith('/') || 
            targetCommand.startsWith('#') || targetCommand.startsWith('!')) {
            targetCommand = targetCommand.slice(1);
        }

        // Verificar si es un comando protegido
        if (isProtectedCommand(targetCommand)) {
            return await message.reply(`❌ El comando *${usedPrefix}${targetCommand}* está protegido y no puede ser desactivado.`);
        }

        // Obtener estado actual
        const currentStatus = isCommandEnabled(chatId, targetCommand);

        // Aplicar cambio
        if (setCommandStatus(chatId, targetCommand, action)) {
            let emoji, statusText, mensaje;
            
            if (action === 'off') {
                emoji = '🔴';
                statusText = 'DESACTIVADO';
                mensaje = `${emoji} *Comando ${statusText}*\n\n`;
                mensaje += `📌 Comando: *${usedPrefix}${targetCommand}*\n`;
                mensaje += `📊 Estado: Desactivado para todos\n\n`;
                mensaje += `ℹ️ Nadie podrá usar este comando en el grupo.\n`;
                mensaje += `💡 Para reactivarlo: *${usedPrefix}oncomando ${targetCommand}*`;
            } else if (action === 'on') {
                emoji = '🟢';
                statusText = 'ACTIVADO';
                mensaje = `${emoji} *Comando ${statusText}*\n\n`;
                mensaje += `📌 Comando: *${usedPrefix}${targetCommand}*\n`;
                mensaje += `📊 Estado: Habilitado para todos\n\n`;
                mensaje += `ℹ️ Todos los miembros pueden usar este comando.`;
            } else if (action === 'admins') {
                emoji = '🟡';
                statusText = 'SOLO ADMINS';
                mensaje = `${emoji} *Comando en modo ${statusText}*\n\n`;
                mensaje += `📌 Comando: *${usedPrefix}${targetCommand}*\n`;
                mensaje += `📊 Estado: Solo administradores\n\n`;
                mensaje += `ℹ️ Solo los admins pueden usar este comando.\n`;
                mensaje += `💡 Para permitir a todos: *${usedPrefix}oncomando ${targetCommand}*`;
            }
            
            await message.reply(mensaje);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando comandos-on-off:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['offcomando', 'oncomando', 'adminscomando', 'listacomandos'];
handler.tags = ['admin'];
handler.command = /^(offcomando|oncomando|comandooff|comandoon|adminscomando|comandoadmins|listacomandos|comandosoff)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.isCommandEnabled = isCommandEnabled;
module.exports.setCommandStatus = setCommandStatus;
module.exports.getDisabledCommands = getDisabledCommands;
module.exports.isProtectedCommand = isProtectedCommand;