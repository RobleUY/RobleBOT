const fs = require('fs');
const path = require('path');

// Archivo donde se guardan las redes
const REDES_FILE = path.join(__dirname, 'redes.json');

// Redes permitidas y sus URLs base
const REDES_PERMITIDAS = {
    tiktok: 'https://www.tiktok.com/@',
    instagram: 'https://www.instagram.com/'
};

// Cargar datos existentes o crear uno vacío
let redesUsuarios = {};
try {
    redesUsuarios = JSON.parse(fs.readFileSync(REDES_FILE, 'utf8'));
} catch {
    redesUsuarios = {};
}

// Guardar archivo
function guardarRedes() {
    try {
        fs.writeFileSync(REDES_FILE, JSON.stringify(redesUsuarios, null, 2), { mode: 0o666 });
    } catch (error) {
        const dir = path.dirname(REDES_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(REDES_FILE, JSON.stringify(redesUsuarios, null, 2), { mode: 0o666 });
    }
}

let handler = async (message, { text }) => {
    try {
        const chatId = message?.key?.remoteJid;

        // 🚫 Si no es grupo, bloquear el comando
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo puede usarse en grupos.*');
        }

        // ✅ Obtener número real del remitente
        let senderJid = message.key.participant || message.key.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente.');

        // Limpiar JID → solo el número
        const senderNumber = senderJid.replace(/@.*$/, '');

        // 🔹 Sin texto → mostrar redes propias
        if (!text) {
            const redes = redesUsuarios[senderNumber];
            if (!redes || Object.keys(redes).length === 0) {
                return await message.reply(
                    '📱 *NO TIENES REDES GUARDADAS*\n' +
                    '━━━━━━━━━━━━━━━\n\n' +
                    '_Usa:_\n' +
                    '/redes tiktok tu_usuario\n' +
                    '/redes instagram tu_usuario'
                );
            }

            let mensaje = '📱 *TUS REDES SOCIALES*\n━━━━━━━━━━━━━━━\n\n';
            for (let [red, data] of Object.entries(redes)) {
                const emoji = red === 'tiktok' ? '🎵' : red === 'instagram' ? '📷' : '📌';
                mensaje += `${emoji} *${red.toUpperCase()}*: @${data.usuario}\n🔗 ${data.url}\n\n`;
            }
            return await message.reply(mensaje.trim());
        }

        // 🔹 Si menciona a otro usuario → mostrar sus redes
        const mentioned = message?.mentions;
        if (mentioned && mentioned.length > 0) {
            const target = mentioned[0].replace(/@.*$/, '');
            const redes = redesUsuarios[target];
            if (!redes || Object.keys(redes).length === 0)
                return await message.reply(`👤 *@${target}* no tiene redes guardadas.`, { mentions: [mentioned[0]] });

            let mensaje = `📱 *REDES DE @${target}*\n━━━━━━━━━━━━━━━\n\n`;
            for (let [red, data] of Object.entries(redes)) {
                const emoji = red === 'tiktok' ? '🎵' : red === 'instagram' ? '📷' : '📌';
                mensaje += `${emoji} *${red.toUpperCase()}*: @${data.usuario}\n🔗 ${data.url}\n\n`;
            }
            return await message.reply(mensaje.trim(), { mentions: [mentioned[0]] });
        }

        // 🔹 Guardar o actualizar red
        const partes = text.split(' ');
        if (partes.length >= 2) {
            const redSocial = partes[0].toLowerCase();
            let usuarioRed = partes.slice(1).join(' ').trim();

            // Si el usuario pegó una URL completa, extraemos el nombre
            if (usuarioRed.includes('tiktok.com') || usuarioRed.includes('instagram.com')) {
                usuarioRed = usuarioRed
                    .replace(/(https?:\/\/)?(www\.)?(tiktok\.com\/@|instagram\.com\/)/, '')
                    .replace('/', '')
                    .replace('@', '')
                    .trim();
            }

            if (!REDES_PERMITIDAS[redSocial]) {
                return await message.reply('❌ *Red no permitida.* Usa: tiktok o instagram');
            }

            if (usuarioRed.length < 2) {
                return await message.reply('❌ *Usuario inválido.* Debe tener al menos 2 caracteres.');
            }

            // Crear estructura
            if (!redesUsuarios[senderNumber]) redesUsuarios[senderNumber] = {};

            // Generar URL según la red
            const url = REDES_PERMITIDAS[redSocial] + usuarioRed + (redSocial === 'instagram' ? '/' : '');
            const anterior = redesUsuarios[senderNumber][redSocial];

            // Guardar
            redesUsuarios[senderNumber][redSocial] = { usuario: usuarioRed, url };
            guardarRedes();

            const emoji = redSocial === 'tiktok' ? '🎵' : '📷';
            if (anterior) {
                return await message.reply(
                    `${emoji} *ACTUALIZADO*\n━━━━━━━━━━━━━━━\n\n` +
                    `*${redSocial.toUpperCase()}*\n` +
                    `_Anterior:_ @${anterior.usuario}\n` +
                    `_Nuevo:_ @${usuarioRed}\n` +
                    `🔗 ${url}`
                );
            } else {
                return await message.reply(
                    `${emoji} *GUARDADO* ✅\n━━━━━━━━━━━━━━━\n\n` +
                    `*${redSocial.toUpperCase()}*: @${usuarioRed}\n` +
                    `🔗 ${url}\n\n` +
                    `_Usa /redes para ver todas tus redes_`
                );
            }
        }

        // 🔹 Ayuda / uso
        return await message.reply(
            '*📱 COMANDOS DE REDES SOCIALES*\n' +
            '━━━━━━━━━━━━━━━\n\n' +
            '/redes - Ver tus redes\n' +
            '/redes @usuario - Ver redes de otro\n' +
            '/redes [red] [usuario|link] - Guardar o actualizar\n\n' +
            '*Ejemplo:*\n' +
            '/redes tiktok robleuy\n' +
            '/redes instagram robleuy'
        );

    } catch (error) {
        console.error('[ERROR] Sistema de redes:', error);
        return await message.reply('❌ Error al procesar tu solicitud.');
    }
};

handler.help = ['redes', 'redes @usuario', 'redes tiktok usuario'];
handler.tags = ['redes'];
handler.command = /^(redes)$/i;

module.exports = handler;
