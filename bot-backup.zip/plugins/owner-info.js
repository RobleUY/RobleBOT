/**
 * Comando: owner / dueño / creador
 * Descripción: Muestra información sobre el creador del bot.
 * Uso: .owner
 */

const moment = require('moment-timezone');

function calcularEdad(fechaNacimiento) {
    const hoy = moment().tz('America/Montevideo');
    const nacimiento = moment.tz(fechaNacimiento, 'America/Montevideo');
    return hoy.diff(nacimiento, 'years');
}

let handler = async (message, { usedPrefix }) => {
    try {
        const edad = calcularEdad('2004-01-13');

        const info = `━━━━━━━━━━━━━
┃ 👑 *CREADOR DEL BOT*
━━━━━━━━━━━━━
┃ 🧠 *Nombre:* RobleUY
┃ 🪪 *Nombre real:* Sebastián
┃ 🗓️ *Fecha de nacimiento:* 13 de enero de 2004
┃ 🎂 *Edad:* ${edad} años
┃ 🌎 *País:* 🇺🇾 Uruguay
┃
┃ 💬 *Contacto:*
┃    • WhatsApp: wa.me/+59893900470
┃    • Instagram: @robleuy
┃
┃ 🌐 *Web:* https://robleuy.site/roblebot
┃ 📢 *Canal del bot:* 
┃    https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q
━━━━━━━━━━━━━
┃ 🤖 *Bot desarrollado por RobleUY*
━━━━━━━━━━━━━`;

        await message.reply(info);
    } catch (error) {
        console.error('[ERROR] en comando owner:', error);
        await message.reply('❌ Ocurrió un error al mostrar la información del creador.');
    }
};

handler.help = ['owner', 'dueño', 'creador'];
handler.tags = ['info'];
handler.command = /^(owner|dueño|creador)$/i;

module.exports = handler;
