const fs = require('fs');
const path = require('path');

// Ruta del archivo forzada a la raíz para evitar problemas de permisos
const HUERTOS_FILE = path.resolve(process.cwd(), 'huertos.json');

// Catálogo masivo de cultivos
const CULTIVOS = {
    // 🟢 BÁSICOS (Crecen rápido, ganancia pequeña)
    ajo: { nombre: '🧄 Ajo', tiempo: 0.5 * 60 * 1000, min: 1, max: 3, precioCompra: 2, precioVenta: 1, cat: '🟢 Básico' },          // 30 seg
    papa: { nombre: '🥔 Papa', tiempo: 1 * 60 * 1000, min: 1, max: 4, precioCompra: 5, precioVenta: 2, cat: '🟢 Básico' },           // 1 min
    fresa: { nombre: '🍓 Fresa', tiempo: 3 * 60 * 1000, min: 2, max: 5, precioCompra: 12, precioVenta: 4, cat: '🟢 Básico' },        // 3 min
    zanahoria: { nombre: '🥕 Zanahoria', tiempo: 5 * 60 * 1000, min: 1, max: 5, precioCompra: 15, precioVenta: 6, cat: '🟢 Básico' },// 5 min

    // 🟡 INTERMEDIOS (Requieren paciencia, buena ganancia)
    tomate: { nombre: '🍅 Tomate', tiempo: 15 * 60 * 1000, min: 2, max: 5, precioCompra: 50, precioVenta: 18, cat: '🟡 Intermedio' },// 15 min
    cebolla: { nombre: '🧅 Cebolla', tiempo: 20 * 60 * 1000, min: 1, max: 4, precioCompra: 70, precioVenta: 30, cat: '🟡 Intermedio' },// 20 min
    maiz: { nombre: '🌽 Maíz', tiempo: 30 * 60 * 1000, min: 2, max: 6, precioCompra: 120, precioVenta: 40, cat: '🟡 Intermedio' },   // 30 min
    uva: { nombre: '🍇 Uva', tiempo: 45 * 60 * 1000, min: 3, max: 8, precioCompra: 200, precioVenta: 50, cat: '🟡 Intermedio' },     // 45 min

    // 🔴 AVANZADOS (Para dejar plantados mientras no usas el bot)
    sandia: { nombre: '🍉 Sandía', tiempo: 60 * 60 * 1000, min: 1, max: 3, precioCompra: 300, precioVenta: 150, cat: '🔴 Avanzado' },// 1 hora
    calabaza: { nombre: '🎃 Calabaza', tiempo: 2 * 60 * 60 * 1000, min: 1, max: 2, precioCompra: 500, precioVenta: 400, cat: '🔴 Avanzado' }, // 2 horas
    pina: { nombre: '🍍 Piña', tiempo: 4 * 60 * 60 * 1000, min: 1, max: 3, precioCompra: 1000, precioVenta: 600, cat: '🔴 Avanzado' },   // 4 horas
    rosa: { nombre: '🌹 Rosa', tiempo: 8 * 60 * 60 * 1000, min: 1, max: 5, precioCompra: 2500, precioVenta: 1000, cat: '🔴 Avanzado' },  // 8 horas

    // 🟣 EXÓTICOS (Extremadamente caros, ganancias masivas)
    trufa: { nombre: '🍄 Trufa', tiempo: 12 * 60 * 60 * 1000, min: 1, max: 2, precioCompra: 5000, precioVenta: 4000, cat: '🟣 Exótico' }, // 12 horas
    girasol: { nombre: '🌻 Girasol Dorado', tiempo: 24 * 60 * 60 * 1000, min: 1, max: 1, precioCompra: 10000, precioVenta: 15000, cat: '🟣 Exótico' } // 24 horas
};

// Cargar datos existentes
let huertos = {};
try {
    if (fs.existsSync(HUERTOS_FILE)) {
        huertos = JSON.parse(fs.readFileSync(HUERTOS_FILE, 'utf8'));
    } else {
        fs.writeFileSync(HUERTOS_FILE, JSON.stringify({}, null, 2));
    }
} catch (error) {
    huertos = {};
}

// Función para guardar los datos
function guardarHuertos() {
    try {
        fs.writeFileSync(HUERTOS_FILE, JSON.stringify(huertos, null, 2));
    } catch (error) {
        console.error('No se pudo guardar el archivo de huertos:', error);
    }
}

// Inicializar usuario si no existe
function inicializarUsuario(numero) {
    if (!huertos[numero]) {
        huertos[numero] = {
            monedas: 0,
            capacidad: 5,
            inventario: { papa: 1, ajo: 2 }, // Inicia con 1 papa y 2 ajos de regalo
            plantaciones: [] 
        };
        guardarHuertos();
    }
    return huertos[numero];
}

// Función mejorada para formatear el tiempo (Soporta horas)
function formatearTiempo(ms) {
    if (ms <= 0) return "¡Listo para cosechar!";
    const horas = Math.floor(ms / 3600000);
    const minutos = Math.floor((ms % 3600000) / 60000);
    const segundos = ((ms % 60000) / 1000).toFixed(0);
    
    let timeStr = "";
    if (horas > 0) timeStr += `${horas}h `;
    if (minutos > 0) timeStr += `${minutos}m `;
    timeStr += `${segundos}s`;
    
    return timeStr.trim();
}

let handler = async (message, { text, command }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        if (!senderJid) return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        
        const senderNumber = senderJid.split('@')[0];
        const args = text ? text.toLowerCase().trim().split(' ') : [];
        const accion = args[0];

        // 1. MENÚ PRINCIPAL
        if (!accion || accion === 'ayuda' || accion === 'menu') {
            return await message.reply(
                '*🚜 MEGA HUERTO V2 🚜*\n' +
                '━━━━━━━━━━━━━━━\n\n' +
                '_Gestiona tu granja, planta semillas y conviértete en millonario._\n\n' +
                '📋 *.huerto info* - _Tu dinero, inventario y estado de tus plantas._\n' +
                '🏪 *.huerto tienda* - _Mira las 14 semillas disponibles y sus precios._\n' +
                '🌱 *.huerto plantar [semilla] [cant]* - _Planta semillas. Ej: .huerto plantar ajo 2_\n' +
                '🌾 *.huerto cosechar* - _Recoge todo lo que ya terminó de crecer._\n' +
                '💰 *.huerto vender [semilla] [cant]* - _Vende tu cosecha. Ej: .huerto vender papa 1_\n' +
                '💸 *.huerto vender todo* - _Vende absolutamente todo tu inventario._\n' +
                '🛒 *.huerto comprar [semilla] [cant]* - _Compra semillas. Ej: .huerto comprar sandia 1_\n' +
                '🗺️ *.huerto expandir* - _Compra +5 espacios de tierra (el precio sube)._\n' +
                '🤝 *.huerto dar @usuario [cant]* - _Regálale AgroMonedas a un amigo._'
            );
        }

        const usuario = inicializarUsuario(senderNumber);

        // 2. INFORMACIÓN DEL HUERTO (.huerto info)
        if (accion === 'info') {
            let info = `📊 *ESTADO DE TU HUERTO* 📊\n━━━━━━━━━━━━━━━\n`;
            info += `🌿 *AgroMonedas:* ${usuario.monedas}\n`;
            info += `📏 *Capacidad:* ${usuario.capacidad} espacios totales\n\n`;
            
            info += `📦 *Tu Inventario (Sin plantar / Cosechado):*\n`;
            let invVacio = true;
            for (let [item, cant] of Object.entries(usuario.inventario)) {
                if (cant > 0) {
                    info += `- ${CULTIVOS[item] ? CULTIVOS[item].nombre : item}: ${cant}\n`;
                    invVacio = false;
                }
            }
            if (invVacio) info += `_Inventario vacío_\n`;

            info += `\n🌱 *Plantaciones Actuales:*\n`;
            let espaciosUsados = 0;
            const ahora = Date.now();
            
            if (usuario.plantaciones.length === 0) {
                info += `_No tienes nada plantado ahora mismo_\n`;
            } else {
                usuario.plantaciones.forEach((p, index) => {
                    espaciosUsados += p.cantidad;
                    const cultivo = CULTIVOS[p.tipo];
                    const tiempoRestante = (p.fechaPlantado + cultivo.tiempo) - ahora;
                    info += `${index + 1}. ${cultivo.nombre} (x${p.cantidad}) - ⏳ ${formatearTiempo(tiempoRestante)}\n`;
                });
            }
            
            info += `\n*Tierra disponible para plantar:* ${usuario.capacidad - espaciosUsados}\n`;
            return await message.reply(info);
        }

        // 3. PLANTAR CULTIVOS (.huerto plantar)
        if (accion === 'plantar') {
            const tipo = args[1];
            const cantidad = parseInt(args[2]) || 1;

            if (!tipo || !CULTIVOS[tipo]) {
                return await message.reply('❌ *Semilla no válida.* Revisa la _.huerto tienda_ para ver los nombres válidos.\nEjemplo: _.huerto plantar uva 2_');
            }
            if (cantidad <= 0 || isNaN(cantidad)) return await message.reply('❌ Cantidad inválida.');
            if (!usuario.inventario[tipo] || usuario.inventario[tipo] < cantidad) {
                return await message.reply(`❌ No tienes suficientes semillas de *${tipo}* en tu inventario. Tienes ${usuario.inventario[tipo] || 0}.`);
            }

            const espaciosUsados = usuario.plantaciones.reduce((acc, curr) => acc + curr.cantidad, 0);
            if (espaciosUsados + cantidad > usuario.capacidad) {
                return await message.reply(`❌ No tienes espacio de tierra suficiente. Espacio libre: ${usuario.capacidad - espaciosUsados}`);
            }

            usuario.inventario[tipo] -= cantidad;
            usuario.plantaciones.push({
                tipo: tipo,
                cantidad: cantidad,
                fechaPlantado: Date.now()
            });
            guardarHuertos();

            return await message.reply(`🌱 Has plantado *${cantidad}x ${CULTIVOS[tipo].nombre}*.\nEstará listo en: ${formatearTiempo(CULTIVOS[tipo].tiempo)}.`);
        }

        // 4. COSECHAR (.huerto cosechar)
        if (accion === 'cosechar') {
            const ahora = Date.now();
            let cosechados = {};
            let plantacionesRestantes = [];
            let totalGanado = 0;

            usuario.plantaciones.forEach(p => {
                const cultivo = CULTIVOS[p.tipo];
                if (ahora >= p.fechaPlantado + cultivo.tiempo) {
                    let cantidadObtenida = 0;
                    for(let i = 0; i < p.cantidad; i++) {
                        cantidadObtenida += Math.floor(Math.random() * (cultivo.max - cultivo.min + 1)) + cultivo.min;
                    }
                    
                    if (!usuario.inventario[p.tipo]) usuario.inventario[p.tipo] = 0;
                    usuario.inventario[p.tipo] += cantidadObtenida;
                    
                    if (!cosechados[p.tipo]) cosechados[p.tipo] = 0;
                    cosechados[p.tipo] += cantidadObtenida;
                    totalGanado += cantidadObtenida;
                } else {
                    plantacionesRestantes.push(p);
                }
            });

            if (totalGanado === 0) {
                return await message.reply('❌ Todavía no tienes plantas listas. ¡Ten paciencia!\n_Usa .huerto info para ver cuánto falta._');
            }

            usuario.plantaciones = plantacionesRestantes;
            guardarHuertos();

            let msj = `👨‍🌾 *¡COSECHA EXITOSA!* 👨‍🌾\n━━━━━━━━━━━━━━━\nHas recolectado todo lo que estaba listo:\n\n`;
            for (let [tipo, cant] of Object.entries(cosechados)) {
                msj += `✅ +${cant} ${CULTIVOS[tipo].nombre}\n`;
            }
            return await message.reply(msj);
        }

        // 5. VENDER (.huerto vender)
        if (accion === 'vender') {
            const tipoOVenderTodo = args[1];
            
            if (tipoOVenderTodo === 'todo') {
                let gananciaTotal = 0;
                let vendidoAlgo = false;
                let msjDetalle = "";
                
                for (let [item, cant] of Object.entries(usuario.inventario)) {
                    if (cant > 0 && CULTIVOS[item]) {
                        const ganancia = cant * CULTIVOS[item].precioVenta;
                        gananciaTotal += ganancia;
                        msjDetalle += `- ${cant}x ${CULTIVOS[item].nombre} ➡️ 🌿 ${ganancia}\n`;
                        usuario.inventario[item] = 0;
                        vendidoAlgo = true;
                    }
                }
                
                if (!vendidoAlgo) return await message.reply('❌ No tienes ningún cultivo en tu inventario para vender.');
                
                usuario.monedas += gananciaTotal;
                guardarHuertos();
                return await message.reply(`💰 *VENTA MASIVA COMPLETA* 💰\n━━━━━━━━━━━━━━━\nHas vaciado tu inventario:\n${msjDetalle}\n*Ganancia total:* 🌿 ${gananciaTotal} AgroMonedas`);
            }
            
            const cantidad = parseInt(args[2]);
            if (!tipoOVenderTodo || !CULTIVOS[tipoOVenderTodo]) {
                return await message.reply('❌ *Falta información.* Debes decirme qué vender.\nEjemplo: _.huerto vender cebolla 2_ o _.huerto vender todo_');
            }
            if (isNaN(cantidad) || cantidad <= 0) return await message.reply('❌ Cantidad inválida. Indica un número.');
            
            if (!usuario.inventario[tipoOVenderTodo] || usuario.inventario[tipoOVenderTodo] < cantidad) {
                return await message.reply(`❌ No tienes esa cantidad de *${tipoOVenderTodo}* guardada.`);
            }

            const ganancia = cantidad * CULTIVOS[tipoOVenderTodo].precioVenta;
            usuario.inventario[tipoOVenderTodo] -= cantidad;
            usuario.monedas += ganancia;
            guardarHuertos();

            return await message.reply(`💰 Has vendido *${cantidad}x ${CULTIVOS[tipoOVenderTodo].nombre}*\nHas ganado 🌿 *${ganancia} AgroMonedas*.`);
        }

        // 6. COMPRAR (.huerto comprar)
        if (accion === 'comprar') {
            const tipo = args[1];
            const cantidad = parseInt(args[2]) || 1;

            if (!tipo || !CULTIVOS[tipo]) {
                return await message.reply('❌ *Cultivo no válido.* Revisa la tienda.\nEjemplo: _.huerto comprar pina 1_');
            }
            if (isNaN(cantidad) || cantidad <= 0) return await message.reply('❌ Cantidad inválida.');

            const costo = CULTIVOS[tipo].precioCompra * cantidad;
            if (usuario.monedas < costo) {
                return await message.reply(`❌ *Dinero insuficiente.*\nNecesitas 🌿 ${costo} y solo tienes 🌿 ${usuario.monedas}.`);
            }

            usuario.monedas -= costo;
            if (!usuario.inventario[tipo]) usuario.inventario[tipo] = 0;
            usuario.inventario[tipo] += cantidad;
            guardarHuertos();

            return await message.reply(`🛒 *COMPRA REALIZADA*\nHas adquirido *${cantidad}x ${CULTIVOS[tipo].nombre}*\nGastaste: 🌿 ${costo} AgroMonedas\n\n_Usa .huerto plantar ${tipo} ${cantidad}_`);
        }

        // 7. EXPANDIR TERRENO (.huerto expandir)
        if (accion === 'expandir') {
            const costoExpansion = (usuario.capacidad / 5) * 100;

            if (args[1] === 'confirmar') {
                if (usuario.monedas < costoExpansion) {
                    return await message.reply(`❌ No tienes fondos suficientes. Cuesta 🌿 *${costoExpansion} AgroMonedas*.`);
                }
                usuario.monedas -= costoExpansion;
                usuario.capacidad += 5;
                guardarHuertos();
                return await message.reply(`✅ *¡TERRENO EXPANDIDO!* 🚜\nHas pagado 🌿 ${costoExpansion} AgroMonedas.\nAhora tienes capacidad para *${usuario.capacidad}* plantas.`);
            }

            return await message.reply(`🗺️ *AGENCIA DE TIERRAS*\n━━━━━━━━━━━━━━━\nMejorar tu granja te dará *+5 espacios extras* para sembrar.\n\n*Tu capacidad actual:* ${usuario.capacidad}\n*Costo de expansión:* 🌿 ${costoExpansion} AgroMonedas\n\nPara confirmar esta compra usa:\n*.huerto expandir confirmar*`);
        }

        // 8. TRANSFERIR MONEDAS (.huerto dar)
        if (accion === 'dar' || accion === 'transferir') {
            const mentionedJids = message?.mentions;
            if (!mentionedJids || mentionedJids.length === 0) return await message.reply('❌ Debes mencionar a un granjero. Ejemplo: _.huerto dar @usuario 50_');

            const targetJid = mentionedJids[0];
            const targetNumber = targetJid.split('@')[0];
            const cantidadStr = args.find(arg => !isNaN(arg) && arg > 0);
            const cantidad = parseInt(cantidadStr);

            if (!cantidad || cantidad <= 0) return await message.reply('❌ Especifica una cantidad válida.');
            if (targetNumber === senderNumber) return await message.reply('❌ No puedes darte monedas a ti mismo.');
            if (usuario.monedas < cantidad) return await message.reply(`❌ No tienes ese dinero. Tu saldo es de 🌿 ${usuario.monedas}.`);

            const receptor = inicializarUsuario(targetNumber);
            usuario.monedas -= cantidad;
            receptor.monedas += cantidad;
            guardarHuertos();

            return await message.reply(`🤝 *TRANSFERENCIA EXITOSA*\nHas regalado 🌿 *${cantidad} AgroMonedas* a @${targetNumber}.`, { mentions: [targetJid] });
        }

        // 9. TIENDA DE PRECIOS MEJORADA (.huerto tienda)
        if (accion === 'tienda') {
            // Agrupar cultivos por categoría
            let categorias = {};
            for (let [clave, datos] of Object.entries(CULTIVOS)) {
                if (!categorias[datos.cat]) categorias[datos.cat] = [];
                categorias[datos.cat].push({ clave, ...datos });
            }

            let msj = `🏪 *MERCADO AGRÍCOLA* 🏪\n━━━━━━━━━━━━━━━\n_Para comprar usa: .huerto comprar [nombre] [cant]_\n\n`;
            
            for (let [catNombre, plantas] of Object.entries(categorias)) {
                msj += `*━━ ${catNombre.toUpperCase()} ━━*\n`;
                plantas.forEach(p => {
                    msj += `*${p.nombre}* (Cod: _${p.clave}_)\n`;
                    msj += ` ⏱️ Crece en: ${formatearTiempo(p.tiempo)}\n`;
                    msj += ` 📈 Da: ${p.min} a ${p.max} u. | 🛒: 🌿${p.precioCompra} | 💰: 🌿${p.precioVenta}\n\n`;
                });
            }
            
            return await message.reply(msj);
        }

        return await message.reply('❌ Comando incorrecto. Escribe *.huerto* para ver el menú con todas las opciones.');

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en el sistema de huertos:', error, '\x1b[0m');
        return await message.reply('❌ *Error en el sistema*\n\n_Ocurrió un error al procesar tu solicitud del huerto._');
    }
};

handler.help = ['huerto'];
handler.tags = ['juegos'];
handler.command = /^(huerto)$/i;

module.exports = handler;