const db = require('../database.js');

let handler = async (message, { text }) => {
    try {
        if (!text) {
            return message.reply('⚠️ Usa:\n.givemoney @user|apodo|numero cantidad');
        }

        let args = text.split(' ');
        let targetInput = args[0];
        let amount = parseInt(args[1]);

        if (!targetInput || isNaN(amount)) {
            return message.reply('⚠️ Formato:\n.givemoney @usuario|apodo|numero cantidad');
        }

        if (amount <= 0) {
            return message.reply('❌ La cantidad debe ser mayor a 0');
        }

        let targetId = null;

        // ========== 1. SI ES MENCION ==========
        if (targetInput.includes('@')) {
            targetId = targetInput.replace(/[^0-9]/g, '');
        }

        // ========== 2. SI ES NÚMERO ==========
        if (!targetId && /^\d+$/.test(targetInput)) {
            targetId = targetInput;
        }

        // ========== 3. SI ES APODO ==========
        if (!targetId && db.data?.users) {
            const search = targetInput.toLowerCase();

            for (const [id, user] of Object.entries(db.data.users)) {
                if (user.apodo &&
                    user.apodo.toLowerCase() === search) {
                    targetId = id;
                    break;
                }
            }
        }

        if (!targetId) {
            return message.reply(
                `❌ No pude encontrar al usuario.\n\n` +
                `💡 Puedes usar:\n` +
                `• @usuario\n• número\n• apodo`
            );
        }

        // ========== OBTENER USUARIO ==========
        let user = db.getUser(targetId);

        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                apodo: "sin apodo",
                respeto: 0
            };
        }

        user.money = Number(user.money) || 0;

        user.money += amount;

        db.setUser(targetId, user);

        return message.reply(
            `💰 *GIVE MONEY (OWNER)*\n\n` +
            `👤 Usuario: ${user.apodo ? `(${user.apodo})` : ''} @${targetId}\n` +
            `➕ Dinero dado: ${amount.toLocaleString()}\n` +
            `💵 Nuevo saldo: ${user.money.toLocaleString()}`
        );

    } catch (err) {
        console.error(err);
        return message.reply('❌ Error en givemoney');
    }
};

handler.command = /^givemoney$/i;
handler.owner = true;
handler.help = ['givemoney'];
handler.tags = ['owner', 'economy'];

module.exports = handler;