const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const RESPUESTAS_FILE = path.join(DATA_DIR, 'respuestas-usuarios.json');

// Inicializar archivo
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(RESPUESTAS_FILE)) {
    fs.writeFileSync(RESPUESTAS_FILE, JSON.stringify({}, null, 2), 'utf8');
}

function loadRespuestas() {
    try {
        if (fs.existsSync(RESPUESTAS_FILE)) {
            const data = fs.readFileSync(RESPUESTAS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando respuestas-usuarios.json:', e);
    }
    return {};
}

function saveRespuestas(data) {
    try {
        fs.writeFileSync(RESPUESTAS_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Error guardando respuestas-usuarios.json:', e);
        return false;
    }
}

let handler = async (message, { conn, args }) => {
    try {
        if (!message.isGroup) return message.reply('❌ Solo en grupos.');

        const activeConn = message._sock || global.conn;
        if (!activeConn) {
            return message.reply('❌ No hay ningún bot conectado disponible.');
        }

        const meta = await activeConn.groupMetadata(message.from);
        const sender = (message.sender || message.author).split('@')[0].split(':')[0];
        const user = meta.participants.find(p => p.id.includes(sender));
        const isAdmin = user && (user.admin === 'admin' || user.admin === 'superadmin');
        const isOwner = global.botConfig?.isOwner?.(sender) || global.botConfig?.owners?.some?.(o => o.replace(/\D/g, '') === sender);

        if (!isAdmin && !isOwner) {
            return message.reply('❌ Solo los *administradores* pueden usar este comando.');
        }

        if (!args || args.length === 0) {
            return message.reply('⚠️ Formato incorrecto.\n\nEjemplos:\n.respuesta add @usuario Texto\n.respuesta list @usuario\n.respuesta del @usuario 1');
        }

        const action = args[0].toLowerCase();

        const validActions = ['add', 'set', 'list', 'lista', 'ver', 'view', 'del', 'delete', 'remove', 'borrar'];
        if (!validActions.includes(action)) {
            return message.reply('⚠️ Acción no reconocida. Usa add, list o del.');
        }

        // Resolver target: mención, "me" o "yo"
        let target, num;
        const secondArg = args[1]?.toLowerCase();

        if (secondArg === 'me' || secondArg === 'yo') {
            num = sender;
            target = message.sender || message.author;
        } else if (message.mentions && message.mentions.length > 0) {
            // @usuario detectado en mentions
            target = message.mentions[0];
            num = target.split('@')[0].split(':')[0];
        } else {
            return message.reply('⚠️ Debes mencionar a un usuario, o escribir "me" / "yo".');
        }

        const group = message.from;
        let data = loadRespuestas();
        if (!data[group]) data[group] = {};
        if (!data[group][num]) data[group][num] = [];

        if (['add', 'set'].includes(action)) {
            // El texto viene después del @usuario (o de me/yo)
            // args: [action, @user_o_me, ...texto]
            const texto = args.slice(2).join(' ').trim();
            if (!texto) return message.reply('⚠️ Debes escribir el texto de la respuesta.');

            data[group][num].push(texto);
            saveRespuestas(data);
            return message.reply(`✅ Respuesta agregada para @${num}:\n"${texto}"`, { mentions: [target] });

        } else if (['list', 'lista', 'ver', 'view'].includes(action)) {
            const respuestas = data[group][num];
            if (!respuestas || respuestas.length === 0) {
                return message.reply(`ℹ️ No hay respuestas configuradas para @${num}.`, { mentions: [target] });
            }

            let replyText = `Respuestas configuradas para @${num}\n\n`;
            respuestas.forEach((r, i) => {
                replyText += `${i + 1}. ${r}\n`;
            });

            return message.reply(replyText.trim(), { mentions: [target] });

        } else if (['del', 'delete', 'remove', 'borrar'].includes(action)) {
            const index = parseInt(args[2]);
            if (isNaN(index) || index < 1 || index > data[group][num].length) {
                return message.reply(`⚠️ Número inválido. Usa .respuesta list @${num} para ver los números.`, { mentions: [target] });
            }

            const removed = data[group][num].splice(index - 1, 1)[0];

            if (data[group][num].length === 0) delete data[group][num];
            if (Object.keys(data[group]).length === 0) delete data[group];

            saveRespuestas(data);
            return message.reply(`✅ Respuesta eliminada para @${num}:\n"${removed}"`, { mentions: [target] });
        }

    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[Plugin Respuesta] Error:', error);
        }
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['respuesta'];
handler.tags = ['admin'];
handler.command = /^(respuesta|respuestas|responder|responde|answer|answers)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
// La detección automática de todos los mensajes se hace directamente en index.js y subbot-serbot.js
