const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones
const GRUPOS_DIR = path.join(__dirname);
const MYBOT_STATUS_FILE = path.join(GRUPOS_DIR, 'mybot-on-off.json');

// Grupos donde los subbots siempre están desactivados y no pueden reactivarse
const BLOCKED_GROUPS = [
    '120363203689229697@g.us', // Grupo oficial
];

// ── Caché en memoria ─────────────────────────────────────────────────────────
// Igual que bot-on-off.js: evita leer disco en cada mensaje de grupo.
let _mybotCache = null;
let _mybotMtime = 0;

// Cargar configuración de mybot
function loadMyBotConfig() {
    try {
        if (fs.existsSync(MYBOT_STATUS_FILE)) {
            const mtime = fs.statSync(MYBOT_STATUS_FILE).mtimeMs;
            if (_mybotCache !== null && mtime === _mybotMtime) {
                return _mybotCache;
            }
            const data = fs.readFileSync(MYBOT_STATUS_FILE, 'utf8');
            _mybotCache = JSON.parse(data);
            _mybotMtime = mtime;
            return _mybotCache;
        }
    } catch (error) {
        console.error('Error cargando mybot-on-off.json:', error.message);
    }
    _mybotCache = {};
    return _mybotCache;
}

// Guardar configuración de mybot
function saveMyBotConfig(config) {
    try {
        fs.writeFileSync(MYBOT_STATUS_FILE, JSON.stringify(config, null, 2), 'utf8');
        _mybotCache = config;
        _mybotMtime = fs.statSync(MYBOT_STATUS_FILE).mtimeMs;
        return true;
    } catch (error) {
        console.error('Error guardando mybot-on-off.json:', error.message);
        return false;
    }
}

// Verificar si un subbot específico está encendido en un grupo
function isMyBotEnabled(groupJid, botNumber) {
    // Grupos bloqueados: siempre desactivado, sin excepción
    if (BLOCKED_GROUPS.includes(groupJid)) return false;

    const config = loadMyBotConfig();
    const cleanJid = groupJid.split('@')[0];
    const key = `${cleanJid}_${botNumber}`;
    
    // Por defecto el bot está encendido (true)
    // Retorna false solo si está explícitamente en false
    return config[key] !== false;
}

// Activar/desactivar un subbot específico en un grupo
function setMyBotStatus(groupJid, botNumber, enabled) {
    const config = loadMyBotConfig();
    const cleanJid = groupJid.split('@')[0];
    const key = `${cleanJid}_${botNumber}`;
    
    if (enabled) {
        // Si se enciende, eliminamos la entrada (por defecto está on)
        delete config[key];
    } else {
        // Solo guardamos cuando está apagado
        config[key] = false;
    }
    
    return saveMyBotConfig(config);
}

// Comando .onmybot
let onHandler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Grupos bloqueados: no se puede reactivar el subbot
        if (BLOCKED_GROUPS.includes(chatId)) {
            return; // Ignorar silenciosamente
        }

        // Verificar que quien ejecuta el comando es un subbot
        const botNumber = conn._subNum;
        if (!botNumber) {
            return; // Silenciosamente ignorar si no es un subbot
        }

        // Verificar que el mensaje lo envió el dueño del subbot
        const senderJid = message.sender;
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        
        // Obtener el dueño del subbot
        const ownerJid = conn._ownerJid;
        if (!ownerJid) {
            return; // Silenciosamente ignorar si no se puede verificar el dueño
        }
        
        const ownerNumber = ownerJid.split('@')[0].split(':')[0];
        
        // Solo responder si este subbot pertenece al usuario que envió el comando
        if (senderNumber !== ownerNumber) {
            return; // Silenciosamente ignorar si no es el dueño
        }

        // Activar el bot
        if (setMyBotStatus(chatId, botNumber, true)) {
            await message.reply(`✅ *Sub-Bot #${botNumber} encendido*\n\nTu sub-bot volverá a responder comandos en este grupo.`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando onmybot:', error);
        // No enviar mensaje de error para evitar spam de múltiples bots
    }
};

// Comando .offmybot
let offHandler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Verificar que quien ejecuta el comando es un subbot
        const botNumber = conn._subNum;
        if (!botNumber) {
            return; // Silenciosamente ignorar si no es un subbot
        }

        // Verificar que el mensaje lo envió el dueño del subbot
        const senderJid = message.sender;
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        
        // Obtener el dueño del subbot
        const ownerJid = conn._ownerJid;
        if (!ownerJid) {
            return; // Silenciosamente ignorar si no se puede verificar el dueño
        }
        
        const ownerNumber = ownerJid.split('@')[0].split(':')[0];
        
        // Solo responder si este subbot pertenece al usuario que envió el comando
        if (senderNumber !== ownerNumber) {
            return; // Silenciosamente ignorar si no es el dueño
        }

        // Desactivar el bot
        if (setMyBotStatus(chatId, botNumber, false)) {
            await message.reply(`❌ *Sub-Bot #${botNumber} apagado*\n\nTu sub-bot dejará de responder comandos en este grupo.\n\n💡 Para volver a encenderlo, usa: *.onmybot*`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando offmybot:', error);
        // No enviar mensaje de error para evitar spam de múltiples bots
    }
};

onHandler.help = ['onmybot'];
onHandler.tags = ['subbots'];
onHandler.command = /^(onmybot)$/i;
onHandler.group = true;

offHandler.help = ['offmybot'];
offHandler.tags = ['subbots'];
offHandler.command = /^(offmybot)$/i;
offHandler.group = true;

// Exportar ambos handlers para que se carguen correctamente
module.exports = offHandler; // El principal
module.exports.onmybot = onHandler; // Handler adicional
module.exports.offmybot = offHandler; // Handler adicional
module.exports.isMyBotEnabled = isMyBotEnabled;
module.exports.setMyBotStatus = setMyBotStatus;
