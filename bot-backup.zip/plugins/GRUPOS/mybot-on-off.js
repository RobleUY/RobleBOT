const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones
const GRUPOS_DIR = path.join(__dirname);
const MYBOT_STATUS_FILE = path.join(GRUPOS_DIR, 'mybot-on-off.json');

// Cargar configuración de mybot
function loadMyBotConfig() {
    try {
        if (fs.existsSync(MYBOT_STATUS_FILE)) {
            const data = fs.readFileSync(MYBOT_STATUS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando mybot-on-off.json:', error.message);
    }
    return {};
}

// Guardar configuración de mybot
function saveMyBotConfig(config) {
    try {
        fs.writeFileSync(MYBOT_STATUS_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando mybot-on-off.json:', error.message);
        return false;
    }
}

// Verificar si un subbot específico está encendido en un grupo
function isMyBotEnabled(groupJid, botNumber) {
    const config = loadMyBotConfig();
    const cleanJid = groupJid.split('@')[0];
    const key = `${cleanJid}_${botNumber}`;
    
    // Por defecto el bot está encendido (true)
    // Retorna false solo si está explícitamente en false
    return config[key] !== false;
}

// Activar/desactivar un subbot específico en un grupo
function setMyBotStatus(groupJid, botNumber, enabled) {
    const config = loadMyBotConfig();
    const cleanJid = groupJid.split('@')[0];
    const key = `${cleanJid}_${botNumber}`;
    
    if (enabled) {
        // Si se enciende, eliminamos la entrada (por defecto está on)
        delete config[key];
    } else {
        // Solo guardamos cuando está apagado
        config[key] = false;
    }
    
    return saveMyBotConfig(config);
}

// Comando .onmybot
let onHandler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Verificar que quien ejecuta el comando es un subbot
        const botNumber = conn._subNum;
        if (!botNumber) {
            return await message.reply('❌ Este comando solo puede ser usado por sub-bots.\n\n💡 Si eres admin del grupo, usa `.bot on` en su lugar.');
        }

        // Verificar que el mensaje lo envió el dueño del subbot
        const senderJid = message.sender;
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        
        // Obtener el dueño del subbot
        const ownerJid = conn._ownerJid;
        if (!ownerJid) {
            return await message.reply('❌ No se pudo verificar el dueño de este sub-bot.');
        }
        
        const ownerNumber = ownerJid.split('@')[0].split(':')[0];
        
        if (senderNumber !== ownerNumber) {
            return await message.reply('❌ Solo el dueño de este sub-bot puede usar este comando.');
        }

        // Activar el bot
        if (setMyBotStatus(chatId, botNumber, true)) {
            await message.reply(`✅ *Sub-Bot #${botNumber} encendido*\n\nTu sub-bot volverá a responder comandos en este grupo.`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando onmybot:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

// Comando .offmybot
let offHandler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Verificar que quien ejecuta el comando es un subbot
        const botNumber = conn._subNum;
        if (!botNumber) {
            return await message.reply('❌ Este comando solo puede ser usado por sub-bots.\n\n💡 Si eres admin del grupo, usa `.bot off` en su lugar.');
        }

        // Verificar que el mensaje lo envió el dueño del subbot
        const senderJid = message.sender;
        const senderNumber = senderJid.split('@')[0].split(':')[0];
        
        // Obtener el dueño del subbot
        const ownerJid = conn._ownerJid;
        if (!ownerJid) {
            return await message.reply('❌ No se pudo verificar el dueño de este sub-bot.');
        }
        
        const ownerNumber = ownerJid.split('@')[0].split(':')[0];
        
        if (senderNumber !== ownerNumber) {
            return await message.reply('❌ Solo el dueño de este sub-bot puede usar este comando.');
        }

        // Desactivar el bot
        if (setMyBotStatus(chatId, botNumber, false)) {
            await message.reply(`❌ *Sub-Bot #${botNumber} apagado*\n\nTu sub-bot dejará de responder comandos en este grupo.\n\n💡 Para volver a encenderlo, usa: *.onmybot*`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando offmybot:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

onHandler.help = ['onmybot'];
onHandler.tags = ['subbots'];
onHandler.command = /^(onmybot)$/i;
onHandler.group = true;

offHandler.help = ['offmybot'];
offHandler.tags = ['subbots'];
offHandler.command = /^(offmybot)$/i;
offHandler.group = true;

// Exportar ambos handlers para que se carguen correctamente
module.exports = offHandler; // El principal
module.exports.onmybot = onHandler; // Handler adicional
module.exports.offmybot = offHandler; // Handler adicional
module.exports.isMyBotEnabled = isMyBotEnabled;
module.exports.setMyBotStatus = setMyBotStatus;
