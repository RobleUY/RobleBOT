/**
 * Comando: /online <código>
 * Verifica que el usuario no está automatizando comandos.
 * El código es generado por el sistema anti-automatización del handler.
 */

let handler = async (message, { args, conn }) => {
    try {
        const userId = message.author || message.sender;
        const clean  = userId?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '');

        const inputCode = args[0];

        if (!inputCode) {
            return await message.reply(
                `🔐 *Verificación requerida*\n\n` +
                `Usa: */online <código>*\n\n` +
                `El código te fue enviado cuando el bot detectó actividad automatizada.`
            );
        }

        // Acceder al handler global para verificar el código
        const cmdHandler = global.commandHandler;
        if (!cmdHandler || typeof cmdHandler.verifyOnlineCode !== 'function') {
            return await message.reply('❌ Sistema de verificación no disponible.');
        }

        const ok = cmdHandler.verifyOnlineCode(clean, inputCode);

        if (ok) {
            return await message.reply(
                `✅ *Verificación exitosa*\n\n` +
                `Confirmado que eres una persona real. ¡Ya podés usar los comandos normalmente!`
            );
        } else {
            // Puede que no esté bloqueado o el código sea incorrecto
            const isPending = cmdHandler.pendingVerify?.has(clean);
            if (!isPending) {
                return await message.reply(`ℹ️ No tenés ninguna verificación pendiente.`);
            }
            return await message.reply(
                `❌ *Código incorrecto.*\n\n` +
                `Revisá el código que te envió el bot e intentá de nuevo.`
            );
        }

    } catch (error) {
        console.error('❌ Error en /online:', error);
        return await message.reply('❌ Ocurrió un error al verificar.');
    }
};

handler.help    = ['online <código>'];
handler.tags    = ['utilidad'];
handler.command = /^online$/i;

module.exports = handler;
