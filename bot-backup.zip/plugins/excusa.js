const KEYS = [
    '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',
    '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',
    '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'
];

let handler = async (message, { text }) => {
    try {
        const situacion = text?.trim() || 'no ir a un evento comprometido';
        const systemPrompt = 'Eres un experto en inventar excusas creativas, graciosas y creíbles. Responde ÚNICAMENTE con la excusa en 1 o 2 oraciones, sin intros ni saludos.';
        const userPrompt = `Genera una excusa para: ${situacion}`;

        let excusa = '';
        try {
            const iaModule = require('./HERRAMIENTAS/ia/ia');
            const callIA = iaModule.callIA || iaModule;
            if (typeof callIA === 'function') {
                const res = await callIA(systemPrompt, userPrompt);
                if (res && res !== '_SILENT_FAIL_') excusa = res;
            }
        } catch (e) {
            console.warn('[excusa] callIA falló, probando Groq directo:', e.message);
        }

        if (!excusa) {
            const apiKey = KEYS[Math.floor(Math.random() * KEYS.length)];
            const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'llama-3.1-8b-instant',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userPrompt }
                    ],
                    temperature: 0.8
                })
            });

            const data = await res.json();
            excusa = data.choices[0].message.content.trim();
        }

        await message.reply(`🎭 *EXCUSA GENERADA*\n\n"${excusa.replace(/^"+|"+$/g, '').trim()}"`);
    } catch (error) {
        console.error('[ERROR] excusa:', error);
        await message.reply('❌ Ocurrió un error al inventar la excusa.');
    }
};

handler.help = ['excusa'];
handler.tags = ['fun'];
handler.command = /^excusa$/i;

module.exports = handler;