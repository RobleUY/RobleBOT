const db = require('../database.js');
const achievements = require('../achievements');

const CATEGORY_ALIASES = {
  commands: ['comandos', 'commandos', 'cmds', 'commands'],
  work: ['trabajo', 'trabajos', 'work', 'works'],
  betting: ['apuestas', 'betting', 'casino', 'apostar'],
  daily: ['diaria', 'daily', 'cadadia', 'diarias']
};

function findCategory(key) {
  if (!key) return null;
  const normalized = key.trim().toLowerCase();
  for (const [category, aliases] of Object.entries(CATEGORY_ALIASES)) {
    if (category === normalized || aliases.includes(normalized)) {
      return category;
    }
  }
  return null;
}

let handler = async (message, { text, args }) => {
  try {
    const senderJid = message?.author || message?.sender || message?.key?.participant || message?.key?.remoteJid;
    if (!senderJid) {
      return await message.reply('❌ No se pudo obtener tu usuario.');
    }

    const senderNumber = senderJid.split('@')[0].split(':')[0];
    const userData = db.getUser(senderNumber);
    if (!userData) {
      return await message.reply('❌ No se pudieron cargar tus datos.');
    }

    const categoryArg = args && args.length > 0 ? args[0] : (text ? text.trim().split(/\s+/)[0] : '');
    const category = findCategory(categoryArg);
    const summary = category
      ? achievements.getAchievementSummary(userData, category)
      : achievements.getAchievementSummary(userData);

    if (!summary) {
      return await message.reply(
        '❌ Categoría inválida. Usa:
' +
        '• .logros comandos
' +
        '• .logros trabajo
' +
        '• .logros apuestas
' +
        '• .logros diaria
'
      );
    }

    const header = category ? `📌 *Logros de ${categoryArg}*\n\n` : '🏆 *Tus logros*\n\n';
    return await message.reply(header + summary);
  } catch (error) {
    console.error('Error en comando logros:', error);
    return await message.reply('❌ Ocurrió un error al mostrar tus logros.');
  }
};

handler.help = ['logros', 'logro', 'achievements', 'objetivos'];
handler.tags = ['info', 'usuarios'];
handler.command = /^(logros|logro|achievements|objetivos)$/i;
module.exports = handler;
handler.group = false;
handler.apodo = true;
