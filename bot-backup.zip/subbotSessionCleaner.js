const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const chalk = require('chalk');

const SESIONES_DIR = path.join(__dirname, 'plugins', 'SUBBOTS', 'sesiones'); // minúsculas
const BAILEYS_AUTH_DIR = path.join(__dirname, 'baileys_auth');

// Archivos esenciales que NUNCA se borran
const KEEP_FILES = new Set(['creds.json', 'owner.json']);

// Límites para bot principal
const LIMITS_MAIN = {
  'pre-key-':                100,
  'device-list-':             20,
  'lid-mapping-':             50,
  'session-':                 10,
  'sender-key-':              30,
  'sender-key-memory-':        5,
  'app-state-sync-key-':       5,
  'app-state-sync-version-':   3,
  'tctoken-':                 10,
};

// Límites agresivos para subbots
const LIMITS_SUBBOT = {
  'pre-key-':                 50,
  'device-list-':             10,
  'lid-mapping-':             20,
  'session-':                  5,
  'sender-key-':              15,
  'sender-key-memory-':        3,
  'app-state-sync-key-':       3,
  'app-state-sync-version-':   2,
  'tctoken-':                  5,
};

async function cleanupDir(dir, pattern, limit) {
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    const matching = entries.filter(e =>
      e.isFile() &&
      e.name.startsWith(pattern) &&
      e.name.endsWith('.json') &&
      !KEEP_FILES.has(e.name)
    );

    if (matching.length === 0) return 0;

    const files = await Promise.all(
      matching.map(async e => {
        const filePath = path.join(dir, e.name);
        const stat = await fs.stat(filePath);
        return { name: e.name, path: filePath, mtime: stat.mtimeMs };
      })
    );

    files.sort((a, b) => b.mtime - a.mtime); // más recientes primero

    // Separar corruptos de válidos
    const validFiles = [];
    let deleted = 0;

    for (const file of files) {
      try {
        const content = await fs.readFile(file.path, 'utf-8');
        JSON.parse(content);
        validFiles.push(file);
      } catch {
        // corrupto — borrar
        try { await fs.unlink(file.path); deleted++; } catch {}
      }
    }

    // Borrar los válidos que exceden el límite
    const toDelete = validFiles.slice(limit);
    for (const file of toDelete) {
      try { await fs.unlink(file.path); deleted++; } catch {}
    }

    return deleted;
  } catch {
    return 0;
  }
}

async function cleanSessionFolder(dir, limits, silent) {
  try {
    await fs.access(dir);
  } catch {
    return 0;
  }

  let deleted = 0;
  for (const [pattern, limit] of Object.entries(limits)) {
    deleted += await cleanupDir(dir, pattern, limit);
  }

  if (!silent && deleted > 0) {
    console.log(chalk.yellow(`  🧹 ${path.basename(dir)}: -${deleted} archivos`));
  }

  return deleted;
}

async function cleanAllSubbotSessions(silent = false) {
  let totalDeleted = 0;
  let foldersProcessed = 0;

  // Limpiar baileys_auth (bot principal)
  if (fsSync.existsSync(BAILEYS_AUTH_DIR)) {
    const d = await cleanSessionFolder(BAILEYS_AUTH_DIR, LIMITS_MAIN, silent);
    totalDeleted += d;
    if (!silent && d > 0) {
      console.log(chalk.yellow(`  🧹 baileys_auth: -${d} archivos`));
    }
  }

  // Limpiar sesiones de subbots
  if (!fsSync.existsSync(SESIONES_DIR)) {
    return { totalDeleted, totalKept: 0, foldersProcessed };
  }

  const entries = await fs.readdir(SESIONES_DIR, { withFileTypes: true });
  const subbots = entries.filter(e => e.isDirectory()).map(e => e.name).sort();

  for (const subbot of subbots) {
    const subbotDir = path.join(SESIONES_DIR, subbot);
    const d = await cleanSessionFolder(subbotDir, LIMITS_SUBBOT, silent);
    totalDeleted += d;
    foldersProcessed++;
  }

  if (!silent && totalDeleted > 0) {
    console.log(chalk.green(`✓ Limpieza total: ${totalDeleted} archivos eliminados de ${foldersProcessed} sesiones`));
  }

  return { totalDeleted, totalKept: 0, foldersProcessed };
}

function startAutoCleanup(intervalMinutes = 30) {
  const intervalMs = intervalMinutes * 60 * 1000;
  console.log(chalk.cyan(`🧹 Limpieza automática activada (cada ${intervalMinutes} minutos)`));

  return setInterval(async () => {
    try {
      await cleanAllSubbotSessions(true);
    } catch (error) {
      console.error(chalk.red('Error en limpieza automática:'), error.message);
    }
  }, intervalMs);
}

module.exports = { cleanAllSubbotSessions, startAutoCleanup };
