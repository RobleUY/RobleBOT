const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

const SESIONES_DIR = path.join(__dirname, 'plugins', 'SUBBOTS', 'SESIONES');

// Archivos esenciales que NO se deben eliminar
const ESSENTIAL_FILES = [
    'creds.json',
    'owner.json',
    'app-state-sync-version-regular_low.json'
];

// Patrones de archivos a eliminar
const PATTERNS_TO_DELETE = [
    /^device-list-.*\.json$/,
    /^session-.*\.json$/,
    /^sender-key-.*\.json$/,
    /^sender-key-memory-.*\.json$/,
    /^lid-mapping-.*\.json$/,
    /^pre-key-\d+\.json$/
];

// Mantener solo las últimas N claves app-state-sync
const MAX_APP_STATE_KEYS = 3;

/**
 * Limpia una carpeta de sesión individual
 */
function cleanSessionFolder(folderPath) {
    if (!fs.existsSync(folderPath)) return { deleted: 0, kept: 0 };

    const files = fs.readdirSync(folderPath);
    let deletedCount = 0;
    let keptCount = 0;

    // Separar archivos app-state-sync-key
    const appStateKeys = files.filter(f => f.startsWith('app-state-sync-key-') && f.endsWith('.json'));
    
    // Ordenar por fecha de modificación (más recientes primero)
    appStateKeys.sort((a, b) => {
        const statA = fs.statSync(path.join(folderPath, a));
        const statB = fs.statSync(path.join(folderPath, b));
        return statB.mtimeMs - statA.mtimeMs;
    });

    // Mantener solo las últimas N claves
    const keysToKeep = appStateKeys.slice(0, MAX_APP_STATE_KEYS);
    const keysToDelete = appStateKeys.slice(MAX_APP_STATE_KEYS);

    files.forEach(file => {
        const filePath = path.join(folderPath, file);
        
        // Saltar si es un directorio
        try {
            if (fs.statSync(filePath).isDirectory()) return;
        } catch (e) {
            return;
        }

        // Mantener archivos esenciales
        if (ESSENTIAL_FILES.includes(file)) {
            keptCount++;
            return;
        }

        // Mantener las claves app-state-sync más recientes
        if (keysToKeep.includes(file)) {
            keptCount++;
            return;
        }

        // Eliminar claves app-state-sync viejas
        if (keysToDelete.includes(file)) {
            try {
                fs.unlinkSync(filePath);
                deletedCount++;
            } catch (err) {
                // Silencioso en limpieza automática
            }
            return;
        }

        // Eliminar archivos que coincidan con los patrones
        const shouldDelete = PATTERNS_TO_DELETE.some(pattern => pattern.test(file));
        
        if (shouldDelete) {
            try {
                fs.unlinkSync(filePath);
                deletedCount++;
            } catch (err) {
                // Silencioso en limpieza automática
            }
        } else {
            keptCount++;
        }
    });

    return { deleted: deletedCount, kept: keptCount };
}

/**
 * Limpia todas las sesiones de subbots
 * @param {boolean} silent - Si es true, no imprime mensajes en consola
 * @returns {Object} Estadísticas de limpieza
 */
function cleanAllSubbotSessions(silent = false) {
    if (!fs.existsSync(SESIONES_DIR)) {
        return { totalDeleted: 0, totalKept: 0, foldersProcessed: 0 };
    }

    const subfolders = fs.readdirSync(SESIONES_DIR).filter(item => {
        const itemPath = path.join(SESIONES_DIR, item);
        try {
            return fs.statSync(itemPath).isDirectory();
        } catch (e) {
            return false;
        }
    });

    let totalDeleted = 0;
    let totalKept = 0;

    subfolders.forEach(folder => {
        const folderPath = path.join(SESIONES_DIR, folder);
        const { deleted, kept } = cleanSessionFolder(folderPath);
        totalDeleted += deleted;
        totalKept += kept;
    });

    if (!silent && totalDeleted > 0) {
        console.log(chalk.yellow(`🧹 Limpieza subbots: ${totalDeleted} archivos eliminados de ${subfolders.length} sesiones`));
    }

    return {
        totalDeleted,
        totalKept,
        foldersProcessed: subfolders.length
    };
}

/**
 * Inicia la limpieza automática periódica
 * @param {number} intervalMinutes - Intervalo en minutos entre limpiezas
 * @returns {NodeJS.Timeout} El intervalo para poder detenerlo si es necesario
 */
function startAutoCleanup(intervalMinutes = 5) {
    const intervalMs = intervalMinutes * 60 * 1000;
    
    console.log(chalk.cyan(`🧹 Limpieza automática de subbots activada (cada ${intervalMinutes} minutos)`));
    
    return setInterval(() => {
        try {
            cleanAllSubbotSessions(true); // silent = true para no saturar logs
        } catch (error) {
            console.error(chalk.red('Error en limpieza automática de subbots:'), error.message);
        }
    }, intervalMs);
}

module.exports = {
    cleanAllSubbotSessions,
    startAutoCleanup
};
