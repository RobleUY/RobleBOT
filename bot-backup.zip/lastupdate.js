// lastupdate.js

/**
 * Módulo para gestionar el timestamp de la última actualización del bot/plugins
 * y calcular el tiempo transcurrido.
 */

// Variable para almacenar el timestamp de la última actualización (ms)
let lastUpdateTimestamp = Date.now();

const LastUpdate = {
    // Retorna el timestamp actual
    getTimestamp: () => lastUpdateTimestamp,

    // Actualiza el timestamp a la hora actual
    updateTimestamp: () => {
        lastUpdateTimestamp = Date.now();
        console.log(`\x1b[35m[LASTUPDATE] Timestamp actualizado a: ${lastUpdateTimestamp}\x1b[0m`);
    },

    /**
     * Convierte el delta de tiempo a formato d h m s (ej: "15d 10h 22m 15s")
     * @param {number} timestamp - El timestamp de referencia.
     * @returns {string} El tiempo transcurrido en formato legible.
     */
    timeSince: (timestamp) => {
        const now = Date.now();
        let delta = now - timestamp;

        const days = Math.floor(delta / (1000 * 60 * 60 * 24));
        delta -= days * (1000 * 60 * 60 * 24);

        const hours = Math.floor(delta / (1000 * 60 * 60));
        delta -= hours * (1000 * 60 * 60);

        const minutes = Math.floor(delta / (1000 * 60));
        delta -= minutes * (1000 * 60);

        const seconds = Math.floor(delta / 1000);

        let result = [];
        if (days > 0) result.push(`${days}d`);
        if (hours > 0) result.push(`${hours}h`);
        if (minutes > 0) result.push(`${minutes}m`);
        // Siempre mostrar segundos si no hay días/horas/minutos, o si es el último componente.
        if (result.length === 0 || seconds > 0) result.push(`${seconds}s`);
        
        return result.slice(0, 4).join(' '); // Tomar hasta 4 unidades
    }
};

module.exports = LastUpdate;