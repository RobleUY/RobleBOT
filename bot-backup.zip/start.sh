#!/bin/bash

RESTART_DELAY=5
MAX_RESTARTS=999999
restarts=0

echo "🤖 RobleBOT Watchdog iniciado"

while [ $restarts -lt $MAX_RESTARTS ]; do
    echo "▶️ Iniciando bot... (reinicio #$restarts)"
    node index.js
    EXIT_CODE=$?
    restarts=$((restarts + 1))

    # Si el exit code es 0, fue un apagado limpio intencional — no reiniciar
    if [ $EXIT_CODE -eq 0 ]; then
        echo "🛑 Bot detenido limpiamente (exit 0). No se reinicia."
        exit 0
    fi

    echo "⚠️ Bot cayó con código $EXIT_CODE. Reiniciando en ${RESTART_DELAY}s... (reinicio #$restarts)"
    sleep $RESTART_DELAY
done

echo "❌ Máximo de reinicios alcanzado."
