/**
 * Sistema de SubBots para RobleBOT
 * Gestiona subbots vinculados mediante código de 8 dígitos
 */

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, DisconnectReason } = require('@whiskeysockets/baileys');
const P = require('pino');
const chalk = require('chalk');

const SUBBOTS_FILE = path.join(__dirname, 'data', 'subbots.json');
const PENDING_CODES_FILE = path.join(__dirname, 'data', 'pending-codes.json');

// Almacena las conexiones activas de subbots
const activeSubbots = new Map();

// Códigos pendientes de vinculación
let pendingCodes = {};

// Cargar códigos pendientes
function loadPendingCodes() {
    try {
        if (fs.existsSync(PENDING_CODES_FILE)) {
            pendingCodes = JSON.parse(fs.readFileSync(PENDING_CODES_FILE, 'utf8'));
            // Limpiar códigos expirados (más de 5 minutos)
            const now = Date.now();
            for (const code in pendingCodes) {
                if (now - pendingCodes[code].createdAt > 300000) {
                    delete pendingCodes[code];
                }
            }
            savePendingCodes();
        }
    } catch (error) {
        console.error(chalk.red('[SubBots] Error cargando códigos pendientes:'), error.message);
        pendingCodes = {};
    }
}

// Guardar códigos pendientes
function savePendingCodes() {
    try {
        const dir = path.dirname(PENDING_CODES_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(PENDING_CODES_FILE, JSON.stringify(pendingCodes, null, 2));
    } catch (error) {
        console.error(chalk.red('[SubBots] Error guardando códigos:'), error.message);
    }
}

// Cargar lista de subbots
function loadSubbots() {
    try {
        if (fs.existsSync(SUBBOTS_FILE)) {
            return JSON.parse(fs.readFileSync(SUBBOTS_FILE, 'utf8'));
        }
    } catch (error) {
        console.error(chalk.red('[SubBots] Error cargando subbots:'), error.message);
    }
    return { subbots: [], mainBotId: null };
}

// Guardar lista de subbots
function saveSubbots(data) {
    try {
        const dir = path.dirname(SUBBOTS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(SUBBOTS_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(chalk.red('[SubBots] Error guardando subbots:'), error.message);
    }
}

// Generar código de 8 dígitos
function generateCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// Crear código de vinculación para subbot
async function createPairingCode(phoneNumber, requestedBy) {
    loadPendingCodes();
    
    // Limpiar número
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    
    // Verificar si ya hay un código pendiente para este número
    for (const code in pendingCodes) {
        if (pendingCodes[code].phoneNumber === cleanNumber) {
            delete pendingCodes[code];
        }
    }
    
    // Generar nuevo código
    const code = generateCode();
    
    // Crear carpeta de auth para el subbot
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    
    try {
        const { state, saveCreds } = await useMultiFileAuthState(authFolder);
        const { version } = await fetchLatestBaileysVersion();
        
        const sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            printQRInTerminal: false,
            browser: ['RobleBOT-Sub', 'Chrome', '4.0.0']
        });
        
        // Esperar a que esté listo para generar código
        await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                reject(new Error('Timeout esperando conexión'));
            }, 30000);
            
            sock.ev.on('connection.update', async (update) => {
                const { connection, qr } = update;
                
                if (connection === 'open') {
                    clearTimeout(timeout);
                    resolve();
                }
            });
        });
        
        // Solicitar código de vinculación
        const pairingCode = await sock.requestPairingCode(cleanNumber);
        
        // Guardar información del código pendiente
        pendingCodes[pairingCode] = {
            phoneNumber: cleanNumber,
            requestedBy,
            createdAt: Date.now(),
            authFolder
        };
        savePendingCodes();
        
        // Manejar eventos de conexión
        sock.ev.on('creds.update', saveCreds);
        
        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;
            
            if (connection === 'open') {
                console.log(chalk.green(`[SubBot] ✓ ${cleanNumber} vinculado exitosamente`));
                
                // Registrar como subbot
                const data = loadSubbots();
                if (!data.subbots.includes(cleanNumber)) {
                    data.subbots.push(cleanNumber);
                    saveSubbots(data);
                }
                
                // Guardar conexión activa
                activeSubbots.set(cleanNumber, sock);
                
                // Limpiar código pendiente
                delete pendingCodes[pairingCode];
                savePendingCodes();
            }
            
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                if (statusCode !== DisconnectReason.loggedOut) {
                    // Reconectar
                    setTimeout(() => connectSubbot(cleanNumber), 5000);
                } else {
                    // Eliminar de subbots
                    removeSubbot(cleanNumber);
                }
            }
        });
        
        return pairingCode;
        
    } catch (error) {
        console.error(chalk.red('[SubBots] Error creando código:'), error.message);
        throw error;
    }
}

// Conectar un subbot existente
async function connectSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    
    if (!fs.existsSync(authFolder)) {
        console.log(chalk.yellow(`[SubBot] No existe auth para ${cleanNumber}`));
        return null;
    }
    
    try {
        const { state, saveCreds } = await useMultiFileAuthState(authFolder);
        const { version } = await fetchLatestBaileysVersion();
        
        const sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            printQRInTerminal: false,
            browser: ['RobleBOT-Sub', 'Chrome', '4.0.0']
        });
        
        sock.ev.on('creds.update', saveCreds);
        
        sock.ev.on('connection.update', (update) => {
            const { connection, lastDisconnect } = update;
            
            if (connection === 'open') {
                console.log(chalk.green(`[SubBot] ✓ ${cleanNumber} conectado`));
                activeSubbots.set(cleanNumber, sock);
            }
            
            if (connection === 'close') {
                activeSubbots.delete(cleanNumber);
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                if (statusCode !== DisconnectReason.loggedOut) {
                    setTimeout(() => connectSubbot(cleanNumber), 10000);
                }
            }
        });
        
        return sock;
        
    } catch (error) {
        console.error(chalk.red(`[SubBot] Error conectando ${cleanNumber}:`), error.message);
        return null;
    }
}

// Eliminar un subbot
function removeSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    
    // Desconectar si está activo
    if (activeSubbots.has(cleanNumber)) {
        const sock = activeSubbots.get(cleanNumber);
        try {
            sock.logout();
        } catch (e) {}
        activeSubbots.delete(cleanNumber);
    }
    
    // Eliminar de la lista
    const data = loadSubbots();
    data.subbots = data.subbots.filter(n => n !== cleanNumber);
    saveSubbots(data);
    
    // Eliminar carpeta de auth
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    if (fs.existsSync(authFolder)) {
        fs.rmSync(authFolder, { recursive: true, force: true });
    }
    
    console.log(chalk.yellow(`[SubBot] ${cleanNumber} eliminado`));
}

// Verificar si un número es subbot
function isSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    const data = loadSubbots();
    return data.subbots.includes(cleanNumber);
}

// Obtener el ID del bot principal
function getMainBotId() {
    if (global.conn && global.conn.user) {
        return global.conn.user.id.split(':')[0].split('@')[0];
    }
    return null;
}

// Verificar si el bot principal está en un grupo
async function isMainBotInGroup(groupJid) {
    try {
        if (!global.conn) return false;
        
        const mainBotId = getMainBotId();
        if (!mainBotId) return false;
        
        const groupMetadata = await global.conn.groupMetadata(groupJid);
        const participants = groupMetadata.participants || [];
        
        return participants.some(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === mainBotId;
        });
    } catch (error) {
        return false;
    }
}

// Verificar si debe responder (prioridad al bot principal)
async function shouldRespond(currentBotNumber, groupJid) {
    const mainBotId = getMainBotId();
    
    // Si es el bot principal, siempre responde
    if (currentBotNumber === mainBotId) {
        return true;
    }
    
    // Si es un subbot, verificar si el bot principal está en el grupo
    if (isSubbot(currentBotNumber)) {
        const mainInGroup = await isMainBotInGroup(groupJid);
        // Si el bot principal está en el grupo, el subbot NO responde
        return !mainInGroup;
    }
    
    return true;
}

// Inicializar subbots al arrancar
async function initializeSubbots() {
    loadPendingCodes();
    const data = loadSubbots();
    
    console.log(chalk.cyan(`[SubBots] Inicializando ${data.subbots.length} subbots...`));
    
    for (const phoneNumber of data.subbots) {
        await connectSubbot(phoneNumber);
        // Esperar un poco entre conexiones
        await new Promise(resolve => setTimeout(resolve, 2000));
    }
}

// Obtener lista de subbots
function getSubbotsList() {
    const data = loadSubbots();
    return data.subbots.map(number => ({
        number,
        active: activeSubbots.has(number)
    }));
}

module.exports = {
    createPairingCode,
    connectSubbot,
    removeSubbot,
    isSubbot,
    getMainBotId,
    isMainBotInGroup,
    shouldRespond,
    initializeSubbots,
    getSubbotsList,
    activeSubbots
};
