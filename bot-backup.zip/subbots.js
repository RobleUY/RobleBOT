/**
 * Sistema de SubBots para RobleBOT
 * Gestiona subbots vinculados mediante código de 8 dígitos
 */

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, DisconnectReason, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const P = require('pino');
const chalk = require('chalk');

const SUBBOTS_FILE = path.join(__dirname, 'data', 'subbots.json');

// Almacena las conexiones activas de subbots
const activeSubbots = new Map();

// Sockets pendientes de vinculación
const pendingSockets = new Map();

// IDs de mensajes procesados por subbots
const processedSubbotMessages = new Set();

// Cargar lista de subbots
function loadSubbots() {
    try {
        if (fs.existsSync(SUBBOTS_FILE)) {
            return JSON.parse(fs.readFileSync(SUBBOTS_FILE, 'utf8'));
        }
    } catch (error) {
        console.error(chalk.red('[SubBots] Error cargando subbots:'), error.message);
    }
    return { subbots: [] };
}

// Guardar lista de subbots
function saveSubbots(data) {
    try {
        const dir = path.dirname(SUBBOTS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(SUBBOTS_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(chalk.red('[SubBots] Error guardando subbots:'), error.message);
    }
}

// Obtener texto del mensaje
function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';
    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    return '';
}

// Crear mensaje compatible para el handler
function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    const message = {
        id: baileyMessage.key.id,
        from: baileyMessage.key.remoteJid,
        key: baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author: baileyMessage.key.participant || baileyMessage.key.remoteJid,
        sender: baileyMessage.key.participant || baileyMessage.key.remoteJid,
        body: getMessageText(baileyMessage),
        isGroup: baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp: baileyMessage.messageTimestamp,
        mentions: baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,
        
        quoted: quotedMessage ? {
            key: {
                remoteJid: baileyMessage.key.remoteJid,
                id: contextInfo.stanzaId,
                participant: contextInfo.participant,
                fromMe: false
            },
            id: contextInfo.stanzaId,
            sender: contextInfo.participant,
            fromMe: false,
            mtype: Object.keys(quotedMessage)[0],
            download: async () => {
                if (quotedMessage.imageMessage) {
                    const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }
                    return buffer;
                } else if (quotedMessage.videoMessage) {
                    const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }
                    return buffer;
                }
                return null;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function() {
            if (!quotedMessage) return null;
            return {
                downloadMedia: async function() {
                    if (quotedMessage.imageMessage) {
                        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
                        let buffer = Buffer.alloc(0);
                        for await (const chunk of stream) {
                            buffer = Buffer.concat([buffer, chunk]);
                        }
                        return { data: buffer, mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg' };
                    } else if (quotedMessage.videoMessage) {
                        const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
                        let buffer = Buffer.alloc(0);
                        for await (const chunk of stream) {
                            buffer = Buffer.concat([buffer, chunk]);
                        }
                        return { data: buffer, mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4' };
                    }
                    return null;
                }
            };
        },

        reply: async function(text, options = {}) {
            try {
                if (!sock || !sock.user) {
                    console.error('Socket subbot no disponible');
                    return;
                }
                await sock.sendMessage(this.from, { text: text, mentions: options.mentions }, { quoted: baileyMessage });
            } catch (error) {
                console.error('Error reply subbot:', error.message);
            }
        },
        
        delete: async function() {
            try {
                if (!sock || !sock.user) return;
                await sock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (error) {
                console.error('Error delete subbot:', error.message);
            }
        }
    };

    return message;
}

// Obtener el ID del bot principal
function getMainBotId() {
    if (global.conn && global.conn.user) {
        return global.conn.user.id.split(':')[0].split('@')[0];
    }
    return null;
}

// Verificar si el bot principal está en un grupo
async function isMainBotInGroup(groupJid) {
    try {
        if (!global.conn) return false;
        
        const mainBotId = getMainBotId();
        if (!mainBotId) return false;
        
        const groupMetadata = await global.conn.groupMetadata(groupJid);
        const participants = groupMetadata.participants || [];
        
        return participants.some(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === mainBotId;
        });
    } catch (error) {
        return false;
    }
}

// Configurar handler de mensajes para un subbot
function setupSubbotMessageHandler(sock, subbotNumber) {
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        for (const baileyMessage of messages) {
            if (!baileyMessage.message) continue;
            
            const messageId = baileyMessage.key.id;
            const uniqueKey = `${subbotNumber}_${messageId}`;
            
            if (processedSubbotMessages.has(uniqueKey)) continue;
            processedSubbotMessages.add(uniqueKey);
            setTimeout(() => processedSubbotMessages.delete(uniqueKey), 20000);
            
            const chatId = baileyMessage.key.remoteJid;
            const isGroup = chatId.endsWith('@g.us');
            
            // PRIORIDAD: Si el bot principal está en el grupo, no responder
            if (isGroup) {
                try {
                    const mainInGroup = await isMainBotInGroup(chatId);
                    if (mainInGroup) continue;
                } catch (e) {
                    console.error('[SubBot] Error verificando bot principal:', e.message);
                }
            }
            
            const isFromMe = baileyMessage.key.fromMe;
            const messageText = getMessageText(baileyMessage);
            const prefixes = ['.', '/', '❤️', '#'];
            const hasPrefix = prefixes.some(p => messageText.startsWith(p));
            
            if (isFromMe && !hasPrefix) continue;
            
            try {
                const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                const senderNumber = sender.split('@')[0];
                
                if (!global.db?.data) continue;
                
                try {
                    await global.db.getUser(senderNumber);
                } catch (error) {
                    continue;
                }
                
                const compatibleMessage = createCompatibleMessage(baileyMessage, sock);
                
                if (global.commandHandler) {
                    await global.commandHandler.handleMessage(compatibleMessage);
                    console.log(chalk.blue(`[SubBot ${subbotNumber}] Comando procesado`));
                }
                
            } catch (error) {
                console.error(`[SubBot ${subbotNumber}] Error:`, error.message);
            }
        }
    });
}

// Crear código de vinculación para subbot
async function createPairingCode(phoneNumber, requestedBy) {
    // Limpiar número - solo dígitos
    let cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    
    console.log(chalk.cyan(`[SubBot] Iniciando vinculación para: ${cleanNumber}`));
    
    // Cerrar socket pendiente anterior
    if (pendingSockets.has(cleanNumber)) {
        try {
            const oldSock = pendingSockets.get(cleanNumber);
            oldSock.ws?.close();
            oldSock.end();
        } catch (e) {}
        pendingSockets.delete(cleanNumber);
    }
    
    // Eliminar de activos si existe
    if (activeSubbots.has(cleanNumber)) {
        try {
            const oldSock = activeSubbots.get(cleanNumber);
            oldSock.ws?.close();
            oldSock.end();
        } catch (e) {}
        activeSubbots.delete(cleanNumber);
    }
    
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    
    // Limpiar auth anterior
    if (fs.existsSync(authFolder)) {
        fs.rmSync(authFolder, { recursive: true, force: true });
    }
    
    return new Promise(async (resolve, reject) => {
        try {
            const { state, saveCreds } = await useMultiFileAuthState(authFolder);
            const { version } = await fetchLatestBaileysVersion();
            
            const sock = makeWASocket({
                version,
                logger: P({ level: 'silent' }),
                auth: {
                    creds: state.creds,
                    keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
                },
                printQRInTerminal: false,
                browser: ['Ubuntu', 'Chrome', '114.0.0'],
                syncFullHistory: false,
                generateHighQualityLinkPreview: false
            });
            
            pendingSockets.set(cleanNumber, sock);
            sock.ev.on('creds.update', saveCreds);
            
            let pairingCodeRequested = false;
            let resolved = false;
            
            // Timeout de 60 segundos
            const timeout = setTimeout(() => {
                if (!resolved) {
                    resolved = true;
                    pendingSockets.delete(cleanNumber);
                    try { sock.end(); } catch(e) {}
                    reject(new Error('Timeout: No se pudo generar el código'));
                }
            }, 60000);
            
            sock.ev.on('connection.update', async (update) => {
                const { connection, lastDisconnect } = update;
                
                console.log(chalk.gray(`[SubBot] Estado conexión: ${connection || 'update'}`));
                
                // Solicitar código cuando el socket esté listo pero antes del QR
                if (!pairingCodeRequested && !sock.authState.creds.registered) {
                    pairingCodeRequested = true;
                    
                    try {
                        // Pequeña espera para asegurar que el socket esté listo
                        await new Promise(r => setTimeout(r, 2000));
                        
                        console.log(chalk.cyan(`[SubBot] Solicitando código para: ${cleanNumber}`));
                        const code = await sock.requestPairingCode(cleanNumber);
                        
                        console.log(chalk.green(`[SubBot] ✓ Código generado: ${code}`));
                        
                        if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            resolve(code);
                        }
                    } catch (err) {
                        console.error(chalk.red(`[SubBot] Error solicitando código:`), err.message);
                        if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            pendingSockets.delete(cleanNumber);
                            reject(err);
                        }
                    }
                }
                
                if (connection === 'open') {
                    console.log(chalk.green(`[SubBot] ✓ ${cleanNumber} conectado exitosamente`));
                    clearTimeout(timeout);
                    
                    // Registrar como subbot
                    const data = loadSubbots();
                    if (!data.subbots.includes(cleanNumber)) {
                        data.subbots.push(cleanNumber);
                        saveSubbots(data);
                    }
                    
                    pendingSockets.delete(cleanNumber);
                    activeSubbots.set(cleanNumber, sock);
                    
                    // Configurar handler de mensajes
                    setupSubbotMessageHandler(sock, cleanNumber);
                }
                
                if (connection === 'close') {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    console.log(chalk.yellow(`[SubBot] ${cleanNumber} desconectado (${statusCode})`));
                    
                    pendingSockets.delete(cleanNumber);
                    
                    // Si ya estaba activo, manejar reconexión
                    if (activeSubbots.has(cleanNumber)) {
                        activeSubbots.delete(cleanNumber);
                        
                        const data = loadSubbots();
                        if (data.subbots.includes(cleanNumber) && statusCode !== DisconnectReason.loggedOut) {
                            setTimeout(() => connectSubbot(cleanNumber), 5000);
                        } else if (statusCode === DisconnectReason.loggedOut) {
                            removeSubbot(cleanNumber);
                        }
                    }
                }
            });
            
        } catch (error) {
            console.error(chalk.red('[SubBots] Error creando socket:'), error.message);
            pendingSockets.delete(cleanNumber);
            if (fs.existsSync(authFolder)) {
                try { fs.rmSync(authFolder, { recursive: true, force: true }); } catch(e) {}
            }
            reject(error);
        }
    });
}

// Conectar un subbot existente
async function connectSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    
    if (!fs.existsSync(authFolder)) {
        console.log(chalk.yellow(`[SubBot] No existe auth para ${cleanNumber}`));
        return null;
    }
    
    if (activeSubbots.has(cleanNumber)) {
        return activeSubbots.get(cleanNumber);
    }
    
    try {
        const { state, saveCreds } = await useMultiFileAuthState(authFolder);
        const { version } = await fetchLatestBaileysVersion();
        
        const sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            printQRInTerminal: false,
            browser: ['Ubuntu', 'Chrome', '114.0.0'],
            syncFullHistory: false
        });
        
        sock.ev.on('creds.update', saveCreds);
        
        sock.ev.on('connection.update', (update) => {
            const { connection, lastDisconnect } = update;
            
            if (connection === 'open') {
                console.log(chalk.green(`[SubBot] ✓ ${cleanNumber} conectado`));
                activeSubbots.set(cleanNumber, sock);
                setupSubbotMessageHandler(sock, cleanNumber);
            }
            
            if (connection === 'close') {
                activeSubbots.delete(cleanNumber);
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                
                if (statusCode === DisconnectReason.loggedOut) {
                    removeSubbot(cleanNumber);
                } else {
                    setTimeout(() => connectSubbot(cleanNumber), 10000);
                }
            }
        });
        
        return sock;
        
    } catch (error) {
        console.error(chalk.red(`[SubBot] Error conectando ${cleanNumber}:`), error.message);
        return null;
    }
}

// Eliminar un subbot
function removeSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    
    if (activeSubbots.has(cleanNumber)) {
        const sock = activeSubbots.get(cleanNumber);
        try { sock.logout(); } catch (e) {}
        activeSubbots.delete(cleanNumber);
    }
    
    if (pendingSockets.has(cleanNumber)) {
        const sock = pendingSockets.get(cleanNumber);
        try { sock.end(); } catch (e) {}
        pendingSockets.delete(cleanNumber);
    }
    
    const data = loadSubbots();
    data.subbots = data.subbots.filter(n => n !== cleanNumber);
    saveSubbots(data);
    
    const authFolder = path.join(__dirname, `baileys_subbot_${cleanNumber}`);
    if (fs.existsSync(authFolder)) {
        try { fs.rmSync(authFolder, { recursive: true, force: true }); } catch(e) {}
    }
    
    console.log(chalk.yellow(`[SubBot] ${cleanNumber} eliminado`));
}

// Verificar si un número es subbot
function isSubbot(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    const data = loadSubbots();
    return data.subbots.includes(cleanNumber);
}

// Verificar si debe responder
async function shouldRespond(currentBotNumber, groupJid) {
    const mainBotId = getMainBotId();
    if (currentBotNumber === mainBotId) return true;
    if (isSubbot(currentBotNumber)) {
        const mainInGroup = await isMainBotInGroup(groupJid);
        return !mainInGroup;
    }
    return true;
}

// Inicializar subbots al arrancar
async function initializeSubbots() {
    const data = loadSubbots();
    
    if (data.subbots.length === 0) {
        console.log(chalk.cyan('[SubBots] No hay subbots registrados'));
        return;
    }
    
    console.log(chalk.cyan(`[SubBots] Inicializando ${data.subbots.length} subbots...`));
    
    for (const phoneNumber of data.subbots) {
        await connectSubbot(phoneNumber);
        await new Promise(resolve => setTimeout(resolve, 3000));
    }
}

// Obtener lista de subbots
function getSubbotsList() {
    const data = loadSubbots();
    return data.subbots.map(number => ({
        number,
        active: activeSubbots.has(number)
    }));
}

// Limpiar cache
setInterval(() => {
    if (processedSubbotMessages.size > 500) {
        processedSubbotMessages.clear();
    }
}, 60000);

module.exports = {
    createPairingCode,
    connectSubbot,
    removeSubbot,
    isSubbot,
    getMainBotId,
    isMainBotInGroup,
    shouldRespond,
    initializeSubbots,
    getSubbotsList,
    activeSubbots
};
