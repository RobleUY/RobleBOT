const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const PREMIUM_FILE = path.join(DATA_DIR, 'usuarios-premium.json');
const MS_PER_DAY = 24 * 60 * 60 * 1000;

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadPremiumData() {
  try {
    ensureDataDir();
    if (!fs.existsSync(PREMIUM_FILE)) {
      const initial = { users: {} };
      fs.writeFileSync(PREMIUM_FILE, JSON.stringify(initial, null, 2), 'utf8');
      return initial;
    }
    const raw = fs.readFileSync(PREMIUM_FILE, 'utf8');
    return JSON.parse(raw || '{"users":{}}');
  } catch (error) {
    console.error('[Premium] Error cargando usuarios premium:', error.message);
    return { users: {} };
  }
}

function savePremiumData(data) {
  try {
    ensureDataDir();
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('[Premium] Error guardando usuarios premium:', error.message);
    return false;
  }
}

function cleanDigits(value) {
  if (!value) return '';
  return value.toString().split('@')[0].split(':')[0].trim().replace(/\.0+$/, '').replace(/[^0-9]/g, '');
}

function normalizeNumber(value) {
  if (!value) return '';
  const rawClean = cleanDigits(value);
  if (!rawClean) return '';
  if (global.db && typeof global.db.getCanonicalId === 'function') {
    return global.db.getCanonicalId(rawClean) || rawClean;
  }
  return rawClean;
}

function getPremiumData() {
  if (!global.__premiumDataCache) {
    global.__premiumDataCache = loadPremiumData();
  }
  return global.__premiumDataCache;
}

function reloadPremiumData() {
  global.__premiumDataCache = loadPremiumData();
  return global.__premiumDataCache;
}

function getPremiumEntry(userId) {
  const data = getPremiumData();

  // 1) Intentar con el canonical ID (camino normal)
  const canonicalId = normalizeNumber(userId);
  if (canonicalId && data.users[canonicalId]) return data.users[canonicalId];

  // 2) Intentar con el raw clean (sin pasar por getCanonicalId)
  //    cubre casos donde el entry fue guardado antes del sistema de aliases
  const rawClean = cleanDigits(userId);
  if (rawClean && rawClean !== canonicalId && data.users[rawClean]) return data.users[rawClean];

  // 3) Búsqueda inversa: recorrer las claves del JSON y ver si alguna es un alias
  //    del userId que se está verificando (cubre LID ↔ teléfono y vice-versa)
  if (global.db && typeof global.db.getCanonicalId === 'function') {
    for (const key of Object.keys(data.users)) {
      const keyCanonical = global.db.getCanonicalId(key) || key;
      if (keyCanonical === canonicalId && key !== canonicalId) {
        return data.users[key];
      }
      // También: el canonical del JSON-key puede ser el rawClean del userId
      if (rawClean && keyCanonical === rawClean && key !== rawClean) {
        return data.users[key];
      }
    }
  }

  return null;
}

function getPremiumSourceFromEntry(entry) {
  if (!entry) return null;
  const source = entry.source;
  if (source === 'free' || source === 'paid' || source === 'mixed') {
    return source;
  }
  return 'paid';
}

function getPremiumSource(userId) {
  const entry = getPremiumEntry(userId);
  if (entry) {
    const source = getPremiumSourceFromEntry(entry);
    if (source) return source;
  }

  const cleanId = normalizeNumber(userId);
  const user = global.db?.getUser?.(cleanId);
  if (user?.premium_free_claimed) return 'free';
  return null;
}

function getPremiumList() {
  const data = getPremiumData();
  const now = Date.now();
  return Object.entries(data.users)
    .map(([userId, entry]) => {
      const expiresAt = Number(entry.expiresAt) || 0;
      const startedAt = entry.startedAt ? Number(entry.startedAt) : null;
      const remainingMs = Math.max(0, expiresAt - now);
      return {
        userId,
        startedAt,
        expiresAt,
        remainingMs,
        active: remainingMs > 0,
        source: getPremiumSourceFromEntry(entry)
      };
    })
    .filter(item => item.active)
    .sort((a, b) => b.remainingMs - a.remainingMs);
}

function getPremiumInfo(userId) {
  const entry = getPremiumEntry(userId);
  const now = Date.now();
  if (!entry || !entry.expiresAt) {
    return { active: false, startedAt: null, expiresAt: null, remainingMs: 0, source: null };
  }
  const expiresAt = Number(entry.expiresAt) || 0;
  const startedAt = entry.startedAt ? Number(entry.startedAt) : null;
  const remainingMs = Math.max(0, expiresAt - now);
  return {
    active: remainingMs > 0,
    startedAt,
    expiresAt,
    remainingMs,
    source: getPremiumSource(userId)
  };
}

function addPremium(userId, months, options = {}) {
  const cleanId = normalizeNumber(userId);
  if (!cleanId || !months || months <= 0) return null;
  const data = getPremiumData();
  const now = Date.now();
  const extraMs = Math.floor(months * 30 * MS_PER_DAY);
  const existingEntry = data.users[cleanId];
  let entry = existingEntry;
  const grantSource = options?.source === 'free' ? 'free' : 'paid';

  if (entry && entry.expiresAt && Number(entry.expiresAt) > now) {
    entry.expiresAt = Number(entry.expiresAt) + extraMs;
    entry.startedAt = Number(entry.startedAt) || now;
  } else {
    entry = {
      startedAt: now,
      expiresAt: now + extraMs
    };
  }

  const currentSource = entry.source || getPremiumSource(cleanId) || (existingEntry ? 'paid' : null);
  const nextSource = currentSource === 'mixed'
    ? 'mixed'
    : (currentSource === 'paid' && grantSource === 'free') || (currentSource === 'free' && grantSource === 'paid')
      ? 'mixed'
      : currentSource || grantSource;

  entry.source = nextSource || grantSource;
  data.users[cleanId] = entry;
  savePremiumData(data);
  return {
    userId: cleanId,
    startedAt: entry.startedAt,
    expiresAt: entry.expiresAt,
    remainingMs: Math.max(0, Number(entry.expiresAt) - now),
    source: entry.source
  };
}

function migratePremiumEntriesToMixed() {
  const data = getPremiumData();
  const entries = Object.entries(data.users || {});
  let migratedCount = 0;

  for (const [userId, entry] of entries) {
    if (!entry || typeof entry !== 'object') continue;
    if (entry.source === 'mixed') {
      migratedCount += 1;
      continue;
    }
    entry.source = 'mixed';
    data.users[userId] = entry;
    migratedCount += 1;
  }

  if (migratedCount > 0) {
    savePremiumData(data);
    global.__premiumDataCache = null;
  }

  return {
    totalEntries: entries.length,
    migratedCount
  };
}

/**
 * Repara el JSON de premium:
 * - Re-normaliza todas las claves al canonical ID actual
 * - Fusiona entradas duplicadas (el que expira más tarde gana)
 * - Elimina entradas inválidas (IDs demasiado cortos < 5 dígitos) o ya expiradas
 * @param {object} options
 * @param {boolean} [options.removeExpired=false] - Si true, elimina también las entradas expiradas
 * @returns {{ fixed: number, merged: number, removed: number, total: number }}
 */
function repairPremiumData(options = {}) {
  const { removeExpired = false } = options;
  const data = loadPremiumData(); // leer directo del disco para no trabajar con caché obsoleta
  const now = Date.now();
  const canonicalMap = {}; // canonicalId → entry más reciente/larga
  let fixed = 0;
  let merged = 0;
  let removed = 0;

  for (const [rawKey, entry] of Object.entries(data.users || {})) {
    if (!entry || typeof entry !== 'object') { removed++; continue; }

    // Filtrar IDs claramente inválidos (menos de 5 dígitos)
    const rawClean = cleanDigits(rawKey);
    if (!rawClean || rawClean.length < 5) { removed++; continue; }

    // Filtrar expiradas si se pidió
    const expiresAt = Number(entry.expiresAt) || 0;
    if (removeExpired && expiresAt <= now) { removed++; continue; }

    // Resolver canonical
    let canonical = rawClean;
    if (global.db && typeof global.db.getCanonicalId === 'function') {
      canonical = global.db.getCanonicalId(rawClean) || rawClean;
    }

    if (canonicalMap[canonical]) {
      // Fusionar: quedarse con el que expira más tarde
      const existing = canonicalMap[canonical];
      if (expiresAt > (Number(existing.expiresAt) || 0)) {
        canonicalMap[canonical] = { ...entry, expiresAt };
      }
      merged++;
    } else {
      canonicalMap[canonical] = { ...entry };
      if (canonical !== rawKey) fixed++;
    }
  }

  data.users = canonicalMap;
  savePremiumData(data);
  global.__premiumDataCache = null;

  return {
    fixed,
    merged,
    removed,
    total: Object.keys(canonicalMap).length
  };
}

function isPremium(userId) {
  return getPremiumInfo(userId).active;
}

function hasPremiumMaxRank(userId) {
  const info = getPremiumInfo(userId);
  return Boolean(info.active && (info.source === 'paid' || info.source === 'mixed'));
}

function getPremiumMultiplier(userId) {
  return isPremium(userId) ? 2 : 1;
}

function formatDateOnly(timestamp) {
  if (!timestamp) return 'N/A';
  const d = new Date(Number(timestamp));
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

function formatRemaining(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

const TOP_MEDALS = {
  1: '🥇', 2: '🥈', 3: '🥉', 4: '4️⃣', 5: '5️⃣',
  6: '6️⃣', 7: '7️⃣', 8: '8️⃣', 9: '9️⃣', 10: '🔟'
};

let _topCoinsCache = [];
let _topCoinsCacheTime = 0;

function getUserMedal(userId) {
  if (!userId || !global.db || typeof global.db.getUniqueUsers !== 'function') return '';
  try {
    const now = Date.now();
    if (now - _topCoinsCacheTime > 30000) {
      const uniqueUsers = global.db.getUniqueUsers();
      const arr = [];
      for (const [uNum, uData] of uniqueUsers.entries()) {
        const total = (Number(uData.money) || 0) + (Number(uData.bank) || 0);
        if (total > 0) arr.push({ userId: uNum, total });
      }
      arr.sort((a, b) => b.total - a.total);
      _topCoinsCache = arr.slice(0, 10).map(x => x.userId);
      _topCoinsCacheTime = now;
    }

    const cleanNum = global.db.cleanNumber ? global.db.cleanNumber(userId) : String(userId).replace(/\D/g, '');
    const canonicalNum = global.db.getCanonicalId ? global.db.getCanonicalId(cleanNum) : cleanNum;

    const idx = _topCoinsCache.findIndex(id => id === cleanNum || id === canonicalNum);
    if (idx >= 0) {
      return TOP_MEDALS[idx + 1] || '';
    }
  } catch (_) {}
  return '';
}

function formatPremiumReply(text, userId = null) {
  if (typeof text !== 'string' || text.trim() === '') return text;
  const trimmed = text.trimStart();
  
  // Si ya tiene estrella premium, retornar tal cual
  if (trimmed.startsWith('★')) return trimmed;
  
  // Primero la estrella premium, luego la medalla si está en top 10
  let result = `★ ${trimmed}`;
  
  // Obtener medalla de top coins si el usuario está en el top 10
  if (userId) {
    const medal = getUserMedal(userId);
    if (medal) {
      // Insertar la medalla entre corchetes después de la estrella y el espacio
      result = `★ [${medal}] ${trimmed}`;
    }
  }
  
  return result;
}

/**
 * Formatea una respuesta agregando la medalla de top coins si corresponde (para usuarios NO premium)
 * @param {string} text - Texto a formatear
 * @param {string} userId - JID del usuario
 * @returns {string} Texto formateado con medalla si está en el top 10
 */
function formatTopCoinsReply(text, userId = null) {
  if (typeof text !== 'string' || text.trim() === '') return text;
  const trimmed = text.trimStart();
  
  // Si ya tiene estrella premium o medalla, retornar tal cual
  if (trimmed.startsWith('★') || /^[🥇🥈🥉4️⃣5️⃣6️⃣7️⃣8️⃣9️⃣🔟]/.test(trimmed) || trimmed.startsWith('[')) {
    return trimmed;
  }
  
  // Obtener medalla de top coins si el usuario está en el top 10
  if (userId) {
    const medal = getUserMedal(userId);
    if (medal) {
      return `[${medal}] ${trimmed}`;
    }
  }
  
  return trimmed;
}

function findNumberByApodo(apodo) {
  if (!apodo) return null;
  const rawStr = apodo.toString().trim();
  const target = rawStr.replace(/^@+/, '').toLowerCase();
  if (!target) return null;

  const numericOnly = target.replace(/[^0-9]/g, '');
  if (numericOnly.length >= 6) {
    return (global.db && typeof global.db.getCanonicalId === 'function')
      ? (global.db.getCanonicalId(numericOnly) || numericOnly)
      : numericOnly;
  }

  if (global.db) {
    if (global.db._userCache) {
      for (const [key, entry] of global.db._userCache.entries()) {
        const u = entry?.obj;
        if (!u) continue;
        const ap = (u.apodo || '').toString().trim().replace(/^@+/, '').toLowerCase();
        const nm = (u.name || '').toString().trim().replace(/^@+/, '').toLowerCase();
        if ((ap && ap !== 'sin apodo' && ap === target) || (nm && nm === target)) {
          const clean = cleanDigits(key);
          return (typeof global.db.getCanonicalId === 'function') ? (global.db.getCanonicalId(clean) || clean) : clean;
        }
      }
    }

    try {
      const rows = global.db._stmts ? global.db._stmts.getAllUsers.all() : [];
      for (const row of rows) {
        try {
          const u = JSON.parse(row.data);
          const ap = (u?.apodo || '').toString().trim().replace(/^@+/, '').toLowerCase();
          const nm = (u?.name || '').toString().trim().replace(/^@+/, '').toLowerCase();
          if ((ap && ap !== 'sin apodo' && ap === target) || (nm && nm === target)) {
            const clean = cleanDigits(row.id);
            return (typeof global.db.getCanonicalId === 'function') ? (global.db.getCanonicalId(clean) || clean) : clean;
          }
        } catch (_) {}
      }
    } catch (_) {}
  }

  return null;
}

module.exports = {
  getPremiumInfo,
  getPremiumList,
  getPremiumSource,
  addPremium,
  migratePremiumEntriesToMixed,
  repairPremiumData,
  isPremium,
  hasPremiumMaxRank,
  getPremiumMultiplier,
  formatPremiumReply,
  formatTopCoinsReply,
  formatDateOnly,
  formatRemaining,
  findNumberByApodo,
  reloadPremiumData
};
