const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const PREMIUM_FILE = path.join(DATA_DIR, 'usuarios-premium.json');
const MS_PER_DAY = 24 * 60 * 60 * 1000;

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadPremiumData() {
  try {
    ensureDataDir();
    if (!fs.existsSync(PREMIUM_FILE)) {
      const initial = { users: {} };
      fs.writeFileSync(PREMIUM_FILE, JSON.stringify(initial, null, 2), 'utf8');
      return initial;
    }
    const raw = fs.readFileSync(PREMIUM_FILE, 'utf8');
    return JSON.parse(raw || '{"users":{}}');
  } catch (error) {
    console.error('[Premium] Error cargando usuarios premium:', error.message);
    return { users: {} };
  }
}

function savePremiumData(data) {
  try {
    ensureDataDir();
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('[Premium] Error guardando usuarios premium:', error.message);
    return false;
  }
}

function normalizeNumber(value) {
  return (value || '').toString().replace(/[^0-9]/g, '');
}

function getPremiumData() {
  if (!global.__premiumDataCache) {
    global.__premiumDataCache = loadPremiumData();
  }
  return global.__premiumDataCache;
}

function reloadPremiumData() {
  global.__premiumDataCache = loadPremiumData();
  return global.__premiumDataCache;
}

function getPremiumEntry(userId) {
  const cleanId = normalizeNumber(userId);
  const data = getPremiumData();
  return data.users[cleanId] || null;
}

function getPremiumList() {
  const data = getPremiumData();
  const now = Date.now();
  return Object.entries(data.users)
    .map(([userId, entry]) => {
      const expiresAt = Number(entry.expiresAt) || 0;
      const startedAt = entry.startedAt ? Number(entry.startedAt) : null;
      const remainingMs = Math.max(0, expiresAt - now);
      return {
        userId,
        startedAt,
        expiresAt,
        remainingMs,
        active: remainingMs > 0
      };
    })
    .filter(item => item.active)
    .sort((a, b) => b.remainingMs - a.remainingMs);
}

function getPremiumInfo(userId) {
  const entry = getPremiumEntry(userId);
  const now = Date.now();
  if (!entry || !entry.expiresAt) {
    return { active: false, startedAt: null, expiresAt: null, remainingMs: 0 };
  }
  const expiresAt = Number(entry.expiresAt) || 0;
  const startedAt = entry.startedAt ? Number(entry.startedAt) : null;
  const remainingMs = Math.max(0, expiresAt - now);
  return {
    active: remainingMs > 0,
    startedAt,
    expiresAt,
    remainingMs
  };
}

function addPremium(userId, months) {
  const cleanId = normalizeNumber(userId);
  if (!cleanId || !months || months <= 0) return null;
  const data = getPremiumData();
  const now = Date.now();
  const extraMs = Math.floor(months * 30 * MS_PER_DAY);
  let entry = data.users[cleanId];
  if (entry && entry.expiresAt && Number(entry.expiresAt) > now) {
    entry.expiresAt = Number(entry.expiresAt) + extraMs;
    entry.startedAt = Number(entry.startedAt) || now;
  } else {
    entry = {
      startedAt: now,
      expiresAt: now + extraMs
    };
  }
  data.users[cleanId] = entry;
  savePremiumData(data);
  return {
    userId: cleanId,
    startedAt: entry.startedAt,
    expiresAt: entry.expiresAt,
    remainingMs: Math.max(0, Number(entry.expiresAt) - now)
  };
}

function isPremium(userId) {
  return getPremiumInfo(userId).active;
}

function getPremiumMultiplier(userId) {
  return isPremium(userId) ? 2 : 1;
}

function formatDateOnly(timestamp) {
  if (!timestamp) return 'N/A';
  const d = new Date(Number(timestamp));
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

function formatRemaining(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function formatPremiumReply(text) {
  if (typeof text !== 'string' || text.trim() === '') return text;
  const trimmed = text.trimStart();
  if (trimmed.startsWith('★')) return trimmed;
  return `★ ${trimmed}`;
}

function findNumberByApodo(apodo) {
  if (!apodo || !global.db || !global.db.data || !global.db.data.users) return null;
  const target = apodo.toString().trim().replace(/^@+/, '').toLowerCase();
  if (!target) return null;
  for (const [num, userData] of Object.entries(global.db.data.users)) {
    const apodoActual = (userData.apodo || '').toString().trim().replace(/^@+/, '').toLowerCase();
    if (!apodoActual || apodoActual === 'sin apodo') continue;
    if (apodoActual === target) return num;
  }
  return null;
}

module.exports = {
  getPremiumInfo,
  getPremiumList,
  addPremium,
  isPremium,
  getPremiumMultiplier,
  formatPremiumReply,
  formatDateOnly,
  formatRemaining,
  findNumberByApodo,
  reloadPremiumData
};
