const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Configuración
const MAX_FILE_SIZE_MB = 300; // Límite de 300 MB para videos
const TEMP_DIR = path.join(__dirname, '.temp');

// Crear directorio temporal si no existe
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

/**
 * Descargar archivo con límite de tamaño
 * @param {string} url - URL del archivo
 * @param {number} maxSizeMB - Tamaño máximo en MB (opcional, por defecto 300MB)
 * @returns {Promise<{buffer: Buffer, size: number, tempFile: string}>}
 */
async function downloadWithLimit(url, maxSizeMB = MAX_FILE_SIZE_MB) {
    const maxBytes = maxSizeMB * 1024 * 1024;
    
    try {
        // Primero hacer HEAD request para verificar el tamaño
        const headResponse = await axios.head(url, { timeout: 10000 }).catch(() => null);
        
        if (headResponse?.headers['content-length']) {
            const contentLength = parseInt(headResponse.headers['content-length']);
            
            if (contentLength > maxBytes) {
                const sizeMB = (contentLength / (1024 * 1024)).toFixed(2);
                throw new Error(`LIMIT_EXCEEDED:${sizeMB}`);
            }
        }

        // Descargar el archivo
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 120000,
            maxContentLength: maxBytes,
            maxBodyLength: maxBytes
        });

        const buffer = Buffer.from(response.data);
        const size = buffer.length;

        // Verificar tamaño después de descargar
        if (size > maxBytes) {
            const sizeMB = (size / (1024 * 1024)).toFixed(2);
            throw new Error(`LIMIT_EXCEEDED:${sizeMB}`);
        }

        // Guardar en archivo temporal
        const tempFileName = `download_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const tempFilePath = path.join(TEMP_DIR, tempFileName);
        
        fs.writeFileSync(tempFilePath, buffer);

        return {
            buffer,
            size,
            tempFile: tempFilePath,
            sizeMB: (size / (1024 * 1024)).toFixed(2)
        };

    } catch (error) {
        if (error.message?.startsWith('LIMIT_EXCEEDED:')) {
            throw error;
        }
        
        if (error.code === 'ERR_FR_MAX_BODY_LENGTH_EXCEEDED') {
            throw new Error(`LIMIT_EXCEEDED:${maxSizeMB}`);
        }
        
        throw error;
    }
}

/**
 * Limpiar archivo temporal
 * @param {string} tempFile - Ruta del archivo temporal
 */
function cleanupTempFile(tempFile) {
    try {
        if (tempFile && fs.existsSync(tempFile)) {
            fs.unlinkSync(tempFile);
        }
    } catch (error) {
        console.error('[downloadUtils] Error limpiando archivo temporal:', error.message);
    }
}

/**
 * Limpiar archivos temporales antiguos (más de 1 hora)
 */
function cleanupOldTempFiles() {
    try {
        if (!fs.existsSync(TEMP_DIR)) return;

        const files = fs.readdirSync(TEMP_DIR);
        const now = Date.now();
        const oneHour = 60 * 60 * 1000;
        let cleaned = 0;

        for (const file of files) {
            const filePath = path.join(TEMP_DIR, file);
            
            try {
                const stats = fs.statSync(filePath);
                const age = now - stats.mtimeMs;

                if (age > oneHour) {
                    fs.unlinkSync(filePath);
                    cleaned++;
                }
            } catch (e) {
                // Ignorar errores en archivos individuales
            }
        }

        if (cleaned > 0) {
            console.log(`[downloadUtils] 🧹 Limpiados ${cleaned} archivos temporales antiguos`);
        }
    } catch (error) {
        console.error('[downloadUtils] Error limpiando archivos antiguos:', error.message);
    }
}

// Limpiar archivos antiguos cada 30 minutos
setInterval(cleanupOldTempFiles, 30 * 60 * 1000);

// Limpiar al iniciar
cleanupOldTempFiles();

module.exports = {
    downloadWithLimit,
    cleanupTempFile,
    cleanupOldTempFiles,
    MAX_FILE_SIZE_MB,
    TEMP_DIR
};
