# 🔄 Cambio de Paquete Baileys

## 📋 Resumen de Cambios

Se ha cambiado el paquete de Baileys de `@whiskeysockets/baileys` a `@fadzzzslebew/baileys` en todo el proyecto.

## 📁 Archivos Modificados

### Archivos Principales
- ✅ `package.json` - Dependencia actualizada
- ✅ `index.js` - Import principal actualizado
- ✅ `messageUtils.js` - Import actualizado

### Plugins Actualizados
- ✅ `plugins/wao.js`
- ✅ `plugins/SUBBOTS/subbot-serbot.js`
- ✅ `plugins/Personajes/personajes.js`
- ✅ `plugins/HERRAMIENTAS/toimg.js`
- ✅ `plugins/HERRAMIENTAS/GRUPOS/grupo-foto.js`
- ✅ `plugins/HERRAMIENTAS/transcribir.js`
- ✅ `plugins/HERRAMIENTAS/tomp3.js`
- ✅ `plugins/HERRAMIENTAS/stickers/sticker.js`
- ✅ `plugins/HERRAMIENTAS/removebg.js`
- ✅ `plugins/HERRAMIENTAS/audio-efectos.js`
- ✅ `plugins/HERRAMIENTAS/grupos-bot-num.js`
- ✅ `plugins/FUTBOL_PJ/jugadores.js`
- ✅ `plugins/DESCARGADORES/threads.js`
- ✅ `plugins/canal-textos.js`
- ✅ `plugins/avisos-bot.js`
- ✅ `plugins/menu backup.zz`

## 🚀 Instrucciones de Instalación

### 1. Desinstalar el paquete antiguo
```bash
npm uninstall @whiskeysockets/baileys
```

### 2. Limpiar cache de npm
```bash
npm cache clean --force
```

### 3. Eliminar node_modules y package-lock.json
```bash
rm -rf node_modules package-lock.json
```

En Windows (PowerShell):
```powershell
Remove-Item -Recurse -Force node_modules, package-lock.json
```

### 4. Instalar dependencias con el nuevo paquete
```bash
npm install
```

### 5. Verificar la instalación
```bash
npm list @fadzzzslebew/baileys
```

Deberías ver algo como:
```
└── @fadzzzslebew/baileys@latest
```

## ⚠️ Notas Importantes

1. **Compatibilidad**: Asegúrate de que `@fadzzzslebew/baileys` sea compatible con tu versión de Node.js

2. **Backup**: Se recomienda hacer un backup completo antes de realizar estos cambios

3. **Testing**: Después de la instalación, prueba las funcionalidades principales:
   - Conexión del bot
   - Envío de mensajes
   - Descarga de medios
   - Stickers
   - Comandos de grupos

4. **package-lock.json**: Este archivo se regenerará automáticamente con las nuevas dependencias

## 🔍 Verificación de Cambios

Para verificar que no queden referencias al paquete antiguo:

```bash
grep -r "@whiskeysockets/baileys" --exclude-dir=node_modules --exclude=package-lock.json .
```

En Windows (PowerShell):
```powershell
Select-String -Path . -Pattern "@whiskeysockets/baileys" -Recurse -Exclude "package-lock.json","node_modules"
```

## 🐛 Troubleshooting

### Error: Cannot find module '@fadzzzslebew/baileys'
- Ejecuta `npm install` nuevamente
- Verifica que el paquete esté en npm: `npm view @fadzzzslebew/baileys`

### Error de compatibilidad
- Verifica la versión de Node.js: `node --version`
- Actualiza Node.js si es necesario

### El bot no se conecta
- Revisa los logs de error
- Verifica que la autenticación esté correcta
- Elimina la carpeta `baileys_auth` y vuelve a escanear el QR

## ✅ Checklist Post-Instalación

- [ ] Paquete antiguo desinstalado
- [ ] Nuevo paquete instalado correctamente
- [ ] Bot se conecta sin errores
- [ ] Comandos básicos funcionan
- [ ] Descarga de medios funciona
- [ ] Stickers funcionan
- [ ] Grupos funcionan correctamente
- [ ] Sub-bots funcionan (si aplica)

---

**Fecha del cambio:** $(date)
**Paquete anterior:** @whiskeysockets/baileys
**Paquete nuevo:** @fadzzzslebew/baileys
