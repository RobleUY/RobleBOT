/**
 * chatHistory.js
 * Historial de chat por grupo — almacenado en data/chats/chats-usuarios.db
 * 
 * Estructura por fila:
 *   group_id    → JID del grupo (ej: 1234567890@g.us)
 *   user_id     → número limpio del usuario (ej: 5491112345678)
 *   history     → texto del historial (últimos 4000 chars, recortado por el frente)
 *   msg_count   → total de mensajes enviados en ese grupo
 *   last_msg_ts → timestamp (ms) del último mensaje en ese grupo
 *
 * Solo se guarda historial de mensajes de GRUPOS.
 * Los mensajes de bot o del propio bot NO se guardan aquí.
 */

'use strict';

const path = require('path');
const fs   = require('fs');

const DATA_DIR  = path.join(__dirname, 'data', 'chats');
const DB_PATH   = path.join(DATA_DIR, 'chats-usuarios.db');
const MAX_CHARS = 4000;

let db = null;

// ── Inicialización ───────────────────────────────────────────────────────────

function init() {
    if (db) return; // ya inicializado

    // Crear carpeta si no existe
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    try {
        const Database = require('better-sqlite3');
        db = new Database(DB_PATH);

        // WAL mode: mejor rendimiento concurrente y .wal / .shm automáticos
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('cache_size = -4096'); // 4 MB de caché

        db.exec(`
            CREATE TABLE IF NOT EXISTS chat_history (
                group_id    TEXT NOT NULL,
                user_id     TEXT NOT NULL,
                history     TEXT NOT NULL DEFAULT '',
                msg_count   INTEGER NOT NULL DEFAULT 0,
                last_msg_ts INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (group_id, user_id)
            )
        `);

        // Índice por grupo para consultas rápidas
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_group ON chat_history (group_id)
        `);

        console.log('[ChatHistory] ✓ Base de datos inicializada en', DB_PATH);
    } catch (err) {
        console.error('[ChatHistory] ❌ Error iniciando DB:', err.message);
        db = null;
    }
}

// ── Helpers internos ─────────────────────────────────────────────────────────

/** Recorta el string para que no supere MAX_CHARS, conservando los últimos chars */
function trimHistory(existing, newText) {
    // Agregar separador solo si ya hay contenido
    const combined = existing
        ? existing + '\n' + newText
        : newText;

    if (combined.length <= MAX_CHARS) return combined;

    // Quedarse con los últimos MAX_CHARS caracteres
    return combined.slice(combined.length - MAX_CHARS);
}

// Statements preparados (lazy, se crean al primer uso)
let stmtGet, stmtUpsert;

function getStmts() {
    if (!db) return null;

    if (!stmtGet) {
        stmtGet = db.prepare(`
            SELECT history, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ? AND user_id = ?
        `);
    }

    if (!stmtUpsert) {
        stmtUpsert = db.prepare(`
            INSERT INTO chat_history (group_id, user_id, history, msg_count, last_msg_ts)
            VALUES (?, ?, ?, 1, ?)
            ON CONFLICT(group_id, user_id) DO UPDATE SET
                history     = excluded.history,
                msg_count   = chat_history.msg_count + 1,
                last_msg_ts = excluded.last_msg_ts
        `);
    }

    return { stmtGet, stmtUpsert };
}

// ── API pública ──────────────────────────────────────────────────────────────

/**
 * Registra un mensaje de un usuario en un grupo.
 * Solo actúa si es un grupo (@g.us).
 * 
 * @param {string} groupId  - JID del grupo
 * @param {string} userId   - número limpio del usuario
 * @param {string} text     - texto del mensaje
 */
function recordMessage(groupId, userId, text) {
    if (!db) init();
    if (!db) return; // falló la inicialización

    if (!groupId || !groupId.endsWith('@g.us')) return;
    if (!userId || !text || typeof text !== 'string') return;

    const cleanText = text.trim();
    if (!cleanText) return;

    try {
        const stmts = getStmts();
        if (!stmts) return;

        const row = stmtGet.get(groupId, userId);
        const existing = row ? row.history : '';
        const newHistory = trimHistory(existing, cleanText);
        const now = Date.now();

        stmtUpsert.run(groupId, userId, newHistory, now);
    } catch (err) {
        console.error('[ChatHistory] Error guardando mensaje:', err.message);
    }
}

/**
 * Obtiene el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 * @returns {{ history: string, msgCount: number, lastMsgTs: number } | null}
 */
function getUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return null;

    try {
        const stmts = getStmts();
        if (!stmts) return null;

        const row = stmtGet.get(groupId, userId);
        if (!row) return null;

        return {
            history:    row.history,
            msgCount:   row.msg_count,
            lastMsgTs:  row.last_msg_ts
        };
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo historial:', err.message);
        return null;
    }
}

/**
 * Obtiene todos los usuarios de un grupo con sus stats.
 * 
 * @param {string} groupId
 * @returns {Array<{ userId: string, msgCount: number, lastMsgTs: number }>}
 */
function getGroupStats(groupId) {
    if (!db) init();
    if (!db) return [];

    try {
        const stmt = db.prepare(`
            SELECT user_id, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ?
            ORDER BY msg_count DESC
        `);
        return stmt.all(groupId).map(r => ({
            userId:    r.user_id,
            msgCount:  r.msg_count,
            lastMsgTs: r.last_msg_ts
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo stats del grupo:', err.message);
        return [];
    }
}

/**
 * Borra el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 */
function clearUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return;

    try {
        db.prepare('DELETE FROM chat_history WHERE group_id = ? AND user_id = ?')
          .run(groupId, userId);
    } catch (err) {
        console.error('[ChatHistory] Error borrando historial:', err.message);
    }
}

/**
 * Cierra la conexión a la base de datos limpiamente.
 * Útil al hacer graceful shutdown.
 */
function close() {
    if (db) {
        try { db.close(); } catch (_) {}
        db = null;
        stmtGet   = null;
        stmtUpsert = null;
    }
}

// Inicializar al cargar el módulo
init();

module.exports = {
    recordMessage,
    getUserHistory,
    getGroupStats,
    clearUserHistory,
    close,
    get isReady() { return !!db; }
};
