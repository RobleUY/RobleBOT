require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
require('./database');
const LastUpdate = require('./lastupdate');
const { backupToGithub } = require('./gitZipUpload');
const { createCompatibleMessage, getMessageText } = require('./messageUtils');

const MuteSystem = require('./muteSystem');
const AutoRewardSystem = require('./autoRewardSystem');
const { getMemoryMonitor } = require('./memoryMonitor');

let sock;
let commandHandler;
let muteSystem;
let autoRewardSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;

global._botStartTime = 0;

global._currentProcessingJid = null;

(function patchConsoleForClosingSession() {
    const _origWarn  = console.warn.bind(console);
    const _origError = console.error.bind(console);

    function cleanSessionForJid(jid) {
        if (!jid) return;
        const authFolder = path.join(__dirname, 'baileys_auth');
        if (!fs.existsSync(authFolder)) return;

        try {
            const userNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
            if (!userNumber || userNumber.length < 5) return;

            const files = fs.readdirSync(authFolder);
            let cleaned = 0;

            for (const file of files) {
                if (file.includes(userNumber)) {
                    try {
                        fs.unlinkSync(path.join(authFolder, file));
                        cleaned++;
                    } catch {}
                }
            }

            if (cleaned > 0) {
                console.log(chalk.yellow(`[Session-Fix] 🔧 ${cleaned} archivo(s) limpiados para ${userNumber}`));
            }
        } catch {}
    }

    function handleClosingSession(args) {

        let jid = null;

        for (const arg of args) {
            if (!arg) continue;
            if (typeof arg === 'string') {

                const match = arg.match(/(\d{10,15})(?:@s\.whatsapp\.net|@g\.us)?/);
                if (match) { jid = match[1]; break; }
            }
        }

        if (!jid && global._currentProcessingJid) {
            jid = global._currentProcessingJid.split('@')[0].split(':')[0].replace(/\D/g, '');
        }

        if (jid) {
            cleanSessionForJid(jid);
        } else {

            _origWarn(chalk.gray(`[Session-Fix] Sesión cerrada — sin JID identificable, omitiendo limpieza`));
        }
    }

    console.warn = function (...args) {
        const first = typeof args[0] === 'string' ? args[0] : '';
        if (first.toLowerCase().includes('closing session') ||
            (typeof args[1] === 'object' && args[1]?._chains !== undefined)) {
            handleClosingSession(args);
            return; 

        }
        _origWarn(...args);
    };

    console.error = function (...args) {
        const first = typeof args[0] === 'string' ? args[0] : '';
        if (first.toLowerCase().includes('closing session') ||
            (typeof args[1] === 'object' && args[1]?._chains !== undefined)) {
            handleClosingSession(args);
            return;
        }
        _origError(...args);
    };
})();

let lastMessageTime = Date.now();
let lastSuccessfulReply = Date.now();
let isConnected = false;

let consecutiveForbiddenErrors = 0;
const MAX_FORBIDDEN_BEFORE_RECONNECT = 3;
let forbiddenReconnectScheduled = false;

const processedMessageIds = new Map();
const MESSAGE_ID_TTL = 60000;   

const MAX_PROCESSED_IDS = 20000; 

const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 15;    
const MAX_BAD_MAC_ENTRIES = 500; 

let cleanupInterval = null;
let badMacCleanupInterval = null;

function startCleanupIntervals() {
    if (cleanupInterval) clearInterval(cleanupInterval);
    if (badMacCleanupInterval) clearInterval(badMacCleanupInterval);

    cleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [id, ts] of processedMessageIds.entries()) {
            if (now - ts > MESSAGE_ID_TTL) processedMessageIds.delete(id);
        }

        if (processedMessageIds.size > MAX_PROCESSED_IDS) {
            const entries = Array.from(processedMessageIds.entries())
                .sort((a, b) => a[1] - b[1]);
            const toDelete = entries.slice(0, processedMessageIds.size - MAX_PROCESSED_IDS);
            toDelete.forEach(([id]) => processedMessageIds.delete(id));
        }

        if (global.gc) global.gc();
    }, MESSAGE_ID_TTL);

    badMacCleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [jid, data] of badMacErrors.entries()) {
            if (now - data.lastError > 1800000) { 
                badMacErrors.delete(jid);
            }
        }

        if (badMacErrors.size > MAX_BAD_MAC_ENTRIES) {
            const entries = Array.from(badMacErrors.entries())
                .sort((a, b) => a[1].lastError - b[1].lastError);
            const toDelete = entries.slice(0, badMacErrors.size - MAX_BAD_MAC_ENTRIES);
            toDelete.forEach(([jid]) => badMacErrors.delete(jid));
        }
    }, 180000);
}

startCleanupIntervals();

let _forceRestartInProgress = false;

async function forceRestart() {
    if (_forceRestartInProgress) return;
    _forceRestartInProgress = true;

    console.log(chalk.red('🔄 Apagando el proceso de Node.js (el watchdog/PM2 lo volverá a levantar en breve)...'));

    try { if (cleanupInterval) clearInterval(cleanupInterval); } catch (e) {}
    try { if (badMacCleanupInterval) clearInterval(badMacCleanupInterval); } catch (e) {}

    // Modificación principal: forzamos el cierre agresivo de los WebSockets
    try {
        if (sock) {
            sock.ev.removeAllListeners();
            if (sock.ws) {
                sock.ws.close(); // Forzar cierre de conexión para evitar que se quede colgado
            }
            sock = null;
        }
    } catch (e) {}

    // Llamada de limpieza de basura de memoria (opcional, ayuda al reinicio)
    if (global.gc) {
        try { global.gc(); } catch (e) {}
    }

    setTimeout(() => {
        console.log(chalk.bgRed.white(' 🛑 FINALIZANDO PROCESO AHORA 🛑 '));
        process.exit(1); // Cierre absoluto del proceso bot.
    }, 1500);
}

async function softReconnect(reason = 'desconocido') {
    if (isReconnecting || forbiddenReconnectScheduled) return;
    forbiddenReconnectScheduled = true;

    console.log(chalk.yellow(`🔄 Reconexión suave por: ${reason}. Reconectando en 3s...`));

    isConnected = false;

    await new Promise(r => setTimeout(r, 3000));

    forbiddenReconnectScheduled = false;
    consecutiveForbiddenErrors = 0;

    try {
        await connectToWhatsApp();
    } catch (e) {
        console.error(chalk.red('Error en softReconnect:'), e.message);
    }
}

async function connectToWhatsApp() {

    let saveCreds;

    try {
        if (sock) {
            try {
                sock.ev.removeAllListeners('connection.update');
                sock.ev.removeAllListeners('creds.update');
                sock.ev.removeAllListeners('messages.upsert');
                sock.ev.removeAllListeners();
                if (sock.ws) sock.ws.close();
                sock = null;
            } catch (e) {
                console.error('Error limpiando socket:', e.message);
            }
        }

        const { state, saveCreds: _saveCreds } = await useMultiFileAuthState('./baileys_auth');
        saveCreds = _saveCreds;

        const { version } = await fetchLatestBaileysVersion();

        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }), 
            auth: {
                creds: state.creds,
                keys: state.keys
            },
            msgRetryCounterCache: new Map(),
            generateHighQualityLinkPreview: true,
            defaultQueryTimeoutMs: 60000,
            browser: ['RobleBOT', 'Chrome', '120.0.0'],
            retryRequestDelayMs: 500,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: true,
            syncFullHistory: false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async () => {
                return undefined;
            }
        });

        const originalGroupMetadata = sock.groupMetadata.bind(sock);
        const MAX_RETRIES = 2;

        sock.groupMetadata = async (jid, retryCount = 0) => {
            try {
                return await originalGroupMetadata(jid);
            } catch (error) {
                const errorCode = error?.data || error?.output?.statusCode;
                if (errorCode !== 403) throw error;

                if (retryCount < MAX_RETRIES) {
                    await new Promise(r => setTimeout(r, 1000 * (retryCount + 1)));
                    return sock.groupMetadata(jid, retryCount + 1);
                }

                throw error;
            }
        };

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };

                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        const originalSendMessage = sock.sendMessage.bind(sock);
        let consecutiveSendErrors = 0;
        let lastErrorTime = 0;
        let rateLimitCount = 0;
        let lastRateLimitTime = 0;

        sock.sendMessage = async (jid, content, options = {}) => {
            try {

                if (jid?.endsWith('@g.us') && saveCreds) {
                    await saveCreds().catch(() => {});
                }

                const result = await originalSendMessage(jid, content, options);

                consecutiveSendErrors = 0;
                consecutiveForbiddenErrors = 0;
                rateLimitCount = 0;
                lastSuccessfulReply = Date.now();
                return result;
            } catch (error) {
                const now = Date.now();
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = error?.message || '';

                if (now - lastErrorTime > 30000) {
                    consecutiveSendErrors = 0;
                }

                lastErrorTime = now;
                consecutiveSendErrors++;

                if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                    rateLimitCount++;
                    const timeSinceLastRateLimit = now - lastRateLimitTime;
                    lastRateLimitTime = now;

                    if (rateLimitCount % 5 === 0 || timeSinceLastRateLimit > 60000) {
                        console.log(chalk.yellow(`⏱️ Rate limit alcanzado (${rateLimitCount} veces)`));
                    }

                    if (rateLimitCount > 10) {
                        console.log(chalk.red(`⚠️ Demasiados rate limits (${rateLimitCount}) - esperando 5s...`));
                        await new Promise(resolve => setTimeout(resolve, 5000));
                    }

                    return null;
                }

                if (errorCode === 403 || errorCode === 401 || errorMsg.includes('forbidden')) {
                    consecutiveForbiddenErrors++;

                    console.log(chalk.yellow(`⚠️ Error ${errorCode || 'forbidden'} al enviar (${consecutiveForbiddenErrors}/${MAX_FORBIDDEN_BEFORE_RECONNECT})`));

                    if (consecutiveForbiddenErrors >= MAX_FORBIDDEN_BEFORE_RECONNECT) {

                        softReconnect(`${consecutiveForbiddenErrors} errores 403/forbidden consecutivos`);
                    }

                    return null;
                }

                if (errorMsg.includes('No sessions') || errorMsg.includes('no sessions')) {
                    if (!options._noSessionRetry) {
                        await new Promise(r => setTimeout(r, 1500));
                        try {
                            return await originalSendMessage(jid, content, { ...options, _noSessionRetry: true });
                        } catch (retryErr) {

                            const userNum = jid.split('@')[0].split(':')[0];
                            const authFolder = path.join(__dirname, 'baileys_auth');
                            if (fs.existsSync(authFolder)) {
                                for (const file of fs.readdirSync(authFolder)) {
                                    if (file.includes(userNum)) {
                                        try { fs.unlinkSync(path.join(authFolder, file)); } catch {}
                                    }
                                }
                            }

                            return null;
                        }
                    }
                    return null;
                }

                if (errorMsg.includes('ECONNRESET') || 
                    errorMsg.includes('ETIMEDOUT') || 
                    errorMsg.includes('ENOTFOUND') ||
                    errorMsg.includes('Connection Closed')) {
                    if (consecutiveSendErrors <= 3) {
                        return null;
                    }
                    console.log(chalk.yellow(`⚠️ Error de red temporal (${consecutiveSendErrors} veces)`));
                    return null;
                }

                if (consecutiveSendErrors <= 3) {
                    console.error(chalk.red(`Error sendMessage [${errorCode}]:`, error.message));
                }
                return null;
            }
        };

        global.conn = sock;

        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        global.LastUpdate = LastUpdate;
        LastUpdate.updateTimestamp();

        if (commandHandler?.destroy) commandHandler.destroy();
        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        if (muteSystem?.destroy) muteSystem.destroy();
        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        if (!global.autoRewardSystem) {
            autoRewardSystem = new AutoRewardSystem();
            autoRewardSystem.start();
            global.autoRewardSystem = autoRewardSystem;
            console.log(chalk.green('✓ Sistema de recompensas automáticas iniciado'));
        } else {
            autoRewardSystem = global.autoRewardSystem;
            console.log(chalk.yellow('⚠️ Sistema de recompensas ya estaba iniciado'));
        }

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules') && !key.includes('SUBBOTS') && !key.includes('messageUtils')) {
                        delete require.cache[key];
                    }
                });

                const NewLastUpdate = require('./lastupdate');
                NewLastUpdate.updateTimestamp();
                global.LastUpdate = NewLastUpdate;

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }

                const Handler = require('./handler');
                if (commandHandler?.destroy) commandHandler.destroy();
                commandHandler = new Handler();
                global.commandHandler = commandHandler;
                console.log(chalk.green('✓ Handler recargado'));

                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    if (muteSystem?.destroy) muteSystem.destroy();
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                }

                if (autoRewardSystem?.stop) autoRewardSystem.stop();
                const NewAutoRewardSystem = require('./autoRewardSystem');
                autoRewardSystem = new NewAutoRewardSystem();
                autoRewardSystem.start();
                global.autoRewardSystem = autoRewardSystem;
                console.log(chalk.green('✓ Sistema de recompensas recargado'));

                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log(chalk.yellow('📱 QR generado'));
                qrcode.generate(qr, { small: true });
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;

                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Sesión con error de auth — limpia manualmente si persiste'));
                    reconnectAttempts = 0;
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    const delay = Math.min(5000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado — reiniciando proceso...'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                console.log(chalk.green('✅ CONECTADO'));

                // --- INICIO LÓGICA DE REINICIO AUTOMÁTICO ---
                // Resetear siempre al conectar para que cada nueva conexión
                // programe su propio reinicio (evita que reconexiones dentro
                // del mismo proceso queden sin timer).
                if (global._restartTimer) {
                    clearInterval(global._restartTimer);
                    global._restartTimer = null;
                }
                if (global._restartCheckInterval) {
                    clearInterval(global._restartCheckInterval);
                    global._restartCheckInterval = null;
                }
                global._scheduledRestart = true;
                // Resetear flag de subbots para que el checkReady espere
                // la reconexión real de los subbots en esta nueva sesión
                global._subBotsAutoReconnected = false;
                console.log(chalk.magenta('⏳ Esperando a que el sistema de SubBots confirme inicio para activar cuenta regresiva...'));

                {
                    const OFFICIAL_GROUP_RESTART = '120363203689229697@g.us';
                    const RESTART_SECONDS = 7200; // 2 horas

                    const checkReady = setInterval(async () => {
                        if (global._subBotsAutoReconnected) {
                            clearInterval(checkReady);
                            global._restartCheckInterval = null;

                            let countdown = RESTART_SECONDS;
                            console.log(chalk.cyan(`🚀 [SISTEMA] RobleBOT y SubBots iniciados al 100%. Reinicio en ${RESTART_SECONDS / 60} min.`));

                            const sentWarnings = new Set();

                            const timer = setInterval(async () => {
                                if (countdown > 0) {
                                    if (countdown % 3000 === 0 && countdown !== RESTART_SECONDS) {
                                        const minLeft = Math.round(countdown / 60);
                                        console.log(chalk.bgYellow.black(` ⏳ [REINICIO] Faltan ${minLeft} minutos para el reinicio automático `));
                                    }

                                    const minutesLeft = countdown / 60;

                                    if (minutesLeft === 1 && !sentWarnings.has(1)) {
                                        sentWarnings.add(1);
                                        console.log(chalk.bgRed.white(` 🔄 [REINICIO] ⚠️ El bot se reiniciará en 1 MINUTO `));
                                        try {
                                            await global.conn?.sendMessage(OFFICIAL_GROUP_RESTART, {
                                                text: '⚠️ *Aviso de reinicio*\n\n🔄 El bot se reiniciará en *1 minuto*.\nEsto es normal, vuelve en unos segundos.'
                                            });
                                        } catch (e) { console.error('[Restart-Warn] Error 1min:', e.message); }
                                    }

                                    countdown--;
                                } else {
                                    clearInterval(timer);
                                    global._restartTimer = null;
                                    console.log(chalk.bgRed.yellow(' 🚨 EJECUTANDO REINICIO DE PROCESO 🚨 '));
                                    try {
                                        await global.conn?.sendMessage(OFFICIAL_GROUP_RESTART, {
                                            text: '🔄 *El bot se está reiniciando ahora...*\n\nVuelve en unos segundos 🕐'
                                        });
                                    } catch (e) { console.error('[Restart-Warn] Error al reiniciar:', e.message); }
                                    
                                    // Aumentado a 3000ms para asegurar el envío en conexiones lentas
                                    setTimeout(() => forceRestart(), 3000); 
                                }
                            }, 1000);
                            global._restartTimer = timer;
                        }
                    }, 5000);
                    global._restartCheckInterval = checkReady;
                }
                // --- FIN LÓGICA REINICIO ---

                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));

                global._botStartTime = Date.now();
                console.log(chalk.gray(`[MSG-FILTER] Ignorando mensajes anteriores a ${new Date(global._botStartTime).toLocaleTimeString()}`))

                if (sock.user?.id) {
                    global.mainBotNumber = sock.user.id.split('@')[0].split(':')[0];
                }

                if (!global._subBotServerStarted) {
                    global._subBotServerStarted = true;
                    try {
                        const { startSubBotServer } = require('./subbotServer');
                        startSubBotServer(25196);
                    } catch (e) {
                        console.error('[SubBotServer] Error al iniciar:', e.message);
                    }
                }

                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;

                consecutiveForbiddenErrors = 0;
                forbiddenReconnectScheduled = false;

                if (!muteSystem) {
                    if (global.muteSystem?.destroy) global.muteSystem.destroy();
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }

                setTimeout(async () => {
                    try {
                        const groupJid = `120363203689229697@g.us`;
                        try {
                            const groupMeta = await sock.groupMetadata(groupJid);
                            if (groupMeta) {
                                console.log('[Bot Principal] Ya está en el grupo oficial');
                            }
                        } catch (e) {
                            await sock.groupAcceptInvite('HaDX5l2tQCz9KJ7lyw7VHv');
                            console.log('[Bot Principal] ✅ Unido al grupo oficial');
                        }
                    } catch (error) {
                        console.error('[Bot Principal] Error uniéndose al grupo:', error.message);
                    }

                    // Unirse al canal oficial
                    try {
                        const CHANNEL_INVITE = '0029VaePMFRGk1Fq0mv6b80Q';
                        const meta = await sock.newsletterMetadata('invite', CHANNEL_INVITE);
                        if (meta?.id) {
                            await sock.newsletterFollow(meta.id);
                            console.log('[Bot Principal] ✅ Siguiendo canal oficial');
                        }
                    } catch (e) {
                        console.error('[Bot Principal] Error siguiendo canal:', e.message);
                    }
                }, 5000);

                try {
                    // Siempre reconectar subbots en cada nueva conexión del bot principal.
                    // _subBotsAutoReconnected se pone en true DESPUÉS de que autoReconnectSubBots
                    // termina, para que el checkReady del reinicio espere a que estén listos.
                    const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
                    autoReconnectSubBots(sock)
                        .then(() => { global._subBotsAutoReconnected = true; })
                        .catch(e => {
                            console.error('[SubBot] Error auto-reconexión:', e.message);
                            // Aunque fallen, marcar como listo para no bloquear el reinicio
                            global._subBotsAutoReconnected = true;
                        });
                } catch (e) {
                    console.error('[SubBot] No se pudo cargar módulo de sub-bots:', e.message);
                    global._subBotsAutoReconnected = true; // No bloquear el reinicio
                }

                if (!global._botsOnlineInterval) {
                    // Heartbeat solo en consola (sin mensajes al grupo oficial)
                    setInterval(() => {
                        const active = (global.subConns || []).filter(c => c?.user);
                        console.log(chalk.bgYellow.black(` ⏳ [HEARTBEAT] Bot principal + ${active.length} subbot(s) activos `));
                    }, 50 * 60 * 1000);

                    global._botsOnlineInterval = true; // Marcar como inicializado
                    console.log(chalk.green('✓ Heartbeat: consola cada 50 min'));
                } else {
                    console.log(chalk.yellow('⚠️ Heartbeat ya estaba activo (reutilizando)'));
                }

                if (!global._subbotsCleanupInterval) {
                    global._subbotsCleanupInterval = setInterval(() => {
                        if (global.subConns && Array.isArray(global.subConns)) {
                            const before = global.subConns.length;
                            global.subConns = global.subConns.filter(c => c && c.user);
                            const after = global.subConns.length;
                            if (before > after) {
                                console.log(chalk.cyan(`🧹 Limpiados ${before - after} subbots desconectados`));
                            }
                        }
                    }, 5 * 60 * 1000);
                    console.log(chalk.green('✓ Limpieza de subbots cada 5 min'));
                }

                console.log(chalk.green('✓ Conectado'));
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;
            if (!isConnected) return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;

                const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
                if (!msgTs || msgTs < global._botStartTime) continue;

                const messageId = baileyMessage.key.id;
                const remoteJid = baileyMessage.key.remoteJid;
                const cacheKey = `${remoteJid}:${messageId}`;

                if (processedMessageIds.has(cacheKey)) continue;
                processedMessageIds.set(cacheKey, Date.now());

                const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;

                global._currentProcessingJid = senderJid;

                if (muteSystem) {
                    const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage);
                    if (wasDeleted) continue;
                }

                const isFromMe = baileyMessage.key.fromMe;
                const messageText = getMessageText(baileyMessage);
                const prefixes = ['.', '/', '❤️', '#'];
                const hasPrefix = prefixes.some(p => messageText.startsWith(p));

                if (isFromMe && !hasPrefix) continue;

                try {
                    const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    const senderNumber = sender.split('@')[0];

                    if (!global.db?.data) {
                        console.error('BD no inicializada');
                        continue;
                    }

                    try {
                        await global.db.getUser(senderNumber);
                    } catch (error) {
                        console.error('Error obteniendo usuario (continuando igual):', error.message);
                    }

                    global.lastBaileyMessage = baileyMessage;
                    const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                    if (!isFromMe && messageText && messageText.trim() && !hasPrefix) {
                        setImmediate(() => {
                            try {
                                const chatId = baileyMessage.key.remoteJid;
                                const chatUsersDir = path.join(__dirname, 'CHATS-USUARIOS', chatId);
                                if (!fs.existsSync(chatUsersDir)) fs.mkdirSync(chatUsersDir, { recursive: true });
                                const userFile = path.join(chatUsersDir, `${senderNumber}.txt`);
                                const timestamp = new Date().toISOString();

                                const ctxInfo = baileyMessage.message?.extendedTextMessage?.contextInfo;
                                const quotedText = ctxInfo?.quotedMessage?.conversation
                                    || ctxInfo?.quotedMessage?.extendedTextMessage?.text
                                    || null;
                                const quotedParticipant = ctxInfo?.participant
                                    ? ctxInfo.participant.split('@')[0].replace(/\D/g, '')
                                    : null;

                                let line;
                                if (quotedText && quotedParticipant) {
                                    const quotedClean = quotedText.trim().slice(0, 200);
                                    line = `[${timestamp}] (respondiendo a ${quotedParticipant}: "${quotedClean}") ${messageText.trim()}\n`;
                                } else {
                                    line = `[${timestamp}] ${messageText.trim()}\n`;
                                }

                                fs.appendFile(userFile, line, 'utf-8', (e) => {
                                    if (e) console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                                });
                            } catch (e) {
                                console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                            }
                        });
                    }

                    if (messageText && hasPrefix) {
                        const usedPrefix = prefixes.find(p => messageText.startsWith(p));
                        if (usedPrefix) {
                            const cmdName = messageText.slice(usedPrefix.length).trim().split(' ')[0].toLowerCase();
                            if (cmdName === 'botsonline' || cmdName === 'subbotsonline') {
                                const chatJid = baileyMessage.key.remoteJid;
                                const officialGroupJid = `120363426476029684@g.us`;
                                if (chatJid === officialGroupJid) {
                                    try {
                                        await sock.sendMessage(officialGroupJid, {
                                            text: '🟢 *Bot principal activo* ✅'
                                        }, { quoted: baileyMessage });
                                    } catch (e) {
                                        console.error('[botsonline] Error:', e.message);
                                    }
                                    continue;
                                }
                            }
                        }
                    }

                    await commandHandler.handleMessage(compatibleMessage);

                } catch (error) {
                    if (error.message?.includes('Bad MAC')) {
                        if (!badMacErrors.has(senderJid)) {
                            badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                        }
                        const errorData = badMacErrors.get(senderJid);
                        errorData.count++;
                        errorData.lastError = Date.now();
                        console.error(chalk.red(`[BAD MAC] ${senderJid} (x${errorData.count}) — ignorado`));
                    } else {
                        console.error('Error proceso mensaje:', error.message);
                    }
                } finally {

                    global._currentProcessingJid = null;
                }            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);

        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));

    const memMonitor = getMemoryMonitor();
    memMonitor.start(5);
    global.memoryMonitor = memMonitor;

    console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
    await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'lastupdate.js', 
        'muteSystem.js',
        'messageUtils.js'
    ], {
        ignored: [/(^|[\/\\])\../, '**/SUBBOTS/**'],
        persistent: true,
        ignoreInitial: true,
        usePolling: true,
        interval: 2000,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));

        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        if (watcher._reloadTimer) {
            clearTimeout(watcher._reloadTimer);
        }
        watcher._reloadTimer = setTimeout(async () => {
            watcher._reloadTimer = null;
            try {
                const fullPath = path.resolve(__dirname, filePath);
                const resolvedPath = require.resolve(fullPath);
                if (require.cache[resolvedPath]) {
                    delete require.cache[resolvedPath];
                }
                await global.reload();
            } catch (error) {
                console.error(chalk.red(`Error reload: ${error.message}`));
            }
        }, 3000);
    });
}

process.on('unhandledRejection', (error) => {
    console.error(chalk.red('Unhandled rejection:'), error);
});

process.on('uncaughtException', (error) => {
    console.error(chalk.red('Uncaught exception:'), error);
    if (!isReconnecting) {
        setTimeout(() => forceRestart(), 5000);
    }
});

startServer();