require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
require('./database');
const LastUpdate = require('./lastupdate');
const { backupToGithub } = require('./gitZipUpload');
const { createCompatibleMessage, getMessageText } = require('./messageUtils');

const MuteSystem = require('./muteSystem');
const AutoRewardSystem = require('./autoRewardSystem');
const { cleanAllSubbotSessions, startAutoCleanup } = require('./subbotSessionCleaner');
const { getMemoryMonitor } = require('./memoryMonitor');

let sock;
let commandHandler;
let muteSystem;
let autoRewardSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;

// Health check
let lastMessageTime = Date.now();
let lastSuccessfulReply = Date.now();
let isConnected = false;

// 🔄 Auto-reconexión por 403s consecutivos
let consecutiveForbiddenErrors = 0;
const MAX_FORBIDDEN_BEFORE_RECONNECT = 3;
let forbiddenReconnectScheduled = false;

// Cache de mensajes procesados (id -> timestamp) - CON LÍMITE
const processedMessageIds = new Map();
const MESSAGE_ID_TTL = 60000;
const MAX_PROCESSED_IDS = 1000;

// Errores BAD MAC - CON LÍMITE
const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 3;
const MAX_BAD_MAC_ENTRIES = 100;

// Referencias a intervalos para poder limpiarlos
let cleanupInterval = null;
let badMacCleanupInterval = null;
let baileysAuthCleanupInterval = null;

function startCleanupIntervals() {
    if (cleanupInterval) clearInterval(cleanupInterval);
    if (badMacCleanupInterval) clearInterval(badMacCleanupInterval);
    if (baileysAuthCleanupInterval) clearInterval(baileysAuthCleanupInterval);

    cleanupInterval = setInterval(() => {
        const now = Date.now();
        
        for (const [id, ts] of processedMessageIds.entries()) {
            if (now - ts > MESSAGE_ID_TTL) processedMessageIds.delete(id);
        }
        
        if (processedMessageIds.size > MAX_PROCESSED_IDS) {
            const entries = Array.from(processedMessageIds.entries())
                .sort((a, b) => a[1] - b[1]);
            const toDelete = entries.slice(0, processedMessageIds.size - MAX_PROCESSED_IDS);
            toDelete.forEach(([id]) => processedMessageIds.delete(id));
        }
        
        if (global.gc) global.gc();
    }, MESSAGE_ID_TTL);

    badMacCleanupInterval = setInterval(() => {
        const now = Date.now();
        
        for (const [jid, data] of badMacErrors.entries()) {
            if (now - data.lastError > 300000) {
                badMacErrors.delete(jid);
            }
        }
        
        if (badMacErrors.size > MAX_BAD_MAC_ENTRIES) {
            const entries = Array.from(badMacErrors.entries())
                .sort((a, b) => a[1].lastError - b[1].lastError);
            const toDelete = entries.slice(0, badMacErrors.size - MAX_BAD_MAC_ENTRIES);
            toDelete.forEach(([jid]) => badMacErrors.delete(jid));
        }
    }, 180000);

    baileysAuthCleanupInterval = setInterval(() => {
        cleanBaileyCache().catch(e => console.error('Error limpieza periódica baileys_auth:', e.message));
    }, 1800000);
}

startCleanupIntervals();

async function cleanBaileyCache() {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        if (!fs.existsSync(authFolder)) return;

        const files = fs.readdirSync(authFolder);
        const now = Date.now();
        let cleaned = 0;

        for (const file of files) {
            if (file.includes('session-') || file.includes('sender-key')) {
                const filePath = path.join(authFolder, file);
                try {
                    const stats = fs.statSync(filePath);
                    const age = now - stats.mtimeMs;
                    if (age > 3600000) {
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }
                } catch (e) {}
            }
        }

        const limits = {
            'pre-key-': 100,
            'device-list-': 20,
            'lid-mapping-': 50
        };

        for (const [prefix, limit] of Object.entries(limits)) {
            const matchingFiles = files
                .filter(f => f.startsWith(prefix) && f.endsWith('.json'))
                .map(f => ({
                    name: f,
                    path: path.join(authFolder, f),
                    mtime: fs.statSync(path.join(authFolder, f)).mtimeMs
                }))
                .sort((a, b) => b.mtime - a.mtime);

            if (matchingFiles.length > limit) {
                const toDelete = matchingFiles.slice(limit);
                for (const file of toDelete) {
                    try {
                        fs.unlinkSync(file.path);
                        cleaned++;
                    } catch (e) {}
                }
            }
        }

        if (cleaned > 0) {
            console.log(chalk.yellow(`🧹 ${cleaned} archivos cache eliminados`));
        }
    } catch (error) {
        console.error(chalk.red('Error limpiando cache:'), error.message);
    }
}

async function resetUserSession(jid) {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        const sessionFiles = fs.readdirSync(authFolder);
        const userNumber = jid.split('@')[0];
        
        for (const file of sessionFiles) {
            if (file.includes(userNumber)) {
                const filePath = path.join(authFolder, file);
                try {
                    fs.unlinkSync(filePath);
                    console.log(chalk.yellow(`🔄 Sesión eliminada: ${userNumber}`));
                } catch (e) {}
            }
        }
        
        badMacErrors.delete(jid);
    } catch (error) {
        console.error(chalk.red('Error reset sesión:'), error.message);
    }
}

async function forceRestart() {
    // Desactivado por solicitud del usuario
    if (isReconnecting) return;
    console.log(chalk.yellow('⏸️ forceRestart desactivado (sin reinicio forzado).'));
}

// 🔄 Reconexión suave: cierra el socket actual y vuelve a conectar SIN borrar credenciales
async function softReconnect(reason = 'desconocido') {
    if (isReconnecting || forbiddenReconnectScheduled) return;
    forbiddenReconnectScheduled = true;

    console.log(chalk.yellow(`🔄 Reconexión suave por: ${reason}. Reconectando en 3s...`));

    // Marcar como desconectado para que no se procesen mensajes viejos
    isConnected = false;

    // Pequeño delay para no reconectar en cascada
    await new Promise(r => setTimeout(r, 3000));

    forbiddenReconnectScheduled = false;
    consecutiveForbiddenErrors = 0;

    try {
        await connectToWhatsApp();
    } catch (e) {
        console.error(chalk.red('Error en softReconnect:'), e.message);
    }
}

async function connectToWhatsApp() {
    try {
        if (sock) {
            try {
                sock.ev.removeAllListeners('connection.update');
                sock.ev.removeAllListeners('creds.update');
                sock.ev.removeAllListeners('messages.upsert');
                sock.ev.removeAllListeners();
                sock = null;
            } catch (e) {
                console.error('Error limpiando socket:', e.message);
            }
        }
        
        const { state, saveCreds } = await useMultiFileAuthState('./baileys_auth');
        const { version } = await fetchLatestBaileysVersion();
        
        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }), 
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            msgRetryCounterCache: new Map(),
            generateHighQualityLinkPreview: true,
            defaultQueryTimeoutMs: 60000,
            browser: ['RobleBOT', 'Chrome', '4.0.0'],
            retryRequestDelayMs: 500,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: true,
            syncFullHistory: false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async () => {
                return undefined;
            }
        });

        // 🛡️ Wrapper seguro para groupMetadata
        const originalGroupMetadata = sock.groupMetadata.bind(sock);
        const failedGroupsCache = new Map();
        const CACHE_DURATION = 30 * 1000;
        const MAX_RETRIES = 2;

        sock.groupMetadata = async (jid, retryCount = 0) => {
            const cachedError = failedGroupsCache.get(jid);
            if (cachedError && (Date.now() - cachedError.timestamp) < CACHE_DURATION) {
                if (cachedError.retries >= MAX_RETRIES) {
                    const error = new Error('Bot sin permisos en este grupo');
                    error.data = 403;
                    error.isBoom = true;
                    throw error;
                }
            }
            
            try {
                const result = await originalGroupMetadata(jid);
                failedGroupsCache.delete(jid);
                return result;
            } catch (error) {
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = error?.message || '';
                
                // Cualquier 403 (incluyendo "forbidden" genérico) puede ser transitorio
                // mientras el socket sincroniza el grupo — reintentar antes de rendirse
                if (errorCode === 403) {
                    if (retryCount < MAX_RETRIES) {
                        console.log(chalk.yellow(`⚠️ groupMetadata 403 en ${jid}, reintentando (${retryCount + 1}/${MAX_RETRIES})...`));
                        await new Promise(r => setTimeout(r, 1500 * (retryCount + 1)));
                        return sock.groupMetadata(jid, retryCount + 1);
                    }
                    // Agotados los reintentos — error permanente
                    console.log(chalk.yellow(`⚠️ Error 403 persistente en grupo ${jid} tras ${MAX_RETRIES} reintentos`));
                    const cached = failedGroupsCache.get(jid) || { retries: 0 };
                    failedGroupsCache.set(jid, { timestamp: Date.now(), retries: cached.retries + 1 });
                    const friendlyError = new Error('Bot sin permisos en este grupo');
                    friendlyError.data = 403;
                    friendlyError.isBoom = true;
                    friendlyError.isGroupPermissionError = true;
                    throw friendlyError;
                }
                
                throw error;
            }
        };

        setInterval(() => {
            const now = Date.now();
            for (const [jid, data] of failedGroupsCache.entries()) {
                if (now - data.timestamp > CACHE_DURATION) {
                    failedGroupsCache.delete(jid);
                }
            }
        }, 60000);

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };
                
                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        // 🛡️ Wrapper mejorado para sendMessage con auto-reconexión por 403
        const originalSendMessage = sock.sendMessage.bind(sock);
        let consecutiveSendErrors = 0;
        let lastErrorTime = 0;
        let rateLimitCount = 0;
        let lastRateLimitTime = 0;
        
        sock.sendMessage = async (jid, content, options = {}) => {
            try {
                const result = await originalSendMessage(jid, content, options);
                // Éxito: resetear TODOS los contadores
                consecutiveSendErrors = 0;
                consecutiveForbiddenErrors = 0;
                rateLimitCount = 0;
                lastSuccessfulReply = Date.now();
                return result;
            } catch (error) {
                const now = Date.now();
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = error?.message || '';
                
                if (now - lastErrorTime > 30000) {
                    consecutiveSendErrors = 0;
                }
                
                lastErrorTime = now;
                consecutiveSendErrors++;
                
                // Rate limit (429)
                if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                    rateLimitCount++;
                    const timeSinceLastRateLimit = now - lastRateLimitTime;
                    lastRateLimitTime = now;
                    
                    if (rateLimitCount % 5 === 0 || timeSinceLastRateLimit > 60000) {
                        console.log(chalk.yellow(`⏱️ Rate limit alcanzado (${rateLimitCount} veces)`));
                    }
                    
                    if (rateLimitCount > 10) {
                        console.log(chalk.red(`⚠️ Demasiados rate limits (${rateLimitCount}) - esperando 5s...`));
                        await new Promise(resolve => setTimeout(resolve, 5000));
                    }
                    
                    return null;
                }
                
                // 🔑 Errores 403/401 — contar y reconectar si se acumulan
                if (errorCode === 403 || errorCode === 401 || errorMsg.includes('forbidden')) {
                    consecutiveForbiddenErrors++;
                    
                    console.log(chalk.yellow(`⚠️ Error ${errorCode || 'forbidden'} al enviar (${consecutiveForbiddenErrors}/${MAX_FORBIDDEN_BEFORE_RECONNECT})`));
                    
                    if (consecutiveForbiddenErrors >= MAX_FORBIDDEN_BEFORE_RECONNECT) {
                        // La sesión perdió autorización para enviar — reconectar
                        softReconnect(`${consecutiveForbiddenErrors} errores 403/forbidden consecutivos`);
                    }
                    
                    return null;
                }
                
                // Errores de red temporales
                if (errorMsg.includes('ECONNRESET') || 
                    errorMsg.includes('ETIMEDOUT') || 
                    errorMsg.includes('ENOTFOUND') ||
                    errorMsg.includes('Connection Closed')) {
                    if (consecutiveSendErrors <= 3) {
                        return null;
                    }
                    console.log(chalk.yellow(`⚠️ Error de red temporal (${consecutiveSendErrors} veces)`));
                    return null;
                }
                
                // Otros errores
                if (consecutiveSendErrors <= 3) {
                    console.error(chalk.red(`Error sendMessage [${errorCode}]:`, error.message));
                }
                return null;
            }
        };

        global.conn = sock;
        
        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        global.LastUpdate = LastUpdate;
        LastUpdate.updateTimestamp();

        if (commandHandler?.destroy) commandHandler.destroy();
        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        if (muteSystem?.destroy) muteSystem.destroy();
        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        if (!global.autoRewardSystem) {
            autoRewardSystem = new AutoRewardSystem();
            autoRewardSystem.start();
            global.autoRewardSystem = autoRewardSystem;
            console.log(chalk.green('✓ Sistema de recompensas automáticas iniciado'));
        } else {
            autoRewardSystem = global.autoRewardSystem;
            console.log(chalk.yellow('⚠️ Sistema de recompensas ya estaba iniciado'));
        }

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules') && !key.includes('SUBBOTS') && !key.includes('messageUtils')) {
                        delete require.cache[key];
                    }
                });
                
                const NewLastUpdate = require('./lastupdate');
                NewLastUpdate.updateTimestamp();
                global.LastUpdate = NewLastUpdate;

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }
                
                const Handler = require('./handler');
                if (commandHandler?.destroy) commandHandler.destroy();
                commandHandler = new Handler();
                global.commandHandler = commandHandler;
                console.log(chalk.green('✓ Handler recargado'));
                
                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    if (muteSystem?.destroy) muteSystem.destroy();
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                }

                if (autoRewardSystem?.stop) autoRewardSystem.stop();
                const NewAutoRewardSystem = require('./autoRewardSystem');
                autoRewardSystem = new NewAutoRewardSystem();
                autoRewardSystem.start();
                global.autoRewardSystem = autoRewardSystem;
                console.log(chalk.green('✓ Sistema de recompensas recargado'));
                
                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log(chalk.yellow('📱 QR generado'));
                qrcode.generate(qr, { small: true });
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;
                
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Limpiando sesión corrupta...'));
                    await cleanBaileyCache();
                    reconnectAttempts = 0;
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    const delay = Math.min(5000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                console.log(chalk.green('✅ CONECTADO'));
                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));
                
                if (sock.user?.id) {
                    global.mainBotNumber = sock.user.id.split('@')[0].split(':')[0];
                }

                if (!global._subBotServerStarted) {
                    global._subBotServerStarted = true;
                    try {
                        const { startSubBotServer } = require('./subbotServer');
                        startSubBotServer(25196);
                    } catch (e) {
                        console.error('[SubBotServer] Error al iniciar:', e.message);
                    }
                }
                
                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;
                
                // Resetear contador de errores forbidden al reconectar exitosamente
                consecutiveForbiddenErrors = 0;
                forbiddenReconnectScheduled = false;
                
                if (!muteSystem) {
                    if (global.muteSystem?.destroy) global.muteSystem.destroy();
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }
                
                await cleanBaileyCache();

                setTimeout(async () => {
                    try {
                        const groupJid = `120363426476029684@g.us`;
                        try {
                            const groupMeta = await sock.groupMetadata(groupJid);
                            if (groupMeta) {
                                console.log('[Bot Principal] Ya está en el grupo oficial');
                            }
                        } catch (e) {
                            await sock.groupAcceptInvite('KwDx3Mgt1FM7heUXKVtFvA');
                            console.log('[Bot Principal] ✅ Unido al grupo oficial');
                        }
                    } catch (error) {
                        console.error('[Bot Principal] Error uniéndose al grupo:', error.message);
                    }
                }, 5000);

                try {
                    if (!global._subBotsAutoReconnected) {
                        global._subBotsAutoReconnected = true;
                        const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
                        autoReconnectSubBots(sock).catch(e => console.error('[SubBot] Error auto-reconexión:', e.message));
                    }
                } catch (e) {
                    console.error('[SubBot] No se pudo cargar módulo de sub-bots:', e.message);
                }

                if (!global._botsOnlineInterval) {
                    const OFFICIAL_GROUP = '120363426476029684@g.us';
                    const sendBotsOnline = async () => {
                        try {
                            if (!global.conn?.user) return;
                            await global.conn.sendMessage(OFFICIAL_GROUP, { text: '🟢 *Bot principal activo* ✅' });
                            const active = (global.subConns || []).filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
                            for (const subSock of active) {
                                await new Promise(r => setTimeout(r, 800));
                                try {
                                    await subSock.sendMessage(OFFICIAL_GROUP, { text: `🤖 *SubBot #${subSock._subNum}* está activo ✅` });
                                } catch (e) {
                                    console.error(`[Heartbeat] Error subbot #${subSock._subNum}:`, e.message);
                                }
                            }
                        } catch (e) {
                            console.error('[Heartbeat] Error:', e.message);
                        }
                    };
                    setTimeout(sendBotsOnline, 15000);
                    global._botsOnlineInterval = setInterval(sendBotsOnline, 30 * 60 * 1000);
                    console.log(chalk.green('✓ Heartbeat de bots activos cada 30 min'));
                } else {
                    console.log(chalk.yellow('⚠️ Heartbeat ya estaba activo (reutilizando)'));
                }
                
                if (!global._subbotsCleanupInterval) {
                    global._subbotsCleanupInterval = setInterval(() => {
                        if (global.subConns && Array.isArray(global.subConns)) {
                            const before = global.subConns.length;
                            global.subConns = global.subConns.filter(c => c && c.user);
                            const after = global.subConns.length;
                            if (before > after) {
                                console.log(chalk.cyan(`🧹 Limpiados ${before - after} subbots desconectados`));
                            }
                        }
                    }, 5 * 60 * 1000);
                    console.log(chalk.green('✓ Limpieza de subbots cada 5 min'));
                }
                
                console.log(chalk.green('✓ Conectado'));
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;
            if (!isConnected) return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;
                
                const messageId = baileyMessage.key.id;
                const remoteJid = baileyMessage.key.remoteJid;
                const cacheKey = `${remoteJid}:${messageId}`;
                
                if (processedMessageIds.has(cacheKey)) continue;
                processedMessageIds.set(cacheKey, Date.now());
                
                const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                
                if (muteSystem) {
                    const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage);
                    if (wasDeleted) continue;
                }
                
                const isFromMe = baileyMessage.key.fromMe;
                const messageText = getMessageText(baileyMessage);
                const prefixes = ['.', '/', '❤️', '#'];
                const hasPrefix = prefixes.some(p => messageText.startsWith(p));
                
                if (isFromMe && !hasPrefix) continue;

                try {
                    const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    const senderNumber = sender.split('@')[0];

                    if (!global.db?.data) {
                        console.error('BD no inicializada');
                        continue;
                    }

                    try {
                        await global.db.getUser(senderNumber);
                    } catch (error) {
                        console.error('Error obteniendo usuario (continuando igual):', error.message);
                    }

                    global.lastBaileyMessage = baileyMessage;
                    const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                    if (!isFromMe && messageText && messageText.trim() && !hasPrefix) {
                        setImmediate(() => {
                            try {
                                const chatId = baileyMessage.key.remoteJid;
                                const chatUsersDir = path.join(__dirname, 'CHATS-USUARIOS', chatId);
                                if (!fs.existsSync(chatUsersDir)) fs.mkdirSync(chatUsersDir, { recursive: true });
                                const userFile = path.join(chatUsersDir, `${senderNumber}.txt`);
                                const timestamp = new Date().toISOString();

                                const ctxInfo = baileyMessage.message?.extendedTextMessage?.contextInfo;
                                const quotedText = ctxInfo?.quotedMessage?.conversation
                                    || ctxInfo?.quotedMessage?.extendedTextMessage?.text
                                    || null;
                                const quotedParticipant = ctxInfo?.participant
                                    ? ctxInfo.participant.split('@')[0].replace(/\D/g, '')
                                    : null;

                                let line;
                                if (quotedText && quotedParticipant) {
                                    const quotedClean = quotedText.trim().slice(0, 200);
                                    line = `[${timestamp}] (respondiendo a ${quotedParticipant}: "${quotedClean}") ${messageText.trim()}\n`;
                                } else {
                                    line = `[${timestamp}] ${messageText.trim()}\n`;
                                }

                                fs.appendFile(userFile, line, 'utf-8', (e) => {
                                    if (e) console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                                });
                            } catch (e) {
                                console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                            }
                        });
                    }

                    if (messageText && hasPrefix) {
                        const usedPrefix = prefixes.find(p => messageText.startsWith(p));
                        if (usedPrefix) {
                            const cmdName = messageText.slice(usedPrefix.length).trim().split(' ')[0].toLowerCase();
                            if (cmdName === 'botsonline' || cmdName === 'subbotsonline') {
                                const chatJid = baileyMessage.key.remoteJid;
                                const officialGroupJid = `120363426476029684@g.us`;
                                if (chatJid === officialGroupJid) {
                                    try {
                                        await sock.sendMessage(officialGroupJid, {
                                            text: '🟢 *Bot principal activo* ✅'
                                        }, { quoted: baileyMessage });
                                    } catch (e) {
                                        console.error('[botsonline] Error:', e.message);
                                    }
                                    continue;
                                }
                            }
                        }
                    }

                    if (hasPrefix) {
                        const cmdName = messageText.split(' ')[0];
                        console.log(chalk.cyan(`[CMD] ${cmdName} de ${senderNumber.substring(0, 10)}...`));
                    }

                    await commandHandler.handleMessage(compatibleMessage);
                    
                } catch (error) {
                    if (error.message?.includes('Bad MAC')) {
                        console.error(chalk.red(`[BAD MAC] ${senderJid}`));
                        
                        if (!badMacErrors.has(senderJid)) {
                            badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                        }
                        
                        const errorData = badMacErrors.get(senderJid);
                        errorData.count++;
                        errorData.lastError = Date.now();
                        
                        if (errorData.count >= BAD_MAC_THRESHOLD) {
                            console.log(chalk.yellow(`🔄 Reset sesión: ${senderJid}`));
                            await resetUserSession(senderJid);
                            
                            const totalBadMac = Array.from(badMacErrors.values())
                                .reduce((acc, v) => acc + v.count, 0);
                            
                            if (totalBadMac > 8) {
                                console.log(chalk.red('⚠️ Demasiados BAD MAC, reiniciando...'));
                                forceRestart();
                            }
                        }
                    } else {
                        console.error('Error proceso mensaje:', error.message);
                    }
                }
            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);
        
        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));

    const memMonitor = getMemoryMonitor();
    memMonitor.start(5);
    global.memoryMonitor = memMonitor;

    console.log(chalk.blue('🧹 Limpiando sesiones de subbots...'));
    try {
        const stats = cleanAllSubbotSessions(false);
        if (stats.totalDeleted > 0) {
            console.log(chalk.green(`✓ ${stats.totalDeleted} archivos innecesarios eliminados de ${stats.foldersProcessed} sesiones`));
        } else {
            console.log(chalk.green('✓ Sesiones de subbots limpias'));
        }
    } catch (error) {
        console.error(chalk.red('Error limpiando sesiones de subbots:'), error.message);
    }

    startAutoCleanup(5);

    console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
    await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));

    console.log(chalk.yellow('🧹 Limpiando cache de baileys_auth...'));
    await cleanBaileyCache();

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'lastupdate.js', 
        'muteSystem.js',
        'messageUtils.js'
    ], {
        ignored: [/(^|[\/\\])\../, '**/SUBBOTS/**'],
        persistent: true,
        ignoreInitial: true,
        usePolling: true,
        interval: 2000,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));
        
        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        try {
            const fullPath = path.resolve(__dirname, filePath);
            const resolvedPath = require.resolve(fullPath);
            if (require.cache[resolvedPath]) {
                delete require.cache[resolvedPath];
            }
            await global.reload();
        } catch (error) {
            console.error(chalk.red(`Error reload: ${error.message}`));
        }
    });
}

process.on('unhandledRejection', (error) => {
    console.error(chalk.red('Unhandled rejection:'), error);
});

process.on('uncaughtException', (error) => {
    console.error(chalk.red('Uncaught exception:'), error);
    if (!isReconnecting) {
        setTimeout(() => forceRestart(), 5000);
    }
});

startServer();