require('dotenv').config();

// ── REDIRECCIÓN DE CARPETA TEMPORAL (ENOSPC FIX) ───────────────────────
// Redirige os.tmpdir() a una carpeta local './tmp' dentro del proyecto.
// Esto evita errores de falta de espacio en la partición '/tmp' del sistema.
const os = require('os');
const path = require('path');
const fs = require('fs');
const localTmpDir = path.join(process.cwd(), 'tmp');
if (!fs.existsSync(localTmpDir)) {
    try {
        fs.mkdirSync(localTmpDir, { recursive: true });
    } catch (e) {
        console.error('[System] Error al crear la carpeta temporal local:', e.message);
    }
}
os.tmpdir = () => localTmpDir;
// ───────────────────────────────────────────────────────────────────────

const http = require('http');
const moment = require('moment-timezone');
const { default: makeWASocket, DisconnectReason, fetchLatestBaileysVersion, Browsers } = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./plugins/SUBBOTS/singleFileAuthState');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
require('./database');
const { backupToGithub } = require('./gitZipUpload');
const { createCompatibleMessage, getMessageText } = require('./messageUtils');
const { tempCleaner } = require('./tempCleaner');

const HEALTH_PORT = process.env.HEALTH_PORT ? parseInt(process.env.HEALTH_PORT, 10) : 24629;

const MuteSystem = require('./muteSystem');
const { initRecordatorios } = require('./plugins/HERRAMIENTAS/recordatorios');
const welcomeGoodbyeModule = require('./plugins/HERRAMIENTAS/bienvenida-despedida');
// Transcripción de audio removida

let sock;
let commandHandler;
let muteSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;
let dailyRestartTimeout = null;

// Configuración para reinicio diario (hora en Uruguay)
const DAILY_RESTART_HOUR_URUGUAY = process.env.DAILY_RESTART_HOUR_URUGUAY ? parseInt(process.env.DAILY_RESTART_HOUR_URUGUAY) : 7;
const DAILY_RESTART_TIMEZONE = 'America/Montevideo';

function scheduleDailyRestartUruguay() {
    try {
        if (dailyRestartTimeout) { clearTimeout(dailyRestartTimeout); dailyRestartTimeout = null; }

        const now = moment.tz(DAILY_RESTART_TIMEZONE);
        let next = now.clone().hour(DAILY_RESTART_HOUR_URUGUAY).minute(0).second(0).millisecond(0);
        if (!next.isAfter(now)) next.add(1, 'day');

        const delay = next.diff(moment());
        console.log(chalk.magenta(`[DailyRestart] Reinicio diario programado en ${next.format('YYYY-MM-DD HH:mm')} ${DAILY_RESTART_TIMEZONE} (${next.utc().format('YYYY-MM-DD HH:mm [UTC]')})`));

        dailyRestartTimeout = setTimeout(async () => {
            try {
                await gracefulDailyRestart();
            } finally {
                // reprogramar para el siguiente día
                scheduleDailyRestartUruguay();
            }
        }, delay);
    } catch (e) {
        console.error('[DailyRestart] Error programando reinicio diario:', e.message);
    }
}

async function gracefulDailyRestart() {
    console.log(chalk.bgYellow.black(' 🔄 Reinicio diario: iniciando cierre limpio...'));

    try {
        // Guardar credenciales del bot principal
        if (global.saveMainCreds && typeof global.saveMainCreds === 'function') {
            try { global.saveMainCreds(); console.log('[DailyRestart] Guardadas credenciales del bot principal'); } catch (e) { console.error('[DailyRestart] Error guardando credenciales principales:', e.message); }
        }

        // Guardar credenciales de subbots
        if (global.subConns && Array.isArray(global.subConns)) {
            for (const c of global.subConns) {
                try {
                    if (c?._saveCreds && typeof c._saveCreds === 'function') {
                        c._saveCreds();
                        console.log(`[DailyRestart] Guardadas credenciales subbot #${c._subNum}`);
                    }
                } catch (e) { console.error('[DailyRestart] Error guardando subbot:', e.message); }
            }
        }

        // Limpieza temporal
        try { await tempCleaner.manualCleanup(); console.log('[DailyRestart] Limpieza temporal completada'); } catch (e) { console.error('[DailyRestart] Error en tempCleaner:', e.message); }

        // Cerrar subbots limpiamente
        if (global.subConns && Array.isArray(global.subConns)) {
            for (const sub of global.subConns) {
                try {
                    if (sub?.ev) sub.ev.removeAllListeners();
                    if (sub?.ws) sub.ws.close();
                    if (sub?._cacheCleanupInterval) clearInterval(sub._cacheCleanupInterval);
                } catch (e) {}
            }
            global.subConns = [];
            console.log('[DailyRestart] Subbots desconectados');
        }

        // Cerrar socket principal
        try {
            if (sock) {
                if (sock.ev) sock.ev.removeAllListeners();
                if (sock.ws) sock.ws.close();
                sock = null;
                console.log('[DailyRestart] Socket principal cerrado');
            }
        } catch (e) { console.error('[DailyRestart] Error cerrando socket principal:', e.message); }

    } catch (e) {
        console.error('[DailyRestart] Error durante cierre limpio:', e.message);
    }

    console.log(chalk.bgYellow.black(' 🔁 Reiniciando proceso para completar reinicio diario...'));
    setTimeout(() => process.exit(1), 1200);
}

global._botStartTime = 0;

global._currentProcessingJid = null;

process.on('unhandledRejection', (reason) => {
    console.error('[Process] Rechazo no manejado:', reason && reason.stack ? reason.stack : reason);
});
process.on('uncaughtException', (error) => {
    console.error('[Process] Excepción no capturada:', error && error.stack ? error.stack : error);
});

(function patchConsoleForClosingSession() {
    const _origWarn  = console.warn.bind(console);
    const _origError = console.error.bind(console);
    const _origLog   = console.log.bind(console);

    function cleanSessionForJid(jid) {
        if (!jid) return;
        const sessionFile = path.join(__dirname, 'main-session.db');
        if (!fs.existsSync(sessionFile)) return;

        try {
            const userNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
            if (!userNumber || userNumber.length < 5) return;

            console.log(chalk.yellow(`[Session-Fix] 🔧 Sesión cerrada para ${userNumber} (archivo .db principal)`));
        } catch {}
    }

    function isSessionEntryArg(arg) {
        if (!arg) return false;
        if (typeof arg === 'string') {
            const lower = arg.toLowerCase();
            return lower.includes('closing session') ||
                lower.includes('sessionentry') ||
                lower.includes('_chains') ||
                lower.includes('registrationid') ||
                lower.includes('currentratchet') ||
                lower.includes('ephemeralkeypair') ||
                lower.includes('basekey') ||
                lower.includes('remoteidentitykey');
        }

        if (typeof arg === 'object') {
            return arg?._chains !== undefined ||
                arg?.currentRatchet !== undefined ||
                arg?.registrationId !== undefined ||
                arg?.pendingPreKey !== undefined;
        }

        return false;
    }

    function shouldHideSessionLog(args) {
        return args.some(isSessionEntryArg);
    }

    function handleClosingSession(args) {
        let jid = null;

        for (const arg of args) {
            if (!arg) continue;
            if (typeof arg === 'string') {
                const match = arg.match(/(\d{10,15})(?:@s\.whatsapp\.net|@g\.us)?/);
                if (match) { jid = match[1]; break; }
            }
        }

        if (!jid && global._currentProcessingJid) {
            jid = global._currentProcessingJid.split('@')[0].split(':')[0].replace(/\D/g, '');
        }

        if (jid) {
            cleanSessionForJid(jid);
        } else {
            _origWarn(chalk.gray(`[Session-Fix] Sesión cerrada — sin JID identificable, omitiendo limpieza`));
        }
    }

    console.warn = function (...args) {
        if (shouldHideSessionLog(args)) {
            handleClosingSession(args);
            return;
        }
        _origWarn(...args);
    };

    console.error = function (...args) {
        if (shouldHideSessionLog(args)) {
            handleClosingSession(args);
            return;
        }
        _origError(...args);
    };

    console.log = function (...args) {
        if (shouldHideSessionLog(args)) {
            return;
        }
        _origLog(...args);
    };

    console.info = function (...args) {
        if (shouldHideSessionLog(args)) {
            return;
        }
        _origLog(...args);
    };
})();

let lastMessageTime = Date.now();
let lastSuccessfulReply = Date.now();
let isConnected = false;

let consecutiveForbiddenErrors = 0;
const MAX_FORBIDDEN_BEFORE_RECONNECT = 3;
let forbiddenReconnectScheduled = false;

const processedMessageIds = new Map();
const MESSAGE_ID_TTL = 60000;   

const MAX_PROCESSED_IDS = 20000; 

const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 15;    
const MAX_BAD_MAC_ENTRIES = 500; 

let cleanupInterval = null;
let badMacCleanupInterval = null;

function startCleanupIntervals() {
    if (cleanupInterval) clearInterval(cleanupInterval);
    if (badMacCleanupInterval) clearInterval(badMacCleanupInterval);

    cleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [id, ts] of processedMessageIds.entries()) {
            if (now - ts > MESSAGE_ID_TTL) processedMessageIds.delete(id);
        }

        if (processedMessageIds.size > MAX_PROCESSED_IDS) {
            const entries = Array.from(processedMessageIds.entries())
                .sort((a, b) => a[1] - b[1]);
            const toDelete = entries.slice(0, processedMessageIds.size - MAX_PROCESSED_IDS);
            toDelete.forEach(([id]) => processedMessageIds.delete(id));
        }

        if (global.gc) global.gc();
    }, MESSAGE_ID_TTL);

    badMacCleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [jid, data] of badMacErrors.entries()) {
            if (now - data.lastError > 1800000) { 
                badMacErrors.delete(jid);
            }
        }

        if (badMacErrors.size > MAX_BAD_MAC_ENTRIES) {
            const entries = Array.from(badMacErrors.entries())
                .sort((a, b) => a[1].lastError - b[1].lastError);
            const toDelete = entries.slice(0, badMacErrors.size - MAX_BAD_MAC_ENTRIES);
            toDelete.forEach(([jid]) => badMacErrors.delete(jid));
        }
    }, 180000);
}

startCleanupIntervals();

// ── LIMPIEZA AL CERRAR EL PROCESO ───────────────────────────────────────
process.on('SIGINT', async () => {
    console.log(chalk.yellow('\n🛑 Recibida señal SIGINT, cerrando bot...'));
    try {
        await tempCleaner.manualCleanup();
        tempCleaner.stopPeriodicCleanup();
    } catch (e) {}
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log(chalk.yellow('\n🛑 Recibida señal SIGTERM, cerrando bot...'));
    try {
        await tempCleaner.manualCleanup();
        tempCleaner.stopPeriodicCleanup();
    } catch (e) {}
    process.exit(0);
});
// ─────────────────────────────────────────────────────────────────────────

let _forceRestartInProgress = false;

async function forceRestart() {
    if (_forceRestartInProgress) return;
    _forceRestartInProgress = true;

    console.log(chalk.red('🔄 Apagando el proceso de Node.js (el watchdog/PM2 lo volverá a levantar en breve)...'));

    // ── LIMPIEZA ANTES DEL REINICIO ─────────────────────────────────────
    try {
        console.log(chalk.blue('[TempCleaner] 🧹 Limpieza final antes del reinicio...'));
        const result = await tempCleaner.manualCleanup();
        if (result.cleaned > 0) {
            console.log(chalk.green(`[TempCleaner] ✅ ${result.cleaned} archivos limpiados antes del reinicio`));
        }
        tempCleaner.stopPeriodicCleanup();
    } catch (error) {
        console.error(chalk.red('[TempCleaner] Error en limpieza final:'), error.message);
    }
    // ─────────────────────────────────────────────────────────────────────

    try { if (cleanupInterval) clearInterval(cleanupInterval); } catch (e) {}
    try { if (badMacCleanupInterval) clearInterval(badMacCleanupInterval); } catch (e) {}

    // ── LIMPIEZA DE SUBBOTS ANTES DEL REINICIO ─────────────────────────────
    console.log(chalk.blue('[SubBots] 🧹 Limpiando subbots antes del reinicio...'));
    if (global.subConns && Array.isArray(global.subConns)) {
        for (const subbot of global.subConns) {
            try {
                if (subbot?.ev) subbot.ev.removeAllListeners();
                if (subbot?.ws) subbot.ws.close();
                if (subbot?._cacheCleanupInterval) clearInterval(subbot._cacheCleanupInterval);
            } catch (e) {}
        }
        global.subConns = [];
        console.log(chalk.green('[SubBots] ✅ Subbots limpiados'));
    }
    // ─────────────────────────────────────────────────────────────────────

    // Modificación principal: forzamos el cierre agresivo de los WebSockets
    try {
        if (sock) {
            sock.ev.removeAllListeners();
            if (sock.ws) {
                sock.ws.close(); // Forzar cierre de conexión para evitar que se quede colgado
            }
            sock = null;
        }
    } catch (e) {}

    // Llamada de limpieza de basura de memoria (opcional, ayuda al reinicio)
    if (global.gc) {
        try { global.gc(); } catch (e) {}
    }

    setTimeout(() => {
        console.log(chalk.bgRed.white(' 🛑 FINALIZANDO PROCESO AHORA 🛑 '));
        process.exit(1); // Cierre absoluto del proceso bot.
    }, 1500);
}

async function softReconnect(reason = 'desconocido') {
    if (isReconnecting || forbiddenReconnectScheduled) return;
    forbiddenReconnectScheduled = true;

    console.log(chalk.yellow(`🔄 Reconexión suave por: ${reason}. Reconectando en 3s...`));

    isConnected = false;

    await new Promise(r => setTimeout(r, 3000));

    forbiddenReconnectScheduled = false;
    consecutiveForbiddenErrors = 0;

    try {
        await connectToWhatsApp();
    } catch (e) {
        console.error(chalk.red('Error en softReconnect:'), e.message);
    }
}

async function connectToWhatsApp() {

    let saveCreds;

    try {
        if (sock) {
            try {
                sock.ev.removeAllListeners('connection.update');
                sock.ev.removeAllListeners('creds.update');
                sock.ev.removeAllListeners('messages.upsert');
                sock.ev.removeAllListeners();
                if (sock.ws) sock.ws.close();
                sock = null;
            } catch (e) {
                console.error('Error limpiando socket:', e.message);
            }
        }

        const { state, saveCreds: _saveCreds } = await useSQLiteAuthState('./main-session.db');
        saveCreds = _saveCreds;
        try { global.saveMainCreds = _saveCreds; } catch (e) {}

        const { version } = await fetchLatestBaileysVersion();

        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }), 
            auth: {
                creds: state.creds,
                keys: state.keys
            },
            msgRetryCounterCache: new Map(),
            generateHighQualityLinkPreview: true,
            defaultQueryTimeoutMs: 60000,
            browser: Browsers.macOS('Desktop'),
            retryRequestDelayMs: 500,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: true,
            syncFullHistory: false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async () => {
                return undefined;
            }
        });

        const originalGroupMetadata = sock.groupMetadata.bind(sock);

        sock.groupMetadata = async (jid) => {
            return await originalGroupMetadata(jid);
        };

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };

                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        const originalSendMessage = sock.sendMessage.bind(sock);
        let consecutiveSendErrors = 0;
        let lastErrorTime = 0;
        let rateLimitCount = 0;
        let lastRateLimitTime = 0;

        sock.sendMessage = async (jid, content, options = {}) => {
            try {

                if (jid?.endsWith('@g.us') && saveCreds) {
                    try {
                        await saveCreds();
                    } catch (e) {
                        // Ignorar errores de saveCreds
                    }
                }

                const result = await originalSendMessage(jid, content, options);

                consecutiveSendErrors = 0;
                consecutiveForbiddenErrors = 0;
                rateLimitCount = 0;
                lastSuccessfulReply = Date.now();
                return result;
            } catch (error) {
                const now = Date.now();
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = error?.message || '';

                if (now - lastErrorTime > 30000) {
                    consecutiveSendErrors = 0;
                }

                lastErrorTime = now;
                consecutiveSendErrors++;

                if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                    rateLimitCount++;
                    const timeSinceLastRateLimit = now - lastRateLimitTime;
                    lastRateLimitTime = now;

                    if (rateLimitCount % 5 === 0 || timeSinceLastRateLimit > 60000) {
                        console.log(chalk.yellow(`⏱️ Rate limit alcanzado (${rateLimitCount} veces)`));
                    }

                    if (rateLimitCount > 10) {
                        console.log(chalk.red(`⚠️ Demasiados rate limits (${rateLimitCount}) - esperando 5s...`));
                        await new Promise(resolve => setTimeout(resolve, 5000));
                    }

                    // Devolver una Promise rechazada en lugar de null
                    return Promise.reject(new Error('Rate limit exceeded'));
                }

                if (errorCode === 403 || errorCode === 401 || errorMsg.includes('forbidden')) {
                    consecutiveForbiddenErrors++;

                    console.log(chalk.yellow(`⚠️ Error ${errorCode || 'forbidden'} al enviar (${consecutiveForbiddenErrors}/${MAX_FORBIDDEN_BEFORE_RECONNECT})`));

                    if (consecutiveForbiddenErrors >= MAX_FORBIDDEN_BEFORE_RECONNECT) {

                        softReconnect(`${consecutiveForbiddenErrors} errores 403/forbidden consecutivos`);
                    }

                    // Devolver una Promise rechazada en lugar de null
                    return Promise.reject(new Error(`Forbidden error: ${errorCode}`));
                }

                if (errorMsg.includes('No sessions') || errorMsg.includes('no sessions')) {
                    if (!options._noSessionRetry) {
                        await new Promise(r => setTimeout(r, 1500));
                        try {
                            return await originalSendMessage(jid, content, { ...options, _noSessionRetry: true });
                        } catch (retryErr) {

                            const userNum = jid.split('@')[0].split(':')[0];
                            const sessionFile = path.join(__dirname, 'main-session.db');
                            // Con el archivo .db no podemos limpiar selectivamente por usuario
                            // como con los archivos individuales de baileys_auth
                            console.log(`[Session-Fix] Usuario ${userNum} - usando archivo .db principal`);

                            return Promise.reject(new Error('No sessions available'));
                        }
                    }
                    return Promise.reject(new Error('No sessions available'));
                }

                if (errorMsg.includes('ECONNRESET') || 
                    errorMsg.includes('ETIMEDOUT') || 
                    errorMsg.includes('ENOTFOUND') ||
                    errorMsg.includes('Connection Closed')) {
                    if (consecutiveSendErrors <= 3) {
                        return Promise.reject(new Error('Network error'));
                    }
                    console.log(chalk.yellow(`⚠️ Error de red temporal (${consecutiveSendErrors} veces)`));
                    return Promise.reject(new Error('Network error'));
                }

                // Baileys a veces devuelve 428 "Precondition Required" con mensaje "Connection Closed"
                if (errorCode === 428 || errorMsg.includes('Precondition Required')) {
                    console.log(chalk.yellow('⚠️ Error 428 (Precondition Required) detectado — aplicando softReconnect')); 
                    try { softReconnect(errorMsg || `statusCode:${errorCode}`); } catch (_) {}
                    return Promise.reject(new Error('Precondition Required'));
                }

                if (consecutiveSendErrors <= 3) {
                    console.error(chalk.red(`Error sendMessage [${errorCode}]:`, error.message));
                }
                return Promise.reject(error);
            }
        };

        global.conn = sock;

        // ── Proxy inteligente para groupMetadata ─────────────────────────────
        // Cuando un plugin llama a global.conn.groupMetadata(jid), este proxy
        // busca automáticamente qué bot (principal o subbot) está en ese grupo
        // y usa el socket correcto. Así todos los plugins funcionan sin cambios.
        const _mainGroupMetadata = sock.groupMetadata.bind(sock);
        global.conn.groupMetadata = async (jid, retryCount = 0) => {
            // Intentar primero con el bot principal
            try {
                return await _mainGroupMetadata(jid);
            } catch (err) {
                const code = err?.data || err?.output?.statusCode;
                // Si no es 403 (forbidden), relanzar — no es un problema de permisos
                if (code !== 403) throw err;

                // 403: el bot principal no está en ese grupo.
                // Buscar un subbot que sí esté.
                const subs = (global.subConns || []).filter(c => c?.user);
                for (const sub of subs) {
                    try {
                        return await sub.groupMetadata(jid);
                    } catch (_) {
                        // Este subbot tampoco está, probar el siguiente
                    }
                }

                // Ningún bot está en el grupo — relanzar el error original
                throw err;
            }
        };

        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        if (commandHandler?.destroy) commandHandler.destroy();
        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        if (muteSystem?.destroy) muteSystem.destroy();
        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        if (welcomeGoodbyeModule?.init) {
            try {
                welcomeGoodbyeModule.init(sock);
                console.log(chalk.green('✓ Bienvenida/Despedida OK'));
            } catch (error) {
                console.error(chalk.red('❌ Error iniciando Bienvenida/Despedida:'), error.message);
            }
        }

        // Inicializar sistema de recordatorios
        try {
            initRecordatorios(sock);
            console.log(chalk.green('✓ Recordatorios OK'));
        } catch (error) {
            console.error(chalk.red('❌ Error inicializando recordatorios:'), error.message);
        }

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules') && !key.includes('SUBBOTS') && !key.includes('messageUtils')) {
                        delete require.cache[key];
                    }
                });

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }

                const Handler = require('./handler');
                if (commandHandler?.destroy) commandHandler.destroy();
                commandHandler = new Handler();
                global.commandHandler = commandHandler;
                console.log(chalk.green('✓ Handler recargado'));

                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    if (muteSystem?.destroy) muteSystem.destroy();
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                }

                // No hay sistema de recompensas automáticas que recargar.

                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log(chalk.yellow('📱 QR generado'));
                qrcode.generate(qr, { small: true });
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;

                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                // Manejo especial para timeouts / errores WebSocket (408, 428, Stream Errored, WebSocket Error)
                const errMsg = String(lastDisconnect?.error?.message || '');
                if (statusCode === 408 || statusCode === 428 || errMsg.includes('WebSocket Error') || errMsg.includes('Stream Errored')) {
                    console.log(chalk.yellow('⚠️ Cierre por WebSocket/timeout detectado — aplicando softReconnect con backoff'));
                    try {
                        await softReconnect(errMsg || `statusCode:${statusCode}`);
                    } catch (e) {
                        console.error(chalk.red('Error al ejecutar softReconnect:'), e.message || e);
                    }
                    return;
                }
                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Sesión con error de auth — limpia manualmente si persiste'));
                    reconnectAttempts = 0;
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    const delay = Math.min(5000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado — reiniciando proceso...'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                console.log(chalk.green('✅ CONECTADO'));

                // ── LIMPIEZA AUTOMÁTICA DE ARCHIVOS TEMPORALES ──────────────
                // Limpiar archivos temporales al conectar y iniciar limpieza periódica
                setTimeout(async () => {
                    try {
                        console.log(chalk.blue('[TempCleaner] 🧹 Iniciando limpieza de archivos temporales...'));
                        const result = await tempCleaner.cleanTempFiles();
                        if (result.cleaned > 0) {
                            const sizeMB = (result.totalSize / (1024 * 1024)).toFixed(2);
                            console.log(chalk.green(`[TempCleaner] ✅ ${result.cleaned} archivos temporales limpiados (${sizeMB} MB liberados)`));
                        }
                        
                        // Iniciar limpieza periódica cada 5 minutos
                        tempCleaner.startPeriodicCleanup(5);
                    } catch (error) {
                        console.error(chalk.red('[TempCleaner] Error en limpieza inicial:'), error.message);
                    }
                }, 3000);
                // ─────────────────────────────────────────────────────────────

                // El reinicio automático del proceso fue desactivado.

                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));

                global._botStartTime = Date.now();
                console.log(chalk.gray(`[MSG-FILTER] Ignorando mensajes anteriores a ${new Date(global._botStartTime).toLocaleTimeString()}`))

                if (sock.user?.id) {
                    global.mainBotNumber = sock.user.id.split('@')[0].split(':')[0];
                }

                if (!global._subBotServerStarted) {
                    global._subBotServerStarted = true;
                    try {
                        const { startSubBotServer } = require('./subbotServer');
                        startSubBotServer(25196);
                    } catch (e) {
                        console.error('[SubBotServer] Error al iniciar:', e.message);
                    }
                }

                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;

                consecutiveForbiddenErrors = 0;
                forbiddenReconnectScheduled = false;

                // Reinicio diario desactivado.
                // if (!muteSystem) {
                if (!muteSystem) {
                    if (global.muteSystem?.destroy) global.muteSystem.destroy();
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }

                // No unir el bot principal al grupo oficial.

                                // ── NUEVO: UNIÓN AUTOMÁTICA AL CANAL DE WHATSAPP ─────────────────
                setTimeout(async () => {
                    try {
                        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
                        const inviteCode = channelUrl.split('/').pop();
                        
                        if (inviteCode) {
                            console.log(chalk.blue(`[Canal] 🔍 Buscando ID para el canal público...`));
                            
                            // Obtiene los metadatos reales usando el código del enlace
                            const metadata = await sock.newsletterMetadata('invite', inviteCode);
                            
                            if (metadata && metadata.id) {
                                const channelJid = metadata.id;
                                console.log(chalk.blue(`[Canal] 🆔 ID detectado: ${channelJid}`));

                                // El bot sigue al canal de WhatsApp
                                await sock.newsletterFollow(channelJid);
                                console.log(chalk.green('[Canal] ✅ Bot siguiendo el canal exitosamente.'));
                            }
                        }
                    } catch (error) {
                        // Filtra el falso error de Baileys v7 si la suscripción ya está activa
                        if (error.message?.includes('unexpected response structure')) {
                            console.log(chalk.green('[Canal] ✅ Bot ya sigue el canal (confirmado).'));
                        } else {
                            // Muestra en rojo si es un error real diferente
                            console.error(chalk.red('[Canal] ❌ Error real al seguir el canal:'), error.message);
                        }
                    }
                }, 8000); // Se ejecuta a los 8 segundos para no colapsar la conexión inicial
                // ─────────────────────────────────────────────────────────────────

                try {
                    // Siempre reconectar subbots en cada nueva conexión del bot principal.
                    const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
                    autoReconnectSubBots(sock).catch(e => {
                        console.error('[SubBot] Error auto-reconexión:', e.message);
                    });
                } catch (e) {
                    console.error('[SubBot] No se pudo cargar módulo de sub-bots:', e.message);
                }

                if (!global._botsOnlineInterval) {
                    // Heartbeat solo en consola (sin mensajes al grupo oficial)
                    setInterval(() => {
                        const active = (global.subConns || []).filter(c => c?.user);
                        console.log(chalk.bgYellow.black(` ⏳ [HEARTBEAT] Bot principal + ${active.length} subbot(s) activos `));
                    }, 50 * 60 * 1000);

                    global._botsOnlineInterval = true; // Marcar como inicializado
                    console.log(chalk.green('✓ Heartbeat: consola cada 50 min'));
                } else {
                    console.log(chalk.yellow('⚠️ Heartbeat ya estaba activo (reutilizando)'));
                }

                if (!global._subbotsCleanupInterval) {
                    global._subbotsCleanupInterval = setInterval(() => {
                        if (global.subConns && Array.isArray(global.subConns)) {
                            const before = global.subConns.length;
                            global.subConns = global.subConns.filter(c => c && c.user);
                            const after = global.subConns.length;
                            if (before > after) {
                                console.log(chalk.cyan(`🧹 Limpiados ${before - after} subbots desconectados`));
                            }
                        }
                    }, 5 * 60 * 1000);
                    console.log(chalk.green('✓ Limpieza de subbots cada 5 min'));
                }

                console.log(chalk.green('✓ Conectado'));
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;
            if (!isConnected) return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;

                const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
                if (!msgTs || msgTs < global._botStartTime) continue;

                const messageId = baileyMessage.key.id;
                const remoteJid = baileyMessage.key.remoteJid;
                const cacheKey = `${remoteJid}:${messageId}`;

                if (processedMessageIds.has(cacheKey)) continue;
                processedMessageIds.set(cacheKey, Date.now());

                const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;

                global._currentProcessingJid = senderJid;

                // Chat logging removido

                if (muteSystem) {
                    const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage);
                    if (wasDeleted) continue;
                }

                const isFromMe = baileyMessage.key.fromMe;
                const messageText = getMessageText(baileyMessage);
                const prefixes = ['.', '/', '❤️', '#'];
                const hasPrefix = prefixes.some(p => messageText.startsWith(p));

                if (isFromMe && !hasPrefix) continue;

                try {
                    const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    const senderNumber = sender.split('@')[0];

                    if (!global.db?.data) {
                        console.error('BD no inicializada');
                        continue;
                    }

                    try {
                        await global.db.getUser(senderNumber);
                    } catch (error) {
                        console.error('Error obteniendo usuario (continuando igual):', error.message);
                    }

                    // ── Registro de actividad por usuario/grupo ──────────────────────────
                    // Solo registrar en grupos (remoteJid termina en @g.us)
                    // y solo si el mensaje no es del propio bot
                    if (!isFromMe && remoteJid && remoteJid.endsWith('@g.us')) {
                        try {
                            if (!global.db.data.groupActivity) {
                                global.db.data.groupActivity = {};
                            }
                            if (!global.db.data.groupActivity[remoteJid]) {
                                global.db.data.groupActivity[remoteJid] = {};
                            }
                            const cleanSender = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');
                            if (cleanSender) {
                                // Guardar último mensaje como objeto { last, count } o timestamp legacy
                                const prev = global.db.data.groupActivity[remoteJid][cleanSender];
                                const prevCount = (prev && typeof prev === 'object') ? (prev.count || 0) : 0;
                                global.db.data.groupActivity[remoteJid][cleanSender] = {
                                    last: Date.now(),
                                    count: prevCount + 1
                                };
                                // Contador total de mensajes del grupo
                                if (!global.db.data.groupActivity[remoteJid].__total) {
                                    global.db.data.groupActivity[remoteJid].__total = 0;
                                }
                                global.db.data.groupActivity[remoteJid].__total++;
                                global.db.save();
                            }
                        } catch (actErr) {
                            // No interrumpir el flujo principal si falla el registro
                        }
                    }
                    // ────────────────────────────────────────────────────────────────────

                    // Transcripción automática removida

                    global.lastBaileyMessage = baileyMessage;
                    const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                    if (messageText && hasPrefix) {
                        const usedPrefix = prefixes.find(p => messageText.startsWith(p));
                        if (usedPrefix) {
                            const cmdName = messageText.slice(usedPrefix.length).trim().split(' ')[0].toLowerCase();
                            if (cmdName === 'botsonline' || cmdName === 'subbotsonline') {
                                const chatJid = baileyMessage.key.remoteJid;
                                const officialGroupJid = `120363426476029684@g.us`;
                                if (chatJid === officialGroupJid) {
                                    try {
                                        await sock.sendMessage(officialGroupJid, {
                                            text: '🟢 *Bot principal activo* ✅'
                                        }, { quoted: baileyMessage });
                                    } catch (e) {
                                        console.error('[botsonline] Error:', e.message);
                                    }
                                    continue;
                                }
                            }
                        }
                    }

                    await commandHandler.handleMessage(compatibleMessage);

                } catch (error) {
                    if (error.message?.includes('Bad MAC')) {
                        if (!badMacErrors.has(senderJid)) {
                            badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                        }
                        const errorData = badMacErrors.get(senderJid);
                        errorData.count++;
                        errorData.lastError = Date.now();
                        console.error(chalk.red(`[BAD MAC] ${senderJid} (x${errorData.count}) — ignorado`));
                    } else {
                        console.error('Error proceso mensaje:', error.message);
                    }
                } finally {

                    global._currentProcessingJid = null;
                }            }
        });

        sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
            if (!isConnected) return;
            // Solo nos interesan promote y demote (cambios de admin)
            if (action !== 'promote' && action !== 'demote') return;

            try {
                const groupMeta = await sock.groupMetadata(id).catch(() => null);
                const groupName = groupMeta?.subject || id;

                for (const participantJid of participants) {
                    const targetNum = participantJid.split('@')[0].split(':')[0];
                    const targetTag = `@${targetNum}`;

                    let msg;
                    if (action === 'promote') {
                        msg = `👑 *${targetTag} ahora es administrador del grupo*`;
                    } else {
                        msg = `👤 *${targetTag} ya no es administrador del grupo*`;
                    }

                    await sock.sendMessage(id, {
                        text: msg,
                        mentions: [participantJid]
                    });
                }
            } catch (e) {
                // silencioso
            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);

        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

function formatDuration(ms) {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours}h ${minutes}m ${seconds}s`;
}

function getActiveSubbotsCount() {
    return new Promise((resolve) => {
        const request = http.get('http://june.hidencloud.com:25196/subbots/list', (resp) => {
            let body = '';

            resp.on('data', (chunk) => {
                body += chunk.toString();
            });

            resp.on('end', () => {
                try {
                    const parsed = JSON.parse(body);
                    if (typeof parsed.total === 'number') {
                        return resolve(parsed.total);
                    }
                    if (Array.isArray(parsed.subbots)) {
                        return resolve(parsed.subbots.length);
                    }
                } catch (e) {
                    // Ignorar parseo inválido y dejar subbots como no disponible
                }
                resolve(null);
            });
        });

        request.on('error', () => resolve(null));
        request.setTimeout(3000, () => {
            request.destroy();
            resolve(null);
        });
    });
}

function startHealthServer() {
    const server = http.createServer(async (req, res) => {
        const active = isConnected === true;
        const uptimeMs = active ? Date.now() - (global._botStartTime || 0) : 0;
        const uptime = formatDuration(uptimeMs);
        const subbotsActive = await getActiveSubbotsCount();

        const payload = {
            active,
            uptime,
            uptimeSeconds: Math.max(0, Math.floor(uptimeMs / 1000)),
            subbotsActive
        };

        res.writeHead(200, {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
        });
        res.end(JSON.stringify(payload));
    });

    server.on('error', (err) => {
        console.error(chalk.red(`[HealthServer] Error en puerto ${HEALTH_PORT}:`), err.message);
    });

    server.listen(HEALTH_PORT, () => {
        console.log(chalk.green(`[HealthServer] Servidor de estado activo en http://localhost:${HEALTH_PORT}`));
    });
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));
    startHealthServer();

    console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
    await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'muteSystem.js',
        'messageUtils.js'
    ], {
        ignored: /(^|[\/\\])\../,
        persistent: true,
        ignoreInitial: true,
        usePolling: true,
        interval: 2000,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));

        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        if (watcher._reloadTimer) {
            clearTimeout(watcher._reloadTimer);
        }
        watcher._reloadTimer = setTimeout(async () => {
            watcher._reloadTimer = null;
            try {
                const fullPath = path.resolve(__dirname, filePath);
                
                // Si es un archivo de plugin específico, solo recargarlo
                if (filePath.startsWith('plugins/') && filePath.endsWith('.js')) {
                    console.log(chalk.cyan(`🔄 Recargando solo: ${filePath}`));
                    
                    // Limpiar caché del archivo específico
                    const resolvedPath = require.resolve(fullPath);
                    if (require.cache[resolvedPath]) {
                        delete require.cache[resolvedPath];
                    }
                    
                    // Recargar solo este plugin específico
                    if (global.commandHandler && global.commandHandler.loadPlugins) {
                        const success = global.commandHandler.loadPlugins(fullPath);
                        if (success) {
                            console.log(chalk.green(`✓ Plugin recargado: ${path.basename(filePath)}`));
                        } else {
                            console.log(chalk.red(`✗ Error recargando: ${path.basename(filePath)}`));
                        }
                    }
                } else {
                    // Para archivos del sistema (handler.js, config.js, etc.), recarga completa
                    console.log(chalk.cyan(`🔄 Archivo del sistema cambiado, recarga completa: ${filePath}`));
                    const resolvedPath = require.resolve(fullPath);
                    if (require.cache[resolvedPath]) {
                        delete require.cache[resolvedPath];
                    }
                    await global.reload();
                }
            } catch (error) {
                console.error(chalk.red(`Error reload: ${error.message}`));
            }
        }, 1500); // Reducido de 3000 a 1500ms para mayor velocidad
    });
}

process.on('unhandledRejection', (error) => {
    try {
        if (error && error.stack) console.error(chalk.red('Unhandled rejection:'), error.stack);
        else console.error(chalk.red('Unhandled rejection:'), error);
    } catch (e) {
        console.error(chalk.red('Unhandled rejection (no se pudo formatear):'), String(error));
    }
    // No forzamos reinicio aquí para evitar cascadas de desconexión.
});

process.on('uncaughtException', (error) => {
    const errorMsg = error?.message || '';
    const errorCode = error?.code || '';

    // 🚨 Si el error es ENOSPC, limpiar temporales y NO reiniciar el proceso
    if (errorMsg.includes('ENOSPC') || errorCode === 'ENOSPC') {
        console.error(chalk.red('[ENOSPC] 🚨 Sin espacio en disco (uncaughtException) — limpieza de emergencia...'));
        console.error(chalk.red('[ENOSPC] Error completo:'), error);
        try {
            // Limpieza sincrona de emergencia
            const { tempCleaner } = require('./tempCleaner');
            tempCleaner.emergencyCleanup().then(result => {
                console.log(chalk.green(`[ENOSPC] Limpieza de emergencia completada: ${result.cleaned} archivos borrados`));
            }).catch(e => {
                console.error('[ENOSPC] Error en limpieza:', e.message);
            });
        } catch (e) {
            console.error('[ENOSPC] No se pudo limpiar:', e.message);
        }
        // NO hacer process.exit() — el bot puede seguir funcionando
        return;
    }

    console.error(chalk.red('Uncaught exception:'), error);
    // Evitar reinicio forzado inmediato para no provocar desconexiones en cadena
    // Las excepciones no capturadas se registran para diagnóstico. Si el equipo
    // admin desea reiniciar tras excepciones críticas, ejecutar `forceRestart()` manualmente.
});

startServer();