require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, downloadContentFromMessage, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
require('./database');
const LastUpdate = require('./lastupdate');
const { backupToGithub } = require('./gitZipUpload');
const { createCompatibleMessage, getMessageText } = require('./messageUtils');

const MuteSystem = require('./muteSystem');

const logger = P({ level: 'silent' });

let sock;
let commandHandler;
let muteSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;

// Health check
let lastMessageTime = Date.now();
let isConnected = false;



// Cache de mensajes procesados (id -> timestamp)
const processedMessageIds = new Map();
const MESSAGE_ID_TTL = 60000; // 60s para evitar reprocesar mensajes recientes

// Errores BAD MAC
const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 3;

// Limpieza de cache: eliminar entradas viejas en vez de limpiar todo
setInterval(() => {
    const now = Date.now();
    for (const [id, ts] of processedMessageIds.entries()) {
        if (now - ts > MESSAGE_ID_TTL) processedMessageIds.delete(id);
    }
    if (global.gc) global.gc();
}, MESSAGE_ID_TTL);

// Limpieza de errores BAD MAC
setInterval(() => {
    const now = Date.now();
    for (const [jid, data] of badMacErrors.entries()) {
        if (now - data.lastError > 300000) {
            badMacErrors.delete(jid);
        }
    }
}, 180000);

async function cleanBaileyCache() {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        if (!fs.existsSync(authFolder)) return;

        const files = fs.readdirSync(authFolder);
        const now = Date.now();
        let cleaned = 0;

        for (const file of files) {
            if (file.includes('session-') || file.includes('sender-key')) {
                const filePath = path.join(authFolder, file);
                try {
                    const stats = fs.statSync(filePath);
                    const age = now - stats.mtimeMs;

                    if (age > 3600000) { // 1 hora
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }
                } catch (e) {}
            }
        }

        if (cleaned > 0) {
            console.log(chalk.yellow(`🧹 ${cleaned} archivos cache eliminados`));
        }
    } catch (error) {
        console.error(chalk.red('Error limpiando cache:'), error.message);
    }
}

async function resetUserSession(jid) {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        const sessionFiles = fs.readdirSync(authFolder);
        const userNumber = jid.split('@')[0];
        
        for (const file of sessionFiles) {
            if (file.includes(userNumber)) {
                const filePath = path.join(authFolder, file);
                try {
                    fs.unlinkSync(filePath);
                    console.log(chalk.yellow(`🔄 Sesión eliminada: ${userNumber}`));
                } catch (e) {}
            }
        }
        
        badMacErrors.delete(jid);
    } catch (error) {
        console.error(chalk.red('Error reset sesión:'), error.message);
    }
}

async function forceRestart() {
    if (isReconnecting) {
        console.log(chalk.yellow('⚠️ Ya hay un reinicio en proceso'));
        return;
    }
    
    isReconnecting = true;
    console.log(chalk.red('⚠️ REINICIO FORZADO'));
    
    if (sock) {
        try {
            sock.ev.removeAllListeners();
            sock.ws?.close();
            sock.end(undefined);
        } catch (e) {
            console.error('Error cerrando socket:', e.message);
        }
    }
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    await cleanBaileyCache();
    
    processedMessageIds.clear();
    badMacErrors.clear();
    reconnectAttempts = 0;
    
    if (global.gc) global.gc();
    
    isReconnecting = false;
    
    console.log(chalk.yellow('🔄 Reconectando...'));
    connectToWhatsApp();
}



async function connectToWhatsApp() {
    try {
        // Limpiar listeners del socket anterior antes de crear uno nuevo
        if (sock) {
            try { sock.ev.removeAllListeners(); } catch (_) {}
        }

        const { state, saveCreds } = await useMultiFileAuthState('./baileys_auth');
        const { version, isLatest } = await fetchLatestBaileysVersion();
        
        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }), 
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            msgRetryCounterCache: new Map(),
            generateHighQualityLinkPreview: true,
            defaultQueryTimeoutMs: 60000,
            browser: ['RobleBOT', 'Chrome', '4.0.0'],
            retryRequestDelayMs: 500,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: true,
            syncFullHistory: false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async (key) => {
                return undefined;
            }
        });

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };
                
                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        global.conn = sock;
        
        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        global.LastUpdate = LastUpdate;
        LastUpdate.updateTimestamp();

        if (commandHandler?.destroy) commandHandler.destroy();
        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        if (muteSystem?.destroy) muteSystem.destroy();
        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules') && !key.includes('SUBBOTS') && !key.includes('messageUtils')) {
                        delete require.cache[key];
                    }
                });
                
                const NewLastUpdate = require('./lastupdate');
                NewLastUpdate.updateTimestamp();
                global.LastUpdate = NewLastUpdate;

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }
                
                const Handler = require('./handler');
                if (commandHandler?.destroy) commandHandler.destroy();
                commandHandler = new Handler();
                global.commandHandler = commandHandler;
                console.log(chalk.green('✓ Handler recargado'));
                
                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    if (muteSystem?.destroy) muteSystem.destroy();
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                }
                
                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log(chalk.yellow('📱 QR generado'));
                qrcode.generate(qr, { small: true });
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;
                
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Limpiando sesión corrupta...'));
                    await cleanBaileyCache();
                    reconnectAttempts = 0;
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    const delay = Math.min(5000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                console.log(chalk.green('✅ CONECTADO'));
                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));
                
                // Guardar número del bot oficial — los subbots lo usan para ceder prioridad
                if (sock.user?.id) {
                    global.mainBotNumber = sock.user.id.split('@')[0].split(':')[0];
                }

                // Iniciar servidor HTTP de subbots (solo una vez)
                if (!global._subBotServerStarted) {
                    global._subBotServerStarted = true;
                    try {
                        const { startSubBotServer } = require('./subbotServer');
                        startSubBotServer(25196);
                    } catch (e) {
                        console.error('[SubBotServer] Error al iniciar:', e.message);
                    }
                }
                
                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;
                
                if (!muteSystem) {
                    if (global.muteSystem?.destroy) global.muteSystem.destroy();
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }
                
                await cleanBaileyCache();

                // Auto-reconectar sub-bots con sesión guardada (solo una vez por arranque)
                try {
                    if (!global._subBotsAutoReconnected) {
                        global._subBotsAutoReconnected = true;
                        const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
                        autoReconnectSubBots(sock).catch(e => console.error('[SubBot] Error auto-reconexión:', e.message));
                    }
                } catch (e) {
                    console.error('[SubBot] No se pudo cargar módulo de sub-bots:', e.message);
                }
                
                console.log(chalk.green('✓ Conectado'));
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;
            if (!isConnected) return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;
                
                const messageId = baileyMessage.key.id;
                
                if (processedMessageIds.has(messageId)) continue;
                processedMessageIds.set(messageId, Date.now());
                
                const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                
                // VERIFICAR MUTEO
                if (muteSystem) {
                    const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage);
                    if (wasDeleted) continue;
                }
                
                // PROCESAR COMANDOS
                const isFromMe = baileyMessage.key.fromMe;
                const messageText = getMessageText(baileyMessage);
                const prefixes = ['.', '/', '❤️', '#'];
                const hasPrefix = prefixes.some(p => messageText.startsWith(p));
                
                if (isFromMe && !hasPrefix) continue;

                try {
                    const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    const senderNumber = sender.split('@')[0];

                    if (!global.db?.data) {
                        console.error('BD no inicializada');
                        continue;
                    }

                    // FIX: No hacer continue si getUser falla — crear usuario nuevo en su lugar
                    try {
                        await global.db.getUser(senderNumber);
                    } catch (error) {
                        console.error('Error obteniendo usuario (continuando igual):', error.message);
                        // No hacer continue, el handler puede funcionar sin datos previos
                    }

                    global.lastBaileyMessage = baileyMessage;
                    const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                    // 💾 Guardar mensaje del usuario en CHATS-USUARIOS (async para no bloquear)
                    if (!isFromMe && messageText && messageText.trim() && !hasPrefix) {
                        setImmediate(() => {
                            try {
                                const chatId = baileyMessage.key.remoteJid;
                                const chatUsersDir = path.join(__dirname, 'CHATS-USUARIOS', chatId);
                                if (!fs.existsSync(chatUsersDir)) fs.mkdirSync(chatUsersDir, { recursive: true });
                                const userFile = path.join(chatUsersDir, `${senderNumber}.txt`);
                                const timestamp = new Date().toISOString();

                                const ctxInfo = baileyMessage.message?.extendedTextMessage?.contextInfo;
                                const quotedText = ctxInfo?.quotedMessage?.conversation
                                    || ctxInfo?.quotedMessage?.extendedTextMessage?.text
                                    || null;
                                const quotedParticipant = ctxInfo?.participant
                                    ? ctxInfo.participant.split('@')[0].replace(/\D/g, '')
                                    : null;

                                let line;
                                if (quotedText && quotedParticipant) {
                                    const quotedClean = quotedText.trim().slice(0, 200);
                                    line = `[${timestamp}] (respondiendo a ${quotedParticipant}: "${quotedClean}") ${messageText.trim()}\n`;
                                } else {
                                    line = `[${timestamp}] ${messageText.trim()}\n`;
                                }

                                fs.appendFile(userFile, line, 'utf-8', (e) => {
                                    if (e) console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                                });
                            } catch (e) {
                                console.error('[CHAT-USUARIOS] Error guardando mensaje:', e.message);
                            }
                        });
                    }

                    await commandHandler.handleMessage(compatibleMessage);
                    
                } catch (error) {
                    if (error.message?.includes('Bad MAC')) {
                        console.error(chalk.red(`[BAD MAC] ${senderJid}`));
                        
                        if (!badMacErrors.has(senderJid)) {
                            badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                        }
                        
                        const errorData = badMacErrors.get(senderJid);
                        errorData.count++;
                        errorData.lastError = Date.now();
                        
                        if (errorData.count >= BAD_MAC_THRESHOLD) {
                            console.log(chalk.yellow(`🔄 Reset sesión: ${senderJid}`));
                            await resetUserSession(senderJid);
                            
                            const totalBadMac = Array.from(badMacErrors.values())
                                .reduce((acc, v) => acc + v.count, 0);
                            
                            if (totalBadMac > 8) {
                                console.log(chalk.red('⚠️ Demasiados BAD MAC, reiniciando...'));
                                forceRestart();
                            }
                        }
                    } else {
                        console.error('Error proceso mensaje:', error.message);
                    }
                }
            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);
        
        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));

    console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
    await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'lastupdate.js', 
        'muteSystem.js',
        'messageUtils.js'
    ], {
        ignored: [/(^|[\/\\])\../, '**/SUBBOTS/**'],
        persistent: true,
        ignoreInitial: true,
        usePolling: true,
        interval: 2000,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));
        
        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        try {
            const fullPath = path.resolve(__dirname, filePath);
            const resolvedPath = require.resolve(fullPath);
            if (require.cache[resolvedPath]) {
                delete require.cache[resolvedPath];
            }
            await global.reload();
        } catch (error) {
            console.error(chalk.red(`Error reload: ${error.message}`));
        }
    });
}

process.on('unhandledRejection', (error) => {
    console.error(chalk.red('Unhandled rejection:'), error);
});

process.on('uncaughtException', (error) => {
    console.error(chalk.red('Uncaught exception:'), error);
    if (!isReconnecting) {
        setTimeout(() => forceRestart(), 5000);
    }
});

startServer();