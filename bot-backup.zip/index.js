require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, downloadContentFromMessage, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
const express = require('express');
require('./database');
const LastUpdate = require('./lastupdate');

const AntiLink = require('./antilinks');
const MuteSystem = require('./muteSystem');

const logger = P({ level: 'silent' });

let sock;
let commandHandler;
let antiLink;
let muteSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;

// Health check
let lastMessageTime = Date.now();
let isConnected = false;
const HEALTH_CHECK_INTERVAL = 120000; // 2 minutos
const MAX_IDLE_TIME = 600000; // 10 minutos

// Auto-restart cada 2 horas
const AUTO_RESTART_INTERVAL = 7200000; // 2 horas
let autoRestartTimer;
let botStartTime = Date.now();

// Cache de mensajes procesados
const processedMessageIds = new Set();
const MESSAGE_ID_TTL = 20000;

// Errores BAD MAC
const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 3;

// Limpieza de cache de mensajes procesados cada 20 segundos
setInterval(() => {
    const beforeSize = processedMessageIds.size;
    processedMessageIds.clear();
    if (global.gc) global.gc();
    if (beforeSize > 0) {
        console.log(chalk.yellow(`🧹 Cache mensajes: ${beforeSize} limpiados`));
    }
}, MESSAGE_ID_TTL);

// Limpieza de errores BAD MAC cada 3 minutos
setInterval(() => {
    const now = Date.now();
    let cleaned = 0;
    for (const [jid, data] of badMacErrors.entries()) {
        if (now - data.lastError > 300000) { // 5 minutos
            badMacErrors.delete(jid);
            cleaned++;
        }
    }
    if (cleaned > 0) {
        console.log(chalk.yellow(`🧹 BAD MAC: ${cleaned} sesiones limpiadas`));
    }
}, 180000);

// Limpieza de archivos de Baileys cada 30 minutos
setInterval(async () => {
    console.log(chalk.cyan('🧹 Limpieza programada de cache Baileys...'));
    await cleanBaileyCache();
}, 1800000); // 30 minutos

// Verificar uptime real y forzar restart si es necesario
setInterval(() => {
    const currentUptime = Date.now() - botStartTime;
    
    // Si el uptime supera las 2 horas y 10 minutos (margen de seguridad amplio)
    if (currentUptime > (AUTO_RESTART_INTERVAL + 600000)) {
        console.log(chalk.red('⚠️ UPTIME EXCEDIDO - Timer de auto-restart falló'));
        console.log(chalk.yellow(`Uptime actual: ${Math.floor(currentUptime / 3600000)}h ${Math.floor((currentUptime % 3600000) / 60000)}m`));
        console.log(chalk.yellow(`Timer activo: ${autoRestartTimer !== null}`));
        forceRestart();
    }
}, 300000); // Verificar cada 5 minutos (más frecuente para detectar problemas)

function createCompatibleMessage(baileyMessage, sock) {
    const contextInfo = baileyMessage.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;

    const message = {
        id: baileyMessage.key.id,
        from: baileyMessage.key.remoteJid,
        key: baileyMessage.key,
        numberInbox: baileyMessage.key.remoteJid,
        numberGroup: baileyMessage.key.participant,
        author: baileyMessage.key.participant || baileyMessage.key.remoteJid,
        sender: baileyMessage.key.participant || baileyMessage.key.remoteJid,
        body: getMessageText(baileyMessage),
        isGroup: baileyMessage.key.remoteJid.includes('@g.us'),
        timestamp: baileyMessage.messageTimestamp,
        mentions: baileyMessage?.message?.extendedTextMessage?.contextInfo?.mentionedJid,
        _baileyMessage: baileyMessage,
        
        quoted: quotedMessage ? {
            key: {
                remoteJid: baileyMessage.key.remoteJid,
                id: contextInfo.stanzaId,
                participant: contextInfo.participant,
                fromMe: false
            },
            id: contextInfo.stanzaId,
            sender: contextInfo.participant,
            fromMe: false,
            mtype: Object.keys(quotedMessage)[0],
            download: async () => {
                if (quotedMessage.imageMessage) {
                    const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }
                    return buffer;
                } else if (quotedMessage.videoMessage) {
                    const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
                    let buffer = Buffer.alloc(0);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }
                    return buffer;
                }
                return null;
            },
            mimetype: quotedMessage.imageMessage?.mimetype || 
                        quotedMessage.videoMessage?.mimetype
        } : null,

        getQuotedMessage: async function() {
            if (!quotedMessage) return null;
            
            return {
                downloadMedia: async function() {
                    if (quotedMessage.imageMessage) {
                        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
                        let buffer = Buffer.alloc(0);
                        for await (const chunk of stream) {
                            buffer = Buffer.concat([buffer, chunk]);
                        }
                        return {
                            data: buffer,
                            mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg'
                        };
                    } else if (quotedMessage.videoMessage) {
                        const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
                        let buffer = Buffer.alloc(0);
                        for await (const chunk of stream) {
                            buffer = Buffer.concat([buffer, chunk]);
                        }
                        return {
                            data: buffer,
                            mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4'
                        };
                    }
                    return null;
                }
            };
        },

        reply: async function(text, options = {}) {
            try {
                if (!sock || !sock.user) {
                    console.error('Socket no disponible');
                    return;
                }
                await sock.sendMessage(this.from, { text: text, mentions: options.mentions }, { quoted: baileyMessage });
            } catch (error) {
                console.error('Error reply:', error.message);
            }
        },
        
        delete: async function() {
            try {
                if (!sock || !sock.user) return;
                await sock.sendMessage(this.from, { delete: baileyMessage.key });
            } catch (error) {
                console.error('Error delete:', error.message);
            }
        }
    };

    return message;
}

function getMessageText(baileyMessage) {
    const msg = baileyMessage.message;
    if (!msg) return '';

    if (msg.conversation) return msg.conversation;
    if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
    if (msg.imageMessage?.caption) return msg.imageMessage.caption;
    if (msg.videoMessage?.caption) return msg.videoMessage.caption;
    if (msg.documentMessage?.caption) return msg.documentMessage.caption;
    
    return '';
}

async function cleanBaileyCache() {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        if (!fs.existsSync(authFolder)) {
            console.log(chalk.yellow('⚠️ Carpeta baileys_auth no existe'));
            return;
        }

        const files = fs.readdirSync(authFolder);
        const now = Date.now();
        let cleaned = 0;
        let totalFiles = 0;

        for (const file of files) {
            if (file.includes('session-') || file.includes('sender-key')) {
                totalFiles++;
                const filePath = path.join(authFolder, file);
                try {
                    const stats = fs.statSync(filePath);
                    const age = now - stats.mtimeMs;

                    if (age > 3600000) { // 1 hora
                        fs.unlinkSync(filePath);
                        cleaned++;
                    }
                } catch (e) {
                    console.error(chalk.red(`Error procesando ${file}:`), e.message);
                }
            }
        }

        if (cleaned > 0) {
            console.log(chalk.green(`🧹 Baileys: ${cleaned}/${totalFiles} archivos cache eliminados`));
        } else {
            console.log(chalk.cyan(`✓ Baileys: ${totalFiles} archivos cache, ninguno viejo`));
        }
    } catch (error) {
        console.error(chalk.red('Error limpiando cache:'), error.message);
    }
}

async function resetUserSession(jid) {
    try {
        const authFolder = path.join(__dirname, 'baileys_auth');
        const sessionFiles = fs.readdirSync(authFolder);
        const userNumber = jid.split('@')[0];
        
        for (const file of sessionFiles) {
            if (file.includes(userNumber)) {
                const filePath = path.join(authFolder, file);
                try {
                    fs.unlinkSync(filePath);
                    console.log(chalk.yellow(`🔄 Sesión eliminada: ${userNumber}`));
                } catch (e) {}
            }
        }
        
        badMacErrors.delete(jid);
    } catch (error) {
        console.error(chalk.red('Error reset sesión:'), error.message);
    }
}

function scheduleAutoRestart() {
    // Limpiar timer anterior si existe
    if (autoRestartTimer) {
        clearTimeout(autoRestartTimer);
        autoRestartTimer = null;
    }
    
    const currentUptime = Date.now() - botStartTime;
    const timeUntilRestart = AUTO_RESTART_INTERVAL - currentUptime;
    
    // Si ya pasó el tiempo de restart, reiniciar inmediatamente
    if (timeUntilRestart <= 0) {
        console.log(chalk.red('⚠️ Tiempo de restart ya pasado, reiniciando ahora'));
        setTimeout(() => forceRestart(), 5000);
        return;
    }
    
    // Programar nuevo restart
    autoRestartTimer = setTimeout(() => {
        const uptime = Date.now() - botStartTime;
        const hours = Math.floor(uptime / 3600000);
        const minutes = Math.floor((uptime % 3600000) / 60000);
        
        console.log(chalk.yellow(`⏰ Auto-restart ejecutándose`));
        console.log(chalk.cyan(`Uptime: ${hours}h ${minutes}m`));
        forceRestart();
    }, timeUntilRestart);
    
    const restartInMinutes = Math.floor(timeUntilRestart / 60000);
    const restartInHours = Math.floor(restartInMinutes / 60);
    const restartMinutesLeft = restartInMinutes % 60;
    
    console.log(chalk.green(`✓ Auto-restart programado: ${restartInHours}h ${restartMinutesLeft}m`));
}

async function forceRestart() {
    if (isReconnecting) {
        console.log(chalk.yellow('⚠️ Ya hay un reinicio en proceso'));
        return;
    }
    
    isReconnecting = true;
    console.log(chalk.red('⚠️ REINICIO FORZADO'));
    
    // Limpiar timer de auto-restart
    if (autoRestartTimer) {
        clearTimeout(autoRestartTimer);
        autoRestartTimer = null;
    }
    
    if (sock) {
        try {
            sock.ev.removeAllListeners();
            sock.ws?.close();
            sock.end(undefined);
        } catch (e) {
            console.error('Error cerrando socket:', e.message);
        }
    }
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    await cleanBaileyCache();
    
    processedMessageIds.clear();
    badMacErrors.clear();
    reconnectAttempts = 0;
    
    if (global.gc) global.gc();
    
    // IMPORTANTE: Reiniciar el contador de tiempo del bot AQUÍ
    botStartTime = Date.now();
    
    isReconnecting = false;
    
    console.log(chalk.yellow('🔄 Reconectando...'));
    connectToWhatsApp();
}

// Health Check cada 2 minutos
setInterval(() => {
    if (!isConnected || isReconnecting) return;

    const timeSinceLastMessage = Date.now() - lastMessageTime;
    
    if (timeSinceLastMessage > MAX_IDLE_TIME) {
        console.log(chalk.red(`⚠️ Inactivo ${Math.floor(timeSinceLastMessage/60000)} min - Reiniciando`));
        forceRestart();
    }
}, HEALTH_CHECK_INTERVAL);

async function connectToWhatsApp() {
    try {
        const { state, saveCreds } = await useMultiFileAuthState('./baileys_auth');
        const { version, isLatest } = await fetchLatestBaileysVersion();
        
        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }), 
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            msgRetryCounterCache: new Map(),
            generateHighQualityLinkPreview: true,
            defaultQueryTimeoutMs: 60000,
            browser: ['RobleBOT', 'Chrome', '4.0.0'],
            retryRequestDelayMs: 500,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: true,
            syncFullHistory: false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async (key) => {
                return { conversation: '' };
            }
        });

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };
                
                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        global.conn = sock;
        
        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        global.LastUpdate = LastUpdate;
        LastUpdate.updateTimestamp();

        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        antiLink = new AntiLink(sock);
        global.antiLink = antiLink;
        console.log(chalk.green('✓ Anti-Links OK'));

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules')) {
                        delete require.cache[key];
                    }
                });
                
                const NewLastUpdate = require('./lastupdate');
                NewLastUpdate.updateTimestamp();
                global.LastUpdate = NewLastUpdate;

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }
                
                const Handler = require('./handler');
                commandHandler = new Handler();
                console.log(chalk.green('✓ Handler recargado'));
                
                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                }

                const NewAntiLink = require('./antilinks');
                if (sock?.user) {
                    antiLink = new NewAntiLink(sock);
                    global.antiLink = antiLink;
                    console.log(chalk.green('✓ Anti-Links recargado'));
                }
                
                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log(chalk.yellow('📱 QR generado'));
                qrcode.generate(qr, { small: true });
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;
                
                // Limpiar auto-restart cuando se cierra la conexión
                if (autoRestartTimer) {
                    clearTimeout(autoRestartTimer);
                    autoRestartTimer = null;
                    console.log(chalk.yellow('⚠️ Auto-restart cancelado por desconexión'));
                }
                
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Limpiando sesión corrupta...'));
                    await cleanBaileyCache();
                    reconnectAttempts = 0;
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    const delay = Math.min(5000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                console.log(chalk.green('✅ CONECTADO'));
                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));
                
                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;
                
                if (!muteSystem) {
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }

                if (!antiLink) {
                    antiLink = new AntiLink(sock);
                    global.antiLink = antiLink;
                }
                
                // Limpieza de cache al conectar
                console.log(chalk.cyan('🧹 Limpiando cache al conectar...'));
                await cleanBaileyCache();
                
                // CRÍTICO: Siempre programar auto-restart después de conectar
                // Esto asegura que el timer esté activo incluso después de reconexiones
                scheduleAutoRestart();
                
                // Inicializar subbots después de conectar el bot principal
                try {
                    const { initializeSubbots } = require('./subbots');
                    console.log(chalk.cyan('🤖 Inicializando sistema de subbots...'));
                    initializeSubbots().catch(e => console.error(chalk.red('[SubBots] Error:'), e.message));
                } catch (e) {
                    // Módulo subbots no disponible, continuar sin él
                }
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('call', async (calls) => {
            for (const call of calls) {
                try {
                    await sock.rejectCall(call.id, call.from);
                    console.log(chalk.red('[CALL] Rechazada'));
                } catch (error) {
                    console.error(chalk.red('[CALL ERROR]'), error.message);
                }
            }
        });

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;
            if (!isConnected) return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;
                
                const messageId = baileyMessage.key.id;
                
                if (processedMessageIds.has(messageId)) continue;
                processedMessageIds.add(messageId);
                
                const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                
                // Verificar muteo primero
                if (muteSystem) {
                    const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage);
                    if (wasDeleted) continue;
                }
                
                // Procesar comandos y antilink
                const isFromMe = baileyMessage.key.fromMe;
                const messageText = getMessageText(baileyMessage);
                const prefixes = ['.', '/', '❤️', '#'];
                const hasPrefix = prefixes.some(p => messageText.startsWith(p));
                
                if (isFromMe && !hasPrefix) continue;

                try {
                    const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    const senderNumber = sender.split('@')[0];

                    if (!global.db?.data) {
                        console.error('BD no inicializada');
                        continue;
                    }

                    let user;
                    try {
                        user = await global.db.getUser(senderNumber); 
                    } catch (error) {
                        console.error('Error obteniendo usuario:', error.message);
                        continue;
                    }

                    global.lastBaileyMessage = baileyMessage;
                    const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                    await commandHandler.handleMessage(compatibleMessage);
                    
                } catch (error) {
                    if (error.message?.includes('Bad MAC')) {
                        console.error(chalk.red(`[BAD MAC] ${senderJid}`));
                        
                        if (!badMacErrors.has(senderJid)) {
                            badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                        }
                        
                        const errorData = badMacErrors.get(senderJid);
                        errorData.count++;
                        errorData.lastError = Date.now();
                        
                        if (errorData.count >= BAD_MAC_THRESHOLD) {
                            console.log(chalk.yellow(`🔄 Reset sesión: ${senderJid}`));
                            await resetUserSession(senderJid);
                            
                            const totalBadMac = Array.from(badMacErrors.values())
                                .reduce((acc, v) => acc + v.count, 0);
                            
                            if (totalBadMac > 8) {
                                console.log(chalk.red('⚠️ Demasiados BAD MAC, reiniciando...'));
                                forceRestart();
                            }
                        }
                    } else {
                        console.error('Error proceso mensaje:', error.message);
                    }
                }
            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);
        
        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));

    // Limpieza inicial de cache
    console.log(chalk.cyan('🧹 Limpieza inicial de cache...'));
    await cleanBaileyCache();
    processedMessageIds.clear();
    badMacErrors.clear();
    if (global.gc) {
        global.gc();
        console.log(chalk.green('✓ Garbage collector ejecutado'));
    }

    // Backup inicial (opcional)
    let backupToGithub = null;
    try {
        const gitZipModule = require('./gitZipUpload');
        backupToGithub = gitZipModule.backupToGithub;
        
        if (backupToGithub && typeof backupToGithub === 'function') {
            console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
            await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));
        }
    } catch (e) {
        console.log(chalk.yellow('⚠️ Módulo de backup no disponible (opcional)'));
    }

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    // File watcher
    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'lastupdate.js', 
        'antilinks.js',
        'muteSystem.js'
    ], {
        ignored: /(^|[\/\\])\../,
        persistent: true,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));
        
        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        try {
            const fullPath = path.resolve(__dirname, filePath);
            const resolvedPath = require.resolve(fullPath);
            if (require.cache[resolvedPath]) {
                delete require.cache[resolvedPath];
            }
            await global.reload();
        } catch (error) {
            console.error(chalk.red(`Error reload: ${error.message}`));
        }
    });
    
    // Express server
    const app = express();
    
    app.get('/', (req, res) => {
        const uptime = Date.now() - botStartTime;
        const hours = Math.floor(uptime / 3600000);
        const minutes = Math.floor((uptime % 3600000) / 60000);
        const seconds = Math.floor((uptime % 60000) / 1000);
        
        const nextRestart = autoRestartTimer ? AUTO_RESTART_INTERVAL - uptime : 0;
        const nextRestartMin = Math.floor(nextRestart / 60000);
        
        res.json({
            status: 'online',
            bot: 'RobleBOT',
            uptime: `${hours}h ${minutes}m ${seconds}s`,
            uptimeMs: uptime,
            connected: isConnected,
            lastActivity: new Date(lastMessageTime).toISOString(),
            memory: process.memoryUsage(),
            processedMessages: processedMessageIds.size,
            reconnectAttempts,
            nextAutoRestart: nextRestartMin > 0 ? `${nextRestartMin} min` : 'No programado',
            autoRestartActive: autoRestartTimer !== null,
            autoRestartInterval: `${AUTO_RESTART_INTERVAL / 60000} min`,
            botStartTime: new Date(botStartTime).toISOString()
        });
    });
    
    app.get('/restart', (req, res) => {
        res.json({ message: 'Reiniciando en 1 segundo...' });
        setTimeout(() => forceRestart(), 1000);
    });
    
    app.get('/clean', async (req, res) => {
        await cleanBaileyCache();
        processedMessageIds.clear();
        badMacErrors.clear();
        if (antiLink) antiLink.clearCache();
        if (global.gc) global.gc();
        res.json({ message: 'Cache limpiado completamente' });
    });

    app.get('/backup', async (req, res) => {
        try {
            const gitZipModule = require('./gitZipUpload');
            const backupFn = gitZipModule.backupToGithub;
            const resetFn = gitZipModule.resetBackupFlag;
            
            if (backupFn && typeof backupFn === 'function') {
                res.json({ message: 'Iniciando backup...' });
                if (resetFn && typeof resetFn === 'function') {
                    resetFn();
                }
                backupFn().catch(e => console.error('Error backup:', e.message));
            } else {
                res.json({ error: 'Backup no disponible' });
            }
        } catch (e) {
            res.json({ error: 'Módulo de backup no encontrado' });
        }
    });
    
    app.get('/status', (req, res) => {
        const uptime = Date.now() - botStartTime;
        const nextRestart = autoRestartTimer ? AUTO_RESTART_INTERVAL - uptime : 0;
        
        res.json({
            uptime: Math.floor(uptime / 1000),
            uptimeFormatted: `${Math.floor(uptime / 3600000)}h ${Math.floor((uptime % 3600000) / 60000)}m`,
            nextRestart: Math.floor(nextRestart / 1000),
            nextRestartFormatted: nextRestart > 0 ? `${Math.floor(nextRestart / 60000)}m` : 'N/A',
            autoRestartConfigured: AUTO_RESTART_INTERVAL / 60000,
            timerActive: autoRestartTimer !== null,
            isConnected,
            reconnectAttempts,
            lastMessage: new Date(lastMessageTime).toISOString()
        });
    });

    const PORT = process.env.PORT || 24667;
    app.listen(PORT, () => {
        console.log(chalk.green(`✓ HTTP: ${PORT}`));
        console.log(chalk.cyan(`Health: http://localhost:${PORT}/`));
        console.log(chalk.cyan(`Status: http://localhost:${PORT}/status`));
        console.log(chalk.cyan(`Restart: http://localhost:${PORT}/restart`));
        console.log(chalk.cyan(`Clean: http://localhost:${PORT}/clean`));
        console.log(chalk.cyan(`Backup: http://localhost:${PORT}/backup`));
    });
}

process.on('unhandledRejection', (error) => {
    console.error(chalk.red('Unhandled rejection:'), error);
});

process.on('uncaughtException', (error) => {
    console.error(chalk.red('Uncaught exception:'), error);
    if (!isReconnecting) {
        setTimeout(() => forceRestart(), 5000);
    }
});

startServer();