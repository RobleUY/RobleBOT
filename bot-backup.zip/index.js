require('dotenv').config();

// ── REDIRECCIÓN DE CARPETA TEMPORAL (ENOSPC FIX) ───────────────────────
// Redirige os.tmpdir() a una carpeta local './tmp' dentro del proyecto.
// Esto evita errores de falta de espacio en la partición '/tmp' del sistema.
const os = require('os');
const path = require('path');
const fs = require('fs');
const localTmpDir = path.join(process.cwd(), 'tmp');
if (!fs.existsSync(localTmpDir)) {
    try {
        fs.mkdirSync(localTmpDir, { recursive: true });
    } catch (e) {
        console.error('[System] Error al crear la carpeta temporal local:', e.message);
    }
}
os.tmpdir = () => localTmpDir;
// ───────────────────────────────────────────────────────────────────────

const http = require('http');
const moment = require('moment-timezone');
const { default: makeWASocket, DisconnectReason, fetchLatestBaileysVersion, Browsers, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const { useSQLiteAuthState } = require('./plugins/SUBBOTS/singleFileAuthState');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const CommandHandler = require('./handler');
const chokidar = require('chokidar');
const chalk = require('chalk');
require('./database');
const { backupToGithub } = require('./gitZipUpload');
const { createCompatibleMessage, getMessageText } = require('./messageUtils');
const { isBorradosEnabled } = require('./plugins/HERRAMIENTAS/GRUPOS/borrados');
const { tempCleaner } = require('./tempCleaner');

const HEALTH_PORT = process.env.HEALTH_PORT ? parseInt(process.env.HEALTH_PORT, 10) : 24629;

const MuteSystem = require('./muteSystem');
const { initRecordatorios } = require('./plugins/HERRAMIENTAS/recordatorios');
const welcomeGoodbyeModule = require('./plugins/HERRAMIENTAS/bienvenida-despedida');
const { initPetAutocuidado, stopPetAutocuidado } = require('./petAutocuidado');
// Transcripción de audio removida

let sock;
let commandHandler;
let muteSystem;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let isReconnecting = false;


// ── QR de sesión principal: se muestra UNA sola vez por arranque ──────────
// Si expira sin escanearse, el servidor sigue corriendo (subbots intactos)
// y solo se imprime un aviso. Para generar un QR nuevo hay que reiniciar.
let mainQrShown  = false;  // ya se mostró el QR al menos una vez
let mainAuthed   = false;  // el bot principal llegó al estado 'open' alguna vez
// ─────────────────────────────────────────────────────────────────────────

// ── CACHÉ DE RESPUESTAS DE USUARIOS (TTL 5s) ────────────────────────────
let _respUsuariosCache = null;
let _respUsuariosTime = 0;
function getRespuestasUsuariosData() {
    const now = Date.now();
    if (_respUsuariosCache && (now - _respUsuariosTime < 5000)) {
        return _respUsuariosCache;
    }
    try {
        const respFile = path.join(__dirname, 'data', 'respuestas-usuarios.json');
        if (fs.existsSync(respFile)) {
            _respUsuariosCache = JSON.parse(fs.readFileSync(respFile, 'utf8'));
            _respUsuariosTime = now;
            return _respUsuariosCache;
        }
    } catch (e) {}
    _respUsuariosCache = {};
    _respUsuariosTime = now;
    return _respUsuariosCache;
}
// ─────────────────────────────────────────────────────────────────────────

// ── HELPER: manejar mensajes borrados (texto, imagen, video, sticker, audio, voz) ──
async function _handleBorradoMessage(sock, remoteJid, original) {
    try {
        const msg = original.message || {};
        const senderJid = original.key.participant || original.key.remoteJid || '';
        const userNum = senderJid.split('@')[0].split(':')[0];
        const mentionJid = original.key.participant || original.key.remoteJid;

        // ── Texto / Texto extendido ──────────────────────────────────────
        const textContent = msg.conversation || msg.extendedTextMessage?.text || '';
        if (textContent.trim().length > 0) {
            const hasLink = /(https?:\/\/|www\.)/i.test(textContent);
            if (!hasLink) {
                await sock.sendMessage(remoteJid, {
                    text: `📌 El usuario @${userNum} eliminó este mensaje:\n\n${textContent}`,
                    mentions: [mentionJid]
                });
            }
            return;
        }

        // ── Imagen ───────────────────────────────────────────────────────
        if (msg.imageMessage) {
            const caption = msg.imageMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una imagen${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Video ─────────────────────────────────────────────────────────
        if (msg.videoMessage) {
            const caption = msg.videoMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un video${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Sticker ───────────────────────────────────────────────────────
        if (msg.stickerMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un sticker:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el sticker eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Audio / Nota de voz ───────────────────────────────────────────
        if (msg.audioMessage) {
            const isPtt = msg.audioMessage.ptt === true;
            const tipo = isPtt ? 'nota de voz' : 'audio';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ${tipo}:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el ${tipo} eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Documento ─────────────────────────────────────────────────────
        if (msg.documentMessage) {
            const fileName = msg.documentMessage.fileName || 'archivo';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un documento: *${fileName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── GIF ───────────────────────────────────────────────────────────
        if (msg.gifMessage || (msg.videoMessage && msg.videoMessage.gifPlayback)) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un GIF.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Contacto ──────────────────────────────────────────────────────
        if (msg.contactMessage) {
            const contactName = msg.contactMessage.displayName || 'contacto';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un contacto: *${contactName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Ubicación ─────────────────────────────────────────────────────
        if (msg.locationMessage || msg.liveLocationMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ubicación.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

    } catch (err) {
        console.error('[borrados] Error al manejar mensaje borrado:', err.message);
    }
}
global._botStartTime = 0;

global._currentProcessingJid = null;

process.on('unhandledRejection', (reason) => {
    console.error('[Process] Rechazo no manejado:', reason && reason.stack ? reason.stack : reason);
});
process.on('uncaughtException', (error) => {
    console.error('[Process] Excepción no capturada:', error && error.stack ? error.stack : error);
});

(function patchConsoleForClosingSession() {
    const _origWarn  = console.warn.bind(console);
    const _origError = console.error.bind(console);
    const _origLog   = console.log.bind(console);

    function cleanSessionForJid(jid) {
        if (!jid) return;
        const sessionFile = path.join(__dirname, 'main-session.db');
        if (!fs.existsSync(sessionFile)) return;

        try {
            const userNumber = jid.split('@')[0].split(':')[0].replace(/\D/g, '');
            if (!userNumber || userNumber.length < 5) return;

            console.log(chalk.yellow(`[Session-Fix] 🔧 Sesión cerrada para ${userNumber} (archivo .db principal)`));
        } catch {}
    }

    function isSessionEntryArg(arg) {
        if (!arg) return false;
        if (typeof arg === 'string') {
            const lower = arg.toLowerCase();
            return lower.includes('closing session') ||
                lower.includes('sessionentry') ||
                lower.includes('_chains') ||
                lower.includes('registrationid') ||
                lower.includes('currentratchet') ||
                lower.includes('ephemeralkeypair') ||
                lower.includes('basekey') ||
                lower.includes('remoteidentitykey');
        }

        if (typeof arg === 'object') {
            return arg?._chains !== undefined ||
                arg?.currentRatchet !== undefined ||
                arg?.registrationId !== undefined ||
                arg?.pendingPreKey !== undefined;
        }

        return false;
    }

    function shouldHideSessionLog(args) {
        return args.some(isSessionEntryArg);
    }

    function handleClosingSession(args) {
        let jid = null;

        for (const arg of args) {
            if (!arg) continue;
            if (typeof arg === 'string') {
                const match = arg.match(/(\d{10,15})(?:@s\.whatsapp\.net|@g\.us)?/);
                if (match) { jid = match[1]; break; }
            }
        }

        if (!jid && global._currentProcessingJid) {
            jid = global._currentProcessingJid.split('@')[0].split(':')[0].replace(/\D/g, '');
        }

        if (jid) {
            cleanSessionForJid(jid);
        } else {
            _origWarn(chalk.gray(`[Session-Fix] Sesión cerrada — sin JID identificable, omitiendo limpieza`));
        }
    }

    console.warn = function (...args) {
        if (shouldHideSessionLog(args)) {
            handleClosingSession(args);
            return;
        }
        _origWarn(...args);
    };

    console.error = function (...args) {
        if (shouldHideSessionLog(args)) {
            handleClosingSession(args);
            return;
        }
        _origError(...args);
    };

    console.log = function (...args) {
        if (shouldHideSessionLog(args)) {
            return;
        }
        _origLog(...args);
    };

    console.info = function (...args) {
        if (shouldHideSessionLog(args)) {
            return;
        }
        _origLog(...args);
    };
})();

let lastMessageTime = Date.now();
let lastSuccessfulReply = Date.now();
let isConnected = false;

let consecutiveForbiddenErrors = 0;
const MAX_FORBIDDEN_BEFORE_RECONNECT = 3;
let forbiddenReconnectScheduled = false;

const processedMessageIds = new Map();
const MESSAGE_ID_TTL = 60000;   

const MAX_PROCESSED_IDS = 20000; 

const badMacErrors = new Map();
const BAD_MAC_THRESHOLD = 15;    
const MAX_BAD_MAC_ENTRIES = 500; 

const recentGroupMessages = new Map();
const RECENT_MESSAGE_TTL = 5 * 60 * 1000; // 5 minutos

let cleanupInterval = null;
let badMacCleanupInterval = null;

function startCleanupIntervals() {
    if (cleanupInterval) clearInterval(cleanupInterval);
    if (badMacCleanupInterval) clearInterval(badMacCleanupInterval);

    cleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [id, ts] of processedMessageIds.entries()) {
            if (now - ts > MESSAGE_ID_TTL) processedMessageIds.delete(id);
        }

        if (processedMessageIds.size > MAX_PROCESSED_IDS) {
            const entries = Array.from(processedMessageIds.entries())
                .sort((a, b) => a[1] - b[1]);
            const toDelete = entries.slice(0, processedMessageIds.size - MAX_PROCESSED_IDS);
            toDelete.forEach(([id]) => processedMessageIds.delete(id));
        }

        for (const [groupId, groupMap] of recentGroupMessages.entries()) {
            for (const [msgId, msg] of groupMap.entries()) {
                const ts = (msg.messageTimestamp || 0) * 1000;
                if (!ts || now - ts > RECENT_MESSAGE_TTL) {
                    groupMap.delete(msgId);
                }
            }
            if (groupMap.size === 0) {
                recentGroupMessages.delete(groupId);
            }
        }
    }, MESSAGE_ID_TTL);

    badMacCleanupInterval = setInterval(() => {
        const now = Date.now();

        for (const [jid, data] of badMacErrors.entries()) {
            if (now - data.lastError > 1800000) { 
                badMacErrors.delete(jid);
            }
        }

        if (badMacErrors.size > MAX_BAD_MAC_ENTRIES) {
            const entries = Array.from(badMacErrors.entries())
                .sort((a, b) => a[1].lastError - b[1].lastError);
            const toDelete = entries.slice(0, badMacErrors.size - MAX_BAD_MAC_ENTRIES);
            toDelete.forEach(([jid]) => badMacErrors.delete(jid));
        }
    }, 180000);
}

startCleanupIntervals();

// ── LIMPIEZA AL CERRAR EL PROCESO ───────────────────────────────────────
process.on('SIGINT', async () => {
    console.log(chalk.yellow('\n🛑 Recibida señal SIGINT, cerrando bot...'));
    try {
        await tempCleaner.manualCleanup();
        tempCleaner.stopPeriodicCleanup();
        stopPetAutocuidado();
    } catch (e) {}
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log(chalk.yellow('\n🛑 Recibida señal SIGTERM, cerrando bot...'));
    try {
        await tempCleaner.manualCleanup();
        tempCleaner.stopPeriodicCleanup();
        stopPetAutocuidado();
    } catch (e) {}
    process.exit(0);
});
// ─────────────────────────────────────────────────────────────────────────

let _forceRestartInProgress = false;

async function forceRestart() {
    if (_forceRestartInProgress) return;
    _forceRestartInProgress = true;

    console.log(chalk.red('🔄 Apagando el proceso de Node.js (el watchdog/PM2 lo volverá a levantar en breve)...'));

    // ── LIMPIEZA ANTES DEL REINICIO ─────────────────────────────────────
    try {
        console.log(chalk.blue('[TempCleaner] 🧹 Limpieza final antes del reinicio...'));
        const result = await tempCleaner.manualCleanup();
        if (result.cleaned > 0) {
            console.log(chalk.green(`[TempCleaner] ✅ ${result.cleaned} archivos limpiados antes del reinicio`));
        }
        tempCleaner.stopPeriodicCleanup();
    } catch (error) {
        console.error(chalk.red('[TempCleaner] Error en limpieza final:'), error.message);
    }
    // ─────────────────────────────────────────────────────────────────────

    try { if (cleanupInterval) clearInterval(cleanupInterval); } catch (e) {}
    try { if (badMacCleanupInterval) clearInterval(badMacCleanupInterval); } catch (e) {}
    try { if (global._periodicRestartInterval) { clearInterval(global._periodicRestartInterval); global._periodicRestartInterval = null; } } catch (e) {}
    try { if (global._subbotsCleanupInterval) { clearInterval(global._subbotsCleanupInterval); global._subbotsCleanupInterval = null; } } catch (e) {}

    // ── LIMPIEZA DE SUBBOTS ANTES DEL REINICIO ─────────────────────────────
    console.log(chalk.blue('[SubBots] 🧹 Limpiando subbots antes del reinicio...'));
    if (global.subConns && Array.isArray(global.subConns)) {
        for (const subbot of global.subConns) {
            try {
                if (subbot?.ev) subbot.ev.removeAllListeners();
                if (subbot?.ws) subbot.ws.close();
                if (subbot?._cacheCleanupInterval) clearInterval(subbot._cacheCleanupInterval);
            } catch (e) {}
        }
        global.subConns = [];
        console.log(chalk.green('[SubBots] ✅ Subbots limpiados'));
    }
    // ─────────────────────────────────────────────────────────────────────

    // Modificación principal: forzamos el cierre agresivo de los WebSockets
    try {
        if (sock) {
            sock.ev.removeAllListeners();
            if (sock.ws) {
                sock.ws.close(); // Forzar cierre de conexión para evitar que se quede colgado
            }
            sock = null;
        }
    } catch (e) {}

    // Llamada de limpieza de basura de memoria (opcional, ayuda al reinicio)
    if (global.gc) {
        try { global.gc(); } catch (e) {}
    }

    setTimeout(() => {
        console.log(chalk.bgRed.white(' 🛑 FINALIZANDO PROCESO AHORA 🛑 '));
        process.exit(1); // Cierre absoluto del proceso bot.
    }, 1500);
}

// Exponer forceRestart globalmente para que el comando .reiniciar lo pueda llamar
global.forceRestart = forceRestart;

async function softReconnect(reason = 'desconocido') {
    if (isReconnecting || forbiddenReconnectScheduled) return;
    forbiddenReconnectScheduled = true;

    console.log(chalk.yellow(`🔄 Reconexión suave por: ${reason}. Reconectando en 8s...`));

    isConnected = false;

    // Anti-suspensión: delay más humano antes de reconectar (8s en vez de 3s)
    await new Promise(r => setTimeout(r, 8000));

    forbiddenReconnectScheduled = false;
    consecutiveForbiddenErrors = 0;

    try {
        await connectToWhatsApp();
    } catch (e) {
        console.error(chalk.red('Error en softReconnect:'), e.message);
    }
}

// ── CACHÉ DE VERSIÓN BAILEYS (anti-suspensión + resiliencia ante 405) ──────────
// FIX 405 (2026-07, actualizado): WhatsApp está rotando la versión de protocolo
// aceptada con mucha frecuencia estos días, así que fijar un solo número a mano
// deja de servir en cuestión de días. Ver hilos activos:
//   https://github.com/WhiskeySockets/Baileys/issues/2370
//   https://github.com/WhiskeySockets/Baileys/issues/2485 (contiene la versión
//   funcional más reciente reportada por la comunidad al momento de escribir esto)
//
// Estrategia (sugerida por un maintainer en el issue 2485):
//   1. Si existe la env var WA_BAILEYS_VERSION ("2,3000,1037641644"), se usa esa.
//   2. Si no, se usa el valor por defecto de abajo (actualizar cuando deje de andar).
//   3. Si falla con 405, se descarta el valor en caché y en el próximo intento se
//      hace fallback a fetchLatestBaileysVersion() (puede o no funcionar según el
//      momento, pero evita quedar trabado para siempre con el mismo número viejo).
//
// Cuando este número deje de funcionar de nuevo: revisar el issue 2485 (o buscar
// "baileys 405" en GitHub) por la versión más reciente reportada como funcional,
// y ponerla en WA_BAILEYS_VERSION sin tener que tocar el código.
const DEFAULT_BAILEYS_VERSION = [2, 3000, 1037641644];

let _baileysVersionCache = null;
let _usedFallback = false;

function parseEnvVersion() {
    const raw = process.env.WA_BAILEYS_VERSION;
    if (!raw) return null;
    const parts = raw.split(',').map(n => parseInt(n.trim(), 10));
    if (parts.length !== 3 || parts.some(n => Number.isNaN(n))) return null;
    return parts;
}

async function getBaileysVersion() {
    if (_baileysVersionCache) return _baileysVersionCache;

    const envVersion = parseEnvVersion();
    if (envVersion) {
        console.log(chalk.cyan(`[Baileys] Usando versión de env WA_BAILEYS_VERSION: ${envVersion.join('.')}`));
        _baileysVersionCache = envVersion;
    } else {
        console.log(chalk.cyan(`[Baileys] Usando versión fija por defecto: ${DEFAULT_BAILEYS_VERSION.join('.')}`));
        _baileysVersionCache = DEFAULT_BAILEYS_VERSION;
    }
    return _baileysVersionCache;
}

// Llamar esto cuando una conexión falle con 405: invalida la caché para que el
// próximo intento pruebe con fetchLatestBaileysVersion() en vez de repetir la
// misma versión rota indefinidamente.
async function invalidateBaileysVersionOnAuthFailure() {
    if (_usedFallback) return; // ya se usó el fallback, no insistir en loop
    _usedFallback = true;
    try {
        const { version } = await fetchLatestBaileysVersion();
        console.log(chalk.yellow(`[Baileys] Versión fija rechazada (405). Probando fetchLatestBaileysVersion(): ${version.join('.')}`));
        _baileysVersionCache = version;
    } catch (e) {
        console.error(chalk.red('[Baileys] fetchLatestBaileysVersion() también falló:'), e.message);
    }
}
// ──────────────────────────────────────────────────────────────────────────────

async function connectToWhatsApp() {

    let saveCreds;

    try {
        if (sock) {
            try {
                sock.ev.removeAllListeners('connection.update');
                sock.ev.removeAllListeners('creds.update');
                sock.ev.removeAllListeners('messages.upsert');
                sock.ev.removeAllListeners();
                if (sock.ws) sock.ws.close();
                sock = null;
            } catch (e) {
                console.error('Error limpiando socket:', e.message);
            }
        }

        const { state, saveCreds: _saveCreds } = await useSQLiteAuthState('./main-session.db');
        saveCreds = _saveCreds;
        try { global.saveMainCreds = _saveCreds; } catch (e) {}

        // Anti-suspensión: usar versión cacheada para evitar re-fetch en cada reconexión
        const version = await getBaileysVersion();

        console.log(chalk.cyan(`Baileys v${version.join('.')}`));

        sock = makeWASocket({
            version,
            logger: P({ level: 'silent' }),
            auth: {
                creds: state.creds,
                // Anti-suspensión: caché de claves Signal en memoria (evita I/O masivo en SQLite
                // por cada mensaje y previene desincronizaciones que WhatsApp detecta como sesión sospechosa)
                keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
            },
            msgRetryCounterCache: new Map(),
            // Anti-suspensión: desactivado para no generar requests extra a servidores WA
            generateHighQualityLinkPreview: false,
            defaultQueryTimeoutMs: 60000,
            // Anti-suspensión: Usar Windows/Chrome en lugar de macOS para evitar firmas sospechosas de Apple
            browser: Browsers.windows('Chrome'),
            // Anti-suspensión: 3s para reintentos progresivos menos agresivos ante micro-caídas
            retryRequestDelayMs: 3000,
            maxMsgRetryCount: 3,
            connectTimeoutMs: 60000,
            // Anti-suspensión: KeepAlive optimizado a 45s
            keepAliveIntervalMs: 45000,
            // Anti-suspensión: false evita que el bot aparezca online en el milisegundo exacto de conexión
            markOnlineOnConnect: false,
            syncFullHistory: false,
            // Anti-suspensión: ignorar estados/historias de contactos (evita ráfagas de paquetes al conectar)
            ignoreStatusBroadcast: true,
            // Anti-suspensión: no sincronizar historial al reconectar (evita tráfico masivo sospechoso)
            shouldSyncHistoryMessage: () => false,
            shouldIgnoreJid: (jid) => false,
            getMessage: async () => {
                return undefined;
            }
        });

        const originalGroupMetadata = sock.groupMetadata.bind(sock);

        sock.groupMetadata = async (jid) => {
            return await originalGroupMetadata(jid);
        };

        sock.fakeReply = async (jidChat, text, jidFakeSender, textFakeQuote, jidQuotedChat, options = {}) => {
            try {
                const fakeKey = {
                    remoteJid: jidQuotedChat || jidChat,
                    id: '3EB0' + require('crypto').randomBytes(12).toString('hex'),
                    participant: jidFakeSender,
                    fromMe: false
                };

                const quoted = {
                    key: fakeKey,
                    message: { extendedTextMessage: { text: textFakeQuote } }
                };

                return await sock.sendMessage(jidChat, { text: text }, { quoted, ...options });
            } catch (error) {
                console.error('Error fakeReply:', error.message);
            }
        };

        const originalSendMessage = sock.sendMessage.bind(sock);
        let consecutiveSendErrors = 0;
        let lastErrorTime = 0;
        let rateLimitCount = 0;
        let lastRateLimitTime = 0;

        sock.sendMessage = async (jid, content, options = {}) => {
            try {

                if (jid?.endsWith('@g.us') && saveCreds) {
                    try {
                        await saveCreds();
                    } catch (e) {
                        // Ignorar errores de saveCreds
                    }
                }

                const result = await originalSendMessage(jid, content, options);

                consecutiveSendErrors = 0;
                consecutiveForbiddenErrors = 0;
                rateLimitCount = 0;
                lastSuccessfulReply = Date.now();
                return result;
            } catch (error) {
                const now = Date.now();
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = error?.message || '';

                if (now - lastErrorTime > 30000) {
                    consecutiveSendErrors = 0;
                }

                lastErrorTime = now;
                consecutiveSendErrors++;

                if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                    rateLimitCount++;
                    const timeSinceLastRateLimit = now - lastRateLimitTime;
                    lastRateLimitTime = now;

                    const waitMs = rateLimitCount > 5 ? 5000 : 1500;
                    if (rateLimitCount % 5 === 0 || timeSinceLastRateLimit > 60000) {
                        console.log(chalk.yellow(`⏱️ Rate limit alcanzado (${rateLimitCount} veces) — pausando ${waitMs}ms`));
                    }

                    await new Promise(resolve => setTimeout(resolve, waitMs));

                    // Devolver una Promise rechazada en lugar de null
                    return Promise.reject(new Error('Rate limit exceeded'));
                }

                if (errorCode === 403 || errorCode === 401 || errorMsg.includes('forbidden')) {
                    consecutiveForbiddenErrors++;

                    console.log(chalk.yellow(`⚠️ Error ${errorCode || 'forbidden'} al enviar (${consecutiveForbiddenErrors}/${MAX_FORBIDDEN_BEFORE_RECONNECT})`));

                    if (consecutiveForbiddenErrors >= MAX_FORBIDDEN_BEFORE_RECONNECT) {

                        softReconnect(`${consecutiveForbiddenErrors} errores 403/forbidden consecutivos`);
                    }

                    // Devolver una Promise rechazada en lugar de null
                    return Promise.reject(new Error(`Forbidden error: ${errorCode}`));
                }

                if (errorMsg.includes('No sessions') || errorMsg.includes('no sessions')) {
                    if (!options._noSessionRetry) {
                        await new Promise(r => setTimeout(r, 1500));
                        try {
                            return await originalSendMessage(jid, content, { ...options, _noSessionRetry: true });
                        } catch (retryErr) {

                            const userNum = jid.split('@')[0].split(':')[0];
                            const sessionFile = path.join(__dirname, 'main-session.db');
                            // Con el archivo .db no podemos limpiar selectivamente por usuario
                            // como con los archivos individuales de baileys_auth
                            console.log(`[Session-Fix] Usuario ${userNum} - usando archivo .db principal`);

                            return Promise.reject(new Error('No sessions available'));
                        }
                    }
                    return Promise.reject(new Error('No sessions available'));
                }

                if (errorMsg.includes('ECONNRESET') || 
                    errorMsg.includes('ETIMEDOUT') || 
                    errorMsg.includes('ENOTFOUND') ||
                    errorMsg.includes('Connection Closed')) {
                    if (consecutiveSendErrors <= 3) {
                        return Promise.reject(new Error('Network error'));
                    }
                    console.log(chalk.yellow(`⚠️ Error de red temporal (${consecutiveSendErrors} veces)`));
                    return Promise.reject(new Error('Network error'));
                }

                // Baileys falla con 500 "missing <group> node" cuando WA devuelve
                // metadata inválida para el grupo (caída transitoria de servidores).
                // Se reintenta una vez tras un breve delay antes de propagar el error.
                if (
                    (errorCode === 500 || errorMsg.includes('missing <group> node') || errorMsg.includes('Invalid group metadata')) &&
                    !options._groupMetaRetry
                ) {
                    console.log(chalk.yellow('⚠️ Metadata de grupo inválida (error 500) — reintentando en 2s...'));
                    await new Promise(r => setTimeout(r, 2000));
                    try {
                        return await originalSendMessage(jid, content, { ...options, _groupMetaRetry: true });
                    } catch (retryErr) {
                        console.log(chalk.red('❌ Reintento fallido por metadata de grupo inválida'));
                        return Promise.reject(retryErr);
                    }
                }

                // Baileys a veces devuelve 428 "Precondition Required" con mensaje "Connection Closed"
                if (errorCode === 428 || errorMsg.includes('Precondition Required')) {
                    console.log(chalk.yellow('⚠️ Error 428 (Precondition Required) detectado — aplicando softReconnect')); 
                    try { softReconnect(errorMsg || `statusCode:${errorCode}`); } catch (_) {}
                    return Promise.reject(new Error('Precondition Required'));
                }

                if (consecutiveSendErrors <= 3) {
                    console.error(chalk.red(`Error sendMessage [${errorCode}]:`, error.message));
                }
                return Promise.reject(error);
            }
        };

        global.conn = sock;

        // ── Proxy inteligente para groupMetadata ─────────────────────────────
        // Cuando un plugin llama a global.conn.groupMetadata(jid), este proxy
        // busca automáticamente qué bot (principal o subbot) está en ese grupo
        // y usa el socket correcto. Así todos los plugins funcionan sin cambios.
        const _mainGroupMetadata = sock.groupMetadata.bind(sock);
        global.conn.groupMetadata = async (jid, retryCount = 0) => {
            // Intentar primero con el bot principal
            try {
                return await _mainGroupMetadata(jid);
            } catch (err) {
                const code = err?.data || err?.output?.statusCode;
                const msg  = err?.message || '';

                // 403: el bot principal no está en ese grupo → probar subbots.
                if (code === 403) {
                    const subs = (global.subConns || []).filter(c => c?.user);
                    for (const sub of subs) {
                        try {
                            return await sub.groupMetadata(jid);
                        } catch (_) {
                            // Este subbot tampoco está, probar el siguiente
                        }
                    }
                    // Ningún bot está en el grupo — relanzar el error original
                    throw err;
                }

                // 500 / "missing <group> node": WA devolvió metadata corrupta
                // (caída transitoria). Reintentar una vez tras un breve delay;
                // si sigue fallando, propagar el error original.
                if (
                    (code === 500 || msg.includes('missing <group> node') || msg.includes('Invalid group metadata')) &&
                    retryCount === 0
                ) {
                    console.log(chalk.yellow(`⚠️ groupMetadata 500 para ${jid} — reintentando en 2s...`));
                    await new Promise(r => setTimeout(r, 2000));
                    try {
                        return await global.conn.groupMetadata(jid, 1);
                    } catch (retryErr) {
                        // Si el retry también falla, intentar con subbots como último recurso
                        const subs = (global.subConns || []).filter(c => c?.user);
                        for (const sub of subs) {
                            try { return await sub.groupMetadata(jid); } catch (_) {}
                        }
                        throw retryErr;
                    }
                }

                // Cualquier otro error: relanzar sin más intentos
                throw err;
            }
        };

        if (global.db?.setConnection) {
            global.db.setConnection(sock);
            console.log(chalk.green('✓ BD OK'));
        }

        if (commandHandler?.destroy) commandHandler.destroy();
        commandHandler = new CommandHandler();
        global.commandHandler = commandHandler;

        if (muteSystem?.destroy) muteSystem.destroy();
        muteSystem = new MuteSystem(sock);
        global.muteSystem = muteSystem;
        console.log(chalk.green('✓ Muteo OK'));

        if (welcomeGoodbyeModule?.init) {
            try {
                welcomeGoodbyeModule.init(sock);
                console.log(chalk.green('✓ Bienvenida/Despedida OK'));
            } catch (error) {
                console.error(chalk.red('❌ Error iniciando Bienvenida/Despedida:'), error.message);
            }
        }

        // Inicializar sistema de recordatorios
        try {
            initRecordatorios(sock);
            console.log(chalk.green('✓ Recordatorios OK'));
        } catch (error) {
            console.error(chalk.red('❌ Error inicializando recordatorios:'), error.message);
        }

        // Inicializar autocuidado automático de mascotas premium
        try {
            initPetAutocuidado(sock);
            console.log(chalk.green('✓ Autocuidado mascotas premium OK'));
        } catch (error) {
            console.error(chalk.red('❌ Error inicializando autocuidado mascotas:'), error.message);
        }

        global.reload = async () => {
            try {
                console.log(chalk.yellow('Recargando...'));

                Object.keys(require.cache).forEach((key) => {
                    if (key.includes(__dirname) && !key.includes('node_modules') && !key.includes('SUBBOTS') && !key.includes('messageUtils')) {
                        delete require.cache[key];
                    }
                });

                require('./database');
                if (global.db?.setConnection) {
                    global.db.setConnection(sock);
                }
                if (global.db?.load) {
                    global.db.load();
                    console.log(chalk.green('✓ BD recargada'));
                }

                const Handler = require('./handler');
                if (commandHandler?.destroy) commandHandler.destroy();
                commandHandler = new Handler();
                global.commandHandler = commandHandler;
                console.log(chalk.green('✓ Handler recargado'));

                const NewMuteSystem = require('./muteSystem');
                if (sock?.user) {
                    if (muteSystem?.destroy) muteSystem.destroy();
                    muteSystem = new NewMuteSystem(sock);
                    global.muteSystem = muteSystem;
                    console.log(chalk.green('✓ Muteo recargado'));
                } else if (global.muteSystem) {
                    // Si el bot principal no está conectado, mantener el existente
                    muteSystem = global.muteSystem;
                    console.log(chalk.green('✓ Muteo recargado (conn pendiente)'));
                }

                // No hay sistema de recompensas automáticas que recargar.

                console.log(chalk.green('✓ Recarga completa'));
                return true;
            } catch (error) {
                console.error(chalk.red('Error reload:'), error.message);
                return false;
            }
        };

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                if (!mainQrShown) {
                    // Primera (y única) vez que mostramos el QR en este arranque
                    console.log(chalk.yellow('📱 QR generado — escanéalo con WhatsApp'));
                    qrcode.generate(qr, { small: true });
                    mainQrShown = true;
                } else {
                    // El QR anterior expiró y Baileys generó uno nuevo — lo ignoramos
                    console.log(chalk.gray('⏳ QR anterior ignorado (ya se mostró uno). Reinicia el servidor para generar un QR nuevo.'));
                }
                reconnectAttempts = 0;
                isConnected = false;
            }

            if (connection === 'close') {
                isConnected = false;

                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

                console.log(chalk.red('❌ Conexión cerrada'), { 
                    statusCode, 
                    shouldReconnect,
                    reason: lastDisconnect?.error?.message 
                });

                // ── QR expirado sin autenticar: NO reconectar el bot principal ──
                // Si el QR ya fue mostrado pero el bot nunca llegó a autenticarse
                // (mainAuthed === false), significa que el código expiró sin ser
                // escaneado. En ese caso dejamos el servidor vivo (los subbots
                // siguen funcionando) y solo avisamos por consola.
                if (mainQrShown && !mainAuthed) {
                    console.log(chalk.yellow(
                        '⚠️  El QR del bot principal expiró sin ser escaneado.\n' +
                        '    Los subbots siguen activos con normalidad.\n' +
                        '    Reinicia el servidor para generar un QR nuevo.'
                    ));
                    return; // No reconectar — evita el bucle infinito de QRs
                }

                // Manejo especial para timeouts / errores WebSocket (408, 428, Stream Errored, WebSocket Error)
                const errMsg = String(lastDisconnect?.error?.message || '');
                if (statusCode === 408 || statusCode === 428 || errMsg.includes('WebSocket Error') || errMsg.includes('Stream Errored')) {
                    console.log(chalk.yellow('⚠️ Cierre por WebSocket/timeout detectado — aplicando softReconnect con backoff'));
                    try {
                        await softReconnect(errMsg || `statusCode:${statusCode}`);
                    } catch (e) {
                        console.error(chalk.red('Error al ejecutar softReconnect:'), e.message || e);
                    }
                    return;
                }
                if (statusCode === 440 || statusCode === 401 || statusCode === 403) {
                    console.log(chalk.yellow('🔄 Sesión con error de auth — limpia manualmente si persiste'));
                    reconnectAttempts = 0;
                }

                // FIX 405: si la versión fijada fue rechazada por WhatsApp, probar
                // con fetchLatestBaileysVersion() en el próximo intento en vez de
                // repetir la misma versión rota en loop infinito.
                if (statusCode === 405) {
                    try { await invalidateBaileysVersionOnAuthFailure(); } catch (_) {}
                }

                if (shouldReconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS && !isReconnecting) {
                    reconnectAttempts++;
                    // Anti-suspensión: backoff mínimo 8s (antes 5s) para reconexiones más humanas
                    const delay = Math.min(8000 * reconnectAttempts, 30000);
                    console.log(chalk.yellow(`🔄 Reconectando en ${delay/1000}s (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`));
                    setTimeout(() => connectToWhatsApp(), delay);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.red('⚠️ Máximo de intentos alcanzado — reiniciando proceso...'));
                    setTimeout(() => {
                        reconnectAttempts = 0;
                        forceRestart();
                    }, 60000);
                }
            } else if (connection === 'open') {
                // El bot principal se autenticó correctamente
                mainAuthed = true;
                mainQrShown = false; // Reset para que futuros QR (tras desconexión real) se muestren
                console.log(chalk.green('✅ CONECTADO'));

                // ── LIMPIEZA AUTOMÁTICA DE ARCHIVOS TEMPORALES ──────────────
                // Limpiar archivos temporales al conectar y iniciar limpieza periódica
                setTimeout(async () => {
                    try {
                        console.log(chalk.blue('[TempCleaner] 🧹 Iniciando limpieza de archivos temporales...'));
                        const result = await tempCleaner.cleanTempFiles();
                        if (result.cleaned > 0) {
                            const sizeMB = (result.totalSize / (1024 * 1024)).toFixed(2);
                            console.log(chalk.green(`[TempCleaner] ✅ ${result.cleaned} archivos temporales limpiados (${sizeMB} MB liberados)`));
                        }
                        
                        // Iniciar limpieza periódica cada 5 minutos
                        tempCleaner.startPeriodicCleanup(5);
                    } catch (error) {
                        console.error(chalk.red('[TempCleaner] Error en limpieza inicial:'), error.message);
                    }
                }, 3000);
                // ─────────────────────────────────────────────────────────────

                // El reinicio automático del proceso fue desactivado.

                console.log(chalk.cyan(`Bot: ${sock.user?.id}`));

                global._botStartTime = Date.now();
                console.log(chalk.gray(`[MSG-FILTER] Ignorando mensajes anteriores a ${new Date(global._botStartTime).toLocaleTimeString()}`))

                if (sock.user?.id) {
                    global.mainBotNumber = sock.user.id.split('@')[0].split(':')[0];
                }

                // El servidor HTTP ya se inició al arranque del proceso, no volver a iniciarlo aquí

                reconnectAttempts = 0;
                isConnected = true;
                lastMessageTime = Date.now();
                isReconnecting = false;

                consecutiveForbiddenErrors = 0;
                forbiddenReconnectScheduled = false;

                // Actualizar la referencia conn del MuteSystem al conectarse el bot principal
                // (puede haber sido creado sin conn al arranque del proceso)
                if (global.muteSystem) {
                    global.muteSystem.conn = sock;
                    muteSystem = global.muteSystem;
                } else {
                    muteSystem = new MuteSystem(sock);
                    global.muteSystem = muteSystem;
                }

                // No unir el bot principal al grupo oficial.

                                // ── NUEVO: UNIÓN AUTOMÁTICA AL CANAL DE WHATSAPP ─────────────────
                setTimeout(async () => {
                    try {
                        const channelUrl = 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q';
                        const inviteCode = channelUrl.split('/').pop();
                        
                        if (inviteCode) {
                            console.log(chalk.blue(`[Canal] 🔍 Buscando ID para el canal público...`));
                            
                            // Obtiene los metadatos reales usando el código del enlace
                            const metadata = await sock.newsletterMetadata('invite', inviteCode);
                            
                            if (metadata && metadata.id) {
                                const channelJid = metadata.id;
                                console.log(chalk.blue(`[Canal] 🆔 ID detectado: ${channelJid}`));

                                // El bot sigue al canal de WhatsApp
                                await sock.newsletterFollow(channelJid);
                                console.log(chalk.green('[Canal] ✅ Bot siguiendo el canal exitosamente.'));
                            }
                        }
                    } catch (error) {
                        // Filtra el falso error de Baileys v7 si la suscripción ya está activa
                        if (error.message?.includes('unexpected response structure')) {
                            console.log(chalk.green('[Canal] ✅ Bot ya sigue el canal (confirmado).'));
                        } else {
                            // Muestra en rojo si es un error real diferente
                            console.error(chalk.red('[Canal] ❌ Error real al seguir el canal:'), error.message);
                        }
                    }
                }, 8000); // Se ejecuta a los 8 segundos para no colapsar la conexión inicial
                // ─────────────────────────────────────────────────────────────────

                try {
                    // El bot principal ya está conectado: actualizar la referencia conn en los subbots
                    // y reconectar cualquier subbot que no haya logrado conectarse antes.
                    const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
                    autoReconnectSubBots(sock).catch(e => {
                        console.error('[SubBot] Error auto-reconexión (post-login):', e.message);
                    });
                } catch (e) {
                    console.error('[SubBot] No se pudo cargar módulo de sub-bots:', e.message);
                }

                if (!global._botsOnlineInterval) {
                    // Heartbeat solo en consola (sin mensajes al grupo oficial)
                    setInterval(() => {
                        const active = (global.subConns || []).filter(c => c?.user);
                        console.log(chalk.bgYellow.black(` ⏳ [HEARTBEAT] Bot principal + ${active.length} subbot(s) activos `));
                    }, 50 * 60 * 1000);

                    global._botsOnlineInterval = true; // Marcar como inicializado
                    console.log(chalk.green('✓ Heartbeat: consola cada 50 min'));
                } else {
                    console.log(chalk.yellow('⚠️ Heartbeat ya estaba activo (reutilizando)'));
                }

                // ── Reinicio automático cada 4 horas (mismo mecanismo que .reiniciar) ──
                if (!global._periodicRestartInterval) {
                    const PERIODIC_RESTART_MS = 4 * 60 * 60 * 1000; // 4 horas en ms
                    global._nextRestartTime = Date.now() + PERIODIC_RESTART_MS;
                    global._periodicRestartInterval = setInterval(async () => {
                        console.log(chalk.bgMagenta.white(' 🔄 [AutoRestart] Reinicio automático de 4 horas iniciado... '));
                        try {
                            await forceRestart();
                        } catch (e) {
                            console.error('[AutoRestart] Error en reinicio automático:', e.message);
                            process.exit(1);
                        }
                    }, PERIODIC_RESTART_MS);
                    console.log(chalk.green(`✓ Reinicio automático: cada 4 horas`));
                } else {
                    console.log(chalk.yellow('⚠️ Reinicio automático ya estaba activo (reutilizando)'));
                }

                if (!global._subbotsCleanupInterval) {
                    global._subbotsCleanupInterval = setInterval(() => {
                        if (global.subConns && Array.isArray(global.subConns)) {
                            const before = global.subConns.length;
                            global.subConns = global.subConns.filter(c => c && c.user);
                            const after = global.subConns.length;
                            if (before > after) {
                                console.log(chalk.cyan(`🧹 Limpiados ${before - after} subbots desconectados`));
                            }
                        }
                    }, 5 * 60 * 1000);
                    console.log(chalk.green('✓ Limpieza de subbots cada 5 min'));
                }

                console.log(chalk.green('✓ Conectado'));
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            lastMessageTime = Date.now();

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;

                const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
                if (!msgTs || msgTs < global._botStartTime) continue;

                const messageId = baileyMessage.key.id;
                const remoteJid = baileyMessage.key.remoteJid;
                const cacheKey = `${remoteJid}:${messageId}`;

                if (processedMessageIds.has(cacheKey)) continue;
                processedMessageIds.set(cacheKey, Date.now());

                // Procesamiento concurrente no bloqueante por mensaje
                (async () => {
                    const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                    global._currentProcessingJid = senderJid;

                    if (remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        if (baileyMessage.message.protocolMessage?.type === 0 && baileyMessage.message.protocolMessage?.key) {
                            const deletedKey = baileyMessage.message.protocolMessage.key;
                            const groupMap = recentGroupMessages.get(remoteJid);
                            const original = groupMap?.get(deletedKey.id);

                            if (original && isBorradosEnabled(remoteJid)) {
                                await _handleBorradoMessage(sock, remoteJid, original);
                            }
                            return;
                        }

                        const groupMap = recentGroupMessages.get(remoteJid) || new Map();
                        groupMap.set(messageId, baileyMessage);
                        recentGroupMessages.set(remoteJid, groupMap);
                    }

                    // ── Mute: siempre corre ──
                    if (muteSystem && remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const wasDeleted = await muteSystem.checkAndDeleteMutedMessage(baileyMessage, sock);
                            if (wasDeleted) return;
                        } catch (e) { /* silencioso */ }
                    }

                    // ── Respuestas automáticas con caché de TTL ──
                    if (remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const respData = getRespuestasUsuariosData();
                            const senderNum = (baileyMessage.key.participant || baileyMessage.key.remoteJid).split('@')[0].split(':')[0];
                            const isMuted = global.muteSystem?.isUserMuted(remoteJid, senderNum);
                            if (!isMuted && respData[remoteJid]?.[senderNum]?.length) {
                                const lista = respData[remoteJid][senderNum];
                                const texto = lista[Math.floor(Math.random() * lista.length)];
                                await sock.sendMessage(remoteJid, { text: texto }, { quoted: baileyMessage });
                            }
                        } catch (e) { /* silencioso */ }
                    }

                    // ── Registro de actividad SIEMPRE ──
                    if (!baileyMessage.key.fromMe && remoteJid && remoteJid.endsWith('@g.us')) {
                        try {
                            const cleanSenderForRecord = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');
                            const msgTextForRecord = getMessageText(baileyMessage);
                            const msgTimestamp = (baileyMessage.messageTimestamp || 0) * 1000;

                            try {
                                const chatHistory = require('./chatHistory');
                                if (chatHistory.isReady) {
                                    chatHistory.recordMessage(remoteJid, cleanSenderForRecord, msgTextForRecord, msgTimestamp);
                                }
                            } catch (chErr) { /* silencioso */ }
                        } catch (actErr) { /* silencioso */ }
                    }

                    if (!isConnected) return;

                    const isFromMe = baileyMessage.key.fromMe;
                    const messageText = getMessageText(baileyMessage);
                    const prefixes = ['.', '/', '❤️', '#'];
                    const hasPrefix = prefixes.some(p => messageText.startsWith(p));
                    const hasQuotedContext = (msg) => {
                        const ctx = msg?.contextInfo
                                 || msg?.extendedTextMessage?.contextInfo
                                 || msg?.extendedTextMessageV2?.contextInfo
                                 || msg?.buttonsResponseMessage?.contextInfo
                                 || msg?.listResponseMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || null;
                        return !!(ctx?.quotedMessage || ctx?.stanzaId || ctx?.participant);
                    };
                    const isQuotedReply = hasQuotedContext(baileyMessage.message);

                    if (isFromMe && !hasPrefix && !isQuotedReply) return;

                    try {
                        const sender = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                        const senderNumber = sender.split('@')[0];

                        if (!global.db?.data) {
                            console.error('BD no inicializada');
                            return;
                        }

                        try {
                            await global.db.getUser(senderNumber);
                        } catch (error) {
                            console.error('Error obteniendo usuario (continuando igual):', error.message);
                        }

                        global.lastBaileyMessage = baileyMessage;
                        const compatibleMessage = createCompatibleMessage(baileyMessage, sock);

                        if (messageText && hasPrefix) {
                            const usedPrefix = prefixes.find(p => messageText.startsWith(p));
                            if (usedPrefix) {
                                const cmdName = messageText.slice(usedPrefix.length).trim().split(' ')[0].toLowerCase();
                                if (cmdName === 'botsonline' || cmdName === 'subbotsonline') {
                                    const chatJid = baileyMessage.key.remoteJid;
                                    const officialGroupJid = `120363426476029684@g.us`;
                                    if (chatJid === officialGroupJid) {
                                        try {
                                            await sock.sendMessage(officialGroupJid, {
                                                text: '🟢 *Bot principal activo* ✅'
                                            }, { quoted: baileyMessage });
                                        } catch (e) {
                                            console.error('[botsonline] Error:', e.message);
                                        }
                                        return;
                                    }
                                }
                            }
                        }

                        await commandHandler.handleMessage(compatibleMessage);

                    } catch (error) {
                        if (error.message?.includes('Bad MAC')) {
                            if (!badMacErrors.has(senderJid)) {
                                badMacErrors.set(senderJid, { count: 0, lastError: Date.now() });
                            }
                            const errorData = badMacErrors.get(senderJid);
                            errorData.count++;
                            errorData.lastError = Date.now();
                            console.error(chalk.red(`[BAD MAC] ${senderJid} (x${errorData.count}) — ignorado`));
                        } else {
                            console.error('Error proceso mensaje:', error.message);
                        }
                    } finally {
                        global._currentProcessingJid = null;
                    }
                })().catch(e => console.error('Error no capturado en mensaje:', e.message));
            }
        });

        sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
            if (!isConnected) return;
            // Solo nos interesan promote y demote (cambios de admin)
            if (action !== 'promote' && action !== 'demote') return;

            try {
                const groupMeta = await sock.groupMetadata(id).catch(() => null);
                const groupName = groupMeta?.subject || id;

                for (const participantJid of participants) {
                    const targetNum = participantJid.split('@')[0].split(':')[0];
                    const targetTag = `@${targetNum}`;

                    let msg;
                    if (action === 'promote') {
                        msg = `👑 *${targetTag} ahora es administrador del grupo*`;
                    } else {
                        msg = `👤 *${targetTag} ya no es administrador del grupo*`;
                    }

                    await sock.sendMessage(id, {
                        text: msg,
                        mentions: [participantJid]
                    });
                }
            } catch (e) {
                // silencioso
            }
        });

        return sock;
    } catch (error) {
        console.error(chalk.red('Error en connectToWhatsApp:'), error.message);

        if (!isReconnecting && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = 10000;
            console.log(chalk.yellow(`Reintentando en ${delay/1000}s...`));
            setTimeout(() => connectToWhatsApp(), delay);
        }
    }
}

function formatDuration(ms) {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours}h ${minutes}m ${seconds}s`;
}

function getActiveSubbotsCount() {
    return new Promise((resolve) => {
        const request = http.get('http://june.hidencloud.com:25196/subbots/list', (resp) => {
            let body = '';

            resp.on('data', (chunk) => {
                body += chunk.toString();
            });

            resp.on('end', () => {
                try {
                    const parsed = JSON.parse(body);
                    if (typeof parsed.total === 'number') {
                        return resolve(parsed.total);
                    }
                    if (Array.isArray(parsed.subbots)) {
                        return resolve(parsed.subbots.length);
                    }
                } catch (e) {
                    // Ignorar parseo inválido y dejar subbots como no disponible
                }
                resolve(null);
            });
        });

        request.on('error', () => resolve(null));
        request.setTimeout(3000, () => {
            request.destroy();
            resolve(null);
        });
    });
}

function startHealthServer() {
    const server = http.createServer(async (req, res) => {
        const active = isConnected === true;
        const uptimeMs = active ? Date.now() - (global._botStartTime || 0) : 0;
        const uptime = formatDuration(uptimeMs);
        const subbotsActive = await getActiveSubbotsCount();

        const payload = {
            active,
            uptime,
            uptimeSeconds: Math.max(0, Math.floor(uptimeMs / 1000)),
            subbotsActive
        };

        res.writeHead(200, {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
        });
        res.end(JSON.stringify(payload));
    });

    server.on('error', (err) => {
        console.error(chalk.red(`[HealthServer] Error en puerto ${HEALTH_PORT}:`), err.message);
    });

    server.listen(HEALTH_PORT, () => {
        console.log(chalk.green(`[HealthServer] Servidor de estado activo en http://localhost:${HEALTH_PORT}`));
    });
}

async function startServer() {
    console.log(chalk.cyan('🤖 RobleBOT Iniciando...'));
    startHealthServer();

    // ── Iniciar servidor HTTP y reconectar subbots INMEDIATAMENTE ────────────
    // No esperar a que el bot principal se escanee/conecte.
    // Los subbots tienen sus propias sesiones y se conectan de forma independiente.
    if (!global._subBotServerStarted) {
        global._subBotServerStarted = true;
        try {
            const { startSubBotServer } = require('./subbotServer');
            startSubBotServer(25196);
            console.log(chalk.green('[SubBotServer] ✓ Servidor HTTP iniciado (independiente del bot principal)'));
        } catch (e) {
            console.error(chalk.red('[SubBotServer] Error al iniciar:'), e.message);
        }
    }

    // Reconectar subbots existentes sin esperar al bot principal
    try {
        const { autoReconnectSubBots } = require('./plugins/SUBBOTS/subbot-serbot');
        console.log(chalk.cyan('[SubBot] Reconectando subbots (sin esperar al bot principal)...'));
        autoReconnectSubBots(null).catch(e => {
            console.error(chalk.red('[SubBot] Error auto-reconexión temprana:'), e.message);
        });
    } catch (e) {
        console.error(chalk.red('[SubBot] No se pudo cargar módulo de sub-bots:'), e.message);
    }

    // ── Inicializar MuteSystem al arranque sin esperar al bot principal ──────
    // Así los subbots pueden usar .mute/.unmute aunque el bot principal no esté conectado
    if (!global.muteSystem) {
        try {
            muteSystem = new MuteSystem(null);
            global.muteSystem = muteSystem;
            console.log(chalk.green('[MuteSystem] ✓ Inicializado al arranque (independiente del bot principal)'));
        } catch (e) {
            console.error(chalk.red('[MuteSystem] Error al inicializar temprano:'), e.message);
        }
    }
    // ─────────────────────────────────────────────────────────────────────────
    console.log(chalk.blue('🗜️ Ejecutando backup inicial...'));
    await backupToGithub().catch(e => console.error(chalk.red('Error backup inicial:'), e.message));

    try {
        await connectToWhatsApp();
    } catch (error) {
        console.error('Error conectar:', error.message);
    }

    const watcher = chokidar.watch([
        'plugins/**/*.js', 
        'handler.js', 
        'config.js', 
        'database.js', 
        'muteSystem.js',
        'messageUtils.js'
    ], {
        ignored: /(^|[\/\\])\../,
        persistent: true,
        ignoreInitial: true,
        usePolling: true,
        interval: 2000,
        cwd: __dirname
    });

    watcher.on('change', async (filePath) => {
        console.log(chalk.yellow(`${filePath} actualizado`));

        if (filePath.includes('menu.js')) {
            try {
                delete require.cache[require.resolve('./plugins/menu.js')];
                const menuHandler = require('./plugins/menu.js');
                if (menuHandler.saveMenuFile) {
                    menuHandler.saveMenuFile('.');
                    console.log(chalk.green('✓ menu.txt regenerado'));
                }
            } catch (error) {
                console.error(chalk.red('Error menu:'), error.message);
            }
        }

        if (watcher._reloadTimer) {
            clearTimeout(watcher._reloadTimer);
        }
        watcher._reloadTimer = setTimeout(async () => {
            watcher._reloadTimer = null;
            try {
                const fullPath = path.resolve(__dirname, filePath);
                
                // Si es un archivo de plugin específico, solo recargarlo
                if (filePath.startsWith('plugins/') && filePath.endsWith('.js')) {
                    console.log(chalk.cyan(`🔄 Recargando solo: ${filePath}`));
                    
                    // Limpiar caché del archivo específico
                    const resolvedPath = require.resolve(fullPath);
                    if (require.cache[resolvedPath]) {
                        delete require.cache[resolvedPath];
                    }
                    
                    // Recargar solo este plugin específico
                    if (global.commandHandler && global.commandHandler.loadPlugins) {
                        const success = global.commandHandler.loadPlugins(fullPath);
                        if (success) {
                            console.log(chalk.green(`✓ Plugin recargado: ${path.basename(filePath)}`));
                        } else {
                            console.log(chalk.red(`✗ Error recargando: ${path.basename(filePath)}`));
                        }
                    }
                } else {
                    // Para archivos del sistema (handler.js, config.js, etc.), recarga completa
                    console.log(chalk.cyan(`🔄 Archivo del sistema cambiado, recarga completa: ${filePath}`));
                    const resolvedPath = require.resolve(fullPath);
                    if (require.cache[resolvedPath]) {
                        delete require.cache[resolvedPath];
                    }
                    await global.reload();
                }
            } catch (error) {
                console.error(chalk.red(`Error reload: ${error.message}`));
            }
        }, 1500); // Reducido de 3000 a 1500ms para mayor velocidad
    });
}

process.on('unhandledRejection', (error) => {
    try {
        if (error && error.stack) console.error(chalk.red('Unhandled rejection:'), error.stack);
        else console.error(chalk.red('Unhandled rejection:'), error);
    } catch (e) {
        console.error(chalk.red('Unhandled rejection (no se pudo formatear):'), String(error));
    }
    // No forzamos reinicio aquí para evitar cascadas de desconexión.
});

process.on('uncaughtException', (error) => {
    const errorMsg = error?.message || '';
    const errorCode = error?.code || '';

    // 🚨 Si el error es ENOSPC, limpiar temporales y NO reiniciar el proceso
    if (errorMsg.includes('ENOSPC') || errorCode === 'ENOSPC') {
        console.error(chalk.red('[ENOSPC] 🚨 Sin espacio en disco (uncaughtException) — limpieza de emergencia...'));
        console.error(chalk.red('[ENOSPC] Error completo:'), error);
        try {
            // Limpieza sincrona de emergencia
            const { tempCleaner } = require('./tempCleaner');
            tempCleaner.emergencyCleanup().then(result => {
                console.log(chalk.green(`[ENOSPC] Limpieza de emergencia completada: ${result.cleaned} archivos borrados`));
            }).catch(e => {
                console.error('[ENOSPC] Error en limpieza:', e.message);
            });
        } catch (e) {
            console.error('[ENOSPC] No se pudo limpiar:', e.message);
        }
     
        return;
    }

    console.error(chalk.red('Uncaught exception:'), error);

});

startServer();