preguntas.md:
Información general, preguntas del bot y su creador: qué es RobleBOT, quién lo creó, como unir el bot a grupos, datos del creador como nombre, edad, origen, estudios, tecnologías que maneja, proyectos. También responde preguntas generales sobre el bot que no tienen un .md específico.

como-ganar-dinero.md:
Este documento resume los comandos y actividades disponibles en el bot para obtener monedas/coins: trabajo (.work, .study, .slut, .crime), caza, minería, robo, recompensa diaria, préstamos y juegos que dan coins.

como-ser-subbot.md:
Este documento explica cómo convertir tu número en un subbot usando .qr o .code en chat privado con el bot principal.

subbots.md:
Este documento explica cómo gestionar tu subbot: crearlo, encenderlo, apagarlo (global o por chat), configurar si responde en grupos o privados, reconectarlo y controlar los bots en un grupo (.bots on/off/admins).

descargas.md:
Este documento resume los comandos para descargar contenido multimedia: imágenes (Pinterest, .imagen), videos (YouTube, Instagram, TikTok, Facebook, Twitter, Threads) y audio/música (YouTube audio, Spotify, APK).

juegos.md:
Este documento explica los juegos del bot: duelo de piedra papel o tijera (.ppt reto/aceptar/rechazar/cancelar/piedra/papel/tijera) y minijuegos que dan coins (.describe, .emoji, .completar, .ordenar, .trivia).

admin-grupos.md:
Este documento explica los comandos para administradores de grupos: info y link del grupo, editar nombre y descripción, expulsar miembros, dar o quitar admin, sistema de advertencias/warns, abrir o cerrar el grupo y controlar subbots (.bots on/off/admins).

economia-banco.md:
Este documento explica los comandos de economía: ver saldo, depositar, retirar, regalar coins, ganar dinero trabajando y gestionar préstamos.

casino-apuestas.md:
Este documento explica los juegos de casino y apuestas: .apostar, .bj (blackjack), .slot, .caraocruz, .race y apostar contra otro usuario.

perfil-social.md:
Este documento explica los comandos de perfil y social: ver perfil, cambiar apodo y género, sistema de parejas (.pareja), registrar redes sociales y sistema de rangos (.rankup, .ranks, .rank).

coleccionables.md:
Este documento explica cómo reclamar, vender, regalar e intercambiar los coleccionables del bot: futbolistas (.fpj), personajes de anime (.pj) y famosos (.famoso / .myfamoso).

stickers-imagenes.md:
Este documento explica los comandos para crear stickers (.sticker, .brat, .brat2, .ss, .emojimix, .tts), obtener imágenes (.imagen, .waifu, .bts, .blackpink, .pinterest) y convertir stickers a imagen (.toimg).

herramientas-ia.md:
Este documento explica las herramientas de IA (.ia, .iavoz, .tradai), edición de archivos (.efecto, .removebg, .leer, .tav), clima (.clima) y buscadores de video (.ytsearch, .ttsearch).

stalkers.md:
Este documento explica los comandos para obtener información pública de perfiles en redes sociales y plataformas: YouTube, TikTok, Instagram, Twitter/X, Telegram, Threads, GitHub, Pinterest, Steam y Minecraft.

interacciones-random.md:
Este documento explica los comandos de interacción con usuarios (.love, .ship, .abrazar, .besar, .follar, .matar, .golpear), oráculos (.quien, .siono, .elegir, .quiero) y calculadoras random (.ego, .drama, .banana, .calcular1/2/3).

mensajes-privados.md:
Este documento explica el sistema de mensajes privados entre usuarios del bot usando .sms: enviar mensaje por apodo, ver bandeja de entrada y borrar mensajes.

comandos-personalizados.md:
Este documento explica cómo crear, ver y eliminar comandos personalizados con .addcmd, .mycmds y .delcmd, usando variables como @yo, @text, @random y @randomUser.

nsfw.md:
Este documento explica los comandos de contenido adulto (+18): descargar videos (.xnxx, .xvideos, .xvideossearch, .hentaiv) y obtener imágenes (.tetas, .hotgirl).
