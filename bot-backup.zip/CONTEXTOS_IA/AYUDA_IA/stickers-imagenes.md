# Stickers e imágenes (responde breve y directo)
Este documento explica los comandos para crear stickers, obtener imágenes y convertir contenido visual.

## Obtener imágenes
- `.imagen texto` — Genera o descarga una imagen a partir de un texto.
- `.pinterest texto` — Busca y descarga una imagen de Pinterest.
- `.waifu` — Obtené una imagen de waifu aleatoria.
- `.bts` — Obtené una imagen de BTS aleatoria.
- `.blackpink` — Obtené una imagen de Blackpink aleatoria.

## Crear stickers
- `.sticker` — Convertí una imagen, GIF o video corto en sticker (enviá el archivo y usá el comando).
- `.toimg` — Convertí un sticker a formato de imagen.
- `.brat texto` — Creá un sticker con texto estilo "Brat".
- `.brat2 texto` — Creá un sticker de video animado con texto estilo "Brat".
- `.ss búsqueda` — Buscá videos en Tenor y convertílos en sticker animado.
- `.emojimix emoji1 emoji2` — Combiná dos emojis en un sticker único.
- `.emojitos emoji` — Convertí un emoji en sticker.
- `.tts texto` — Creá un sticker simple con texto.
- `.tts texto color fondo` — Creá un sticker con texto, color de texto y color de fondo personalizados.
