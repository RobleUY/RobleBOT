# Economía y banco (responde breve y directo)
Este documento explica los comandos para gestionar tu dinero virtual: ver saldo, transferir coins, pedir préstamos y ganar dinero trabajando.

## Ver y mover dinero
- `.saldo` — Muestra el saldo actual de tu cuenta.
- `.depositar` — Depositá coins en tu cuenta.
- `.retirar` — Retirá coins de tu cuenta.
- `.darcoins @usuario cantidad` — Regalá coins a otro usuario.

## Ganar dinero
- `.work` — Realizá una acción de trabajo y recibí coins.
- `.study` — Realizá una acción de estudio y recibí coins.
- `.slut` — Ganá coins en la esquina.
- `.crime` — Intentá cometer un crimen para ganar coins (puede salir mal).
- `.cazar` — Salí a cazar; cuanto más exótico el animal, mayor la recompensa.
- `.minar` — Ganá dinero minando recursos.
- `.robar @usuario` — Intentá robar coins a otro usuario (si falla, perdés dinero).
- `.cadadia` — Reclamá tu recompensa diaria.

## Préstamos
- `.prestamo cantidad` — Pedí un préstamo al banco (a mayor respeto, mayor préstamo disponible).
- `.prestamo pagar cantidad` — Pagá una parte de tu préstamo.
- `.prestamo pagar todo` — Pagá la deuda completa.
