# Cómo descargar contenido con el bot (responde breve y directo)
Este documento resume los comandos disponibles en el bot para descargar imágenes, videos y audio desde distintas plataformas.

## Descargar imágenes
- `.pinterest texto`: Busca y descarga una imagen de Pinterest según el texto ingresado.
- `.imagen texto`: Genera o descarga una imagen a partir de un texto.

## Descargar video
- `.ytvideo título o enlace`: Descarga un video de YouTube usando el título o el link directo.
- `.instagram enlace`: Descarga un video o publicación de Instagram.
- `.threads enlace`: Descarga contenido de Threads.
- `.tiktok enlace`: Descarga un video de TikTok.
- `.facebook enlace`: Descarga un video de Facebook.
- `.twitter enlace`: Descarga un video o GIF de Twitter/X.

## Descargar audio / música
- `.ytaudio título o enlace`: Descarga el audio de un video de YouTube.
- `.spotify título o enlace`: Descarga una canción de Spotify.
- `.apk título`: Descarga un APK buscando por nombre.
