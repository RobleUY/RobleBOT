# Stalkers y búsqueda de perfiles (responde breve y directo)
Este documento explica los comandos para obtener información pública de perfiles en distintas redes sociales y plataformas.

## Redes sociales y plataformas
- `.ytstalk usuario` — Información de un canal de YouTube.
- `.ttstalk usuario` — Información de un perfil de TikTok.
- `.igstalk usuario` — Información de un perfil de Instagram.
- `.xstalk usuario` — Información de un perfil de Twitter/X.
- `.tgstalk usuario` — Información de un perfil de Telegram.
- `.thstalk usuario` — Información de un perfil de Threads.
- `.ghstalk usuario` — Información de un perfil de GitHub.
- `.ptstalk usuario` — Información de un perfil de Pinterest.
- `.steamstalk usuario` — Información de un perfil de Steam.
- `.mcstalk usuario` — Información de un perfil de Minecraft.
