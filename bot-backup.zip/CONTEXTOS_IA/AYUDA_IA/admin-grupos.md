# Administración de grupo (responde breve y directo)
Este documento explica los comandos disponibles para moderadores y administradores de grupos.

## Info y links
- `.infog` — Muestra la información del grupo.
- `.link` — Obtiene el enlace de invitación del grupo.

## Edición del grupo
- `.nameg texto` — Cambia el nombre del grupo.
- `.desc texto` — Cambia la descripción del grupo.

## Gestión de miembros
- `.kick @usuario` — Expulsa a un miembro del grupo.
- `.op @usuario` — Nombra a un miembro como administrador.
- `.deop @usuario` — Le quita el rol de administrador a un miembro.

## Sistema de advertencias
- `.warn @usuario razón` — Advierte a un miembro. Al acumular 3 warns es expulsado automáticamente.
- `.unwarn @usuario 1|2` — Elimina una advertencia específica de un miembro (indicá el número de warn).
- `.warneados` — Muestra todos los miembros con advertencias activas en el grupo.

## Apertura y cierre del grupo
- `.close` — Cierra el grupo (solo admins pueden escribir).
- `.open` — Abre el grupo (todos pueden escribir).

## Control de subbots
- `.bots on` — Enciende todos los subbots del grupo.
- `.bots off` — Apaga todos los subbots del grupo.
- `.bots admins` — Hace que los subbots solo puedan ser usados por administradores.
