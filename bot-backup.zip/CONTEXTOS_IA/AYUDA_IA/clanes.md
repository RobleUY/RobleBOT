# Sistema de Clanes (RobleBOT)

El sistema de clanes permite a los usuarios agruparse, competir en combates, depositar fondos y ascender en el ranking global de riqueza. Tiene mecánicas de guerra, reparación progresiva y economía interna.

## Comando Principal y Menú
- **.clan**: Muestra la lista interactiva de todos los comandos de clanes según los permisos del usuario. En cualquier comando que requiera un objetivo podés usar menciones (@usuario) o apodos directamente.

## Comandos de Información y Ranking
- **.clan top [página]**: Muestra el ranking global de clanes ordenados por dinero total depositado. Incluye la vida actual (HP) de cada clan. Cada página muestra 10 clanes.
- **.clan info [nombre]** (o **.clan informacion [nombre]**): Muestra la ficha completa del clan: líder, decanos, miembros, barra de vida (`[████████░░] 80/100 HP`), dinero depositado total, posición en el ranking global, estadísticas de combate (ataques realizados, ataques recibidos, clanes derrotados), Top 10 de miembros más depositantes, y el rol y dinero depositado del usuario que consulta. Si se especifica un nombre, muestra la info de ese clan.

## Sistema de Vida (HP)
- Cada clan tiene **100 HP** de vida máxima.
- Al llegar a 0 HP el clan es **destruido y eliminado permanentemente** de la base de datos.
- El HP se puede ver en `.clan info` y `.clan top`.

## Combate: Atacar Clanes
- **.clan atacar <nombre_clan>** (o **.clan attack <nombre_clan>**): Ataca a un clan enemigo causándole **-10 HP** de daño.
  - *Requisito*: Debes pertenecer a un clan para atacar. No puedes atacar a tu propio clan.
  - *Cooldown del atacante*: Un usuario solo puede realizar **1 ataque cada 30 minutos** (sin importar a qué clan ataque).
  - *Cooldown del defensor*: Un clan que recibe un ataque entra en **protección de 30 minutos** y no puede volver a ser atacado en ese tiempo.
  - *Sin notificaciones*: El clan atacado no recibe ningún aviso automático. Los miembros deben revisar periódicamente el estado de su clan con `.clan info`.
  - *Estadísticas*: Cada ataque incrementa `ataquesRealizados` en el clan atacante y `ataquesRecibidos` en el defensor.
  - *Destrucción*: Si el clan defensor llega a 0 HP, es **eliminado por completo**. Todo el dinero depositado en el clan destruido se reparte equitativamente entre los miembros del clan victorioso como **saldo depositado** en su propio clan (no va a la billetera personal). Se incrementa `clanesDerrotados` en el clan victorioso.

## Economía del Clan: Depósitos
- **.clan depositar <monto | % | all>** (también **.clan deposite**, **.clan dep**, **.clan d**): Deposita dinero de la billetera personal del usuario (`user.money`) al clan.
  - El dinero depositado queda vinculado al usuario que lo depositó dentro de `clan.depositos[usuario]`.
  - Solo el usuario que depositó puede usar ese dinero para reparar el clan.
  - El dinero depositado de todos los miembros activos suma para el ranking (`.clan top`) y el dinero total mostrado en `.clan info`.
  - ⚠️ **El dinero depositado al clan no se puede recuperar ni retirar.** Al depositar, el bot muestra obligatoriamente este aviso.
  - Acepta cantidades fijas (`dep 5000`), porcentajes (`dep 50%`) o todo (`dep all`).
  - El botín de guerra al destruir un clan enemigo se acredita también como dinero depositado (no va a la billetera personal).

## Reparación del Clan
- **.clan reparar [cantidad / all]** (o **.clan repair**): Restaura la vida del clan usando el saldo depositado por el usuario que ejecuta el comando.
  - **Costo progresivo**: El costo empieza en **$50,000 por 1 HP** y sube **+$50,000 por HP** en cada reparación que realice el clan (`clan.reparaciones`). Fórmula: `costoPorHP = 50000 + (clan.reparaciones × 50000)`.
  - Se puede reparar una cantidad específica de HP o usar `.clan reparar all` para restaurar el máximo posible con el saldo depositado disponible.
  - Si el saldo depositado es insuficiente para reparar 1 HP, muestra el costo actual y no hace nada.

## Crear y Renombrar Clan
- **.clan crear <nombre>** (o **.clan create <nombre>**): Crea un nuevo clan. El creador se convierte en Líder. Valores iniciales: vida 100/100 HP, 0 depósitos, estadísticas en 0.
  - *Reglas*: El nombre debe ir todo junto (sin espacios), máximo 30 caracteres, sin duplicados.
- **.clan nombre <nuevo_nombre>** (o **.clan name <nuevo_nombre>**): Cambia el nombre del clan. Solo Líder.

## Invitaciones y Membresía
- **.clan invitar @usuario / apodo** (o **.clan invite**): Invita a un usuario al clan. (Líder y Decanos. Límite: 30 miembros).
- **.clan invitar cancelar @usuario / apodo**: Cancela una invitación pendiente. (Líder y Decanos).
- **.clan invitaciones** (o **.clan invitations**): Lista las invitaciones a clanes que tiene pendientes el usuario.
- **.clan aceptar <nombre_clan / @invitador / apodo>** (o **.clan accept**): Acepta una invitación pendiente.
- **.clan rechazar <nombre_clan / @invitador / apodo>** (o **.clan reject**): Rechaza una invitación de clan.
- **.clan salir** (o **.clan leave**): Abandona el clan actual (requiere confirmar con `.clan salir confirmar`). *El líder no puede salirse sin transferir primero el liderazgo.*

## Administración de Miembros y Roles
- **.clan expulsar @usuario / apodo** (o **.clan kick**): Expulsa a un miembro del clan. (Líder y Decanos. Los decanos no pueden expulsar a otros decanos ni al líder).
- **.clan decano agregar @usuario / apodo** (o **.clan decano add**): Otorga el rol de Decano. (Solo Líder).
- **.clan decano borrar @usuario / apodo** (o **.clan decano delete**): Quita el rol de Decano. (Solo Líder).
- **.clan lider @usuario / apodo**: Transfiere el liderazgo (requiere confirmar con `.clan lider confirmar`). El líder actual pasa a ser miembro común.
- **.clan borrar** (o **.clan eliminar** / **.clan delete**): Elimina el clan por completo (requiere confirmar con `.clan borrar confirmar`). (Solo Líder).

## Jerarquía y Permisos
- **👑 Líder**: Puede invitar, cancelar invitaciones, expulsar, agregar/quitar decanos, transferir liderazgo, cambiar nombre y eliminar el clan.
- **⭐ Decano**: Puede invitar miembros, cancelar invitaciones y expulsar miembros comunes. No puede nombrar decanos, renombrar ni borrar el clan.
- **👤 Miembro**: Puede ver ranking (`.clan top`), ver info (`.clan info`), ver/aceptar/rechazar invitaciones, depositar dinero (`.clan depositar`), reparar el clan (`.clan reparar`) y salir (`.clan salir`).
