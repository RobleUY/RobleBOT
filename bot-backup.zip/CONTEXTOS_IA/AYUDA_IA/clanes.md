# Sistema de Clanes (RobleBOT)

El sistema de clanes permite a los usuarios agruparse, formar comunidades dentro del bot y competir en un ranking global de riqueza.

## Comando Principal y Menú
- **.clan**: Muestra la lista interactiva de todos los comandos de clanes según los permisos del usuario y explica que se pueden usar menciones (@usuario) o apodos en cualquier comando que requiera un objetivo.

## Comandos de Información y Ranking
- **.clan top [página]**: Muestra el ranking global de clanes ordenados de mayor a menor riqueza total (dinero en mano + banco de todos los miembros del clan). Cada página muestra 10 clanes con su posición, nombre, líder, número de miembros y dinero total.
- **.clan info [nombre]** (o **.clan informacion [nombre]**): Muestra la ficha técnica de tu clan (líder, decanos, número de miembros, dinero del clan, posición en el top global y tu rol actual). Si especificas un nombre de clan, muestra la información de dicho clan.

## Crear y Renombrar Clan
- **.clan crear <nombre>** (o **.clan create <nombre>**): Crea un nuevo clan y te convierte en el Líder.
  - *Reglas*: El nombre debe ir todo junto (sin espacios), máximo 30 caracteres y no debe existir otro clan con el mismo nombre. No puedes crear un clan si ya perteneces a uno.
- **.clan nombre <nuevo_nombre>** (o **.clan name <nuevo_nombre>**): Cambia el nombre del clan. Solo ejecutable por el Líder.

## Invitaciones y Membresía
- **.clan invitar @usuario / apodo** (o **.clan invite**): Invita a un usuario a unirse al clan. (Permitido para Líder y Decanos. Límite: 30 miembros por clan).
- **.clan invitar cancelar @usuario / apodo**: Cancela una invitación pendiente enviada a un usuario. (Permitido para Líder y Decanos).
- **.clan invitaciones** (o **.clan invitations**): Muestra la lista de invitaciones a clanes que has recibido, indicando el clan, el líder, miembros actuales, top global y quién te invitó.
- **.clan aceptar <nombre_clan / @invitador / apodo>** (o **.clan accept**): Acepta una invitación pendiente para unirte al clan.
- **.clan rechazar <nombre_clan / @invitador / apodo>** (o **.clan reject**): Rechaza una invitación de clan recibida.
- **.clan salir** (o **.clan leave**): Abandona el clan actual (requiere confirmación escribiendo `.clan salir confirmar`). Válido para miembros y decanos. *El líder no puede salirse directamente sin transferir primero el liderazgo.*

## Administración de Miembros y Roles
- **.clan expulsar @usuario / apodo** (o **.clan kick**): Expulsa a un miembro del clan. (Ejecutable por Líder y Decanos. Los decanos no pueden expulsar a otros decanos ni al líder).
- **.clan decano agregar @usuario / apodo** (o **.clan decano add**): Otorga permisos administrativos de Decano a un miembro. (Solo Líder).
- **.clan decano borrar @usuario / apodo** (o **.clan decano delete**): Quita el rol de Decano a un miembro. (Solo Líder).
- **.clan lider @usuario / apodo**: Transfiere el liderazgo del clan a otro miembro (requiere confirmación con `.clan lider confirmar`). El líder actual pasa a ser un miembro común.
- **.clan borrar** (o **.clan eliminar** / **.clan delete**): Elimina el clan por completo y expulsa a todos los miembros (requiere confirmación escribiendo `.clan borrar confirmar`). (Solo Líder).

## Jerarquía y Permisos
- **👑 Líder**: Puede invitar, cancelar invitaciones, expulsar miembros, agregar/quitar decanos, transferir liderazgo, cambiar nombre del clan y eliminar el clan.
- **⭐ Decano**: Puede invitar miembros, cancelar invitaciones y expulsar miembros comunes. No puede nombrar decanos, renombrar ni borrar el clan.
- **👤 Miembro**: Puede ver ranking (.clan top), ver info (.clan info), ver/aceptar/rechazar invitaciones y salir del clan (.clan salir).
