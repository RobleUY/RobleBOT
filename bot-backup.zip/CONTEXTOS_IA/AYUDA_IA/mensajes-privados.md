# Mensajes privados entre usuarios (responde breve y directo)
Este documento explica cómo enviar y recibir mensajes privados entre usuarios del bot usando el sistema de SMS interno.

## Comandos
- `.sms apodo mensaje` — Enviá un mensaje privado a otro usuario por su apodo.
- `.sms` — Mostrá tu bandeja de mensajes recibidos.
- `.sms borrar` — Borrá todos los mensajes de tu bandeja.

## Nota
Para poder enviarle un mensaje a alguien necesitás conocer su apodo dentro del bot. Los apodos se configuran con el comando `.apodo`.
