# Casino y apuestas (responde breve y directo)
Este documento explica los comandos de casino y apuestas disponibles en el bot para apostar coins.

## Juegos de casino
- `.apostar` — Apuesta directa de coins contra el bot.
- `.apostar @usuario` — Retá a otro usuario a una apuesta directa.
- `.bj` — Jugá al blackjack contra el bot.
- `.slot` — Tirá la palanca del tragamonedas.
- `.caraocruz` — Apostá al cara o cruz.
- `.race` — Apostá en una carrera.

## Consejos
Todos estos juegos implican riesgo: podés ganar o perder tus coins. Usá con cuidado.
