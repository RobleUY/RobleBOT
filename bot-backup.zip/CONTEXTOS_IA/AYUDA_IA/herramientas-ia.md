# Herramientas e inteligencia artificial (responde breve y directo)
Este documento explica los comandos de IA, edición de archivos, conversión de texto/audio y herramientas útiles del bot.

## Inteligencia artificial
- `.ia texto` — Chateá con la IA del bot de forma inteligente.
- `.iavoz texto` — Enviá una consulta y recibí la respuesta en nota de voz.
- `.tradai texto idioma` — Traducí texto a otro idioma usando IA (ej: .tradai Hola mundo inglés).

## Edición y conversión
- `.efecto` — Aplicá efectos a un audio (enviá la nota de voz y usá el comando).
- `.removebg` — Eliminá el fondo de una imagen (enviá la imagen y usá el comando).
- `.leer` — Transcribí el contenido de un audio o documento a texto.
- `.tav texto` — Convertí texto a audio (voz).

## Clima
- `.clima ciudad país` — Muestra el clima actual de una ciudad específica.

## Buscadores
- `.ytsearch texto` — Buscá videos en YouTube.
- `.ttsearch texto` — Buscá videos en TikTok.
