# Subbots (responde breve y directo)
Este documento explica cómo crear, encender, apagar y gestionar tu subbot en RobleBOT.

## Crear tu subbot
- `.qr` — Convertite en subbot escaneando un QR (solo en chat privado con un bot o subbot).
- `.code` — Convertite en subbot usando un código de vinculación (solo en chat privado con un bot o subbot).

## Encender y apagar
- `.bot encender` — Enciende tu subbot solo en el chat actual.
- `.bot apagar` — Apaga tu subbot solo en el chat actual.
- `.bot encender global` — Enciende tu subbot en todos los chats.
- `.bot apagar global` — Apaga tu subbot en todos los chats (los chats apagados manualmente siguen apagados al encender global).
- `.onmybot` — Alias rápido para encender tu subbot en el chat actual.
- `.offmybot` — Alias rápido para apagar tu subbot en el chat actual.

## Configurar comportamiento
- `.bot priv on` — El subbot responde en chats privados.
- `.bot priv off` — El subbot no responde en chats privados.
- `.bot grupo on` — El subbot responde en grupos.
- `.bot grupo off` — El subbot no responde en grupos.

## Otros
- `.reconectar` — Reconecta tu subbot si está caído o lento (solo en chat privado con el bot principal).
- `.mybot` — Muestra cuál es el ID de tu subbot.

## Control de bots en el grupo (solo admins)
- `.bots on` — Enciende todos los bots en el grupo.
- `.bots off` — Apaga todos los bots en el grupo.
- `.bots admins` — Pone todos los bots en modo solo administradores.
