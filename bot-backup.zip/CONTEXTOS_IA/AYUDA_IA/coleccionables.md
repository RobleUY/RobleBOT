# Coleccionables: futbolistas, personajes anime y famosos (responde breve y directo)
Este documento explica cómo reclamar, regalar e intercambiar los coleccionables del bot: futbolistas, personajes de anime y famosos.

## Futbolistas (.fpj)
- `.fpj reclamar` — Reclamá tu futbolista coleccionable diario.
- `.myfpj` — Muestra todos los futbolistas que tenés.
- `.fpj vender nombre cantidad` — Vendé una cantidad de ese futbolista.
- `.fpj vender nombre all` — Vendé todos los de ese futbolista.
- `.fpj regalar @usuario nombre` — Regalá un futbolista a otro usuario.
- `.fpj intercambio @usuario mifutbolista sufutbolista` — Proponé un intercambio de futbolistas.

## Personajes de anime (.pj)
- `.pj reclamar` — Reclamá tu personaje de anime coleccionable diario.
- `.mypj` — Muestra todos los personajes que tenés.
- `.pj vender nombre cantidad` — Vendé una cantidad de ese personaje.
- `.pj vender nombre all` — Vendé todos los de ese personaje.
- `.pj regalar @usuario nombre` — Regalá un personaje a otro usuario.
- `.pj intercambio @usuario mipersonaje supersonaje` — Proponé un intercambio de personajes.

## Famosos (.famoso)
- `.famoso reclamar` o `.famoso claim` — Reclamá un famoso aleatorio (1 por hora). Incluye celebridades de música, cine, deporte, tecnología y más.
- `.myfamoso` — Muestra todos los famosos que tenés en tu colección.
- `.famoso ver nombre` — Muestra la imagen de un famoso (solo si lo tenés en tu colección).
- `.famoso regalar @usuario nombre` — Regalá un famoso a otro usuario.
- `.famoso intercambio @usuario mifamoso sufamoso` — Proponé un intercambio de famosos.
- `.famoso intercambio aceptar @usuario` — Aceptá un intercambio propuesto.
- `.famoso intercambio rechazar @usuario` — Rechazá un intercambio propuesto.
