# Coleccionables: futbolistas y personajes anime (responde breve y directo)
Este documento explica cómo reclamar, vender, regalar e intercambiar los coleccionables del bot: futbolistas y personajes de anime.

## Futbolistas (.fpj)
- `.fpj reclamar` — Reclamá tu futbolista coleccionable diario.
- `.myfpj` — Muestra todos los futbolistas que tenés.
- `.fpj vender nombre cantidad` — Vendé una cantidad de ese futbolista.
- `.fpj vender nombre all` — Vendé todos los de ese futbolista.
- `.fpj regalar @usuario nombre` — Regalá un futbolista a otro usuario.
- `.fpj intercambio @usuario mifutbolista sufutbolista` — Proponé un intercambio de futbolistas.

## Personajes de anime (.pj)
- `.pj reclamar` — Reclamá tu personaje de anime coleccionable diario.
- `.mypj` — Muestra todos los personajes que tenés.
- `.pj vender nombre cantidad` — Vendé una cantidad de ese personaje.
- `.pj vender nombre all` — Vendé todos los de ese personaje.
- `.pj regalar @usuario nombre` — Regalá un personaje a otro usuario.
- `.pj intercambio @usuario mipersonaje supersonaje` — Proponé un intercambio de personajes.
