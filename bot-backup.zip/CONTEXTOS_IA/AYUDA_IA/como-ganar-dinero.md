# Cómo ganar dinero con el bot (responde breve y directo)
Este documento resume los comandos y actividades disponibles en el bot para obtener monedas/coins dentro del sistema económico.

## Comandos de trabajo
- `.work` — Realizá una acción de trabajo y recibí coins.
- `.study` — Realizá una acción de estudio y recibí coins.
- `.slut` — Ganá coins en la esquina.
- `.crime` — Intentá cometer un crimen para ganar coins (puede salir mal).
- `.cazar` — Salí a cazar; cuanto más exótico el animal, mayor la recompensa.
- `.minar` — Ganá dinero minando recursos.
- `.robar @usuario` — Intentá robar coins a otro usuario (si falla, perdés dinero).
- `.cadadia` — Reclamá tu recompensa diaria.

## Préstamos
- `.prestamo cantidad` — Pedí un préstamo al banco (a mayor respeto, mayor préstamo disponible).
- `.prestamo pagar cantidad` — Pagá una parte de tu préstamo.
- `.prestamo pagar todo` — Pagá la deuda completa.

## Juegos que dan coins
- `.trivia` — Respondé correctamente una pregunta de 4 opciones.
- `.completar` — Adiviná la palabra con letras faltantes.
- `.emoji` — Respondé con el emoji correcto según la pista.
- `.describe` — Describí lo que muestran los emojis del bot.
- `.ordenar` — Ordená la palabra desordenada que manda el bot.
