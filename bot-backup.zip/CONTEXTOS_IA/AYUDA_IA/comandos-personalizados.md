# Comandos personalizados (responde breve y directo)
Este documento explica cómo crear, ver y eliminar tus propios comandos personalizados dentro del bot.

## ¿Qué son?
Los comandos personalizados te permiten crear tus propios comandos con mensajes y menciones automáticas, usando variables especiales.

## Variables disponibles
- `@yo` — Se reemplaza por tu mención.
- `@text` — Se reemplaza por la mención o texto que escriba quien use el comando.
- `@random` — Se reemplaza por un número aleatorio del 1 al 100.
- `@randomUser` — Se reemplaza por un usuario aleatorio del grupo.

## Comandos
- `.addcmd .nombre mensaje` — Crea un comando personalizado con ese nombre y mensaje.
- `.mycmds` — Muestra todos tus comandos personalizados creados.
- `.delcmd .nombre` — Elimina uno de tus comandos personalizados.

## Ejemplos
- `.addcmd .suerte La suerte de @text es @random%`
- `.addcmd .abrazo @yo abraza a @text`
- `.addcmd .sorpresa @yo sorprende a @randomUser`
