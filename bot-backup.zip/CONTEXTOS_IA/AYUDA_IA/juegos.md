# Juegos del bot (responde breve y directo)
Este documento explica los juegos disponibles en el bot: el duelo de piedra papel o tijera (.ppt) y los minijuegos de grupo donde podés ganar coins.

## Piedra Papel o Tijera (.ppt)

Para jugar necesitás retar a otro usuario y que acepte el duelo.

Comandos del duelo:
- `.ppt @usuario` — Reta a un usuario a un duelo de piedra papel o tijera.
- `.ppt aceptar @usuario` — Acepta el duelo propuesto por ese usuario.
- `.ppt rechazar @usuario` — Rechaza el duelo propuesto por ese usuario.
- `.ppt cancelar` — Cancela un duelo que vos iniciaste.

Cómo funciona:
1. Retás a alguien con `.ppt @usuario`.
2. Si acepta, el bot les manda un mensaje privado a cada uno con las opciones.
3. Cada jugador elige en privado con `.ppt piedra`, `.ppt papel` o `.ppt tijera`.
4. Una vez que ambos eligen, el bot anuncia en el grupo quién ganó o si fue empate.

## Minijuegos de grupo (ganás coins si ganás)

- `.describe` — El bot te manda unos emojis y tenés que describir con palabras lo que estás viendo.
- `.emoji` — El bot te da una pista y tenés que responder con el emoji correcto.
- `.completar` — El bot te muestra una palabra con letras faltantes y tenés que adivinar cuál es.
- `.ordenar` — El bot te manda una palabra desordenada y tenés que escribirla correctamente.
- `.trivia` — El bot hace una pregunta con 4 opciones numeradas; respondé con el número de la opción correcta (1, 2, 3 o 4).

En todos estos juegos, si ganás recibís coins como recompensa.

## Sistema de Pene (.mipene / .toppenes)

Cada usuario tiene un pene virtual que empieza en 1 cm (nivel 0) y puede crecer comprando upgrades con coins.

Comandos:
- `.mipene` — Muestra tu tamaño actual, nivel, rango y cuánto cuesta el próximo upgrade.
- `.mipene upgrade` — Mejora tu pene +0.5 cm. Cada nivel cuesta más que el anterior (curva exponencial).
- `.mipene upgrade all` — Compra todos los upgrades posibles con tu saldo actual de una sola vez.
- `.mipene @usuario` o `.mipene apodo` — Muestra el pene de otro usuario.
- `.toppenes` — Muestra el ranking de penes del grupo (paginado, ej: `.toppenes 2` para la página 2).
- `.toppenes global` o `.toppenes g` — Ranking mundial de penes.
- `.toppenes global 2` — Página 2 del ranking mundial.

Rangos: hay 30 rangos según el tamaño, desde 🌱 Brote (1 cm) hasta ∞ El Infinito (202+ cm). Cuanto más nivel, más caro es cada upgrade. Solo aparecen en el ranking los usuarios que hicieron al menos 1 upgrade.

El comando `.mipene` y `.mipene @usuario` también muestra cuántas veces te lo han chupado y cuántas veces has chupado tú.

## Chupar pene (.chuparpene)

- `.chuparpene @usuario` — Le das +1 nivel gratis a ese usuario en su pene. Solo en grupos.
- Cooldown: cada usuario puede chupar 1 vez por hora, sin importar a quién. El target puede recibir chupadas de cualquiera sin límite propio.
- No puedes usarlo en ti mismo.
- El comando registra cuántas veces has chupado y cuántas veces te lo han chupado (visible en `.mipene`).

## Sistema de Vagina (.mivagina / .topvaginas)

Cada usuario tiene una vagina virtual que empieza en nivel 0 y puede subir de nivel comprando upgrades con coins. La lógica es idéntica al sistema de pene.

Comandos:
- `.mivagina` — Muestra tu nivel, rango, cuánto cuesta el próximo upgrade y stats de chupadas.
- `.mivagina upgrade` — Sube tu vagina 1 nivel. Cada nivel cuesta más que el anterior (curva exponencial).
- `.mivagina upgrade all` — Compra todos los upgrades posibles con tu saldo actual de una sola vez.
- `.mivagina @usuario` o `.mivagina apodo` — Muestra la vagina de otro usuario.
- `.topvaginas` — Ranking de vaginas del grupo (paginado, ej: `.topvaginas 2`).
- `.topvaginas global` o `.topvaginas g` — Ranking mundial de vaginas.

Rangos: hay 30 rangos propios, desde 🌱 Capullo hasta ∞ El Infinito. Solo aparecen en el ranking los usuarios que hicieron al menos 1 upgrade.

## Chupar vagina (.chuparvagina)

- `.chuparvagina @usuario` — Le das +1 nivel gratis a ese usuario en su vagina. Solo en grupos.
- Cooldown: cada usuario puede chupar 1 vez por hora, sin importar a quién. El target puede recibir chupadas de cualquiera sin límite propio.
- No puedes usarlo en ti mismo.
- El comando registra cuántas veces has chupado y cuántas veces te la han chupado (visible en `.mivagina`).

## Masturbar (.masturbar)

- `.masturbar` — Te masturbas a ti mismo: sube +1 nivel tanto tu pene como tu vagina a la vez.
- `.masturbar @usuario` — Masturbas a otro usuario: sube +1 nivel su pene y su vagina a la vez.
- Los dos usos tienen cooldowns **independientes**: podés masturbarte a ti mismo 1 vez por hora Y masturbar a otra persona 1 vez por hora, son contadores separados.
- A diferencia de chupar, sí podés usarlo en ti mismo.
- No hay restricción en el target (cualquiera puede recibir masturb de cualquiera sin cooldown propio).
