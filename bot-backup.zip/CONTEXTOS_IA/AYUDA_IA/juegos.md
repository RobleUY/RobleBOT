# Juegos del bot (responde breve y directo)
Este documento explica los juegos disponibles en el bot: el duelo de piedra papel o tijera (.ppt) y los minijuegos de grupo donde podés ganar coins.

## Piedra Papel o Tijera (.ppt)

Para jugar necesitás retar a otro usuario y que acepte el duelo.

Comandos del duelo:
- `.ppt @usuario` — Reta a un usuario a un duelo de piedra papel o tijera.
- `.ppt aceptar @usuario` — Acepta el duelo propuesto por ese usuario.
- `.ppt rechazar @usuario` — Rechaza el duelo propuesto por ese usuario.
- `.ppt cancelar` — Cancela un duelo que vos iniciaste.

Cómo funciona:
1. Retás a alguien con `.ppt @usuario`.
2. Si acepta, el bot les manda un mensaje privado a cada uno con las opciones.
3. Cada jugador elige en privado con `.ppt piedra`, `.ppt papel` o `.ppt tijera`.
4. Una vez que ambos eligen, el bot anuncia en el grupo quién ganó o si fue empate.

## Minijuegos de grupo (ganás coins si ganás)

- `.describe` — El bot te manda unos emojis y tenés que describir con palabras lo que estás viendo.
- `.emoji` — El bot te da una pista y tenés que responder con el emoji correcto.
- `.completar` — El bot te muestra una palabra con letras faltantes y tenés que adivinar cuál es.
- `.ordenar` — El bot te manda una palabra desordenada y tenés que escribirla correctamente.
- `.trivia` — El bot hace una pregunta con 4 opciones numeradas; respondé con el número de la opción correcta (1, 2, 3 o 4).

En todos estos juegos, si ganás recibís coins como recompensa.
