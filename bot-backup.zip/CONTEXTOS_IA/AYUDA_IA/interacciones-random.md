# Interacciones y comandos random (responde breve y directo)
Este documento explica los comandos de interacción con otros usuarios y las calculadoras/oráculos random del bot.

## Interacciones con usuarios
- `.love @usuario` — Muestra el porcentaje de amor entre vos y otro usuario.
- `.ship @usuario` — Shipea tu nombre con el de otro usuario.
- `.abrazar @usuario` — Abrazá a otro usuario.
- `.besar @usuario` — Besá a otro usuario.
- `.follar @usuario` — Interacción adulta con otro usuario.
- `.matar @usuario` — "Matá" a otro usuario (es un juego).
- `.golpear @usuario` — Golpeá a otro usuario.

## Oráculos y decisiones
- `.quien` — El bot elige a alguien al azar del grupo.
- `.siono` — El bot responde sí o no al azar.
- `.elegir opción1|opción2` — El bot elige entre las opciones que le des.
- `.quiero` — Respuesta random del bot.

## Calculadoras random
- `.calcular1` — Cálculo random 1.
- `.calcular2` — Cálculo random 2.
- `.calcular3` — Cálculo random 3.
- `.ego` — Muestra tu ego en porcentaje random.
- `.drama` — Muestra tu nivel de drama random.
- `.banana` — Resultado random de banana.
