# Perfil y social (responde breve y directo)
Este documento explica los comandos para ver y personalizar tu perfil, gestionar parejas, redes sociales y sistema de niveles.

## Perfil
- `.perfil` — Muestra tu perfil completo con estadísticas.
- `.nivel` — Muestra tu nivel actual y cuánta XP te falta para el siguiente.
- `.genero` — Cambia tu género en el perfil.
- `.apodo` — Cambia tu apodo en el perfil.

## Parejas
- `.pareja estado` — Muestra tu estado civil actual.
- `.pareja pedir @usuario` — Le pedís matrimonio a otro usuario.
- `.pareja aceptar @usuario` — Aceptás una propuesta de matrimonio.
- `.pareja rechazar @usuario` — Rechazás una propuesta de matrimonio.
- `.pareja romper` — Terminás tu relación actual.

## Redes sociales
- `.redes` — Muestra las redes sociales que tenés registradas.
- `.redes tiktok usuario` — Registra tu usuario de TikTok.
- `.redes instagram usuario` — Registra tu usuario de Instagram.

## Rangos
- `.rankup` — Sube de rango si cumplís los requisitos.
- `.ranks` — Muestra todos los rangos disponibles.
- `.rank` — Muestra tu rango actual.
