# Cómo ser subbot (responde breve y directo)
Este documento explica las formas de convertir tu sesión en un subbot o vincular un número para usar subbots.

## Desde el bot (chat privado con el bot principal)
- `.qr` — Convertite en subbot escaneando un código QR.
- `.code` — Convertite en subbot usando un código de vinculación.

Ambos comandos solo funcionan en chat privado con el bot principal: +59895122492

## ¿Qué es un subbot?
Un subbot es tu propia instancia del bot vinculada a tu número de WhatsApp. Podés controlarlo, encenderlo, apagarlo y configurar dónde responde.
