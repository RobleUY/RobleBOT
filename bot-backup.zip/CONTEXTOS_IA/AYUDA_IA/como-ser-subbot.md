# Cómo ser subbot (responde breve y directo)
Este documento explica las formas de convertir tu sesión en un subbot o vincular un número para usar subbots.

## Desde el bot
- `.qr` — Convertite en subbot escaneando un código QR.
- `.code` — Convertite en subbot usando un código de vinculación.

Podés usar estos comandos desde cualquier chat donde haya un Roblebot, sea privado o grupo.

## ¿Qué es un subbot?
Un subbot es tu propia instancia del bot vinculada a tu número de WhatsApp. Podés controlarlo, encenderlo, apagarlo y configurar dónde responde.
