# IAs personalizadas (responde breve y directo)
Este documento explica cómo crear, usar, ver y eliminar IAs personalizadas dentro del bot.

## ¿Qué son?
Las IAs personalizadas permiten a cualquier usuario crear su propio asistente con un nombre y una personalidad definidos por un prompt. Una vez creada, funciona como un comando con prefijo punto que cualquier persona puede usar.

## Límites
- Máximo 50 IAs personalizadas por usuario.
- El prompt tiene un máximo de 100 caracteres.

## Comandos
- `.addia .nombre prompt` — Crea una IA personalizada con ese nombre e instrucciones.
- `.myia` — Muestra todas las IAs personalizadas que creaste.
- `.topia [página]` — Muestra las IAs más usadas del bot (ranking global).
- `.delia .nombre` — Elimina una de tus IAs personalizadas.
- `.delia all` — Elimina todas tus IAs personalizadas de una vez.

## Usar una IA personalizada
Una vez creada, se usa igual que cualquier comando del bot:
`.nombreia mensaje`

## Ejemplos
- `.addia .chefbot Eres un chef experto que solo habla de cocina`
- `.chefbot ¿Cómo hago una pizza margarita?`
- `.addia .motivacion Eres un coach motivacional que responde con frases de aliento`
- `.delia .chefbot`
