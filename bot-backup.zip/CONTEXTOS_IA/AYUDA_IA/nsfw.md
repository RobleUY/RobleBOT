# Contenido +18 / NSFW (responde breve y directo)
Este documento explica los comandos de contenido adulto disponibles en el bot. Solo disponibles en chats habilitados para ello.

## Videos
- `.xnxx título o link` — Busca y descarga un video de XNXX.
- `.hentaiv` — Obtené un video hentai aleatorio.

## Imágenes
- `.tetas` — Obtené una imagen aleatoria.
- `.hotgirl` — Obtené una imagen de chica sexy aleatoria.
