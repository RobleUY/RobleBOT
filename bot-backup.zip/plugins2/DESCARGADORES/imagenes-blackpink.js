const axios = require('axios');

// 🔑 Claves API de Google
const GOOGLE_API_KEYS = [
    'AIzaSyDXkazQNz9Yt8f7Yr8yy-3JJ3RBEu1IVe8',
    'AIzaSyAZQ_WR4RwnziBRhsasG3jH8ofCgT6ebd4',
    'AIzaSyAXrqyXs4IcdOHvQfMYdkgebkWaoiazO4Q'
];

// 🔍 ID del motor de búsqueda (Custom Search Engine)
const GOOGLE_CX = '635e6b14f7cf84f2c';

// 🎤 Términos de búsqueda específicos para Blackpink
const BLACKPINK_TERMS = [
    'Blackpink group photo', 
    'Blackpink members', 
    'Blackpink Jennie', 
    'Blackpink Lisa', 
    'Blackpink Rosé', 
    'Blackpink Jisoo', 
    'Blackpink concert', 
    'Blackpink performance', 
    'Blackpink band photo', 
    'Blackpink official photo', 
    'Blackpink music video stills', 
    'Blackpink blinks',  // Para fans
    'Blackpink stage photo'
];

// 🧠 Cache simple + delay para evitar exceso de peticiones
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function buscarImagenBlackpink(termsArray, keyIndex = 0, retries = 3) {
    const randomTerm = termsArray[Math.floor(Math.random() * termsArray.length)];

    // Usa cache si ya existe una imagen para ese término
    if (imageCache.has(randomTerm)) return imageCache.get(randomTerm);
    if (keyIndex >= GOOGLE_API_KEYS.length) return null;

    const key = GOOGLE_API_KEYS[keyIndex];
    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(randomTerm)}&cx=${GOOGLE_CX}&key=${key}&searchType=image&num=5&safe=active`;  // SafeSearch activado para contenido seguro

    try {
        const response = await axios.get(url);
        if (response.data.items && response.data.items.length > 0) {
            const validImages = response.data.items.filter(item => 
                item.link && item.mime && item.mime.startsWith('image/')  // Filtrar solo imágenes
            );
            if (validImages.length > 0) {
                const randomImage = validImages[Math.floor(Math.random() * validImages.length)];
                imageCache.set(randomTerm, randomImage.link);
                return randomImage.link;
            }
        }
    } catch (error) {
        // Si la API key se agota, pasa a la siguiente
        if (error.response && (error.response.status === 429 || error.response.data?.error?.status === 'RESOURCE_EXHAUSTED') && retries > 0) {
            console.warn(`⚠️ Clave de API agotada, cambiando a la siguiente...`);
            await sleep(2000);
            return buscarImagenBlackpink(termsArray, keyIndex + 1, retries - 1);
        }
        console.error('Error en la búsqueda de imágenes de Blackpink:', error.message);
    }

    return null;
}

// 🎤 Handler principal del comando /blackpink
let handlerBlackpink = async (message, { conn }) => {
    try {
        const imageUrl = await buscarImagenBlackpink(BLACKPINK_TERMS);
        if (!imageUrl) return message.reply('❌ No se encontraron imágenes de Blackpink. Intenta de nuevo más tarde.');

        // Descargar imagen
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        // Enviar al chat como respuesta con el caption especificado
        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: '🖤 BlackPink 🩷'  // Caption con corazón negro y rosado
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('Error en /blackpink:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
};

// 📦 Exportación del comando
handlerBlackpink.command = /^blackpink/i;
handlerBlackpink.help = ['blackpink'];
handlerBlackpink.tags = ['fun', 'kpop'];  // Etiquetas para categorizar

module.exports = { blackpink: handlerBlackpink };