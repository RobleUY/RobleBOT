const axios = require('axios');

// 🧠 Cache simple + delay para evitar exceso de peticiones
const imageCache = new Map();
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Lista de APIs con su tipo (json o direct)
const apis = [
    { url: 'https://delirius-apiofc.vercel.app/anime/waifu', type: 'json' },
    { url: 'https://delirius-apiofc.vercel.app/anime/foxgirl', type: 'direct' },
    { url: 'https://delirius-apiofc.vercel.app/anime/mori_calliope', type: 'json' },
    { url: 'https://delirius-apiofc.vercel.app/anime/marin_kitagawa', type: 'json' },
    { url: 'https://delirius-apiofc.vercel.app/anime/uniform', type: 'json' }
];

// Función auxiliar para obtener imagen de APIs que devuelven JSON
async function getImageFromJsonApi(apiUrl, message, conn) {
    try {
        await message.reply('🔍 Buscando a tu waifu...');
        
        const response = await axios.get(apiUrl);
        if (response.data && response.data.status && response.data.data && response.data.data.image) {
            const imageUrl = response.data.data.image;
            
            if (imageCache.has(imageUrl)) {
                const cachedBuffer = imageCache.get(imageUrl);
                await conn.sendMessage(message.from, {
                    image: cachedBuffer,
                    caption: '💖 Imagen 💖'
                }, { quoted: message._baileyMessage });
                return;
            }

            const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(imageResponse.data, 'binary');
            imageCache.set(imageUrl, imageBuffer);

            await conn.sendMessage(message.from, {
                image: imageBuffer,
                caption: '💖 Tu Waifu 💖'
            }, { quoted: message._baileyMessage });
        } else {
            await message.reply('❌ No se pudo obtener la imagen. Intenta de nuevo más tarde.');
        }
    } catch (error) {
        console.error('Error:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
}

// Función auxiliar para obtener imagen directa de APIs que devuelven URL directa
async function getImageDirect(apiUrl, message, conn) {
    try {
        await message.reply('🔍 Buscando imagen hermosa...');
        
        const response = await axios.get(apiUrl);
        const imageUrl = response.data; // Asumiendo que devuelve directamente la URL
        
        if (imageCache.has(imageUrl)) {
            const cachedBuffer = imageCache.get(imageUrl);
            await conn.sendMessage(message.from, {
                image: cachedBuffer,
                caption: '💖 Imagen hermosa 💖'
            }, { quoted: message._baileyMessage });
            return;
        }

        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');
        imageCache.set(imageUrl, imageBuffer);

        await conn.sendMessage(message.from, {
            image: imageBuffer,
            caption: '💖 Imagen hermosa 💖'
        }, { quoted: message._baileyMessage });
    } catch (error) {
        console.error('Error:', error);
        await message.reply('❌ Ocurrió un error al obtener la imagen. Intenta de nuevo más tarde.');
    }
}

// 🍔 Handler principal del comando /waifu
let handlerWaifu = async (message, { conn }) => {
    // Seleccionar una API al azar
    const randomApi = apis[Math.floor(Math.random() * apis.length)];
    
    if (randomApi.type === 'json') {
        await getImageFromJsonApi(randomApi.url, message, conn);
    } else if (randomApi.type === 'direct') {
        await getImageDirect(randomApi.url, message, conn);
    }
};

// 📦 Exportación del comando
handlerWaifu.command = /^waifu(s)?/i;
handlerWaifu.help = ['waifu', 'waifus'];
handlerWaifu.tags = ['fun'];

module.exports = { waifu: handlerWaifu };
