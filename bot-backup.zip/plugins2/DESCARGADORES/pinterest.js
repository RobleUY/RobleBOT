const axios = require('axios');

// 🧠 Cache simple para resultados
const imageCache = new Map();

/**
 * 🔍 Buscar imágenes en Pinterest por texto.
 */
async function buscarPinterestTexto(query) {
    if (imageCache.has(query)) return imageCache.get(query);

    const url = `https://delirius-apiofc.vercel.app/search/pinterest?text=${encodeURIComponent(query)}`;
    const { data } = await axios.get(url);

    if (!data?.status || !data?.results?.length) return null;

    const valid = data.results.filter(r => typeof r === 'string' && r.startsWith('http'));
    if (valid.length === 0) return null;

    const random = valid[Math.floor(Math.random() * valid.length)];
    imageCache.set(query, random);
    return random;
}

/**
 * 📥 Descargar contenido (imagen o video) desde un enlace de Pinterest.
 */
async function descargarPinterestEnlace(link) {
    const url = `https://delirius-apiofc.vercel.app/download/pinterestdl?url=${encodeURIComponent(link)}`;
    const { data } = await axios.get(url);

    if (!data?.status || !data?.data?.download?.url) return null;

    return data.data;
}

/**
 * 🎯 Handler principal del comando /pinterest
 */
let handlerPinterest = async (message, { conn, text }) => {
    try {
        if (!text) {
            return await message.reply(
                '❌ *Uso correcto:*\n> .pinterest <texto o enlace de Pinterest>\n\n📌 Ejemplos:\n.pinterest paisajes\n.pinterest https://pin.it/2Vflx5O'
            );
        }

        const isUrl = /(https?:\/\/)?(www\.)?(pinterest\.com|pin\.it)\/[^\s]+/i.test(text);

        // -------------------------
        // 📎 Si es un enlace (descarga)
        // -------------------------
        if (isUrl) {
            await message.reply('📥 *Descargando contenido de Pinterest...*');

            const data = await descargarPinterestEnlace(text);
            if (!data) return await message.reply('❌ No se pudo descargar el contenido. Verifica el enlace.');

            const tipo = data.download.type || 'image';
            const caption = 
                `📌 *Pinterest Downloader*\n\n` +
                `📄 *Título:* ${data.title || 'Sin título'}\n` +
                `👤 *Autor:* ${data.username || 'Desconocido'}\n` +
                `📅 *Fecha:* ${data.upload || 'Desconocida'}`;

            if (tipo === 'video') {
                await conn.sendMessage(
                    message.from,
                    {
                        video: { url: data.download.url },
                        caption
                    },
                    { quoted: message._baileyMessage }
                );
            } else {
                await conn.sendMessage(
                    message.from,
                    {
                        image: { url: data.download.url },
                        caption
                    },
                    { quoted: message._baileyMessage }
                );
            }

            return;
        }

        // -------------------------
        // 🔍 Si es texto (búsqueda)
        // -------------------------
        await message.reply(`🔎 *Buscando en Pinterest...*\n> ${text}`);

        const imageUrl = await buscarPinterestTexto(text);
        if (!imageUrl)
            return await message.reply(`❌ No se encontraron resultados para: *${text}*`);

        // Descargar imagen y mandarla
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(imageResponse.data, 'binary');

        await conn.sendMessage(
            message.from,
            {
                image: imageBuffer,
                caption: `🎯 *Resultado de Pinterest*\n\n📌 *Búsqueda:* ${text}`
            },
            { quoted: message._baileyMessage }
        );

    } catch (error) {
        console.error('💥 Error en /pinterest:', error);
        await message.reply('❌ Ocurrió un error al procesar tu solicitud de Pinterest.');
    }
};

// 📦 Exportar comando
handlerPinterest.command = /^pinterest$/i;
handlerPinterest.help = ['pinterest <texto|url>'];
handlerPinterest.tags = ['imagenes', 'descargas'];

module.exports = { pinterest: handlerPinterest };
