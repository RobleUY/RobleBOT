/**
 * Comando: vat
 * Descripción: Transcribe audios, videos o archivos de texto plano (mp3, wav, mp4, txt, etc.) usando la API de Gemini.
 * Uso: responde a un audio, video o archivo con .vat
 */

const { downloadContentFromMessage } = require('@fadzzzslebew/baileys');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const FormData = require('form-data');
const fsSync = require('fs');
const execFileAsync = promisify(execFile);

const GROQ_API_KEY = "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";

/* --------------------------- FUNCIONES AUXILIARES --------------------------- */
function tmpFileName(ext = '') {
  return path.join(os.tmpdir(), crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : ''));
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
  return buffer;
}

async function detectQuotedFile() {
  const msg = global.lastBaileyMessage;
  if (!msg) return null;

  const context = msg.message?.extendedTextMessage?.contextInfo;
  if (!context?.quotedMessage) return null;

  const q = context.quotedMessage;
  let file = null;

  if (q.audioMessage) {
    const stream = await downloadContentFromMessage(q.audioMessage, 'audio');
    file = { data: await streamToBuffer(stream), mimetype: q.audioMessage.mimetype, type: 'audio' };
  } else if (q.videoMessage) {
    const stream = await downloadContentFromMessage(q.videoMessage, 'video');
    file = { data: await streamToBuffer(stream), mimetype: q.videoMessage.mimetype, type: 'video' };
  } else if (q.documentMessage) {
    const stream = await downloadContentFromMessage(q.documentMessage, 'document');
    file = {
      data: await streamToBuffer(stream),
      mimetype: q.documentMessage.mimetype,
      fileName: q.documentMessage.fileName,
      type: 'document'
    };
  }

  return file;
}

async function convertToWav(inputPath) {
  const output = tmpFileName('wav');
  await execFileAsync('ffmpeg', ['-y', '-i', inputPath, '-ar', '16000', '-ac', '1', output]);
  return output;
}

async function transcribeWithGroq(filePath) {
  const form = new FormData();
  form.append('file', fsSync.createReadStream(filePath), { filename: 'audio.wav', contentType: 'audio/wav' });
  form.append('model', 'whisper-large-v3');
  form.append('language', 'es');
  form.append('response_format', 'text');

  const res = await axios.post('https://api.groq.com/openai/v1/audio/transcriptions', form, {
    headers: {
      ...form.getHeaders(),
      'Authorization': `Bearer ${GROQ_API_KEY}`
    },
    timeout: 60000
  });

  return typeof res.data === 'string' ? res.data : res.data?.text || null;
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message) => {
  try {
    const quoted = await detectQuotedFile();

    if (!quoted) {
      return message.reply(
        '*🎙️ TRANSCRIPCIÓN / LECTURA DE ARCHIVOS*\n\n' +
        'Responde a un archivo con:\n' +
        '• *.vat*\n\n' +
        'Funciona con:\n' +
        '🎧 Audios y notas de voz\n🎬 Videos (mp4, mov)\n📄 txt, json, csv, yaml, xml, html, md, js, ts, py, sql, env, ini, y más\n\n' +
        'Ejemplo: responde a un audio o archivo con .vat'
      );
    }

    const loading = await message.reply('⏳ Procesando archivo...');

    const ext = quoted.fileName ? path.extname(quoted.fileName).toLowerCase().replace('.', '') : '';
    const tempFile = tmpFileName(ext || 'dat');
    await fs.writeFile(tempFile, quoted.data);

    let resultText = null;

    if (quoted.type === 'audio' || quoted.type === 'video') {
      const wav = await convertToWav(tempFile);
      resultText = await transcribeWithGroq(wav);
      await fs.unlink(wav).catch(() => {});
    } else if (quoted.type === 'document') {
      const TEXT_EXTS = [
        'txt', 'json', 'csv', 'log', 'yaml', 'yml', 'xml', 'html', 'htm',
        'md', 'markdown', 'js', 'ts', 'py', 'java', 'c', 'cpp', 'cs', 'go',
        'rb', 'php', 'sh', 'bat', 'ini', 'cfg', 'conf', 'env', 'toml',
        'sql', 'graphql', 'jsx', 'tsx', 'vue', 'css', 'scss', 'less', 'rs'
      ];
      const isKnownText = quoted.mimetype.startsWith('text/') ||
                          quoted.mimetype.includes('json') ||
                          quoted.mimetype.includes('xml') ||
                          quoted.mimetype.includes('yaml') ||
                          TEXT_EXTS.includes(ext);
      try {
        const raw = await fs.readFile(tempFile, 'utf8');
        // Si no es extensión conocida, verificar que no sea binario
        if (!isKnownText && /[\x00-\x08\x0E-\x1F]/.test(raw.slice(0, 512))) {
          return message.reply('❌ Archivo binario no soportado. Solo se pueden leer archivos de texto.');
        }
        resultText = raw;
      } catch {
        return message.reply('❌ No se pudo leer el archivo.');
      }
    }

    await fs.unlink(tempFile).catch(() => {});
    if (!resultText) return message.reply('❌ No se pudo obtener texto del archivo.');

    await message.reply(`📜 *Texto obtenido:*\n\n${resultText.trim()}`);
  } catch (err) {
    console.error('❌ Error en comando VAT:', err);
    await message.reply('❌ Ocurrió un error al procesar el archivo.');
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['vat'];
handler.tags = ['media', 'audio', 'document'];
handler.command = /^(vat|transcribir|leer|aat)$/i;

module.exports = handler;
