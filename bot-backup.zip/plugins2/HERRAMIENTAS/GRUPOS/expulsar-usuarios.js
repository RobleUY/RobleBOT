/**
 * Comando: kick
 * Descripción: Expulsa a un usuario del grupo
 * Uso: .kick @usuario o responder a un mensaje con .kick
 */

let handler = async (message, { conn }) => {
    try {
        // Verificar si es un grupo
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- Verificaciones de permisos ---
        
        // 1. Obtener metadatos del grupo
        const groupMetadata = await conn.groupMetadata(message.from);
        
        // 2. Obtener el número real del bot de diferentes maneras
        const botJid = conn.user.id;
        console.log('\x1b[36m[DEBUG] Bot JID desde conn.user.id:', botJid, '\x1b[0m');
        
        console.log('\x1b[36m[DEBUG] Participantes completos:\x1b[0m');
        groupMetadata.participants.forEach(p => {
            console.log(`  - ${p.id} (admin: ${p.admin || 'no'})`);
        });
        
        // Método: Buscar usando múltiples formatos
        const possibleBotNumbers = [
            botJid.split(':')[0].split('@')[0],
            botJid.split('@')[0].split(':')[0]
        ];
        
        console.log('\x1b[36m[DEBUG] Posibles números del bot:', possibleBotNumbers, '\x1b[0m');
        
        // Buscar al bot en los participantes probando diferentes formatos
        let botParticipant;
        
        for (const participant of groupMetadata.participants) {
            const participantNumber = participant.id.split('@')[0].split(':')[0];
            
            // Verificar si coincide con alguno de los posibles números
            if (possibleBotNumbers.includes(participantNumber)) {
                botParticipant = participant;
                console.log('\x1b[32m[DEBUG] ¡Bot encontrado! Participant:', participant.id, '\x1b[0m');
                break;
            }
            
            // También verificar si el participant.id contiene alguna parte del botJid
            if (participant.id.includes(possibleBotNumbers[0]) || participant.id.includes(possibleBotNumbers[1])) {
                botParticipant = participant;
                console.log('\x1b[32m[DEBUG] ¡Bot encontrado por coincidencia parcial! Participant:', participant.id, '\x1b[0m');
                break;
            }
        }
        
        console.log('\x1b[36m[DEBUG] Bot Participant encontrado:', botParticipant, '\x1b[0m');
        
        // Si no encontramos el bot, buscar quién envió el mensaje de comando
        if (!botParticipant) {
            console.log('\x1b[33m[WARN] No se encontró el bot por número, buscando de otra forma...\x1b[0m');
            
            // Buscar el participante que tenga el mismo formato que los mensajes del bot
            botParticipant = groupMetadata.participants.find(p => {
                return p.id.includes('@lid') && p.admin;
            });
            
            console.log('\x1b[36m[DEBUG] Bot encontrado como admin con @lid:', botParticipant, '\x1b[0m');
        }
        
        // Verificar si el bot es administrador
        const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
        
        console.log('\x1b[36m[DEBUG] Bot es admin?:', botIsAdmin, '\x1b[0m');
        
        if (!botIsAdmin) {
            return await message.reply('❌ No puedo expulsar usuarios porque *no soy administrador* del grupo.');
        }
        
        // 3. Verificar si el usuario que ejecuta el comando es administrador
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        console.log('\x1b[36m[DEBUG] User JID:', userJid, '\x1b[0m');
        console.log('\x1b[36m[DEBUG] User número:', userNumber, '\x1b[0m');
        
        const userParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        console.log('\x1b[36m[DEBUG] User Participant encontrado:', userParticipant, '\x1b[0m');
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // --- Obtener el usuario a expulsar ---
        
        let targetUser = null;
        let targetJid = null;
        
        // Método 1: Si se mencionó a un usuario con @
        if (message.mentions && message.mentions.length > 0) {
            targetJid = message.mentions[0];
            console.log('\x1b[36m[DEBUG] Usuario mencionado:', targetJid, '\x1b[0m');
        }
        // Método 2: Si se respondió a un mensaje
        else if (message.quoted) {
            targetJid = message.quoted.sender;
            console.log('\x1b[36m[DEBUG] Usuario del mensaje citado:', targetJid, '\x1b[0m');
        }
        // Método 3: Si se escribió el número sin @
        else {
            const text = message.body.split(' ')[1];
            if (text) {
                // Limpiar el número (quitar caracteres no numéricos)
                const cleanNumber = text.replace(/\D/g, '');
                if (cleanNumber) {
                    targetJid = `${cleanNumber}@s.whatsapp.net`;
                    console.log('\x1b[36m[DEBUG] Número detectado:', targetJid, '\x1b[0m');
                }
            }
        }
        
        if (!targetJid) {
            return await message.reply('⚠️ Debes *mencionar* a un usuario con @ o *responder* a su mensaje.\n\n*Ejemplos:*\n`.kick @usuario`\n`.kick 5491123456789`\nO responder a un mensaje con `.kick`');
        }
        
        // Buscar al usuario objetivo en los participantes
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        
        console.log('\x1b[36m[DEBUG] Buscando usuario objetivo con número:', targetNumber, '\x1b[0m');
        
        const targetParticipant = groupMetadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            console.log(`  - Comparando ${participantNumber} con ${targetNumber}`);
            return participantNumber === targetNumber;
        });
        
        console.log('\x1b[36m[DEBUG] Target Participant encontrado:', targetParticipant, '\x1b[0m');
        
        if (!targetParticipant) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }
        
        // Verificar que no intenten expulsar al bot
        if (botParticipant && targetParticipant.id === botParticipant.id) {
            return await message.reply('❌ No puedo expulsarme a mí mismo del grupo. 😅');
        }
        
        // Verificar que no intenten expulsar a otro admin (opcional, puedes quitarlo si quieres)
        const targetIsAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin';
        
        if (targetIsAdmin && userParticipant.admin !== 'superadmin') {
            return await message.reply('❌ No puedes expulsar a otro administrador.');
        }
        
        // --- Acción de expulsar ---
        
        try {
            console.log('\x1b[33m[INFO] Expulsando a:', targetParticipant.id, '\x1b[0m');
            
            // Expulsar al usuario
            await conn.groupParticipantsUpdate(
                message.from,
                [targetParticipant.id],
                'remove'
            );
            
            console.log('\x1b[32m[SUCCESS] Usuario expulsado correctamente\x1b[0m');
            
            // Obtener nombre del usuario expulsado
            const targetName = message.quoted?.pushName || 
                              targetNumber || 
                              'Usuario';
            
            // Enviar mensaje de confirmación
            await message.reply(`✅ *Usuario expulsado correctamente.*`);
            
        } catch (kickError) {
            console.error('\x1b[31m[ERROR] Error al expulsar:', kickError, '\x1b[0m');
            console.error('\x1b[31m[ERROR] Stack:', kickError.stack, '\x1b[0m');
            
            if (kickError.toString().includes('forbidden') || kickError.toString().includes('403')) {
                return await message.reply('❌ No tengo permisos suficientes para expulsar a este usuario.');
            }
            
            return await message.reply('❌ Ocurrió un error al intentar expulsar al usuario.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
        }

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error general en comando kick:', error, '\x1b[0m');
        console.error('\x1b[31m[ERROR] Stack:', error.stack, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error inesperado al ejecutar el comando.\n\nRecuerda que para que esta función pueda ser utilizada, el bot necesita ser administrador del grupo.');
    }
};

// --- Configuración del Handler ---
handler.help = ['kick @usuario', 'expulsar @usuario', 'echar @usuario'];
handler.tags = ['admin'];
handler.command = /^(kick|expulsar|echar)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;