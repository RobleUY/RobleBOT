const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones
const GRUPOS_DIR = path.join(__dirname, 'GRUPOS');
const NSFW_FILE = path.join(GRUPOS_DIR, 'nsfw.json');

// Asegurar que el directorio existe
if (!fs.existsSync(GRUPOS_DIR)) {
    fs.mkdirSync(GRUPOS_DIR, { recursive: true });
}

// Cargar lista de grupos con NSFW activado
function loadNsfwGroups() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando nsfw.json:', error.message);
    }
    return [];
}

// Guardar lista de grupos con NSFW activado
function saveNsfwGroups(groups) {
    try {
        fs.writeFileSync(NSFW_FILE, JSON.stringify(groups, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando nsfw.json:', error.message);
        return false;
    }
}

// Verificar si NSFW está activado en un grupo (si está en la lista = activado)
function isNsfwEnabled(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    return groups.includes(cleanJid);
}

// Activar NSFW (agregar grupo a la lista)
function enableNsfw(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    
    if (!groups.includes(cleanJid)) {
        groups.push(cleanJid);
        return saveNsfwGroups(groups);
    }
    return true; // Ya estaba activado
}

// Desactivar NSFW (quitar grupo de la lista)
function disableNsfw(groupJid) {
    const groups = loadNsfwGroups();
    const cleanJid = groupJid.split('@')[0];
    
    const index = groups.indexOf(cleanJid);
    if (index > -1) {
        groups.splice(index, 1);
        return saveNsfwGroups(groups);
    }
    return true; // Ya estaba desactivado
}

// Comando .nsfw
let handler = async (message, { conn }) => {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo
        const groupMetadata = await conn.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        
        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender;
        const userNumber = userJid.split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = p.id.split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener argumentos del comando
        const args = message.body.split(/\s+/).slice(1);

        // Si no hay argumentos, mostrar estado actual
        if (args.length === 0) {
            const isEnabled = isNsfwEnabled(chatId);
            const status = isEnabled ? '🔓 Activado' : '🔒 Desactivado';
            
            let texto = '🔞 *NSFW*\n\n';
            texto += `📊 *Estado actual:* ${status}\n\n`;
            texto += `💡 *Uso:*\n`;
            texto += `   • .nsfw on - Activar NSFW\n`;
            texto += `   • .nsfw off - Desactivar NSFW\n\n`;
            texto += `ℹ️ Por defecto está desactivado. Cuando está desactivado, solo los admins pueden usar comandos NSFW.`;
            
            return await message.reply(texto);
        }

        // Procesar comando on/off
        const action = args[0]?.toLowerCase();

        if (!['on', 'off', 'activar', 'desactivar'].includes(action)) {
            return await message.reply('⚠️ Usa: .nsfw on/off');
        }

        const enable = ['on', 'activar'].includes(action);

        if (enable) {
            // Activar NSFW
            if (isNsfwEnabled(chatId)) {
                return await message.reply('ℹ️ El contenido NSFW ya está activado en este grupo.');
            }
            if (enableNsfw(chatId)) {
                await message.reply('✅ *Contenido NSFW ACTIVADO*\n\nAhora todos los miembros pueden usar comandos NSFW en este grupo.');
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        } else {
            // Desactivar NSFW
            if (!isNsfwEnabled(chatId)) {
                return await message.reply('ℹ️ El contenido NSFW ya está desactivado en este grupo.');
            }
            if (disableNsfw(chatId)) {
                await message.reply('🔒 *Contenido NSFW DESACTIVADO*\n\nLos miembros ya no pueden usar comandos NSFW en este grupo.\n\n_Los administradores aún pueden usarlos._');
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        }

    } catch (error) {
        console.error('Error en comando nsfw:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['nsfw on', 'nsfw off'];
handler.tags = ['group', 'admin'];
handler.command = /^(nsfw)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.loadNsfwGroups = loadNsfwGroups;
module.exports.isNsfwEnabled = isNsfwEnabled;
module.exports.NSFW_FILE = NSFW_FILE;