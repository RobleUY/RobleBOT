const db = require('../database.js');

let handler = async (message, { text, args }) => {
    try {
        if (!db.data || !db.data.users) {
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        }

        const users = Object.values(db.data.users);
        const total = users.length;

        const conApodo = users.filter(u => 
            u.apodo && 
            u.apodo.trim() !== '' && 
            u.apodo !== 'sin apodo'
        );

        const sinApodo = total - conApodo.length;

        const porcentaje = total > 0 
            ? ((conApodo.length / total) * 100).toFixed(1) 
            : 0;

        const respuesta = 
            `📊 *ESTADÍSTICAS DE APODOS* 📊\n\n` +
            `👥 Total de usuarios: *${total}*\n` +
            `🎭 Con apodo: *${conApodo.length}*\n` +
            `❌ Sin apodo: *${sinApodo}*\n` +
            `📈 Adopción: *${porcentaje}%*\n\n` +
            `💡 Usa \`.apodo TuApodo\` para registrar el tuyo`;

        return await message.reply(respuesta);

    } catch (error) {
        console.error('Error en comando apodostotal:', error);
        return await message.reply('❌ Ocurrió un error al consultar los apodos.');
    }
};

handler.help = ['apodostotal'];
handler.tags = ['fun', 'juegos'];
handler.command = /^(apodostotal|totalapodos|nickstotal)$/i;
handler.group = true;

module.exports = handler;