const el = id => document.getElementById(id);
function setMsg(id, txt){ const e = el(id); if(e) e.innerText = txt }

async function post(path, body){
  const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  return res.json();
}

el('btnLogin').addEventListener('click', async ()=>{
  const code = el('code').value.trim();
  setMsg('loginMsg','')
  if(!code){ setMsg('loginMsg','Ingresa el código'); return }
  const r = await post('/api/login',{code});
  if(!r.success){ setMsg('loginMsg', r.error || 'Error'); return }
  localStorage.setItem('rb_token', r.token);
  // Redirect to app
  window.location.href = '/app';
});

// If already logged, redirect to /app
if(localStorage.getItem('rb_token')){
  window.location.href = '/app';
}
