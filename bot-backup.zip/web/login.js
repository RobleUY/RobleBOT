const apiBase = '';
const el = id => document.getElementById(id);
function setMsg(id, txt){ el(id).innerText = txt }

async function post(path, body){
  const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  return res.json();
}

el('btnLogin').addEventListener('click', async ()=>{
  const code = el('code').value.trim();
  setMsg('loginMsg','')
  if(!code){ setMsg('loginMsg','Ingresa el código'); return }
  const r = await post('/api/login',{code});
  if(!r.success){ setMsg('loginMsg', r.error || 'Error'); return }
  localStorage.setItem('rb_token', r.token);
  setMsg('loginMsg','Sesión iniciada');
  showPanel();
});

async function showPanel(){
  const token = localStorage.getItem('rb_token');
  if(!token) return;
  const profileRes = await fetch(`/api/profile?token=${token}`);
  const pj = await profileRes.json();
  if(!pj.success){ setMsg('loginMsg', pj.error || 'Token inválido'); return }
  el('panel').style.display = 'block';
  el('profile').innerText = `Apodo: ${pj.profile.apodo}\nSaldo: $${pj.profile.dinero}  Banco: $${pj.profile.banco}`;
}

el('btnApodo').addEventListener('click', async ()=>{
  const token = localStorage.getItem('rb_token');
  const apodo = el('apodo').value.trim();
  setMsg('apodoMsg','')
  if(!token) { setMsg('apodoMsg','No autenticado'); return }
  const r = await post('/api/change-apodo',{ token, apodo });
  if(!r.success) setMsg('apodoMsg', r.error || 'Error'); else { setMsg('apodoMsg','Apodo actualizado'); showPanel(); }
});

el('btnDaily').addEventListener('click', async ()=>{
  const token = localStorage.getItem('rb_token'); setMsg('actionMsg','');
  const r = await post('/api/daily',{ token });
  if(!r.success) setMsg('actionMsg', r.error || JSON.stringify(r)); else setMsg('actionMsg', r.result || '¡Diaria reclamada!'); showPanel();
});

el('btnWork').addEventListener('click', async ()=>{
  const token = localStorage.getItem('rb_token'); setMsg('actionMsg','');
  const r = await post('/api/work',{ token });
  if(!r.success) setMsg('actionMsg', r.error || JSON.stringify(r)); else setMsg('actionMsg', r.result || 'Trabajo hecho'); showPanel();
});

el('btnBet').addEventListener('click', async ()=>{
  const token = localStorage.getItem('rb_token'); const amount = el('betAmount').value.trim(); setMsg('betMsg','');
  const r = await post('/api/bet',{ token, amount });
  if(!r.success) setMsg('betMsg', r.error || JSON.stringify(r)); else setMsg('betMsg', r.result || 'Apuesta procesada'); showPanel();
});

// Auto-show if token exists
if(localStorage.getItem('rb_token')) showPanel();
