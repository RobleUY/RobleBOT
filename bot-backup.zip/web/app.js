const el = id => document.getElementById(id);
function setTxt(id, txt){ const e=el(id); if(e) e.innerText = txt }
async function post(path, body){
  const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  return res.json();
}

function token(){return localStorage.getItem('rb_token')}
function log(msg){ const l = el('log'); if(l){ const p=document.createElement('div'); p.innerText = msg; l.prepend(p);} }

async function loadProfile(){
  const t = token(); if(!t) { window.location.href='/login'; return }
  const r = await fetch(`/api/profile?token=${t}`); const j = await r.json();
  if(!j.success){ localStorage.removeItem('rb_token'); window.location.href='/login'; return }
  el('apodoVal').innerText = j.profile.apodo;
  el('nivelVal').innerText = j.profile.nivel;
  el('moneyVal').innerText = `$${(j.profile.dinero||0).toLocaleString()}`;
  el('bankVal').innerText = `$${(j.profile.banco||0).toLocaleString()}`;
}

el('btnLogout').addEventListener('click', ()=>{ localStorage.removeItem('rb_token'); window.location.href='/login'; });

el('btnChangeApodo').addEventListener('click', async ()=>{
  const a = el('apodoInput').value.trim(); setTxt('bankMsg',''); if(!a) return log('Ingresa apodo');
  const r = await post('/api/change-apodo',{ token: token(), apodo: a });
  if(!r.success) { log('Error: '+(r.error||JSON.stringify(r))); } else { log('Apodo actualizado'); loadProfile(); }
});

el('btnDailyApp').addEventListener('click', async ()=>{
  setTxt('bankMsg',''); const r = await post('/api/daily',{ token: token() });
  if(!r.success) log('Error: '+(r.error||JSON.stringify(r))); else { log('Diaria: '+JSON.stringify(r.result)); loadProfile(); }
});

el('btnWorkApp').addEventListener('click', async ()=>{
  setTxt('bankMsg',''); const r = await post('/api/work',{ token: token() });
  if(!r.success) log('Error: '+(r.error||JSON.stringify(r))); else { log('Trabajo: '+JSON.stringify(r.result)); loadProfile(); }
});

el('btnDeposit').addEventListener('click', async ()=>{
  const amt = el('bankAmount').value.trim(); if(!amt) return; setTxt('bankMsg','');
  const r = await post('/api/deposit',{ token: token(), amount: amt });
  if(!r.success) setTxt('bankMsg', r.error||'Error'); else { setTxt('bankMsg','Depósito procesado'); log('Depósito: '+JSON.stringify(r.result)); loadProfile(); }
});

el('btnWithdraw').addEventListener('click', async ()=>{
  const amt = el('bankAmount').value.trim(); if(!amt) return; setTxt('bankMsg','');
  const r = await post('/api/withdraw',{ token: token(), amount: amt });
  if(!r.success) setTxt('bankMsg', r.error||'Error'); else { setTxt('bankMsg','Retiro procesado'); log('Retiro: '+JSON.stringify(r.result)); loadProfile(); }
});

el('btnBetApp').addEventListener('click', async ()=>{
  const amt = el('betAmountApp').value.trim(); if(!amt) return; const r = await post('/api/bet',{ token: token(), amount: amt });
  if(!r.success) setTxt('betMsgApp', r.error||'Error'); else { setTxt('betMsgApp','Apuesta procesada'); log('Apuesta: '+JSON.stringify(r.result)); loadProfile(); }
});

// Load on start
loadProfile();
