const fs = require('fs').promises;
const path = require('path');

const BAILEYS_AUTH_DIR = './baileys_auth';
const SUBBOTS_SESIONES_DIR = './plugins/SUBBOTS/sesiones';

// Límites para bot principal
const LIMITS_MAIN = {
  'pre-key-':            100,
  'device-list-':         20,
  'lid-mapping-':         50,
  'session-':             10,
  'sender-key-':          30,
  'app-state-sync-key-':   5,
};

// Límites más agresivos para subbots
const LIMITS_SUBBOT = {
  'pre-key-':             50,
  'device-list-':         10,
  'lid-mapping-':         20,
  'session-':              5,
  'sender-key-':          15,
  'app-state-sync-key-':   3,
};

async function isValidJson(filePath) {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    JSON.parse(content);
    return true;
  } catch {
    return false;
  }
}

async function cleanupDir(dir, pattern, limit) {
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    // Filtrar solo archivos que coincidan con el patrón
    const matching = entries.filter(e => e.isFile() && e.name.startsWith(pattern) && e.name.endsWith('.json'));

    if (matching.length === 0) return 0;

    // Obtener mtime de cada archivo en paralelo
    const files = await Promise.all(
      matching.map(async e => {
        const filePath = path.join(dir, e.name);
        const stat = await fs.stat(filePath);
        return { name: e.name, path: filePath, mtime: stat.mtimeMs };
      })
    );

    // Ordenar: más recientes primero
    files.sort((a, b) => b.mtime - a.mtime);

    let deleted = 0;

    // Separar corruptos de válidos
    const corruptFiles = [];
    const validFiles = [];

    for (const file of files) {
      if (await isValidJson(file.path)) {
        validFiles.push(file);
      } else {
        corruptFiles.push(file);
      }
    }

    // Borrar corruptos
    for (const file of corruptFiles) {
      try {
        await fs.unlink(file.path);
        deleted++;
        console.log(`  🗑️  Corrupto eliminado: ${file.name}`);
      } catch (err) {
        console.error(`  ❌ Error eliminando corrupto ${file.name}:`, err.message);
      }
    }

    // De los válidos, borrar los que exceden el límite (los más viejos)
    const toDelete = validFiles.slice(limit);
    for (const file of toDelete) {
      try {
        await fs.unlink(file.path);
        deleted++;
      } catch (err) {
        console.error(`  ❌ Error eliminando ${file.name}:`, err.message);
      }
    }

    const kept = validFiles.length - toDelete.length;
    if (deleted > 0) {
      console.log(`  🧹 ${pattern}: ${deleted} eliminados (${corruptFiles.length} corruptos + ${toDelete.length} exceso), mantenidos ${kept}`);
    } else {
      console.log(`  ✅ ${pattern}: ${files.length} archivos (ok)`);
    }

    return deleted;

  } catch (err) {
    console.error(`  ❌ Error procesando ${pattern} en ${dir}:`, err.message);
    return 0;
  }
}

async function cleanupSession(dir, label, limits) {
  try {
    await fs.access(dir);
  } catch {
    return 0;
  }

  const entries = await fs.readdir(dir);
  console.log(`\n📁 ${label} (${entries.length} archivos)`);

  let deleted = 0;
  for (const [pattern, limit] of Object.entries(limits)) {
    deleted += await cleanupDir(dir, pattern, limit);
  }

  return deleted;
}

async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧹 LIMPIEZA DE SESIONES BAILEYS');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  let totalDeleted = 0;

  // Limpiar baileys_auth (bot principal)
  try {
    await fs.access(BAILEYS_AUTH_DIR);
    totalDeleted += await cleanupSession(BAILEYS_AUTH_DIR, 'baileys_auth (bot principal)', LIMITS_MAIN);
  } catch {
    console.log('\n⚠️  No existe baileys_auth, saltando...');
  }

  // Limpiar sesiones de subbots
  try {
    await fs.access(SUBBOTS_SESIONES_DIR);
    const entries = await fs.readdir(SUBBOTS_SESIONES_DIR, { withFileTypes: true });
    const subbots = entries
      .filter(e => e.isDirectory())
      .map(e => e.name)
      .sort();

    for (const subbot of subbots) {
      const subbotDir = path.join(SUBBOTS_SESIONES_DIR, subbot);
      totalDeleted += await cleanupSession(subbotDir, `SUBBOT sesion/${subbot}`, LIMITS_SUBBOT);
    }
  } catch {
    console.log('\n⚠️  No existe plugins/SUBBOTS/sesiones, saltando...');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ LIMPIEZA COMPLETADA`);
  console.log(`🗑️  Total archivos eliminados: ${totalDeleted}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

main().catch(console.error);
