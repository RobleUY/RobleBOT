const fs = require('fs');
const path = require('path');

const BAILEYS_AUTH_DIR = './baileys_auth';
const SUBBOTS_SESIONES_DIR = './plugins/SUBBOTS/sesiones';

// Configuración de límites para bot principal
const LIMITS_MAIN = {
  'pre-key-':          100,
  'device-list-':       20,
  'lid-mapping-':       50,
  'session-':           10,
  'sender-key-':        30,
  'app-state-sync-key-': 5,
};

// Límites más agresivos para subbots (tienen miles de archivos)
const LIMITS_SUBBOT = {
  'pre-key-':          50,
  'device-list-':      10,
  'lid-mapping-':      20,
  'session-':           5,
  'sender-key-':       15,
  'app-state-sync-key-': 3,
};

function cleanupDir(dir, pattern, limit) {
  try {
    const files = fs.readdirSync(dir)
      .filter(f => f.startsWith(pattern) && f.endsWith('.json'))
      .map(f => ({
        name: f,
        path: path.join(dir, f),
        mtime: fs.statSync(path.join(dir, f)).mtime
      }))
      .sort((a, b) => b.mtime - a.mtime); // Más recientes primero

    if (files.length <= limit) {
      console.log(`  ✅ ${pattern}: ${files.length} archivos (dentro del límite de ${limit})`);
      return 0;
    }

    const toDelete = files.slice(limit);
    let deleted = 0;

    for (const file of toDelete) {
      try {
        fs.unlinkSync(file.path);
        deleted++;
      } catch (err) {
        console.error(`  ❌ Error eliminando ${file.name}:`, err.message);
      }
    }

    console.log(`  🧹 ${pattern}: Eliminados ${deleted}/${toDelete.length} (mantenidos ${limit})`);
    return deleted;

  } catch (err) {
    console.error(`  ❌ Error procesando ${pattern}:`, err.message);
    return 0;
  }
}

function cleanupSession(dir, label, limits) {
  if (!fs.existsSync(dir)) return 0;

  const before = fs.readdirSync(dir).length;
  console.log(`\n📁 ${label} (${before} archivos)`);

  let deleted = 0;
  for (const [pattern, limit] of Object.entries(limits)) {
    deleted += cleanupDir(dir, pattern, limit);
  }

  return deleted;
}

async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧹 LIMPIEZA DE SESIONES BAILEYS');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  let totalDeleted = 0;

  // --- Limpiar baileys_auth (bot principal) ---
  if (fs.existsSync(BAILEYS_AUTH_DIR)) {
    totalDeleted += cleanupSession(BAILEYS_AUTH_DIR, 'baileys_auth (bot principal)', LIMITS_MAIN);
  } else {
    console.log('\n⚠️  No existe baileys_auth, saltando...');
  }

  // --- Limpiar sesiones de subbots ---
  if (fs.existsSync(SUBBOTS_SESIONES_DIR)) {
    const subbots = fs.readdirSync(SUBBOTS_SESIONES_DIR)
      .filter(f => fs.statSync(path.join(SUBBOTS_SESIONES_DIR, f)).isDirectory())
      .sort();

    for (const subbot of subbots) {
      const subbotDir = path.join(SUBBOTS_SESIONES_DIR, subbot);
      totalDeleted += cleanupSession(subbotDir, `SUBBOT sesion/${subbot}`, LIMITS_SUBBOT);
    }
  } else {
    console.log('\n⚠️  No existe plugins/SUBBOTS/sesiones, saltando...');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ LIMPIEZA COMPLETADA`);
  console.log(`🗑️  Total archivos eliminados: ${totalDeleted}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

main().catch(console.error);
