const fs = require('fs').promises;
const path = require('path');

const BAILEYS_AUTH_DIR = './baileys_auth';
const SUBBOTS_SESIONES_DIR = './plugins/SUBBOTS/sesiones';


const KEEP_FILES = new Set(['creds.json', 'owner.json']);


const LIMITS_MAIN = {
  'pre-key-':                100,
  'device-list-':             20,
  'lid-mapping-':             50,
  'session-':                 10,
  'sender-key-':              30,
  'sender-key-memory-':        5,
  'app-state-sync-key-':       5,
  'app-state-sync-version-':   3,
  'tctoken-':                 10,
};


const LIMITS_SUBBOT = {
  'pre-key-':                 50,
  'device-list-':             10,
  'lid-mapping-':             20,
  'session-':                  5,
  'sender-key-':              15,
  'sender-key-memory-':        3,
  'app-state-sync-key-':       3,
  'app-state-sync-version-':   2,
  'tctoken-':                  5,
};

async function isValidJson(filePath) {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    JSON.parse(content);
    return true;
  } catch {
    return false;
  }
}

async function cleanupDir(dir, pattern, limit) {
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    const matching = entries.filter(e =>
      e.isFile() &&
      e.name.startsWith(pattern) &&
      e.name.endsWith('.json') &&
      !KEEP_FILES.has(e.name)
    );

    if (matching.length === 0) return 0;

   
    const files = await Promise.all(
      matching.map(async e => {
        const filePath = path.join(dir, e.name);
        const stat = await fs.stat(filePath);
        return { name: e.name, path: filePath, mtime: stat.mtimeMs };
      })
    );

   
    files.sort((a, b) => b.mtime - a.mtime);

    let deleted = 0;

   
    const corruptFiles = [];
    const validFiles = [];
    for (const file of files) {
      if (await isValidJson(file.path)) {
        validFiles.push(file);
      } else {
        corruptFiles.push(file);
      }
    }

    
    for (const file of corruptFiles) {
      try {
        await fs.unlink(file.path);
        deleted++;
      } catch {}
    }

    
    const toDelete = validFiles.slice(limit);
    for (const file of toDelete) {
      try {
        await fs.unlink(file.path);
        deleted++;
      } catch {}
    }

    const kept = validFiles.length - toDelete.length;
    if (deleted > 0) {
      console.log(`  🧹 ${pattern}: -${deleted} (corruptos:${corruptFiles.length} exceso:${toDelete.length}) → quedan ${kept}`);
    } else {
      console.log(`  ✅ ${pattern}: ${files.length} archivos (ok)`);
    }

    return deleted;
  } catch (err) {
    console.error(`  ❌ Error en ${pattern}:`, err.message);
    return 0;
  }
}

async function cleanupSession(dir, label, limits) {
  try {
    await fs.access(dir);
  } catch {
    return 0;
  }

  const entries = await fs.readdir(dir);
  console.log(`\n📁 ${label} (${entries.length} archivos antes)`);

  let deleted = 0;
  for (const [pattern, limit] of Object.entries(limits)) {
    deleted += await cleanupDir(dir, pattern, limit);
  }

  const after = (await fs.readdir(dir)).length;
  console.log(`   → ${after} archivos después (-${deleted})`);

  return deleted;
}

async function runCleanup() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧹 LIMPIEZA DE SESIONES BAILEYS');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  let totalDeleted = 0;

  
  try {
    await fs.access(BAILEYS_AUTH_DIR);
    totalDeleted += await cleanupSession(BAILEYS_AUTH_DIR, 'baileys_auth (principal)', LIMITS_MAIN);
  } catch {
    console.log('\n⚠️  No existe baileys_auth');
  }


  try {
    await fs.access(SUBBOTS_SESIONES_DIR);
    const entries = await fs.readdir(SUBBOTS_SESIONES_DIR, { withFileTypes: true });
    const subbots = entries.filter(e => e.isDirectory()).map(e => e.name).sort();

    for (const subbot of subbots) {
      const subbotDir = path.join(SUBBOTS_SESIONES_DIR, subbot);
      totalDeleted += await cleanupSession(subbotDir, `SUBBOT sesion/${subbot}`, LIMITS_SUBBOT);
    }
  } catch {
    console.log('\n⚠️  No existe plugins/SUBBOTS/sesiones');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ LIMPIEZA COMPLETADA — eliminados: ${totalDeleted} archivos`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
}

module.exports = { runCleanup };


if (require.main === module) {
  runCleanup().catch(console.error);
}
