const fs = require('fs');
const path = require('path');

const BAILEYS_AUTH_DIR = './baileys_auth';
const SUBBOTS_SESIONES_DIR = './plugins/SUBBOTS/sesiones';

// Configuración de límites
const LIMITS = {
  'pre-key': 100,        // Mantener solo las últimas 100 pre-keys
  'device-list': 20,     // Mantener solo las últimas 20 device-lists
  'lid-mapping': 50,     // Mantener solo los últimos 50 lid-mappings
  'session': 10          // Mantener solo las últimas 10 sesiones
};

function cleanupDir(dir, pattern, limit) {
  try {
    const files = fs.readdirSync(dir)
      .filter(f => f.startsWith(pattern) && f.endsWith('.json'))
      .map(f => ({
        name: f,
        path: path.join(dir, f),
        mtime: fs.statSync(path.join(dir, f)).mtime
      }))
      .sort((a, b) => b.mtime - a.mtime); // Más recientes primero

    if (files.length <= limit) {
      console.log(`  ✅ ${pattern}: ${files.length} archivos (dentro del límite de ${limit})`);
      return 0;
    }

    const toDelete = files.slice(limit);
    let deleted = 0;

    for (const file of toDelete) {
      try {
        fs.unlinkSync(file.path);
        deleted++;
      } catch (err) {
        console.error(`  ❌ Error eliminando ${file.name}:`, err.message);
      }
    }

    console.log(`  🧹 ${pattern}: Eliminados ${deleted}/${toDelete.length} (mantenidos ${limit})`);
    return deleted;

  } catch (err) {
    console.error(`  ❌ Error procesando ${pattern}:`, err.message);
    return 0;
  }
}

function cleanupSession(dir, label) {
  if (!fs.existsSync(dir)) return 0;

  const before = fs.readdirSync(dir).length;
  console.log(`\n📁 ${label} (${before} archivos)`);

  let deleted = 0;
  deleted += cleanupDir(dir, 'pre-key-', LIMITS['pre-key']);
  deleted += cleanupDir(dir, 'device-list-', LIMITS['device-list']);
  deleted += cleanupDir(dir, 'lid-mapping-', LIMITS['lid-mapping']);
  deleted += cleanupDir(dir, 'session-', LIMITS['session']);

  return deleted;
}

async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧹 LIMPIEZA DE SESIONES BAILEYS');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  let totalDeleted = 0;

  // --- Limpiar baileys_auth (bot principal) ---
  if (fs.existsSync(BAILEYS_AUTH_DIR)) {
    totalDeleted += cleanupSession(BAILEYS_AUTH_DIR, 'baileys_auth (bot principal)');
  } else {
    console.log('\n⚠️  No existe baileys_auth, saltando...');
  }

  // --- Limpiar sesiones de subbots ---
  if (fs.existsSync(SUBBOTS_SESIONES_DIR)) {
    const subbots = fs.readdirSync(SUBBOTS_SESIONES_DIR)
      .filter(f => fs.statSync(path.join(SUBBOTS_SESIONES_DIR, f)).isDirectory())
      .sort();

    for (const subbot of subbots) {
      const subbotDir = path.join(SUBBOTS_SESIONES_DIR, subbot);
      totalDeleted += cleanupSession(subbotDir, `SUBBOT sesion/${subbot}`);
    }
  } else {
    console.log('\n⚠️  No existe plugins/SUBBOTS/sesiones, saltando...');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ LIMPIEZA COMPLETADA`);
  console.log(`🗑️  Total archivos eliminados: ${totalDeleted}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

main().catch(console.error);
