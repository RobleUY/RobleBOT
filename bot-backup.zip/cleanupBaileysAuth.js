const fs = require('fs');
const path = require('path');

const BAILEYS_AUTH_DIR = './baileys_auth';

// Configuración de límites
const LIMITS = {
  'pre-key': 100,        // Mantener solo las últimas 100 pre-keys
  'device-list': 20,     // Mantener solo las últimas 20 device-lists
  'lid-mapping': 50,     // Mantener solo los últimos 50 lid-mappings
  'session': 10          // Mantener solo las últimas 10 sesiones
};

function cleanupOldFiles(pattern, limit) {
  try {
    const files = fs.readdirSync(BAILEYS_AUTH_DIR)
      .filter(f => f.startsWith(pattern) && f.endsWith('.json'))
      .map(f => ({
        name: f,
        path: path.join(BAILEYS_AUTH_DIR, f),
        mtime: fs.statSync(path.join(BAILEYS_AUTH_DIR, f)).mtime
      }))
      .sort((a, b) => b.mtime - a.mtime); // Más recientes primero

    if (files.length <= limit) {
      console.log(`✅ ${pattern}: ${files.length} archivos (dentro del límite de ${limit})`);
      return 0;
    }

    const toDelete = files.slice(limit);
    let deleted = 0;

    for (const file of toDelete) {
      try {
        fs.unlinkSync(file.path);
        deleted++;
      } catch (err) {
        console.error(`❌ Error eliminando ${file.name}:`, err.message);
      }
    }

    console.log(`🧹 ${pattern}: Eliminados ${deleted}/${toDelete.length} archivos antiguos (mantenidos ${limit})`);
    return deleted;

  } catch (err) {
    console.error(`❌ Error procesando ${pattern}:`, err.message);
    return 0;
  }
}

async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('🧹 LIMPIEZA DE BAILEYS_AUTH');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  if (!fs.existsSync(BAILEYS_AUTH_DIR)) {
    console.error('❌ No existe la carpeta baileys_auth');
    process.exit(1);
  }

  const totalBefore = fs.readdirSync(BAILEYS_AUTH_DIR).length;
  console.log(`📊 Archivos totales antes: ${totalBefore}\n`);

  let totalDeleted = 0;

  // Limpiar cada tipo de archivo
  totalDeleted += cleanupOldFiles('pre-key-', LIMITS['pre-key']);
  totalDeleted += cleanupOldFiles('device-list-', LIMITS['device-list']);
  totalDeleted += cleanupOldFiles('lid-mapping-', LIMITS['lid-mapping']);
  totalDeleted += cleanupOldFiles('session-', LIMITS['session']);

  const totalAfter = fs.readdirSync(BAILEYS_AUTH_DIR).length;

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ LIMPIEZA COMPLETADA`);
  console.log(`📊 Archivos antes: ${totalBefore}`);
  console.log(`📊 Archivos después: ${totalAfter}`);
  console.log(`🗑️  Archivos eliminados: ${totalDeleted}`);
  console.log(`💾 Espacio liberado: ~${Math.round(totalDeleted * 0.01)}MB`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

main().catch(console.error);
