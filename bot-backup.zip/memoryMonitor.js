/**
 * SISTEMA DE MONITOREO DE MEMORIA RAM Y REINICIO AUTOMÁTICO
 * 
 * Este módulo monitorea constantemente el uso de memoria RAM del proceso.
 * Cuando el uso supera el umbral definido (2.2 GB), ejecuta un reinicio
 * automático limpio del bot para evitar problemas de memoria.
 * 
 * El watchdog/PM2 se encargará de reiniciar el proceso automáticamente.
 */

const chalk = require('chalk');

// Configuración
const RAM_THRESHOLD_GB = 2.2; // Umbral en gigabytes
const RAM_THRESHOLD_BYTES = RAM_THRESHOLD_GB * 1024 * 1024 * 1024; // Convertir a bytes
const CHECK_INTERVAL_MS = 30 * 1000; // Revisar cada 30 segundos

let monitorInterval = null;
let isRestarting = false;

/**
 * Obtiene el uso actual de memoria en bytes y GB
 */
function getMemoryUsage() {
  const usage = process.memoryUsage();
  return {
    rss: usage.rss, // Resident Set Size - memoria total usada
    rssGB: (usage.rss / (1024 * 1024 * 1024)).toFixed(2),
    heapUsed: usage.heapUsed,
    heapUsedGB: (usage.heapUsed / (1024 * 1024 * 1024)).toFixed(2),
    heapTotal: usage.heapTotal,
    heapTotalGB: (usage.heapTotal / (1024 * 1024 * 1024)).toFixed(2)
  };
}

/**
 * Verifica si se debe reiniciar por exceso de memoria
 */
function checkMemoryAndRestart() {
  if (isRestarting) return;

  const memory = getMemoryUsage();
  
  // Log silencioso cada 10 minutos para diagnóstico (opcional)
  if (Math.random() < 0.01) { // ~1% de probabilidad cada check = ~5 min aprox
    console.log(chalk.gray(`[MemoryMonitor] 📊 Uso actual: ${memory.rssGB} GB / ${RAM_THRESHOLD_GB} GB`));
  }

  // Si se supera el umbral, ejecutar reinicio
  if (memory.rss >= RAM_THRESHOLD_BYTES) {
    isRestarting = true;
    
    console.log(chalk.yellow('\n┌─────────────────────────────────────────────────────────┐'));
    console.log(chalk.yellow('│     ⚠️  UMBRAL DE MEMORIA RAM SUPERADO                 │'));
    console.log(chalk.yellow('└─────────────────────────────────────────────────────────┘'));
    console.log(chalk.yellow(`\n[MemoryMonitor] 🔴 Uso de RAM: ${memory.rssGB} GB`));
    console.log(chalk.yellow(`[MemoryMonitor] 🎯 Umbral configurado: ${RAM_THRESHOLD_GB} GB`));
    console.log(chalk.yellow(`[MemoryMonitor] 🔄 Iniciando reinicio automático por memoria...\n`));
    
    console.log(chalk.cyan('[MemoryMonitor] 📊 Detalles de memoria:'));
    console.log(chalk.cyan(`   • RSS (Total): ${memory.rssGB} GB`));
    console.log(chalk.cyan(`   • Heap Used: ${memory.heapUsedGB} GB`));
    console.log(chalk.cyan(`   • Heap Total: ${memory.heapTotalGB} GB\n`));

    // Detener el monitoreo
    stopMemoryMonitor();

    // Ejecutar reinicio forzado (usa la función global del index.js)
    setTimeout(() => {
      if (global.forceRestart && typeof global.forceRestart === 'function') {
        console.log(chalk.yellow('[MemoryMonitor] 🔄 Ejecutando forceRestart()...\n'));
        global.forceRestart();
      } else {
        console.log(chalk.yellow('[MemoryMonitor] 🔄 forceRestart() no disponible, forzando process.exit(1)...\n'));
        process.exit(1);
      }
    }, 1000);
  }
}

/**
 * Inicia el monitoreo de memoria
 */
function startMemoryMonitor() {
  if (monitorInterval) {
    console.log(chalk.yellow('[MemoryMonitor] ⚠️ El monitoreo ya está activo.'));
    return;
  }

  console.log(chalk.green('\n┌─────────────────────────────────────────────────────────┐'));
  console.log(chalk.green('│     🛡️  MONITOR DE MEMORIA RAM INICIADO                │'));
  console.log(chalk.green('└─────────────────────────────────────────────────────────┘'));
  console.log(chalk.cyan(`[MemoryMonitor] 🎯 Umbral configurado: ${RAM_THRESHOLD_GB} GB`));
  console.log(chalk.cyan(`[MemoryMonitor] ⏱️  Intervalo de chequeo: ${CHECK_INTERVAL_MS / 1000}s`));
  
  const memory = getMemoryUsage();
  console.log(chalk.cyan(`[MemoryMonitor] 📊 Uso actual: ${memory.rssGB} GB\n`));

  monitorInterval = setInterval(checkMemoryAndRestart, CHECK_INTERVAL_MS);
}

/**
 * Detiene el monitoreo de memoria
 */
function stopMemoryMonitor() {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
    console.log(chalk.gray('[MemoryMonitor] 🛑 Monitor de memoria detenido.'));
  }
}

/**
 * Obtiene el estado actual del monitor
 */
function getMonitorStatus() {
  const memory = getMemoryUsage();
  return {
    isActive: monitorInterval !== null,
    isRestarting,
    thresholdGB: RAM_THRESHOLD_GB,
    thresholdBytes: RAM_THRESHOLD_BYTES,
    currentMemory: memory,
    percentageUsed: ((memory.rss / RAM_THRESHOLD_BYTES) * 100).toFixed(1)
  };
}

module.exports = {
  startMemoryMonitor,
  stopMemoryMonitor,
  getMonitorStatus,
  RAM_THRESHOLD_GB
};
