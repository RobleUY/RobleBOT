const chalk = require('chalk');

class MemoryMonitor {
    constructor() {
        this.startTime = Date.now();
        this.initialMemory = process.memoryUsage().heapUsed;
        this.peakMemory = this.initialMemory;
        this.samples = [];
        this.maxSamples = 100;
        this.monitorInterval = null;
    }

    start(intervalMinutes = 5) {
        console.log(chalk.cyan('📊 Monitor de memoria iniciado'));
        
        // Mostrar memoria inicial
        this.logMemory();
        
        // Monitorear cada X minutos
        this.monitorInterval = setInterval(() => {
            this.logMemory();
            this.checkMemoryHealth();
        }, intervalMinutes * 60 * 1000);
    }

    stop() {
        if (this.monitorInterval) {
            clearInterval(this.monitorInterval);
            this.monitorInterval = null;
            console.log(chalk.yellow('📊 Monitor de memoria detenido'));
        }
    }

    logMemory() {
        const usage = process.memoryUsage();
        const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
        const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
        const rssMB = Math.round(usage.rss / 1024 / 1024);
        const externalMB = Math.round(usage.external / 1024 / 1024);
        
        // Actualizar pico
        if (usage.heapUsed > this.peakMemory) {
            this.peakMemory = usage.heapUsed;
        }
        
        // Guardar muestra
        this.samples.push({
            timestamp: Date.now(),
            heapUsed: usage.heapUsed,
            heapTotal: usage.heapTotal,
            rss: usage.rss
        });
        
        // Limitar muestras
        if (this.samples.length > this.maxSamples) {
            this.samples.shift();
        }
        
        // Calcular uptime
        const uptimeMs = Date.now() - this.startTime;
        const uptimeHours = Math.floor(uptimeMs / (60 * 60 * 1000));
        const uptimeMinutes = Math.floor((uptimeMs % (60 * 60 * 1000)) / (60 * 1000));
        
        // Calcular crecimiento
        const growthMB = Math.round((usage.heapUsed - this.initialMemory) / 1024 / 1024);
        const growthPercent = Math.round(((usage.heapUsed - this.initialMemory) / this.initialMemory) * 100);
        
        // Color según uso
        let color = chalk.green;
        if (heapUsedMB > 400) color = chalk.yellow;
        if (heapUsedMB > 600) color = chalk.red;
        
        console.log(color('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
        console.log(color(`📊 MEMORIA - Uptime: ${uptimeHours}h ${uptimeMinutes}m`));
        console.log(color(`   Heap: ${heapUsedMB}MB / ${heapTotalMB}MB`));
        console.log(color(`   RSS: ${rssMB}MB | External: ${externalMB}MB`));
        console.log(color(`   Pico: ${Math.round(this.peakMemory / 1024 / 1024)}MB`));
        console.log(color(`   Crecimiento: ${growthMB > 0 ? '+' : ''}${growthMB}MB (${growthPercent > 0 ? '+' : ''}${growthPercent}%)`));
        
        // Mostrar estadísticas de objetos globales
        this.logGlobalStats();
        
        console.log(color('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    }

    logGlobalStats() {
        const stats = [];
        
        // Subbots
        if (global.subConns) {
            const activeSubbots = global.subConns.filter(c => c && c.user).length;
            stats.push(`Subbots: ${activeSubbots}/${global.subConns.length}`);
        }
        
        // Base de datos
        if (global.db?.data) {
            const users = Object.keys(global.db.data.users || {}).length;
            const groups = Object.keys(global.db.data.groups || {}).length;
            stats.push(`DB: ${users} users, ${groups} groups`);
        }
        
        // Comandos
        if (global.commandHandler?.commands) {
            stats.push(`Comandos: ${global.commandHandler.commands.size}`);
        }
        
        if (stats.length > 0) {
            console.log(chalk.cyan(`   ${stats.join(' | ')}`));
        }
    }

    checkMemoryHealth() {
        const usage = process.memoryUsage();
        const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
        
        // Advertencias
        if (heapUsedMB > 600) {
            console.log(chalk.red('⚠️ ADVERTENCIA: Uso de memoria alto (>600MB)'));
            console.log(chalk.yellow('   Considera reiniciar el bot pronto'));
        } else if (heapUsedMB > 400) {
            console.log(chalk.yellow('⚠️ Uso de memoria moderado (>400MB)'));
        }
        
        // Calcular tasa de crecimiento
        if (this.samples.length >= 2) {
            const oldestSample = this.samples[0];
            const newestSample = this.samples[this.samples.length - 1];
            const timeDiff = newestSample.timestamp - oldestSample.timestamp;
            const memDiff = newestSample.heapUsed - oldestSample.heapUsed;
            
            if (timeDiff > 0) {
                const growthPerHour = (memDiff / timeDiff) * (60 * 60 * 1000);
                const growthPerHourMB = Math.round(growthPerHour / 1024 / 1024);
                
                if (growthPerHourMB > 50) {
                    console.log(chalk.red(`⚠️ Crecimiento rápido: +${growthPerHourMB}MB/hora`));
                    console.log(chalk.yellow('   Posible memory leak detectado'));
                } else if (growthPerHourMB > 20) {
                    console.log(chalk.yellow(`⚠️ Crecimiento moderado: +${growthPerHourMB}MB/hora`));
                }
            }
        }
    }

    getStats() {
        const usage = process.memoryUsage();
        return {
            heapUsed: Math.round(usage.heapUsed / 1024 / 1024),
            heapTotal: Math.round(usage.heapTotal / 1024 / 1024),
            rss: Math.round(usage.rss / 1024 / 1024),
            external: Math.round(usage.external / 1024 / 1024),
            peak: Math.round(this.peakMemory / 1024 / 1024),
            uptime: Date.now() - this.startTime,
            samples: this.samples.length
        };
    }

    forceGC() {
        if (global.gc) {
            console.log(chalk.cyan('🗑️ Ejecutando garbage collection...'));
            const before = process.memoryUsage().heapUsed;
            global.gc();
            const after = process.memoryUsage().heapUsed;
            const freed = Math.round((before - after) / 1024 / 1024);
            console.log(chalk.green(`✓ Liberados ${freed}MB`));
        } else {
            console.log(chalk.yellow('⚠️ GC no disponible. Ejecuta con --expose-gc'));
        }
    }
}

// Singleton
let instance = null;

function getMemoryMonitor() {
    if (!instance) {
        instance = new MemoryMonitor();
    }
    return instance;
}

module.exports = { MemoryMonitor, getMemoryMonitor };
