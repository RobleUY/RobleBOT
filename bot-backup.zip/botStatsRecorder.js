const fs = require('fs');
const path = require('path');

const STATS_FILE = path.join(__dirname, 'data', 'botstats.json');
const LEGACY_STATS_FILE = path.join(__dirname, 'plugins', 'GRUPOS', 'botstats.json');

function ensureDataFile(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({
            totalCommandsExecuted: 0,
            availableCommands: 0,
            loadedPlugins: 0,
            commands: {},
            users: {},
            commandLog: []
        }, null, 2));
    }
}

function migrateLegacyStats() {
    try {
        if (!fs.existsSync(STATS_FILE)) {
            ensureDataFile(STATS_FILE);
            const newData = {
                totalCommandsExecuted: 0,
                availableCommands: 0,
                loadedPlugins: 0,
                commands: {},
                users: {},
                commandLog: []
            };
            saveStats(newData);
            return newData;
        }
    } catch (e) {
        console.error('[botstats] Error creando stats nuevos:', e.message);
    }
    return null;
}

function loadStats() {
    try {
        migrateLegacyStats();
        ensureDataFile(STATS_FILE);
        return JSON.parse(fs.readFileSync(STATS_FILE, 'utf8'));
    } catch (e) {
        console.error('[botstats] Error cargando stats:', e.message);
        return {
            totalCommandsExecuted: 0,
            availableCommands: 0,
            loadedPlugins: 0,
            commands: {},
            users: {},
            commandLog: []
        };
    }
}

function saveStats(data) {
    try {
        ensureDataFile(STATS_FILE);
        fs.writeFileSync(STATS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[botstats] Error guardando stats:', e.message);
    }
}

function formatCommandName(commandName) {
    if (!commandName || typeof commandName !== 'string') return '.unknown';
    if (commandName.startsWith('.')) return commandName.toLowerCase();
    return `.${commandName.toLowerCase()}`;
}

function recordCommand(userId, commandName) {
    const stats = loadStats();
    const now = Date.now();
    const cleanId = (userId || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const cmdName = formatCommandName(commandName);

    stats.totalCommandsExecuted = (stats.totalCommandsExecuted || 0) + 1;

    if (!stats.commands || typeof stats.commands !== 'object') stats.commands = {};
    stats.commands[cmdName] = (stats.commands[cmdName] || 0) + 1;

    if (!Array.isArray(stats.commandLog)) stats.commandLog = [];
    stats.commandLog.push(now);

    const cutoff7d = now - 7 * 24 * 60 * 60 * 1000;
    stats.commandLog = stats.commandLog.filter(t => t > cutoff7d);

    if (!stats.users || typeof stats.users !== 'object') stats.users = {};
    if (!stats.users[cleanId]) {
        stats.users[cleanId] = { firstSeen: now, lastSeen: now };
    } else {
        stats.users[cleanId].lastSeen = now;
    }

    saveStats(stats);
}

function updateStatsMeta(meta = {}) {
    const stats = loadStats();
    if (typeof meta.availableCommands === 'number') {
        stats.availableCommands = meta.availableCommands;
    }
    if (typeof meta.loadedPlugins === 'number') {
        stats.loadedPlugins = meta.loadedPlugins;
    }
    saveStats(stats);
}

module.exports = { recordCommand, loadStats, updateStatsMeta };
