const fs = require('fs');
const path = require('path');

const STATS_FILE = path.join(__dirname, 'data', 'botstats.json');
const LEGACY_STATS_FILE = path.join(__dirname, 'plugins', 'GRUPOS', 'botstats.json');

// Cache en memoria para evitar read+write al disco en cada comando
let _cachedStats = null;
let _saveTimeout = null;
const SAVE_DEBOUNCE_MS = 30000; // Guardar al disco máximo 1 vez cada 30 segundos

function ensureDataFile(filePath) {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({
            totalCommandsExecuted: 0,
            availableCommands: 0,
            loadedPlugins: 0,
            commands: {},
            users: {},
            commandLog: []
        }, null, 2));
    }
}

function migrateLegacyStats() {
    try {
        if (!fs.existsSync(STATS_FILE)) {
            ensureDataFile(STATS_FILE);
            const newData = {
                totalCommandsExecuted: 0,
                availableCommands: 0,
                loadedPlugins: 0,
                commands: {},
                users: {},
                commandLog: []
            };
            saveStats(newData);
            return newData;
        }
    } catch (e) {
        console.error('[botstats] Error creando stats nuevos:', e.message);
    }
    return null;
}

function loadStats() {
    try {
        migrateLegacyStats();
        ensureDataFile(STATS_FILE);
        return JSON.parse(fs.readFileSync(STATS_FILE, 'utf8'));
    } catch (e) {
        console.error('[botstats] Error cargando stats:', e.message);
        return {
            totalCommandsExecuted: 0,
            availableCommands: 0,
            loadedPlugins: 0,
            commands: {},
            users: {},
            commandLog: []
        };
    }
}

function saveStats(data) {
    try {
        ensureDataFile(STATS_FILE);
        const tempPath = STATS_FILE + '.tmp';
        fs.writeFileSync(tempPath, JSON.stringify(data, null, 2));
        fs.renameSync(tempPath, STATS_FILE);
    } catch (e) {
        if (e.code === 'ENOSPC') {
            console.error('[botstats] 🚨 Sin espacio en disco (ENOSPC) — intentando limpieza de emergencia...');
            try {
                const { tempCleaner } = require('./tempCleaner');
                tempCleaner.emergencyCleanup().catch(() => {});
            } catch (_) {}
        } else {
            console.error('[botstats] Error guardando stats:', e.message);
        }
    }
}

// Guarda con debounce: solo escribe al disco una vez cada SAVE_DEBOUNCE_MS ms
function scheduleSave(data) {
    _cachedStats = data;
    if (_saveTimeout) return; // ya hay un guardado programado
    _saveTimeout = setTimeout(() => {
        _saveTimeout = null;
        if (_cachedStats) {
            saveStats(_cachedStats);
        }
    }, SAVE_DEBOUNCE_MS);
}

function formatCommandName(commandName) {
    if (!commandName || typeof commandName !== 'string') return '.unknown';
    if (commandName.startsWith('.')) return commandName.toLowerCase();
    return `.${commandName.toLowerCase()}`;
}

function recordCommand(userId, commandName) {
    // Usar cache en memoria — no leer del disco en cada llamada
    if (!_cachedStats) {
        _cachedStats = loadStats();
    }
    const stats = _cachedStats;
    const now = Date.now();
    const cleanId = (userId || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const cmdName = formatCommandName(commandName);

    stats.totalCommandsExecuted = (stats.totalCommandsExecuted || 0) + 1;

    if (!stats.commands || typeof stats.commands !== 'object') stats.commands = {};
    stats.commands[cmdName] = (stats.commands[cmdName] || 0) + 1;

    if (!Array.isArray(stats.commandLog)) stats.commandLog = [];
    // Cada entrada guarda timestamp (t), userId limpio (u) y comando (c)
    stats.commandLog.push({ t: now, u: cleanId, c: cmdName });

    // Migrar entradas antiguas (eran sólo timestamps numéricos) y limpiar > 7 días
    const cutoff7d = now - 7 * 24 * 60 * 60 * 1000;
    stats.commandLog = stats.commandLog.filter(entry => {
        const ts = typeof entry === 'number' ? entry : entry.t;
        return ts > cutoff7d;
    });

    if (!stats.users || typeof stats.users !== 'object') stats.users = {};
    if (!stats.users[cleanId]) {
        stats.users[cleanId] = { firstSeen: now, lastSeen: now };
    } else {
        stats.users[cleanId].lastSeen = now;
    }

    // Guardar con debounce — NO escribir al disco en cada comando
    scheduleSave(stats);
}

function updateStatsMeta(meta = {}) {
    if (!_cachedStats) {
        _cachedStats = loadStats();
    }
    const stats = _cachedStats;
    if (typeof meta.availableCommands === 'number') {
        stats.availableCommands = meta.availableCommands;
    }
    if (typeof meta.loadedPlugins === 'number') {
        stats.loadedPlugins = meta.loadedPlugins;
    }
    scheduleSave(stats);
}

/**
 * Devuelve estadísticas de actividad para un período de tiempo.
 * @param {number} sinceMs - timestamp (ms) desde cuando filtrar. Filtra entradas con t >= sinceMs.
 * @returns {{ totalCommands: number, uniqueUsers: number, topCommands: Array }}
 */
function getActivitySince(sinceMs) {
    const stats = _cachedStats || loadStats();
    if (!Array.isArray(stats.commandLog)) return { totalCommands: 0, uniqueUsers: 0, topCommands: [] };

    const entries = stats.commandLog.filter(entry => {
        const ts = typeof entry === 'number' ? entry : entry.t;
        return ts >= sinceMs;
    });

    const usersSet = new Set();
    const cmdCount = {};

    for (const entry of entries) {
        if (typeof entry === 'object' && entry.u) usersSet.add(entry.u);
        if (typeof entry === 'object' && entry.c) {
            cmdCount[entry.c] = (cmdCount[entry.c] || 0) + 1;
        }
    }

    const topCommands = Object.entries(cmdCount)
        .map(([cmd, count]) => ({ cmd, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

    return {
        totalCommands: entries.length,
        uniqueUsers: usersSet.size,
        topCommands,
    };
}

module.exports = { recordCommand, loadStats, updateStatsMeta, getActivitySince };
