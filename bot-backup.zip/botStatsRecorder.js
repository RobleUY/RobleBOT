const fs = require('fs');
const path = require('path');

const STATS_FILE = path.join(__dirname, 'plugins', 'GRUPOS', 'botstats.json');

function loadStats() {
    try {
        if (fs.existsSync(STATS_FILE)) {
            return JSON.parse(fs.readFileSync(STATS_FILE, 'utf8'));
        }
    } catch (e) {}
    return { totalCommands: 0, commandLog: [], users: {} };
}

function saveStats(data) {
    try {
        fs.writeFileSync(STATS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[botstats] Error guardando stats:', e.message);
    }
}

function recordCommand(userId) {
    const stats = loadStats();
    const now = Date.now();
    const cleanId = (userId || '').split('@')[0].split(':')[0].replace(/\D/g, '');

    stats.totalCommands = (stats.totalCommands || 0) + 1;

    if (!Array.isArray(stats.commandLog)) stats.commandLog = [];
    stats.commandLog.push(now);

    // Mantener solo últimos 7 días
    const cutoff7d = now - 7 * 24 * 60 * 60 * 1000;
    stats.commandLog = stats.commandLog.filter(t => t > cutoff7d);

    if (!stats.users) stats.users = {};
    if (!stats.users[cleanId]) {
        stats.users[cleanId] = { firstSeen: now, lastSeen: now };
    } else {
        stats.users[cleanId].lastSeen = now;
    }

    saveStats(stats);
}

module.exports = { recordCommand, loadStats };
