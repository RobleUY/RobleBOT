/**
 * logSystem.js — Sistema de logging centralizado
 * Captura ABSOLUTAMENTE TODO lo que se ve en consola
 * y lo guarda en archivos .txt con rotación automática
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

class LogSystem {
    constructor() {
        this.logsDir = path.join(__dirname, 'logs');
        this.maxLogAge = 24 * 60 * 60 * 1000; // 24 horas
        this.buffer = [];
        this.bufferSize = 0;
        this.maxBufferSize = 1024 * 1024; // 1 MB en buffer antes de forzar escritura
        this.isWriting = false;
        this.flushInterval = null;
        
        // Crear carpeta si no existe
        if (!fs.existsSync(this.logsDir)) {
            fs.mkdirSync(this.logsDir, { recursive: true });
            console.log(`[LogSystem] 📁 Carpeta de logs creada: ${this.logsDir}`);
        }

        // Iniciar flush periódico cada 2 segundos
        this.startFlushInterval();

        // Limpiar logs viejos al iniciar
        this.cleanOldLogs();

        // Interceptar todos los métodos de console
        this.interceptConsole();
    }

    /**
     * Obtiene el siguiente nombre de archivo disponible (1-logs.txt, 2-logs.txt, etc)
     */
    getNextLogFile() {
        const files = fs.readdirSync(this.logsDir)
            .filter(f => f.match(/^\d+-logs\.txt$/))
            .map(f => parseInt(f.split('-')[0]))
            .sort((a, b) => b - a); // Ordenar descendente para que el más alto sea primero

        const nextNum = (files.length > 0 ? files[0] + 1 : 1);
        return path.join(this.logsDir, `${nextNum}-logs.txt`);
    }

    /**
     * Obtiene el archivo de log actual (el número más alto)
     */
    getCurrentLogFile() {
        const files = fs.readdirSync(this.logsDir)
            .filter(f => f.match(/^\d+-logs\.txt$/))
            .map(f => parseInt(f.split('-')[0]))
            .sort((a, b) => b - a); // Mayor primero

        if (files.length === 0) {
            return path.join(this.logsDir, '1-logs.txt');
        }

        return path.join(this.logsDir, `${files[0]}-logs.txt`);
    }

    /**
     * Formatea una línea de log con timestamp
     */
    formatLogLine(level, args) {
        const timestamp = new Date().toISOString();
        const message = args.map(arg => {
            if (typeof arg === 'string') return arg;
            if (typeof arg === 'object') {
                try {
                    return JSON.stringify(arg);
                } catch (e) {
                    return String(arg);
                }
            }
            return String(arg);
        }).join(' ');

        return `[${timestamp}] [${level}] ${message}`;
    }

    /**
     * Agrega una línea al buffer
     */
    addToBuffer(line) {
        const lineWithNewline = line + '\n';
        this.buffer.push(lineWithNewline);
        this.bufferSize += Buffer.byteLength(lineWithNewline, 'utf8');

        // Si el buffer es muy grande, forzar escritura inmediata
        if (this.bufferSize > this.maxBufferSize) {
            this.flushBuffer();
        }
    }

    /**
     * Escribe el buffer a disco de forma asincrónica
     */
    async flushBuffer() {
        if (this.buffer.length === 0 || this.isWriting) return;

        this.isWriting = true;

        try {
            const logFile = this.getCurrentLogFile();
            const content = this.buffer.join('');

            // Escribir de forma asincrónica para no bloquear
            await fs.promises.appendFile(logFile, content, 'utf8');

            // Limpiar buffer
            this.buffer = [];
            this.bufferSize = 0;
        } catch (error) {
            // Si falla, intentar al menos una vez más
            try {
                const logFile = this.getCurrentLogFile();
                fs.appendFileSync(logFile, this.buffer.join(''), 'utf8');
                this.buffer = [];
                this.bufferSize = 0;
            } catch (syncError) {
                console.error('[LogSystem] Error crítico escribiendo logs:', syncError.message);
            }
        } finally {
            this.isWriting = false;
        }
    }

    /**
     * Inicia el intervalo de flush periódico
     */
    startFlushInterval() {
        if (this.flushInterval) clearInterval(this.flushInterval);

        this.flushInterval = setInterval(() => {
            this.flushBuffer();
        }, 2000); // Cada 2 segundos
    }

    /**
     * Detiene el intervalo de flush
     */
    stopFlushInterval() {
        if (this.flushInterval) {
            clearInterval(this.flushInterval);
            this.flushInterval = null;
        }
    }

    /**
     * Rotación de logs: cambiar nombre del archivo actual
     */
    rotateLog() {
        try {
            // Flush del buffer actual antes de rotar
            const currentFile = this.getCurrentLogFile();
            if (this.buffer.length > 0) {
                try {
                    fs.appendFileSync(currentFile, this.buffer.join(''), 'utf8');
                    this.buffer = [];
                    this.bufferSize = 0;
                } catch (e) {}
            }
            // Crear un nuevo archivo numerado para que el próximo flush vaya ahí
            const nextFile = this.getNextLogFile();
            try {
                // Asegurar que el archivo exista (se creará vacío)
                fs.closeSync(fs.openSync(nextFile, 'a'));
            } catch (e) {}

            console.log('[LogSystem] 🔄 Logs rotados a nuevo archivo:', path.basename(nextFile));
        } catch (error) {
            console.error('[LogSystem] Error en rotación:', error.message);
        }
    }

    /**
     * Limpia archivos de log más viejos de 24 horas
     */
    cleanOldLogs() {
        try {
            const files = fs.readdirSync(this.logsDir)
                .filter(f => f.match(/^\d+-logs\.txt$/));

            const now = Date.now();
            let cleaned = 0;

            for (const file of files) {
                const filePath = path.join(this.logsDir, file);
                const stats = fs.statSync(filePath);
                const age = now - stats.mtimeMs;

                if (age > this.maxLogAge) {
                    fs.unlinkSync(filePath);
                    cleaned++;
                }
            }

            if (cleaned > 0) {
                console.log(`[LogSystem] 🧹 ${cleaned} archivos de log antiguos eliminados`);
            }
        } catch (error) {
            console.error('[LogSystem] Error limpiando logs viejos:', error.message);
        }
    }

    /**
     * Intercepta todos los métodos de console
     */
    interceptConsole() {
        const levels = ['log', 'error', 'warn', 'info', 'debug'];
        const self = this;

        for (const level of levels) {
            const original = console[level].bind(console);

            console[level] = function (...args) {
                // Mostrar en consola normalmente
                original(...args);

                // También guardar en archivo
                try {
                    const line = self.formatLogLine(level.toUpperCase(), args);
                    self.addToBuffer(line);
                } catch (e) {
                    // Silencioso si falla
                }
            };
        }
    }

    /**
     * Obtiene información sobre los logs actuales
     */
    getLogStats() {
        try {
            const files = fs.readdirSync(this.logsDir)
                .filter(f => f.match(/^\d+-logs\.txt$/))
                .map(f => {
                    const filePath = path.join(this.logsDir, f);
                    const stats = fs.statSync(filePath);
                    return {
                        file: f,
                        size: (stats.size / 1024).toFixed(2) + ' KB',
                        created: new Date(stats.birthtimeMs).toLocaleString(),
                        modified: new Date(stats.mtimeMs).toLocaleString()
                    };
                })
                .sort((a, b) => parseInt(b.file) - parseInt(a.file));

            return {
                totalFiles: files.length,
                totalBufferSize: (this.bufferSize / 1024).toFixed(2) + ' KB',
                files: files
            };
        } catch (error) {
            return { error: error.message };
        }
    }

    /**
     * Fuerza escritura y cierre limpio
     */
    async shutdown() {
        console.log('[LogSystem] 🛑 Cerrando LogSystem...');
        this.stopFlushInterval();
        await this.flushBuffer();
        console.log('[LogSystem] ✅ Logs guardados y sistema cerrado');
    }
}

// Instancia global
const logSystem = new LogSystem();

module.exports = { LogSystem, logSystem };
