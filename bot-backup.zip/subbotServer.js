'use strict';
/**
 * Servidor HTTP para gestión de sub-bots
 *
 * GET /subbots/qr                    → Genera QR para nuevo sub-bot (imagen PNG)
 * GET /subbots/code?phone=XXXXXXXXXX → Genera código de emparejamiento de 8 dígitos (JSON)
 * GET /subbots/list                  → Lista de sub-bots activos (JSON)
 */

const express = require('express');
const qrcode  = require('qrcode');
const fs      = require('fs');
const path    = require('path');

// Map de QRs pendientes por num: { resolve, reject, timeout }
const pendingWebQR = new Map();

// Map de códigos de emparejamiento pendientes por num: { resolve, reject, timeout }
const pendingWebCode = new Map();

// Usa nextSubBotNumber del módulo principal para evitar conflictos de numeración
function getNextNum() {
    const { nextSubBotNumber } = require('./plugins/SUBBOTS/subbot-serbot');
    return nextSubBotNumber();
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un QR
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebQR(num, qrDataUrl) {
    const pending = pendingWebQR.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebQR.delete(num);
        pending.resolve(qrDataUrl);
    }
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un código de emparejamiento
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebCode(num, code) {
    const pending = pendingWebCode.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebCode.delete(num);
        if (code === null) {
            pending.reject(new Error('Error generando código de emparejamiento'));
        } else {
            pending.resolve(code);
        }
    }
}

function startSubBotServer(port = 3000) {
    const app = express();

    // CORS — permite acceso desde cualquier origen (incluyendo páginas HTTPS)
    app.use((req, res, next) => {
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        if (req.method === 'OPTIONS') return res.sendStatus(204);
        next();
    });

    // ── GET /subbots/info ────────────────────────────────────────────────────
    app.get('/subbots/info', (req, res) => {
        const mainNum = global.mainBotNumber || null;
        res.json({
            mainBot: mainNum ? { number: mainNum, link: `wa.me/+${mainNum}` } : null,
            group:   'https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv',
            channel: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
        });
    });

    // ── GET /subbots/list ────────────────────────────────────────────────────
    app.get('/subbots/list', (req, res) => {
        const active = (global.subConns || [])
            .filter(c => c.user)
            .sort((a, b) => a._subNum - b._subNum)
            .map(c => ({
                num:    c._subNum,
                number: c.user.id.split('@')[0].split(':')[0],
                link:   `wa.me/+${c.user.id.split('@')[0].split(':')[0]}`,
                uptime: c.uptime ? Date.now() - c.uptime : null,
            }));

        res.json({ total: active.length, subbots: active });
    });

    // ── GET /subbots/qr ──────────────────────────────────────────────────────
    app.get('/subbots/qr', async (req, res) => {
        if (!global.conn?.user) {
            return res.status(503).json({ error: 'Bot principal no conectado' });
        }

        const num = getNextNum();

        // Verificar si ya hay un QR pendiente para este num
        if (pendingWebQR.has(num)) {
            return res.status(429).json({ error: `Ya hay un QR pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el QR
        let resolveQR, rejectQR;
        const qrPromise = new Promise((res, rej) => { resolveQR = res; rejectQR = rej; });

        const timeout = setTimeout(() => {
            pendingWebQR.delete(num);
            rejectQR(new Error('Timeout esperando QR'));
        }, 30000);

        pendingWebQR.set(num, { resolve: resolveQR, reject: rejectQR, timeout });

        try {
            // Conectar subbot con ownerJid null (web) — el QR llegará via resolveWebQR
            const { connectSubBotWeb } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWeb({ num, conn: global.conn });

            const qrDataUrl = await qrPromise;

            // Convertir data URL a buffer PNG y enviar
            const base64 = qrDataUrl.replace(/^data:image\/png;base64,/, '');
            const imgBuf = Buffer.from(base64, 'base64');

            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'no-store');
            res.send(imgBuf);
        } catch (e) {
            pendingWebQR.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/code ────────────────────────────────────────────────────
    app.get('/subbots/code', async (req, res) => {
        if (!global.conn?.user) {
            return res.status(503).json({ error: 'Bot principal no conectado' });
        }

        const rawPhone = (req.query.phone || req.query.number || '').trim();
        if (!rawPhone) {
            return res.status(400).json({ error: 'Parámetro "phone" requerido. Ejemplo: /subbots/code?phone=59893900470' });
        }

        // Limpiar igual que el comando .serbot code: quitar +, espacios, guiones, etc.
        const cleanNumber = rawPhone.replace(/[^0-9]/g, '');
        if (cleanNumber.length < 7 || cleanNumber.length > 15) {
            return res.status(400).json({ error: 'Número inválido. Usa formato internacional, ej: 59893900470' });
        }

        const num = getNextNum();

        // Verificar si ya hay un código pendiente para este num
        if (pendingWebCode.has(num)) {
            return res.status(429).json({ error: `Ya hay un código pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el código
        let resolveCode, rejectCode;
        const codePromise = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });

        const timeout = setTimeout(() => {
            pendingWebCode.delete(num);
            rejectCode(new Error('Timeout esperando código de emparejamiento'));
        }, 60000); // 60 segundos para el código

        pendingWebCode.set(num, { resolve: resolveCode, reject: rejectCode, timeout });

        try {
            // Conectar subbot con método de código
            const { connectSubBotWebWithCode } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWebWithCode({ num, conn: global.conn, phoneNumber: cleanNumber });

            const pairingCode = await codePromise;

            res.json({
                success:      true,
                subbotNumber: num,
                phoneNumber:  cleanNumber,
                pairingCode:  pairingCode,
                message:      'Ingresa este código en WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono'
            });
        } catch (e) {
            pendingWebCode.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    app.listen(port, () => {
        console.log(`[SubBotServer] HTTP en puerto ${port} → /subbots/qr | /subbots/code | /subbots/list`);
    });

    return { resolveWebQR, resolveWebCode };
}

module.exports = { startSubBotServer, resolveWebQR, resolveWebCode };
