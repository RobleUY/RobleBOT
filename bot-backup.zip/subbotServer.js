'use strict';
/**
 * Servidor HTTP para gestión de sub-bots
 *
 * GET /subbots/qr                    → Genera QR para nuevo sub-bot (imagen PNG)
 * GET /subbots/code?phone=XXXXXXXXXX → Genera código de emparejamiento de 8 dígitos (JSON)
 * GET /subbots/list                  → Lista de sub-bots activos (JSON)
 * GET /exists?number=XXXXXXXXXX      → Verifica si un número está registrado en WhatsApp (JSON)
 */

const express = require('express');
const qrcode  = require('qrcode');
const fs      = require('fs');
const path    = require('path');
const { loadStats } = require('./botStatsRecorder');
const achievements = require('./achievements');
const {
    createSignedSessionToken,
    verifySignedSessionToken,
    saveSession,
    getSession,
    revokeSession,
} = require('./lib/webSessionStore');

// Map de QRs pendientes por num: { resolve, reject, timeout }
const pendingWebQR = new Map();

// Map de códigos de emparejamiento pendientes por num: { resolve, reject, timeout }
const pendingWebCode = new Map();

// Map de web auth: code -> { apodo, status: 'pending'|'verified', createdAt }
const pendingWebAuth = new Map();

// Sin caché - el endpoint /stats se actualiza al instante

// Usa nextSubBotNumber del módulo principal para evitar conflictos de numeración
function getNextNum() {
    const { nextSubBotNumber } = require('./plugins/SUBBOTS/subbot-serbot');
    return nextSubBotNumber();
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un QR
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebQR(num, qrDataUrl) {
    const pending = pendingWebQR.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebQR.delete(num);
        if (!qrDataUrl) {
            pending.reject(new Error('Error generando código QR'));
        } else {
            pending.resolve(qrDataUrl);
        }
    }
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un código de emparejamiento
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebCode(num, code) {
    const pending = pendingWebCode.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebCode.delete(num);
        if (code === null) {
            pending.reject(new Error('Error generando código de emparejamiento'));
        } else {
            pending.resolve(code);
        }
    }
}

function startSubBotServer(port = 3000) {
    const app = express();

    // CORS — permite acceso desde cualquier origen (incluyendo páginas HTTPS)
    app.use((req, res, next) => {
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        if (req.method === 'OPTIONS') return res.sendStatus(204);
        next();
    });

    // ── Middleware para manejar rutas con ?action= ──────────────────────────
    // Reescribe /api/roblebot?action=X a /X para compatibilidad
    app.use((req, res, next) => {
        const action = req.query.action;
        if (action) {
            req.url = `/${action}${req.url.includes('&') ? '?' + req.url.split('&').slice(1).join('&') : ''}`;
            delete req.query.action;
        }
        next();
    });

    // ── GET /subbots/info ────────────────────────────────────────────────────
    app.get('/subbots/info', (req, res) => {
        const mainNum = global.mainBotNumber || null;
        res.json({
            mainBot: mainNum ? { number: mainNum, link: `wa.me/+${mainNum}` } : null,
            group:   'https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv',
            channel: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
        });
    });

    // ── GET /subbots/list ────────────────────────────────────────────────────
    app.get('/subbots/list', (req, res) => {
        const active = (global.subConns || [])
            .filter(c => c.user)
            .sort((a, b) => a._subNum - b._subNum)
            .map(c => ({
                num:    c._subNum,
                uptime: c.uptime ? Date.now() - c.uptime : null,
            }));

        res.json({ total: active.length, subbots: active });
    });

    // ── GET /topdinero ───────────────────────────────────────────────────────
    // Top global de dinero: apodo, posición, dinero (money+bank)
    // Params:
    // - apodo: busca jugador por apodo exacto (case-insensitive)
    // - position: devuelve jugador en posición exacta
    // - page: devuelve 10 jugadores de la página solicitada
    app.get('/topdinero', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const rows = [];
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (!userData) continue;
                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? 'Sin Apodo'
                    : apodoRaw;

                rows.push({ apodo, dinero: totalMoney });
            }

            rows.sort((a, b) => b.dinero - a.dinero);
            const top = rows.map((u, i) => ({
                posicion: i + 1,
                apodo: u.apodo,
                dinero: u.dinero
            }));

            const apodoQuery = (req.query.apodo || '').toString().trim();
            const positionQuery = req.query.position ? parseInt(req.query.position, 10) : NaN;
            const pageQuery = req.query.page ? parseInt(req.query.page, 10) : NaN;

            if (apodoQuery) {
                const found = top.find(u => u.apodo.toLowerCase() === apodoQuery.toLowerCase());
                if (!found) {
                    return res.status(404).json({
                        error: `No se encontró el jugador con apodo '${apodoQuery}'`,
                        query: { apodo: apodoQuery }
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { apodo: apodoQuery },
                    resultado: found
                });
            }

            if (!Number.isNaN(positionQuery)) {
                if (positionQuery < 1 || positionQuery > top.length) {
                    return res.status(404).json({
                        error: `No existe un jugador en la posición ${positionQuery}`,
                        query: { position: positionQuery },
                        totalRankeados: top.length
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { position: positionQuery },
                    resultado: top[positionQuery - 1]
                });
            }

            if (!Number.isNaN(pageQuery)) {
                if (pageQuery < 1) {
                    return res.status(400).json({
                        error: 'El parámetro page debe ser un número entero mayor o igual a 1',
                        query: { page: pageQuery }
                    });
                }
                const pageSize = 10;
                const start = (pageQuery - 1) * pageSize;
                const pageItems = top.slice(start, start + pageSize);
                return res.json({
                    totalRankeados: top.length,
                    page: pageQuery,
                    pageSize,
                    resultados: pageItems
                });
            }

            return res.json({
                totalRankeados: top.length,
                top
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /funciones ───────────────────────────────────────────────────────
    // Cantidad total de plugins (.js) dentro de /plugins (recursivo)
    app.get('/funciones', (req, res) => {
        try {
            const pluginsDir = path.join(__dirname, 'plugins');
            if (!fs.existsSync(pluginsDir)) {
                return res.status(500).json({ error: 'No existe la carpeta plugins' });
            }

            const countJsRecursive = (dir) => {
                let count = 0;
                const items = fs.readdirSync(dir, { withFileTypes: true });
                for (const it of items) {
                    const full = path.join(dir, it.name);
                    if (it.isDirectory()) count += countJsRecursive(full);
                    else if (it.isFile() && it.name.toLowerCase().endsWith('.js')) count++;
                }
                return count;
            };

            const totalPlugins = countJsRecursive(pluginsDir);
            return res.json({ pluginsJs: totalPlugins });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /menu.txt ─────────────────────────────────────────────────────────
    app.get('/menu.txt', (req, res) => {
        try {
            const menuPath = path.join(__dirname, 'menu.txt');
            if (!fs.existsSync(menuPath)) {
                return res.status(404).json({ error: 'menu.txt no encontrado' });
            }
            const content = fs.readFileSync(menuPath, 'utf8');
            res.set('Content-Type', 'text/plain; charset=utf-8');
            return res.send(content);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /stats ───────────────────────────────────────────────────────────
    // Devuelve stats del bot (resumen en JSON) - SIN info de grupos/participantes
    app.get('/stats', async (req, res) => {
        try {
            const stats = loadStats();
            const totalCommands = stats.totalCommandsExecuted || stats.totalCommands || 0;
            const totalUsers = global.db?.data?.users ? Object.keys(global.db.data.users).length : 0;

            // Cantidad de bots activos
            const activeSubbots = (global.subConns || []).filter(c => c.user);
            const subbotsCount = activeSubbots.length;
            const mainActive = global.conn?.user ? 1 : 0;

            const result = {
                totalCommands,
                totalCommandsExecuted: totalCommands,
                availableCommands: stats.availableCommands || 0,
                loadedPlugins: stats.loadedPlugins || 0,
                totalUsers,
                bots: {
                    main: mainActive,
                    subbots: subbotsCount,
                    total: mainActive + subbotsCount
                }
            };

            return res.json(result);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /userprofile ─────────────────────────────────────────────────────
    // Devuelve el perfil completo de un usuario por apodo o userId
    // Params: apodo | userId
    app.get('/userprofile', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const apodoQuery = (req.query.apodo || '').trim();
            const userIdQuery = (req.query.userId || '').trim();
            
            if (!apodoQuery && !userIdQuery) {
                return res.status(400).json({ error: 'Parámetro "apodo" o "userId" requerido' });
            }

            // Función para normalizar texto
            const normalizeText = (text) => {
                if (!text) return '';
                return text
                    .trim()
                    .toLowerCase()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .replace(/\s+/g, ' ');
            };

            // Level calculation handled by achievements module

            let foundUser = null;
            let foundNumber = null;

            // Búsqueda por ID directo (Prioridad)
            if (userIdQuery && global.db.data.users[userIdQuery]) {
                foundUser = global.db.data.users[userIdQuery];
                foundNumber = userIdQuery;
            } 
            // Si no hay ID o no se encontró por ID, buscar por apodo
            else if (apodoQuery) {
                const normalizedApodo = normalizeText(apodoQuery);

            // Primera pasada: búsqueda exacta
            for (let [number, userData] of Object.entries(global.db.data.users)) {
                if (userData?.apodo && userData.apodo.trim() !== '') {
                    const normalizedUserApodo = normalizeText(userData.apodo);
                    if (normalizedUserApodo === normalizedApodo) {
                        foundUser = userData;
                        foundNumber = number;
                        break;
                    }
                }
            }

            // Segunda pasada: búsqueda parcial
            if (!foundUser) {
                for (let [number, userData] of Object.entries(global.db.data.users)) {
                    if (userData?.apodo && userData.apodo.trim() !== '') {
                        const normalizedUserApodo = normalizeText(userData.apodo);
                        if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                            foundUser = userData;
                            foundNumber = number;
                            break;
                        }
                    }
                }
            }

            }

            if (!foundUser) {
                return res.status(404).json({ error: `No se encontró ningún usuario con el identificador proporcionado` });
            }

            // Calcular datos del perfil
            const levelInfo = achievements.calculateLevel(foundUser.exp || 0);
            const totalMoney = (foundUser.money || 0) + (foundUser.bank || 0);
            const apodo = (foundUser.apodo && foundUser.apodo.trim() !== '') ? foundUser.apodo : 'Sin apodo';
            const respeto = foundUser.respeto || 0;
            const rango = foundUser.rango || '🌱 Novato';
            const genero = foundUser.genero || 'No definido';
            const deuda = (foundUser.prestamo?.activo && foundUser.prestamo?.deuda > 0) ? foundUser.prestamo.deuda : 0;

            // Calcular ranking global
            const globalRanking = Object.entries(global.db.data.users)
                .map(([num, u]) => ({ num, total: (u.money || 0) + (u.bank || 0) }))
                .filter(u => u.total > 0)
                .sort((a, b) => b.total - a.total);
            const globalPos = globalRanking.findIndex(u => u.num === foundNumber) + 1;
            const globalTotal = globalRanking.length;
            // Información de pareja (estado civil)
            function tiempoTranscurrido(fecha) {
                const ahora = new Date();
                const inicio = new Date(fecha);
                const diferencia = ahora - inicio;
                const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
                const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
                return { dias, horas, minutos };
            }

            let parejaInfo = { estado: 'soltero' };
            try {
                const pareja = global.db.getPareja(foundNumber);
                if (pareja) {
                    const partnerUser = global.db.getUser(pareja.numero) || {};
                    const partnerApodo = partnerUser.apodo || 'Desconocido';
                    if (pareja.estado === 'aceptado') {
                        parejaInfo = {
                            estado: 'casado',
                            apodo: partnerApodo,
                            fecha: pareja.fecha,
                            tiempo: tiempoTranscurrido(pareja.fecha)
                        };
                    } else {
                        parejaInfo = {
                            estado: pareja.estado || 'pendiente',
                            apodo: partnerApodo,
                            fecha: pareja.fecha
                        };
                    }
                }
            } catch (_) {}

            return res.json({
                userId: foundNumber,
                apodo,
                genero,
                nivel: {
                    level: levelInfo.level,
                    xpActual: levelInfo.xpActual,
                    xpTotal: levelInfo.xpTotal,
                    xpFaltante: levelInfo.xpFaltante
                },
                economia: {
                    dinero: foundUser.money || 0,
                    banco: foundUser.bank || 0,
                    total: totalMoney,
                    deuda
                },
                respeto,
                rango,
                vecesTrabajadas: foundUser.totalWorkedTimes || 0,
                comandosUsados: foundUser.ComandosEjecutados || 0,
                rankingGlobal: {
                    posicion: globalPos > 0 ? globalPos : null,
                    total: globalTotal
                },
                pareja: parejaInfo
            });

        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /userprofile/update ─────────────────────────────────────────────
    // Actualiza el apodo de un usuario autenticado desde la web oficial
    // Seguridad: solo acepta peticiones desde los dominios oficiales
    app.post('/userprofile/update', express.json(), (req, res) => {
        try {
            // ── Validación de origen ──────────────────────────────────────────
            // Cuando el request viene de Vercel (server-to-server), el origen real
            // se reenvía en el header x-real-origin. Si no existe, se usa origin/referer.
            const allowedOrigins = [
                'https://roblebotpage.vercel.app',
                'https://robleuy.vercel.app',
                'https://robleuy.vercel.app',
            ];

            const origin  = (req.headers['x-real-origin'] || req.headers['origin'] || '').trim();
            const referer = (req.headers['x-real-referer'] || req.headers['referer'] || '').trim();

            const isAllowed = allowedOrigins.some(o =>
                origin === o ||
                origin.endsWith('.robleuy.vercel.app') ||
                referer.startsWith(o) ||
                referer.includes('.robleuy.vercel.app')
            );

            if (!isAllowed) {
                return res.status(403).json({ error: 'Origen no autorizado' });
            }

            // ── Validación de parámetros ──────────────────────────────────────
            const { userId, newApodo } = req.body || {};

            if (!userId || !newApodo) {
                return res.status(400).json({ error: 'Faltan parámetros userId o newApodo' });
            }

            // Solo letras, números y guiones bajos. 3–20 caracteres.
            if (!/^[a-zA-Z0-9_]{3,20}$/.test(newApodo)) {
                return res.status(400).json({ error: 'Apodo inválido. Solo letras, números y _ (3-20 caracteres).' });
            }

            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const userData = global.db.data.users[userId];
            if (!userData) {
                return res.status(404).json({ error: 'Usuario no encontrado' });
            }

            // Verificar que no sea el mismo apodo actual (case-insensitive)
            if ((userData.apodo || '').toLowerCase() === newApodo.toLowerCase()) {
                return res.status(400).json({ error: `Ese ya es tu apodo actual: ${userData.apodo}` });
            }

            // Verificar que el apodo no esté en uso por otro usuario
            const apodoTaken = Object.entries(global.db.data.users).some(
                ([num, u]) => num !== userId && u?.apodo && u.apodo.toLowerCase() === newApodo.toLowerCase()
            );
            if (apodoTaken) {
                return res.status(409).json({ error: 'Ese apodo ya está en uso' });
            }

            // ── Aplicar cambio ────────────────────────────────────────────────
            const oldApodo = userData.apodo || '';
            global.db.data.users[userId].apodo = newApodo;
            global.db.save(); // síncrono con debounce — no retorna Promise

            console.log(`[userprofile/update] ${userId}: apodo cambiado de "${oldApodo}" a "${newApodo}"`);

            return res.json({ success: true, apodo: newApodo });

        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/qr ──────────────────────────────────────────────────────
    app.get('/subbots/qr', async (req, res) => {
        // Usar bot principal si está disponible, sino el primer subbot activo, sino null
        // (los subbots pueden conectarse sin bot principal disponible)
        const connToUse = global.conn?.user
            ? global.conn
            : (global.subConns || []).find(c => c?.user) || null;

        const num = getNextNum();

        // Verificar si ya hay un QR pendiente para este num
        if (pendingWebQR.has(num)) {
            return res.status(429).json({ error: `Ya hay un QR pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el QR
        let resolveQR, rejectQR;
        const qrPromise = new Promise((res, rej) => { resolveQR = res; rejectQR = rej; });

        const timeout = setTimeout(() => {
            pendingWebQR.delete(num);
            rejectQR(new Error('Timeout esperando QR'));
        }, 30000);

        pendingWebQR.set(num, { resolve: resolveQR, reject: rejectQR, timeout });

        try {
            // Conectar subbot con ownerJid null (web) — el QR llegará via resolveWebQR
            const { connectSubBotWeb } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWeb({ num, conn: connToUse });

            const qrDataUrl = await qrPromise;

            // Convertir data URL a buffer PNG y enviar
            const base64 = qrDataUrl.replace(/^data:image\/png;base64,/, '');
            const imgBuf = Buffer.from(base64, 'base64');

            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'no-store');
            res.send(imgBuf);
        } catch (e) {
            pendingWebQR.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/code ────────────────────────────────────────────────────
    app.get('/subbots/code', async (req, res) => {
        // Usar bot principal si está disponible, sino el primer subbot activo, sino null
        // (los subbots pueden conectarse sin bot principal disponible)
        const connToUse = global.conn?.user
            ? global.conn
            : (global.subConns || []).find(c => c?.user) || null;

        const rawPhone = (req.query.phone || req.query.number || '').trim();
        if (!rawPhone) {
            return res.status(400).json({ error: 'Parámetro "phone" requerido. Ejemplo: /subbots/code?phone=59893900470' });
        }

        // Limpiar igual que el comando .serbot code: quitar +, espacios, guiones, etc.
        const cleanNumber = rawPhone.replace(/[^0-9]/g, '');
        if (cleanNumber.length < 7 || cleanNumber.length > 15) {
            return res.status(400).json({ error: 'Número inválido. Usa formato internacional, ej: 59893900470' });
        }

        const num = getNextNum();

        // Verificar si ya hay un código pendiente para este num
        if (pendingWebCode.has(num)) {
            return res.status(429).json({ error: `Ya hay un código pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el código
        let resolveCode, rejectCode;
        const codePromise = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });

        const timeout = setTimeout(() => {
            pendingWebCode.delete(num);
            rejectCode(new Error('Timeout esperando código de emparejamiento'));
        }, 60000); // 60 segundos para el código

        pendingWebCode.set(num, { resolve: resolveCode, reject: rejectCode, timeout });

        try {
            // Conectar subbot con método de código
            const { connectSubBotWebWithCode } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWebWithCode({ num, conn: connToUse, phoneNumber: cleanNumber });

            const pairingCode = await codePromise;

            res.json({
                success:      true,
                subbotNumber: num,
                phoneNumber:  cleanNumber,
                pairingCode:  pairingCode,
                message:      'Ingresa este código en WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono'
            });
        } catch (e) {
            pendingWebCode.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── GET /exists ─────────────────────────────────────────────────────────
    // Verifica si un número de teléfono está registrado en WhatsApp
    // Params: number | phone (ej: /exists?number=59893900470)
    app.get(['/exists', '/subbots/exists'], async (req, res) => {
        try {
            const rawNumber = (req.query.number || req.query.phone || '').trim();
            if (!rawNumber) {
                return res.status(400).json({ error: 'Parámetro "number" o "phone" requerido. Ejemplo: /exists?number=59893900470' });
            }

            const cleanNumber = rawNumber.replace(/[^0-9]/g, '');
            if (cleanNumber.length < 7 || cleanNumber.length > 15) {
                return res.status(400).json({ error: 'Número inválido. Debe tener entre 7 y 15 dígitos.', exists: false });
            }

            const connToUse = global.conn?.user
                ? global.conn
                : (global.subConns || []).find(c => c?.user) || null;

            if (!connToUse || typeof connToUse.onWhatsApp !== 'function') {
                return res.status(503).json({ error: 'No hay conexión de WhatsApp disponible para realizar la verificación.' });
            }

            const jid = `${cleanNumber}@s.whatsapp.net`;
            const results = await connToUse.onWhatsApp(jid);
            const result = Array.isArray(results) ? results[0] : null;
            const exists = !!(result && (result.exists === true || result.jid));

            return res.json({
                exists,
                number: cleanNumber,
                jid: result?.jid || (exists ? jid : null)
            });
        } catch (e) {
            return res.status(500).json({ error: e.message, exists: false });
        }
    });

    // ── POST /webauth/request ───────────────────────────────────────────────
    // Genera un código de 4 dígitos para login web
    app.post('/webauth/request', express.json(), (req, res) => {
        try {
            const apodo = (req.query.apodo || req.body?.apodo || '').trim();
            if (!apodo) {
                return res.status(400).json({ error: 'Falta parámetro apodo' });
            }

            // Generar código numérico de 4 dígitos
            let code = Math.floor(1000 + Math.random() * 9000).toString();
            
            // Asegurar que no exista ya (improbable pero posible)
            while(pendingWebAuth.has(code)) {
                code = Math.floor(1000 + Math.random() * 9000).toString();
            }

            // Guardar con TTL de 5 minutos
            pendingWebAuth.set(code, {
                apodo: apodo.toLowerCase(),
                status: 'pending',
                createdAt: Date.now()
            });

            // Limpiar códigos expirados
            for (const [key, val] of pendingWebAuth.entries()) {
                if (Date.now() - val.createdAt > 5 * 60 * 1000) {
                    pendingWebAuth.delete(key);
                }
            }

            return res.json({ success: true, code: code, apodo: apodo });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /webauth/verify ────────────────────────────────────────────────
    // Llamado desde el bot cuando el usuario usa .webcode
    app.post('/webauth/verify', express.json(), async (req, res) => {
        try {
            const apodo = (req.query.apodo || req.body?.apodo || '').trim();
            const code = (req.query.code || req.body?.code || '').trim();
            const userId = req.body?.userId || req.query.userId;

            if (!apodo || !code) {
                return res.status(400).json({ error: 'Faltan parámetros apodo o code' });
            }

            const authReq = pendingWebAuth.get(code);
            
            if (!authReq) {
                return res.status(404).json({ error: 'Código inválido o expirado' });
            }

            if (authReq.apodo !== apodo.toLowerCase()) {
                return res.status(403).json({ error: 'El apodo no coincide con la solicitud original' });
            }

            authReq.status = 'verified';
            authReq.userId = userId;
            pendingWebAuth.set(code, authReq);

            const secret = process.env.WEB_AUTH_SECRET || 'roblebotrobleuy13paginaweb';
            const sessionToken = createSignedSessionToken({
                userId,
                apodo: apodo.toLowerCase(),
                createdAt: Date.now(),
                expiresAt: Date.now() + 30 * 60 * 1000,
            }, secret);

            await saveSession({
                sessionToken,
                userId,
                apodo: apodo.toLowerCase(),
                expiresAt: Date.now() + 30 * 60 * 1000,
                createdAt: Date.now(),
            });

            return res.json({ success: true, message: 'Sesión verificada', sessionToken, userId });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /webauth/status ─────────────────────────────────────────────────
    // Usado por la web (polling) para saber si ya se verificó
    app.get('/webauth/status', async (req, res) => {
        try {
            const code = (req.query.code || '').trim();
            const sessionToken = (req.query.sessionToken || '').trim();
            if (!code && !sessionToken) {
                return res.status(400).json({ error: 'Falta código o sessionToken' });
            }

            if (sessionToken) {
                const secret = process.env.WEB_AUTH_SECRET || 'roblebotrobleuy13paginaweb';
                const payload = verifySignedSessionToken(sessionToken, secret);
                if (!payload) {
                    return res.status(401).json({ error: 'Sesión inválida' });
                }
                if (payload.expiresAt && Date.now() > payload.expiresAt) {
                    await revokeSession(sessionToken);
                    return res.status(401).json({ error: 'Sesión expirada' });
                }
                const dbSession = await getSession(sessionToken);
                if (!dbSession) {
                    return res.status(401).json({ error: 'Sesión no encontrada' });
                }
                return res.json({ success: true, status: 'verified', apodo: dbSession.apodo, userId: dbSession.userId, sessionToken });
            }

            const authReq = pendingWebAuth.get(code);
            if (!authReq) {
                return res.status(404).json({ error: 'Código no encontrado o expirado' });
            }

            return res.json({ 
                success: true, 
                status: authReq.status,
                apodo: authReq.apodo,
                userId: authReq.userId
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /topcomandos ─────────────────────────────────────────────────────
    // Lista de comandos más usados con su cantidad de usos (histórico total).
    // Params:
    //   limit → cuántos comandos devolver (por defecto 20, máximo 200)
    //   page  → paginación (por defecto 1, pageSize = limit)
    //
    // Ejemplos:
    //   /topcomandos          → top 20 comandos
    //   /topcomandos?limit=10 → top 10 comandos
    //   /topcomandos?page=2   → página 2 (comandos 21-40)
    app.get('/topcomandos', (req, res) => {
        try {
            const stats = loadStats();

            if (!stats.commands || typeof stats.commands !== 'object') {
                return res.json({ total: 0, comandos: [] });
            }

            const limitParam = parseInt(req.query.limit, 10);
            const pageParam  = parseInt(req.query.page,  10);
            const limit = (!Number.isNaN(limitParam) && limitParam > 0)
                ? Math.min(limitParam, 200)
                : 20;
            const page  = (!Number.isNaN(pageParam) && pageParam > 0) ? pageParam : 1;

            const sorted = Object.entries(stats.commands)
                .map(([cmd, usos]) => ({ cmd, usos }))
                .sort((a, b) => b.usos - a.usos);

            const total = sorted.length;
            const start = (page - 1) * limit;
            const slice = sorted.slice(start, start + limit).map((item, i) => ({
                posicion: start + i + 1,
                cmd:  item.cmd,
                usos: item.usos,
            }));

            return res.json({
                total,
                page,
                limit,
                totalPaginas: Math.ceil(total / limit),
                comandos: slice,
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /activity ────────────────────────────────────────────────────────
    // Estadísticas de actividad del bot en un período de tiempo.
    // Params:
    //   q  → período (ej: 1h, 6h, 12h, 1d, 7d, 30d). Por defecto: 1d
    //
    // Fuente de usuarios: stats.users[id].lastSeen (igual que .usersbot)
    // Fuente de comandos: commandLog (disponible hasta 7 días atrás)
    app.get('/activity', (req, res) => {
        try {
            const qParam = (req.query.q || '1d').toString().trim().toLowerCase();

            // Parsear el período: número + unidad (m = minutos, h = horas, d = días)
            const match = qParam.match(/^(\d+(?:\.\d+)?)(m|h|d)$/);
            if (!match) {
                return res.status(400).json({
                    error: 'Parámetro "q" inválido. Usa formato: 1h, 6h, 1d, 7d, 30d, 30m, etc.',
                    ejemplos: ['1h', '6h', '12h', '1d', '7d', '30d']
                });
            }

            const value = parseFloat(match[1]);
            const unit  = match[2];

            let ms;
            if      (unit === 'm') ms = value * 60 * 1000;
            else if (unit === 'h') ms = value * 60 * 60 * 1000;
            else                   ms = value * 24 * 60 * 60 * 1000;

            const sinceMs = Date.now() - ms;
            const stats   = loadStats();

            // ── Usuarios activos: misma lógica que .usersbot ──────────────────
            // Usa stats.users[id].lastSeen — historial completo, sin límite de días
            const users = stats.users || {};
            let usuariosActivos = 0;
            for (const u of Object.values(users)) {
                if (u && u.lastSeen >= sinceMs) usuariosActivos++;
            }

            // ── Comandos ejecutados: del commandLog (permanente) ─────────────
            let comandosEjecutados = 0;
            if (Array.isArray(stats.commandLog)) {
                comandosEjecutados = stats.commandLog.filter(entry => {
                    const ts = typeof entry === 'number' ? entry : entry.t;
                    return ts >= sinceMs;
                }).length;
            }

            return res.json({
                periodo: qParam,
                desde: new Date(sinceMs).toISOString(),
                hasta: new Date().toISOString(),
                usuariosActivos,
                comandosEjecutados,
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── Helpers para comandos personalizados (idénticos a los del plugin) ──────
    const CMD_DATA_PATH = path.join(__dirname, 'data', 'comandos.json');
    const CMD_RESERVED  = ['addcmd', 'mycmds', 'delcmd', 'cmds'];
    const CMD_MAX       = 50;
    const CMD_IMG_REGEX = /@img=(\S+)/i;

    function cmdLoadStore() {
        try {
            if (!fs.existsSync(CMD_DATA_PATH)) return { commands: {} };
            const parsed = JSON.parse(fs.readFileSync(CMD_DATA_PATH, 'utf8'));
            if (!parsed?.commands) parsed.commands = {};
            return parsed;
        } catch { return { commands: {} }; }
    }

    function cmdSaveStore(store) {
        const dir = path.dirname(CMD_DATA_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CMD_DATA_PATH, JSON.stringify(store, null, 2));
    }

    function cmdNormalizeName(raw) {
        return (raw || '').trim().replace(/^[^a-zA-Z0-9]+/, '').toLowerCase();
    }

    function cmdIsValidName(name) {
        return /^[a-z0-9_]+$/i.test(name);
    }

    function cmdTemplateHasBase64(tpl) {
        return /@img=data:[^;]+;base64,/i.test(tpl);
    }

    function cmdIsValidImageUrl(url) {
        try { new URL(url); return /^https?:\/\/.+/i.test(url); } catch { return false; }
    }

    function cmdTemplateLengthOk(tpl) {
        const stripped = tpl
            .replace(/@yo|@text|@random|@randomUser/gi, '')
            .replace(/@img=\S+/gi, '')
            .trim();
        return stripped.length <= 100;
    }

    function cmdHasOfficialCommand(name) {
        const h = global.commandHandler;
        if (!h?.commands) return false;
        if (h.commands.has(name)) return true;
        for (const [k] of h.commands) {
            if (k instanceof RegExp && k.test(name)) return true;
        }
        return false;
    }

    const ALLOWED_ORIGINS_CMDS = [
        'https://roblebotpage.vercel.app',
        'https://robleuy.vercel.app',
    ];

    function cmdIsAllowedOrigin(req) {
        const origin  = (req.headers['x-real-origin'] || req.headers['origin'] || '').trim();
        const referer = (req.headers['x-real-referer'] || req.headers['referer'] || '').trim();
        return ALLOWED_ORIGINS_CMDS.some(o =>
            origin === o ||
            origin.endsWith('.vercel.app') ||
            referer.startsWith(o) ||
            referer.includes('.vercel.app')
        );
    }

    // ── GET /customcmds ──────────────────────────────────────────────────────
    // Lista los comandos personalizados de un usuario.
    // Params: userId (obligatorio)
    app.get('/customcmds', (req, res) => {
        try {
            const userId = (req.query.userId || '').trim();
            if (!userId) {
                return res.status(400).json({ error: 'Falta el parámetro userId' });
            }

            const store = cmdLoadStore();
            const userCmds = Object.entries(store.commands)
                .filter(([, data]) => data.creator === userId)
                .sort(([, a], [, b]) => (b.createdAt || 0) - (a.createdAt || 0))
                .map(([name, data]) => {
                    const imgMatch = data.template.match(CMD_IMG_REGEX);
                    const imageUrl = imgMatch ? imgMatch[1] : null;
                    const cleanTemplate = data.template.replace(CMD_IMG_REGEX, '').trim();
                    return {
                        name,
                        template: data.template,
                        cleanTemplate,
                        imageUrl,
                        uses: data.uses || 0,
                        uniqueUsers: Array.isArray(data.usedBy) ? data.usedBy.length : 0,
                        createdAt: data.createdAt || null,
                    };
                });

            return res.json({
                success: true,
                total: userCmds.length,
                max: CMD_MAX,
                commands: userCmds,
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /customcmds ─────────────────────────────────────────────────────
    // Crea un nuevo comando personalizado.
    // Body: { userId, commandName, template }
    app.post('/customcmds', express.json(), (req, res) => {
        try {
            if (!cmdIsAllowedOrigin(req)) {
                return res.status(403).json({ error: 'Origen no autorizado' });
            }

            const { userId, commandName: rawName, template: rawTemplate } = req.body || {};

            if (!userId || !rawName || !rawTemplate) {
                return res.status(400).json({ error: 'Faltan parámetros: userId, commandName, template' });
            }

            const commandName = cmdNormalizeName(rawName);
            const template    = (rawTemplate || '').trim();

            if (!commandName) {
                return res.status(400).json({ error: 'Nombre de comando inválido. Debe ser solo letras, números o guion bajo.' });
            }

            if (!cmdIsValidName(commandName)) {
                return res.status(400).json({ error: 'El nombre del comando solo puede contener letras, números y guion bajo.' });
            }

            if (CMD_RESERVED.includes(commandName)) {
                return res.status(400).json({ error: 'Ese nombre está reservado. Usa otro nombre para tu comando.' });
            }

            if (!template) {
                return res.status(400).json({ error: 'Debes indicar el mensaje que devolverá el comando.' });
            }

            if (cmdTemplateHasBase64(template)) {
                return res.status(400).json({ error: 'No se puede usar imagen en base64. Sube la imagen a un hosting (imgur, imgbb) y usa el link directo.' });
            }

            const imgMatch = template.match(CMD_IMG_REGEX);
            if (imgMatch && !cmdIsValidImageUrl(imgMatch[1])) {
                return res.status(400).json({ error: 'La URL de imagen en @img= no es válida. Debe comenzar con http:// o https://' });
            }

            if (!cmdTemplateLengthOk(template)) {
                return res.status(400).json({ error: 'El mensaje no puede tener más de 100 caracteres sin contar los parámetros @yo, @text, @random o @img=URL.' });
            }

            const store = cmdLoadStore();

            const userCount = Object.values(store.commands).filter(d => d.creator === userId).length;
            if (userCount >= CMD_MAX) {
                return res.status(400).json({ error: `Has alcanzado el límite de ${CMD_MAX} comandos personalizados. Elimina uno para poder crear uno nuevo.` });
            }

            if (store.commands[commandName]) {
                return res.status(409).json({ error: 'Ese comando ya existe. Elige otro nombre.' });
            }

            if (cmdHasOfficialCommand(commandName)) {
                return res.status(409).json({ error: 'No puedes crear ese comando porque ya existe como comando oficial del bot.' });
            }

            store.commands[commandName] = {
                template,
                creator:   userId,
                createdAt: Date.now(),
                uses:      0,
                usedBy:    [],
            };

            cmdSaveStore(store);

            const imageUrl = imgMatch ? imgMatch[1] : null;
            const cleanTemplate = template.replace(CMD_IMG_REGEX, '').trim();

            return res.json({
                success: true,
                message: `✅ Comando .${commandName} creado con éxito.`,
                command: { name: commandName, template, cleanTemplate, imageUrl, createdAt: store.commands[commandName].createdAt },
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── DELETE /customcmds ───────────────────────────────────────────────────
    // Elimina un comando personalizado del usuario.
    // Body: { userId, commandName }
    app.delete('/customcmds', express.json(), (req, res) => {
        try {
            if (!cmdIsAllowedOrigin(req)) {
                return res.status(403).json({ error: 'Origen no autorizado' });
            }

            const { userId, commandName: rawName } = req.body || {};
            if (!userId || !rawName) {
                return res.status(400).json({ error: 'Faltan parámetros: userId, commandName' });
            }

            const commandName = cmdNormalizeName(rawName);
            const store = cmdLoadStore();
            const stored = store.commands[commandName];

            if (!stored) {
                return res.status(404).json({ error: `El comando .${commandName} no existe.` });
            }

            const isOwner = global.botConfig?.isOwner?.(userId);
            if (stored.creator !== userId && !isOwner) {
                return res.status(403).json({ error: 'No eres el creador de este comando.' });
            }

            delete store.commands[commandName];
            cmdSaveStore(store);

            return res.json({ success: true, message: `✅ Comando .${commandName} eliminado.` });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /premium/check-free ──────────────────────────────────────────────
    // Verifica si un usuario ya reclamó su premium gratuito.
    // Query: ?apodo=xxx  o  ?userId=xxx
    app.get('/premium/check-free', (req, res) => {
        try {
            const { apodo, userId } = req.query;
            if (!apodo && !userId) {
                return res.status(400).json({ error: 'Falta el parámetro apodo o userId' });
            }

            const premium = require('./premium');
            let targetId = userId;
            if (!targetId && apodo) {
                targetId = premium.findNumberByApodo(apodo) || apodo;
            }

            const cleanId = (targetId || '').replace(/[^0-9]/g, '');
            const user = global.db?.getUser?.(cleanId);
            const claimed = user?.premium_free_claimed === true;

            return res.json({ success: true, userId: cleanId, claimed });
        } catch (e) {
            console.error('[Premium] Error en GET /premium/check-free:', e);
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /premium/free-claim ─────────────────────────────────────────────
    // Otorga 1 día de Premium gratuito si el usuario no lo ha reclamado antes.
    // Body: { apodo, secret }
    app.post('/premium/free-claim', express.json(), (req, res) => {
        try {
            const { apodo, secret } = req.body || {};
            const expectedSecret = process.env.WEB_AUTH_SECRET || 'roblebotrobleuy13paginaweb';

            if (!secret || secret !== expectedSecret) {
                return res.status(403).json({ error: 'Secret de autorización inválido' });
            }
            if (!apodo) {
                return res.status(400).json({ error: 'Falta el parámetro apodo' });
            }

            const premium = require('./premium');
            const targetNumber = premium.findNumberByApodo(apodo);
            const userId = targetNumber || apodo;
            const cleanId = (userId || '').replace(/[^0-9]/g, '');

            if (!cleanId) {
                return res.status(400).json({ error: 'Usuario no encontrado' });
            }

            const user = global.db?.getUser?.(cleanId);
            if (!user) {
                return res.status(404).json({ error: 'Usuario no encontrado en la base de datos' });
            }

            // Verificar si ya reclamó
            if (user.premium_free_claimed === true) {
                return res.status(409).json({
                    error: 'already_claimed',
                    message: `El usuario *${apodo}* ya reclamó su Premium gratuito. Podrá volver a reclamarlo el día 1 del mes siguiente.`
                });
            }

            // Otorgar 1 día (~1/30 de mes)
            const MS_PER_DAY = 24 * 60 * 60 * 1000;
            const { loadPremiumData, savePremiumData } = (() => {
                // Acceso directo al módulo premium para otorgar días exactos
                const fs = require('fs');
                const path = require('path');
                const DATA_DIR = path.join(__dirname, 'data');
                const PREMIUM_FILE = path.join(DATA_DIR, 'usuarios-premium.json');
                return {
                    loadPremiumData: () => {
                        try { return JSON.parse(fs.readFileSync(PREMIUM_FILE, 'utf8')); } catch { return { users: {} }; }
                    },
                    savePremiumData: (d) => {
                        const tmp = PREMIUM_FILE + '.tmp';
                        fs.writeFileSync(tmp, JSON.stringify(d, null, 2));
                        fs.renameSync(tmp, PREMIUM_FILE);
                    }
                };
            })();

            const now = Date.now();
            const data = loadPremiumData();
            const existing = data.users[cleanId];
            if (existing && Number(existing.expiresAt) > now) {
                data.users[cleanId].expiresAt = Number(existing.expiresAt) + MS_PER_DAY;
            } else {
                data.users[cleanId] = { startedAt: now, expiresAt: now + MS_PER_DAY };
            }
            savePremiumData(data);
            // Invalidar caché del módulo premium
            if (global.__premiumDataCache) global.__premiumDataCache = null;

            // Marcar en database.json que ya reclamó
            user.premium_free_claimed = true;
            global.db?.setUser?.(cleanId, user);

            console.log(`[Premium] 🎁 Premium gratuito (1 día) otorgado a "${apodo}" (ID: ${cleanId})`);

            return res.json({
                success: true,
                message: `✅ ¡1 día de Premium gratuito activado para ${apodo}!`,
                userId: cleanId,
                expiresAt: data.users[cleanId].expiresAt
            });
        } catch (e) {
            console.error('[Premium] Error en /premium/free-claim:', e);
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /premium/usuarios ────────────────────────────────────────────────
    // Devuelve la lista de usuarios premium activos con su apodo y tiempo restante.
    app.get('/premium/usuarios', (req, res) => {
        try {
            const premium = require('./premium');
            const premiumList = premium.getPremiumList();

            const result = premiumList.map(entry => {
                const user = global.db?.getUser?.(entry.userId);
                const apodo = (user?.apodo || '').trim() || null;

                const dias = Math.floor(entry.remainingMs / (1000 * 60 * 60 * 24));
                const horas = Math.floor((entry.remainingMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutos = Math.floor((entry.remainingMs % (1000 * 60 * 60)) / (1000 * 60));

                return {
                    userId: entry.userId,
                    apodo: apodo || entry.userId,
                    tiempoRestante: premium.formatRemaining(entry.remainingMs),
                    tiempoRestanteDesglosado: { dias, horas, minutos },
                    expiresAt: entry.expiresAt
                };
            });

            return res.json({ success: true, total: result.length, usuarios: result });
        } catch (e) {
            console.error('[Premium] Error en GET /premium/usuarios:', e);
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /premium/grant ──────────────────────────────────────────────────
    // Otorga Premium a un usuario tras verificación del pago de la web.
    // Body: { apodo, months, secret, orderID }
    app.post('/premium/grant', express.json(), (req, res) => {
        try {
            const { apodo, months = 1, secret, orderID } = req.body || {};
            const expectedSecret = process.env.WEB_AUTH_SECRET || 'roblebotrobleuy13paginaweb';
            
            if (!secret || secret !== expectedSecret) {
                return res.status(403).json({ error: 'Secret de autorización inválido' });
            }

            if (!apodo) {
                return res.status(400).json({ error: 'Falta el parámetro apodo' });
            }

            const premium = require('./premium');
            const targetNumber = premium.findNumberByApodo(apodo);
            const userId = targetNumber || apodo;

            const result = premium.addPremium(userId, months);
            if (!result) {
                return res.status(500).json({ error: 'No se pudo otorgar el estado Premium' });
            }

            console.log(`[Premium] ⭐ Se han acreditado ${months * 30} días de Premium a "${apodo}" (ID: ${userId}) por la orden ${orderID || 'N/A'}`);

            return res.json({
                success: true,
                message: `✅ Premium de ${months * 30} días acreditado con éxito a ${apodo}`,
                data: result
            });
        } catch (e) {
            console.error('[Premium] Error en /premium/grant:', e);
            return res.status(500).json({ error: e.message });
        }
    });

    app.listen(port, () => {
        console.log(`[SubBotServer] HTTP en puerto ${port} → /subbots/qr | /subbots/code | /subbots/exists | /exists | /topdinero | /stats | /activity | /topcomandos | /customcmds | /premium/grant | /premium/usuarios | /premium/check-free | /premium/free-claim`);
    });

    return { resolveWebQR, resolveWebCode };
}

module.exports = { startSubBotServer, resolveWebQR, resolveWebCode };