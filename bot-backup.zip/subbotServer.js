'use strict';
/**
 * Servidor HTTP para gestión de sub-bots
 *
 * GET /subbots/qr                    → Genera QR para nuevo sub-bot (imagen PNG)
 * GET /subbots/code?phone=XXXXXXXXXX → Genera código de emparejamiento de 8 dígitos (JSON)
 * GET /subbots/list                  → Lista de sub-bots activos (JSON)
 */

const express = require('express');
const qrcode  = require('qrcode');
const fs      = require('fs');
const path    = require('path');
const { loadStats } = require('./botStatsRecorder');
const achievements = require('./achievements');

// Map de QRs pendientes por num: { resolve, reject, timeout }
const pendingWebQR = new Map();

// Map de códigos de emparejamiento pendientes por num: { resolve, reject, timeout }
const pendingWebCode = new Map();

// Map de web auth: code -> { apodo, status: 'pending'|'verified', createdAt }
const pendingWebAuth = new Map();

// Sin caché - el endpoint /stats se actualiza al instante

// Usa nextSubBotNumber del módulo principal para evitar conflictos de numeración
function getNextNum() {
    const { nextSubBotNumber } = require('./plugins/SUBBOTS/subbot-serbot');
    return nextSubBotNumber();
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un QR
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebQR(num, qrDataUrl) {
    const pending = pendingWebQR.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebQR.delete(num);
        pending.resolve(qrDataUrl);
    }
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un código de emparejamiento
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebCode(num, code) {
    const pending = pendingWebCode.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebCode.delete(num);
        if (code === null) {
            pending.reject(new Error('Error generando código de emparejamiento'));
        } else {
            pending.resolve(code);
        }
    }
}

function startSubBotServer(port = 3000) {
    const app = express();

    // CORS — permite acceso desde cualquier origen (incluyendo páginas HTTPS)
    app.use((req, res, next) => {
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        if (req.method === 'OPTIONS') return res.sendStatus(204);
        next();
    });

    // ── Middleware para manejar rutas con ?action= ──────────────────────────
    // Reescribe /api/roblebot?action=X a /X para compatibilidad
    app.use((req, res, next) => {
        const action = req.query.action;
        if (action) {
            req.url = `/${action}${req.url.includes('&') ? '?' + req.url.split('&').slice(1).join('&') : ''}`;
            delete req.query.action;
        }
        next();
    });

    // ── GET /subbots/info ────────────────────────────────────────────────────
    app.get('/subbots/info', (req, res) => {
        const mainNum = global.mainBotNumber || null;
        res.json({
            mainBot: mainNum ? { number: mainNum, link: `wa.me/+${mainNum}` } : null,
            group:   'https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv',
            channel: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
        });
    });

    // ── GET /subbots/list ────────────────────────────────────────────────────
    app.get('/subbots/list', (req, res) => {
        const active = (global.subConns || [])
            .filter(c => c.user)
            .sort((a, b) => a._subNum - b._subNum)
            .map(c => ({
                num:    c._subNum,
                uptime: c.uptime ? Date.now() - c.uptime : null,
            }));

        res.json({ total: active.length, subbots: active });
    });

    // ── GET /topdinero ───────────────────────────────────────────────────────
    // Top global de dinero: apodo, posición, dinero (money+bank)
    // Params:
    // - apodo: busca jugador por apodo exacto (case-insensitive)
    // - position: devuelve jugador en posición exacta
    // - page: devuelve 10 jugadores de la página solicitada
    app.get('/topdinero', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const rows = [];
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (!userData) continue;
                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? 'Sin Apodo'
                    : apodoRaw;

                rows.push({ apodo, dinero: totalMoney });
            }

            rows.sort((a, b) => b.dinero - a.dinero);
            const top = rows.map((u, i) => ({
                posicion: i + 1,
                apodo: u.apodo,
                dinero: u.dinero
            }));

            const apodoQuery = (req.query.apodo || '').toString().trim();
            const positionQuery = req.query.position ? parseInt(req.query.position, 10) : NaN;
            const pageQuery = req.query.page ? parseInt(req.query.page, 10) : NaN;

            if (apodoQuery) {
                const found = top.find(u => u.apodo.toLowerCase() === apodoQuery.toLowerCase());
                if (!found) {
                    return res.status(404).json({
                        error: `No se encontró el jugador con apodo '${apodoQuery}'`,
                        query: { apodo: apodoQuery }
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { apodo: apodoQuery },
                    resultado: found
                });
            }

            if (!Number.isNaN(positionQuery)) {
                if (positionQuery < 1 || positionQuery > top.length) {
                    return res.status(404).json({
                        error: `No existe un jugador en la posición ${positionQuery}`,
                        query: { position: positionQuery },
                        totalRankeados: top.length
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { position: positionQuery },
                    resultado: top[positionQuery - 1]
                });
            }

            if (!Number.isNaN(pageQuery)) {
                if (pageQuery < 1) {
                    return res.status(400).json({
                        error: 'El parámetro page debe ser un número entero mayor o igual a 1',
                        query: { page: pageQuery }
                    });
                }
                const pageSize = 10;
                const start = (pageQuery - 1) * pageSize;
                const pageItems = top.slice(start, start + pageSize);
                return res.json({
                    totalRankeados: top.length,
                    page: pageQuery,
                    pageSize,
                    resultados: pageItems
                });
            }

            return res.json({
                totalRankeados: top.length,
                top
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /funciones ───────────────────────────────────────────────────────
    // Cantidad total de plugins (.js) dentro de /plugins (recursivo)
    app.get('/funciones', (req, res) => {
        try {
            const pluginsDir = path.join(__dirname, 'plugins');
            if (!fs.existsSync(pluginsDir)) {
                return res.status(500).json({ error: 'No existe la carpeta plugins' });
            }

            const countJsRecursive = (dir) => {
                let count = 0;
                const items = fs.readdirSync(dir, { withFileTypes: true });
                for (const it of items) {
                    const full = path.join(dir, it.name);
                    if (it.isDirectory()) count += countJsRecursive(full);
                    else if (it.isFile() && it.name.toLowerCase().endsWith('.js')) count++;
                }
                return count;
            };

            const totalPlugins = countJsRecursive(pluginsDir);
            return res.json({ pluginsJs: totalPlugins });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /menu.txt ─────────────────────────────────────────────────────────
    app.get('/menu.txt', (req, res) => {
        try {
            const menuPath = path.join(__dirname, 'menu.txt');
            if (!fs.existsSync(menuPath)) {
                return res.status(404).json({ error: 'menu.txt no encontrado' });
            }
            const content = fs.readFileSync(menuPath, 'utf8');
            res.set('Content-Type', 'text/plain; charset=utf-8');
            return res.send(content);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /stats ───────────────────────────────────────────────────────────
    // Devuelve stats del bot (resumen en JSON) - SIN info de grupos/participantes
    app.get('/stats', async (req, res) => {
        try {
            const stats = loadStats();
            const totalCommands = stats.totalCommandsExecuted || stats.totalCommands || 0;
            const totalUsers = global.db?.data?.users ? Object.keys(global.db.data.users).length : 0;

            // Cantidad de bots activos
            const activeSubbots = (global.subConns || []).filter(c => c.user);
            const subbotsCount = activeSubbots.length;
            const mainActive = global.conn?.user ? 1 : 0;

            const result = {
                totalCommands,
                totalCommandsExecuted: totalCommands,
                availableCommands: stats.availableCommands || 0,
                loadedPlugins: stats.loadedPlugins || 0,
                totalUsers,
                bots: {
                    main: mainActive,
                    subbots: subbotsCount,
                    total: mainActive + subbotsCount
                }
            };

            return res.json(result);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /userprofile ─────────────────────────────────────────────────────
    // Devuelve el perfil completo de un usuario por apodo o userId
    // Params: apodo | userId
    app.get('/userprofile', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const apodoQuery = (req.query.apodo || '').trim();
            const userIdQuery = (req.query.userId || '').trim();
            
            if (!apodoQuery && !userIdQuery) {
                return res.status(400).json({ error: 'Parámetro "apodo" o "userId" requerido' });
            }

            // Función para normalizar texto
            const normalizeText = (text) => {
                if (!text) return '';
                return text
                    .trim()
                    .toLowerCase()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .replace(/\s+/g, ' ');
            };

            // Level calculation handled by achievements module

            let foundUser = null;
            let foundNumber = null;

            // Búsqueda por ID directo (Prioridad)
            if (userIdQuery && global.db.data.users[userIdQuery]) {
                foundUser = global.db.data.users[userIdQuery];
                foundNumber = userIdQuery;
            } 
            // Si no hay ID o no se encontró por ID, buscar por apodo
            else if (apodoQuery) {
                const normalizedApodo = normalizeText(apodoQuery);

            // Primera pasada: búsqueda exacta
            for (let [number, userData] of Object.entries(global.db.data.users)) {
                if (userData?.apodo && userData.apodo.trim() !== '') {
                    const normalizedUserApodo = normalizeText(userData.apodo);
                    if (normalizedUserApodo === normalizedApodo) {
                        foundUser = userData;
                        foundNumber = number;
                        break;
                    }
                }
            }

            // Segunda pasada: búsqueda parcial
            if (!foundUser) {
                for (let [number, userData] of Object.entries(global.db.data.users)) {
                    if (userData?.apodo && userData.apodo.trim() !== '') {
                        const normalizedUserApodo = normalizeText(userData.apodo);
                        if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                            foundUser = userData;
                            foundNumber = number;
                            break;
                        }
                    }
                }
            }

            }

            if (!foundUser) {
                return res.status(404).json({ error: `No se encontró ningún usuario con el identificador proporcionado` });
            }

            // Calcular datos del perfil
            const levelInfo = achievements.calculateLevel(foundUser.exp || 0);
            const totalMoney = (foundUser.money || 0) + (foundUser.bank || 0);
            const apodo = (foundUser.apodo && foundUser.apodo.trim() !== '') ? foundUser.apodo : 'Sin apodo';
            const respeto = foundUser.respeto || 0;
            const rango = foundUser.rango || '🌱 Novato';
            const genero = foundUser.genero || 'No definido';
            const deuda = (foundUser.prestamo?.activo && foundUser.prestamo?.deuda > 0) ? foundUser.prestamo.deuda : 0;

            // Calcular ranking global
            const globalRanking = Object.entries(global.db.data.users)
                .map(([num, u]) => ({ num, total: (u.money || 0) + (u.bank || 0) }))
                .filter(u => u.total > 0)
                .sort((a, b) => b.total - a.total);
            const globalPos = globalRanking.findIndex(u => u.num === foundNumber) + 1;
            const globalTotal = globalRanking.length;
            // Información de pareja (estado civil)
            function tiempoTranscurrido(fecha) {
                const ahora = new Date();
                const inicio = new Date(fecha);
                const diferencia = ahora - inicio;
                const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
                const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
                return { dias, horas, minutos };
            }

            let parejaInfo = { estado: 'soltero' };
            try {
                const pareja = global.db.getPareja(foundNumber);
                if (pareja) {
                    const partnerUser = global.db.getUser(pareja.numero) || {};
                    const partnerApodo = partnerUser.apodo || 'Desconocido';
                    if (pareja.estado === 'aceptado') {
                        parejaInfo = {
                            estado: 'casado',
                            apodo: partnerApodo,
                            fecha: pareja.fecha,
                            tiempo: tiempoTranscurrido(pareja.fecha)
                        };
                    } else {
                        parejaInfo = {
                            estado: pareja.estado || 'pendiente',
                            apodo: partnerApodo,
                            fecha: pareja.fecha
                        };
                    }
                }
            } catch (_) {}

            return res.json({
                userId: foundNumber,
                apodo,
                genero,
                nivel: {
                    level: levelInfo.level,
                    xpActual: levelInfo.xpActual,
                    xpTotal: levelInfo.xpTotal,
                    xpFaltante: levelInfo.xpFaltante
                },
                economia: {
                    dinero: foundUser.money || 0,
                    banco: foundUser.bank || 0,
                    total: totalMoney,
                    deuda
                },
                respeto,
                rango,
                vecesTrabajadas: foundUser.totalWorkedTimes || 0,
                comandosUsados: foundUser.ComandosEjecutados || 0,
                rankingGlobal: {
                    posicion: globalPos > 0 ? globalPos : null,
                    total: globalTotal
                },
                pareja: parejaInfo
            });

        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /userprofile/update ─────────────────────────────────────────────
    // Actualiza el apodo de un usuario autenticado desde la web oficial
    // Seguridad: solo acepta peticiones desde los dominios oficiales
    app.post('/userprofile/update', express.json(), (req, res) => {
        try {
            // ── Validación de origen ──────────────────────────────────────────
            // Cuando el request viene de Vercel (server-to-server), el origen real
            // se reenvía en el header x-real-origin. Si no existe, se usa origin/referer.
            const allowedOrigins = [
                'https://roblebotpage.vercel.app',
                'https://robleuy.vercel.app',
                'https://robleuy.site',
            ];

            const origin  = (req.headers['x-real-origin'] || req.headers['origin'] || '').trim();
            const referer = (req.headers['x-real-referer'] || req.headers['referer'] || '').trim();

            const isAllowed = allowedOrigins.some(o =>
                origin === o ||
                origin.endsWith('.robleuy.site') ||
                referer.startsWith(o) ||
                referer.includes('.robleuy.site')
            );

            if (!isAllowed) {
                return res.status(403).json({ error: 'Origen no autorizado' });
            }

            // ── Validación de parámetros ──────────────────────────────────────
            const { userId, newApodo } = req.body || {};

            if (!userId || !newApodo) {
                return res.status(400).json({ error: 'Faltan parámetros userId o newApodo' });
            }

            // Solo letras, números y guiones bajos. 3–20 caracteres.
            if (!/^[a-zA-Z0-9_]{3,20}$/.test(newApodo)) {
                return res.status(400).json({ error: 'Apodo inválido. Solo letras, números y _ (3-20 caracteres).' });
            }

            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const userData = global.db.data.users[userId];
            if (!userData) {
                return res.status(404).json({ error: 'Usuario no encontrado' });
            }

            // Verificar que no sea el mismo apodo actual (case-insensitive)
            if ((userData.apodo || '').toLowerCase() === newApodo.toLowerCase()) {
                return res.status(400).json({ error: `Ese ya es tu apodo actual: ${userData.apodo}` });
            }

            // Verificar que el apodo no esté en uso por otro usuario
            const apodoTaken = Object.entries(global.db.data.users).some(
                ([num, u]) => num !== userId && u?.apodo && u.apodo.toLowerCase() === newApodo.toLowerCase()
            );
            if (apodoTaken) {
                return res.status(409).json({ error: 'Ese apodo ya está en uso' });
            }

            // ── Aplicar cambio ────────────────────────────────────────────────
            const oldApodo = userData.apodo || '';
            global.db.data.users[userId].apodo = newApodo;
            global.db.save(); // síncrono con debounce — no retorna Promise

            console.log(`[userprofile/update] ${userId}: apodo cambiado de "${oldApodo}" a "${newApodo}"`);

            return res.json({ success: true, apodo: newApodo });

        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/qr ──────────────────────────────────────────────────────
    app.get('/subbots/qr', async (req, res) => {
        // Usar bot principal si está disponible, sino el primer subbot activo, sino null
        // (los subbots pueden conectarse sin bot principal disponible)
        const connToUse = global.conn?.user
            ? global.conn
            : (global.subConns || []).find(c => c?.user) || null;

        const num = getNextNum();

        // Verificar si ya hay un QR pendiente para este num
        if (pendingWebQR.has(num)) {
            return res.status(429).json({ error: `Ya hay un QR pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el QR
        let resolveQR, rejectQR;
        const qrPromise = new Promise((res, rej) => { resolveQR = res; rejectQR = rej; });

        const timeout = setTimeout(() => {
            pendingWebQR.delete(num);
            rejectQR(new Error('Timeout esperando QR'));
        }, 30000);

        pendingWebQR.set(num, { resolve: resolveQR, reject: rejectQR, timeout });

        try {
            // Conectar subbot con ownerJid null (web) — el QR llegará via resolveWebQR
            const { connectSubBotWeb } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWeb({ num, conn: connToUse });

            const qrDataUrl = await qrPromise;

            // Convertir data URL a buffer PNG y enviar
            const base64 = qrDataUrl.replace(/^data:image\/png;base64,/, '');
            const imgBuf = Buffer.from(base64, 'base64');

            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'no-store');
            res.send(imgBuf);
        } catch (e) {
            pendingWebQR.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/code ────────────────────────────────────────────────────
    app.get('/subbots/code', async (req, res) => {
        // Usar bot principal si está disponible, sino el primer subbot activo, sino null
        // (los subbots pueden conectarse sin bot principal disponible)
        const connToUse = global.conn?.user
            ? global.conn
            : (global.subConns || []).find(c => c?.user) || null;

        const rawPhone = (req.query.phone || req.query.number || '').trim();
        if (!rawPhone) {
            return res.status(400).json({ error: 'Parámetro "phone" requerido. Ejemplo: /subbots/code?phone=59893900470' });
        }

        // Limpiar igual que el comando .serbot code: quitar +, espacios, guiones, etc.
        const cleanNumber = rawPhone.replace(/[^0-9]/g, '');
        if (cleanNumber.length < 7 || cleanNumber.length > 15) {
            return res.status(400).json({ error: 'Número inválido. Usa formato internacional, ej: 59893900470' });
        }

        const num = getNextNum();

        // Verificar si ya hay un código pendiente para este num
        if (pendingWebCode.has(num)) {
            return res.status(429).json({ error: `Ya hay un código pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el código
        let resolveCode, rejectCode;
        const codePromise = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });

        const timeout = setTimeout(() => {
            pendingWebCode.delete(num);
            rejectCode(new Error('Timeout esperando código de emparejamiento'));
        }, 60000); // 60 segundos para el código

        pendingWebCode.set(num, { resolve: resolveCode, reject: rejectCode, timeout });

        try {
            // Conectar subbot con método de código
            const { connectSubBotWebWithCode } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWebWithCode({ num, conn: connToUse, phoneNumber: cleanNumber });

            const pairingCode = await codePromise;

            res.json({
                success:      true,
                subbotNumber: num,
                phoneNumber:  cleanNumber,
                pairingCode:  pairingCode,
                message:      'Ingresa este código en WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono'
            });
        } catch (e) {
            pendingWebCode.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── POST /webauth/request ───────────────────────────────────────────────
    // Genera un código de 4 dígitos para login web
    app.post('/webauth/request', express.json(), (req, res) => {
        try {
            const apodo = (req.query.apodo || req.body?.apodo || '').trim();
            if (!apodo) {
                return res.status(400).json({ error: 'Falta parámetro apodo' });
            }

            // Generar código numérico de 4 dígitos
            let code = Math.floor(1000 + Math.random() * 9000).toString();
            
            // Asegurar que no exista ya (improbable pero posible)
            while(pendingWebAuth.has(code)) {
                code = Math.floor(1000 + Math.random() * 9000).toString();
            }

            // Guardar con TTL de 5 minutos
            pendingWebAuth.set(code, {
                apodo: apodo.toLowerCase(),
                status: 'pending',
                createdAt: Date.now()
            });

            // Limpiar códigos expirados
            for (const [key, val] of pendingWebAuth.entries()) {
                if (Date.now() - val.createdAt > 5 * 60 * 1000) {
                    pendingWebAuth.delete(key);
                }
            }

            return res.json({ success: true, code: code, apodo: apodo });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── POST /webauth/verify ────────────────────────────────────────────────
    // Llamado desde el bot cuando el usuario usa .webcode
    app.post('/webauth/verify', express.json(), (req, res) => {
        try {
            const apodo = (req.query.apodo || req.body?.apodo || '').trim();
            const code = (req.query.code || req.body?.code || '').trim();
            const userId = req.body?.userId || req.query.userId;

            if (!apodo || !code) {
                return res.status(400).json({ error: 'Faltan parámetros apodo o code' });
            }

            const authReq = pendingWebAuth.get(code);
            
            if (!authReq) {
                return res.status(404).json({ error: 'Código inválido o expirado' });
            }

            if (authReq.apodo !== apodo.toLowerCase()) {
                return res.status(403).json({ error: 'El apodo no coincide con la solicitud original' });
            }

            // Marcar como verificado y guardar userId
            authReq.status = 'verified';
            authReq.userId = userId;
            pendingWebAuth.set(code, authReq);

            return res.json({ success: true, message: 'Sesión verificada' });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /webauth/status ─────────────────────────────────────────────────
    // Usado por la web (polling) para saber si ya se verificó
    app.get('/webauth/status', (req, res) => {
        try {
            const code = (req.query.code || '').trim();
            if (!code) {
                return res.status(400).json({ error: 'Falta código' });
            }

            const authReq = pendingWebAuth.get(code);
            if (!authReq) {
                return res.status(404).json({ error: 'Código no encontrado o expirado' });
            }

            return res.json({ 
                success: true, 
                status: authReq.status,
                apodo: authReq.apodo,
                userId: authReq.userId
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    app.listen(port, () => {
        console.log(`[SubBotServer] HTTP en puerto ${port} → /subbots/qr | /subbots/code | /subbots/list | /topdinero | /funciones | /stats | /userprofile | /webauth`);
    });

    return { resolveWebQR, resolveWebCode };
}

module.exports = { startSubBotServer, resolveWebQR, resolveWebCode };