'use strict';
/**
 * Servidor HTTP para gestión de sub-bots
 *
 * GET /subbots/qr                    → Genera QR para nuevo sub-bot (imagen PNG)
 * GET /subbots/code?phone=XXXXXXXXXX → Genera código de emparejamiento de 8 dígitos (JSON)
 * GET /subbots/list                  → Lista de sub-bots activos (JSON)
 */

const express = require('express');
const qrcode  = require('qrcode');
const fs      = require('fs');
const path    = require('path');
const { loadStats } = require('./botStatsRecorder');
const achievements = require('./achievements');

// Map de QRs pendientes por num: { resolve, reject, timeout }
const pendingWebQR = new Map();

// Map de códigos de emparejamiento pendientes por num: { resolve, reject, timeout }
const pendingWebCode = new Map();

// Caché para el endpoint /stats — evita llamadas repetidas a groupFetchAllParticipating
// que es muy pesada y puede causar errores 403 si se llama seguido
const _statsCache = { data: null, ts: 0 };
const STATS_CACHE_TTL = 5 * 60 * 1000; // 5 minutos

// Usa nextSubBotNumber del módulo principal para evitar conflictos de numeración
function getNextNum() {
    const { nextSubBotNumber } = require('./plugins/SUBBOTS/subbot-serbot');
    return nextSubBotNumber();
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un QR
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebQR(num, qrDataUrl) {
    const pending = pendingWebQR.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebQR.delete(num);
        pending.resolve(qrDataUrl);
    }
}

/**
 * Llamado desde subbot-serbot.js cuando un subbot genera un código de emparejamiento
 * para que el endpoint web lo pueda entregar.
 */
function resolveWebCode(num, code) {
    const pending = pendingWebCode.get(num);
    if (pending) {
        clearTimeout(pending.timeout);
        pendingWebCode.delete(num);
        if (code === null) {
            pending.reject(new Error('Error generando código de emparejamiento'));
        } else {
            pending.resolve(code);
        }
    }
}

function startSubBotServer(port = 3000) {
    const app = express();

    // Permitir JSON en bodies POST
    app.use(express.json());
    // CORS — permite acceso desde cualquier origen (incluyendo páginas HTTPS)
    app.use((req, res, next) => {
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        if (req.method === 'OPTIONS') return res.sendStatus(204);
        next();
    });

    // ── Middleware para manejar rutas con ?action= ──────────────────────────
    // Reescribe /api/roblebot?action=X a /X para compatibilidad
    app.use((req, res, next) => {
        const action = req.query.action;
        if (action) {
            req.url = `/${action}${req.url.includes('&') ? '?' + req.url.split('&').slice(1).join('&') : ''}`;
            delete req.query.action;
        }
        next();
    });

    // ── GET /subbots/info ────────────────────────────────────────────────────
    app.get('/subbots/info', (req, res) => {
        const mainNum = global.mainBotNumber || null;
        res.json({
            mainBot: mainNum ? { number: mainNum, link: `wa.me/+${mainNum}` } : null,
            group:   'https://chat.whatsapp.com/HaDX5l2tQCz9KJ7lyw7VHv',
            channel: 'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',
        });
    });

    // ── GET /subbots/list ────────────────────────────────────────────────────
    app.get('/subbots/list', (req, res) => {
        const active = (global.subConns || [])
            .filter(c => c.user)
            .sort((a, b) => a._subNum - b._subNum)
            .map(c => ({
                num:    c._subNum,
                number: c.user.id.split('@')[0].split(':')[0],
                link:   `wa.me/+${c.user.id.split('@')[0].split(':')[0]}`,
                uptime: c.uptime ? Date.now() - c.uptime : null,
            }));

        res.json({ total: active.length, subbots: active });
    });

    // ── GET /topdinero ───────────────────────────────────────────────────────
    // Top global de dinero: apodo, posición, dinero (money+bank)
    // Params:
    // - apodo: busca jugador por apodo exacto (case-insensitive)
    // - position: devuelve jugador en posición exacta
    // - page: devuelve 10 jugadores de la página solicitada
    app.get('/topdinero', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const rows = [];
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (!userData) continue;
                const totalMoney = (userData.money || 0) + (userData.bank || 0);
                if (totalMoney <= 0) continue;

                const apodoRaw = (userData.apodo || '').trim();
                const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo')
                    ? 'Sin Apodo'
                    : apodoRaw;

                rows.push({ apodo, dinero: totalMoney });
            }

            rows.sort((a, b) => b.dinero - a.dinero);
            const top = rows.map((u, i) => ({
                posicion: i + 1,
                apodo: u.apodo,
                dinero: u.dinero
            }));

            const apodoQuery = (req.query.apodo || '').toString().trim();
            const positionQuery = req.query.position ? parseInt(req.query.position, 10) : NaN;
            const pageQuery = req.query.page ? parseInt(req.query.page, 10) : NaN;

            if (apodoQuery) {
                const found = top.find(u => u.apodo.toLowerCase() === apodoQuery.toLowerCase());
                if (!found) {
                    return res.status(404).json({
                        error: `No se encontró el jugador con apodo '${apodoQuery}'`,
                        query: { apodo: apodoQuery }
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { apodo: apodoQuery },
                    resultado: found
                });
            }

            if (!Number.isNaN(positionQuery)) {
                if (positionQuery < 1 || positionQuery > top.length) {
                    return res.status(404).json({
                        error: `No existe un jugador en la posición ${positionQuery}`,
                        query: { position: positionQuery },
                        totalRankeados: top.length
                    });
                }
                return res.json({
                    totalRankeados: top.length,
                    query: { position: positionQuery },
                    resultado: top[positionQuery - 1]
                });
            }

            if (!Number.isNaN(pageQuery)) {
                if (pageQuery < 1) {
                    return res.status(400).json({
                        error: 'El parámetro page debe ser un número entero mayor o igual a 1',
                        query: { page: pageQuery }
                    });
                }
                const pageSize = 10;
                const start = (pageQuery - 1) * pageSize;
                const pageItems = top.slice(start, start + pageSize);
                return res.json({
                    totalRankeados: top.length,
                    page: pageQuery,
                    pageSize,
                    resultados: pageItems
                });
            }

            return res.json({
                totalRankeados: top.length,
                top
            });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /funciones ───────────────────────────────────────────────────────
    // Cantidad total de plugins (.js) dentro de /plugins (recursivo)
    app.get('/funciones', (req, res) => {
        try {
            const pluginsDir = path.join(__dirname, 'plugins');
            if (!fs.existsSync(pluginsDir)) {
                return res.status(500).json({ error: 'No existe la carpeta plugins' });
            }

            const countJsRecursive = (dir) => {
                let count = 0;
                const items = fs.readdirSync(dir, { withFileTypes: true });
                for (const it of items) {
                    const full = path.join(dir, it.name);
                    if (it.isDirectory()) count += countJsRecursive(full);
                    else if (it.isFile() && it.name.toLowerCase().endsWith('.js')) count++;
                }
                return count;
            };

            const totalPlugins = countJsRecursive(pluginsDir);
            return res.json({ pluginsJs: totalPlugins });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /menu.txt ─────────────────────────────────────────────────────────
    app.get('/menu.txt', (req, res) => {
        try {
            const menuPath = path.join(__dirname, 'menu.txt');
            if (!fs.existsSync(menuPath)) {
                return res.status(404).json({ error: 'menu.txt no encontrado' });
            }
            const content = fs.readFileSync(menuPath, 'utf8');
            res.set('Content-Type', 'text/plain; charset=utf-8');
            return res.send(content);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

        // Servir archivos estáticos de la interfaz web (carpeta /web)
        app.use('/web', express.static(path.join(__dirname, 'web')));
        app.use(express.static(path.join(__dirname, 'web')));

        // Mapa global para códigos de login (creado por el plugin .login)
        if (!global.pendingLoginCodes) global.pendingLoginCodes = new Map();
        if (!global.webSessions) global.webSessions = new Map();
        if (!global.webActionCooldowns) global.webActionCooldowns = new Map();

        // Helper para obtener número desde token de sesión
        function getNumberFromToken(token) {
            if (!token) return null;
            const entry = global.webSessions.get(token);
            if (!entry) return null;
            if (entry.expiresAt && Date.now() > entry.expiresAt) {
                global.webSessions.delete(token);
                return null;
            }
            return entry.number;
        }

        // Página de login (HTML)
        app.get('/login', (req, res) => {
            const file = path.join(__dirname, 'web', 'login.html');
            if (!fs.existsSync(file)) return res.status(404).send('Login page not found');
            res.sendFile(file);
        });

        // API: POST /api/login { code }
        app.post('/api/login', (req, res) => {
            const code = (req.body.code || '').toString().trim();
            if (!code) return res.status(400).json({ error: 'Código requerido' });
            const pending = global.pendingLoginCodes.get(code);
            if (!pending) return res.status(404).json({ error: 'Código no encontrado o expirado' });
            // Crear sesión web corta
            const token = Math.random().toString(36).slice(2, 12) + Math.random().toString(36).slice(2, 12);
            const number = pending.jid || pending.number;
            global.webSessions.set(token, { number: number.toString(), expiresAt: Date.now() + (30 * 60 * 1000) }); // 30 min
            // Eliminar código pendiente
            try { clearTimeout(pending.timeout); } catch {};
            global.pendingLoginCodes.delete(code);
            return res.json({ success: true, token });
        });

        // Middleware de cooldown global (5s entre acciones por usuario)
        function checkGlobalCooldown(number) {
            const last = global.webActionCooldowns.get(number) || 0;
            const now = Date.now();
            if (now - last < 5000) return Math.ceil((5000 - (now - last)) / 1000);
            global.webActionCooldowns.set(number, now);
            return 0;
        }

        // API: obtener perfil (GET /api/profile?token=...)
        app.get('/api/profile', async (req, res) => {
            try {
                const token = req.query.token || req.headers['x-session'];
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                const user = global.db.getUser(number);
                if (!user) return res.status(404).json({ error: 'Usuario no registrado' });
                // Formatear respuesta similar a /userprofile
                const profile = {
                    apodo: user.apodo || 'Sin apodo',
                    dinero: user.money || 0,
                    banco: user.bank || 0,
                    total: (user.money || 0) + (user.bank || 0),
                    respeto: user.respeto || 0,
                    nivel: user.level || 0,
                    lastDaily: user.lastDaily || 0,
                    lastWork: user.lastWork || 0
                };
                return res.json({ success: true, profile });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // API: cambiar apodo (POST /api/change-apodo { token, apodo })
        app.post('/api/change-apodo', (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const apodo = (req.body.apodo || '').toString().trim();
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                if (!apodo) return res.status(400).json({ error: 'Apodo requerido' });
                // Global cooldown
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                // Validaciones (mismas que plugin apodos)
                if (apodo.length > 30) return res.status(400).json({ error: 'Apodo demasiado largo (máx 30)' });
                if (/\s/.test(apodo)) return res.status(400).json({ error: 'El apodo no puede contener espacios' });
                // Unicidad
                for (const [id, u] of Object.entries(global.db.data.users || {})) {
                    if (id === number) continue;
                    if (u && u.apodo && u.apodo.toLowerCase && u.apodo.toLowerCase() === apodo.toLowerCase() && u.apodo !== 'sin apodo') {
                        return res.status(409).json({ error: 'Apodo ya en uso' });
                    }
                }
                const user = global.db.getUser(number);
                user.apodo = apodo;
                global.db.setUser(number, user);
                return res.json({ success: true, apodo });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // Helper: construir mensaje simulado para plugins
        function makeMockMessage(number, text = '', mentions = []) {
            const jid = `${number}@s.whatsapp.net`;
            return {
                from: jid,
                author: jid,
                key: { remoteJid: jid, participant: jid },
                mentions: mentions.map(m => `${m}@s.whatsapp.net`),
                reply: async (msg, opts) => {
                    return msg;
                }
            };
        }

        // API: reclamar diaria (POST /api/daily { token })
        app.post('/api/daily', async (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                const cadadia = require('./plugins/ECONOMIA/cadadia');
                const msg = makeMockMessage(number);
                const result = await cadadia(msg);
                return res.json({ success: true, result });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // API: trabajar (POST /api/work { token })
        app.post('/api/work', async (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                const workHandler = require('./plugins/ECONOMIA/trabajar');
                const msg = makeMockMessage(number);
                const result = await workHandler(msg, { text: '' });
                return res.json({ success: true, result });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // API: apostar (POST /api/bet { token, amount })
        app.post('/api/bet', async (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const amount = (req.body.amount || '').toString().trim();
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                if (!amount) return res.status(400).json({ error: 'Cantidad requerida' });
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                const apostar = require('./plugins/CASINO/apostar');
                const msg = makeMockMessage(number);
                const result = await apostar(msg, { text: amount });
                return res.json({ success: true, result });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // API: depositar (POST /api/deposit { token, amount })
        app.post('/api/deposit', async (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const amount = (req.body.amount || '').toString().trim();
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                const banco = require('./plugins/ECONOMIA/banco');
                const msg = makeMockMessage(number);
                // Simular body del comando .depositar
                msg.body = '.depositar ' + amount;
                const result = await banco(msg, { text: amount });
                return res.json({ success: true, result });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // API: retirar (POST /api/withdraw { token, amount })
        app.post('/api/withdraw', async (req, res) => {
            try {
                const token = req.body.token || req.headers['x-session'];
                const amount = (req.body.amount || '').toString().trim();
                const number = getNumberFromToken(token);
                if (!number) return res.status(401).json({ error: 'Token inválido' });
                const wait = checkGlobalCooldown(number);
                if (wait) return res.status(429).json({ error: `Cooldown activo: espera ${wait}s` });
                const banco = require('./plugins/ECONOMIA/banco');
                const msg = makeMockMessage(number);
                msg.body = '.retirar ' + amount;
                const result = await banco(msg, { text: amount });
                return res.json({ success: true, result });
            } catch (e) {
                return res.status(500).json({ error: e.message });
            }
        });

        // Página principal de la app (dashboard)
        app.get('/app', (req, res) => {
            const file = path.join(__dirname, 'web', 'app.html');
            if (!fs.existsSync(file)) return res.status(404).send('App not found');
            res.sendFile(file);
        });

        app.get('/app.html', (req, res) => res.redirect(302, '/app'));
        app.get('/login.html', (req, res) => res.redirect(302, '/login'));
        app.get('/', (req, res) => res.redirect(302, '/login'));

    // ── GET /stats ───────────────────────────────────────────────────────────
    // Devuelve stats tipo plugin stats (resumen en JSON)
    app.get('/stats', async (req, res) => {
        try {
            // Servir desde caché si está fresca (evita groupFetchAllParticipating en cada request)
            if (_statsCache.data && Date.now() - _statsCache.ts < STATS_CACHE_TTL) {
                return res.json(_statsCache.data);
            }

            const stats = loadStats();
            const totalCommands = stats.totalCommandsExecuted || stats.totalCommands || 0;
            const totalUsers = global.db?.data?.users ? Object.keys(global.db.data.users).length : 0;

            // Map<jid, participantCount> para deduplicar grupos compartidos entre bots
            const uniqueGroupsMap = new Map();

            // Grupos/participantes del bot principal
            let mainGroups = 0;
            let mainParticipants = 0;
            try {
                const socket = global.conn;
                if (socket?.groupFetchAllParticipating) {
                    const chats = await socket.groupFetchAllParticipating();
                    const groupEntries = Object.values(chats).filter(g =>
                        g.id.endsWith('@g.us') && !g.id.includes('@newsletter') && g.announce !== true
                    );
                    mainGroups = groupEntries.length;
                    mainParticipants = groupEntries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
                    for (const g of groupEntries) {
                        uniqueGroupsMap.set(g.id, g.participants?.length || 0);
                    }
                }
            } catch {}

            // Subbots activos + grupos/participantes
            const activeSubbots = (global.subConns || []).filter(c => c.user);
            const subbotsCount = activeSubbots.length;
            let subbotsGroups = 0;
            let subbotsParticipants = 0;

            for (const subbot of activeSubbots) {
                try {
                    const chats = await subbot.groupFetchAllParticipating();
                    const groupEntries = Object.values(chats).filter(g =>
                        g.id.endsWith('@g.us') && !g.id.includes('@newsletter') && g.announce !== true
                    );
                    subbotsGroups += groupEntries.length;
                    subbotsParticipants += groupEntries.reduce((sum, g) => sum + (g.participants?.length || 0), 0);
                    for (const g of groupEntries) {
                        if (!uniqueGroupsMap.has(g.id)) {
                            uniqueGroupsMap.set(g.id, g.participants?.length || 0);
                        }
                    }
                } catch {}
            }

            // Totales deduplicados
            const totalGroups = uniqueGroupsMap.size;
            const totalParticipants = [...uniqueGroupsMap.values()].reduce((sum, n) => sum + n, 0);

            const result = {
                totalCommands,
                totalCommandsExecuted: totalCommands,
                availableCommands: stats.availableCommands || 0,
                loadedPlugins: stats.loadedPlugins || 0,
                totalUsers,
                bots: { main: 1, subbots: subbotsCount },
                groups: {
                    main: mainGroups,
                    subbots: subbotsGroups,
                    total: totalGroups
                },
                participants: {
                    main: mainParticipants,
                    subbots: subbotsParticipants,
                    total: totalParticipants
                }
            };

            // Guardar en caché
            _statsCache.data = result;
            _statsCache.ts = Date.now();

            return res.json(result);
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /userprofile ─────────────────────────────────────────────────────
    // Devuelve el perfil completo de un usuario por apodo
    // Params: apodo (requerido)
    app.get('/userprofile', (req, res) => {
        try {
            if (!global.db?.data?.users) {
                return res.status(503).json({ error: 'Base de datos no disponible' });
            }

            const apodoQuery = (req.query.apodo || '').trim();
            if (!apodoQuery) {
                return res.status(400).json({ error: 'Parámetro "apodo" requerido' });
            }

            // Función para normalizar texto
            const normalizeText = (text) => {
                if (!text) return '';
                return text
                    .trim()
                    .toLowerCase()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .replace(/\s+/g, ' ');
            };

            // Level calculation handled by achievements module

            // Buscar usuario por apodo
            const normalizedApodo = normalizeText(apodoQuery);
            let foundUser = null;
            let foundNumber = null;

            // Primera pasada: búsqueda exacta
            for (let [number, userData] of Object.entries(global.db.data.users)) {
                if (userData?.apodo && userData.apodo.trim() !== '') {
                    const normalizedUserApodo = normalizeText(userData.apodo);
                    if (normalizedUserApodo === normalizedApodo) {
                        foundUser = userData;
                        foundNumber = number;
                        break;
                    }
                }
            }

            // Segunda pasada: búsqueda parcial
            if (!foundUser) {
                for (let [number, userData] of Object.entries(global.db.data.users)) {
                    if (userData?.apodo && userData.apodo.trim() !== '') {
                        const normalizedUserApodo = normalizeText(userData.apodo);
                        if (normalizedUserApodo.includes(normalizedApodo) || normalizedApodo.includes(normalizedUserApodo)) {
                            foundUser = userData;
                            foundNumber = number;
                            break;
                        }
                    }
                }
            }

            if (!foundUser) {
                return res.status(404).json({ error: `No se encontró ningún usuario con el apodo "${apodoQuery}"` });
            }

            // Calcular datos del perfil
            const levelInfo = achievements.calculateLevel(foundUser.exp || 0);
            const totalMoney = (foundUser.money || 0) + (foundUser.bank || 0);
            const apodo = (foundUser.apodo && foundUser.apodo.trim() !== '') ? foundUser.apodo : 'Sin apodo';
            const respeto = foundUser.respeto || 0;
            const rango = foundUser.rango || '🌱 Novato';
            const genero = foundUser.genero || 'No definido';
            const deuda = (foundUser.prestamo?.activo && foundUser.prestamo?.deuda > 0) ? foundUser.prestamo.deuda : 0;

            // Calcular ranking global
            const globalRanking = Object.entries(global.db.data.users)
                .map(([num, u]) => ({ num, total: (u.money || 0) + (u.bank || 0) }))
                .filter(u => u.total > 0)
                .sort((a, b) => b.total - a.total);
            const globalPos = globalRanking.findIndex(u => u.num === foundNumber) + 1;
            const globalTotal = globalRanking.length;
            // Información de pareja (estado civil)
            function tiempoTranscurrido(fecha) {
                const ahora = new Date();
                const inicio = new Date(fecha);
                const diferencia = ahora - inicio;
                const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
                const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
                return { dias, horas, minutos };
            }

            let parejaInfo = { estado: 'soltero' };
            try {
                const pareja = global.db.getPareja(foundNumber);
                if (pareja) {
                    const partnerUser = global.db.getUser(pareja.numero) || {};
                    const partnerApodo = partnerUser.apodo || 'Desconocido';
                    if (pareja.estado === 'aceptado') {
                        parejaInfo = {
                            estado: 'casado',
                            apodo: partnerApodo,
                            fecha: pareja.fecha,
                            tiempo: tiempoTranscurrido(pareja.fecha)
                        };
                    } else {
                        parejaInfo = {
                            estado: pareja.estado || 'pendiente',
                            apodo: partnerApodo,
                            fecha: pareja.fecha
                        };
                    }
                }
            } catch (_) {}

            return res.json({
                apodo,
                genero,
                nivel: {
                    level: levelInfo.level,
                    xpActual: levelInfo.xpActual,
                    xpTotal: levelInfo.xpTotal,
                    xpFaltante: levelInfo.xpFaltante
                },
                economia: {
                    dinero: foundUser.money || 0,
                    banco: foundUser.bank || 0,
                    total: totalMoney,
                    deuda
                },
                respeto,
                rango,
                vecesTrabajadas: foundUser.totalWorkedTimes || 0,
                comandosUsados: foundUser.ComandosEjecutados || 0,
                rankingGlobal: {
                    posicion: globalPos > 0 ? globalPos : null,
                    total: globalTotal
                },
                pareja: parejaInfo
            });

        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/qr ──────────────────────────────────────────────────────
    app.get('/subbots/qr', async (req, res) => {
        if (!global.conn?.user) {
            return res.status(503).json({ error: 'Bot principal no conectado' });
        }

        const num = getNextNum();

        // Reservar el número creando la carpeta inmediatamente para evitar race conditions
        const sessDir = path.join(__dirname, 'plugins/SUBBOTS/sesiones', String(num));
        fs.mkdirSync(sessDir, { recursive: true });

        // Verificar si ya hay un QR pendiente para este num
        if (pendingWebQR.has(num)) {
            return res.status(429).json({ error: `Ya hay un QR pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el QR
        let resolveQR, rejectQR;
        const qrPromise = new Promise((res, rej) => { resolveQR = res; rejectQR = rej; });

        const timeout = setTimeout(() => {
            pendingWebQR.delete(num);
            rejectQR(new Error('Timeout esperando QR'));
        }, 30000);

        pendingWebQR.set(num, { resolve: resolveQR, reject: rejectQR, timeout });

        try {
            // Conectar subbot con ownerJid null (web) — el QR llegará via resolveWebQR
            const { connectSubBotWeb } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWeb({ num, conn: global.conn });

            const qrDataUrl = await qrPromise;

            // Convertir data URL a buffer PNG y enviar
            const base64 = qrDataUrl.replace(/^data:image\/png;base64,/, '');
            const imgBuf = Buffer.from(base64, 'base64');

            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'no-store');
            res.send(imgBuf);
        } catch (e) {
            pendingWebQR.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    // ── GET /subbots/code ────────────────────────────────────────────────────
    app.get('/subbots/code', async (req, res) => {
        if (!global.conn?.user) {
            return res.status(503).json({ error: 'Bot principal no conectado' });
        }

        const rawPhone = (req.query.phone || req.query.number || '').trim();
        if (!rawPhone) {
            return res.status(400).json({ error: 'Parámetro "phone" requerido. Ejemplo: /subbots/code?phone=59893900470' });
        }

        // Limpiar igual que el comando .serbot code: quitar +, espacios, guiones, etc.
        const cleanNumber = rawPhone.replace(/[^0-9]/g, '');
        if (cleanNumber.length < 7 || cleanNumber.length > 15) {
            return res.status(400).json({ error: 'Número inválido. Usa formato internacional, ej: 59893900470' });
        }

        const num = getNextNum();

        // Reservar el número creando la carpeta inmediatamente para evitar race conditions
        const sessDir = path.join(__dirname, 'plugins/SUBBOTS/sesiones', String(num));
        fs.mkdirSync(sessDir, { recursive: true });

        // Verificar si ya hay un código pendiente para este num
        if (pendingWebCode.has(num)) {
            return res.status(429).json({ error: `Ya hay un código pendiente para el sub-bot #${num}` });
        }

        // Pedir al módulo de subbots que conecte y esperar el código
        let resolveCode, rejectCode;
        const codePromise = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });

        const timeout = setTimeout(() => {
            pendingWebCode.delete(num);
            rejectCode(new Error('Timeout esperando código de emparejamiento'));
        }, 60000); // 60 segundos para el código

        pendingWebCode.set(num, { resolve: resolveCode, reject: rejectCode, timeout });

        try {
            // Conectar subbot con método de código
            const { connectSubBotWebWithCode } = require('./plugins/SUBBOTS/subbot-serbot');
            connectSubBotWebWithCode({ num, conn: global.conn, phoneNumber: cleanNumber });

            const pairingCode = await codePromise;

            res.json({
                success:      true,
                subbotNumber: num,
                phoneNumber:  cleanNumber,
                pairingCode:  pairingCode,
                message:      'Ingresa este código en WhatsApp > Dispositivos Vinculados > Vincular un dispositivo > Vincular con número de teléfono'
            });
        } catch (e) {
            pendingWebCode.delete(num);
            res.status(500).json({ error: e.message });
        }
    });

    app.listen(port, () => {
        console.log(`[SubBotServer] HTTP en puerto ${port} → /subbots/qr | /subbots/code | /subbots/list | /topdinero | /funciones | /stats | /userprofile`);
    });

    return { resolveWebQR, resolveWebCode };
}

module.exports = { startSubBotServer, resolveWebQR, resolveWebCode };