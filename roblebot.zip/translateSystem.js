const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data/idiomas-usuarios.json');
let iaModule = null;

// Cargar el módulo de IA con lazy loading
function getIAModule() {
    if (!iaModule) {
        try {
            iaModule = require('./plugins/HERRAMIENTAS/ia/ia.js');
        } catch (e) {
            console.error('[translateSystem] Error cargando módulo IA:', e);
        }
    }
    return iaModule;
}

// Cargar configuración de idiomas
function loadLanguageConfig() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('[translateSystem] Error cargando config:', e);
    }
    return {};
}

// Obtener idioma configurado para un usuario
function getLanguage(userId) {
    const config = loadLanguageConfig();
    // Usar la misma lógica de limpieza que handler.js
    const cleanId = userId?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '') || userId;
    return config[cleanId] || 'español';
}

// Verificar si necesita traducción
function needsTranslation(userId) {
    const lang = getLanguage(userId);
    const spanishVariants = ['español', 'espanol', 'spanish', 'es', 'esp'];
    return !spanishVariants.some(v => lang.toLowerCase().includes(v));
}

// Traducir un mensaje usando IA
async function translateMessage(text, targetLanguage) {
    if (!text || typeof text !== 'string') return text;
    
    // No traducir si es muy corto
    if (text.trim().length < 3) return text;

    const ia = getIAModule();
    if (!ia || !ia.callIA) {
        console.error('[translateSystem] Módulo IA no disponible');
        return text;
    }

    const systemPrompt = `Traduce este mensaje al idioma: ${targetLanguage}

${text}

Déjalo tal cual, solo traduce.`;

    try {
        const translated = await ia.callIA('', systemPrompt);
        return translated.trim();
    } catch (e) {
        console.error('[translateSystem] Error traduciendo:', e.message);
        return text;
    }
}

// Función principal para procesar respuestas del bot
async function processResponse(text, userId) {
    if (!text || typeof text !== 'string') return text;
    
    // Si no necesita traducción, devolver original
    if (!needsTranslation(userId)) {
        return text;
    }

    const targetLanguage = getLanguage(userId);
    
    try {
        const translated = await translateMessage(text, targetLanguage);
        // Asegurar que devuelve string válido
        return (translated && typeof translated === 'string') ? translated : text;
    } catch (e) {
        console.error('[translateSystem] Error en traducción:', e);
        return text; // En caso de error, devolver original
    }
}

module.exports = {
    getLanguage,
    needsTranslation,
    translateMessage,
    processResponse
};
