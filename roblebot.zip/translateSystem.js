const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data/idiomas-usuarios.json');
let iaModule = null;

// Cargar el módulo de IA con lazy loading
function getIAModule() {
    if (!iaModule) {
        try {
            iaModule = require('./plugins/HERRAMIENTAS/ia/ia.js');
        } catch (e) {
            console.error('[translateSystem] Error cargando módulo IA:', e);
        }
    }
    return iaModule;
}

// Cargar configuración de idiomas
function loadLanguageConfig() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('[translateSystem] Error cargando config:', e);
    }
    return {};
}

// Obtener idioma configurado para un usuario
function getLanguage(userId) {
    const config = loadLanguageConfig();
    // Usar la misma lógica de limpieza que handler.js
    const cleanId = userId?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '') || userId;
    return config[cleanId] || 'español';
}

// Verificar si necesita traducción
function needsTranslation(userId) {
    const lang = getLanguage(userId);
    const spanishVariants = ['español', 'espanol', 'spanish', 'es', 'esp'];
    return !spanishVariants.some(v => lang.toLowerCase().includes(v));
}

// Traducir un mensaje usando IA
async function translateMessage(text, targetLanguage) {
    if (!text || typeof text !== 'string') return text;
    
    // No traducir si es muy corto o solo emojis
    const cleanText = text.replace(/[^\w\s]/g, '').trim();
    if (cleanText.length < 3) return text;

    const ia = getIAModule();
    if (!ia || !ia.callIA) {
        console.error('[translateSystem] Módulo IA no disponible');
        return text;
    }

    const systemPrompt = `Eres un traductor profesional. Tu única tarea es traducir el siguiente texto al idioma: ${targetLanguage}.

REGLAS ESTRICTAS:
1. SOLO traduce el texto, NO agregues explicaciones, comentarios ni introducciones
2. Mantén el formato exacto: si hay *negritas*, _cursivas_, ~tachados~ o \`código\`, consérvalos
3. Mantén los emojis en sus posiciones originales
4. NO traduzcas: URLs, menciones (@), hashtags (#), comandos (.), nombres propios
5. Si el texto contiene formato de lista o viñetas, mantenlo
6. NO agregues "Traducción:", "Aquí está:" ni frases similares
7. Responde SOLO con el texto traducido, nada más

Si el texto contiene contenido inapropiado que no puedes traducir, responde exactamente: "_NO_TRADUCIBLE_"`;

    try {
        const translated = await ia.callIA(systemPrompt, text);
        
        // Si la IA dice que no puede traducir
        if (translated.includes('_NO_TRADUCIBLE_')) {
            return text; // Devolver original
        }
        
        return translated.trim();
    } catch (e) {
        console.error('[translateSystem] Error traduciendo:', e.message);
        // En caso de error, devolver el original
        return text;
    }
}

// Función principal para procesar respuestas del bot
async function processResponse(text, userId) {
    if (!text || typeof text !== 'string') return text;
    
    // Si no necesita traducción, devolver original
    if (!needsTranslation(userId)) {
        return text;
    }

    const targetLanguage = getLanguage(userId);
    
    try {
        const translated = await translateMessage(text, targetLanguage);
        // Asegurar que devuelve string válido
        return (translated && typeof translated === 'string') ? translated : text;
    } catch (e) {
        console.error('[translateSystem] Error en traducción:', e);
        return text; // En caso de error, devolver original
    }
}

module.exports = {
    getLanguage,
    needsTranslation,
    translateMessage,
    processResponse
};
