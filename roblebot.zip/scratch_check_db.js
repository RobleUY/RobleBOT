const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync('database.db');
try { db.exec('PRAGMA wal_checkpoint(PASSIVE)'); } catch(e){}
const rows = db.prepare('SELECT id, data FROM users').all();
console.log('Total usuarios tras checkpoint:', rows.length);
for (const r of rows) {
    try {
        const d = JSON.parse(r.data);
        console.log('ID:', r.id, '| APODO:', d.apodo, '| TOTAL:', (d.money||0)+(d.bank||0));
    } catch(e) {}
}
const aliases = db.prepare("SELECT collection, key, value FROM kv WHERE collection = 'aliases'").all();
console.log('Total Aliases:', aliases.length);
for (const a of aliases) {
    console.log('Alias:', a.key, '->', a.value);
}
process.exit(0);

