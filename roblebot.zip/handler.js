const fs = require('fs'); //asd
const path = require('path');
const chalk = require('chalk');
const { ownerNumber } = require('./config');
const { recordCommand, updateStatsMeta } = require('./botStatsRecorder');
const achievements = require('./achievements');
const botConfig = require('./config');
const premium = require('./premium');
const { getGroupMetadataCached } = require('./lib/groupCache');
const banModule = require('./plugins/baneados.js');
const botsAdminsModule = require('./plugins/SUBBOTS/subbots-admins.js');
const subbotOnOffModule = require('./plugins/SUBBOTS/subbots-onoff.js');
const translateSystem = require('./translateSystem');
const halloween = require('./lib/halloween');

// Constantes y caches globales de alto rendimiento
const COMMAND_PREFIXES = ['.', '/', '❤️', '#', '👅', '😎'];

// Ejecuta plugins con protección tanto para handlers async como sync.
// Algunos plugins devuelven undefined; no se debe asumir que siempre existe .catch().
async function runHandlersSafely(handlers, message, label) {
    const pending = [];
    for (const cmd of handlers) {
        if (typeof cmd?.handler !== 'function') continue;
        pending.push((async () => {
            try {
                // Invocar de inmediato (sin un .then() intermedio) para reducir
                // una vuelta de microtarea en la ruta de mensajes.
                await cmd.handler(message);
            } catch (error) {
                console.error(`Error ${label} (${cmd.filePath || 'unknown'}):`, error?.message || error);
            }
        })());
    }
    await Promise.allSettled(pending);
}
let staffModule = null;
try { staffModule = require('./plugins/staff'); } catch (_) { }

const _apodoCache = new Map();
const APODO_CACHE_TTL = 30000;

function invalidateApodoCache(senderNumber) {
    if (!senderNumber) return;
    const clean = String(senderNumber).replace(/[^0-9]/g, '');
    _apodoCache.delete(clean);
    if (global.db?.getCanonicalId) {
        _apodoCache.delete(global.db.getCanonicalId(clean));
    }
}
global.invalidateApodoCache = invalidateApodoCache;

function getCachedApodo(senderNumber) {
    if (!senderNumber) return '';
    const clean = String(senderNumber).replace(/[^0-9]/g, '');
    const canonical = global.db?.getCanonicalId ? (global.db.getCanonicalId(clean) || clean) : clean;

    const now = Date.now();
    const cached = _apodoCache.get(canonical) || _apodoCache.get(clean);
    if (cached && (now - cached.time < APODO_CACHE_TTL)) {
        return cached.apodo;
    }

    let apodo = '';
    try {
        const senderUser = global.db?.getUser?.(canonical) || global.db?.getUser?.(clean);
        apodo = (senderUser?.apodo || '').trim().toLowerCase();
    } catch (_) { }

    // CRÍTICO: Solo cachear si es un apodo real.
    // NUNCA cachear un apodo vacío o 'sin apodo', para que si el usuario se pone apodo
    // en el comando siguiente, se reconozca de inmediato sin esperar a que expire el TTL.
    if (apodo && apodo !== 'sin apodo') {
        _apodoCache.set(canonical, { apodo, time: now });
        _apodoCache.set(clean, { apodo, time: now });
        if (_apodoCache.size > 2000) {
            const oldestKey = _apodoCache.keys().next().value;
            if (oldestKey) _apodoCache.delete(oldestKey);
        }
    } else {
        // Asegurar que no quede ningún residuo negativo viejo
        _apodoCache.delete(canonical);
        _apodoCache.delete(clean);
    }
    return apodo;
}

let _gofcCache = null;
let _gofcCacheTime = 0;
function getGofcAllowedSubbots() {
    const now = Date.now();
    if (_gofcCache && (now - _gofcCacheTime < 10000)) {
        return _gofcCache;
    }
    try {
        const gofcPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', 'gofc-subbots.json');
        if (fs.existsSync(gofcPath)) {
            const gofcData = JSON.parse(fs.readFileSync(gofcPath, 'utf8'));
            _gofcCache = Array.isArray(gofcData.allowedSubbots) ? gofcData.allowedSubbots : [];
            _gofcCacheTime = now;
            return _gofcCache;
        }
    } catch (e) { }
    _gofcCache = [];
    _gofcCacheTime = now;
    return _gofcCache;
}

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.textReplyHandlers = [];
        this.allMessageHandlers = [];
        this.reactionHandlers = [];
        this.imageCollectors = [];
        this.regexCommands = [];
        this.lastMessageId = new Map();
        this.processingMessages = new Map();

        this.cooldowns = new Map();
        this.COOLDOWN_MS = 2000; // 2s de cooldown entre comandos por usuario (evita silencios fantasma)

        this.DUPLICATE_WINDOW = 3000;
        this.MAX_LAST_MESSAGE_IDS = 1000;
        this.PROCESSING_STALE_MS = 5 * 60 * 1000;

        // ── Invitación al canal de WhatsApp ──────────────────────────────────
        this.inviteCommandCount = new Map(); // userId → número de comandos usados
        this.inviteTarget = new Map(); // userId → meta de comandos para mostrar aviso
        // ────────────────────────────────────────────────────────────────────

        this.loadPlugins();

        this._cleanupInterval = setInterval(() => this.cleanupMemory(), 120000);
    }

    destroy() {
        if (this._cleanupInterval) {
            clearInterval(this._cleanupInterval);
            this._cleanupInterval = null;
        }
    }

    cleanupMemory() {
        const now = Date.now();

        if (this.lastMessageId.size > 0) {
            const cutoff = now - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        // No borrar todos los mensajes en curso por superar un umbral: con alta
        // concurrencia eso permitía procesar duplicados. Solo retirar tareas obsoletas.
        for (const [messageId, startedAt] of this.processingMessages.entries()) {
            if (now - startedAt > this.PROCESSING_STALE_MS) {
                this.processingMessages.delete(messageId);
            }
        }

        for (const [userId, data] of this.cooldowns.entries()) {
            if (now - data.lastCommandTime >= this.COOLDOWN_MS) {
                this.cooldowns.delete(userId);
            }
        }

        if (this.inviteCommandCount.size > 2000) {
            this.inviteCommandCount.clear();
            this.inviteTarget.clear();
        }
    }

    cleanId(id) {
        if (id === null || id === undefined) return '';
        return String(id).split('@')[0].split(':')[0].replace(/\D/g, '');
    }

    normalizeText(text) {
        return String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    getAutoPromoMessage() {
        const promos = [
            '\n\n_Sigueme en YouTube:_\nhttps://www.youtube.com/@robleuymc',
            '\n\n_Recuerda unirte a nuestro servidor de discord_\nhttps://discord.gg/CzQmqyUTZG',
            '\n\n_Recuerda unirte a nuestro canal de WhatsApp_\nhttps://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q',

            // '\n\n_¿Quieres más ventajas?_ Puedes comprar Premium o monedas:\nhttps://roblebot.vercel.app/tienda.html
        ];
        return promos[Math.floor(Math.random() * promos.length)];
    }

    async enrichText(t, ctx) {
        if (typeof t !== 'string') return t;
        let result = premium.isPremium(ctx.userId)
            ? premium.formatPremiumReply(t, ctx.userId)
            : premium.formatTopCoinsReply(t, ctx.userId);
        if (ctx.isAdminBot && ctx.staffTagEnabled && !result.includes('[RobleBOT Staff]')) {
            result += ' \n\n[RobleBOT Staff]';
        }
        if (ctx.appendFooter && ctx.footer && !result.includes('whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q') && !result.includes('roblebot.vercel.app/tienda.html')) {
            result += ctx.footer;
        }

        // ── Halloween: añadir prefijo [🎃] ──────────────────────────────────
        const hwPrefix = halloween.getHalloweenPrefix();
        if (hwPrefix) {
            // Si empieza con ★ (premium), insertar [🎃] justo después de "★ "
            if (result.startsWith('★')) {
                result = result.replace(/^(★\s*)/, `$1${hwPrefix}`);
            } else {
                result = hwPrefix + result;
            }
        }
        // ────────────────────────────────────────────────────────────────────

        if (translateSystem.needsTranslation(ctx.cleanUserId)) {
            try {
                const translated = await translateSystem.processResponse(result, ctx.cleanUserId);
                if (translated && typeof translated === 'string') {
                    result = translated;
                }
            } catch (e) {
                console.error('[Handler-Translate] Error:', e.message);
            }
        }

        return typeof result === 'string' ? result : String(result || t);
    }

    isDuplicateMessage(messageId) {
        if (this.lastMessageId.has(messageId)) return true;

        this.lastMessageId.set(messageId, Date.now());

        if (this.lastMessageId.size > this.MAX_LAST_MESSAGE_IDS) {
            const cutoff = Date.now() - this.DUPLICATE_WINDOW;
            for (const [k, v] of this.lastMessageId.entries()) {
                if (v < cutoff) this.lastMessageId.delete(k);
            }
        }

        return false;
    }

    isProcessing(messageId) {
        return this.processingMessages.has(messageId);
    }

    startProcessing(messageId) {
        // Evita crear un timer por mensaje; finishProcessing libera la entrada y
        // cleanupMemory retira únicamente trabajos que hayan quedado colgados.
        this.processingMessages.set(messageId, Date.now());
    }

    finishProcessing(messageId) {
        this.processingMessages.delete(messageId);
    }

    isGroupChat(chatId) {
        return chatId?.endsWith('@g.us');
    }

    // ── Helpers de owner ──────────────────────────────────────────────────

    /** Devuelve true si el userId es owner según config */
    isOwnerUser(userId) {
        const clean = this.cleanId(userId);
        return botConfig.isOwner(clean) || botConfig.isOwner(`${clean}@s.whatsapp.net`);
    }

    // ────────────────────────────────────────────────────────────────────────

    checkCooldown(userId) {
        const now = Date.now();
        const data = this.cooldowns.get(userId);

        if (!data) {
            this.cooldowns.set(userId, { lastCommandTime: now, lastWarnTime: 0 });
            return { onCooldown: false };
        }

        const elapsed = now - data.lastCommandTime;

        if (elapsed >= this.COOLDOWN_MS) {
            data.lastCommandTime = now;
            data.lastWarnTime = 0;
            return { onCooldown: false };
        }

        // Si está en cooldown: avisar como máximo una vez cada 2 segundos para no spamear ni quedar en silencio total
        const shouldWarn = !data.lastWarnTime || (now - data.lastWarnTime >= 2000);
        if (shouldWarn) {
            data.lastWarnTime = now;
        }

        const remaining = Math.max(1, Math.ceil((this.COOLDOWN_MS - elapsed) / 1000));
        return { onCooldown: true, shouldWarn, remaining };
    }

    registerPluginCommand(commandKey, commandData) {
        if (!commandKey || !commandData) return;

        this.commands.set(commandKey, commandData);

        if (commandKey instanceof RegExp) {
            this.regexCommands.push({ regex: commandKey, command: commandData, filePath: commandData.filePath });
        }

        if (commandData.isTextReplyHandler) {
            this.textReplyHandlers.push(commandData);
        }

        if (commandData.isAllMessageHandler) {
            this.allMessageHandlers.push(commandData);
        }

        if (commandData.isReactionHandler) {
            this.reactionHandlers.push(commandData);
        }

        if (commandData.isImageCollector) {
            this.imageCollectors.push(commandData);
        }
    }

    clearPluginCommands(filePath) {
        for (const [key, command] of [...this.commands.entries()]) {
            if (command.filePath === filePath) {
                this.commands.delete(key);
            }
        }

        this.regexCommands = this.regexCommands.filter(cmd => cmd.filePath !== filePath);
        this.textReplyHandlers = this.textReplyHandlers.filter(cmd => cmd.filePath !== filePath);
        this.allMessageHandlers = this.allMessageHandlers.filter(cmd => cmd.filePath !== filePath);
        this.reactionHandlers = this.reactionHandlers.filter(cmd => cmd.filePath !== filePath);
        this.imageCollectors = this.imageCollectors.filter(cmd => cmd.filePath !== filePath);
    }

    loadPlugin(fullPath) {
        const resolved = require.resolve(fullPath);
        if (require.cache[resolved]) {
            delete require.cache[resolved];
        }

        const plugin = require(fullPath);
        this.clearPluginCommands(fullPath);

        if (plugin.command) {
            const commandData = typeof plugin === 'function' ? {
                command: plugin.command,
                handler: plugin,
                help: plugin.help || 'Sin descripción',
                tags: plugin.tags || [],
                group: plugin.group || false,
                owner: plugin.owner || false,
                botAdmin: plugin.botAdmin === true || plugin.requiresBotAdmin === true,
                groupAdmin: plugin.groupAdmin === true,
                requiresBotAdmin: plugin.requiresBotAdmin === true,
                filePath: fullPath
            } : { ...plugin, filePath: fullPath };

            this.registerPluginCommand(plugin.command, commandData);
        }

        if (plugin.textReplyHandler) {
            this.registerPluginCommand('__textReplyHandler__' + fullPath, {
                handler: plugin.textReplyHandler,
                isTextReplyHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.allMessageHandler) {
            this.registerPluginCommand('__allMessageHandler__' + fullPath, {
                handler: plugin.allMessageHandler,
                isAllMessageHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.reactionHandler) {
            this.registerPluginCommand('__reaction__' + fullPath, {
                handler: plugin.reactionHandler,
                isReactionHandler: true,
                all: true,
                filePath: fullPath
            });
        }

        if (plugin.imageCollector) {
            this.registerPluginCommand('__imageCollector__' + fullPath, {
                handler: plugin.imageCollector,
                isImageCollector: true,
                all: true,
                filePath: fullPath
            });
        }

        for (const [key, value] of Object.entries(plugin)) {
            if (key !== 'command' && key !== 'handler' && key !== 'help' &&
                key !== 'tags' && key !== 'textReplyHandler' && key !== 'allMessageHandler' &&
                key !== 'reactionHandler' && key !== 'imageCollector' &&
                value?.command) {
                const commandData = typeof value === 'function' ? {
                    command: value.command,
                    handler: value,
                    help: value.help || [],
                    tags: value.tags || [],
                    group: value.group || false,
                    owner: value.owner || false,
                    botAdmin: value.botAdmin === true || value.requiresBotAdmin === true,
                    groupAdmin: value.groupAdmin === true,
                    requiresBotAdmin: value.requiresBotAdmin === true,
                    filePath: fullPath
                } : { ...value, filePath: fullPath };

                this.registerPluginCommand(value.command, commandData);
            }
        }
    }

    loadPluginsFromDir(dir) {
        const items = fs.readdirSync(dir);

        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
                this.loadPluginsFromDir(fullPath);
            } else if (item.endsWith('.js')) {
                try {
                    this.loadPlugin(fullPath);
                } catch (error) {
                    console.error(`Error cargando ${item}:`, error && error.stack ? error.stack : error.message);
                }
            }
        }
    }

    loadPlugins(specificFile = null) {
        if (specificFile) {
            try {
                const fullPath = path.resolve(specificFile);

                // La función loadPlugin ya maneja la limpieza del caché y comandos anteriores
                this.loadPlugin(fullPath);
                return true;
            } catch (error) {
                console.error(`Error recargando ${specificFile}:`, error.message);
                return false;
            }
        } else {
            this.commands.clear();
            this.regexCommands = [];
            this.textReplyHandlers = [];
            this.allMessageHandlers = [];
            this.reactionHandlers = [];
            this.imageCollectors = [];

            const pluginsDir = path.join(__dirname, 'plugins');
            this.loadPluginsFromDir(pluginsDir);
            return true;
        }
    }

    async handleMessage(message) {
        const messageId = message.id || message.key?.id;
        if (!messageId) return;

        // Usar _subNum del mensaje (asignado por subbot-serbot) en vez de global.conn
        // para evitar condiciones de carrera cuando múltiples subbots procesan en paralelo.
        const botId = message._subNum ? `sub${message._subNum}` : 'main';
        const chatId = message.from || message.key?.remoteJid;
        const isGroup = this.isGroupChat(chatId);
        // En grupos, deduplicar a nivel de grupo:mensaje para evitar que múltiples bots procesen en paralelo
        const dedupKey = isGroup ? `group:${chatId}:${messageId}` : `${botId}:${chatId}:${messageId}`;

        // Verificar el socket correcto: el del mensaje si es subbot, global.conn si es principal
        const activeSock = message._sock || global.conn;
        if (!activeSock || !activeSock.user) {
            console.log('⚠️ Socket no disponible, saltando mensaje');
            return;
        }

        if (this.isProcessing(dedupKey) || this.isDuplicateMessage(dedupKey)) {
            return;
        }

        this.startProcessing(dedupKey);

        try {
            const wrappedMessage = message;

            const prefixes = COMMAND_PREFIXES;
            // El mensaje crudo viaja junto al wrapper: no depender del global
            // compartido evita cruces entre mensajes/subbots concurrentes.
            const baileyMsg = message._baileyMessage || message._baileysMessage ||
                message.baileysMessage || message.rawMessage || global.lastBaileyMessage;
            const isReaction = baileyMsg?.message?.reactionMessage;

            let text = '';
            if (typeof message.body === 'string') {
                text = message.body;
            } else if (message.body?.caption) {
                text = message.body.caption;
            }

            const userId = message.author || message.sender || message.from;
            const cleanUserId = this.cleanId(userId);



            try {
                if (banModule && typeof banModule.isUserBanned === 'function') {
                    const groupId = isGroup ? chatId : null;
                    if (banModule.isUserBanned(cleanUserId, groupId)) {
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }
            } catch (banError) { }

            // ── Bypass para subbots en lista blanca del grupo oficial ───────────────
            const OFFICIAL_GROUP_ID = 'Z120363203689229697@g.us'; // Desactivado temporalmente con Z
            // Lista de grupos especiales donde TODOS los subbots funcionan siempre (incluso si están apagados)
            const SPECIAL_SUBBOT_GROUP_IDS = [
                '120363410569220249@g.us',  // Grupo especial original
                '120363203689229697@g.us'   // Grupo oficial agregado aquí
            ];
            let isAllowedSubbotInOfficial = false;
            const currentSubNum = message._subNum || activeSock._subNum || null;
            const isSpecialSubbotGroup = !!currentSubNum && SPECIAL_SUBBOT_GROUP_IDS.includes(chatId);
            if (currentSubNum && chatId === OFFICIAL_GROUP_ID) {
                const allowed = getGofcAllowedSubbots();
                isAllowedSubbotInOfficial = allowed.includes(currentSubNum);
            }

            // ── Check integrado nivel bot/subbot y grupo ─────────────────────────────
            const currentBotNum = currentSubNum || 'main';
            if (!isAllowedSubbotInOfficial && !message._groupPolicyValidated) {
                try {
                    // Check si el bot responde en privados
                    if (!isGroup && typeof subbotOnOffModule.isSubBotRespondsInPriv === 'function') {
                        if (!subbotOnOffModule.isSubBotRespondsInPriv(currentBotNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Check si el bot responde en grupos
                    if (isGroup && !isSpecialSubbotGroup && typeof subbotOnOffModule.isSubBotRespondsInGrupos === 'function') {
                        if (!subbotOnOffModule.isSubBotRespondsInGrupos(currentBotNum)) {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Estado del bot individual y del grupo
                    const subBotEnabled = isSpecialSubbotGroup
                        ? true
                        : typeof subbotOnOffModule.isSubBotEnabled === 'function'
                            ? subbotOnOffModule.isSubBotEnabled(chatId, currentBotNum)
                            : true;
                    const groupBotStatus = isGroup && typeof botsAdminsModule?.isBotEnabled === 'function'
                        ? botsAdminsModule.isBotEnabled(chatId)
                        : true;

                    // isSubBotExplicitlyEnabled: solo true si hay entrada === true en el JSON (excepción manual)
                    // Distinción necesaria entre 'default activo' y 'excepción explícita'
                    const hasExplicitSubbotException = typeof subbotOnOffModule.isSubBotExplicitlyEnabled === 'function'
                        ? subbotOnOffModule.isSubBotExplicitlyEnabled(chatId, currentBotNum)
                        : false;

                    // Grupo apagado con .bots off → bloquear SIEMPRE salvo excepción explícita (=== true) en subbot-onoff.json
                    const isOffGroup = isGroup && groupBotStatus === false && !hasExplicitSubbotException;
                    // Bot apagado individualmente con .bot off
                    const isOffBot = subBotEnabled === false;

                    if (!isSpecialSubbotGroup && (isOffBot || isOffGroup)) {
                        const prefixes = COMMAND_PREFIXES;
                        const usedPrefix = typeof text === 'string' ? prefixes.find(p => text.startsWith(p)) : null;
                        if (usedPrefix) {
                            const commandText = text.slice(usedPrefix.length).trim();
                            const [commandName] = commandText.split(' ');
                            if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                this.finishProcessing(dedupKey);
                                return;
                            }
                        } else {
                            this.finishProcessing(dedupKey);
                            return;
                        }
                    }

                    // Modo solo admins en grupo (.bots admins) salvo excepción manual subBotEnabled === true
                    if (isGroup && groupBotStatus === 'admins' && subBotEnabled !== true) {
                        try {
                            const groupMetadata = await getGroupMetadataCached(activeSock || global.conn, chatId);
                            const isAdmin = groupMetadata?.adminSet
                                ? groupMetadata.adminSet.has(cleanUserId)
                                : !!(groupMetadata?.participants?.some(p => {
                                    const pNum = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
                                    return pNum === cleanUserId && (p.admin === 'admin' || p.admin === 'superadmin');
                                }));

                            if (!isAdmin) {
                                const prefixes = COMMAND_PREFIXES;
                                const usedPrefix = typeof text === 'string' ? prefixes.find(p => text.startsWith(p)) : null;
                                if (usedPrefix) {
                                    const commandText = text.slice(usedPrefix.length).trim();
                                    const [commandName] = commandText.split(' ');
                                    if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                        this.finishProcessing(dedupKey);
                                        return;
                                    }
                                } else {
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            }
                        } catch (metadataError) {
                            console.error('[Handler-GroupAdminsCheck] Error:', metadataError.message);
                        }
                    }
                } catch (subBotError) {
                    console.error('[Handler-SubbotCheck] Error:', subBotError.message);
                }
            }

            const usedPrefix = typeof text === 'string' ? prefixes.find(p => text.startsWith(p)) : null;

            if (isReaction) {
                // Ejecutar reactionHandlers en paralelo
                await runHandlersSafely(
                    this.reactionHandlers.filter(cmd => cmd.all),
                    wrappedMessage,
                    'reaction handler'
                );
                this.finishProcessing(dedupKey);
                return;
            }

            // ── Ejecución no bloqueante de Handlers Pasivos en segundo plano ──
            const runPassiveHandlers = () => {
                setImmediate(async () => {
                    try {
                        if (this.allMessageHandlers.length > 0) {
                            await runHandlersSafely(this.allMessageHandlers, wrappedMessage, 'handler allMessage');
                        }
                        if (!usedPrefix && typeof text === 'string' && text !== '') {
                            const allHandlers = [...this.textReplyHandlers, ...this.imageCollectors];
                            if (allHandlers.length > 0) {
                                await runHandlersSafely(allHandlers, wrappedMessage, 'handler all');
                            }
                        }
                    } catch (_) { }
                });
            };

            if (!usedPrefix) {
                // Si NO es un comando con prefijo, ejecutar handlers pasivos de inmediato
                runPassiveHandlers();
                if (global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error:', error.message);
                        }
                    }
                }
                this.finishProcessing(dedupKey);
                return;
            }

            // Si ES un comando con prefijo, lanzar handlers pasivos en segundo plano
            runPassiveHandlers();

            // Bloqueo temporal durante el reinicio diario de temporada (23:58 a 00:00:20 UY)
            if (global.isSeasonResetting) {
                try {
                    await wrappedMessage.reply('⚠️ *La temporada se está reiniciando en este momento.* El bot volverá a estar disponible a las 00:00:20.');
                } catch (_) {}
                this.finishProcessing(dedupKey);
                return;
            }

            const commandText = text.slice(usedPrefix.length).trim();
            const [commandName, ...args] = commandText.split(' ');
            const fullText = args.join(' ');
            const normalizedCommandName = this.normalizeText(commandName);

            let commandExecuted = false;

            let matchedCommand = this.commands.get(normalizedCommandName);

            if (!matchedCommand) {
                for (const item of this.regexCommands) {
                    // Las regex con /g o /y conservan lastIndex; resetearlo evita
                    // que comandos válidos fallen de forma alternada.
                    item.regex.lastIndex = 0;
                    const matches = item.regex.test(commandName);
                    item.regex.lastIndex = 0;
                    if (matches) {
                        matchedCommand = item.command;
                        break;
                    }
                }
            }

            // ── Si no hay comando oficial, intentar textReplyHandlers (comandos/IAs personalizadas) ──
            if (!matchedCommand && this.textReplyHandlers.length > 0) {
                try {
                    // Ejecutar todos los textReplyHandlers en paralelo
                    await runHandlersSafely(this.textReplyHandlers, wrappedMessage, 'textReplyHandler');
                } catch (e) {
                    console.error('[Handler-TextReplyHandlers] Error:', e.message);
                }
                this.finishProcessing(dedupKey);
                return;
            }

            if (matchedCommand) {
                const command = matchedCommand;

                if (command.group === true && !isGroup) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede usarse en grupos.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                const isOwner = botConfig.isOwner(cleanUserId) ||
                    botConfig.isOwner(`${cleanUserId}@s.whatsapp.net`);

                if (command.owner && !isOwner) {
                    await wrappedMessage.reply('⚠️ Este comando solo puede ser usado por el owner del bot.');
                    this.finishProcessing(dedupKey);
                    return;
                }

                // ── Check NSFW en Sub-Bots ─────────────────────────────────────
                if (currentSubNum) {
                    const isNsfwCmd = command.nsfw === true ||
                        (Array.isArray(command.tags) && command.tags.includes('nsfw')) ||
                        (command.filePath && command.filePath.replace(/\\/g, '/').toLowerCase().includes('/nsfw/')) ||
                        /^(nsfw|xnxx|xvideos|xvsearch|xnxxsearch|pornhub|tetas|hentai|hentaiv|rule34|hotgirl|cpbroma)$/i.test(commandName);

                    if (isNsfwCmd) {
                        try {
                            if (typeof subbotOnOffModule.isSubBotNsfwEnabled === 'function') {
                                if (!subbotOnOffModule.isSubBotNsfwEnabled(currentSubNum)) {
                                    await wrappedMessage.reply('🔒 *NSFW Desactivado en este Sub-Bot*\n\nEl dueño de este sub-bot ha desactivado el contenido NSFW con *.bot nsfw off*.');
                                    this.finishProcessing(dedupKey);
                                    return;
                                }
                            }
                        } catch (e) {
                            console.error('[Handler-SubbotNSFW] Error:', e.message);
                        }
                    }
                }

                if (isGroup && !/^(apodo|nickname|alias)$/i.test(commandName)) {
                    const senderNumber = cleanUserId.replace(/[^0-9]/g, '').trim();
                    const apodo = getCachedApodo(senderNumber);
                    if (!apodo || apodo === 'sin apodo') {
                        await wrappedMessage.reply(`🚫 Debes tener un apodo para usar comandos en grupos.\n\n💡 Usa: *.apodo TuApodo* para establecer uno.`);
                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                if (!isOwner) {
                    const cooldownResult = this.checkCooldown(cleanUserId);

                    if (cooldownResult.onCooldown) {
                        if (cooldownResult.shouldWarn) {
                            await wrappedMessage.reply(
                                `⏳ Vas muy rápido. Espera *${cooldownResult.remaining}s* antes de usar otro comando.`
                            ).catch(() => { });
                        }

                        this.finishProcessing(dedupKey);
                        return;
                    }
                }

                // ── Lógica de invitación al canal de WhatsApp ───────────────────────
                if (!this.inviteTarget.has(cleanUserId)) {
                    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 6) + 10); // 10 a 15
                }
                const targetCount = this.inviteTarget.get(cleanUserId);
                const currentCount = (this.inviteCommandCount.get(cleanUserId) || 0) + 1;
                this.inviteCommandCount.set(cleanUserId, currentCount);

                let appendFooter = false;
                let footer = '';
                if (currentCount >= targetCount) {
                    appendFooter = true;
                    this.inviteCommandCount.set(cleanUserId, 0);
                    this.inviteTarget.set(cleanUserId, Math.floor(Math.random() * 6) + 10); // 10 a 15
                    footer = this.getAutoPromoMessage();
                }

                const baseConn = message._sock || global.conn;
                const isAdminBot = botConfig.adminsbot.includes(cleanUserId) || botConfig.adminsbot.includes(userId);
                const STAFF_SUFFIX = ' \n\n[RobleBOT Staff]';

                // Verificar si el usuario tiene la etiqueta staff activada (por defecto: sí)
                let staffTagEnabled = true;
                if (isAdminBot && staffModule) {
                    try {
                        const isStaffTagEnabled = staffModule.isStaffTagEnabled;
                        if (typeof isStaffTagEnabled === 'function') {
                            staffTagEnabled = isStaffTagEnabled(cleanUserId) || isStaffTagEnabled(userId);
                        }
                    } catch (_) { }
                }

                const enrichCtx = {
                    userId,
                    cleanUserId,
                    isAdminBot,
                    staffTagEnabled,
                    appendFooter,
                    footer
                };

                const originalReply = wrappedMessage.reply.bind(wrappedMessage);
                const originalSendMessage = baseConn.sendMessage.bind(baseConn);
                const connToUse = Object.create(baseConn);

                // ── Halloween: decidir ANTES del handler si toca imagen ───────────
                // tickCommand() es stateful; lo evaluamos una sola vez por comando.
                // _hwImageReady = true → la próxima reply de texto pura se convierte
                // en imagen+caption. Se consume la primera vez (_hwImageUsed).
                let _hwImageReady = halloween.tickCommand();
                let _hwImageUsed  = false;
                // ────────────────────────────────────────────────────────────────

                wrappedMessage.reply = async (text, options = {}) => {
                    if (typeof text === 'string') {
                        const enriched = await this.enrichText(text, enrichCtx);
                        // Si toca imagen y aún no la usamos, enviar como imagen+caption
                        if (_hwImageReady && !_hwImageUsed) {
                            const imgBuf = halloween.getRandomImage();
                            if (imgBuf) {
                                _hwImageUsed = true;
                                const destJid = message.key?.remoteJid;
                                if (destJid) {
                                    return originalSendMessage(destJid, {
                                        image: imgBuf,
                                        caption: enriched,
                                        mimetype: 'image/jpeg'
                                    }, options);
                                }
                            }
                        }
                        return originalReply(enriched, options);
                    }
                    return originalReply(text, options);
                };

                connToUse.sendMessage = async (jid, content, options = {}) => {
                    if (content && content.text && typeof content.text === 'string') {
                        const enriched = await this.enrichText(content.text, enrichCtx);
                        content.text = enriched;
                    }
                    return originalSendMessage(jid, content, options);
                };
                // ────────────────────────────────────────────────────────────────────

                const commandParams = {
                    text: fullText,
                    args,
                    conn: connToUse,
                    usedPrefix,
                    command: commandName,
                    fullUserId: userId,
                    isGroup
                };

                const handlerFunction = typeof command.handler === 'function' ? command.handler :
                    (typeof command === 'function' ? command : null);

                if (handlerFunction) {
                    try {
                        try {
                            const rawSender = message.author || message.sender || message.from;
                            if (rawSender && connToUse?.signalRepository?.lidMapping) {
                                const lidMap = connToUse.signalRepository.lidMapping;
                                if (rawSender.endsWith('@lid') && typeof lidMap.getPNForLID === 'function') {
                                    lidMap.getPNForLID(rawSender).then(pn => {
                                        if (pn && global.db?.linkUserAlias) global.db.linkUserAlias(pn, rawSender);
                                    }).catch(() => { });
                                } else if (rawSender.endsWith('@s.whatsapp.net') && typeof lidMap.getLIDForPN === 'function') {
                                    lidMap.getLIDForPN(rawSender).then(lid => {
                                        if (lid && global.db?.linkUserAlias) global.db.linkUserAlias(rawSender, lid);
                                    }).catch(() => { });
                                }
                            }
                        } catch (_) { }
                        try {
                            if (activeSock && typeof activeSock.readMessages === 'function' && message.key) {
                                activeSock.readMessages([message.key]).catch(() => { });
                            }
                        } catch (_) { }

                        await handlerFunction(wrappedMessage, commandParams);
                        commandExecuted = true;

                        try {
                            const userNum = this.cleanId(userId);
                            const userData = global.db?.getUser?.(userNum);
                            const apodo = (userData?.apodo || '').trim() || userNum;
                            const pluginFile = command.filePath ? path.basename(command.filePath) : 'desconocido';
                            const fullCmd = fullText ? `${usedPrefix}${commandName} ${fullText}` : `${usedPrefix}${commandName}`;

                            const subNum = message._subNum || connToUse._subNum;
                            const botLabel = subNum ? `Sub-bot #${subNum}` : 'Principal';

                            console.log(chalk.cyan(`[CMD] [${botLabel}] ${fullCmd} - ${apodo} - ${pluginFile}`));
                        } catch (_) { }

                        try { recordCommand(userId, commandName); } catch (_) { }

                        setImmediate(async () => {
                            try {
                                const userNum = this.cleanId(userId);
                                const userData = global.db?.getUser(userNum);
                                if (userData) {
                                    userData.ComandosEjecutados = (userData.ComandosEjecutados || 0) + 1;

                                    const { ensureAchievements } = achievements;
                                    ensureAchievements(userData);
                                    userData.achievements.commands.total = userData.ComandosEjecutados;

                                    const achievementMessage = achievements.addAchievementProgress(userData, 'commands', 0);

                                    const xpGain = Math.floor(Math.random() * 2) + 1;
                                    userData.exp = (Number(userData.exp) || 0) + xpGain;

                                    try {
                                        const levelInfo = achievements.calculateLevel(userData.exp || 0);
                                        userData.level = levelInfo.level;
                                    } catch (_) { }

                                    global.db.save(userNum);
                                    if (achievementMessage) {
                                        await wrappedMessage.reply(achievementMessage).catch(() => { });
                                    }
                                }
                            } catch (_) { }
                        });
                    } catch (error) {
                        const errorCode = error?.data || error?.output?.statusCode;
                        const errorMsg = error?.message || '';

                        // 🚨 ENOSPC: sin espacio en disco — limpiar temporales inmediatamente
                        if (errorMsg.includes('ENOSPC') || error?.code === 'ENOSPC') {
                            console.error(chalk.red(`[ENOSPC] Sin espacio en disco en comando ${commandName}. Activando limpieza de emergencia...`));
                            try {
                                const { tempCleaner } = require('./tempCleaner');
                                tempCleaner.emergencyCleanup().then(result => {
                                    console.log(chalk.green(`[ENOSPC] Limpieza completada: ${result.cleaned} archivos borrados`));
                                }).catch(e => {
                                    console.error('[ENOSPC] Error en limpieza de emergencia:', e.message);
                                });
                            } catch (cleanErr) {
                                console.error('[ENOSPC] No se pudo importar tempCleaner:', cleanErr.message);
                            }
                            await wrappedMessage.reply('⚠️ Error temporal de espacio en disco. Limpiando automáticamente...').catch(() => { });
                        }
                        else if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                            console.log(`⏱️ Rate limit alcanzado en comando ${commandName} - esperando...`);
                        }
                        else if (error?.isGroupPermissionError || errorCode === 403 || errorMsg.includes('forbidden')) {
                            if (!errorMsg.includes('ECONNRESET') && !errorMsg.includes('ETIMEDOUT')) {
                                console.log(`⚠️ Comando ${commandName} - Error 403 en grupo ${chatId} (puede ser temporal)`);
                            }
                        }
                        else if (errorMsg.includes('Connection Closed') || errorMsg.includes('connection closed')) {
                            console.log('⚠️ Conexión cerrada durante comando');
                        }
                        else {
                            console.error(`[ERROR] Error en comando ${commandName}:`, errorMsg);
                            if (error.stack) console.error(error.stack);
                            await wrappedMessage.reply('❌ Error al procesar el comando.').catch(() => { });
                        }
                    }
                }

                if (commandExecuted && normalizedCommandName !== 'join' && global.antiLink && baileyMsg) {
                    try {
                        await global.antiLink.checkMessage(baileyMsg);
                    } catch (error) {
                        if (!error.message?.includes('Connection Closed')) {
                            console.error('[Handler-AntiLink] Error post-comando:', error.message);
                        }
                    }
                }
            }

            this.finishProcessing(dedupKey);
        } catch (error) {
            if (error.message?.includes('Connection Closed')) {
                console.log('⚠️ Conexión cerrada en handleMessage');
            } else {
                console.error('Error handleMessage:', error.message);
            }
            this.finishProcessing(dedupKey);
        }
    }
}

module.exports = CommandHandler;