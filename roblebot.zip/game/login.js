(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const API = '/game/api';
  let challenge = '';
  let code = '';
  let pollTimer = null;
  let busy = false;

  function setError(message) {
    const node = $('loginError');
    if (node) node.textContent = message || '';
  }

  function setStatus(message, state) {
    const node = $('verifyStatus');
    if (!node) return;
    node.textContent = message || '';
    node.dataset.state = state || 'pending';
  }

  function clearPoll() {
    if (pollTimer) clearTimeout(pollTimer);
    pollTimer = null;
  }

  function fetchWithTimeout(url, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || 12000);
    return fetch(url, { ...(options || {}), signal: controller.signal })
      .finally(() => clearTimeout(timer));
  }

  function setRequestBusy(value) {
    const button = $('requestCode');
    if (!button) return;
    button.disabled = !!value;
    button.innerHTML = value ? 'Generando…' : 'Generar código <span>→</span>';
  }

  async function requestCode(event) {
    event.preventDefault();
    if (busy) return;
    const nickname = String($('nickname')?.value || '').trim();
    setError('');
    if (!nickname) {
      setError('Escribí tu apodo para continuar.');
      $('nickname')?.focus();
      return;
    }
    if (nickname.length > 32) {
      setError('El apodo no puede superar los 32 caracteres.');
      return;
    }

    busy = true;
    setRequestBusy(true);
    clearPoll();
    try {
      const response = await fetchWithTimeout(`${API}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ apodo: nickname }),
        credentials: 'omit',
        cache: 'no-store'
      }, 12000);
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `No se pudo generar el código (HTTP ${response.status}).`);
      if (!data.code || !data.challenge) throw new Error('El servidor respondió sin un código válido. Reiniciá el juego y probá otra vez.');

      code = String(data.code);
      challenge = String(data.challenge);
      $('loginCode').textContent = code;
      $('copyCommand').innerHTML = `.gamecode ${code} <span>Copiar</span>`;
      $('codePanel').classList.remove('hidden');
      setStatus('Esperando confirmación del bot…', 'pending');
      startPolling();
    } catch (error) {
      setError(error?.message || 'No se pudo conectar con RobleBOT. Revisá la conexión e intentá otra vez.');
    } finally {
      busy = false;
      setRequestBusy(false);
    }
  }

  async function checkStatus(silent) {
    if (!challenge) {
      if (!silent) setError('Primero generá un código con tu apodo.');
      return false;
    }
    try {
      const response = await fetchWithTimeout(`${API}/status?challenge=${encodeURIComponent(challenge)}`, {
        headers: { 'Accept': 'application/json' },
        credentials: 'omit',
        cache: 'no-store'
      }, 8000);
      const result = await response.json().catch(() => ({}));
      if (response.status === 410 || result.status === 'expired') {
        clearPoll();
        setStatus('El código venció. Generá uno nuevo.', 'expired');
        return false;
      }
      if (!response.ok) throw new Error(result.error || `Error al verificar (HTTP ${response.status}).`);
      if (result.status === 'verified' && result.token) {
        clearPoll();
        sessionStorage.setItem('robleGameSession', result.token);
        setStatus('Cuenta verificada. Preparando tu personaje…', 'verified');
        window.dispatchEvent(new CustomEvent('roblegame:verified', { detail: { token: result.token, apodo: result.apodo } }));
        return true;
      }
      if (!silent) setStatus('Todavía no llegó la confirmación. Enviá el comando al bot y volvé a comprobar.', 'pending');
      return false;
    } catch (error) {
      if (!silent) setError(error?.message || 'No se pudo verificar el estado. Comprobá tu conexión.');
      return false;
    }
  }

  function schedulePoll() {
    clearPoll();
    if (!challenge) return;
    pollTimer = setTimeout(async () => {
      const verified = await checkStatus(true);
      if (!verified && challenge) schedulePoll();
    }, 1800);
  }

  function startPolling() {
    clearPoll();
    schedulePoll();
  }

  function reset() {
    clearPoll();
    challenge = '';
    code = '';
    $('codePanel')?.classList.add('hidden');
    setStatus('', 'pending');
    setError('');
  }

  function bind() {
    const form = $('loginForm');
    if (form) form.addEventListener('submit', requestCode);

    $('checkStatus')?.addEventListener('click', () => checkStatus(false));
    $('copyCommand')?.addEventListener('click', async () => {
      if (!code) return;
      try {
        await navigator.clipboard.writeText(`.gamecode ${code}`);
        const button = $('copyCommand');
        button.innerHTML = `.gamecode ${code} <span>Copiado</span>`;
      } catch (_) {
        setStatus(`En WhatsApp enviá: .gamecode ${code}`, 'pending');
      }
    });

    window.addEventListener('error', (event) => {
      if (event.target && event.target.id === 'gameClientModule') {
        setError('El acceso web está disponible, pero no se pudo cargar el motor 3D. Recargá la página o revisá la conexión a los recursos gráficos.');
      }
    }, true);

    // Permite abrir /game?nickname=robleuy y deja el apodo listo en el formulario.
    try {
      const nickname = new URLSearchParams(window.location.search).get('nickname');
      if (nickname && $('nickname') && !$('nickname').value) {
        $('nickname').value = nickname.trim().slice(0, 32);
      }
    } catch (_) { }
  }

  window.RobleGameLogin = { reset, checkStatus };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind, { once: true });
  else bind();
})();
