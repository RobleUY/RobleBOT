import * as THREE from 'three';
import * as skinview3d from 'https://cdn.jsdelivr.net/npm/skinview3d@3.4.2/libs/skinview3d.js';

const $ = (id) => document.getElementById(id);
const screens = { login: $('loginScreen'), wardrobe: $('wardrobeScreen'), world: $('worldScreen') };
const API = '/game/api';
const SKINS = ['hombre/1','hombre/2','hombre/3','hombre/4','hombre/5','mujer/1','mujer/2','mujer/3','mujer/4','mujer/5'];
const WORLD = window.RobleWorld || { BOUNDS: 48, BLOCKERS: [] };
let sessionToken = sessionStorage.getItem('robleGameSession') || '';
let skinPreviewViewer = null;
let currentSkin = 'hombre/1';
let currentSkinUrl = '/game/skins/hombre/1.png';
let activeGender = 'hombre';
let toastTimer = 0;
let socket = null;
let renderer = null;
let scene = null;
let camera = null;
let animationFrame = 0;
let gameRunning = false;
let localPlayer = null;
let localPlayerId = '';
let playerModels = new Map();
let raycaster = new THREE.Raycaster();
let mouseNdc = new THREE.Vector2(0, 0);
let lastSendAt = 0;
let lastCount = 0;
let clock = new THREE.Clock();
const keys = new Set();
const controls = { forward: 0, strafe: 0, yaw: 0, pitch: 0, jump: false, velocityY: 0, y: 0, mobileX: 0, mobileY: 0 };
const moveSpeed = 4.65;
let mapGroup = null;
let firstPersonArm = null;
let canvasRect = null;

function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 2300);
}

function showScreen(screen) {
  Object.entries(screens).forEach(([name, element]) => element.classList.toggle('hidden', name !== screen));
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (sessionToken) headers.set('Authorization', `Bearer ${sessionToken}`);
  if (options.json) {
    headers.set('Content-Type', 'application/json');
    options.body = JSON.stringify(options.json);
  }
  const response = await fetch(`${API}${path}`, { ...options, headers, credentials: 'omit', cache: 'no-store' });
  let data = {};
  try { data = await response.json(); } catch (_) { }
  if (!response.ok) throw new Error(data.error || `Error HTTP ${response.status}`);
  return data;
}

async function openWardrobe() {
  try {
    const result = await api('/me');
    $('wardrobeName').textContent = result.player.apodo;
    currentSkinUrl = result.player.skinUrl;
    currentSkin = skinKeyFromUrl(currentSkinUrl);
    activeGender = currentSkin.startsWith('mujer/') ? 'mujer' : 'hombre';
    document.querySelectorAll('.gender-button').forEach(button => button.classList.toggle('active', button.dataset.gender === activeGender));
    initSkinPreview(currentSkinUrl);
    showScreen('wardrobe');
    renderSkinGrid();
    updateSkinPreview(currentSkinUrl, currentSkin);
  } catch (error) {
    sessionToken = '';
    sessionStorage.removeItem('robleGameSession');
    showScreen('login');
    $('loginError').textContent = error.message;
  }
}

function skinKeyFromUrl(url) {
  const match = String(url || '').match(/\/(hombre|mujer)\/([1-5])\.png$/);
  return match ? `${match[1]}/${match[2]}` : 'custom';
}

function renderSkinGrid() {
  const grid = $('skinGrid');
  grid.innerHTML = '';
  SKINS.filter(key => key.startsWith(`${activeGender}/`)).forEach((key, index) => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `skin-option${currentSkin === key ? ' selected' : ''}`;
    const image = document.createElement('img');
    image.src = `/game/skins/${key}.png`;
    image.alt = `Skin ${index + 1}`;
    const label = document.createElement('span');
    label.textContent = `Modelo ${index + 1}`;
    card.append(image, label);
    card.addEventListener('click', () => selectDefaultSkin(key));
    grid.append(card);
  });
}

function initSkinPreview(url) {
  if (skinPreviewViewer) { try { skinPreviewViewer.dispose(); } catch (_) { } skinPreviewViewer = null; }
  skinPreviewViewer = new skinview3d.SkinViewer({ canvas: $('skinPreview'), width: 190, height: 285 });
  skinPreviewViewer.loadSkin(url, { model: 'slim' }).catch(() => { });
  skinPreviewViewer.background = 0x21382a;
  skinPreviewViewer.autoRotate = true;
  skinPreviewViewer.zoom = 0.82;
  skinPreviewViewer.globalLight.intensity = 2.2;
  skinPreviewViewer.cameraLight.intensity = 0.25;
  try { skinPreviewViewer.animation = new skinview3d.IdleAnimation(); } catch (_) { }
}

function updateSkinPreview(url, key) {
  if (skinPreviewViewer) skinPreviewViewer.loadSkin(url, { model: 'slim' }).catch(() => { });
  $('selectedSkinName').textContent = key === 'custom' ? 'Skin personalizada' : `Skin ${key.split('/')[1]} · ${key.split('/')[0] === 'hombre' ? 'Hombre' : 'Mujer'}`;
  $('skinMessage').textContent = key === 'custom' ? 'Tu skin personalizada está aplicada.' : '';
  document.querySelectorAll('.skin-option').forEach(card => card.classList.toggle('selected', card.querySelector('img')?.src.endsWith(`/${key}.png`)));
}

async function selectDefaultSkin(key) {
  try {
    const result = await api('/skin/select', { method: 'POST', json: { skin: key } });
    currentSkin = key;
    currentSkinUrl = result.skinUrl;
    renderSkinGrid();
    updateSkinPreview(currentSkinUrl, currentSkin);
    showToast('Skin actualizada');
  } catch (error) { $('skinMessage').textContent = error.message; }
}

async function uploadSkin(event) {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  if (file.type !== 'image/png' || file.size > 256 * 1024) {
    $('skinMessage').textContent = 'Elegí un archivo PNG de hasta 256 KB.';
    return;
  }
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = new Image();
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = objectUrl; });
    if (image.naturalWidth !== 64 || image.naturalHeight !== 64) throw new Error('La skin debe medir exactamente 64 × 64 píxeles.');
    const response = await fetch(`${API}/skin/upload`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sessionToken}`, 'Content-Type': 'image/png' },
      body: file,
      credentials: 'omit'
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'No se pudo subir la skin.');
    currentSkin = 'custom';
    currentSkinUrl = `${data.skinUrl}?v=${Date.now()}`;
    updateSkinPreview(currentSkinUrl, currentSkin);
    showToast('Skin personalizada aplicada');
  } catch (error) { $('skinMessage').textContent = error.message; }
  finally { URL.revokeObjectURL(objectUrl); }
}

function logout() {
  if (sessionToken) fetch(`${API}/logout`, { method: 'POST', headers: { Authorization: `Bearer ${sessionToken}` }, credentials: 'omit' }).catch(() => {});
  window.RobleGameLogin?.reset?.();
  if (skinPreviewViewer) { try { skinPreviewViewer.dispose(); } catch (_) { } skinPreviewViewer = null; }
  sessionToken = '';
  sessionStorage.removeItem('robleGameSession');
  if (socket) { socket.disconnect(); socket = null; }
  stopWorld();
  $('codePanel').classList.add('hidden');
  $('loginError').textContent = '';
  showScreen('login');
}

function addBox(parent, x, y, z, sx, sy, sz, color, opts = {}) {
  const geometry = new THREE.BoxGeometry(sx, sy, sz);
  const material = new THREE.MeshStandardMaterial({ color, roughness: 1, metalness: 0, flatShading: true });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  if (opts.rotationY) mesh.rotation.y = opts.rotationY;
  parent.add(mesh);
  return mesh;
}

function addCylinder(parent, x, y, z, radiusTop, radiusBottom, height, color, segments = 8) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments),
    new THREE.MeshStandardMaterial({ color, roughness: 1, flatShading: true })
  );
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function createTree(x, z, scale = 1) {
  const group = new THREE.Group();
  group.position.set(x, 0, z);
  addCylinder(group, 0, 1.15 * scale, 0, .23 * scale, .3 * scale, 2.3 * scale, 0x765337, 6);
  addCylinder(group, 0, 2.35 * scale, 0, 0, 1.45 * scale, 2.2 * scale, 0x356d3f, 7);
  addCylinder(group, 0, 3.15 * scale, 0, 0, 1.05 * scale, 1.4 * scale, 0x45864b, 7);
  scene.add(group);
}

function createLamp(x, z) {
  const group = new THREE.Group(); group.position.set(x, 0, z);
  addCylinder(group, 0, 1.45, 0, .07, .09, 2.9, 0x36483c, 6);
  addBox(group, 0, 2.95, 0, .45, .22, .45, 0x263c30);
  addBox(group, 0, 2.82, 0, .33, .08, .33, 0xd9d8a4);
  scene.add(group);
}

function createBench(x, z, rotation = 0) {
  const group = new THREE.Group(); group.position.set(x, 0, z); group.rotation.y = rotation;
  addBox(group, 0, .5, 0, 2.1, .16, .55, 0x95633c);
  addBox(group, 0, .9, -.22, 2.1, .65, .13, 0x875a36);
  [-.78,.78].forEach(px => addBox(group, px, .25, 0, .13, .5, .45, 0x394b3e));
  scene.add(group);
}

function createBuilding(x, z, width, depth, color, roofColor) {
  const group = new THREE.Group(); group.position.set(x, 0, z);
  addBox(group, 0, 1.9, 0, width, 3.8, depth, color);
  addBox(group, 0, 4.0, 0, width + .7, .35, depth + .7, roofColor);
  addBox(group, 0, .95, depth / 2 + .04, 1.15, 1.9, .12, 0x5b422e);
  [-width * .28, width * .28].forEach(wx => {
    addBox(group, wx, 2.35, depth / 2 + .07, 1.1, 1.05, .12, 0x8bc0bd);
    addBox(group, wx, 2.35, depth / 2 + .14, .09, 1.12, .04, 0xe3e5d4);
    addBox(group, wx, 2.35, depth / 2 + .14, 1.12, .09, .04, 0xe3e5d4);
  });
  scene.add(group);
}

function createWorld() {
  if (mapGroup) return;
  scene.background = new THREE.Color(0x9ab9a3);
  scene.fog = new THREE.Fog(0x9ab9a3, 55, 112);
  const hemi = new THREE.HemisphereLight(0xe4f4df, 0x486147, 1.65); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffefcf, 1.35); sun.position.set(-25, 45, -22); scene.add(sun);
  mapGroup = new THREE.Group(); scene.add(mapGroup);
  addBox(mapGroup, 0, -.15, 0, 100, .3, 100, 0x4f8b51);
  // Caminos y plaza central.
  addBox(mapGroup, 0, .015, 0, 8, .035, 94, 0xa6a28d);
  addBox(mapGroup, 0, .018, 0, 94, .04, 8, 0xa6a28d);
  const plaza = new THREE.Mesh(new THREE.CylinderGeometry(14, 14, .12, 40), new THREE.MeshStandardMaterial({ color: 0xbab6a0, roughness: 1 }));
  plaza.position.set(0, .025, 0); scene.add(plaza);
  const inner = new THREE.Mesh(new THREE.CylinderGeometry(10.5, 10.5, .08, 40), new THREE.MeshStandardMaterial({ color: 0x8caa83, roughness: 1 }));
  inner.position.set(0, .09, 0); scene.add(inner);
  // Fuente con bordes sólidos y agua.
  addCylinder(scene, 0, .32, 0, 4.4, 4.7, .55, 0x9caa9d, 16);
  addCylinder(scene, 0, .63, 0, 3.85, 4.15, .12, 0x6b8f8d, 16);
  addCylinder(scene, 0, .72, 0, 3.25, 3.25, .08, 0x72b7bb, 16);
  addCylinder(scene, 0, 1.15, 0, .42, .55, .85, 0x859b91, 10);
  addCylinder(scene, 0, 1.68, 0, .1, .35, .25, 0x74c1c6, 10);
  // Edificios perimetrales.
  createBuilding(-24, -23, 21, 11, 0xd0b58e, 0x6d5944);
  createBuilding(25, -21, 17, 11, 0xc7d0bd, 0x6c866d);
  createBuilding(-27, 22, 17, 11, 0xb6c5b0, 0x80654a);
  // Árboles, bancos, faroles y jardines.
  [
    [-39,-36,.9],[-31,-7,1],[-40,8,.95],[-35,37,1],[-18,-39,.95],[-7,-38,.9],[10,-39,1],[39,-37,1],
    [40,-5,.95],[37,14,1],[39,37,.9],[20,39,1],[4,39,.95],[-12,38,1],[-42,24,.9],[10,22,.9],[28,8,1],[-27,5,.9]
  ].forEach(p => createTree(...p));
  [[-15,-15],[15,-15],[-15,15],[15,15],[-40,0],[40,0],[0,-42],[0,42]].forEach(p => createLamp(...p));
  [[-10,10,Math.PI/2],[10,10,-Math.PI/2],[-10,-11,Math.PI/2],[10,-11,-Math.PI/2],[-19,0,0],[19,0,0]].forEach(p => createBench(...p));
  // Maceteros y bloques bajos decorativos.
  [[-7,23],[7,23],[-7,-23],[7,-23],[-23,-7],[23,-7],[-23,7],[23,7]].forEach(([x,z]) => {
    addBox(scene, x, .25, z, 2.3, .5, 2.3, 0x8d987c);
    addBox(scene, x, .58, z, 1.8, .2, 1.8, 0x4f8751);
  });
  // Vallas del límite del mundo.
  [-48,48].forEach(z => { addBox(scene, 0, .55, z, 96, 1.1, .35, 0x6b876b); });
  [-48,48].forEach(x => { addBox(scene, x, .55, 0, .35, 1.1, 96, 0x6b876b); });
}

function cropTexture(image, rect) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, rect[2]); canvas.height = Math.max(1, rect[3]);
  const ctx = canvas.getContext('2d', { alpha: true });
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(image, rect[0], rect[1], rect[2], rect[3], 0, 0, canvas.width, canvas.height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return new THREE.MeshStandardMaterial({ map: texture, transparent: true, roughness: 1, metalness: 0, side: THREE.FrontSide });
}

function partMaterials(image, faces) {
  // BoxGeometry usa este orden: +X, -X, +Y, -Y, +Z, -Z.
  return [
    cropTexture(image, faces.right), cropTexture(image, faces.left),
    cropTexture(image, faces.top), cropTexture(image, faces.bottom),
    cropTexture(image, faces.front), cropTexture(image, faces.back)
  ];
}

const FACE = {
  head: { right:[0,8,8,8], left:[16,8,8,8], top:[8,0,8,8], bottom:[16,0,8,8], front:[8,8,8,8], back:[24,8,8,8] },
  body: { right:[16,20,4,12], left:[28,20,4,12], top:[20,16,8,4], bottom:[28,16,8,4], front:[20,20,8,12], back:[32,20,8,12] },
  rightArm: { right:[40,20,4,12], left:[48,20,4,12], top:[44,16,4,4], bottom:[48,16,4,4], front:[44,20,4,12], back:[52,20,4,12] },
  leftArm: { right:[32,52,4,12], left:[40,52,4,12], top:[36,48,4,4], bottom:[40,48,4,4], front:[36,52,4,12], back:[44,52,4,12] },
  rightLeg: { right:[0,20,4,12], left:[8,20,4,12], top:[4,16,4,4], bottom:[8,16,4,4], front:[4,20,4,12], back:[12,20,4,12] },
  leftLeg: { right:[16,52,4,12], left:[24,52,4,12], top:[20,48,4,4], bottom:[24,48,4,4], front:[20,52,4,12], back:[28,52,4,12] },
  headOuter: { right:[32,8,8,8], left:[48,8,8,8], top:[40,0,8,8], bottom:[48,0,8,8], front:[40,8,8,8], back:[56,8,8,8] },
  bodyOuter: { right:[16,36,4,12], left:[28,36,4,12], top:[20,32,8,4], bottom:[28,32,8,4], front:[20,36,8,12], back:[32,36,8,12] },
  rightArmOuter: { right:[40,36,4,12], left:[48,36,4,12], top:[44,32,4,4], bottom:[48,32,4,4], front:[44,36,4,12], back:[52,36,4,12] },
  leftArmOuter: { right:[48,52,4,12], left:[56,52,4,12], top:[52,48,4,4], bottom:[56,48,4,4], front:[52,52,4,12], back:[60,52,4,12] },
  rightLegOuter: { right:[0,36,4,12], left:[8,36,4,12], top:[4,32,4,4], bottom:[8,32,4,4], front:[4,36,4,12], back:[12,36,4,12] },
  leftLegOuter: { right:[0,52,4,12], left:[8,52,4,12], top:[4,48,4,4], bottom:[8,48,4,4], front:[4,52,4,12], back:[12,52,4,12] }
};

function createAvatar(id, name, skinUrl) {
  const root = new THREE.Group();
  root.userData.playerId = id;
  const parts = {};
  function makeLimb(key, size, position, parent, faces) {
    const geometry = new THREE.BoxGeometry(...size);
    const material = new THREE.MeshStandardMaterial({ color: 0xd3d8d2, roughness: 1 });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(...position);
    mesh.userData.faceKey = key;
    parent.add(mesh);
    parts[key] = { mesh, faces };
    return mesh;
  }
  makeLimb('head', [.5,.5,.5], [0,1.67,0], root, FACE.head);
  makeLimb('headOuter', [.531,.531,.531], [0,1.67,0], root, FACE.headOuter);
  makeLimb('body', [.5,.75,.25], [0,1.05,0], root, FACE.body);
  makeLimb('bodyOuter', [.531,.781,.281], [0,1.05,0], root, FACE.bodyOuter);
  const rightArm = new THREE.Group(); rightArm.position.set(.345,1.43,0); root.add(rightArm);
  makeLimb('rightArm', [.1875,.75,.25], [0,-.36,0], rightArm, FACE.rightArm);
  makeLimb('rightArmOuter', [.205,.77,.27], [0,-.36,0], rightArm, FACE.rightArmOuter);
  const leftArm = new THREE.Group(); leftArm.position.set(-.345,1.43,0); root.add(leftArm);
  makeLimb('leftArm', [.1875,.75,.25], [0,-.36,0], leftArm, FACE.leftArm);
  makeLimb('leftArmOuter', [.205,.77,.27], [0,-.36,0], leftArm, FACE.leftArmOuter);
  const rightLeg = new THREE.Group(); rightLeg.position.set(.13,.76,0); root.add(rightLeg);
  makeLimb('rightLeg', [.25,.76,.25], [0,-.37,0], rightLeg, FACE.rightLeg);
  makeLimb('rightLegOuter', [.27,.78,.27], [0,-.37,0], rightLeg, FACE.rightLegOuter);
  const leftLeg = new THREE.Group(); leftLeg.position.set(-.13,.76,0); root.add(leftLeg);
  makeLimb('leftLeg', [.25,.76,.25], [0,-.37,0], leftLeg, FACE.leftLeg);
  makeLimb('leftLegOuter', [.27,.78,.27], [0,-.37,0], leftLeg, FACE.leftLegOuter);
  parts.groups = { rightArm, leftArm, rightLeg, leftLeg };
  parts.head = parts.head;
  root.userData.parts = parts;
  root.userData.name = name;
  const labelCanvas = document.createElement('canvas'); labelCanvas.width = 512; labelCanvas.height = 128;
  const labelCtx = labelCanvas.getContext('2d');
  labelCtx.fillStyle = 'rgba(12,20,14,.72)';
  roundRect(labelCtx, 20, 15, 472, 98, 26); labelCtx.fill();
  labelCtx.font = '700 42px system-ui'; labelCtx.textAlign = 'center'; labelCtx.textBaseline = 'middle'; labelCtx.fillStyle = '#f0f7f1';
  labelCtx.fillText(name, 256, 65, 430);
  const labelTexture = new THREE.CanvasTexture(labelCanvas); labelTexture.colorSpace = THREE.SRGBColorSpace;
  const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTexture, transparent: true, depthTest: true }));
  label.position.set(0,2.35,0); label.scale.set(2.55,.64,1); root.add(label);
  const image = new Image(); image.crossOrigin = 'anonymous';
  image.onload = () => {
    Object.entries(parts).forEach(([key, part]) => {
      if (!part?.mesh || !part.faces) return;
      part.mesh.material = partMaterials(image, part.faces);
    });
  };
  image.src = skinUrl;
  root.userData.skinUrl = skinUrl;
  return root;
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath(); ctx.moveTo(x+radius,y); ctx.lineTo(x+width-radius,y); ctx.quadraticCurveTo(x+width,y,x+width,y+radius);
  ctx.lineTo(x+width,y+height-radius); ctx.quadraticCurveTo(x+width,y+height,x+width-radius,y+height); ctx.lineTo(x+radius,y+height);
  ctx.quadraticCurveTo(x,y+height,x,y+height-radius); ctx.lineTo(x,y+radius); ctx.quadraticCurveTo(x,y,x+radius,y); ctx.closePath();
}

function createFirstPersonArm() {
  const group = new THREE.Group();
  const geometry = new THREE.BoxGeometry(.2,.74,.24);
  const material = new THREE.MeshStandardMaterial({ color: 0xd4d8d0, roughness: 1 });
  const arm = new THREE.Mesh(geometry, material); arm.position.set(0,-.37,0); group.add(arm);
  group.position.set(.43,-.43,-.72); group.rotation.set(-.08,-.18,-.08); camera.add(group);
  const image = new Image(); image.onload = () => { arm.material = partMaterials(image, FACE.rightArm); }; image.src = currentSkinUrl;
  return group;
}

function initRenderer() {
  if (renderer) return;
  const canvas = $('worldCanvas');
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'high-performance', stencil: false, depth: true });
  } catch (error) {
    showToast('Tu dispositivo no pudo iniciar WebGL. Probá otro navegador o activá la aceleración gráfica.');
    throw error;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(76, 1, .08, 150);
  camera.rotation.order = 'YXZ';
  camera.position.set(0,1.62,14);
  scene.add(camera);
  createWorld();
  firstPersonArm = createFirstPersonArm();
  resizeRenderer();
}

function resizeRenderer() {
  if (!renderer || !camera) return;
  const width = Math.max(1, window.innerWidth), height = Math.max(1, window.innerHeight);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  canvasRect = renderer.domElement.getBoundingClientRect();
}

function canStandAt(x, z, radius = .36) {
  const b = WORLD.BOUNDS;
  if (x < -b + radius || x > b - radius || z < -b + radius || z > b - radius) return false;
  for (const block of WORLD.BLOCKERS) {
    if (x > block.x - block.w / 2 - radius && x < block.x + block.w / 2 + radius && z > block.z - block.d / 2 - radius && z < block.z + block.d / 2 + radius) return false;
  }
  return true;
}

function addRemotePlayer(player) {
  if (!player?.id || player.id === localPlayerId) return;
  let entry = playerModels.get(player.id);
  if (!entry) {
    const model = createAvatar(player.id, player.apodo || 'Jugador', player.skinUrl || '/game/skins/hombre/1.png');
    scene.add(model);
    entry = { model, target: { ...player }, current: { ...player } };
    playerModels.set(player.id, entry);
  } else {
    entry.target = { ...entry.target, ...player };
    if (entry.model.userData.name !== player.apodo) {
      scene.remove(entry.model); disposeObject(entry.model);
      const model = createAvatar(player.id, player.apodo || 'Jugador', player.skinUrl || '/game/skins/hombre/1.png');
      scene.add(model); entry.model = model;
    } else if (player.skinUrl && entry.model.userData.skinUrl !== player.skinUrl) {
      scene.remove(entry.model); disposeObject(entry.model);
      const model = createAvatar(player.id, player.apodo || 'Jugador', player.skinUrl);
      scene.add(model); entry.model = model;
    }
  }
}

function removeRemotePlayer(id) {
  const entry = playerModels.get(id);
  if (!entry) return;
  scene.remove(entry.model); disposeObject(entry.model); playerModels.delete(id);
}

function disposeObject(object) {
  object.traverse(child => {
    if (child.geometry) child.geometry.dispose();
    if (child.material) {
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      materials.forEach(material => { if (material.map) material.map.dispose(); material.dispose(); });
    }
  });
}

function updateRemotePlayers(delta) {
  for (const entry of playerModels.values()) {
    const t = Math.min(1, delta * 12);
    entry.current.x += (entry.target.x - entry.current.x) * t;
    entry.current.y += ((entry.target.y || 0) - (entry.current.y || 0)) * t;
    entry.current.z += (entry.target.z - entry.current.z) * t;
    entry.current.yaw = lerpAngle(entry.current.yaw || 0, entry.target.yaw || 0, t);
    entry.model.position.set(entry.current.x, entry.current.y || 0, entry.current.z);
    entry.model.rotation.y = entry.current.yaw;
    const phase = performance.now() * .009;
    const swing = entry.target.moving ? Math.sin(phase) * .52 : 0;
    const groups = entry.model.userData.parts.groups;
    groups.rightArm.rotation.x = swing;
    groups.leftArm.rotation.x = -swing;
    groups.rightLeg.rotation.x = -swing;
    groups.leftLeg.rotation.x = swing;
  }
}

function lerpAngle(a, b, t) {
  const delta = Math.atan2(Math.sin(b-a), Math.cos(b-a));
  return a + delta * t;
}

function updateMovement(delta) {
  if (!localPlayer) return;
  const forward = (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) - (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0);
  const strafe = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0);
  const mobileForward = -controls.mobileY;
  const mobileStrafe = controls.mobileX;
  let f = forward || mobileForward;
  let s = strafe || mobileStrafe;
  const length = Math.hypot(f,s);
  if (length > 1) { f /= length; s /= length; }
  const yaw = controls.yaw;
  const dx = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * moveSpeed * delta;
  const dz = (-Math.cos(yaw) * f - Math.sin(yaw) * s) * moveSpeed * delta;
  let nextX = localPlayer.x + dx, nextZ = localPlayer.z + dz;
  if (canStandAt(nextX, localPlayer.z)) localPlayer.x = nextX;
  if (canStandAt(localPlayer.x, nextZ)) localPlayer.z = nextZ;
  const jumpPressed = keys.has('Space') || controls.jump;
  if (jumpPressed && localPlayer.y <= .001) controls.velocityY = 5.2;
  controls.velocityY -= 14.2 * delta;
  localPlayer.y = Math.max(0, localPlayer.y + controls.velocityY * delta);
  if (localPlayer.y === 0) controls.velocityY = 0;
  localPlayer.moving = Math.abs(f) + Math.abs(s) > .05;
  camera.position.set(localPlayer.x, 1.62 + localPlayer.y, localPlayer.z);
  camera.rotation.set(controls.pitch, controls.yaw, 0, 'YXZ');
  if (firstPersonArm) firstPersonArm.rotation.x = localPlayer.moving ? Math.sin(performance.now() * .012) * .08 : 0;
  $('coordinates').textContent = `X ${localPlayer.x.toFixed(1)} · Z ${localPlayer.z.toFixed(1)}`;
}

function sendPlayerState(now) {
  if (!socket?.connected || !localPlayer || now - lastSendAt < 50) return;
  lastSendAt = now;
  socket.volatile.emit('player:state', {
    x: localPlayer.x, y: localPlayer.y, z: localPlayer.z,
    yaw: controls.yaw, pitch: controls.pitch, moving: localPlayer.moving
  });
}

function animate() {
  if (!gameRunning || !renderer) return;
  animationFrame = requestAnimationFrame(animate);
  const delta = Math.min(clock.getDelta(), .05);
  updateMovement(delta);
  updateRemotePlayers(delta);
  sendPlayerState(performance.now());
  renderer.render(scene, camera);
}

function startWorld() {
  initRenderer();
  gameRunning = true;
  clock.start();
  animationFrame = requestAnimationFrame(animate);
  connectSocket();
  if (window.matchMedia('(pointer: coarse)').matches) $('mobileControls').style.display = 'block';
  else $('mobileControls').style.display = 'none';
  $('worldScreen').classList.remove('locked');
}

function stopWorld() {
  gameRunning = false;
  if (animationFrame) cancelAnimationFrame(animationFrame);
  animationFrame = 0;
  if (document.pointerLockElement) document.exitPointerLock();
  if (socket) { socket.disconnect(); socket = null; }
  playerModels.forEach(entry => { scene?.remove(entry.model); disposeObject(entry.model); });
  playerModels.clear();
  if (scene) { try { disposeObject(scene); } catch (_) { } }
  if (renderer) { try { renderer.dispose(); renderer.forceContextLoss(); } catch (_) { } }
  renderer = null; scene = null; camera = null; mapGroup = null; firstPersonArm = null;
  localPlayer = null;
  keys.clear();
  controls.mobileX = controls.mobileY = 0;
}

function connectSocket() {
  if (socket) socket.disconnect();
  if (typeof window.io !== 'function') { showToast('No se pudo cargar el cliente de conexión. Recargá el juego.'); return; }
  socket = window.io({ path: '/game/socket.io', transports: ['websocket','polling'], auth: { token: sessionToken }, reconnection: true, reconnectionAttempts: 8, timeout: 10000 });
  socket.on('connect', () => showToast('Conectado al mundo de RobleBOT'));
  socket.on('connect_error', error => showToast(error.message || 'No se pudo conectar al mundo'));
  socket.on('world:init', data => {
    localPlayerId = data.self;
    const self = (data.players || []).find(p => p.id === localPlayerId);
    if (self) {
      localPlayer = { x: self.x, y: self.y || 0, z: self.z, moving: false };
      controls.yaw = self.yaw || 0; controls.pitch = self.pitch || 0;
    }
    (data.players || []).forEach(addRemotePlayer);
    updatePlayerCount(data.players?.length || 1);
  });
  socket.on('world:state', players => {
    if (!Array.isArray(players)) return;
    const seen = new Set();
    players.forEach(player => {
      seen.add(player.id);
      if (player.id === localPlayerId) {
        if (localPlayer && Math.hypot(player.x-localPlayer.x, player.z-localPlayer.z) > 1.15) {
          localPlayer.x = player.x; localPlayer.z = player.z; camera.position.x = player.x; camera.position.z = player.z;
        }
      } else addRemotePlayer(player);
    });
    for (const id of playerModels.keys()) if (!seen.has(id)) removeRemotePlayer(id);
    updatePlayerCount(players.length);
  });
  socket.on('player:joined', addRemotePlayer);
  socket.on('player:left', removeRemotePlayer);
  socket.on('player:skin', data => {
    const entry = playerModels.get(data?.id);
    if (!entry || !data.skinUrl) return;
    const target = { ...entry.target, skinUrl: data.skinUrl };
    removeRemotePlayer(data.id);
    addRemotePlayer(target);
  });
}

function updatePlayerCount(count) {
  lastCount = count;
  $('playerCount').textContent = String(count || 1);
}

function tryPointerLock() {
  if (window.matchMedia('(pointer: coarse)').matches) return;
  const canvas = $('worldCanvas');
  if (document.pointerLockElement !== canvas) canvas.requestPointerLock?.();
}

function onMouseMove(event) {
  if (document.pointerLockElement !== $('worldCanvas')) return;
  controls.yaw -= event.movementX * .00235;
  controls.pitch -= event.movementY * .0021;
  controls.pitch = Math.max(-1.35, Math.min(1.35, controls.pitch));
}

function interactAt(clientX, clientY, useCenter = false) {
  if (!camera || !renderer || playerModels.size === 0 || $('profilePanel').classList.contains('hidden') === false) return;
  const rect = renderer.domElement.getBoundingClientRect();
  if (useCenter) mouseNdc.set(0,0);
  else mouseNdc.set(((clientX-rect.left)/rect.width)*2-1, -(((clientY-rect.top)/rect.height)*2-1));
  raycaster.setFromCamera(mouseNdc, camera);
  const roots = [...playerModels.values()].map(entry => entry.model);
  const intersections = raycaster.intersectObjects(roots, true);
  if (!intersections.length) return;
  let object = intersections[0].object;
  while (object && !object.userData.playerId) object = object.parent;
  const targetId = object?.userData.playerId;
  if (!targetId || !socket?.connected) return;
  socket.emit('player:profile', targetId, result => {
    if (!result?.ok) return showToast(result?.error || 'No se pudo abrir el perfil.');
    displayProfile(result.profile, targetId);
  });
}

function displayProfile(profile, targetId) {
  const entry = playerModels.get(targetId);
  $('profileNickname').textContent = profile.apodo || 'Jugador';
  $('profileRank').textContent = profile.rango || 'Sin rango';
  $('profilePartner').textContent = profile.pareja || 'Sin pareja';
  $('profileMoney').textContent = `$${(Number(profile.dinero)||0).toLocaleString('es-UY')}`;
  $('profileClan').textContent = profile.clan || 'Sin clan';
  $('profileSkin').src = entry?.target?.skinUrl || '/game/skins/hombre/1.png';
  $('profilePanel').classList.remove('hidden');
  $('profileBackdrop').classList.remove('hidden');
}

function closeProfile() {
  $('profilePanel').classList.add('hidden');
  $('profileBackdrop').classList.add('hidden');
}

function setupMobileControls() {
  const zone = $('joystickZone'), knob = $('joystickKnob'), lookZone = $('lookZone');
  let joystickPointer = null, lookPointer = null, lookStart = null;
  const maxRadius = 34;
  zone.addEventListener('pointerdown', event => {
    joystickPointer = event.pointerId; zone.setPointerCapture(event.pointerId);
    updateJoystick(event);
  });
  zone.addEventListener('pointermove', event => { if (event.pointerId === joystickPointer) updateJoystick(event); });
  const releaseJoystick = event => {
    if (event.pointerId !== joystickPointer) return;
    joystickPointer = null; controls.mobileX = 0; controls.mobileY = 0; knob.style.transform = 'translate(0,0)';
  };
  zone.addEventListener('pointerup', releaseJoystick); zone.addEventListener('pointercancel', releaseJoystick);
  function updateJoystick(event) {
    const rect = zone.getBoundingClientRect();
    const cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
    let dx = event.clientX-cx, dy = event.clientY-cy;
    const len = Math.hypot(dx,dy);
    if (len > maxRadius) { dx = dx/len*maxRadius; dy = dy/len*maxRadius; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    controls.mobileX = dx/maxRadius;
    controls.mobileY = dy/maxRadius;
  }
  lookZone.addEventListener('pointerdown', event => {
    lookPointer = event.pointerId; lookStart = { x:event.clientX,y:event.clientY,lastX:event.clientX,lastY:event.clientY,moved:false };
    lookZone.setPointerCapture(event.pointerId);
  });
  lookZone.addEventListener('pointermove', event => {
    if (event.pointerId !== lookPointer || !lookStart) return;
    const dx = event.clientX-lookStart.lastX, dy = event.clientY-lookStart.lastY;
    if (Math.hypot(event.clientX-lookStart.x,event.clientY-lookStart.y)>8) lookStart.moved = true;
    controls.yaw -= dx*.005; controls.pitch = Math.max(-1.35,Math.min(1.35,controls.pitch-dy*.0045));
    lookStart.lastX = event.clientX; lookStart.lastY = event.clientY;
  });
  const releaseLook = event => {
    if (event.pointerId !== lookPointer) return;
    if (lookStart && !lookStart.moved) interactAt(event.clientX,event.clientY,false);
    lookPointer = null; lookStart = null;
  };
  lookZone.addEventListener('pointerup', releaseLook); lookZone.addEventListener('pointercancel', releaseLook);
  $('jumpButton').addEventListener('pointerdown', event => { event.preventDefault(); controls.jump = true; });
  ['pointerup','pointercancel','pointerleave'].forEach(name => $('jumpButton').addEventListener(name, () => { controls.jump = false; }));
}

async function enterWorld() {
  try {
    if (skinPreviewViewer) { skinPreviewViewer.dispose(); skinPreviewViewer = null; }
    await document.documentElement.requestFullscreen?.().catch(() => {});
    try { await screen.orientation?.lock?.('landscape'); } catch (_) { }
    showScreen('world');
    startWorld();
  } catch (error) { showToast(error.message || 'No se pudo iniciar el mundo.'); }
}

function bindEvents() {
  $('skinUpload').addEventListener('change', uploadSkin);
  document.querySelectorAll('.gender-button').forEach(button => button.addEventListener('click', () => {
    activeGender = button.dataset.gender;
    document.querySelectorAll('.gender-button').forEach(item => item.classList.toggle('active', item === button));
    renderSkinGrid();
  }));
  $('playButton').addEventListener('click', enterWorld);
  $('logoutButton').addEventListener('click', logout);
  $('exitWorld').addEventListener('click', () => { stopWorld(); showScreen('wardrobe'); initSkinPreview(currentSkinUrl); if (document.fullscreenElement) document.exitFullscreen().catch(()=>{}); });
  $('closeProfile').addEventListener('click', closeProfile);
  $('profileBackdrop').addEventListener('click', closeProfile);
  $('worldCanvas').addEventListener('click', event => {
    if (document.pointerLockElement !== $('worldCanvas')) { tryPointerLock(); return; }
    interactAt(window.innerWidth/2,window.innerHeight/2,true);
  });
  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('pointerlockchange', () => $('worldScreen').classList.toggle('locked', document.pointerLockElement === $('worldCanvas')));
  document.addEventListener('keydown', event => {
    if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.code)) event.preventDefault();
    keys.add(event.code);
    if (event.code === 'Escape' && !$('profilePanel').classList.contains('hidden')) closeProfile();
  }, { passive: false });
  document.addEventListener('keyup', event => keys.delete(event.code));
  window.addEventListener('blur', () => { keys.clear(); controls.jump = false; });
  window.addEventListener('resize', resizeRenderer, { passive: true });
  document.addEventListener('visibilitychange', () => { if (document.hidden) { keys.clear(); controls.jump = false; } });
  setupMobileControls();
}

let verifiedEventToken = '';
window.addEventListener('roblegame:verified', async (event) => {
  const token = String(event.detail?.token || sessionStorage.getItem('robleGameSession') || '');
  if (!token || token === verifiedEventToken) return;
  verifiedEventToken = token;
  sessionToken = token;
  await openWardrobe();
});

async function bootstrap() {
  bindEvents();
  if (sessionToken) {
    await openWardrobe();
  } else showScreen('login');
}

bootstrap().catch(error => {
  console.error('[RobleBOT Game]', error);
  showScreen('login');
  $('loginError').textContent = 'No se pudo iniciar el juego. Recargá la página.';
});
