(function (root, factory) {
  const data = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = data;
  if (root) root.RobleWorld = data;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // Coordenadas X/Z. El servidor y el cliente comparten exactamente estos límites.
  const BOUNDS = 48;
  const BLOCKERS = [
    // Edificio norte: paredes y volumen central
    { x: -24, z: -29, w: 22, d: 1.2 }, { x: -24, z: -17, w: 22, d: 1.2 },
    { x: -35, z: -23, w: 1.2, d: 12 }, { x: -13, z: -23, w: 1.2, d: 12 },
    // Edificio este
    { x: 25, z: -27, w: 18, d: 1.2 }, { x: 25, z: -15, w: 18, d: 1.2 },
    { x: 16, z: -21, w: 1.2, d: 12 }, { x: 34, z: -21, w: 1.2, d: 12 },
    // Edificio sur oeste
    { x: -27, z: 28, w: 18, d: 1.2 }, { x: -27, z: 16, w: 18, d: 1.2 },
    { x: -36, z: 22, w: 1.2, d: 12 }, { x: -18, z: 22, w: 1.2, d: 12 },
    // Fuente central
    { x: 0, z: 0, w: 9.4, d: 9.4 },
    // Muros/bordes de mapa
    { x: 0, z: -49.5, w: 100, d: 2 }, { x: 0, z: 49.5, w: 100, d: 2 },
    { x: -49.5, z: 0, w: 2, d: 100 }, { x: 49.5, z: 0, w: 2, d: 100 },
    // Árboles
    ...[
      [-39,-36],[-31,-7],[-40,8],[-35,37],[-18,-39],[-7,-38],[10,-39],[39,-37],
      [40,-5],[37,14],[39,37],[20,39],[4,39],[-12,38],[-42,24],[10,22],[28,8],[-27,5]
    ].map(([x,z]) => ({ x, z, w: 1.2, d: 1.2 })),
    // Bancos y faroles
    ...[[-10,10],[10,10],[-10,-11],[10,-11],[-19,0],[19,0]].map(([x,z]) => ({ x,z,w:2.5,d:1.2 })),
    ...[[-15,-15],[15,-15],[-15,15],[15,15],[-40,0],[40,0],[0,-42],[0,42]].map(([x,z]) => ({x,z,w:0.8,d:0.8}))
  ];

  return { BOUNDS, BLOCKERS };
});
