# RobleBOT Game

Juego 3D multijugador integrado en el servidor HTTP público de RobleBOT.

## URL

`http://june.hidencloud.com:24629/game`

El puerto se toma de `HEALTH_PORT` (predeterminado: `24629`). El servidor independiente de subbots en `25196` no se modifica.

## Inicio de sesión

1. Abrir `/game` y escribir el apodo exacto de RobleBOT.
2. La página genera un código numérico de 4 cifras y un identificador secreto de verificación.
3. En WhatsApp, ejecutar `.gamecode 1234` con el código que muestra la página.
4. Volver a la página y esperar la verificación.
5. Elegir una skin y entrar al mundo.

El código vence a los cinco minutos y está ligado al ID canónico de la cuenta; otro usuario no puede validarlo. La sesión web se conserva en memoria del proceso durante siete días como máximo y debe generarse otra luego de reiniciar el bot.

## Controles

- PC: `W`, `A`, `S`, `D`, mouse para mirar y `Espacio` para saltar. El clic captura el mouse; apuntar a un jugador cercano y hacer clic abre su perfil.
- Móvil: mantener el dispositivo en horizontal, joystick izquierdo para caminar, arrastrar en la zona derecha para mirar y botón derecho para saltar. Tocar a un jugador cercano abre su perfil.

## Skins

Incluye 5 skins `hombre` y 5 `mujer`, todas de 64×64. También acepta PNG de skin Minecraft de exactamente 64×64, hasta 256 KB. Cada usuario conserva una sola skin personalizada activa; el archivo anterior se reemplaza al subir otra o se elimina al seleccionar una predeterminada.

## Infraestructura

- HTTP y Socket.IO se añaden al servidor público actual (`HEALTH_PORT`, por defecto `24629`).
- `subbotServer.js` continúa en su puerto independiente `25196`.
- Se comparte la base de datos SQLite de RobleBOT para validar apodos y consultar perfiles.
- Para HTTPS, el hosting debe terminar TLS en un proxy/reverse proxy y reenviar al servidor Node. CORS habilita orígenes externos, pero no puede evitar el bloqueo de contenido mixto de los navegadores cuando una página HTTPS intenta conectarse directamente a un endpoint HTTP.
- Three.js y [skinview3d](https://www.npmjs.com/package/skinview3d) se cargan desde jsDelivr; el navegador necesita conexión al CDN para el render 3D y la vista previa del vestuario.
