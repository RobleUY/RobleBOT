# RobleBOT Game

Juego 3D multijugador integrado en el servidor HTTP público de RobleBOT.

## URL

`http://june.hidencloud.com:24629/game`

El puerto se toma de `HEALTH_PORT` (predeterminado: `24629`). El servidor independiente de subbots en `25196` no se modifica.

## Inicio de sesión

1. Abrir `/game` y escribir el apodo exacto de RobleBOT.
2. La página genera un código numérico de 4 cifras y un identificador secreto de verificación.
3. En WhatsApp, ejecutar `.gamecode 1234` con el código que muestra la página.
4. Volver a la página y esperar la verificación.
5. Elegir una skin y entrar al mundo.

El código vence a los cinco minutos y está ligado al ID canónico de la cuenta; otro usuario no puede validarlo. La sesión web se conserva en memoria del proceso durante siete días como máximo y debe generarse otra luego de reiniciar el bot.

## Controles

- PC: `W`, `A`, `S`, `D`, mouse para mirar y `Espacio` para saltar. El clic captura el mouse; apuntar a un jugador cercano y hacer clic abre su perfil.
- Móvil: mantener el dispositivo en horizontal, joystick izquierdo para caminar, arrastrar en la zona derecha para mirar y botón derecho para saltar. Tocar a un jugador cercano abre su perfil.

## Skins

Incluye 5 skins `hombre` y 5 `mujer`, todas de 64×64. También acepta PNG de skin Minecraft de exactamente 64×64, hasta 256 KB. Cada usuario conserva una sola skin personalizada activa; el archivo anterior se reemplaza al subir otra o se elimina al seleccionar una predeterminada.

## Infraestructura

- HTTP y Socket.IO se añaden al servidor público actual (`HEALTH_PORT`, por defecto `24629`).
- `subbotServer.js` continúa en su puerto independiente `25196`.
- Se comparte la base de datos SQLite de RobleBOT para validar apodos y consultar perfiles.
- Para HTTPS, el hosting debe terminar TLS en un proxy/reverse proxy y reenviar al servidor Node. CORS habilita orígenes externos, pero no puede evitar el bloqueo de contenido mixto de los navegadores cuando una página HTTPS intenta conectarse directamente a un endpoint HTTP.
- Three.js se carga desde jsDelivr. El modelo de los jugadores y la vista previa del vestuario reutilizan el mismo renderizador 3D y las mismas texturas de Minecraft; ya no se depende de skinview3d ni de su dependencia skinview-utils.


### Inicio de sesión independiente del motor 3D

El formulario y la verificación de códigos se gestionan desde `login.js`, un script local sin dependencias CDN. De esta forma, un fallo al descargar los recursos gráficos no impide solicitar el código de acceso. La URL admite `?nickname=APODO` para precargar el campo, sin iniciar sesión automáticamente. Las solicitudes de login y estado tienen tiempo límite y muestran errores comprensibles.


## Ajustes de skins y movimiento

- El avatar usa el atlas 64×64 completo con UV por cara, respeta las transparencias de la capa exterior y evita que una cara del atlas invada otra. La capa base usa las coordenadas correspondientes al modelo seleccionado.
- El tipo de brazo se estima por las 64 celdas exclusivas del atlas Classic y se puede corregir manualmente en el vestuario. El PNG no codifica formalmente el modelo; la preferencia final se guarda por usuario en `data/player-models.json`.
- La corrección brusca de la posición local a partir de snapshots del servidor se eliminó; el cliente mantiene movimiento predictivo. El servidor continúa validando velocidad y colisiones para la posición compartida.
- El radio de colisión del jugador se redujo a 0,24 y se aplica de forma idéntica en cliente y servidor.

- El render de cada jugador reutiliza dos atlas compartidos por avatar (capa base opaca y capa exterior transparente) para todas sus piezas y consolida las caras en una malla por parte, reduciendo las texturas y draw calls de cada avatar.


### Modelos de skin y movimiento

- El mundo renderiza por separado la capa interior opaca y la capa exterior con transparencia, como Minecraft Java.
- El detector usa las celdas exclusivas del atlas Classic como sugerencia; el selector manual Classic/Slim del vestuario permite corregirla.
- Si una skin personalizada no coincide, elegí el modelo manualmente antes de entrar.
- Durante reconexiones se pausa el movimiento y se conserva la posición local, evitando saltos hacia posiciones antiguas.
- Las colisiones del cliente y del servidor usan el mismo radio y deslizamiento por ejes.


### Texturas sin cortes y movimiento suave

- La capa base se compone como opaca y la capa exterior conserva transparencia, siguiendo el render de Minecraft Java.
- Cada brazo usa coordenadas UV distintas para Classic (4 px) y Slim (3 px); el modelo queda guardado por usuario y puede ajustarse manualmente.
- El detector evalúa sólo los píxeles exclusivos del atlas Classic; su resultado es una sugerencia, no un dato incrustado en el PNG.
- Las colisiones se resuelven por subpasos de 0,06 unidades y por eje, tanto en navegador como en servidor, permitiendo deslizarse junto a obstáculos.
- El cliente pausa el movimiento mientras Socket.IO está desconectado y no sustituye la posición local por snapshots antiguos al reconectar.
