'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const sharp = require('sharp');
const gameAuth = require('../lib/gameAuth');
const WORLD = require('./world');
const { Server: SocketIOServer } = require('socket.io');

const ROOT = __dirname;
const PLAYER_SKINS_DIR = path.join(ROOT, 'skins', 'players');
const SKIN_DATA_FILE = path.join(ROOT, 'data', 'player-skins.json');
const MODEL_DATA_FILE = path.join(ROOT, 'data', 'player-models.json');
const MAX_SKIN_BYTES = 256 * 1024;
const RATE_LIMIT_WINDOW = 15 * 60 * 1000;
const RATE_LIMIT_MAX = 20;
const rateLimits = new Map();
const activePlayers = new Map(); // playerId -> { socket, state }
const recentPositions = new Map(); // conserva la posición brevemente durante reconexiones
let io = null;
let broadcastTimer = null;
let playerSkinChoices = Object.create(null);
let playerSkinModels = Object.create(null);

for (const dir of [PLAYER_SKINS_DIR, path.dirname(SKIN_DATA_FILE)]) {
  fs.mkdirSync(dir, { recursive: true });
}
try {
  const parsed = JSON.parse(fs.readFileSync(SKIN_DATA_FILE, 'utf8'));
  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) playerSkinChoices = parsed;
} catch (_) { }
try {
  const parsed = JSON.parse(fs.readFileSync(MODEL_DATA_FILE, 'utf8'));
  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) playerSkinModels = parsed;
} catch (_) { }

function hashId(userId) {
  return crypto.createHash('sha256').update(String(userId)).digest('hex');
}

function json(res, status, data) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
}

function setCors(req, res) {
  // Sin cookies ni credenciales cross-site: el token se envía explícitamente como Bearer.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Max-Age', '86400');
  res.setHeader('Vary', 'Origin');
}

function readBody(req, maxBytes = 8192) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', chunk => {
      total += chunk.length;
      if (total > maxBytes) {
        reject(Object.assign(new Error('El archivo o cuerpo supera el tamaño permitido.'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req, maxBytes = 8192) {
  const body = await readBody(req, maxBytes);
  if (!body.length) return {};
  try { return JSON.parse(body.toString('utf8')); }
  catch (_) { throw Object.assign(new Error('JSON inválido.'), { statusCode: 400 }); }
}

function getClientIp(req) {
  // X-Forwarded-For solo lo usa el rate-limit; la identidad nunca depende de esa cabecera.
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket?.remoteAddress || 'unknown';
}

function checkRateLimit(ip) {
  const now = Date.now();
  const entry = rateLimits.get(ip);
  if (!entry || now - entry.startedAt >= RATE_LIMIT_WINDOW) {
    rateLimits.set(ip, { startedAt: now, count: 1 });
    if (rateLimits.size > 5000) {
      for (const [key, value] of rateLimits) if (now - value.startedAt > RATE_LIMIT_WINDOW) rateLimits.delete(key);
    }
    return true;
  }
  if (entry.count >= RATE_LIMIT_MAX) return false;
  entry.count++;
  return true;
}

function findExactUserByApodo(input) {
  const wanted = String(input || '').trim().toLocaleLowerCase('es');
  if (!wanted || wanted.length > 32) return null;
  const users = global.db?.data?.users || {};
  let found = null;
  for (const [rawId, data] of Object.entries(users)) {
    const apodo = String(data?.apodo || '').trim();
    if (!apodo || ['sin apodo', '.', '-'].includes(apodo.toLowerCase())) continue;
    if (apodo.toLocaleLowerCase('es') !== wanted) continue;
    const userId = global.db?.getCanonicalId?.(rawId) || global.db?.cleanNumber?.(rawId) || rawId;
    if (found && found.userId !== userId) return { ambiguous: true };
    found = { userId: String(userId), apodo, data };
  }
  return found;
}

function getSessionFromRequest(req) {
  const header = String(req.headers.authorization || '');
  const match = header.match(/^Bearer\s+(.+)$/i);
  if (!match) return null;
  return gameAuth.getSession(match[1].trim());
}

function getSkinChoice(userId) {
  const choice = playerSkinChoices[String(userId)] || 'hombre/1';
  if (choice === 'custom') {
    const file = path.join(PLAYER_SKINS_DIR, `${hashId(userId)}.png`);
    if (fs.existsSync(file)) return `/game/skins/players/${hashId(userId)}.png`;
  }
  if (/^(hombre|mujer)\/[1-5]$/.test(choice)) return `/game/skins/${choice}.png`;
  return '/game/skins/hombre/1.png';
}

function saveSkinChoices() {
  const temp = `${SKIN_DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(playerSkinChoices));
  fs.renameSync(temp, SKIN_DATA_FILE);
}

function getSkinModel(userId) {
  return playerSkinModels[String(userId)] === 'slim' ? 'slim' : 'classic';
}

async function detectSkinModel(buffer) {
  try {
    const { data, info } = await sharp(buffer, { limitInputPixels: 4096 })
      .ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    if (info.width !== 64 || info.height !== 64 || info.channels !== 4) return 'classic';

    // Son los 64 texels que sólo utiliza el mapeo de brazos Classic (4 px).
    // Si están pintados, es evidencia mucho más fuerte que inspeccionar
    // franjas enteras del atlas, que pueden contener partes compartidas.
    const classicOnly = [
      [50, 16, 2, 4], [54, 20, 2, 12],
      [42, 48, 2, 4], [46, 52, 2, 12]
    ];
    let occupied = 0;
    let total = 0;
    for (const [x0, y0, width, height] of classicOnly) {
      for (let y = y0; y < y0 + height; y++) {
        for (let x = x0; x < x0 + width; x++) {
          if (data[(y * 64 + x) * 4 + 3] > 8) occupied++;
          total++;
        }
      }
    }
    // Slim/Classic no viene codificado en el PNG. Es una sugerencia; el
    // selector manual del vestuario sigue siendo la fuente de verdad.
    return total > 0 && occupied / total >= 0.2 ? 'classic' : 'slim';
  } catch (_) {
    return 'classic';
  }
}

async function ensureSkinModel(userId) {
  const key = String(userId);
  if (playerSkinModels[key] === 'classic' || playerSkinModels[key] === 'slim') return playerSkinModels[key];
  const choice = playerSkinChoices[key] || 'hombre/1';
  let file;
  if (choice === 'custom') file = path.join(PLAYER_SKINS_DIR, `${hashId(userId)}.png`);
  else if (/^(hombre|mujer)\/[1-5]$/.test(choice)) file = path.join(ROOT, 'skins', `${choice}.png`);
  if (!file || !fs.existsSync(file)) return 'classic';
  const model = await detectSkinModel(fs.readFileSync(file));
  playerSkinModels[key] = model;
  saveSkinModels();
  return model;
}

function saveSkinModels() {
  const temp = `${MODEL_DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(playerSkinModels));
  fs.renameSync(temp, MODEL_DATA_FILE);
}

function makePlayerPayload(session, socketId, position) {
  const userData = global.db?.getUser?.(session.userId) || {};
  const apodo = String(userData.apodo || session.apodo || 'Jugador').slice(0, 32);
  return {
    id: hashId(session.userId).slice(0, 20),
    apodo,
    skinUrl: getSkinChoice(session.userId),
    skinModel: getSkinModel(session.userId),
    x: position.x,
    y: 0,
    z: position.z,
    yaw: 0,
    pitch: 0,
    moving: false,
    socketId
  };
}

function isBlocked(x, z, radius = 0.24) {
  const b = WORLD.BOUNDS;
  if (x < -b + radius || x > b - radius || z < -b + radius || z > b - radius) return true;
  for (const block of WORLD.BLOCKERS) {
    const minX = block.x - block.w / 2 - radius;
    const maxX = block.x + block.w / 2 + radius;
    const minZ = block.z - block.d / 2 - radius;
    const maxZ = block.z + block.d / 2 + radius;
    if (x > minX && x < maxX && z > minZ && z < maxZ) return true;
  }
  return false;
}

function profileFor(targetUserId) {
  const db = global.db;
  const user = db?.getUser?.(targetUserId);
  if (!user) return null;
  let parejaApodo = 'Sin pareja';
  try {
    const pareja = db.getPareja?.(targetUserId);
    if (pareja?.estado === 'aceptado' && pareja.numero) {
      const partner = db.getUser(pareja.numero);
      if (partner?.apodo) parejaApodo = String(partner.apodo).slice(0, 32);
    }
  } catch (_) { }
  let clanNombre = 'Sin clan';
  try {
    const clan = db.getClanDeUsuario?.(targetUserId);
    if (clan?.nombre) clanNombre = String(clan.nombre).slice(0, 32);
  } catch (_) { }
  return {
    apodo: String(user.apodo || 'Jugador').slice(0, 32),
    rango: String(user.rango || '🌱 Novato').slice(0, 48),
    pareja: parejaApodo,
    dinero: Number(user.money) || 0,
    clan: clanNombre
  };
}

function broadcastState() {
  if (!io || activePlayers.size === 0) return;
  const players = [];
  for (const { state } of activePlayers.values()) {
    const { socketId, userId, ...publicState } = state;
    players.push(publicState);
  }
  io.to('world').volatile.emit('world:state', players);
}

function ensureBroadcastLoop() {
  if (broadcastTimer || activePlayers.size === 0) return;
  broadcastTimer = setInterval(broadcastState, 100);
  if (typeof broadcastTimer.unref === 'function') broadcastTimer.unref();
}

function attachSocketServer(server) {
  if (io) return io;
  io = new SocketIOServer(server, {
    path: '/game/socket.io',
    cors: { origin: '*', methods: ['GET', 'POST'], credentials: false },
    transports: ['websocket', 'polling'],
    maxHttpBufferSize: 128 * 1024,
    perMessageDeflate: false,
    pingInterval: 25000,
    pingTimeout: 20000
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    const session = gameAuth.getSession(token);
    if (!session) return next(new Error('Sesión de juego inválida o expirada.'));
    socket.data.gameSession = session;
    next();
  });

  io.on('connection', socket => {
    const session = socket.data.gameSession;
    const playerId = hashId(session.userId).slice(0, 20);
    const previous = activePlayers.get(playerId);
    const previousState = previous?.state || null;
    if (previous?.socket && previous.socket.id !== socket.id) previous.socket.disconnect(true);

    const recent = recentPositions.get(playerId);
    const canResume = previousState || (recent && Date.now() - recent.savedAt < 60_000 ? recent : null);
    const spawn = canResume ? { x: canResume.x, z: canResume.z } : [
      { x: -7, z: 14 }, { x: 7, z: 14 }, { x: -7, z: 18 }, { x: 7, z: 18 },
      { x: -12, z: 0 }, { x: 12, z: 0 }, { x: 0, z: 14 }, { x: 0, z: -12 }
    ][activePlayers.size % 8];
    const state = makePlayerPayload(session, socket.id, spawn);
    if (canResume) {
      state.y = Number(canResume.y) || 0;
      state.yaw = Number(canResume.yaw) || 0;
      state.pitch = Number(canResume.pitch) || 0;
      state.moving = false;
      recentPositions.delete(playerId);
    }
    state.userId = session.userId;
    activePlayers.set(playerId, { socket, state });
    socket.data.playerId = playerId;
    socket.join('world');

    const snapshot = [];
    for (const { state: other } of activePlayers.values()) {
      const { socketId, userId, ...pub } = other;
      snapshot.push(pub);
    }
    socket.emit('world:init', { self: playerId, players: snapshot });
    socket.to('world').volatile.emit('player:joined', (() => { const { socketId, userId, ...pub } = state; return pub; })());
    ensureBroadcastLoop();

    socket.on('player:state', data => {
      const entry = activePlayers.get(playerId);
      // Un socket anterior no puede actualizar el estado del socket que acaba
      // de reconectar con el mismo usuario; evita paquetes viejos que lo hagan retroceder.
      if (!entry || entry.socket?.id !== socket.id || !data || typeof data !== 'object') return;
      const now = Date.now();
      const rawElapsed = entry.state.lastPacketAt ? now - entry.state.lastPacketAt : 100;
      const elapsed = Math.max(20, Math.min(500, rawElapsed));
      const x = Number(data.x), z = Number(data.z), yaw = Number(data.yaw), pitch = Number(data.pitch);
      if (![x, z, yaw, pitch].every(Number.isFinite)) return;
      const dx = x - entry.state.x, dz = z - entry.state.z;
      // Margen frente a jitter/pérdida de paquetes: evita rechazar movimiento
      // legítimo cuando el navegador envía un estado con retraso de red.
      const maxDistance = Math.max(1.5, 9.5 * (elapsed / 1000) + 0.75);
      const distance = Math.hypot(dx, dz);
      if (distance > maxDistance) return;
      // La colisión se resuelve por ejes, igual que en el cliente. Si una
      // diagonal roza una pared, conserva el eje libre en vez de rechazar todo
      // el paquete y dejar atrás la posición del jugador.
      let acceptedX = entry.state.x;
      let acceptedZ = entry.state.z;
      const moveSteps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) / 0.06));
      const stepX = dx / moveSteps;
      const stepZ = dz / moveSteps;
      for (let step = 0; step < moveSteps; step++) {
        const nextX = acceptedX + stepX;
        if (!isBlocked(nextX, acceptedZ, 0.24)) acceptedX = nextX;
        const nextZ = acceptedZ + stepZ;
        if (!isBlocked(acceptedX, nextZ, 0.24)) acceptedZ = nextZ;
      }
      entry.state.x = acceptedX;
      entry.state.z = acceptedZ;
      entry.state.y = Math.max(0, Math.min(1.65, Number(data.y) || 0));
      entry.state.yaw = Math.atan2(Math.sin(yaw), Math.cos(yaw));
      entry.state.pitch = Math.max(-1.35, Math.min(1.35, pitch));
      entry.state.moving = Boolean(data.moving);
      entry.state.lastPacketAt = now;
    });

    socket.on('player:profile', (targetId, callback) => {
      const reply = typeof callback === 'function' ? callback : () => {};
      const target = activePlayers.get(String(targetId || ''));
      const selfEntry = activePlayers.get(playerId);
      const selfState = selfEntry?.state;
      if (selfEntry?.socket?.id !== socket.id || !target || !selfState) return reply({ ok: false, error: 'Ese jugador ya no está en el mundo.' });
      const distance = Math.hypot(target.state.x - selfState.x, target.state.z - selfState.z);
      if (distance > 4.5) return reply({ ok: false, error: 'Acercate un poco más para ver su perfil.' });
      const profile = profileFor(target.state.userId);
      if (!profile) return reply({ ok: false, error: 'No se encontró el perfil.' });
      return reply({ ok: true, profile });
    });

    socket.on('disconnect', () => {
      const current = activePlayers.get(playerId);
      if (current?.socket?.id === socket.id) {
        const last = current.state;
        recentPositions.set(playerId, {
          x: last.x, z: last.z, y: last.y, yaw: last.yaw, pitch: last.pitch,
          savedAt: Date.now()
        });
        // Limita el mapa de reconexión y expira posiciones antiguas.
        if (recentPositions.size > 2000) {
          const now = Date.now();
          for (const [id, position] of recentPositions) {
            if (now - position.savedAt > 60_000 || recentPositions.size > 1800) recentPositions.delete(id);
            if (recentPositions.size <= 1800) break;
          }
        }
        activePlayers.delete(playerId);
        io.to('world').volatile.emit('player:left', playerId);
      }
      if (activePlayers.size === 0 && broadcastTimer) {
        clearInterval(broadcastTimer);
        broadcastTimer = null;
      }
    });
  });
  return io;
}

function serveFile(res, filePath, contentType, cache = 'public, max-age=3600') {
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) throw new Error('not file');
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stat.size,
      'Cache-Control': cache,
      'X-Content-Type-Options': 'nosniff',
      'Cross-Origin-Resource-Policy': 'cross-origin'
    });
    fs.createReadStream(filePath).pipe(res);
  } catch (_) { json(res, 404, { error: 'Recurso no encontrado.' }); }
}

function getContentType(file) {
  if (file.endsWith('.html')) return 'text/html; charset=utf-8';
  if (file.endsWith('.js')) return 'text/javascript; charset=utf-8';
  if (file.endsWith('.css')) return 'text/css; charset=utf-8';
  if (file.endsWith('.png')) return 'image/png';
  return 'application/octet-stream';
}

async function handleApi(req, res, url) {
  if (req.method === 'POST' && url.pathname === '/game/api/login') {
    if (!checkRateLimit(getClientIp(req))) return json(res, 429, { error: 'Demasiadas solicitudes. Probá nuevamente en unos minutos.' });
    const body = await readJson(req, 4096);
    const found = findExactUserByApodo(body.apodo);
    if (!found) return json(res, 404, { error: 'No existe una cuenta con ese apodo exacto. Revisá cómo aparece escrito en el bot.' });
    if (found.ambiguous) return json(res, 409, { error: 'Ese apodo está asociado a más de una cuenta. Contactá al equipo del bot para resolverlo.' });
    const request = gameAuth.issueCode(found.userId, found.apodo);
    return json(res, 200, { success: true, ...request });
  }

  if (req.method === 'GET' && url.pathname === '/game/api/status') {
    const challenge = url.searchParams.get('challenge') || '';
    if (!/^[A-Za-z0-9_-]{40,60}$/.test(challenge)) return json(res, 400, { error: 'Solicitud de verificación inválida.' });
    const status = gameAuth.getStatus(challenge);
    if (status.status === 'expired') return json(res, 410, { status: 'expired', error: 'El código venció. Generá uno nuevo.' });
    return json(res, 200, { success: true, ...status });
  }

  if (req.method === 'POST' && url.pathname === '/game/api/logout') {
    const header = String(req.headers.authorization || '');
    const match = header.match(/^Bearer\s+(.+)$/i);
    if (match) gameAuth.revokeSession(match[1].trim());
    return json(res, 200, { success: true });
  }

  if (req.method === 'GET' && url.pathname === '/game/api/me') {
    const session = getSessionFromRequest(req);
    if (!session) return json(res, 401, { error: 'Sesión inválida o expirada.' });
    const user = global.db?.getUser?.(session.userId) || {};
    const skinModel = await ensureSkinModel(session.userId);
    return json(res, 200, {
      success: true,
      player: {
        id: hashId(session.userId).slice(0, 20),
        apodo: String(user.apodo || session.apodo || 'Jugador').slice(0, 32),
        skinUrl: getSkinChoice(session.userId),
        skinModel
      }
    });
  }

  if (req.method === 'POST' && url.pathname === '/game/api/skin/model') {
    const session = getSessionFromRequest(req);
    if (!session) return json(res, 401, { error: 'Sesión inválida o expirada.' });
    const body = await readJson(req, 4096);
    const model = String(body.model || '');
    if (!['classic', 'slim'].includes(model)) return json(res, 400, { error: 'Modelo de brazos inválido.' });
    playerSkinModels[String(session.userId)] = model;
    saveSkinModels();
    const playerId = hashId(session.userId).slice(0, 20);
    const active = activePlayers.get(playerId);
    if (active) {
      active.state.skinModel = model;
      io?.to('world').volatile.emit('player:model', { id: playerId, skinModel: model });
    }
    return json(res, 200, { success: true, skinModel: model });
  }

  if (req.method === 'POST' && url.pathname === '/game/api/skin/select') {
    const session = getSessionFromRequest(req);
    if (!session) return json(res, 401, { error: 'Sesión inválida o expirada.' });
    const body = await readJson(req, 4096);
    const skin = String(body.skin || '');
    if (!/^(hombre|mujer)\/[1-5]$/.test(skin)) return json(res, 400, { error: 'Skin predeterminada inválida.' });
    playerSkinChoices[session.userId] = skin;
    // Cada skin nueva obtiene una sugerencia Slim/Clásico según sus píxeles.
    const skinFile = path.join(ROOT, 'skins', `${skin}.png`);
    const detectedModel = await detectSkinModel(fs.readFileSync(skinFile));
    playerSkinModels[String(session.userId)] = detectedModel;
    // La skin personalizada anterior se elimina al cambiar de apariencia.
    try { fs.unlinkSync(path.join(PLAYER_SKINS_DIR, `${hashId(session.userId)}.png`)); } catch (_) { }
    saveSkinChoices();
    saveSkinModels();
    const playerId = hashId(session.userId).slice(0, 20);
    const active = activePlayers.get(playerId);
    if (active) {
      active.state.skinUrl = getSkinChoice(session.userId);
      active.state.skinModel = detectedModel;
      io?.to('world').volatile.emit('player:skin', { id: playerId, skinUrl: active.state.skinUrl, skinModel: detectedModel });
    }
    return json(res, 200, { success: true, skinUrl: getSkinChoice(session.userId), skinModel: detectedModel });
  }

  if (req.method === 'POST' && url.pathname === '/game/api/skin/upload') {
    const session = getSessionFromRequest(req);
    if (!session) return json(res, 401, { error: 'Sesión inválida o expirada.' });
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (type !== 'image/png') return json(res, 415, { error: 'Solo se admiten archivos PNG.' });
    const buffer = await readBody(req, MAX_SKIN_BYTES);
    const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    if (buffer.length < 24 || !buffer.subarray(0, 8).equals(signature) || buffer.toString('ascii', 12, 16) !== 'IHDR') {
      return json(res, 400, { error: 'El archivo no es un PNG válido.' });
    }
    let sanitized;
    try {
      const metadata = await sharp(buffer, { limitInputPixels: 4096 }).metadata();
      if (metadata.format !== 'png' || metadata.width !== 64 || metadata.height !== 64) return json(res, 400, { error: 'La skin debe ser PNG y medir exactamente 64 × 64 píxeles.' });
      sanitized = await sharp(buffer, { limitInputPixels: 4096 }).png().toBuffer();
    } catch (_) { return json(res, 400, { error: 'El PNG está dañado o no es una skin válida.' }); }
    const detectedModel = await detectSkinModel(sanitized);
    const filePath = path.join(PLAYER_SKINS_DIR, `${hashId(session.userId)}.png`);
    const tempPath = `${filePath}.${crypto.randomBytes(6).toString('hex')}.tmp`;
    fs.writeFileSync(tempPath, sanitized, { mode: 0o600 });
    fs.renameSync(tempPath, filePath);
    playerSkinChoices[session.userId] = 'custom';
    playerSkinModels[String(session.userId)] = detectedModel;
    saveSkinChoices();
    saveSkinModels();
    const playerId = hashId(session.userId).slice(0, 20);
    const active = activePlayers.get(playerId);
    const skinUrl = getSkinChoice(session.userId);
    if (active) {
      active.state.skinUrl = skinUrl;
      active.state.skinModel = detectedModel;
      io?.to('world').volatile.emit('player:skin', { id: playerId, skinUrl, skinModel: detectedModel });
    }
    return json(res, 200, { success: true, skinUrl, skinModel: detectedModel });
  }

  return json(res, 404, { error: 'Endpoint no encontrado.' });
}

function handleHttp(req, res) {
  const rawUrl = String(req.url || '/');
  if (!rawUrl.startsWith('/game')) return false;
  // Socket.IO administra por su cuenta el endpoint de transporte y el cliente JS.
  if (rawUrl.startsWith('/game/socket.io')) return false;
  setCors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return true; }
  let url;
  try { url = new URL(rawUrl, 'http://localhost'); }
  catch (_) { json(res, 400, { error: 'URL inválida.' }); return true; }

  if (url.pathname.startsWith('/game/api/')) {
    handleApi(req, res, url).catch(error => {
      if (!res.headersSent) json(res, error.statusCode || 500, { error: error.statusCode === 413 ? error.message : 'No se pudo procesar la solicitud.' });
    });
    return true;
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') { json(res, 405, { error: 'Método no permitido.' }); return true; }
  if (url.pathname === '/game' || url.pathname === '/game/' || url.pathname === '/game/index.html') {
    serveFile(res, path.join(ROOT, 'index.html'), 'text/html; charset=utf-8', 'no-store');
    return true;
  }
  if (url.pathname === '/game/client.js' || url.pathname === '/game/login.js' || url.pathname === '/game/style.css' || url.pathname === '/game/world.js') {
    const name = path.basename(url.pathname);
    const cachePolicy = name.endsWith('.js') ? 'no-store' : 'public, max-age=300';
    serveFile(res, path.join(ROOT, name), getContentType(name), cachePolicy);
    return true;
  }
  const skinMatch = url.pathname.match(/^\/game\/skins\/(hombre|mujer)\/([1-5])\.png$/);
  if (skinMatch) {
    serveFile(res, path.join(ROOT, 'skins', skinMatch[1], `${skinMatch[2]}.png`), 'image/png', 'public, max-age=86400, immutable');
    return true;
  }
  const playerSkinMatch = url.pathname.match(/^\/game\/skins\/players\/([a-f0-9]{64})\.png$/);
  if (playerSkinMatch) {
    serveFile(res, path.join(PLAYER_SKINS_DIR, `${playerSkinMatch[1]}.png`), 'image/png', 'private, max-age=60');
    return true;
  }
  json(res, 404, { error: 'Página o recurso no encontrado.' });
  return true;
}

function attach(server) {
  attachSocketServer(server);
}

module.exports = { attach, handleHttp, isBlocked, profileFor, getSkinChoice };
