/**
 * chatHistory.js
 * Historial de chat por grupo — almacenado en data/chats/chats-usuarios.db
 * 
 * Estructura por fila:
 *   group_id    → JID del grupo (ej: 1234567890@g.us)
 *   user_id     → número limpio del usuario (ej: 5491112345678)
 *   history     → texto del historial (últimos 4000 chars, recortado por el frente)
 *   msg_count   → total de mensajes enviados en ese grupo
 *   last_msg_ts → timestamp (ms) del último mensaje en ese grupo
 *
 * Tabla extra activity_hourly (para el comando .actividad):
 *   mensajes por grupo + usuario + hora (bucket = inicio de la hora en ms UTC)
 *
 * Tabla extra message_log (para el comando .resumen):
 *   texto de cada mensaje con su hora exacta, solo últimas ~50 horas
 *
 * Solo se guarda historial de mensajes de GRUPOS.
 * Los mensajes de bot o del propio bot NO se guardan aquí.
 */

'use strict';

const path = require('path');
const fs   = require('fs');

const DATA_DIR  = path.join(__dirname, 'data', 'chats');
const DB_PATH   = path.join(DATA_DIR, 'chats-usuarios.db');
const MAX_CHARS = 4000;

// Registro de mensajes con hora (para .resumen)
const LOG_RETENTION_MS = 50 * 3_600_000;   // se conservan ~50 horas
const LOG_MAX_TEXT     = 400;              // máx. caracteres guardados por mensaje
const LOG_CLEAN_EVERY  = 500;              // limpieza cada N mensajes guardados
let logInserts = 0;

let db = null;

// Identidades de las cuentas del bot y sus subbots. Se guardan también en SQLite
// para seguir excluyéndolas de los historiales aunque un subbot se desconecte.
const BOT_ID_CACHE_TTL_MS = 5000;
let botIdCache = new Set();
let botIdCacheAt = 0;
let botIdCacheSocketCount = -1;

// ── Inicialización ───────────────────────────────────────────────────────────

function init() {
    if (db) return; // ya inicializado

    // Crear carpeta si no existe
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    try {
        const Database = require('better-sqlite3');
        db = new Database(DB_PATH);

        // WAL mode: mejor rendimiento concurrente y .wal / .shm automáticos
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('cache_size = -4096'); // 4 MB de caché

        db.exec(`
            CREATE TABLE IF NOT EXISTS chat_history (
                group_id    TEXT NOT NULL,
                user_id     TEXT NOT NULL,
                history     TEXT NOT NULL DEFAULT '',
                msg_count   INTEGER NOT NULL DEFAULT 0,
                last_msg_ts INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (group_id, user_id)
            )
        `);

        // Índice por grupo para consultas rápidas
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_group ON chat_history (group_id)
        `);

        // Actividad por hora (para .actividad): una fila por grupo+usuario+hora
        db.exec(`
            CREATE TABLE IF NOT EXISTS activity_hourly (
                group_id TEXT NOT NULL,
                user_id  TEXT NOT NULL,
                bucket   INTEGER NOT NULL,
                count    INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (group_id, user_id, bucket)
            )
        `);
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_activity_group_bucket
            ON activity_hourly (group_id, bucket)
        `);
        // Registro de mensajes con hora (para .resumen)
        db.exec(`
            CREATE TABLE IF NOT EXISTS message_log (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id TEXT NOT NULL,
                user_id  TEXT NOT NULL,
                ts       INTEGER NOT NULL,
                text     TEXT NOT NULL
            )
        `);
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_log_group_ts
            ON message_log (group_id, ts)
        `);
        db.exec(`
            CREATE TABLE IF NOT EXISTS known_bot_ids (
                identity_id TEXT PRIMARY KEY,
                updated_at  INTEGER NOT NULL
            )
        `);
        db.prepare('DELETE FROM message_log WHERE ts < ?')
          .run(Date.now() - LOG_RETENTION_MS);

        // Limpiar datos de más de 35 días
        db.prepare('DELETE FROM activity_hourly WHERE bucket < ?')
          .run(Date.now() - 35 * 86_400_000);

        console.log('[ChatHistory] ✓ Base de datos inicializada en', DB_PATH);
    } catch (err) {
        console.error('[ChatHistory] ❌ Error iniciando DB:', err.message);
        db = null;
    }
}

// ── Helpers internos ─────────────────────────────────────────────────────────

/** Recorta el string para que no supere MAX_CHARS, conservando los últimos chars */
function trimHistory(existing, newText) {
    // Agregar separador solo si ya hay contenido
    const combined = existing
        ? existing + '\n' + newText
        : newText;

    if (combined.length <= MAX_CHARS) return combined;

    // Quedarse con los últimos MAX_CHARS caracteres
    return combined.slice(combined.length - MAX_CHARS);
}

function normalizeUserId(value) {
    if (value === null || value === undefined) return '';
    return String(value).split('@')[0].split(':')[0].replace(/\D/g, '').trim();
}

function canonicalUserId(value) {
    const clean = normalizeUserId(value);
    if (!clean) return '';
    try {
        return normalizeUserId(global.db?.getCanonicalId?.(clean)) || clean;
    } catch (_) {
        return clean;
    }
}

function addBotIdentity(set, value) {
    const clean = normalizeUserId(value);
    if (!clean) return;
    set.add(clean);
    const canonical = canonicalUserId(clean);
    if (canonical) set.add(canonical);
}

/**
 * Devuelve identidades de todas las sesiones conocidas (principal + subbots).
 * La lista se cachea 5 s para no recorrer cientos de sockets en cada mensaje.
 * Además se persisten para filtrar registros históricos aunque el subbot ya
 * no esté conectado cuando se ejecuta .resumen o .sobre.
 */
function getKnownBotIds() {
    const now = Date.now();
    const ids = new Set();
    const sockets = new Set();
    if (global.conn) sockets.add(global.conn);
    if (Array.isArray(global.subConns)) {
        for (const sock of global.subConns) if (sock) sockets.add(sock);
    }
    const lidMapSize = global.subbotLidMap instanceof Map ? global.subbotLidMap.size : 0;
    if (global.subbotLidMap instanceof Map) {
        for (const [lid, sock] of global.subbotLidMap.entries()) {
            addBotIdentity(ids, lid);
            if (sock) sockets.add(sock);
        }
    }

    const socketCount = sockets.size + lidMapSize;
    if (botIdCacheAt && now - botIdCacheAt < BOT_ID_CACHE_TTL_MS && socketCount === botIdCacheSocketCount) {
        return botIdCache;
    }

    addBotIdentity(ids, global.mainBotNumber);
    for (const sock of sockets) {
        const user = sock?.user || {};
        for (const identity of [user.id, user.jid, user.lid, user.phoneNumber, sock?._lid, sock?._phoneNumber]) {
            addBotIdentity(ids, identity);
        }
    }

    if (db) {
        try {
            const insert = db.prepare(`
                INSERT OR IGNORE INTO known_bot_ids (identity_id, updated_at)
                VALUES (?, ?)
            `);
            for (const id of ids) insert.run(id, now);

            const stored = db.prepare('SELECT identity_id FROM known_bot_ids').all();
            for (const row of stored) {
                const id = normalizeUserId(row.identity_id);
                if (id) ids.add(id);
            }
        } catch (err) {
            // El registro del historial no debe fallar si la tabla aún no está lista.
        }
    }

    botIdCache = ids;
    botIdCacheAt = now;
    botIdCacheSocketCount = socketCount;
    return botIdCache;
}

function isKnownBotUser(value) {
    const clean = normalizeUserId(value);
    if (!clean) return false;
    const known = getKnownBotIds();
    return known.has(clean) || known.has(canonicalUserId(clean));
}

function expandUserIds(values) {
    const input = Array.isArray(values) ? values : [values];
    const ids = new Set();
    for (const value of input) {
        const clean = normalizeUserId(value);
        if (!clean) continue;
        ids.add(clean);
        const canonical = canonicalUserId(clean);
        if (canonical) ids.add(canonical);
    }
    return [...ids].filter(id => !isKnownBotUser(id));
}

function isCommandText(text) {
    const value = typeof text === 'string' ? text.trim() : '';
    // Prefijos utilizados por el bot principal y los subbots.
    return /^(?:[.\/!#]\s*[a-z0-9]|❤️|👅|😎)/i.test(value);
}

// Statements preparados (lazy, se crean al primer uso)
let stmtGet, stmtUpsert, stmtBucket, stmtLog;

function getStmts() {
    if (!db) return null;

    if (!stmtGet) {
        stmtGet = db.prepare(`
            SELECT history, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ? AND user_id = ?
        `);
    }

    if (!stmtUpsert) {
        stmtUpsert = db.prepare(`
            INSERT INTO chat_history (group_id, user_id, history, msg_count, last_msg_ts)
            VALUES (?, ?, ?, 1, ?)
            ON CONFLICT(group_id, user_id) DO UPDATE SET
                history     = excluded.history,
                msg_count   = chat_history.msg_count + 1,
                last_msg_ts = excluded.last_msg_ts
        `);
    }

    if (!stmtBucket) {
        stmtBucket = db.prepare(`
            INSERT INTO activity_hourly (group_id, user_id, bucket, count)
            VALUES (?, ?, ?, 1)
            ON CONFLICT(group_id, user_id, bucket) DO UPDATE SET
                count = activity_hourly.count + 1
        `);
    }

    if (!stmtLog) {
        stmtLog = db.prepare(`
            INSERT INTO message_log (group_id, user_id, ts, text)
            VALUES (?, ?, ?, ?)
        `);
    }

    return { stmtGet, stmtUpsert, stmtBucket, stmtLog };
}

// ── API pública ──────────────────────────────────────────────────────────────

/**
 * Registra un mensaje de un usuario en un grupo.
 * Solo actúa si es un grupo (@g.us).
 * El registro guarda:
 *   - history: el texto del mensaje concatenado al final del historial del usuario,
 *     recortando los caracteres más antiguos cuando excede los 4000.
 *   - msg_count: la cantidad total de mensajes enviados en ese grupo.
 *   - last_msg_ts: la fecha/hora del último mensaje de ese usuario en el grupo.
 *   - activity_hourly: +1 en el contador de la hora del mensaje.
 *
 * Si `text` está vacío (sticker, imagen, audio sin caption), aún actualiza
 * msg_count y last_msg_ts, pero no agrega texto al historial.
 *
 * @param {string} groupId  - JID del grupo
 * @param {string} userId   - número limpio del usuario
 * @param {string} [text]   - texto del mensaje (opcional)
 * @param {number} [timestamp] - timestamp del mensaje en ms (opcional)
 */
function recordMessage(groupId, userId, text, timestamp) {
    if (!db) init();
    if (!db) return; // falló la inicialización

    if (!groupId || !groupId.endsWith('@g.us')) return;
    const cleanUserId = normalizeUserId(userId);
    if (!cleanUserId) return;

    // Un subbot visto desde otra sesión llega como un mensaje entrante normal.
    // Excluirlo por identidad, no solo por key.fromMe (que no alcanza en multi-sesión).
    if (isKnownBotUser(cleanUserId)) return;

    try {
        const stmts = getStmts();
        if (!stmts) return;

        // Unifica LID y número real cuando database.js ya conoce el alias.
        const storageUserId = canonicalUserId(cleanUserId) || cleanUserId;
        const row      = stmtGet.get(groupId, storageUserId);
        const existing = row ? row.history : '';
        const now      = (typeof timestamp === 'number' && timestamp > 0) ? timestamp : Date.now();

        // Los comandos del usuario cuentan para actividad, pero no forman parte
        // del historial conversacional que consumen .sobre y .resumen.
        const cleanText = (text && typeof text === 'string') ? text.trim() : '';
        const isCommand = isCommandText(cleanText);
        const newHistory = cleanText && !isCommand ? trimHistory(existing, cleanText) : existing;

        stmtUpsert.run(groupId, storageUserId, newHistory, now);

        // Contador por hora (inicio de la hora en ms UTC)
        stmtBucket.run(groupId, storageUserId, Math.floor(now / 3_600_000) * 3_600_000);

        // message_log solo contiene mensajes conversacionales, nunca comandos ni bots.
        if (cleanText && !isCommand) {
            stmtLog.run(groupId, storageUserId, now, cleanText.slice(0, LOG_MAX_TEXT));
            if (++logInserts % LOG_CLEAN_EVERY === 0) {
                db.prepare('DELETE FROM message_log WHERE ts < ?')
                  .run(Date.now() - LOG_RETENTION_MS);
            }
        }
    } catch (err) {
        console.error('[ChatHistory] Error guardando mensaje:', err.message);
    }
}

/**
 * Registra presencia de un usuario en un grupo sin texto (sticker, imagen, audio).
 * Alias semántico de recordMessage sin texto.
 *
 * @param {string} groupId
 * @param {string} userId
 */
function recordPresence(groupId, userId, timestamp) {
    recordMessage(groupId, userId, '', timestamp);
}

/**
 * Obtiene el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 * @returns {{ history: string, msgCount: number, lastMsgTs: number } | null}
 */
function getUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return null;
    if (!groupId || !groupId.endsWith('@g.us')) return null;

    try {
        const userIds = expandUserIds(userId);
        if (!userIds.length) return null;

        const placeholders = userIds.map(() => '?').join(', ');
        const rows = db.prepare(`
            SELECT user_id, history, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ?
              AND user_id IN (${placeholders})
              AND user_id NOT IN (SELECT identity_id FROM known_bot_ids)
            ORDER BY last_msg_ts ASC
        `).all(groupId, ...userIds);
        if (!rows.length) return null;

        // Puede haber historial antiguo guardado bajo el LID y otro bajo el
        // teléfono. Se recuperan ambos sin duplicar bloques idénticos.
        const historyParts = [...new Set(rows
            .map(row => String(row.history || '').trim())
            .filter(Boolean))];
        const history = historyParts.join('\n');
        if (!history) return null;

        return {
            history,
            msgCount: rows.reduce((total, row) => total + (Number(row.msg_count) || 0), 0),
            lastMsgTs: Math.max(...rows.map(row => Number(row.last_msg_ts) || 0))
        };
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo historial:', err.message);
        return null;
    }
}

/**
 * Obtiene todos los usuarios de un grupo con sus stats.
 * 
 * @param {string} groupId
 * @returns {Array<{ userId: string, msgCount: number, lastMsgTs: number }>}
 */
function getGroupStats(groupId) {
    if (!db) init();
    if (!db) return [];

    try {
        const stmt = db.prepare(`
            SELECT user_id, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ?
            ORDER BY msg_count DESC
        `);
        return stmt.all(groupId).map(r => ({
            userId:    r.user_id,
            msgCount:  r.msg_count,
            lastMsgTs: r.last_msg_ts
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo stats del grupo:', err.message);
        return [];
    }
}

/**
 * Mensajes por hora de un grupo desde `sinceTs` (ms).
 *
 * @param {string} groupId
 * @param {number} sinceTs
 * @returns {Array<{ userId: string, bucket: number, count: number }>}
 */
function getActivityBuckets(groupId, sinceTs) {
    if (!db) init();
    if (!db) return [];

    try {
        return db.prepare(`
            SELECT user_id, bucket, count
            FROM activity_hourly
            WHERE group_id = ? AND bucket >= ?
        `).all(groupId, sinceTs).map(r => ({
            userId: r.user_id,
            bucket: r.bucket,
            count:  r.count
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo actividad:', err.message);
        return [];
    }
}

/**
 * Mensajes de texto de un grupo desde `sinceTs` (ms), del más viejo al más nuevo.
 * Solo existen los de las últimas ~50 horas y desde que se activó este registro.
 *
 * @param {string} groupId
 * @param {number} sinceTs
 * @param {number} [limit=8000]
 * @returns {Array<{ userId: string, ts: number, text: string }>}
 */
function getRecentMessages(groupId, sinceTs, limit = 8000) {
    if (!db) init();
    if (!db) return [];

    try {
        // Sincroniza las identidades activas antes de consultar el log antiguo.
        getKnownBotIds();
        return db.prepare(`
            SELECT user_id, ts, text
            FROM (
                SELECT user_id, ts, text
                FROM message_log
                WHERE group_id = ?
                  AND ts >= ?
                  AND user_id NOT IN (SELECT identity_id FROM known_bot_ids)
                ORDER BY ts DESC
                LIMIT ?
            )
            ORDER BY ts ASC
        `).all(groupId, sinceTs, limit).map(r => ({
              userId: r.user_id,
              ts:     r.ts,
              text:   r.text
          }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo mensajes recientes:', err.message);
        return [];
    }
}

/**
 * Borra el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 */
function clearUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return;

    try {
        db.prepare('DELETE FROM chat_history WHERE group_id = ? AND user_id = ?')
          .run(groupId, userId);
    } catch (err) {
        console.error('[ChatHistory] Error borrando historial:', err.message);
    }
}

/**
 * Cierra la conexión a la base de datos limpiamente.
 * Útil al hacer graceful shutdown.
 */
function close() {
    if (db) {
        try { db.close(); } catch (_) {}
        db = null;
        stmtGet    = null;
        stmtUpsert = null;
        stmtBucket = null;
        stmtLog    = null;
        botIdCache = new Set();
        botIdCacheAt = 0;
        botIdCacheSocketCount = -1;
    }
}

// Inicializar al cargar el módulo
init();

module.exports = {
    recordMessage,
    recordPresence,
    getUserHistory,
    getGroupStats,
    getActivityBuckets,
    getRecentMessages,
    clearUserHistory,
    isKnownBotUser,
    expandUserIds,
    close,
    get isReady() { return !!db; }
};
