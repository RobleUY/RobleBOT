/**
 * chatHistory.js
 * Historial de chat por grupo — almacenado en data/chats/chats-usuarios.db
 * 
 * Estructura por fila:
 *   group_id    → JID del grupo (ej: 1234567890@g.us)
 *   user_id     → número limpio del usuario (ej: 5491112345678)
 *   history     → texto del historial (últimos 4000 chars, recortado por el frente)
 *   msg_count   → total de mensajes enviados en ese grupo
 *   last_msg_ts → timestamp (ms) del último mensaje en ese grupo
 *
 * Tabla extra activity_hourly (para el comando .actividad):
 *   mensajes por grupo + usuario + hora (bucket = inicio de la hora en ms UTC)
 *
 * Tabla extra message_log (para el comando .resumen):
 *   texto de cada mensaje con su hora exacta, solo últimas ~50 horas
 *
 * Solo se guarda historial de mensajes de GRUPOS.
 * Los mensajes de bot o del propio bot NO se guardan aquí.
 */

'use strict';

const path = require('path');
const fs   = require('fs');

const DATA_DIR  = path.join(__dirname, 'data', 'chats');
const DB_PATH   = path.join(DATA_DIR, 'chats-usuarios.db');
const MAX_CHARS = 4000;

// Registro de mensajes con hora (para .resumen)
const LOG_RETENTION_MS = 50 * 3_600_000;   // se conservan ~50 horas
const LOG_MAX_TEXT     = 400;              // máx. caracteres guardados por mensaje
const LOG_CLEAN_EVERY  = 500;              // limpieza cada N mensajes guardados
let logInserts = 0;

let db = null;

// ── Inicialización ───────────────────────────────────────────────────────────

function init() {
    if (db) return; // ya inicializado

    // Crear carpeta si no existe
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    try {
        const Database = require('better-sqlite3');
        db = new Database(DB_PATH);

        // WAL mode: mejor rendimiento concurrente y .wal / .shm automáticos
        db.pragma('journal_mode = WAL');
        db.pragma('synchronous = NORMAL');
        db.pragma('cache_size = -4096'); // 4 MB de caché

        db.exec(`
            CREATE TABLE IF NOT EXISTS chat_history (
                group_id    TEXT NOT NULL,
                user_id     TEXT NOT NULL,
                history     TEXT NOT NULL DEFAULT '',
                msg_count   INTEGER NOT NULL DEFAULT 0,
                last_msg_ts INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (group_id, user_id)
            )
        `);

        // Índice por grupo para consultas rápidas
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_group ON chat_history (group_id)
        `);

        // Actividad por hora (para .actividad): una fila por grupo+usuario+hora
        db.exec(`
            CREATE TABLE IF NOT EXISTS activity_hourly (
                group_id TEXT NOT NULL,
                user_id  TEXT NOT NULL,
                bucket   INTEGER NOT NULL,
                count    INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (group_id, user_id, bucket)
            )
        `);
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_activity_group_bucket
            ON activity_hourly (group_id, bucket)
        `);
        // Registro de mensajes con hora (para .resumen)
        db.exec(`
            CREATE TABLE IF NOT EXISTS message_log (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id TEXT NOT NULL,
                user_id  TEXT NOT NULL,
                ts       INTEGER NOT NULL,
                text     TEXT NOT NULL
            )
        `);
        db.exec(`
            CREATE INDEX IF NOT EXISTS idx_log_group_ts
            ON message_log (group_id, ts)
        `);
        db.prepare('DELETE FROM message_log WHERE ts < ?')
          .run(Date.now() - LOG_RETENTION_MS);

        // Limpiar datos de más de 35 días
        db.prepare('DELETE FROM activity_hourly WHERE bucket < ?')
          .run(Date.now() - 35 * 86_400_000);

        console.log('[ChatHistory] ✓ Base de datos inicializada en', DB_PATH);
    } catch (err) {
        console.error('[ChatHistory] ❌ Error iniciando DB:', err.message);
        db = null;
    }
}

// ── Helpers internos ─────────────────────────────────────────────────────────

/** Recorta el string para que no supere MAX_CHARS, conservando los últimos chars */
function trimHistory(existing, newText) {
    // Agregar separador solo si ya hay contenido
    const combined = existing
        ? existing + '\n' + newText
        : newText;

    if (combined.length <= MAX_CHARS) return combined;

    // Quedarse con los últimos MAX_CHARS caracteres
    return combined.slice(combined.length - MAX_CHARS);
}

// Statements preparados (lazy, se crean al primer uso)
let stmtGet, stmtUpsert, stmtBucket, stmtLog;

function getStmts() {
    if (!db) return null;

    if (!stmtGet) {
        stmtGet = db.prepare(`
            SELECT history, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ? AND user_id = ?
        `);
    }

    if (!stmtUpsert) {
        stmtUpsert = db.prepare(`
            INSERT INTO chat_history (group_id, user_id, history, msg_count, last_msg_ts)
            VALUES (?, ?, ?, 1, ?)
            ON CONFLICT(group_id, user_id) DO UPDATE SET
                history     = excluded.history,
                msg_count   = chat_history.msg_count + 1,
                last_msg_ts = excluded.last_msg_ts
        `);
    }

    if (!stmtBucket) {
        stmtBucket = db.prepare(`
            INSERT INTO activity_hourly (group_id, user_id, bucket, count)
            VALUES (?, ?, ?, 1)
            ON CONFLICT(group_id, user_id, bucket) DO UPDATE SET
                count = activity_hourly.count + 1
        `);
    }

    if (!stmtLog) {
        stmtLog = db.prepare(`
            INSERT INTO message_log (group_id, user_id, ts, text)
            VALUES (?, ?, ?, ?)
        `);
    }

    return { stmtGet, stmtUpsert, stmtBucket, stmtLog };
}

// ── API pública ──────────────────────────────────────────────────────────────

/**
 * Registra un mensaje de un usuario en un grupo.
 * Solo actúa si es un grupo (@g.us).
 * El registro guarda:
 *   - history: el texto del mensaje concatenado al final del historial del usuario,
 *     recortando los caracteres más antiguos cuando excede los 4000.
 *   - msg_count: la cantidad total de mensajes enviados en ese grupo.
 *   - last_msg_ts: la fecha/hora del último mensaje de ese usuario en el grupo.
 *   - activity_hourly: +1 en el contador de la hora del mensaje.
 *
 * Si `text` está vacío (sticker, imagen, audio sin caption), aún actualiza
 * msg_count y last_msg_ts, pero no agrega texto al historial.
 *
 * @param {string} groupId  - JID del grupo
 * @param {string} userId   - número limpio del usuario
 * @param {string} [text]   - texto del mensaje (opcional)
 * @param {number} [timestamp] - timestamp del mensaje en ms (opcional)
 */
function recordMessage(groupId, userId, text, timestamp) {
    if (!db) init();
    if (!db) return; // falló la inicialización

    if (!groupId || !groupId.endsWith('@g.us')) return;
    if (!userId) return;

    try {
        const stmts = getStmts();
        if (!stmts) return;

        const row      = stmtGet.get(groupId, userId);
        const existing = row ? row.history : '';
        const now      = (typeof timestamp === 'number' && timestamp > 0) ? timestamp : Date.now();

        // Solo agregar texto si hay contenido textual real
        const cleanText = (text && typeof text === 'string') ? text.trim() : '';
        const newHistory = cleanText ? trimHistory(existing, cleanText) : existing;

        stmtUpsert.run(groupId, userId, newHistory, now);

        // Contador por hora (inicio de la hora en ms UTC)
        stmtBucket.run(groupId, userId, Math.floor(now / 3_600_000) * 3_600_000);

        // Texto con hora exacta (para .resumen). Se ignoran comandos del bot (.play, /x, !x, #x)
        if (cleanText && !/^[.\/!#][a-zA-Z0-9]/.test(cleanText)) {
            stmtLog.run(groupId, userId, now, cleanText.slice(0, LOG_MAX_TEXT));
            if (++logInserts % LOG_CLEAN_EVERY === 0) {
                db.prepare('DELETE FROM message_log WHERE ts < ?')
                  .run(Date.now() - LOG_RETENTION_MS);
            }
        }
    } catch (err) {
        console.error('[ChatHistory] Error guardando mensaje:', err.message);
    }
}

/**
 * Registra presencia de un usuario en un grupo sin texto (sticker, imagen, audio).
 * Alias semántico de recordMessage sin texto.
 *
 * @param {string} groupId
 * @param {string} userId
 */
function recordPresence(groupId, userId, timestamp) {
    recordMessage(groupId, userId, '', timestamp);
}

/**
 * Obtiene el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 * @returns {{ history: string, msgCount: number, lastMsgTs: number } | null}
 */
function getUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return null;

    try {
        const stmts = getStmts();
        if (!stmts) return null;

        const row = stmtGet.get(groupId, userId);
        if (!row) return null;

        return {
            history:    row.history,
            msgCount:   row.msg_count,
            lastMsgTs:  row.last_msg_ts
        };
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo historial:', err.message);
        return null;
    }
}

/**
 * Obtiene todos los usuarios de un grupo con sus stats.
 * 
 * @param {string} groupId
 * @returns {Array<{ userId: string, msgCount: number, lastMsgTs: number }>}
 */
function getGroupStats(groupId) {
    if (!db) init();
    if (!db) return [];

    try {
        const stmt = db.prepare(`
            SELECT user_id, msg_count, last_msg_ts
            FROM chat_history
            WHERE group_id = ?
            ORDER BY msg_count DESC
        `);
        return stmt.all(groupId).map(r => ({
            userId:    r.user_id,
            msgCount:  r.msg_count,
            lastMsgTs: r.last_msg_ts
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo stats del grupo:', err.message);
        return [];
    }
}

/**
 * Mensajes por hora de un grupo desde `sinceTs` (ms).
 *
 * @param {string} groupId
 * @param {number} sinceTs
 * @returns {Array<{ userId: string, bucket: number, count: number }>}
 */
function getActivityBuckets(groupId, sinceTs) {
    if (!db) init();
    if (!db) return [];

    try {
        return db.prepare(`
            SELECT user_id, bucket, count
            FROM activity_hourly
            WHERE group_id = ? AND bucket >= ?
        `).all(groupId, sinceTs).map(r => ({
            userId: r.user_id,
            bucket: r.bucket,
            count:  r.count
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo actividad:', err.message);
        return [];
    }
}

/**
 * Mensajes de texto de un grupo desde `sinceTs` (ms), del más viejo al más nuevo.
 * Solo existen los de las últimas ~50 horas y desde que se activó este registro.
 *
 * @param {string} groupId
 * @param {number} sinceTs
 * @param {number} [limit=8000]
 * @returns {Array<{ userId: string, ts: number, text: string }>}
 */
function getRecentMessages(groupId, sinceTs, limit = 8000) {
    if (!db) init();
    if (!db) return [];

    try {
        return db.prepare(`
            SELECT user_id, ts, text
            FROM (
                SELECT user_id, ts, text
                FROM message_log
                WHERE group_id = ? AND ts >= ?
                ORDER BY ts DESC
                LIMIT ?
            )
            ORDER BY ts ASC
        `).all(groupId, sinceTs, limit).map(r => ({
            userId: r.user_id,
            ts:     r.ts,
            text:   r.text
        }));
    } catch (err) {
        console.error('[ChatHistory] Error obteniendo mensajes recientes:', err.message);
        return [];
    }
}

/**
 * Borra el historial de un usuario en un grupo.
 * 
 * @param {string} groupId
 * @param {string} userId
 */
function clearUserHistory(groupId, userId) {
    if (!db) init();
    if (!db) return;

    try {
        db.prepare('DELETE FROM chat_history WHERE group_id = ? AND user_id = ?')
          .run(groupId, userId);
    } catch (err) {
        console.error('[ChatHistory] Error borrando historial:', err.message);
    }
}

/**
 * Cierra la conexión a la base de datos limpiamente.
 * Útil al hacer graceful shutdown.
 */
function close() {
    if (db) {
        try { db.close(); } catch (_) {}
        db = null;
        stmtGet    = null;
        stmtUpsert = null;
        stmtBucket = null;
        stmtLog    = null;
    }
}

// Inicializar al cargar el módulo
init();

module.exports = {
    recordMessage,
    recordPresence,
    getUserHistory,
    getGroupStats,
    getActivityBuckets,
    getRecentMessages,
    clearUserHistory,
    close,
    get isReady() { return !!db; }
};
