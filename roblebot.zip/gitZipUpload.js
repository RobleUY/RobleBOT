const axios = require('axios');
const fs = require('fs');
const archiver = require('archiver');
const path = require('path');
const moment = require('moment-timezone');

// BANDERA para controlar que solo se ejecute UNA VEZ al iniciar
let backupRealizado = false;

/**
 * Crea un ZIP de los archivos publicados y devuelve sus rutas internas.
 */
function createZip(outputPath) {
    return new Promise((resolve, reject) => {
        const output = fs.createWriteStream(outputPath);
        const archive = archiver('zip', { zlib: { level: 1 } });

        output.on('close', () => resolve(outputPath));
        output.on('error', reject);
        archive.on('error', reject);
        archive.on('warning', (err) => {
            if (err.code !== 'ENOENT') reject(err);
        });

        archive.pipe(output);
        archive.glob('**/*', {
            cwd: __dirname,
            ignore: [
                'node_modules/**',
                'database.db',
                'database.db-shm',
                'database.db-wal',
                'main-session.db',
                'main-session.db-shm',
                'main-session.db-wal',
                'backup_*.zip',
                'backup_temp_*.zip',
                'bot-backup.zip',
                'roblebot.zip',
                '.git/**',
                '.env',
                'data/chats/**',
                'data/**/*.opus',
                'data/**/*.ogg',
                'data/**/*.mp3',
                'CHATS-USUARIOS/**',
                '*.log',
                'tmp/**',
                'logs/**',
                'plugins/tmp/**',
                'plugins/DESCARGADORES/descargas/**',
                'plugins/DESCARGADORES/.temp/**',
                'plugins/SUBBOTS/sesiones/**',
                '**/.temp/**',
                '**/*.mp4',
                '**/*.mp3',
                '**/*.webm',
                '**/*.mkv',
                '**/*.avi'
            ]
        });

        archive.finalize();
    });
}

function updateReadmeSize(readme, zipSize) {
    const sizeMarker = /<!-- ZIP_SIZE -->.*?<!-- \/ZIP_SIZE -->/;
    if (!sizeMarker.test(readme)) {
        throw new Error('Falta el marcador ZIP_SIZE en readme.md');
    }

    const sizeInMb = (zipSize / 1024 / 1024).toFixed(2);
    return readme.replace(
        sizeMarker,
        `<!-- ZIP_SIZE -->${sizeInMb} MB<!-- /ZIP_SIZE -->`
    );
}

/**
 * Publica únicamente el README actualizado y el ZIP.
 */
async function uploadToGithub(zipPath, config) {
    const { token, owner, repo, branch } = config;
    if (!token || !owner || !repo || !branch) {
        throw new Error('Falta configurar GITHUB_TOKEN, GITHUB_OWNER, GITHUB_REPO o GITHUB_BRANCH');
    }

    const apiUrl = `https://api.github.com/repos/${owner}/${repo}`;
    const headers = {
        Authorization: `Bearer ${token.trim()}`,
        Accept: 'application/vnd.github+json'
    };
    const requestOptions = {
        headers,
        timeout: 300000,
        maxContentLength: 150 * 1024 * 1024,
        maxBodyLength: 150 * 1024 * 1024
    };
    const encodedBranch = encodeURIComponent(branch);
    const { data: reference } = await axios.get(
        `${apiUrl}/git/ref/heads/${encodedBranch}`,
        requestOptions
    );
    const readme = fs.readFileSync(path.join(__dirname, 'readme.md'), 'utf8');
    const { data: zipBlob } = await axios.post(
        `${apiUrl}/git/blobs`,
        {
            content: fs.readFileSync(zipPath).toString('base64'),
            encoding: 'base64'
        },
        requestOptions
    );
    const { data: createdTree } = await axios.post(
        `${apiUrl}/git/trees`,
        {
            tree: [
                { path: 'readme.md', mode: '100644', type: 'blob', content: readme },
                { path: 'roblebot.zip', mode: '100644', type: 'blob', sha: zipBlob.sha }
            ]
        },
        requestOptions
    );
    const { data: commit } = await axios.post(
        `${apiUrl}/git/commits`,
        {
            message: `Backup ${moment().tz('America/Montevideo').format('YYYY-MM-DD HH:mm:ss')}`,
            tree: createdTree.sha,
            parents: [reference.object.sha]
        },
        requestOptions
    );

    await axios.patch(
        `${apiUrl}/git/refs/heads/${encodedBranch}`,
        { sha: commit.sha },
        requestOptions
    );
}

/**
 * FUNCIÓN PRINCIPAL - Solo se ejecuta UNA VEZ al iniciar
 */
async function backupToGithub() {
    if (backupRealizado) {
        console.log('⏭️  Backup ya realizado en esta sesión');
        return false;
    }

    const BACKUP_TIMEOUT_MS = 3 * 60 * 1000;
    let timeoutId;
    const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Timeout global de backup (3 min)')), BACKUP_TIMEOUT_MS);
    });

    try {
        return await Promise.race([_doBackup(), timeoutPromise]);
    } finally {
        clearTimeout(timeoutId);
    }
}

async function _doBackup() {
    require('dotenv').config();

    try {
        const oldZips = fs.readdirSync(__dirname).filter((file) => /^backup_temp_.*\.zip$/.test(file));
        for (const oldZip of oldZips) {
            fs.unlinkSync(path.join(__dirname, oldZip));
            console.log(`🗑️ Limpiando zip anterior: ${oldZip}`);
        }
    } catch (error) {
        console.warn('⚠️ No se pudieron limpiar todos los ZIP temporales:', error.message);
    }

    const timestamp = moment().tz('America/Montevideo').format('YYYY-MM-DD_HH-mm-ss');
    const zipPath = path.join(__dirname, `backup_temp_${timestamp}.zip`);

    try {
        console.log('🗜️ Ejecutando backup...');
        const readmePath = path.join(__dirname, 'readme.md');
        let readme = fs.readFileSync(readmePath, 'utf8');
        let readmeSizeUpdated = false;

        for (let attempt = 0; attempt < 10; attempt++) {
            console.log('🗜️ Creando ZIP...');
            await createZip(zipPath);
            const updatedReadme = updateReadmeSize(readme, fs.statSync(zipPath).size);

            if (updatedReadme === readme) {
                readmeSizeUpdated = true;
                break;
            }

            fs.writeFileSync(readmePath, updatedReadme, 'utf8');
            readme = updatedReadme;
        }

        if (!readmeSizeUpdated) {
            throw new Error('No se pudo estabilizar el tamaño del ZIP en el README');
        }

        const config = {
            token: process.env.GITHUB_TOKEN,
            owner: process.env.GITHUB_OWNER,
            repo: process.env.GITHUB_REPO,
            branch: process.env.GITHUB_BRANCH || 'main'
        };

        console.log('📤 Subiendo roblebot.zip y readme.md a GitHub...');
        await uploadToGithub(zipPath, config);
        console.log('✅ Backup completado exitosamente');

        backupRealizado = true;
        fs.unlinkSync(zipPath);
        console.log('🗑️ ZIP local eliminado');

        return true;
    } catch (error) {
        const details = error.response && error.response.data;
        console.error(
            '❌ Error en backup:',
            error.message,
            details ? JSON.stringify(details) : ''
        );

        if (fs.existsSync(zipPath)) {
            fs.unlinkSync(zipPath);
        }

        return false;
    }
}

/**
 * Resetear bandera (útil si necesitas hacer backup manual)
 */
function resetBackupFlag() {
    backupRealizado = false;
    console.log('🔄 Bandera de backup reseteada');
}

module.exports = {
    backupToGithub,
    resetBackupFlag
};

if (require.main === module) {
    backupToGithub();
}
