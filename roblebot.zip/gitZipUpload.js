const axios = require('axios');
const fs = require('fs');
const archiver = require('archiver');
const path = require('path');
const moment = require('moment-timezone');

// BANDERA para controlar que solo se ejecute UNA VEZ al iniciar
let backupRealizado = false;

/**
 * Crea un ZIP de los archivos publicados y devuelve sus rutas internas.
 */
function createZip(outputPath) {
    return new Promise((resolve, reject) => {
        const output = fs.createWriteStream(outputPath);
        const archive = archiver('zip', { zlib: { level: 1 } });
        const files = [];

        output.on('close', () => resolve(files));
        output.on('error', reject);
        archive.on('error', reject);
        archive.on('warning', (err) => {
            if (err.code !== 'ENOENT') reject(err);
        });
        archive.on('entry', (entry) => {
            if (entry.type === 'file') files.push(entry.name);
        });

        archive.pipe(output);
        archive.glob('**/*', {
            cwd: __dirname,
            ignore: [
                'node_modules/**',
                'database.db',
                'database.db-shm',
                'database.db-wal',
                'main-session.db',
                'main-session.db-shm',
                'main-session.db-wal',
                'backup_*.zip',
                'backup_temp_*.zip',
                'bot-backup.zip',
                'roblebot.zip',
                '.git/**',
                '.env',
                'data/chats/**',
                'data/**/*.opus',
                'data/**/*.ogg',
                'data/**/*.mp3',
                'CHATS-USUARIOS/**',
                '*.log',
                'tmp/**',
                'logs/**',
                'plugins/tmp/**',
                'plugins/DESCARGADORES/descargas/**',
                'plugins/DESCARGADORES/.temp/**',
                'plugins/SUBBOTS/sesiones/**',
                '**/.temp/**',
                '**/*.mp4',
                '**/*.mp3',
                '**/*.webm',
                '**/*.mkv',
                '**/*.avi'
            ]
        });

        archive.finalize();
    });
}

function updateReadmeSize(readme, zipSize) {
    const sizeLine = `Peso del archivo .zip del bot: ${zipSize} bytes (${(zipSize / 1024 / 1024).toFixed(2)} MB)`;
    const readmeLine = /^Peso del archivo \.zip del bot:.*$/m;

    if (readmeLine.test(readme)) {
        return readme.replace(readmeLine, sizeLine);
    }

    return `${readme.trimEnd()}\n\n${sizeLine}\n`;
}

/**
 * Publica los archivos y el ZIP como una única instantánea del repositorio.
 */
async function uploadToGithub(zipPath, files, config) {
    const { token, owner, repo, branch } = config;
    const apiUrl = `https://api.github.com/repos/${owner}/${repo}`;
    const headers = {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json'
    };
    const requestOptions = {
        headers,
        timeout: 300000,
        maxContentLength: 150 * 1024 * 1024,
        maxBodyLength: 150 * 1024 * 1024
    };
    const encodedBranch = encodeURIComponent(branch);
    const { data: reference } = await axios.get(
        `${apiUrl}/git/ref/heads/${encodedBranch}`,
        requestOptions
    );
    const filesToUpload = files.map((fileName) => ({
        name: fileName.replace(/\\/g, '/'),
        filePath: path.join(__dirname, ...fileName.split(/[\\/]/))
    }));
    filesToUpload.push({ name: 'roblebot.zip', filePath: zipPath });

    const commitFiles = async (filesToCommit) => {
        const tree = [];
        for (const file of filesToCommit) {
            const content = fs.readFileSync(file.filePath);
            const text = content.toString('utf8');
            const isText = !content.includes(0) && Buffer.from(text, 'utf8').equals(content);
            const item = { path: file.name, mode: '100644', type: 'blob' };

            if (isText && content.length <= 1024 * 1024) {
                item.content = text;
            } else {
                const { data: blob } = await axios.post(
                    `${apiUrl}/git/blobs`,
                    { content: content.toString('base64'), encoding: 'base64' },
                    requestOptions
                );
                item.sha = blob.sha;
            }

            tree.push(item);
        }

        const { data: createdTree } = await axios.post(
            `${apiUrl}/git/trees`,
            { tree },
            requestOptions
        );
        const { data: commit } = await axios.post(
            `${apiUrl}/git/commits`,
            {
                message: `Backup ${moment().tz('America/Montevideo').format('YYYY-MM-DD HH:mm:ss')}`,
                tree: createdTree.sha,
                parents: [reference.object.sha]
            },
            requestOptions
        );

        await axios.patch(
            `${apiUrl}/git/refs/heads/${encodedBranch}`,
            { sha: commit.sha },
            requestOptions
        );
    };

    try {
        await commitFiles(filesToUpload);
    } catch (error) {
        const status = error.response && error.response.status;
        const errorInfo = error.response && error.response.data;
        if (![413, 422].includes(status)) throw error;

        console.warn(
            `⚠️ GitHub rechazó los archivos sueltos (${status}: ${JSON.stringify(errorInfo)}). ` +
            'Se publicarán solo roblebot.zip y readme.md.'
        );
        await commitFiles([
            { name: 'readme.md', filePath: path.join(__dirname, 'readme.md') },
            { name: 'roblebot.zip', filePath: zipPath }
        ]);
    }
}

/**
 * FUNCIÓN PRINCIPAL - Solo se ejecuta UNA VEZ al iniciar
 */
async function backupToGithub() {
    if (backupRealizado) {
        console.log('⏭️  Backup ya realizado en esta sesión');
        return false;
    }

    const BACKUP_TIMEOUT_MS = 3 * 60 * 1000;
    let timeoutId;
    const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Timeout global de backup (3 min)')), BACKUP_TIMEOUT_MS);
    });

    try {
        return await Promise.race([_doBackup(), timeoutPromise]);
    } finally {
        clearTimeout(timeoutId);
    }
}

async function _doBackup() {
    require('dotenv').config();

    try {
        const oldZips = fs.readdirSync(__dirname).filter((file) => /^backup_temp_.*\.zip$/.test(file));
        for (const oldZip of oldZips) {
            fs.unlinkSync(path.join(__dirname, oldZip));
            console.log(`🗑️ Limpiando zip anterior: ${oldZip}`);
        }
    } catch (error) {
        console.warn('⚠️ No se pudieron limpiar todos los ZIP temporales:', error.message);
    }

    const timestamp = moment().tz('America/Montevideo').format('YYYY-MM-DD_HH-mm-ss');
    const zipPath = path.join(__dirname, `backup_temp_${timestamp}.zip`);

    try {
        console.log('🗜️ Ejecutando backup...');
        const readmePath = path.join(__dirname, 'readme.md');
        let readme = fs.readFileSync(readmePath, 'utf8');
        let files;
        let readmeSizeUpdated = false;

        for (let attempt = 0; attempt < 10; attempt++) {
            console.log('🗜️ Creando ZIP...');
            files = await createZip(zipPath);
            const updatedReadme = updateReadmeSize(readme, fs.statSync(zipPath).size);

            if (updatedReadme === readme) {
                readmeSizeUpdated = true;
                break;
            }

            fs.writeFileSync(readmePath, updatedReadme, 'utf8');
            readme = updatedReadme;
        }

        if (!readmeSizeUpdated) {
            throw new Error('No se pudo estabilizar el tamaño del ZIP en el README');
        }

        const config = {
            token: process.env.GITHUB_TOKEN,
            owner: process.env.GITHUB_OWNER,
            repo: process.env.GITHUB_REPO,
            branch: process.env.GITHUB_BRANCH || 'main'
        };

        console.log('📤 Subiendo archivos y roblebot.zip a GitHub...');
        await uploadToGithub(zipPath, files, config);
        console.log('✅ Backup completado exitosamente');

        backupRealizado = true;
        fs.unlinkSync(zipPath);
        console.log('🗑️ ZIP local eliminado');

        return true;
    } catch (error) {
        const details = error.response && error.response.data;
        console.error(
            '❌ Error en backup:',
            error.message,
            details ? JSON.stringify(details) : ''
        );

        if (fs.existsSync(zipPath)) {
            fs.unlinkSync(zipPath);
        }

        return false;
    }
}

/**
 * Resetear bandera (útil si necesitas hacer backup manual)
 */
function resetBackupFlag() {
    backupRealizado = false;
    console.log('🔄 Bandera de backup reseteada');
}

module.exports = {
    backupToGithub,
    resetBackupFlag
};

if (require.main === module) {
    backupToGithub();
}
