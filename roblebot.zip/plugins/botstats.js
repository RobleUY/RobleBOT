const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');
const { loadStats, updateStatsMeta } = require('../botStatsRecorder');

function loadCustomCommandsCount() {
    try {
        const dataPath = path.join(__dirname, '..', 'data', 'comandos.json');
        if (!fs.existsSync(dataPath)) return 0;
        const raw = fs.readFileSync(dataPath, 'utf8');
        const json = JSON.parse(raw);
        return Object.keys(json.commands || {}).length;
    } catch (e) {
        return 0;
    }
}

function countAvailableCommands() {
    let count = 0;
    if (global.commandHandler && global.commandHandler.commands) {
        count = Array.from(global.commandHandler.commands.values())
            .filter(cmd => !cmd.isTextReplyHandler && !cmd.isReactionHandler && !cmd.isImageCollector)
            .length;
    }
    count += loadCustomCommandsCount();
    return count;
}

function countLoadedPlugins() {
    const pluginsDir = path.join(__dirname, '..', 'plugins');
    let total = 0;

    function walk(dir) {
        const items = fs.readdirSync(dir, { withFileTypes: true });
        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                walk(full);
            } else if (item.isFile() && item.name.toLowerCase().endsWith('.js')) {
                total += 1;
            }
        }
    }

    try {
        walk(pluginsDir);
    } catch (e) {
        total = 0;
    }

    return total;
}

let handler = async (message, { conn }) => {
    try {
        const stats = loadStats();

        // Comandos
        const totalCommands = stats.totalCommandsExecuted || stats.totalCommands || 0;
        const availableCommands = countAvailableCommands();
        const loadedPlugins = countLoadedPlugins();
        updateStatsMeta({ availableCommands, loadedPlugins });

        // Usuarios (solo �nicos con apodo real, deduplicados por alias LID?tel�fono)
        const totalUsers = global.db?.countRealUsers ? global.db.countRealUsers() : 0;

        const activeSubbots = (global.subConns || []).filter(c => c.user);
        const subbotsCount = activeSubbots.length;

        // Próximo reinicio programado
        let nextRestartLine = 'N/A';
        if (global._nextRestartTime) {
            const nextMoment = moment.tz(global._nextRestartTime, 'America/Montevideo');
            const diffMs = global._nextRestartTime - Date.now();
            const diffMin = Math.max(0, Math.floor(diffMs / 60000));
            const rh = Math.floor(diffMin / 60);
            const rm = diffMin % 60;
            const countdownStr = rh > 0 ? `${rh}h ${rm}m` : `${rm}m`;
            nextRestartLine = `${nextMoment.format('HH:mm')} UY (en ${countdownStr})`;
        }

        const text =
            `╔══════════════════════╗\n` +
            `║   📊 *ESTADÍSTICAS DEL BOT*   ║\n` +
            `╚══════════════════════╝\n\n` +
            `⚡ *Comandos ejecutados*\n` +
            `└ Total: *${totalCommands.toLocaleString()}*\n\n` +
            `👥 *Usuarios*\n` +
            `└ Total: *${totalUsers.toLocaleString()}*\n\n` +
            `🤖 *Bots activos*\n` +
            `└ Total: *${(1 + subbotsCount).toLocaleString()}*\n\n` +
            `📌 *Comandos disponibles*\n` +
            `└ Total: *${availableCommands.toLocaleString()}*\n\n` +
            `🔄 *Próximo reinicio*\n` +
            `└ ${nextRestartLine}`;

        await message.reply(text);
    } catch (error) {
        console.error('[botstats] Error:', error.message);
        await message.reply('❌ Error al obtener las estadísticas.');
    }
};

handler.help = ['stats', 'statsbot', 'botstats'];
handler.tags = ['info'];
handler.command = /^(stats|statsbot|botstats)$/i;

module.exports = handler;
