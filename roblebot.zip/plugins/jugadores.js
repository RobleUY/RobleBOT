const axios = require('axios');
const db = require('../database.js');
const premium = require('../premium');
const botConfig = require('../config.js');

// **IMPORTANTE:** Este código asume acceso a global.conn para @whiskeysockets/baileys
// y global.db para el sistema de monedas

// --- CONFIGURACIÓN DE PRECIOS ---
const PRECIO_BASE_POR_ESTRELLA = 5000; // 5,000 monedas por estrella
// ---

// 🧠 Cache simple para imágenes de Pinterest
const imageCache = new Map();

/**
 * 🔍 Buscar imagen de futbolista en Pinterest
 */
async function buscarImagenFutbolista(nombreJugador, pais) {
    const query = `${nombreJugador} ${pais} football player`;
    
    if (imageCache.has(query)) return imageCache.get(query);

    try {
        const url = `https://api.delirius.online/search/pinterest?text=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url, { timeout: 10000 });

        if (!data?.status || !Array.isArray(data.results) || data.results.length === 0) {
            return null;
        }

        const imageUrl = data.results[Math.floor(Math.random() * data.results.length)];
        imageCache.set(query, imageUrl);
        return imageUrl;
    } catch (error) {
        console.error(`[Futbolistas] Error buscando imagen: ${error.message}`);
        return null;
    }
}

// --- DATOS DE FUTBOLISTAS (Mundial Qatar 2022) ---
const FUTBOLISTAS_BASE = [
    // GRUPO A - CATAR
    { nombre: 'Almoez Ali', pais: 'Catar', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Hassan Al-Haydos', pais: 'Catar', posicion: 'Mediocampista', calidad: '☆☆' },
    
    // GRUPO A - ECUADOR
    { nombre: 'Enner Valencia', pais: 'Ecuador', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Moisés Caicedo', pais: 'Ecuador', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO A - SENEGAL
    { nombre: 'Sadio Mané', pais: 'Senegal', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Kalidou Koulibaly', pais: 'Senegal', posicion: 'Defensa', calidad: '☆☆☆☆' },
    { nombre: 'Édouard Mendy', pais: 'Senegal', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO A - PAÍSES BAJOS
    { nombre: 'Virgil van Dijk', pais: 'Países Bajos', posicion: 'Defensa', calidad: '☆☆☆☆☆' },
    { nombre: 'Frenkie de Jong', pais: 'Países Bajos', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Memphis Depay', pais: 'Países Bajos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO B - INGLATERRA
    { nombre: 'Harry Kane', pais: 'Inglaterra', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Raheem Sterling', pais: 'Inglaterra', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Jude Bellingham', pais: 'Inglaterra', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO B - IRÁN
    { nombre: 'Sardar Azmoun', pais: 'Irán', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Alireza Jahanbakhsh', pais: 'Irán', posicion: 'Mediocampista', calidad: '☆☆' },
    
    // GRUPO B - ESTADOS UNIDOS
    { nombre: 'Christian Pulisic', pais: 'Estados Unidos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Weston McKennie', pais: 'Estados Unidos', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO B - GALES
    { nombre: 'Gareth Bale', pais: 'Gales', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Aaron Ramsey', pais: 'Gales', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO C - ARGENTINA
    { nombre: 'Lionel Messi', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Ángel Di María', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Emiliano Martínez', pais: 'Argentina', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    { nombre: 'Lautaro Martínez', pais: 'Argentina', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Leandro Paredes', pais: 'Argentina', posicion: 'Mediocampista', calidad: '☆☆☆☆☆' },
    
    // GRUPO C - ARABIA SAUDÍ
    { nombre: 'Salem Al-Dawsari', pais: 'Arabia Saudí', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO C - MÉXICO
    { nombre: 'Hirving Lozano', pais: 'México', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Guillermo Ochoa', pais: 'México', posicion: 'Portero', calidad: '☆☆☆' },
    
    // GRUPO C - POLONIA
    { nombre: 'Robert Lewandowski', pais: 'Polonia', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Wojciech Szczęsny', pais: 'Polonia', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO D - FRANCIA
    { nombre: 'Kylian Mbappé', pais: 'Francia', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Antoine Griezmann', pais: 'Francia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'N\'Golo Kanté', pais: 'Francia', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Hugo Lloris', pais: 'Francia', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO D - AUSTRALIA
    { nombre: 'Mathew Leckie', pais: 'Australia', posicion: 'Delantero', calidad: '☆☆' },
    
    // GRUPO D - DINAMARCA
    { nombre: 'Christian Eriksen', pais: 'Dinamarca', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Kasper Schmeichel', pais: 'Dinamarca', posicion: 'Portero', calidad: '☆☆☆' },
    
    // GRUPO D - TÚNEZ
    { nombre: 'Wahbi Khazri', pais: 'Túnez', posicion: 'Delantero', calidad: '☆☆' },
    
    // GRUPO E - ESPAÑA
    { nombre: 'Sergio Busquets', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Pedri', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Gavi', pais: 'España', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO E - COSTA RICA
    { nombre: 'Keylor Navas', pais: 'Costa Rica', posicion: 'Portero', calidad: '☆☆☆☆' },
    
    // GRUPO E - ALEMANIA
    { nombre: 'Manuel Neuer', pais: 'Alemania', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    { nombre: 'Thomas Müller', pais: 'Alemania', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Joshua Kimmich', pais: 'Alemania', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO E - JAPÓN
    { nombre: 'Takumi Minamino', pais: 'Japón', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO F - BÉLGICA
    { nombre: 'Kevin De Bruyne', pais: 'Bélgica', posicion: 'Mediocampista', calidad: '☆☆☆☆☆' },
    { nombre: 'Eden Hazard', pais: 'Bélgica', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Romelu Lukaku', pais: 'Bélgica', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Thibaut Courtois', pais: 'Bélgica', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    
    // GRUPO F - CANADÁ
    { nombre: 'Alphonso Davies', pais: 'Canadá', posicion: 'Defensa', calidad: '☆☆☆☆' },
    
    // GRUPO F - MARRUECOS
    { nombre: 'Achraf Hakimi', pais: 'Marruecos', posicion: 'Defensa', calidad: '☆☆☆☆' },
    { nombre: 'Hakim Ziyech', pais: 'Marruecos', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO F - CROACIA
    { nombre: 'Luka Modrić', pais: 'Croacia', posicion: 'Mediocampista', calidad: '☆☆☆☆☆' },
    { nombre: 'Ivan Perišić', pais: 'Croacia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO G - BRASIL
    { nombre: 'Neymar Jr', pais: 'Brasil', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Vinícius Júnior', pais: 'Brasil', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Casemiro', pais: 'Brasil', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Alisson Becker', pais: 'Brasil', posicion: 'Portero', calidad: '☆☆☆☆☆' },
    
    // GRUPO G - SERBIA
    { nombre: 'Dušan Vlahović', pais: 'Serbia', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Dušan Tadić', pais: 'Serbia', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO G - SUIZA
    { nombre: 'Xherdan Shaqiri', pais: 'Suiza', posicion: 'Delantero', calidad: '☆☆☆' },
    { nombre: 'Granit Xhaka', pais: 'Suiza', posicion: 'Mediocampista', calidad: '☆☆☆' },
    
    // GRUPO G - CAMERÚN
    { nombre: 'André Onana', pais: 'Camerún', posicion: 'Portero', calidad: '☆☆☆☆' },
    { nombre: 'Eric Maxim Choupo-Moting', pais: 'Camerún', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO H - PORTUGAL
    { nombre: 'Cristiano Ronaldo', pais: 'Portugal', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Bruno Fernandes', pais: 'Portugal', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Bernardo Silva', pais: 'Portugal', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    
    // GRUPO H - GHANA
    { nombre: 'Thomas Partey', pais: 'Ghana', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Mohammed Kudus', pais: 'Ghana', posicion: 'Delantero', calidad: '☆☆☆' },
    
    // GRUPO H - URUGUAY
    { nombre: 'Luis Suárez', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Edinson Cavani', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆' },
    { nombre: 'Federico Valverde', pais: 'Uruguay', posicion: 'Mediocampista', calidad: '☆☆☆☆' },
    { nombre: 'Darwin Núñez', pais: 'Uruguay', posicion: 'Delantero', calidad: '☆☆☆☆' },
    
    // GRUPO H - REPÚBLICA DE COREA
    { nombre: 'Son Heung-min', pais: 'República de Corea', posicion: 'Delantero', calidad: '☆☆☆☆☆' },
    { nombre: 'Hwang Hee-chan', pais: 'República de Corea', posicion: 'Delantero', calidad: '☆☆☆' },

    // --- JUGADORES ACTUALES Y ESTRELLAS INTERNACIONALES ---
    { nombre: "Erling Haaland", pais: "Noruega", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Phil Foden", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Bukayo Saka", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Declan Rice", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Cole Palmer", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Marcus Rashford", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Ollie Watkins", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Trent Alexander-Arnold", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Kyle Walker", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "John Stones", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Jordan Pickford", pais: "Inglaterra", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "James Maddison", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Rodri", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆☆☆' },
    { nombre: "Lamine Yamal", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Nico Williams", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Dani Carvajal", pais: "España", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Dani Olmo", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Mikel Merino", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Álvaro Morata", pais: "España", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Unai Simón", pais: "España", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Alejandro Balde", pais: "España", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Ferran Torres", pais: "España", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Fabián Ruiz", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Aymeric Laporte", pais: "España", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Ousmane Dembélé", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Olivier Giroud", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Aurélien Tchouaméni", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Eduardo Camavinga", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "William Saliba", pais: "Francia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Dayot Upamecano", pais: "Francia", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Mike Maignan", pais: "Francia", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Kingsley Coman", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Marcus Thuram", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Jules Koundé", pais: "Francia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Randal Kolo Muani", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Jamal Musiala", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆☆' },
    { nombre: "Florian Wirtz", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆☆' },
    { nombre: "Kai Havertz", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "İlkay Gündoğan", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Antonio Rüdiger", pais: "Alemania", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Marc-André ter Stegen", pais: "Alemania", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Leroy Sané", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Serge Gnabry", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Niclas Füllkrug", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Victor Osimhen", pais: "Nigeria", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Mohamed Salah", pais: "Egipto", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Riyad Mahrez", pais: "Argelia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Yassine Bounou", pais: "Marruecos", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Sofyan Amrabat", pais: "Marruecos", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Brahim Díaz", pais: "Marruecos", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Youssef En-Nesyri", pais: "Marruecos", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Victor Boniface", pais: "Nigeria", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Ademola Lookman", pais: "Nigeria", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Nicolas Jackson", pais: "Senegal", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Raphinha", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Rodrygo", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Endrick", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Gabriel Martinelli", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Gabriel Jesus", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Bruno Guimarães", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Éder Militão", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Marquinhos", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Ederson", pais: "Brasil", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Richarlison", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Thiago Silva", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Julián Álvarez", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Alexis Mac Allister", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Enzo Fernández", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Nicolás Otamendi", pais: "Argentina", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Cristian Romero", pais: "Argentina", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Paulo Dybala", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Alejandro Garnacho", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Nicolás González", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Gerónimo Rulli", pais: "Argentina", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "Lisandro Martínez", pais: "Argentina", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Giovani Lo Celso", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Rodrigo De Paul", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Ángel Correa", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Ronald Araújo", pais: "Uruguay", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "José María Giménez", pais: "Uruguay", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Sergio Rochet", pais: "Uruguay", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "Facundo Pellistri", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Manuel Ugarte", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Giorgian de Arrascaeta", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Maximiliano Araújo", pais: "Uruguay", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Nicolás de la Cruz", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Agustín Canobbio", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Federico Viñas", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Luka Jović", pais: "Serbia", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Aleksandar Mitrović", pais: "Serbia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Sergej Milinković-Savić", pais: "Serbia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Jan Oblak", pais: "Eslovenia", posicion: "Portero", calidad: '☆☆☆☆☆' },
    { nombre: "Benjamin Šeško", pais: "Eslovenia", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Khvicha Kvaratskhelia", pais: "Georgia", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Giorgi Mamardashvili", pais: "Georgia", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Hakan Çalhanoğlu", pais: "Turquía", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Arda Güler", pais: "Turquía", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Nicolò Barella", pais: "Italia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Federico Chiesa", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Gianluigi Donnarumma", pais: "Italia", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Alessandro Bastoni", pais: "Italia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Federico Dimarco", pais: "Italia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Ciro Immobile", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Jorginho", pais: "Italia", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Rafael Leão", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "João Félix", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Diogo Jota", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Diogo Costa", pais: "Portugal", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "João Cancelo", pais: "Portugal", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Rúben Dias", pais: "Portugal", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "João Palhinha", pais: "Portugal", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Josko Gvardiol", pais: "Croacia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Mateo Kovačić", pais: "Croacia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Joško Gvardiol", pais: "Croacia", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Dominik Szoboszlai", pais: "Hungría", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Ádám Szalai", pais: "Hungría", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Kim Min-jae", pais: "República de Corea", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Lee Kang-in", pais: "República de Corea", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Takefusa Kubo", pais: "Japón", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Kaoru Mitoma", pais: "Japón", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Wataru Endo", pais: "Japón", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Mehdi Taremi", pais: "Irán", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Alireza Beiranvand", pais: "Irán", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "Ali Daei", pais: "Irán", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Jonathan David", pais: "Canadá", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Cyle Larin", pais: "Canadá", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Tim Weah", pais: "Estados Unidos", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Tyler Adams", pais: "Estados Unidos", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Gio Reyna", pais: "Estados Unidos", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Ricardo Pepi", pais: "Estados Unidos", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Santiago Giménez", pais: "México", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Raúl Jiménez", pais: "México", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Andrés Guardado", pais: "México", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Javier Hernández", pais: "México", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Rafael Márquez", pais: "México", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Bryan Ruiz", pais: "Costa Rica", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "Joel Campbell", pais: "Costa Rica", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "James Rodríguez", pais: "Colombia", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Luis Díaz", pais: "Colombia", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Radamel Falcao", pais: "Colombia", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Juan Cuadrado", pais: "Colombia", posicion: "Mediocampista", calidad: '☆☆☆' },
    { nombre: "David Ospina", pais: "Colombia", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "Jhon Durán", pais: "Colombia", posicion: "Delantero", calidad: '☆☆☆' },
    { nombre: "Piero Hincapié", pais: "Ecuador", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Antonio Valencia", pais: "Ecuador", posicion: "Defensa", calidad: '☆☆☆☆' },
    { nombre: "Alexis Sánchez", pais: "Chile", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Arturo Vidal", pais: "Chile", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Claudio Bravo", pais: "Chile", posicion: "Portero", calidad: '☆☆☆☆' },
    { nombre: "Gary Medel", pais: "Chile", posicion: "Defensa", calidad: '☆☆☆' },
    { nombre: "Paolo Guerrero", pais: "Perú", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Claudio Pizarro", pais: "Perú", posicion: "Delantero", calidad: '☆☆☆☆' },
    { nombre: "Pedro Gallese", pais: "Perú", posicion: "Portero", calidad: '☆☆☆' },
    { nombre: "Teófilo Cubillas", pais: "Perú", posicion: "Mediocampista", calidad: '☆☆☆☆' },
    { nombre: "Pelé", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Diego Maradona", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Zinedine Zidane", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Johan Cruyff", pais: "Países Bajos", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Franz Beckenbauer", pais: "Alemania", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Alfredo Di Stéfano", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Ferenc Puskás", pais: "Hungría", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Eusébio", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Garrincha", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Sócrates", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Ronaldo Nazário", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Ronaldinho", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Rivaldo", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Romário", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Zico", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Kaká", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Cafu", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Roberto Carlos", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Dida", pais: "Brasil", posicion: "Portero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Jairzinho", pais: "Brasil", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Carlos Alberto Torres", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Gerd Müller", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Lothar Matthäus", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Miroslav Klose", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Philipp Lahm", pais: "Alemania", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Bastian Schweinsteiger", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Oliver Kahn", pais: "Alemania", posicion: "Portero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Andreas Brehme", pais: "Alemania", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Jürgen Klinsmann", pais: "Alemania", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Michael Ballack", pais: "Alemania", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Michel Platini", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Thierry Henry", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Eric Cantona", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Just Fontaine", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Lilian Thuram", pais: "Francia", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Patrick Vieira", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Claude Makélélé", pais: "Francia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "David Trezeguet", pais: "Francia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Fabien Barthez", pais: "Francia", posicion: "Portero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Xavi Hernández", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Andrés Iniesta", pais: "España", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Iker Casillas", pais: "España", posicion: "Portero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Carles Puyol", pais: "España", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Raúl González", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Fernando Torres", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "David Villa", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Sergio Ramos", pais: "España", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Fernando Hierro", pais: "España", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Luis Suárez Miramontes", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Telmo Zarra", pais: "España", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Paolo Maldini", pais: "Italia", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Franco Baresi", pais: "Italia", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Roberto Baggio", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Andrea Pirlo", pais: "Italia", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Francesco Totti", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Alessandro Del Piero", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Gianluigi Buffon", pais: "Italia", posicion: "Portero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Fabio Cannavaro", pais: "Italia", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Gennaro Gattuso", pais: "Italia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Filippo Inzaghi", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Christian Vieri", pais: "Italia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Daniele De Rossi", pais: "Italia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "George Best", pais: "Irlanda del Norte", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Bobby Charlton", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Bobby Moore", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Gary Lineker", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Paul Gascoigne", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "David Beckham", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Steven Gerrard", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Frank Lampard", pais: "Inglaterra", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Wayne Rooney", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Alan Shearer", pais: "Inglaterra", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Rio Ferdinand", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "John Terry", pais: "Inglaterra", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Ryan Giggs", pais: "Gales", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Ian Rush", pais: "Gales", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Kenny Dalglish", pais: "Escocia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Dennis Law", pais: "Escocia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Luís Figo", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Deco", pais: "Portugal", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Rui Costa", pais: "Portugal", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Eusébio da Silva Ferreira", pais: "Portugal", posicion: "Delantero", calidad: '☆☆☆☆☆' },
    { nombre: "Pavel Nedvěd", pais: "Chequia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Petr Čech", pais: "Chequia", posicion: "Portero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Andriy Shevchenko", pais: "Ucrania", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Lev Yashin", pais: "Rusia", posicion: "Portero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Oleg Blokhin", pais: "Ucrania", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Hristo Stoichkov", pais: "Bulgaria", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Davor Šuker", pais: "Croacia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Zvonimir Boban", pais: "Croacia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Dejan Savićević", pais: "Montenegro", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "George Weah", pais: "Liberia", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Didier Drogba", pais: "Costa de Marfil", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Yaya Touré", pais: "Costa de Marfil", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Samuel Eto'o", pais: "Camerún", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Roger Milla", pais: "Camerún", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Jay-Jay Okocha", pais: "Nigeria", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Nwankwo Kanu", pais: "Nigeria", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Abedi Pelé", pais: "Ghana", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Asamoah Gyan", pais: "Ghana", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Hossam Hassan", pais: "Egipto", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Enzo Francescoli", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Obdulio Varela", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Juan Alberto Schiaffino", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Alcides Ghiggia", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Héctor Scarone", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Diego Forlán", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Álvaro Recoba", pais: "Uruguay", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Sebastián Abreu", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆', leyenda: true },
    { nombre: "Diego Lugano", pais: "Uruguay", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Fernando Morena", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Rubén Sosa", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Antonio Alzamendi", pais: "Uruguay", posicion: "Delantero", calidad: '☆☆☆', leyenda: true },
    { nombre: "Mario Kempes", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Gabriel Batistuta", pais: "Argentina", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Juan Román Riquelme", pais: "Argentina", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Carlos Valderrama", pais: "Colombia", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Hugo Sánchez", pais: "México", posicion: "Delantero", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Cuauhtémoc Blanco", pais: "México", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Didi", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Nilton Santos", pais: "Brasil", posicion: "Defensa", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Falcão", pais: "Brasil", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Gheorghe Hagi", pais: "Rumania", posicion: "Mediocampista", calidad: '☆☆☆☆☆', leyenda: true },
    { nombre: "Rabah Madjer", pais: "Argelia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Cha Bum-kun", pais: "República de Corea", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Hidetoshi Nakata", pais: "Japón", posicion: "Mediocampista", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Tim Cahill", pais: "Australia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
    { nombre: "Harry Kewell", pais: "Australia", posicion: "Delantero", calidad: '☆☆☆☆', leyenda: true },
];

const LISTA_FUTBOLISTAS = FUTBOLISTAS_BASE.map(fb => ({ 
    ...fb, 
    nombreFormateado: fb.nombre,
    nombre: fb.nombre.replace(/\s/g, '').toLowerCase()
}));

/**
 * Convierte el nombre simple al formato legible
 */
function formatoNombre(nombreSimple) {
    const fbData = LISTA_FUTBOLISTAS.find(fb => fb.nombre === nombreSimple);
    if (!fbData) return nombreSimple.toUpperCase();
    return fbData.nombreFormateado.replace(/\s/g, '_');
}

/**
 * Obtiene el precio de venta basado en estrellas
 */
function obtenerPrecioVenta(calidadString) {
    const estrellas = calidadString.length;
    return estrellas * PRECIO_BASE_POR_ESTRELLA;
}

// --- Carga y Guardado de Datos ---
function ensureDatabaseCollections() {
    if (!db || !db.data) return;
    if (!db.data.futbolistas) db.data.futbolistas = {};
    if (!db.data.intercambiosFutbol) db.data.intercambiosFutbol = {};
}

function guardarCambios(targetNumber) {
    if (db && db.data && db.data.futbolistas) {
        if (targetNumber && db.data.futbolistas[targetNumber]) {
            db.setFutbolistas(targetNumber, db.data.futbolistas[targetNumber]);
        } else {
            for (const [key, val] of Object.entries(db.data.futbolistas)) {
                db.setFutbolistas(key, val);
            }
        }
    }
    if (db && typeof db.save === 'function') {
        db.save();
    }
}

// --- FUNCIONES DE MANEJO DE MONEDAS ---
function obtenerMonedas(user) {
    return (user.money || 0) + (user.bank || 0);
}

async function añadirMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return;
    const user = await global.db.getUser(jid, groupId);
    user.money = (user.money || 0) + cantidad;
}

async function restarMonedas(jid, groupId, cantidad) {
    if (!global.db || !global.db.getUser) return false;
    const user = await global.db.getUser(jid, groupId);
    let restante = cantidad;

    if (user.money >= restante) {
        user.money -= restante;
    } else {
        restante -= (user.money || 0);
        user.money = 0;
        
        if (user.bank >= restante) {
            user.bank -= restante;
        } else {
            return false;
        }
    }
    await global.db.saveUser(user);
    return true;
}

// --- Otras Funciones de Utilidad ---
function obtenerFutbolistaAleatorio() {
    const totalPeso = LISTA_FUTBOLISTAS.reduce((sum, fb) => {
        const pesoBase = 6 - fb.calidad.length;
        return sum + pesoBase;
    }, 0);

    let random = Math.floor(Math.random() * totalPeso);
    for (const fb of LISTA_FUTBOLISTAS) {
        const pesoBase = 6 - fb.calidad.length;
        if (random < pesoBase) {
            return fb;
        }
        random -= pesoBase;
    }
    return LISTA_FUTBOLISTAS[Math.floor(Math.random() * LISTA_FUTBOLISTAS.length)];
}

function normalizarTexto(str) {
    if (!str) return '';
    return str
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '');
}

function buscarFutbolistaPorNombre(nombreSimple) {
    if (!nombreSimple) return null;
    const targetNorm = normalizarTexto(nombreSimple);
    return LISTA_FUTBOLISTAS.find(fb => 
        normalizarTexto(fb.nombreFormateado) === targetNorm || 
        normalizarTexto(fb.nombre) === targetNorm
    );
}

// --- Manejador Principal ---
let handler = async (message, { text, command, conn }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid;
        const groupJid = message?.key?.remoteJid;
        const senderNumber = db.cleanNumber(senderJid) || senderJid?.split('@')[0];
        
        if (!global.db || !global.db.getUser) {
            return await message.reply('❌ *Error de Base de Datos:* La conexión `global.db` no está disponible.');
        }

        let userDb = await global.db.getUser(senderJid, groupJid);

        if (!groupJid || !groupJid.endsWith('@g.us')) {
            return await message.reply('❌ *Este comando solo funciona en grupos.*');
        }

        if (!senderJid) {
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }

        ensureDatabaseCollections();
        const futbolistasData = db.data.futbolistas;
        const intercambiosFutbol = db.data.intercambiosFutbol;

        if (!futbolistasData[senderNumber]) {
            futbolistasData[senderNumber] = {
                futbolistas: [],
                bloqueados: [],
                ultimoClaim: 0,
                jid: senderJid,
            };
            db.setFutbolistas(senderNumber, futbolistasData[senderNumber]);
            guardarCambios();
        }
        if (!futbolistasData[senderNumber].bloqueados) {
            futbolistasData[senderNumber].bloqueados = [];
        }

        const args = text ? text.split(/\s+/).filter(a => a.length > 0) : [];
        const subCommand = args[0]?.toLowerCase();

        // COMANDO: /fpj (sin subcomando) -> Muestra comandos
        if (command.match(/^fpj$/i) && !subCommand) {
            return await message.reply(
                '⚽ *COMANDOS DE FUTBOLISTAS* ⚽\n' +
                '━━━━━━━━━━\n\n' +
                '*/fpj reclamar* / *claim* - _Reclama un futbolista aleatorio (1 por hora)._\n' +
                '*/myfpj* - _Ver tu colección de futbolistas._\n' +
                '*/myfpj ver [futbolista]* - _Ver la imagen de un futbolista._\n' +
                '*/fpj regalar @user [futbolista]* - _Regala un futbolista._\n' +
                '*/fpj intercambio @user [mi_fb] [su_fb]* - _Propone intercambio._\n' +
                '*/fpj intercambio aceptar @user* - _Aceptar intercambio._\n' +
                '*/fpj intercambio rechazar @user* - _Rechazar intercambio._\n' +
                '*/fpj vender [futbolista] [cantidad]* - _Vende futbolistas._\n' +
                '*/fpj vender all* - _Vende todos tus futbolistas (excepto bloqueados)._\n' +
                '*/fpj block [futbolista] [número]* - _Bloquea una copia (no se vende con all)._\n' +
                '*/fpj block all* - _Bloquea todos tus futbolistas._\n' +
                '*/fpj unlock [futbolista] [número]* - _Desbloquea una copia._\n' +
                '*/fpj unlock all* - _Desbloquea todos tus futbolistas._\n'
            );
        }

        // SUBCOMANDO: block / bloquear
        if (subCommand === 'block' || subCommand === 'bloquear') {
            const objetivo = args[1]?.toLowerCase();
            const inventario = futbolistasData[senderNumber].futbolistas;
            const bloqueados = futbolistasData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj block [futbolista] [número]_ o _/fpj block all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                const aBloqear = [];
                const conteo = {};
                for (const n of inventario) {
                    conteo[n] = (conteo[n] || 0) + 1;
                    const key = n + '_' + conteo[n];
                    if (!bloqueados.includes(key)) aBloqear.push(key);
                }
                futbolistasData[senderNumber].bloqueados = [...new Set([...bloqueados, ...aBloqear])];
                guardarCambios();
                return await message.reply(`🔒 *Todos tus futbolistas han sido bloqueados.* No se venderán con \`/fpj vender all\`.`);
            }

            const futbolista = buscarFutbolistaPorNombre(objetivo);
            if (!futbolista) return await message.reply('❌ *Futbolista no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `/fpj block Messi 1`');

            const copias = inventario.filter(n => n === futbolista.nombre).length;
            if (numero > copias) return await message.reply(`❌ Solo tienes *${copias}x ${formatoNombre(futbolista.nombre)}*.`);

            const key = futbolista.nombre + '_' + numero;
            if (bloqueados.includes(key)) return await message.reply(`🔒 La copia #${numero} de *${formatoNombre(futbolista.nombre)}* ya está bloqueada.`);

            bloqueados.push(key);
            guardarCambios();
            return await message.reply(`🔒 *${formatoNombre(futbolista.nombre)} #${numero}* bloqueado. No se venderá con \`/fpj vender all\`.`);
        }

        // SUBCOMANDO: unlock / desbloquear
        if (subCommand === 'unlock' || subCommand === 'desbloquear') {
            const objetivo = args[1]?.toLowerCase();
            const bloqueados = futbolistasData[senderNumber].bloqueados;

            if (!objetivo) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj unlock [futbolista] [número]_ o _/fpj unlock all_');
            }

            if (objetivo === 'all' || objetivo === 'todos' || objetivo === 'todo') {
                futbolistasData[senderNumber].bloqueados = [];
                guardarCambios();
                return await message.reply('🔓 *Todos tus futbolistas han sido desbloqueados.*');
            }

            const futbolista = buscarFutbolistaPorNombre(objetivo);
            if (!futbolista) return await message.reply('❌ *Futbolista no reconocido.*');

            const numero = parseInt(args[2] || 1);
            if (isNaN(numero) || numero < 1) return await message.reply('❌ *Número inválido.* Ej: `/fpj unlock Messi 1`');

            const key = futbolista.nombre + '_' + numero;
            const idx = bloqueados.indexOf(key);
            if (idx === -1) return await message.reply(`🔓 La copia #${numero} de *${formatoNombre(futbolista.nombre)}* no está bloqueada.`);

            bloqueados.splice(idx, 1);
            guardarCambios();
            return await message.reply(`🔓 *${formatoNombre(futbolista.nombre)} #${numero}* desbloqueado.`);
        }

        // SUBCOMANDO: vender
        if (subCommand === 'vender' || subCommand === 'sell') {
            const comandoVender = args[1]?.toLowerCase();
            let totalMonedasGanadas = 0;
            let futbolistasVendidos = 0;
            const inventarioUsuario = futbolistasData[senderNumber].futbolistas;
            const bloqueados = futbolistasData[senderNumber].bloqueados || [];

            if (comandoVender === 'all' || comandoVender === 'todo' || comandoVender === 'todos') {
                if (inventarioUsuario.length === 0) {
                    return await message.reply('❌ *Tu colección está vacía.*');
                }

                const copiasBloqueadas = {};
                for (const key of bloqueados) {
                    const partes = key.split('_');
                    const num = parseInt(partes[partes.length - 1]);
                    const nombre = partes.slice(0, partes.length - 1).join('_');
                    if (!isNaN(num)) {
                        copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                    }
                }

                const quedan = [];
                const conteoTotal = {};
                for (const n of inventarioUsuario) {
                    conteoTotal[n] = (conteoTotal[n] || 0) + 1;
                }

                for (const nameSimple in conteoTotal) {
                    const totalCopias = conteoTotal[nameSimple];
                    const bloqCopias = copiasBloqueadas[nameSimple] || 0;
                    const vendibles = totalCopias - bloqCopias;
                    const fbData = buscarFutbolistaPorNombre(nameSimple);

                    if (fbData && vendibles > 0) {
                        const precioPorUnidad = obtenerPrecioVenta(fbData.calidad);
                        totalMonedasGanadas += precioPorUnidad * vendibles;
                        futbolistasVendidos += vendibles;
                    }

                    const aGuardar = fbData ? bloqCopias : totalCopias;
                    for (let i = 0; i < aGuardar; i++) quedan.push(nameSimple);
                }

                if (futbolistasVendidos === 0) {
                    return await message.reply('❌ *No tienes futbolistas vendibles.* (Todos están bloqueados o vacíos)');
                }

                futbolistasData[senderNumber].futbolistas = quedan;

            } else {
                const nombreFutbolistaEntrada = args[1];
                const cantidadAVender = parseInt(args[2] || 1);
                
                if (!nombreFutbolistaEntrada || isNaN(cantidadAVender) || cantidadAVender < 1) {
                    return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj vender [NombreFutbolista] [cantidad]_ o _/fpj vender all_');
                }

                const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);

                if (!futbolista) {
                    return await message.reply(`❌ *Futbolista no encontrado.*`);
                }

                const nombreSimple = futbolista.nombre;
                const conteoEnInventario = inventarioUsuario.filter(name => name === nombreSimple).length;
                
                if (conteoEnInventario < cantidadAVender) {
                    return await message.reply(`❌ Solo tienes *${conteoEnInventario}x ${formatoNombre(nombreSimple)}*`);
                }
                
                const precioPorUnidad = obtenerPrecioVenta(futbolista.calidad);
                totalMonedasGanadas = precioPorUnidad * cantidadAVender;
                futbolistasVendidos = cantidadAVender;
                
                let eliminados = 0;
                futbolistasData[senderNumber].futbolistas = inventarioUsuario.filter(name => {
                    if (name === nombreSimple && eliminados < cantidadAVender) {
                        eliminados++;
                        return false;
                    }
                    return true;
                });
            }

            if (futbolistasVendidos > 0) {
                await añadirMonedas(senderJid, groupJid, totalMonedasGanadas);
                guardarCambios();
                
                userDb = await global.db.getUser(senderJid, groupJid);
                const saldoFinal = obtenerMonedas(userDb).toLocaleString();

                const mensaje = 
                    `💰 *¡Venta Exitosa!* 💰\n` +
                    '━━━━━━━━━━\n\n' +
                    `Has vendido *${futbolistasVendidos} futbolistas* por *${totalMonedasGanadas.toLocaleString()} monedas*.\n` +
                    `Tu saldo total: *${saldoFinal} monedas*.\n\n` +
                    '_¡Sigue coleccionando!_ ⚽';
                    
                return await message.reply(mensaje, { mentions: [senderJid] });
            }
            
            return await message.reply('❌ *Error al procesar la venta.*');
        }

        // SUBCOMANDO: ver
        if (command.match(/^myfpj$/i) && subCommand === 'ver') {
            const nombreFutbolistaEntrada = args.slice(1).join('');
            if (!nombreFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /myfpj ver [NombreFutbolista]_');
            }

            const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);

            if (!futbolista) {
                return await message.reply(`❌ *Futbolista no reconocido.*`);
            }

            const tieneFutbolista = futbolistasData[senderNumber].futbolistas.some(fbName => fbName === futbolista.nombre);

            if (!tieneFutbolista) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(futbolista.nombre)}* en tu colección.`);
            }

            if (!global.conn) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            // Buscar imagen en Pinterest
            await message.reply('🔍 *Buscando imagen del futbolista...*');
            const imagenUrl = await buscarImagenFutbolista(futbolista.nombreFormateado, futbolista.pais);

            const caption =
                `⚽ *FUTBOLISTA EN COLECCIÓN* ⚽\n` +
                `━━━━━━━━━━\n\n` +
                `*Jugador:* ${formatoNombre(futbolista.nombre)}\n` +
                `*Selección:* ${futbolista.pais}\n` +
                `*Posición:* ${futbolista.posicion}\n` +
                `*Calidad:* ${futbolista.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(futbolista.calidad).toLocaleString()} monedas\n\n` +
                `_Este futbolista es parte de tu colección._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen desde Pinterest._', { mentions: [senderJid] });
            }

            return;
        }

        // SUBCOMANDO: reclamar / claim
        if (subCommand === 'reclamar' || subCommand === 'claim') {
            const sock = conn || message._sock || global.conn;
            const ultimaVez = futbolistasData[senderNumber].ultimoClaim || 0;
            const isPremiumUser = premium.isPremium(senderJid);
            const cooldown = isPremiumUser ? 30 * 60 * 1000 : 60 * 60 * 1000;
            const ahora = Date.now();

            if (ahora - ultimaVez < cooldown) {
                const tiempoRestante = cooldown - (ahora - ultimaVez);
                const minutos = Math.floor(tiempoRestante / (60 * 1000));
                const segundos = Math.floor((tiempoRestante % (60 * 1000)) / 1000);
                return await message.reply(`⏳ *¡Aún estás en cooldown!* Puedes reclamar otro futbolista en *${minutos}m ${segundos}s*`);
            }

            if (!sock) {
                return await message.reply('❌ *Error de Conexión.*');
            }

            const futbolistaReclamado = obtenerFutbolistaAleatorio();
            futbolistasData[senderNumber].futbolistas.push(futbolistaReclamado.nombre);
            futbolistasData[senderNumber].ultimoClaim = ahora;
            db.setFutbolistas(senderNumber, futbolistasData[senderNumber]);
            guardarCambios();

            // Buscar imagen en Pinterest
            await message.reply('🔍 *Buscando tu nuevo futbolista...*');
            const imagenUrl = await buscarImagenFutbolista(futbolistaReclamado.nombreFormateado, futbolistaReclamado.pais);

            const caption =
                `🎉 *¡Has reclamado un futbolista!*\n` +
                `━━━━━━━━━━\n\n` +
                `*Jugador:* ${formatoNombre(futbolistaReclamado.nombre)}\n` +
                `*Selección:* ${futbolistaReclamado.pais}\n` +
                `*Posición:* ${futbolistaReclamado.posicion}\n` +
                `*Calidad:* ${futbolistaReclamado.calidad}\n` +
                `*Precio de Venta:* ${obtenerPrecioVenta(futbolistaReclamado.calidad).toLocaleString()} monedas\n\n` +
                `_¡Felicidades, @${senderNumber}! Reclama de nuevo en 1 hora._`;

            if (imagenUrl) {
                await sock.sendMessage(groupJid, {
                    image: { url: imagenUrl },
                    caption: caption,
                    mentions: [senderJid]
                });
            } else {
                await message.reply(caption + '\n\n⚠️ _No se pudo cargar la imagen desde Pinterest._', { mentions: [senderJid] });
            }
            
            return;
        }

        // SUBCOMANDO: give / dar (Solo owners)
        if (subCommand === 'give' || subCommand === 'dar') {
            const isOwner = botConfig.owners.some(o => o.includes(senderNumber));
            if (!isOwner) {
                return await message.reply('❌ *Este comando es solo para creadores/owners.*');
            }

            const mentionedJids = message?.mentions;
            let receptorJid = mentionedJids?.[0];
            let receptorNumber = receptorJid ? receptorJid.split('@')[0] : null;

            if (!receptorNumber && args[1]) {
                const query = args[1].replace(/^@/, '').trim().toLowerCase();
                for (const [key, u] of Object.entries(global.db?.data?.users || {})) {
                    if (u?.apodo && u.apodo.toLowerCase() === query) {
                        receptorNumber = key.split('@')[0].split(':')[0];
                        receptorJid = `${receptorNumber}@s.whatsapp.net`;
                        break;
                    }
                }
                if (!receptorNumber && /^\d+$/.test(query)) {
                    receptorNumber = query;
                    receptorJid = `${query}@s.whatsapp.net`;
                }
            }

            const nombreFutbolistaEntrada = args.slice(2).join('');
            let futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);

            // Fallback: buscar el futbolista en todo el texto del mensaje ignorando tildes, guiones y emojis
            if (!futbolista && text) {
                const textNorm = normalizarTexto(text);
                futbolista = LISTA_FUTBOLISTAS.find(fb => {
                    const normFb = normalizarTexto(fb.nombreFormateado);
                    return normFb.length >= 3 && textNorm.includes(normFb);
                });
            }

            if (!receptorNumber || !futbolista) {
                return await message.reply('❌ *Futbolista no reconocido.*\n\n_Ejemplo: .fpj give @usuario luis_suarez_');
            }

            if (!futbolistasData[receptorNumber]) {
                futbolistasData[receptorNumber] = { futbolistas: [], bloqueados: [], ultimoClaim: 0, jid: receptorJid };
            }

            futbolistasData[receptorNumber].futbolistas.push(futbolista.nombre);
            guardarCambios();

            const nombreOtorgado = formatoNombre(futbolista.nombre);
            return await message.reply(
                `⚽ *¡FUTBOLISTA OTORGADO!* ⚽\n` +
                '━━━━━━━━━━\n\n' +
                `Se le ha otorgado *${nombreOtorgado}* (${futbolista.posicion} • ${futbolista.calidad}) a @${receptorNumber}.\n\n` +
                `*Cantidad:* +1`,
                { mentions: [receptorJid] }
            );
        }
        
        // SUBCOMANDO: regalar
        if (subCommand === 'regalar') {
            const mentionedJids = message?.mentions;
            const nombreFutbolistaEntrada = args.slice(2).join('');
            
            if (!mentionedJids || mentionedJids.length === 0 || !nombreFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj regalar @usuario [Nombre_Futbolista]_');
            }
            
            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            const futbolista = buscarFutbolistaPorNombre(nombreFutbolistaEntrada);
            
            if (!futbolista) {
                return await message.reply(`❌ *Futbolista no reconocido.*`);
            }

            const indexEnInventario = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === futbolista.nombre);
            
            if (indexEnInventario === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(futbolista.nombre)}* para regalar.`);
            }

            if (!futbolistasData[receptorNumber]) {
                futbolistasData[receptorNumber] = { futbolistas: [], ultimoClaim: 0, jid: receptorJid };
            }

            futbolistasData[senderNumber].futbolistas.splice(indexEnInventario, 1);
            futbolistasData[receptorNumber].futbolistas.push(futbolista.nombre);
            guardarCambios();

            const nombreRegalado = formatoNombre(futbolista.nombre);

            const mensaje = 
                `🎁 *¡REGALO DE FUTBOLISTA!* 🎁\n` +
                `━━━━━━━━━━\n\n` +
                `@${senderNumber} le ha regalado su *${nombreRegalado}* (${futbolista.calidad}) de *${futbolista.pais}* a @${receptorNumber}.\n\n` +
                '_¡Qué generoso!_ 💖';

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio (proponer)
        if (subCommand === 'intercambio' && args[1] && !['aceptar', 'rechazar'].includes(args[1].toLowerCase())) {
            const mentionedJids = message?.mentions;
            const miFutbolistaEntrada = args[2];
            const suFutbolistaEntrada = args[3];

            if (!mentionedJids || mentionedJids.length === 0 || !miFutbolistaEntrada || !suFutbolistaEntrada) {
                return await message.reply('❌ *Formato inválido*\n\n_Usa: /fpj intercambio @user [mi_futbolista] [su_futbolista]_');
            }

            const receptorJid = mentionedJids[0];
            const receptorNumber = receptorJid.split('@')[0];
            
            if (senderNumber === receptorNumber) {
                return await message.reply('❌ *No puedes intercambiar contigo mismo.*');
            }

            const miFB = buscarFutbolistaPorNombre(miFutbolistaEntrada);
            const suFB = buscarFutbolistaPorNombre(suFutbolistaEntrada);

            if (!miFB || !suFB) {
                return await message.reply('❌ *Futbolista no reconocido.*');
            }

            const indexMiFB = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === miFB.nombre);
            if (indexMiFB === -1) {
                return await message.reply(`❌ *No tienes a ${formatoNombre(miFB.nombre)}* para ofrecer.`);
            }

            if (!futbolistasData[receptorNumber] || !futbolistasData[receptorNumber].futbolistas.includes(suFB.nombre)) {
                return await message.reply(`❌ *@${receptorNumber} no tiene a ${formatoNombre(suFB.nombre)}*`, { mentions: [receptorJid] });
            }

            const tradeKey = `${senderNumber}_${receptorNumber}`;
            intercambiosFutbol[tradeKey] = {
                emisor: senderNumber,
                receptor: receptorNumber,
                emisorFB: miFB.nombre,
                receptorFB: suFB.nombre,
                grupo: groupJid,
                fecha: Date.now(),
                jidEmisor: senderJid,
                jidReceptor: receptorJid
            };
            guardarCambios();

            setTimeout(async () => {
                if (intercambiosFutbol[tradeKey]) {
                    delete intercambiosFutbol[tradeKey];
                    guardarCambios();
                    const mensajeCancelado = `⏳ *Intercambio Cancelado* ⏳\n\nEl intercambio entre @${senderNumber} y @${receptorNumber} ha expirado.`;
                    
                    if (sock) {
                        await sock.sendMessage(groupJid, {
                            text: mensajeCancelado,
                            mentions: [senderJid, receptorJid]
                        });
                    }
                }
            }, 40000);

            const mensaje =
                `🤝 *PROPUESTA DE INTERCAMBIO* 🤝\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* _propone:_ *${formatoNombre(miFB.nombre)}* (${miFB.calidad}) de *${miFB.pais}*\n` +
                `_por el futbolista de_ *@${receptorNumber}:* *${formatoNombre(suFB.nombre)}* (${suFB.calidad}) de *${suFB.pais}*\n\n` +
                `*Para aceptar:*\n/fpj intercambio aceptar @${senderNumber}\n\n` +
                `*Para rechazar:*\n/fpj intercambio rechazar @${senderNumber}\n\n` +
                `_Tienes 40 segundos para responder._ ⏳`;

            return await message.reply(mensaje, { mentions: [senderJid, receptorJid] });
        }

        // SUBCOMANDO: intercambio aceptar/rechazar
        if (subCommand === 'intercambio' && ['aceptar', 'rechazar'].includes(args[1]?.toLowerCase())) {
            const accion = args[1].toLowerCase();
            const mentionedJids = message?.mentions;

            if (!mentionedJids || mentionedJids.length === 0) {
                return await message.reply(`❌ *Formato inválido*\n\n_Usa: /fpj intercambio ${accion} @usuario_`);
            }

            const emisorJid = mentionedJids[0];
            const emisorNumber = emisorJid.split('@')[0];
            const tradeKey = `${emisorNumber}_${senderNumber}`;

            const propuesta = intercambiosFutbol[tradeKey];

            if (!propuesta || propuesta.receptor !== senderNumber || propuesta.grupo !== groupJid) {
                return await message.reply(`❌ *No hay propuesta pendiente* de @${emisorNumber}`, { mentions: [emisorJid] });
            }

            delete intercambiosFutbol[tradeKey];
            guardarCambios();

            if (accion === 'rechazar') {
                const mensaje = 
                    `💔 *INTERCAMBIO RECHAZADO* 💔\n` +
                    `━━━━━━━━━━\n\n` +
                    `*@${senderNumber}* ha rechazado la propuesta de *@${emisorNumber}*.\n\n` +
                    '_Será en otra ocasión..._ 😔';
                return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
            }

            const miFBSimple = propuesta.receptorFB;
            const suFBSimple = propuesta.emisorFB;

            const indexMiFB = futbolistasData[senderNumber].futbolistas.findIndex(fbName => fbName === miFBSimple);
            const indexSuFB = futbolistasData[emisorNumber].futbolistas.findIndex(fbName => fbName === suFBSimple);

            if (indexMiFB === -1) {
                return await message.reply(`❌ *ERROR: Ya no tienes a ${formatoNombre(miFBSimple)}*`, { mentions: [senderJid] });
            }
            if (indexSuFB === -1) {
                return await message.reply(`❌ *ERROR: @${emisorNumber} ya no tiene a ${formatoNombre(suFBSimple)}*`, { mentions: [emisorJid] });
            }
            
            futbolistasData[senderNumber].futbolistas.splice(indexMiFB, 1);
            futbolistasData[emisorNumber].futbolistas.splice(indexSuFB, 1);

            futbolistasData[senderNumber].futbolistas.push(suFBSimple);
            futbolistasData[emisorNumber].futbolistas.push(miFBSimple);
            
            guardarCambios();

            const mensaje =
                `✅ *¡INTERCAMBIO EXITOSO!* ✅\n` +
                '━━━━━━━━━━\n\n' +
                `*@${senderNumber}* recibe: *${formatoNombre(suFBSimple)}*\n` +
                `*@${emisorNumber}* recibe: *${formatoNombre(miFBSimple)}*\n\n` +
                '_¡Nuevos futbolistas para ambos!_ ⚽';

            return await message.reply(mensaje, { mentions: [senderJid, emisorJid] });
        }

        // COMANDO: /myfpj
        if (command.match(/^(myfpj)$/i)) {
            const inventario = futbolistasData[senderNumber]?.futbolistas || [];
            const bloqueados = futbolistasData[senderNumber]?.bloqueados || [];

            userDb = await global.db.getUser(senderJid, groupJid);
            const monedasActuales = obtenerMonedas(userDb).toLocaleString();

            if (inventario.length === 0) {
                return await message.reply(`⚽ *COLECCIÓN DE* @${senderNumber} ⚽\n\n_No tienes futbolistas. Usa /fpj reclamar para obtener uno._\n\n*Monedas Totales:* ${monedasActuales} 💰`, { mentions: [senderJid] });
            }

            const conteo = inventario.reduce((acc, name) => {
                acc[name] = (acc[name] || 0) + 1;
                return acc;
            }, {});

            const copiasBloqueadas = {};
            for (const key of bloqueados) {
                const partes = key.split('_');
                const num = parseInt(partes[partes.length - 1]);
                const nombre = partes.slice(0, partes.length - 1).join('_');
                if (!isNaN(num)) {
                    copiasBloqueadas[nombre] = (copiasBloqueadas[nombre] || 0) + 1;
                }
            }

            let mensaje = `⚽ *COLECCIÓN DE* @${senderNumber} _(${inventario.length} Futbolistas)_ ⚽\n` +
                          `*Monedas Totales:* ${monedasActuales} 💰\n` +
                          '━━━━━━━━━━\n';

            const futbolistasUnicos = Object.keys(conteo).sort();

            futbolistasUnicos.forEach(nameSimple => {
                const fbData = buscarFutbolistaPorNombre(nameSimple);
                const count = conteo[nameSimple];
                const calidad = fbData ? fbData.calidad : '???';
                const pais = fbData ? fbData.pais : '???';
                const posicion = fbData ? fbData.posicion : '???';
                const precio = fbData ? obtenerPrecioVenta(fbData.calidad).toLocaleString() : '???';
                const bloq = copiasBloqueadas[nameSimple] || 0;
                const bloqTexto = bloq > 0 ? ` 🔒x${bloq}` : '';

                mensaje += `\n*${formatoNombre(nameSimple)}* x${count}${bloqTexto}\n` +
                          `└ ${pais} • ${posicion} • ${calidad}\n` +
                          `└ Venta: ${precio} c/u`;
            });

            if (bloqueados.length > 0) {
                mensaje += `\n\n🔒 *Bloqueados:* ${bloqueados.length} copia(s) protegida(s) del \`vender all\``;
            }

            mensaje += '\n\n_Usa /myfpj ver [futbolista] para ver su imagen._';

            return await message.reply(mensaje, { mentions: [senderJid] });
        }
        
        return await message.reply(
            '❌ *Comando no reconocido.*\n\n' +
            '_Usa /fpj para ver la lista de comandos._'
        );

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en sistema de futbolistas:', error.code || error.message, '\x1b[0m');
        
        let userMessage = '❌ *Error en el sistema*';
        if (error.code === 'EACCES') {
            userMessage += '\n\n_Error de permisos (EACCES). Contacta al administrador._';
        } else {
            userMessage += '\n\n_Ocurrió un error al procesar tu solicitud._';
        }
        
        return await message.reply(userMessage);
    }
};

handler.help = ['fpj', 'fpj give', 'fpj reclamar', 'fpj claim', 'myfpj', 'myfpj ver', 'fpj regalar', 'fpj intercambio', 'fpj vender', 'fpj vender all', 'fpj sell', 'fpj sell all', 'fpj block', 'fpj unlock', 'fpj bloquear', 'fpj desbloquear'];
handler.tags = ['juegos'];
handler.command = /^(fpj|myfpj)$/i;

module.exports = handler;
module.exports.FUTBOLISTAS_BASE = FUTBOLISTAS_BASE;
module.exports.buscarImagenFutbolista = buscarImagenFutbolista;
handler.group = false