'use strict';

const fs = require('fs');
const path = require('path');
const botConfig = require('../config');

// ─── CONFIGURACIÓN DE POLÍTICA ────────────────────────────────────────────────
// true  = Modera también a los administradores del grupo si usan malas palabras
// false = Los administradores del grupo quedan exentos de la moderación
const MODERATE_ADMINS = true;

// true  = Modera también a los administradores del bot (staff) si usan malas palabras
// false = Los administradores del bot (configurados en config.js) quedan exentos de la moderación
const MODERATE_STAFF = true;

// ─── Rutas de archivos de datos ───────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, '..', 'data');
const CHATMOD_FILE = path.join(DATA_DIR, 'chatmod.json');
const BADWORDS_FILE = path.join(DATA_DIR, 'badwords.json');

// Asegurar existencia de directorio
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ─── Carga y persistencia de configuración por grupo ──────────────────────────
let chatmodConfigCache = null;
const groupRegexCache = new Map(); // cleanGroupJid -> RegExp de palabras personalizadas

function loadChatmodConfig() {
    if (chatmodConfigCache) return chatmodConfigCache;
    try {
        if (fs.existsSync(CHATMOD_FILE)) {
            const raw = fs.readFileSync(CHATMOD_FILE, 'utf8');
            chatmodConfigCache = JSON.parse(raw);
            return chatmodConfigCache;
        }
    } catch (e) {
        console.error('[ChatMod] Error cargando chatmod.json:', e.message);
    }
    chatmodConfigCache = {};
    return chatmodConfigCache;
}

function saveChatmodConfig(config) {
    try {
        chatmodConfigCache = config;
        fs.writeFileSync(CHATMOD_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('[ChatMod] Error guardando chatmod.json:', e.message);
        return false;
    }
}

/**
 * Obtiene la configuración específica de un grupo
 */
function getGroupConfig(groupJid) {
    if (!groupJid) return { enabled: false, customWords: [], bypassUsers: [] };
    const clean = groupJid.split('@')[0];
    const cfg = loadChatmodConfig();
    const raw = cfg[clean] || cfg[groupJid];

    if (typeof raw === 'boolean') {
        // Compatibilidad hacia atrás si era boolean
        return { enabled: raw, customWords: [], bypassUsers: [] };
    }
    if (raw && typeof raw === 'object') {
        return {
            enabled: !!raw.enabled,
            customWords: Array.isArray(raw.customWords) ? raw.customWords : [],
            bypassUsers: Array.isArray(raw.bypassUsers) ? raw.bypassUsers : []
        };
    }
    return { enabled: false, customWords: [], bypassUsers: [] };
}

/**
 * Actualiza la configuración de un grupo de forma atómica
 */
function updateGroupConfig(groupJid, updater) {
    const clean = groupJid.split('@')[0];
    const cfg = loadChatmodConfig();
    const current = getGroupConfig(groupJid);
    const updated = updater(current);
    cfg[clean] = updated;
    delete cfg[groupJid];
    saveChatmodConfig(cfg);
    groupRegexCache.delete(clean);
    return updated;
}

function isChatmodEnabled(groupJid) {
    return getGroupConfig(groupJid).enabled === true;
}

// ─── Carga y compilación ultra-rápida de malas palabras globales ───────────────
let badwordsRegex = null;
let badwordsList = [];

function loadBadwords() {
    try {
        if (fs.existsSync(BADWORDS_FILE)) {
            const raw = fs.readFileSync(BADWORDS_FILE, 'utf8');
            const data = JSON.parse(raw);
            if (Array.isArray(data.words)) {
                badwordsList = data.words
                    .map(w => String(w).trim().toLowerCase())
                    .filter(w => w.length >= 3);
            }
        }
    } catch (e) {
        console.error('[ChatMod] Error cargando badwords.json:', e.message);
    }

    if (!badwordsList.length) {
        badwordsList = ['puto', 'puta', 'mierda', 'pendejo', 'pendeja', 'pelotudo', 'concha', 'verga', 'pija', 'fuck', 'shit', 'bitch', 'asshole'];
    }

    // Compilar una única expresión regular optimizada en V8
    const escaped = badwordsList.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    badwordsRegex = new RegExp(escaped.join('|'), 'i');
    console.log(`[ChatMod] ✓ Cargadas ${badwordsList.length} malas palabras globales`);
}

loadBadwords();

// Regex para palabras personalizadas de un grupo en memoria
function getGroupCustomRegex(groupJid, customWords) {
    if (!Array.isArray(customWords) || customWords.length === 0) return null;
    const clean = groupJid.split('@')[0];
    if (groupRegexCache.has(clean)) {
        return groupRegexCache.get(clean);
    }
    const escaped = customWords.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const rx = new RegExp(escaped.join('|'), 'i');
    groupRegexCache.set(clean, rx);
    return rx;
}

// ─── Excepciones de palabras legítimas en español para evitar falsos positivos ──
// Por ejemplo: 'computadora' o 'disputa' contienen 'puta', pero son palabras normales.
const LEGIT_EXCEPTIONS = [
    'computadora', 'computadoras', 'computador', 'computadores', 'computo', 'computos', 'computacion',
    'reputacion', 'reputaciones', 'disputa', 'disputas', 'disputar', 'disputado', 'disputando',
    'diputado', 'diputados', 'diputada', 'diputadas', 'imputar', 'imputado', 'imputados', 'imputacion',
    'imputaciones', 'amputado', 'amputar', 'amputacion', 'escupitajo', 'anticonceptivo'
];

const LEGIT_REGEX = new RegExp(LEGIT_EXCEPTIONS.join('|'), 'gi');

// ─── Normalización de texto para detección de evasiones ───────────────────────
function normalizeForCheck(text) {
    if (!text || typeof text !== 'string') return '';
    return text
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '') // Quitar acentos
        .replace(/[@]/g, 'a')
        .replace(/[$]/g, 's')
        .replace(/0/g, 'o')
        .replace(/1/g, 'i')
        .replace(/3/g, 'e')
        .replace(/4/g, 'a')
        .replace(/5/g, 's')
        .replace(/7/g, 't');
}

/**
 * Detecta si el texto contiene alguna mala palabra global o personalizada del grupo
 * (incluso como subcadena en "holaputohola")
 */
function containsBadWord(rawText, groupJid, customWords = []) {
    if (!rawText || typeof rawText !== 'string') return false;

    // Primero remover palabras legítimas que podrían causar falsos positivos
    const sanitized = rawText.replace(LEGIT_REGEX, ' ');
    const norm = normalizeForCheck(sanitized);

    // 1. Detección de malas palabras globales
    if (badwordsRegex && badwordsRegex.test(norm)) return true;

    // 2. Detección compacta (sin espacios ni símbolos, detecta "p.u.t.o" o "p u t o")
    const compact = norm.replace(/[^a-z0-9]/g, '');
    if (compact && badwordsRegex && badwordsRegex.test(compact)) return true;

    // 3. Detección de palabras personalizadas añadidas a este grupo
    if (Array.isArray(customWords) && customWords.length > 0) {
        const customRx = getGroupCustomRegex(groupJid, customWords);
        if (customRx) {
            if (customRx.test(norm)) return true;
            if (compact && customRx.test(compact)) return true;
        }
    }

    return false;
}

// ─── Extraer texto de un mensaje Baileys ───────────────────────────────────────
function extractText(baileyMsg) {
    if (!baileyMsg) return '';
    const m = baileyMsg.message || baileyMsg;
    return (
        m.conversation ||
        m.extendedTextMessage?.text ||
        m.imageMessage?.caption ||
        m.videoMessage?.caption ||
        m.documentMessage?.caption ||
        m.buttonsResponseMessage?.selectedButtonId ||
        m.listResponseMessage?.singleSelectReply?.selectedRowId ||
        m.templateButtonReplyMessage?.selectedId ||
        ''
    ).trim();
}

// ─── Extraer todas las identidades posibles de un socket de bot ───────────────
function getBotIdentities(sock) {
    const ids = new Set();
    if (!sock) return ids;

    const addClean = (val) => {
        if (!val) return;
        const str = String(val).split('@')[0].split(':')[0].replace(/\D/g, '');
        if (str) {
            ids.add(str);
            // Normalización para prefijos de Argentina (549 vs 54)
            if (str.startsWith('549') && str.length >= 12) ids.add('54' + str.slice(3));
            if (str.startsWith('54') && !str.startsWith('549') && str.length >= 11) ids.add('549' + str.slice(2));
        }
    };

    if (sock.user) {
        addClean(sock.user.id);
        addClean(sock.user.jid);
        addClean(sock.user.lid);
    }
    if (sock._phoneNumber) addClean(sock._phoneNumber);
    if (sock._subNum) addClean(sock._subNum);
    if (sock._lid) addClean(sock._lid);

    return ids;
}

// ─── Recopilar TODOS los sockets de bots conectados en el sistema ─────────────
function getAllConnectedBotSocks(currentSock) {
    const socks = [];
    const seenNumbers = new Set();

    const pushSock = (s) => {
        if (!s || !s.user || typeof s.sendMessage !== 'function') return;
        const identities = getBotIdentities(s);
        let key = null;
        for (const id of identities) {
            if (seenNumbers.has(id)) return;
            if (!key) key = id;
        }
        if (key) {
            identities.forEach(id => seenNumbers.add(id));
            socks.push(s);
        }
    };

    // 1. Socket actual que recibió el mensaje
    if (currentSock) pushSock(currentSock);

    // 2. Bot principal
    if (global.conn) pushSock(global.conn);

    // 3. Subbots de activeSocks en subbot-serbot
    try {
        const serbot = require('./SUBBOTS/subbot-serbot');
        if (serbot?.activeSocks && typeof serbot.activeSocks.values === 'function') {
            for (const s of serbot.activeSocks.values()) {
                pushSock(s);
            }
        }
    } catch (_) {}

    // 4. Subbots en global.subConns
    if (Array.isArray(global.subConns)) {
        for (const s of global.subConns) {
            pushSock(s);
        }
    }

    // 5. Subbots en global.subbotLidMap
    if (global.subbotLidMap instanceof Map) {
        for (const s of global.subbotLidMap.values()) {
            pushSock(s);
        }
    }

    return socks;
}

// ─── Verificar si un socket específico es admin en el grupo ───────────────────
function isBotSockAdmin(sock, participants) {
    if (!sock || !Array.isArray(participants) || participants.length === 0) return false;

    const botIds = getBotIdentities(sock);
    if (botIds.size === 0) return false;

    for (const p of participants) {
        const pNum = String(p.id || '').split('@')[0].split(':')[0].replace(/\D/g, '');
        const pPhone = p.phoneNumber ? String(p.phoneNumber).split('@')[0].split(':')[0].replace(/\D/g, '') : null;
        const pLid = p.lid ? String(p.lid).split('@')[0].split(':')[0].replace(/\D/g, '') : null;

        let matches = botIds.has(pNum);
        if (!matches && pPhone && botIds.has(pPhone)) matches = true;
        if (!matches && pLid && botIds.has(pLid)) matches = true;

        if (matches) {
            const isAdmin = p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin === true;
            if (isAdmin) return true;
        }
    }
    return false;
}

// ─── Búsqueda inteligente de bot administrador en el grupo ───────────────────
// Si hay varios bots en el grupo, busca uno que sea admin para poder eliminar el mensaje
async function findAdminBotSock(chatId, fallbackSock) {
    try {
        const coordinator = require('../lib/subbotCoordinator');
        const metadata = await coordinator.getReliableGroupMetadata(chatId, fallbackSock);
        return await coordinator.findAdminBotSocket(chatId, fallbackSock, metadata);
    } catch (_) {
        return null;
    }
}

// ─── Control de deduplicación de borrado entre múltiples bots ────────────────
const recentDeletedBadMessages = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [key, ts] of recentDeletedBadMessages.entries()) {
        if (now - ts > 30000) recentDeletedBadMessages.delete(key);
    }
}, 15000);

// ─── Función principal de verificación y moderación ──────────────────────────
async function checkAndModerateMessage(baileyMessage, sock) {
    try {
        if (!baileyMessage?.key) return false;
        const chatId = baileyMessage.key.remoteJid;
        if (!chatId || !chatId.endsWith('@g.us')) return false;

        // Cargar configuración específica de este grupo
        const groupConfig = getGroupConfig(chatId);

        // Si la moderación está desactivada en este grupo, no hacer nada
        if (!groupConfig.enabled) return false;

        // Ignorar mensajes enviados por el propio bot
        if (baileyMessage.key.fromMe) return false;

        const messageId = baileyMessage.key.id;
        if (!messageId) return false;

        // Deduplicación atómica: si ya fue procesado por otro bot en el grupo, saltar
        const dedupKey = `${chatId}:${messageId}`;
        if (recentDeletedBadMessages.has(dedupKey)) return false;

        const text = extractText(baileyMessage);
        if (!text) return false;

        // Comprobar si contiene malas palabras (globales o personalizadas del grupo)
        if (!containsBadWord(text, chatId, groupConfig.customWords)) return false;

        // Reclamar inmediatamente para que los demás bots no dupliquen la advertencia
        recentDeletedBadMessages.set(dedupKey, Date.now());

        // Identificar al usuario infractor
        const senderJid = baileyMessage.key.participant || baileyMessage.participant || chatId;
        const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');

        // 1. Ignorar si es owner del bot
        if (botConfig.isOwner(senderNum) || botConfig.isOwner(`${senderNum}@s.whatsapp.net`)) {
            return false;
        }

        // 2. Ignorar si es admin del bot (staff) y MODERATE_STAFF está desactivado
        if (!MODERATE_STAFF && botConfig.isAdminBot(senderNum)) {
            return false;
        }

        // 3. Ignorar si el usuario tiene bypass activo en este grupo específico
        if (groupConfig.bypassUsers.includes(senderNum)) {
            return false;
        }

        // 4. Verificar si el mensaje proviene de un bot (el propio bot enviando comandos)
        // Esto evita que se modere la salida de comandos que contengan palabras no permitidas
        const allBotSocks = getAllConnectedBotSocks(sock);
        const botIdentitiesSet = new Set();
        for (const botSock of allBotSocks) {
            const ids = getBotIdentities(botSock);
            for (const id of ids) {
                botIdentitiesSet.add(id);
            }
        }
        
        // Si el remitente es alguno de los bots conectados, no moderar
        if (botIdentitiesSet.has(senderNum)) {
            return false;
        }

        // 5. Obtener metadatos del grupo para verificar si el usuario es admin
        let groupMetadata = null;
        try {
            const { getGroupMetadataCached } = require('../lib/groupCache');
            groupMetadata = await getGroupMetadataCached(sock || global.conn, chatId);
        } catch (_) {}

        if (!MODERATE_ADMINS && groupMetadata) {
            const isAdmin = groupMetadata.adminSet instanceof Set
                ? groupMetadata.adminSet.has(senderNum)
                : !!(groupMetadata.participants?.some(p => {
                    const pNum = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
                    return pNum === senderNum && (p.admin === 'admin' || p.admin === 'superadmin');
                }));

            if (isAdmin) {
                return false; // Administrador del grupo exento
            }
        }

        // 6. Buscar entre los bots presentes en el grupo uno que sea administrador
        const adminBotSock = await findAdminBotSock(chatId, sock);

        if (!adminBotSock || !adminBotSock.user) {
            console.log(`[ChatMod] ⚠️ Mala palabra detectada en ${chatId} de @${senderNum}, pero ningún bot es admin en este grupo para eliminarlo.`);
            return false;
        }

        // 7. Eliminar el mensaje ofensivo
        try {
            await adminBotSock.sendMessage(chatId, { delete: baileyMessage.key });
            console.log(`[ChatMod] 🗑️ Mensaje con mala palabra eliminado de @${senderNum} en ${chatId}`);
        } catch (delErr) {
            console.error('[ChatMod] Error eliminando mensaje:', delErr.message);
        }

        // 8. Enviar aviso mencionando al usuario (sin sanción, solo advertencia)
        try {
            const aviso = `⚠️ @${senderNum} Por favor modera tu lenguaje para evitar posibles sanciones.`;
            await adminBotSock.sendMessage(chatId, {
                text: aviso,
                mentions: [senderJid.includes('@') ? senderJid : `${senderNum}@s.whatsapp.net`]
            });
        } catch (warnErr) {
            console.error('[ChatMod] Error enviando advertencia:', warnErr.message);
        }

        return true;
    } catch (e) {
        console.error('[ChatMod] Error en checkAndModerateMessage:', e.message);
        return false;
    }
}

// ─── Handler de comando: .chatmod ─────────────────────────────────────────────
let handler = async (message, { conn, args }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from || message.key?.remoteJid;

    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo puede usarse en *grupos*.');
    }

    const subArg = (args && args[0] ? args[0] : '').toLowerCase();
    const groupConfig = getGroupConfig(chatId);

    // ── Si no hay argumento o es 'status', mostrar el estado actual del grupo ──
    if (!subArg || subArg === 'status' || subArg === 'estado') {
        const isEnabled = groupConfig.enabled;
        const statusText = isEnabled ? '🟢 *Activada*' : '🔴 *Desactivada*';
        const customCount = groupConfig.customWords.length;
        const bypassCount = groupConfig.bypassUsers.length;

        let extraWordsInfo = 'Ninguna';
        if (customCount > 0) {
            extraWordsInfo = groupConfig.customWords.map(w => `\`${w}\``).join(', ');
        }

        let bypassInfo = 'Ninguno';
        if (bypassCount > 0) {
            bypassInfo = groupConfig.bypassUsers.map(u => `@${u}`).join(', ');
        }

        return message.reply(
            `🛡️ *MODERACIÓN DE LENGUAJE DEL GRUPO*\n\n` +
            `📊 *Estado:* ${statusText}\n` +
            `⚙️ *Moderar administradores del grupo:* ${MODERATE_ADMINS ? 'Sí' : 'No'}\n` +
            `⚙️ *Moderar staff del bot:* ${MODERATE_STAFF ? 'Sí' : 'No'}\n` +
            `📝 *Palabras extra bloqueadas (${customCount}):* ${extraWordsInfo}\n` +
            `🎟️ *Usuarios con Bypass (${bypassCount}):* ${bypassInfo}\n\n` +
            `💡 *Comandos disponibles (solo admins):*\n` +
            `• *.chatmod on* — Activar moderación en este grupo\n` +
            `• *.chatmod off* — Desactivar moderación en este grupo\n` +
            `• *.chatmod addword <palabra>* — Bloquear palabra extra en este grupo\n` +
            `• *.chatmod delword <palabra>* — Quitar palabra extra de este grupo\n` +
            `• *.chatmod bypass on @user / me* — Activar bypass para un usuario\n` +
            `• *.chatmod bypass off @user / me* — Desactivar bypass para un usuario\n` +
            `• *.chatmod* — Ver este panel de estado\n\n` +
            `ℹ️ _Cada grupo tiene su propia configuración independiente._`,
            { mentions: groupConfig.bypassUsers.map(u => `${u}@s.whatsapp.net`) }
        );
    }

    // ── Verificación de permisos de Administrador / Owner ─────────────────────
    const senderJid = message.sender || message.author || message.from;
    const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');
    const isOwner = botConfig.isOwner(senderNum) || botConfig.isOwner(`${senderNum}@s.whatsapp.net`);

    if (!isOwner) {
        let isUserAdmin = false;
        try {
            const { getGroupMetadataCached } = require('../lib/groupCache');
            const metadata = await getGroupMetadataCached(sock, chatId);
            if (metadata?.adminSet instanceof Set) {
                isUserAdmin = metadata.adminSet.has(senderNum);
            } else if (Array.isArray(metadata?.participants)) {
                isUserAdmin = metadata.participants.some(p => {
                    const pNum = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
                    return pNum === senderNum && (p.admin === 'admin' || p.admin === 'superadmin');
                });
            }
        } catch (_) {}

        if (!isUserAdmin) {
            return message.reply('❌ Solo los *administradores* del grupo pueden configurar la moderación de lenguaje.');
        }
    }

    // ── .chatmod on ───────────────────────────────────────────────────────────
    if (subArg === 'on' || subArg === 'activar' || subArg === '1') {
        updateGroupConfig(chatId, cfg => {
            cfg.enabled = true;
            return cfg;
        });
        return message.reply(
            '✅ *Moderación de lenguaje ACTIVADA en este grupo.*\n\n' +
            '🛡️ Los mensajes con malas palabras o insultos serán eliminados automáticamente y se advertirá al usuario.\n' +
            '_(Recuerda que al menos un bot debe ser administrador del grupo para poder eliminar mensajes)_'
        );
    }

    // ── .chatmod off ──────────────────────────────────────────────────────────
    if (subArg === 'off' || subArg === 'desactivar' || subArg === '0') {
        updateGroupConfig(chatId, cfg => {
            cfg.enabled = false;
            return cfg;
        });
        return message.reply('❌ *Moderación de lenguaje DESACTIVADA en este grupo.*');
    }

    // ── .chatmod addword <palabra> ───────────────────────────────────────────
    if (subArg === 'addword' || subArg === 'add' || subArg === 'agregar') {
        const rawWord = args[1] ? args.slice(1).join(' ').trim().toLowerCase() : '';
        if (!rawWord || rawWord.length < 2) {
            return message.reply('⚠️ Debes indicar la palabra que deseas bloquear en este grupo.\nEjemplo: *.chatmod addword palabramala*');
        }

        const normalizedWord = normalizeForCheck(rawWord).replace(/[^a-z0-9]/g, '');
        if (!normalizedWord) {
            return message.reply('⚠️ La palabra contiene caracteres inválidos.');
        }

        const updated = updateGroupConfig(chatId, cfg => {
            if (!cfg.customWords.includes(normalizedWord)) {
                cfg.customWords.push(normalizedWord);
            }
            return cfg;
        });

        return message.reply(`✅ Palabra \`${normalizedWord}\` agregada a la lista de bloqueadas de este grupo.\n📊 Total en este grupo: *${updated.customWords.length}* palabras extra.`);
    }

    // ── .chatmod delword <palabra> ───────────────────────────────────────────
    if (subArg === 'delword' || subArg === 'del' || subArg === 'quitar' || subArg === 'remove') {
        const rawWord = args[1] ? args.slice(1).join(' ').trim().toLowerCase() : '';
        if (!rawWord) {
            return message.reply('⚠️ Debes indicar la palabra que deseas quitar de este grupo.\nEjemplo: *.chatmod delword palabramala*');
        }

        const normalizedWord = normalizeForCheck(rawWord).replace(/[^a-z0-9]/g, '');
        let removed = false;

        const updated = updateGroupConfig(chatId, cfg => {
            const idx = cfg.customWords.indexOf(normalizedWord);
            if (idx !== -1) {
                cfg.customWords.splice(idx, 1);
                removed = true;
            }
            return cfg;
        });

        if (!removed) {
            return message.reply(`⚠️ La palabra \`${normalizedWord}\` no estaba en la lista de palabras personalizadas de este grupo.`);
        }

        return message.reply(`🗑️ Palabra \`${normalizedWord}\` eliminada de este grupo.\n📊 Total en este grupo: *${updated.customWords.length}* palabras extra.`);
    }

    // ── .chatmod bypass on/off <@user | me | numero> ─────────────────────────
    if (subArg === 'bypass') {
        const action = (args[1] || '').toLowerCase(); // 'on' o 'off'
        if (action !== 'on' && action !== 'off') {
            return message.reply(
                '⚠️ Uso incorrecto de bypass.\n\n' +
                '• *.chatmod bypass on @usuario* — Dar bypass en este grupo\n' +
                '• *.chatmod bypass off @usuario* — Quitar bypass en este grupo\n' +
                '• *.chatmod bypass on me* — Darte bypass a ti mismo en este grupo\n' +
                '• *.chatmod bypass off me* — Quitarte bypass a ti mismo'
            );
        }

        const targetArg = (args[2] || '').toLowerCase();
        let targetNum = null;

        if (targetArg === 'me' || targetArg === 'yo') {
            targetNum = senderNum;
        } else if (message.mentions && message.mentions.length > 0) {
            targetNum = message.mentions[0].split('@')[0].split(':')[0].replace(/\D/g, '');
        } else if (message.quoted && message.quoted.sender) {
            targetNum = message.quoted.sender.split('@')[0].split(':')[0].replace(/\D/g, '');
        } else if (targetArg) {
            targetNum = targetArg.replace(/\D/g, '');
        }

        if (!targetNum || targetNum.length < 5) {
            return message.reply('⚠️ Debes mencionar a un usuario (@usuario) o usar `me` para indicar quién recibe el bypass.');
        }

        if (action === 'on') {
            updateGroupConfig(chatId, cfg => {
                if (!cfg.bypassUsers.includes(targetNum)) {
                    cfg.bypassUsers.push(targetNum);
                }
                return cfg;
            });

            return message.reply(
                `🎟️ *Bypass ACTIVADO* para @${targetNum} en este grupo.\n` +
                `Sus mensajes no serán eliminados por la moderación de lenguaje.`,
                { mentions: [`${targetNum}@s.whatsapp.net`] }
            );
        } else {
            let removed = false;
            updateGroupConfig(chatId, cfg => {
                const idx = cfg.bypassUsers.indexOf(targetNum);
                if (idx !== -1) {
                    cfg.bypassUsers.splice(idx, 1);
                    removed = true;
                }
                return cfg;
            });

            if (!removed) {
                return message.reply(`⚠️ El usuario @${targetNum} no tenía bypass activo en este grupo.`, { mentions: [`${targetNum}@s.whatsapp.net`] });
            }

            return message.reply(
                `🚫 *Bypass DESACTIVADO* para @${targetNum} en este grupo.\n` +
                `Ahora sus mensajes volverán a ser moderados.`,
                { mentions: [`${targetNum}@s.whatsapp.net`] }
            );
        }
    }

    return message.reply('💡 Uso: *.chatmod on*, *.chatmod off*, *.chatmod addword <palabra>*, *.chatmod bypass on/off @user* o *.chatmod* para ver el estado.');
};

handler.help = [
    'chatmod on',
    'chatmod off',
    'chatmod addword <palabra>',
    'chatmod delword <palabra>',
    'chatmod bypass on/off @user',
    'chatmod'
];
handler.tags = ['admin', 'grupos'];
handler.command = /^(chatmod|modchat|moderacion)$/i;
handler.group = true;

// Handler pasivo ejecutado por el handler central en todos los mensajes
handler.allMessageHandler = async function(message) {
    const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
    const sock = message._sock || global.conn;
    if (baileyMsg && sock) {
        await checkAndModerateMessage(baileyMsg, sock);
    }
};

handler.checkAndModerateMessage = checkAndModerateMessage;
handler.isChatmodEnabled = isChatmodEnabled;
handler.getGroupConfig = getGroupConfig;
handler.MODERATE_ADMINS = MODERATE_ADMINS;
handler.MODERATE_STAFF = MODERATE_STAFF;

module.exports = handler;
