const fs = require('fs');
const path = require('path');

// Directorio para guardar configuraciones en la raíz del proyecto
const DATA_DIR = path.join(__dirname, '..', 'data');
const ANTILINKS_FILE = path.join(DATA_DIR, 'antilinks.json');

// Asegurar que el directorio y el archivo existen
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(ANTILINKS_FILE)) {
    fs.writeFileSync(ANTILINKS_FILE, JSON.stringify({}, null, 2), 'utf8');
}

// La configuración se mantiene en memoria para evitar lecturas síncronas
// del disco en cada mensaje recibido. Se refresca periódicamente para detectar
// cambios externos y se actualiza inmediatamente al usar el comando on/off.
let antilinksConfigCache = null;
let antilinksConfigCacheAt = 0;
const ANTILINKS_CONFIG_CACHE_TTL_MS = 5000;

function loadAntilinksConfig() {
    const now = Date.now();
    if (antilinksConfigCache && now - antilinksConfigCacheAt < ANTILINKS_CONFIG_CACHE_TTL_MS) {
        return antilinksConfigCache;
    }

    try {
        if (fs.existsSync(ANTILINKS_FILE)) {
            const data = fs.readFileSync(ANTILINKS_FILE, 'utf8');
            const parsed = JSON.parse(data || '{}');
            antilinksConfigCache = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
                ? parsed
                : {};
        } else {
            antilinksConfigCache = {};
        }
    } catch (error) {
        console.error('Error cargando antilinks.json:', error.message);
        // Conservar la última configuración válida si el archivo está siendo
        // reemplazado o editado y momentáneamente contiene JSON inválido.
        if (!antilinksConfigCache) antilinksConfigCache = {};
    }

    antilinksConfigCacheAt = now;
    return antilinksConfigCache;
}

// Guardar configuración y sincronizar la caché sin esperar al próximo refresh.
function saveAntilinksConfig(config) {
    try {
        fs.writeFileSync(ANTILINKS_FILE, JSON.stringify(config, null, 2), 'utf8');
        antilinksConfigCache = config;
        antilinksConfigCacheAt = Date.now();
        return true;
    } catch (error) {
        console.error('Error guardando antilinks.json:', error.message);
        return false;
    }
}

// Verificar si antilinks está activado en un grupo.
function isAntilinksEnabled(groupJid) {
    if (typeof groupJid !== 'string' || !groupJid) return false;
    const config = loadAntilinksConfig();
    const cleanJid = groupJid.split('@')[0];
    return config[cleanJid] === true;
}

// Activar/desactivar antilinks en un grupo
function setAntilinks(groupJid, enabled) {
    if (typeof groupJid !== 'string' || !groupJid) return false;
    // Trabajar sobre una copia: si el guardado falla, la caché válida no cambia.
    const config = { ...loadAntilinksConfig() };
    const cleanJid = groupJid.split('@')[0];
    
    if (enabled) {
        config[cleanJid] = true;
    } else {
        delete config[cleanJid];
    }
    
    return saveAntilinksConfig(config);
}

// Regex para detectar enlaces - NO usar con flag /g en .test() directamente
// Para evitar el bug de lastIndex con regex globales compartidos,
// siempre crear una nueva instancia o resetear antes de usar.
const LINK_REGEX_SOURCE = '(https?:\\/\\/[^\\s]+)|(www\\.[^\\s]+)|([a-zA-Z0-9-]+\\.(com|net|org|io|co|xyz|me|tk|ml|ga|cf|gq|info|online|site|website|tech|store|app|dev|bot|gg|tv|fm|edu|gov|mil|int|us|uk|es|de|fr|it|br|ar|mx|cl|pe|ve|ec|py|uy|bo|gt|hn|ni|cr|pa|do|cu|jm|tt|bs|bb|gd|lc|vc|ag|dm|kn|sx|aw|cw|bq|sr|gy|fk)[^\\s]*)';

function hasLink(text) {
    return new RegExp(LINK_REGEX_SOURCE, 'i').test(text);
}

// Prefijos de comandos del bot
const COMMAND_PREFIXES = ['.', '/', '❤️', '#', '👅', '😎', '!', '\\', '$', '%'];

/**
 * Control de mensajes programados para borrado diferido
 */
const pendingDeletes = new Set();
const activeAntilinksDeletes = new Set();
const recentlyDeletedAntilinks = new Map();

/**
 * Programa la eliminación diferida de un mensaje con comando para dar tiempo
 * a que el plugin procese el comando (extraiga el enlace e inicie la descarga/acción)
 * y luego elimine el mensaje del grupo.
 */
function scheduleAntilinksDelete(chatId, baileyMessage, sock, delayMs = 1500) {
    const msgId = baileyMessage?.key?.id;
    if (!msgId || pendingDeletes.has(msgId)) return;

    pendingDeletes.add(msgId);
    setTimeout(async () => {
        try {
            await _performAntilinksDelete(chatId, baileyMessage, sock);
        } catch (_) {
        } finally {
            setTimeout(() => pendingDeletes.delete(msgId), 10000);
        }
    }, delayMs);
}

/**
 * Verifica si un texto empieza como comando del bot (ej. .ytv, .play, .tiktok, .join, etc.)
 */
function isBotCommand(text) {
    if (!text || typeof text !== 'string') return false;
    const trimmed = text.trim();
    if (COMMAND_PREFIXES.some(p => trimmed.startsWith(p))) return true;
    return /^[^\w\s\u00C0-\u024F]\s*\w+/i.test(trimmed);
}

// Handler automático para eliminar enlaces (llamado desde textReplyHandler de plugins)
async function antilinksHandler(message) {
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        // Solo procesar en grupos
        if (!chatId || !chatId.endsWith('@g.us')) {
            return;
        }

        // Verificar si antilinks está activado en este grupo
        if (!isAntilinksEnabled(chatId)) {
            return;
        }

        // Extraer texto del mensaje
        let text = '';
        
        if (message.body) {
            text = typeof message.body === 'string' ? message.body : 
                   (message.body.caption || message.body.text || '');
        }
        
        if (!text && message.message) {
            const msg = message.message;
            text = msg.conversation || 
                   msg.extendedTextMessage?.text || 
                   msg.imageMessage?.caption || 
                   msg.videoMessage?.caption || 
                   msg.documentMessage?.caption || 
                   '';
        }

        if (!text || typeof text !== 'string') {
            return;
        }

        // Verificar si el mensaje contiene enlaces
        if (!hasLink(text)) {
            return;
        }

        // Obtener conexión (usar la del mensaje primero, luego global)
        const sock = message._sock || global.conn;
        if (!sock || !sock.user) {
            console.error('[AntiLinks] Conexión no disponible');
            return;
        }

        const bMsg = baileyMsgFromWrapped(message);

        // Si es un comando del bot, programar borrado diferido para no interrumpir el procesamiento
        if (isBotCommand(text)) {
            scheduleAntilinksDelete(chatId, bMsg, sock, 1500);
            return;
        }

        await _performAntilinksDelete(chatId, bMsg, sock);

    } catch (error) {
        console.error('Error en antilinks handler:', error.message);
    }
}

/**
 * Extrae la key de baileys desde un mensaje wrapeado o desde message._baileyMessage
 */
function baileyMsgFromWrapped(message) {
    return message._baileyMessage || {
        key: message.key,
        message: message.message
    };
}

/**
 * Función principal de verificación antilinks para ser llamada desde index.js.
 * Recibe el mensaje de Baileys crudo y el socket activo.
 * Retorna true si eliminó el mensaje de inmediato (mensajes sin comando).
 */
async function checkAntilinks(baileyMessage, sock) {
    try {
        if (!sock || !sock.user) return false;

        const chatId = baileyMessage.key.remoteJid;
        if (!chatId?.endsWith('@g.us')) return false;
        if (!isAntilinksEnabled(chatId)) return false;

        // Extraer texto del mensaje de Baileys
        const msg = baileyMessage.message;
        if (!msg) return false;

        const text = msg.conversation ||
                     msg.extendedTextMessage?.text ||
                     msg.imageMessage?.caption ||
                     msg.videoMessage?.caption ||
                     msg.documentMessage?.caption ||
                     '';

        if (!text || typeof text !== 'string') return false;

        if (!hasLink(text)) return false;

        // Si ES un comando del bot (ej. .ytv, .play, .tiktok, .ig, .join, etc.)
        if (isBotCommand(text)) {
            // Programar eliminación retrasada (1.5s) para dar tiempo a que el plugin lea y procese el comando
            scheduleAntilinksDelete(chatId, baileyMessage, sock, 1500);
            // Retornar false para que el manejador de comandos reciba y ejecute el comando
            return false;
        }

        // Si NO es un comando, borrar de inmediato y frenar flujo
        return await _performAntilinksDelete(chatId, baileyMessage, sock);
    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[AntiLinks] Error en checkAntilinks:', error.message);
        }
        return false;
    }
}

/**
 * Verifica permisos y elimina el mensaje si corresponde.
 * Retorna true si eliminó.
 */
async function _performAntilinksDelete(chatId, baileyMessage, sock) {
    const messageId = baileyMessage?.key?.id;
    const dedupKey = messageId ? `${chatId}:${messageId}` : null;
    if (dedupKey) {
        const deletedAt = recentlyDeletedAntilinks.get(dedupKey);
        if (deletedAt && Date.now() - deletedAt < 30000) return true;
        if (activeAntilinksDeletes.has(dedupKey)) return true;
        activeAntilinksDeletes.add(dedupKey);
    }

    try {
        // Seleccionar el socket que realmente es administrador; el mensaje puede
        // haber llegado primero al bot principal o a un subbot sin permisos.
        const coordinator = require('../lib/subbotCoordinator');
        const groupMetadata = await coordinator.getReliableGroupMetadata(chatId, sock);
        if (!Array.isArray(groupMetadata?.participants) || groupMetadata.participants.length === 0) {
            return false;
        }
        const adminSock = await coordinator.findAdminBotSocket(chatId, sock, groupMetadata);
        if (!adminSock?.user) return false;

        // Verificar si el usuario que envió el enlace es administrador.
        const userId = baileyMessage.key.participant || baileyMessage.key.remoteJid;
        const cleanUserId = String(userId || '').split('@')[0].split(':')[0].replace(/\D/g, '');
        const userParticipant = groupMetadata.participants.find(p => {
            const ids = [p?.id, p?.phoneNumber, p?.lid]
                .map(value => String(value || '').split('@')[0].split(':')[0].replace(/\D/g, ''));
            return ids.includes(cleanUserId);
        });
        const isUserAdmin = userParticipant && (
            userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin' || userParticipant.isAdmin === true
        );
        if (isUserAdmin) return false;

        // Verificar si es owner del bot.
        try {
            const botConfig = require('../config');
            if (botConfig.isOwner(cleanUserId) || botConfig.isOwner(`${cleanUserId}@s.whatsapp.net`)) {
                return false;
            }
        } catch (_) { }

        await adminSock.sendMessage(chatId, { delete: baileyMessage.key });
        if (dedupKey) {
            recentlyDeletedAntilinks.set(dedupKey, Date.now());
            if (recentlyDeletedAntilinks.size > 2000) {
                const oldest = recentlyDeletedAntilinks.keys().next().value;
                if (oldest) recentlyDeletedAntilinks.delete(oldest);
            }
        }
        console.log(`[AntiLinks] 🗑️ Enlace eliminado de @${cleanUserId} en ${chatId} usando ${adminSock._subNum == null ? 'bot principal' : `subbot #${adminSock._subNum}`}`);
        return true;
    } catch (error) {
        if (!error.message?.includes('Connection Closed')) {
            console.error('[AntiLinks] Error eliminando enlace:', error.message);
        }
        return false;
    } finally {
        if (dedupKey) activeAntilinksDeletes.delete(dedupKey);
    }
}

// Comando .antilinks
let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    try {
        const chatId = message.from || message.key?.remoteJid;
        
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('⚠️ Este comando solo funciona en grupos.');
        }

        // Obtener metadata del grupo usando la conexión efectiva (principal o subbot).
        if (!sock || typeof sock.groupMetadata !== 'function') {
            return await message.reply('⚠️ No hay una conexión disponible para consultar el grupo.');
        }
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = Array.isArray(groupMetadata?.participants) ? groupMetadata.participants : [];

        // --- Verificación de permisos del Usuario ---
        const userJid = message.sender || message.author || message.key?.participant || '';
        const userNumber = String(userJid).split('@')[0].split(':')[0];
        
        const userParticipant = participants.find(p => {
            const participantNumber = String(p?.id || '').split('@')[0].split(':')[0];
            return participantNumber === userNumber;
        });
        
        const userIsAdmin = userParticipant && (userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin');
        
        if (!userIsAdmin) {
            return await message.reply('❌ Solo los *administradores* del grupo pueden usar este comando.');
        }

        // Obtener argumentos del comando
        const args = message.body.split(/\s+/).slice(1);

        // Si no hay argumentos, mostrar estado actual
        if (args.length === 0) {
            const isEnabled = isAntilinksEnabled(chatId);
            const status = isEnabled ? '✅ Activado' : '❌ Desactivado';
            
            let texto = '🔗 *ANTILINKS*\n\n';
            texto += `📊 *Estado actual:* ${status}\n\n`;
            texto += `💡 *Uso:*\n`;
            texto += `   • .antilinks on - Activar\n`;
            texto += `   • .antilinks off - Desactivar\n\n`;
            texto += `ℹ️ Cuando está activado, el bot eliminará automáticamente mensajes con enlaces (excepto de admins y el comando .join)`;
            
            return await message.reply(texto);
        }

        // Procesar comando on/off
        const action = args[0]?.toLowerCase();

        if (!['on', 'off', 'activar', 'desactivar'].includes(action)) {
            return await message.reply('⚠️ Usa: .antilinks on/off');
        }

        const enable = ['on', 'activar'].includes(action);
        
        // Verificar si el bot es admin (solo cuando se intenta activar)
        if (enable) {
            // --- Verificación de permisos del Bot (MISMO MÉTODO QUE close.js) ---
            const botJid = sock.user?.id || sock.user?.jid || '';
            const possibleBotNumbers = [
                botJid.split(':')[0].split('@')[0],
                botJid.split('@')[0].split(':')[0]
            ];
            
            let botParticipant = participants.find(p => {
                const participantId = String(p?.id || '');
                const participantNumber = participantId.split('@')[0].split(':')[0];
                return possibleBotNumbers.includes(participantNumber) ||
                       participantId.includes(possibleBotNumbers[0]) ||
                       participantId.includes(possibleBotNumbers[1]);
            });
            
            if (!botParticipant) {
                botParticipant = participants.find(p => {
                    return String(p?.id || '').includes('@lid') && (p.admin === 'admin' || p.admin === 'superadmin');
                });
            }
            
            const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

            if (!botIsAdmin) {
                return await message.reply('❌ No puedo activar antilinks porque *no soy administrador* del grupo.\n\n💡 Hazme admin del grupo e intenta de nuevo.');
            }
        }

        // Guardar configuración
        if (setAntilinks(chatId, enable)) {
            const emoji = enable ? '✅' : '❌';
            const status = enable ? 'activado' : 'desactivado';
            await message.reply(`${emoji} *Antilinks* ha sido ${status} en este grupo.`);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }

    } catch (error) {
        console.error('Error en comando antilinks:', error);
        await message.reply('❌ Error al procesar el comando.');
    }
};

handler.help = ['antilinks'];
handler.tags = ['admin'];
handler.command = /^(antilinks|antilink|antienlaces)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;
module.exports.textReplyHandler = antilinksHandler;
module.exports.isAntilinksEnabled = isAntilinksEnabled;
module.exports.checkAntilinks = checkAntilinks;
