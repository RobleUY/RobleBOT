'use strict';

const gameAuth = require('../lib/gameAuth');

const command = /^(gamecode)$/i;
const help = 'Verifica el código de acceso a RobleBOT Game';
const tags = ['juegos'];

async function handler(message, { text, fullUserId }) {
  const code = String(text || '').trim().split(/\s+/)[0];
  if (!/^\d{4}$/.test(code)) {
    return message.reply('🎮 *RobleBOT Game*\n\nUsá el código de 4 números que aparece en la página del juego.\nEjemplo: *.gamecode 4821*');
  }
  const rawId = fullUserId || message?.key?.participant || message?.key?.remoteJid;
  const userId = global.db?.getCanonicalId?.(rawId) || global.db?.cleanNumber?.(rawId) || String(rawId || '').split('@')[0];
  if (!userId) return message.reply('❌ No pude identificar tu cuenta. Volvé a generar el código desde la página del juego.');
  const result = gameAuth.verifyCode(code, userId);
  if (!result.ok) return message.reply(`❌ ${result.reason}`);
  return message.reply(`✅ *Cuenta verificada*\n\nHola, *${result.apodo}*. Ya podés volver a la página de RobleBOT Game y pulsar *Verificar estado*.`);
}

module.exports = { command, help, tags, handler };
