const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const botConfig = require('../config');

// ─── Configuración ────────────────────────────────────────────────────────────
const dataFilePath = path.join(__dirname, '..', 'data', 'ias-personalizadas.json');
const PREFIXES = ['.', '/', '❤️', '#', '👅', '😎'];
const RESERVED_COMMANDS = ['addia', 'myia', 'delia', 'topia'];
const MAX_IAS_PER_USER = 50;       // mismo límite que comandos personalizados
const MAX_PROMPT_CHARS = 200;       // mismo límite de caracteres
const TIMEOUT = 20000;
const MODEL_LIST = [
    'openai/gpt-oss-20b',
    'openai/gpt-oss-120b',
    'qwen/qwen3-32b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'llama-3.3-70b-versatile',
    'llama-3.3-8b-instant',
    'llama-3.1-8b-instant'
];


function collectGroqApiKeys() {
    const keys = new Set();
    const envNames = Object.keys(process.env);
    const keyPattern = /^groq_api_key(?:\d*)?$/i;

    for (const name of envNames) {
        if (!keyPattern.test(name)) continue;
        const value = process.env[name];
        if (value && typeof value === 'string') {
            const trimmed = value.trim();
            if (trimmed) keys.add(trimmed);
        }
    }

    return Array.from(keys);
}

// ─── Persistencia ─────────────────────────────────────────────────────────────
function ensureDataFile() {
    const dir = path.dirname(dataFilePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(dataFilePath)) {
        fs.writeFileSync(dataFilePath, JSON.stringify({ ias: {} }, null, 2));
    }
}

let cachedIaStore = null;

function loadStore() {
    if (cachedIaStore) return cachedIaStore;
    try {
        ensureDataFile();
        const raw = fs.readFileSync(dataFilePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') cachedIaStore = { ias: {} };
        else {
            if (!parsed.ias || typeof parsed.ias !== 'object') parsed.ias = {};
            cachedIaStore = parsed;
        }
        return cachedIaStore;
    } catch (e) {
        console.error('[ias-personalizadas] Error cargando store:', e.message);
        cachedIaStore = { ias: {} };
        return cachedIaStore;
    }
}

function saveStore(store) {
    try {
        cachedIaStore = store;
        ensureDataFile();
        fs.writeFileSync(dataFilePath, JSON.stringify(store));
    } catch (e) {
        console.error('[ias-personalizadas] Error guardando store:', e.message);
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function normalizeCommandName(raw) {
    if (!raw || typeof raw !== 'string') return '';
    const firstWord = raw.trim().split(/[\s\n\r]+/)[0] || '';
    return firstWord
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/^[^a-zA-Z0-9]+/, '')
        .toLowerCase();
}

function isValidCommandName(name) {
    return /^[a-z0-9_]+$/i.test(name);
}

function getCreatorKey(message) {
    const author = message.author || message.sender || message.key?.participant || message.key?.remoteJid;
    if (!author) return null;
    return author.toString().split('@')[0].split(':')[0].replace(/\D/g, '');
}

function formatCommandName(name, displayName) {
    const display = displayName || name;
    return display.startsWith('.') ? display : `.${display}`;
}

function getCreatorDisplayName(creator) {
    if (!creator) return 'Sin apodo';
    try {
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(String(creator));
            const apodo = user?.apodo?.toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') return apodo;
        }
    } catch (_) {}
    return 'Sin apodo';
}

function getUniqueUsageCount(data) {
    return Array.isArray(data.usedBy) ? data.usedBy.length : 0;
}

function hasOfficialCommand(commandName) {
    const handler = global.commandHandler;
    if (!handler || !handler.commands) return false;
    if (handler.commands.has(commandName)) return true;
    for (const [cmdKey] of handler.commands) {
        if (cmdKey instanceof RegExp && cmdKey.test(commandName)) return true;
    }
    return false;
}

function hasCustomCommand(commandName) {
    try {
        const cmdPath = path.join(__dirname, '..', 'data', 'comandos.json');
        if (!fs.existsSync(cmdPath)) return false;
        const raw = fs.readFileSync(cmdPath, 'utf8');
        const parsed = JSON.parse(raw);
        return !!(parsed?.commands?.[commandName]);
    } catch (_) {
        return false;
    }
}

// Circuit breaker global de red (accesible via global.networkGuard si está disponible)
function getNetGuard() { return (typeof global !== 'undefined' && global.networkGuard) ? global.networkGuard : null; }

// ─── Groq API ─────────────────────────────────────────────────────────────────
async function callGroq(systemPrompt, userText) {
    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) {
        throw new Error('No hay claves Groq configuradas');
    }

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        const apiKey = apiKeys[keyIndex];
        for (let modelIndex = 0; modelIndex < MODEL_LIST.length; modelIndex++) {
            const model = MODEL_LIST[modelIndex];
            try {
                const result = await groqRequest(apiKey, model, systemPrompt, userText);
                return result;
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[ias-personalizadas] Groq key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
                if (keyIndex === apiKeys.length - 1 && modelIndex === MODEL_LIST.length - 1) break;
            }
        }
    }

    throw lastErr || new Error('Groq falló');
}

function groqRequest(apiKey, model, systemPrompt, userText) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userText }
            ],
            max_tokens: 600,
            temperature: 0.7,
            top_p: 0.95
        });

        const options = {
            hostname: 'api.groq.com',
            path: '/openai/v1/chat/completions',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'Content-Length': Buffer.byteLength(body)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    const content = parsed.choices?.[0]?.message?.content?.trim();
                    if (!content) return reject(new Error('Respuesta vacía de Groq'));
                    resolve(content);
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT, () => {
            req.destroy();
            reject(new Error('Timeout Groq'));
        });

        req.write(body);
        req.end();
    });
}

// ─── Delirius APIs (fallback) ──────────────────────────────────────────────────
function httpGet(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { timeout: TIMEOUT }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch { reject(new Error('Error parseando respuesta')); }
            });
        });
        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

async function deliriusGptPrompt(systemPrompt, userText) {
    const url = `https://api.delirius.online/ia/gptprompt?text=${encodeURIComponent(userText)}&prompt=${encodeURIComponent(systemPrompt)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gptprompt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gptprompt: sin contenido');
    return text.trim();
}

async function deliriusGemini(systemPrompt, userText) {
    const query = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/gemini?query=${encodeURIComponent(query)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gemini: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gemini: sin contenido');
    return text.trim();
}

async function deliriusChatgpt(systemPrompt, userText) {
    const q = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/chatgpt?q=${encodeURIComponent(q)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius chatgpt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius chatgpt: sin contenido');
    return text.trim();
}

// ─── Llamada principal: TODAS las IAs en paralelo, gana la más rápida ─────────
async function callIA(systemPrompt, userText) {
    // Si el circuit breaker detecta la red caída, no intentamos nada
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) {
        console.warn('[ias-personalizadas] Red caída (circuit breaker activo) — omitiendo peticiones IA.');
        throw new Error('_SILENT_FAIL_');
    }

    const attempts = [
        callGroq(systemPrompt, userText),
        deliriusGptPrompt(systemPrompt, userText),
        deliriusGemini(systemPrompt, userText),
        deliriusChatgpt(systemPrompt, userText)
    ];

    const names = ['Groq', 'Delirius-gptprompt', 'Delirius-gemini', 'Delirius-chatgpt'];
    const labeled = attempts.map((p, i) => p.catch(e => {
        console.warn(`[ias-personalizadas] ${names[i]} falló:`, e.message);
        throw e;
    }));

    try {
        return await Promise.any(labeled);
    } catch (aggregateErr) {
        const details = Array.isArray(aggregateErr?.errors)
            ? aggregateErr.errors.map(e => e.message).join(' | ')
            : aggregateErr.message;
        console.error('[ias-personalizadas] Todas las IAs fallaron:', details);
        throw new Error('_SILENT_FAIL_');
    }
}

// ─── Handlers de comandos ─────────────────────────────────────────────────────

async function handleAddIa(message, { args, text }) {
    if (!args || args.length < 1) {
        return await message.reply(
            '⚠️ Uso correcto:\n' +
            '.addia .nombrecomando prompt de la ia\n\n' +
            'Ejemplo:\n' +
            '.addia .kungfupandaia Eres una ia llamada PO y siempre hablas sobre kung fu panda\n\n' +
            `📌 El prompt tiene un máximo de ${MAX_PROMPT_CHARS} caracteres.\n` +
            `📌 Podés crear hasta ${MAX_IAS_PER_USER} IAs personalizadas.\n\n` +
            '🤖 O créala con IA usando:\n' +
            '.addia .ia quiero una ia que responda como un chef experto en cocina'
        );
    }

    // Reconstruir nombre y prompt desde `text` para soportar prompts multi-línea.
    const rawText = (text || '').trim();
    const firstBreak = rawText.search(/[\s\n\r]/);
    const rawCmdArg = firstBreak === -1 ? rawText : rawText.slice(0, firstBreak);
    const promptRaw = firstBreak === -1 ? '' : rawText.slice(firstBreak + 1);

    // AI Generation Check
    const isIaGeneration = /^\.?ia$/i.test(rawCmdArg);
    if (isIaGeneration) {
        const description = promptRaw.trim();
        if (!description) {
            return await message.reply(
                '⚠️ Debes indicar una descripción de lo que quieres que haga tu IA.\n' +
                'Ejemplo: `.addia .ia quiero una ia que actúe como un chef enojón y responda gritando.`'
            );
        }

        try {
            await message.reply('⏳ _Generando IA personalizada con IA..._');
        } catch (_) {}

        try {
            const systemPrompt = `Eres un asistente experto que diseña IAs personalizadas para un bot de WhatsApp.
El usuario describirá cómo quiere que se comporte la IA.
Debes responder UNICAMENTE con un objeto JSON válido (sin explicaciones adicionales fuera del bloque JSON) con la siguiente estructura:
{
  "commandName": ".nombre", // Nombre del comando en minúsculas, comenzando con un punto (solo letras, números y guión bajo).
  "prompt": "instrucciones de sistema para la IA" // El prompt de sistema/instrucciones de comportamiento para la IA. Debe ser conciso (máximo 180 caracteres).
}

Ejemplo de respuesta esperada:
\`\`\`json
{
  "commandName": ".chefbot",
  "prompt": "Eres un chef experto y enojón. Responde siempre con términos culinarios, gritando (en mayúsculas) y dando consejos de cocina agresivos."
}
\`\`\``;

            const aiResponse = await callIA(systemPrompt, description);
            let jsonStr = aiResponse.trim();
            const match = jsonStr.match(/\{[\s\S]*\}/);
            if (match) {
                jsonStr = match[0];
            }
            const generated = JSON.parse(jsonStr);
            const genName = normalizeCommandName(generated.commandName);
            const genPrompt = (generated.prompt || '').trim();
            const creator = getCreatorKey(message);

            if (!genName) {
                return await message.reply('⚠️ La IA no pudo generar un nombre de comando válido. Intenta describiendo la IA de forma más clara.');
            }

            if (!isValidCommandName(genName)) {
                return await message.reply(`⚠️ El nombre de IA generado por la IA (.${genName}) no es válido. Debe contener solo letras, números y guion bajo.`);
            }

            // Validar duplicados (con mensaje especial si ya existe)
            if (RESERVED_COMMANDS.includes(genName) || hasOfficialCommand(genName)) {
                return await message.reply(
                    `⚠️ No se pudo crear porque el comando oficial \`.${genName}\` ya existe en el bot.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de IA que no esté en uso.`
                );
            }

            const store = loadStore();
            if (store.ias[genName]) {
                return await message.reply(
                    `⚠️ No se pudo crear porque la IA personalizada \`.${genName}\` ya existe.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de IA que no esté en uso.`
                );
            }

            if (hasCustomCommand(genName)) {
                return await message.reply(
                    `⚠️ No se pudo crear porque ya existe un comando personalizado con el nombre \`.${genName}\`.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de IA que no esté en uso.`
                );
            }

            if (!genPrompt) {
                return await message.reply('⚠️ La IA generó instrucciones vacías. Intenta de nuevo con otra descripción.');
            }

            if (genPrompt.length > MAX_PROMPT_CHARS) {
                return await message.reply(`⚠️ El prompt generado es demasiado largo (máximo ${MAX_PROMPT_CHARS} caracteres).`);
            }

            const userCount = Object.values(store.ias).filter(ia => ia.creator === creator).length;
            if (userCount >= MAX_IAS_PER_USER) {
                return await message.reply(`⚠️ Alcanzaste el límite de ${MAX_IAS_PER_USER} IAs personalizadas.`);
            }

            // Registrar la IA generada
            const displayName = generated.commandName.trim().replace(/^[^a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]+/, '');
            store.ias[genName] = {
                prompt: genPrompt,
                creator: creator || 'unknown',
                createdAt: Date.now(),
                uses: 0,
                usedBy: [],
                displayName: displayName
            };

            saveStore(store);

            return await message.reply(
                `✅ IA creada con éxito usando IA:\n` +
                `${formatCommandName(genName, displayName)}\n` +
                `📝 Prompt: _${genPrompt}_\n\n` +
                `Usala así:\n${formatCommandName(genName, displayName)} hola`
            );

        } catch (error) {
            console.error('[ias-personalizadas] Error en generación con IA:', error);
            return await message.reply('⚠️ Ocurrió un error al generar la IA con la IA. Inténtalo de nuevo.');
        }
    }

    if (!promptRaw) {
        return await message.reply('⚠️ Debés indicar las instrucciones (prompt) de tu IA.');
    }

    const rawCommand = rawCmdArg;
    const commandName = normalizeCommandName(rawCommand);
    const prompt = promptRaw.trim();
    const creator = getCreatorKey(message);

    if (!commandName) {
        return await message.reply('⚠️ Nombre de comando inválido. Debe tener solo letras, números o guion bajo.');
    }

    if (!isValidCommandName(commandName)) {
        return await message.reply('⚠️ El nombre solo puede contener letras, números y guion bajo.');
    }

    if (RESERVED_COMMANDS.includes(commandName)) {
        return await message.reply('⚠️ Ese nombre está reservado por el bot. Usá otro nombre para tu IA.');
    }

    if (!prompt) {
        return await message.reply('⚠️ Debés indicar las instrucciones (prompt) de tu IA.');
    }

    if (prompt.length > MAX_PROMPT_CHARS) {
        return await message.reply(
            `⚠️ El prompt es muy largo. Máximo ${MAX_PROMPT_CHARS} caracteres.\n` +
            `Tu prompt tiene ${prompt.length} caracteres. Recortalo en ${prompt.length - MAX_PROMPT_CHARS} caracteres.`
        );
    }

    const store = loadStore();
    const userCount = Object.values(store.ias).filter(ia => ia.creator === creator).length;

    if (userCount >= MAX_IAS_PER_USER) {
        return await message.reply(
            `⚠️ Alcanzaste el límite de ${MAX_IAS_PER_USER} IAs personalizadas. ` +
            `Eliminá una con .delia para poder crear una nueva.`
        );
    }

    if (store.ias[commandName]) {
        return await message.reply('⚠️ Ya existe una IA con ese nombre. Elegí otro nombre o eliminala primero con .delia.');
    }

    if (hasOfficialCommand(commandName)) {
        return await message.reply('⚠️ No podés usar ese nombre porque ya existe como comando oficial del bot.');
    }

    if (hasCustomCommand(commandName)) {
        return await message.reply('⚠️ Ya existe un comando personalizado con ese nombre. Usá otro nombre para tu IA.');
    }

    const originalName = rawCommand.trim().replace(/^[^a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]+/, '');
    store.ias[commandName] = {
        prompt,
        creator: creator || 'unknown',
        createdAt: Date.now(),
        uses: 0,
        usedBy: [],
        displayName: originalName
    };

    saveStore(store);

    return await message.reply(
        `✅ IA creada con éxito:\n` +
        `${formatCommandName(commandName, originalName)}\n` +
        `📝 Prompt: _${prompt}_\n\n` +
        `Usala así:\n${formatCommandName(commandName, originalName)} hola, ¿cómo estás?`
    );
}

async function handleMyIa(message) {
    const creator = getCreatorKey(message);
    const store = loadStore();
    const ownEntries = Object.entries(store.ias)
        .filter(([_, d]) => d.creator === creator)
        .sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));

    if (!ownEntries.length) {
        return await message.reply('📌 No tenés IAs personalizadas guardadas. Usá .addia para crear una.');
    }

    const lines = ownEntries.map(([name, data]) => {
        const usos = getUniqueUsageCount(data);
        return `${formatCommandName(name)}\n→ _${data.prompt}_\n   🔥 Usuarios: ${usos}`;
    });

    const header =
        `🤖 *Tus IAs personalizadas* — Página 1/1\n` +
        `📊 Total: ${ownEntries.length} IAs\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleTopIa(message, { args }) {
    const page = Math.max(1, parseInt(args?.[0] || '1', 10) || 1);
    const store = loadStore();
    const allEntries = Object.entries(store.ias);

    if (!allEntries.length) {
        return await message.reply('📌 No hay IAs personalizadas guardadas. Usá .addia para crear una.');
    }

    const ranked = allEntries.sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));
    const pageSize = 10;
    const total = ranked.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, totalPages);
    const startIndex = (currentPage - 1) * pageSize;
    const pageEntries = ranked.slice(startIndex, startIndex + pageSize);

    const lines = pageEntries.map(([name, data], idx) => {
        const rank = startIndex + idx + 1;
        const ownerName = getCreatorDisplayName(data.creator);
        const usos = getUniqueUsageCount(data);
        return `${rank}. ${formatCommandName(name)} — ${ownerName}\n→ _${data.prompt}_\n   🔥 Usuarios: ${usos}`;
    });

    const header =
        `🏆 *Top IAs personalizadas* — Página ${currentPage}/${totalPages}\n` +
        `📊 Total: ${total} IAs\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleDelIa(message, { args }) {
    if (!args || args.length < 1) {
        return await message.reply(
            '⚠️ Uso correcto:\n.delia .nombre\n\n' +
            'También podés borrar varias de una:\n.delia .nombre1 .nombre2\n\n' +
            'O borrar todas tus IAs:\n.delia all'
        );
    }

    const creator = getCreatorKey(message);
    const store = loadStore();
    const firstArg = args[0].toLowerCase();

    if (['all', 'todo', 'todos'].includes(firstArg)) {
        let deletedCount = 0;
        for (const [name, data] of Object.entries(store.ias)) {
            if (data.creator === creator) {
                delete store.ias[name];
                deletedCount++;
            }
        }
        if (deletedCount > 0) {
            saveStore(store);
            return await message.reply(`✅ Se eliminaron todas tus IAs personalizadas (${deletedCount} en total).`);
        } else {
            return await message.reply('⚠️ No tenés IAs personalizadas para eliminar.');
        }
    }

    const isOwner = creator && botConfig.isOwner(creator);
    const deleted = [];
    const noPermission = [];
    const notFound = [];
    const seen = new Set();

    for (const rawArg of args) {
        const name = normalizeCommandName(rawArg);
        if (!name || seen.has(name)) continue;
        seen.add(name);

        const stored = store.ias[name];
        if (!stored) { notFound.push(name); continue; }
        if (stored.creator !== creator && !isOwner) { noPermission.push({ name, displayName: stored.displayName }); continue; }

        const displayName = stored.displayName || name;
        delete store.ias[name];
        deleted.push({ name, displayName });
    }

    if (deleted.length) saveStore(store);

    const lines = [];
    if (deleted.length) lines.push(`✅ Eliminadas: ${deleted.map(d => formatCommandName(d.name, d.displayName)).join(', ')}`);
    if (noPermission.length) lines.push(`⚠️ Sin permiso: ${noPermission.map(d => formatCommandName(d.name, d.displayName)).join(', ')}`);
    if (notFound.length) lines.push(`⚠️ No existen: ${notFound.map(formatCommandName).join(', ')}`);
    if (!lines.length) lines.push('⚠️ No se indicó ningún nombre de IA válido.');

    return await message.reply(lines.join('\n'));
}

// ─── Ejecutar IA personalizada ────────────────────────────────────────────────
async function runCustomIa(message, commandName, userText) {
    const store = loadStore();
    const stored = store.ias[commandName];
    if (!stored) return false;

    if (!userText || !userText.trim()) {
        await message.reply(
            `⚠️ Escribí un mensaje para la IA:\n${formatCommandName(commandName, stored.displayName)} hola, ¿cómo estás?`
        );
        return true;
    }

    const senderNumber = getCreatorKey(message);

    try {
        await message.reply('⏳ _Pensando..._');
    } catch (_) {}

    let response;
    try {
        response = await callIA(stored.prompt, userText.trim());
    } catch (e) {
        // Error silencioso: todas las APIs fallaron, no notificar al usuario
        console.error('[ias-personalizadas] Todas las IAs fallaron:', e.message);
        return true;
    }

    await message.reply(response);

    // Registrar uso
    if (store.ias[commandName]) {
        store.ias[commandName].uses = Number(store.ias[commandName].uses || 0) + 1;
        if (!Array.isArray(store.ias[commandName].usedBy)) store.ias[commandName].usedBy = [];
        if (senderNumber && !store.ias[commandName].usedBy.includes(senderNumber)) {
            store.ias[commandName].usedBy.push(senderNumber);
        }
        saveStore(store);
    }

    return true;
}

// ─── textReplyHandler — intercepta cualquier mensaje con prefijo ──────────────
async function textReplyHandler(message) {
    if (!message || typeof message.body !== 'string') return;
    const text = message.body.trim();
    if (!text) return;

    const usedPrefix = PREFIXES.find(p => text.startsWith(p));
    if (!usedPrefix) return;

    const commandText = text.slice(usedPrefix.length).trim();
    if (!commandText) return;

    const [rawCommandName, ...rest] = commandText.split(' ');
    const commandName = normalizeCommandName(rawCommandName);
    if (!commandName) return;

    const store = loadStore();
    if (!store.ias[commandName]) return;

    await runCustomIa(message, commandName, rest.join(' '));
}

// ─── Handler principal ────────────────────────────────────────────────────────
let handler = async (message, { args, command, text }) => {
    if (/^addia$/i.test(command)) return await handleAddIa(message, { args, text });
    if (/^myia$/i.test(command)) return await handleMyIa(message);
    if (/^topia$/i.test(command)) return await handleTopIa(message, { args });
    if (/^delia$/i.test(command)) return await handleDelIa(message, { args });

    return await message.reply('⚠️ Comando no reconocido. Usá .addia, .myia, .topia o .delia.');
};

handler.help = [
    'addia .nombre prompt',
    'myia',
    'topia [página]',
    'delia .nombre',
    'delia all'
];
handler.tags = ['ia', 'fun', 'creador'];
handler.command = /^(addia|myia|topia|delia)$/i;
handler.textReplyHandler = textReplyHandler;
handler.callIA = callIA;

module.exports = handler;