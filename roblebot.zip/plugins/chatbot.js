'use strict';

const https = require('https');

// ─── Sesiones en memoria (no se persisten en disco) ───────────────────────────
// Map<userId, SessionObject>
// SessionObject = {
//   userId       : string,          // JID canónico del usuario
//   botMsgIds    : Set<string>,     // IDs de mensajes enviados por el bot en esta sesión
//   history      : Array<{role, content}>,  // historial para la IA (roles: 'user' | 'assistant')
//   stickyInfo   : string,          // info clave siempre presente (nombre, etc.)
//   charCount    : number,          // chars totales en history (sin stickyInfo)
//   lastActive   : number,          // timestamp del último mensaje
// }
const sessions = new Map();

const MAX_CHARS = 2000;
const TIMEOUT = 30000;
const CHATBOT_TAG = '[CHATBOT]';

// Modelos Groq a intentar en orden
const GROQ_MODELS = [
    'llama-3.3-70b-versatile', 
    'llama-3.1-8b-instant',
    'llama-3.3-8b-instant'
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function collectGroqKeys() {
    const keys = new Set();
    const pattern = /^groq_api_key(?:\d*)?$/i;
    for (const name of Object.keys(process.env)) {
        if (!pattern.test(name)) continue;
        const v = (process.env[name] || '').trim();
        if (v) keys.add(v);
    }
    // fallback hardcodeado (igual al de otros plugins)
    if (keys.size === 0) keys.add('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');
    return Array.from(keys);
}

function cleanUserId(raw) {
    if (!raw) return '';
    return String(raw).split('@')[0].split(':')[0].replace(/\D/g, '');
}

// Obtiene el apodo/nombre del usuario desde la DB global si está disponible
function getUserDisplayName(userId) {
    try {
        const clean = cleanUserId(userId);
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(clean) || global.db.getUser(userId);
            const apodo = (user && user.apodo || '').toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') return apodo;
        }
    } catch (_) {}
    return null;
}

// ─── Groq API ─────────────────────────────────────────────────────────────────

function groqChatRequest(apiKey, model, messages) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            model,
            messages,
            max_tokens: 600,
            temperature: 0.8,
            top_p: 0.95
        });

        const req = https.request({
            hostname: 'api.groq.com',
            path: '/openai/v1/chat/completions',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + apiKey,
                'Content-Length': Buffer.byteLength(body)
            }
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    const content = parsed.choices && parsed.choices[0] &&
                        parsed.choices[0].message && parsed.choices[0].message.content;
                    if (!content) return reject(new Error('Respuesta vacía de Groq'));
                    resolve(content.trim());
                } catch (e) {
                    reject(new Error('Error parseando respuesta de Groq'));
                }
            });
        });

        req.on('error', reject);
        req.setTimeout(TIMEOUT, () => {
            req.destroy();
            reject(new Error('Timeout Groq'));
        });
        req.write(body);
        req.end();
    });
}

async function callGroqChat(messages) {
    const keys = collectGroqKeys();
    let lastErr = null;

    for (let k = 0; k < keys.length; k++) {
        for (let m = 0; m < GROQ_MODELS.length; m++) {
            try {
                return await groqChatRequest(keys[k], GROQ_MODELS[m], messages);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuth = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`${CHATBOT_TAG} Groq key #${k + 1} modelo ${GROQ_MODELS[m]} falló: ${e.message}`);
                if (!isRateLimit && !isAuth) throw e;
            }
        }
    }
    throw lastErr || new Error('Groq falló');
}

// ─── Transcripción de audio (Groq Whisper) ────────────────────────────────────

const STT_MODELS = ['whisper-large-v3-turbo', 'whisper-large-v3'];

function groqTranscribeRequest(apiKey, model, buffer, mime) {
    return new Promise((resolve, reject) => {
        const ext = mime && mime.includes('ogg') ? 'ogg' :
                    mime && mime.includes('mpeg') ? 'mp3' :
                    mime && mime.includes('wav') ? 'wav' :
                    mime && mime.includes('webm') ? 'webm' :
                    mime && mime.includes('m4a') ? 'm4a' : 'ogg';
        const filename = 'audio.' + ext;
        const boundary = '----RobleChatbot' + Date.now().toString(16);

        const parts = [];
        const campo = (name, value) => parts.push(
            Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + name + '"\r\n\r\n' + value + '\r\n')
        );
        campo('model', model);
        campo('response_format', 'text');
        campo('temperature', '0');
        parts.push(Buffer.from(
            '--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="' + filename + '"\r\n' +
            'Content-Type: ' + (mime || 'audio/ogg') + '\r\n\r\n'
        ));
        parts.push(buffer);
        parts.push(Buffer.from('\r\n--' + boundary + '--\r\n'));

        const body = Buffer.concat(parts);

        const req = https.request({
            hostname: 'api.groq.com',
            path: '/openai/v1/audio/transcriptions',
            method: 'POST',
            headers: {
                'Authorization': 'Bearer ' + apiKey,
                'Content-Type': 'multipart/form-data; boundary=' + boundary,
                'Content-Length': body.length
            }
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                // response_format=text returns plain text directly
                if (res.statusCode >= 200 && res.statusCode < 300 && data && !data.startsWith('{')) {
                    return resolve(data.trim());
                }
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq STT');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    resolve((parsed.text || '').trim());
                } catch (_) {
                    reject(new Error('Error parseando respuesta STT'));
                }
            });
        });

        req.on('error', reject);
        req.setTimeout(90000, () => {
            req.destroy();
            reject(new Error('Timeout STT'));
        });
        req.write(body);
        req.end();
    });
}

async function transcribirAudio(buffer, mime) {
    const keys = collectGroqKeys();
    let lastErr = null;
    for (let k = 0; k < keys.length; k++) {
        for (const model of STT_MODELS) {
            try {
                return await groqTranscribeRequest(keys[k], model, buffer, mime);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuth = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`${CHATBOT_TAG} STT key #${k + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuth) throw e;
            }
        }
    }
    throw lastErr || new Error('STT falló');
}

// ─── Gestión del contexto (ventana deslizante de 2000 chars) ─────────────────

function buildSystemPrompt(session) {
    const sticky = session.stickyInfo
        ? 'Información del usuario que debes recordar siempre:\n' + session.stickyInfo + '\n\n'
        : '';
    return (
        'Eres RobleBOT, un asistente amigable y conversacional de WhatsApp.\n' +
        'Fuiste creado por Dev RobleUY.\n' +
        'REGLAS:\n' +
        '- Responde en español, de forma natural y amigable.\n' +
        '- Usa formato de WhatsApp: *negrita*, _cursiva_. Nunca uses Markdown normal.\n' +
        '- Mensajes cortos y claros (máximo 3-4 párrafos).\n' +
        '- Si el usuario te envía una transcripción de audio se indicará como "[Audio transcripto]".\n' +
        '- No inventes información que no tienes.\n' +
        sticky +
        'Tu nombre es RobleBOT. Si el usuario pregunta quién eres, díselo.'
    );
}

function addToHistory(session, role, content) {
    const entry = { role, content };
    const entryLen = role.length + content.length + 2;

    // Si ya hay suficiente contexto, eliminar entradas antiguas hasta caber en MAX_CHARS
    while (session.history.length > 0 && session.charCount + entryLen > MAX_CHARS) {
        const removed = session.history.shift();
        session.charCount -= (removed.role.length + removed.content.length + 2);
        if (session.charCount < 0) session.charCount = 0;
    }

    session.history.push(entry);
    session.charCount += entryLen;
    session.lastActive = Date.now();
}

// Intenta extraer y guardar el nombre del usuario de una respuesta de la IA
function tryUpdateStickyInfo(session, userMsg, botReply) {
    // Si todavía no hay info pegajosa, intentar capturar si el usuario dijo su nombre
    if (session.stickyInfo) return;
    const nameMatch = userMsg.match(/(?:me llamo|soy|mi nombre es|llámame)\s+([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,15})/i);
    if (nameMatch) {
        session.stickyInfo = 'Nombre del usuario: ' + nameMatch[1];
        console.log(`${CHATBOT_TAG} Sticky info actualizada para ${session.userId}: ${session.stickyInfo}`);
    }
}

// ─── Lógica principal de respuesta de la IA ───────────────────────────────────

async function responderChatbot(session, userText, message) {
    addToHistory(session, 'user', userText);

    const systemPrompt = buildSystemPrompt(session);
    const messages = [
        { role: 'system', content: systemPrompt },
        ...session.history
    ];

    let respuesta;
    try {
        respuesta = await callGroqChat(messages);
    } catch (e) {
        console.error(`${CHATBOT_TAG} Error llamando IA:`, e.message);
        await message.reply('⚠️ _No pude conectarme con la IA en este momento. Intenta de nuevo._');
        // Revertir el último mensaje del usuario si la IA falló
        const last = session.history.pop();
        if (last) session.charCount -= (last.role.length + last.content.length + 2);
        return null;
    }

    addToHistory(session, 'assistant', respuesta);
    tryUpdateStickyInfo(session, userText, respuesta);

    return respuesta;
}

// ─── Descarga de audio del mensaje ────────────────────────────────────────────

async function downloadAudioFromMessage(message) {
    // Intentar con message.download() primero (forma serializada)
    try {
        if (typeof message.download === 'function') {
            const buf = await message.download();
            if (buf && buf.length) {
                const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
                const inner = baileyMsg && baileyMsg.message;
                const mime = (inner && inner.audioMessage && inner.audioMessage.mimetype) || 'audio/ogg';
                return { buffer: buf, mime };
            }
        }
    } catch (_) {}

    // Intentar con Baileys directamente
    try {
        let baileys = null;
        for (const name of ['@whiskeysockets/baileys', '@adiwajshing/baileys', 'baileys']) {
            try { baileys = require(name); break; } catch (_) {}
        }
        if (baileys && baileys.downloadContentFromMessage) {
            const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
            const inner = baileyMsg && baileyMsg.message;
            const audioMsg = inner && inner.audioMessage;
            if (audioMsg) {
                const stream = await baileys.downloadContentFromMessage(audioMsg, 'audio');
                const chunks = [];
                for await (const chunk of stream) chunks.push(chunk);
                const buffer = Buffer.concat(chunks);
                return { buffer, mime: audioMsg.mimetype || 'audio/ogg' };
            }
        }
    } catch (_) {}

    return null;
}

// ─── Detección de si el mensaje es audio ──────────────────────────────────────

function isAudioMessage(message) {
    // message.body suele ser '«audio»' para audios en el sistema de este bot
    if (message.body === '«audio»') return true;
    // Verificar en la estructura Baileys directamente
    const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
    if (!baileyMsg) return false;
    const inner = baileyMsg.message || {};
    return !!(inner.audioMessage || inner.ptvMessage);
}

// ─── Obtener ID canónico del usuario ─────────────────────────────────────────

function getCanonicalUserId(message) {
    // Usar el número de teléfono como clave de sesión (sin dominio @s.whatsapp.net)
    const raw = message.author || message.sender || message.from || '';
    return cleanUserId(raw);
}

// ─── Procesamiento unificado de un mensaje entrante al chatbot ────────────────

async function procesarMensajeChatbot(message, session, rawUserText) {
    let userText = rawUserText;
    let esAudio = false;

    // Si el texto está vacío o es placeholder de audio → intentar transcribir
    if (!userText || userText === '«audio»') {
        if (isAudioMessage(message)) {
            esAudio = true;
            try {
                await message.reply('🎧 _Transcribiendo audio..._');
                const dl = await downloadAudioFromMessage(message);
                if (dl && dl.buffer && dl.buffer.length) {
                    const transcripcion = await transcribirAudio(dl.buffer, dl.mime);
                    if (transcripcion) {
                        userText = '[Audio transcripto]: ' + transcripcion;
                    } else {
                        await message.reply('⚠️ _No pude transcribir el audio. Intenta enviarlo de nuevo._');
                        return;
                    }
                } else {
                    await message.reply('⚠️ _No pude descargar el audio._');
                    return;
                }
            } catch (e) {
                console.error(`${CHATBOT_TAG} Error transcribiendo:`, e.message);
                await message.reply('⚠️ _Error al transcribir el audio._');
                return;
            }
        } else {
            // Mensaje sin texto y sin audio — ignorar silenciosamente
            return;
        }
    }

    if (!userText.trim()) return;

    const respuesta = await responderChatbot(session, userText, message);
    if (!respuesta) return;

    try {
        const sent = await message.reply(respuesta);
        // Guardar el ID del mensaje enviado por el bot para detectar replies
        if (sent && sent.key && sent.key.id) {
            session.botMsgIds.add(sent.key.id);
            // Limitar el tamaño del set para no crecer indefinidamente
            if (session.botMsgIds.size > 200) {
                const first = session.botMsgIds.values().next().value;
                session.botMsgIds.delete(first);
            }
        }
    } catch (e) {
        console.error(`${CHATBOT_TAG} Error enviando respuesta:`, e.message);
    }
}

// ─── Verifica si el mensaje es una respuesta al bot en una sesión activa ──────

function isReplyToBot(message) {
    // Buscar el ID del mensaje citado
    const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
    if (!baileyMsg) return false;

    // quotedId viene ya parseado en el objeto compatibleMessage
    const quotedId = (message.quoted && message.quoted.id) ||
        (message._data && message._data.quotedMsg && message._data.quotedMsg.id);
    if (quotedId) return quotedId;

    // Intentar extraer desde Baileys directamente
    try {
        const inner = baileyMsg.message || {};
        const getCtx = (obj) => obj && obj.contextInfo;
        const ctx = getCtx(inner.extendedTextMessage) ||
            getCtx(inner.imageMessage) || getCtx(inner.videoMessage) ||
            getCtx(inner.audioMessage) || getCtx(inner.documentMessage) ||
            getCtx(inner.stickerMessage) || getCtx(inner) || null;
        if (ctx && ctx.stanzaId) return ctx.stanzaId;
    } catch (_) {}

    return null;
}

// ─── textReplyHandler: se llama para TODO mensaje que NO tiene prefijo ─────────
// Aquí detectamos replies al bot o mensajes en sesión activa

async function textReplyHandler(message) {
    try {
        const userId = getCanonicalUserId(message);
        if (!userId) return;

        const session = sessions.get(userId);
        if (!session) return; // Sin sesión activa, no hacer nada

        // Verificar si el mensaje es un reply a un mensaje del bot
        const quotedId = isReplyToBot(message);
        const isReply = quotedId && session.botMsgIds.has(quotedId);

        // Si hay sesión activa Y (es reply al bot O simplemente escribe), responder
        // Pero para no responder a CUALQUIER mensaje (ej. el usuario hablando con otro),
        // solo responder si es un reply directo al bot.
        // Si quieren hablar sin reply, deben usar .chatbot <mensaje>
        if (!isReply) return;

        const text = (typeof message.body === 'string' ? message.body : '').trim();
        await procesarMensajeChatbot(message, session, text);

    } catch (e) {
        console.error(`${CHATBOT_TAG} textReplyHandler error:`, e.message);
    }
}

// ─── Handler principal del comando .chatbot ───────────────────────────────────

let handler = async function(message, params) {
    const { text, command } = params;
    const userId = getCanonicalUserId(message);

    if (!userId) {
        return message.reply('⚠️ No se pudo identificar tu número de WhatsApp.');
    }

    // Determinar subcomando
    const rawText = (text || '').trim();
    const firstWord = rawText.split(' ')[0].toLowerCase();
    const restText = rawText.slice(firstWord.length).trim();

    const isStart = /^(start|iniciar|inicio|comenzar|empezar)$/i.test(firstWord) ||
                    /^(start|iniciar|inicio|comenzar|empezar)$/i.test(rawText);
    const isStop  = /^(stop|detener|parar|terminar|salir|fin|cerrar)$/i.test(firstWord) ||
                    /^(stop|detener|parar|terminar|salir|fin|cerrar)$/i.test(rawText);

    // ── .chatbot start ──────────────────────────────────────────────────────
    if (isStart) {
        if (sessions.has(userId)) {
            return message.reply(
                '💬 Ya tienes una sesión de chat activa conmigo.\n' +
                '_Responde a mis mensajes o usa .chatbot <mensaje> para hablarme._\n' +
                '_Usa .chatbot stop para terminar la sesión._'
            );
        }

        const displayName = getUserDisplayName(userId);
        const stickyInfo = displayName ? 'Nombre del usuario: ' + displayName : '';

        const session = {
            userId,
            botMsgIds: new Set(),
            history: [],
            stickyInfo,
            charCount: 0,
            lastActive: Date.now()
        };
        sessions.set(userId, session);

        const saludo = displayName
            ? '¡Hola, *' + displayName + '*! 👋 Soy *RobleBOT*, tu asistente personal en WhatsApp.\n¿De qué quieres hablar hoy? 😊\n\n_(Responde a este mensaje o usa `.chatbot <mensaje>` para chatear conmigo)_'
            : '¡Hola! 👋 Soy *RobleBOT*, tu asistente personal en WhatsApp.\n¿De qué quieres hablar hoy? 😊\n\n_(Responde a este mensaje o usa `.chatbot <mensaje>` para chatear conmigo)_';

        try {
            const sent = await message.reply(saludo);
            if (sent && sent.key && sent.key.id) {
                session.botMsgIds.add(sent.key.id);
            }
        } catch (e) {
            console.error(`${CHATBOT_TAG} Error enviando saludo:`, e.message);
        }
        return;
    }

    // ── .chatbot stop ───────────────────────────────────────────────────────
    if (isStop) {
        if (!sessions.has(userId)) {
            return message.reply('ℹ️ No tienes ninguna sesión de chat activa.');
        }
        sessions.delete(userId);
        return message.reply('👋 *Sesión de chat finalizada.* ¡Hasta luego!\n_Usa .chatbot start para iniciar una nueva sesión._');
    }

    // ── .chatbot <mensaje> ──────────────────────────────────────────────────
    if (!sessions.has(userId)) {
        return message.reply(
            'ℹ️ No tienes ninguna sesión de chat activa.\n\n' +
            'Usa `.chatbot start` para iniciar una sesión con RobleBOT.\n' +
            'O usa `.chatbot iniciar` si prefieres.'
        );
    }

    const session = sessions.get(userId);

    // Si .chatbot sin subcomando → usar todo el text como mensaje
    const msgText = rawText || '';
    await procesarMensajeChatbot(message, session, msgText);
};

handler.help = [
    'chatbot start',
    'chatbot stop',
    'chatbot <mensaje>'
];
handler.tags = ['ia', 'chat'];
handler.command = /^chatbot$/i;
handler.textReplyHandler = textReplyHandler;

module.exports = handler;

