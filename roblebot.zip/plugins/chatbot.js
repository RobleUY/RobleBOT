'use strict';

const axios = require('axios');

// ─── Configuración Groq (EXACTAMENTE igual que resumen.js) ────────────────────

// 👇 Keys hardcodeadas (igual que resumen.js)
const GROQ_KEYS_EXTRA = [
    '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',
    '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',
];

// Modelos en orden de prioridad (igual que resumen.js)
const GROQ_MODELS = [
    'llama-3.3-70b-versatile',
    'openai/gpt-oss-20b',
    'llama-3.1-8b-instant',
];

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const TIMEOUT = 15000;

const GROQ_ENV = ['groq_api_key', 'GROQ_API_KEY',
    ...Array.from({ length: 10 }, (_, i) => [`groq_api_key${i + 1}`, `GROQ_API_KEY${i + 1}`]).flat()];

function groqKeys() {
    const keys = new Set();
    for (const k of GROQ_KEYS_EXTRA) if (k && String(k).trim()) keys.add(String(k).trim());
    for (const k of (process.env.GROQ_KEYS || '').split(',')) if (k && k.trim()) keys.add(k.trim());
    for (const n of GROQ_ENV) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    return [...keys];
}

// ── Groq (igual que resumen.js) ───────────────────────────────────────────────
async function groq(key, model, messages, maxTokens) {
    const body = {
        model, temperature: 0.8, max_tokens: maxTokens,
        messages
    };
    if (model.startsWith('openai/gpt-oss')) body.reasoning_effort = 'low';
    const res = await axios.post(GROQ_URL, body, {
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        timeout: TIMEOUT
    });
    return res.data?.choices?.[0]?.message?.content || '';
}

const validar = (t) => {
    const s = typeof t === 'string' ? t.trim() : '';
    return s.length >= 1 ? s : null;
};

/**
 * Prueba las keys de a una en orden (igual que resumen.js).
 * Acepta messages[] completo (array de {role, content}) para soportar historial.
 */
async function llamarIA(messages, maxTokens = 600) {
    const keys = groqKeys();
    if (!keys.length) throw new Error('No hay API keys de Groq configuradas');

    const invalidas = new Set();
    let huboLimite = false;

    for (const model of GROQ_MODELS) {
        for (let i = 0; i < keys.length; i++) {
            if (invalidas.has(i)) continue;
            try {
                const limpio = validar(await groq(keys[i], model, messages, maxTokens));
                if (!limpio) throw new Error('respuesta vacía');
                console.log(`[CHATBOT] OK con ${model} (key #${i + 1} de ${keys.length})`);
                return limpio;
            } catch (err) {
                const status = err.response?.status;
                if (status === 401 || status === 403) invalidas.add(i);
                if (status === 429) huboLimite = true;
                console.log(`[CHATBOT] ${model} key#${i + 1} falló: ${status || ''} ${err.message}`);
            }
        }
    }

    const err = new Error('Ninguna key de Groq respondió');
    if (huboLimite) err.response = { status: 429 };
    throw err;
}

// ─── Transcripción de audio (Groq Whisper, igual lógica de keys) ──────────────

const https = require('https');
const STT_MODELS = ['whisper-large-v3-turbo', 'whisper-large-v3'];

function groqTranscribeRequest(apiKey, model, buffer, mime) {
    return new Promise((resolve, reject) => {
        const ext = mime && mime.includes('ogg') ? 'ogg' :
                    mime && mime.includes('mpeg') ? 'mp3' :
                    mime && mime.includes('wav') ? 'wav' :
                    mime && mime.includes('webm') ? 'webm' :
                    mime && mime.includes('m4a') ? 'm4a' : 'ogg';
        const filename = 'audio.' + ext;
        const boundary = '----RobleChatbot' + Date.now().toString(16);

        const parts = [];
        const campo = (name, value) => parts.push(
            Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + name + '"\r\n\r\n' + value + '\r\n')
        );
        campo('model', model);
        campo('response_format', 'text');
        campo('temperature', '0');
        parts.push(Buffer.from(
            '--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="' + filename + '"\r\n' +
            'Content-Type: ' + (mime || 'audio/ogg') + '\r\n\r\n'
        ));
        parts.push(buffer);
        parts.push(Buffer.from('\r\n--' + boundary + '--\r\n'));

        const body = Buffer.concat(parts);

        const req = https.request({
            hostname: 'api.groq.com',
            path: '/openai/v1/audio/transcriptions',
            method: 'POST',
            headers: {
                'Authorization': 'Bearer ' + apiKey,
                'Content-Type': 'multipart/form-data; boundary=' + boundary,
                'Content-Length': body.length
            }
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode >= 200 && res.statusCode < 300 && data && !data.startsWith('{')) {
                    return resolve(data.trim());
                }
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq STT');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    resolve((parsed.text || '').trim());
                } catch (_) {
                    reject(new Error('Error parseando respuesta STT'));
                }
            });
        });

        req.on('error', reject);
        req.setTimeout(90000, () => { req.destroy(); reject(new Error('Timeout STT')); });
        req.write(body);
        req.end();
    });
}

async function transcribirAudio(buffer, mime) {
    const keys = groqKeys();
    let lastErr = null;
    for (let k = 0; k < keys.length; k++) {
        for (const model of STT_MODELS) {
            try {
                return await groqTranscribeRequest(keys[k], model, buffer, mime);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuth = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[CHATBOT] STT key #${k + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuth) throw e;
            }
        }
    }
    throw lastErr || new Error('STT falló');
}

// ─── Sesiones en memoria ──────────────────────────────────────────────────────
// Map<userId, SessionObject>
const sessions = new Map();

const MAX_CHARS = 2000;

// ─── Helpers de sesión ────────────────────────────────────────────────────────

function cleanUserId(raw) {
    if (!raw) return '';
    return String(raw).split('@')[0].split(':')[0].replace(/\D/g, '');
}

function getUserDisplayName(userId) {
    try {
        const clean = cleanUserId(userId);
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(clean) || global.db.getUser(userId);
            const apodo = (user && user.apodo || '').toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') return apodo;
        }
    } catch (_) {}
    return null;
}

function getCanonicalUserId(message) {
    const raw = message.author || message.sender || message.from || '';
    return cleanUserId(raw);
}

// ─── Gestión de contexto (ventana deslizante 2000 chars) ─────────────────────

function buildSystemPrompt(session) {
    const sticky = session.stickyInfo
        ? 'Información del usuario que debes recordar siempre:\n' + session.stickyInfo + '\n\n'
        : '';
    return (
        'Eres RobleBOT, un asistente amigable y conversacional de WhatsApp.\n' +
        'Fuiste creado por Dev RobleUY.\n' +
        'REGLAS:\n' +
        '- Responde en español, de forma natural y amigable.\n' +
        '- Usa formato de WhatsApp: *negrita*, _cursiva_. Nunca uses Markdown normal (no ## ni **).\n' +
        '- Mensajes cortos y claros (máximo 3-4 párrafos).\n' +
        '- Si ves "[Audio transcripto]:" es porque el usuario te mandó una nota de voz.\n' +
        '- No inventes información que no tienes.\n' +
        sticky +
        'Tu nombre es RobleBOT. Si el usuario pregunta quién eres, díselo.'
    );
}

function addToHistory(session, role, content) {
    const entryLen = role.length + content.length + 2;
    while (session.history.length > 0 && session.charCount + entryLen > MAX_CHARS) {
        const removed = session.history.shift();
        session.charCount -= (removed.role.length + removed.content.length + 2);
        if (session.charCount < 0) session.charCount = 0;
    }
    session.history.push({ role, content });
    session.charCount += entryLen;
    session.lastActive = Date.now();
}

function tryUpdateStickyInfo(session, userMsg) {
    if (session.stickyInfo) return;
    const nameMatch = userMsg.match(/(?:me llamo|soy|mi nombre es|llámame)\s+([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,15})/i);
    if (nameMatch) {
        session.stickyInfo = 'Nombre del usuario: ' + nameMatch[1];
    }
}

// ─── Respuesta de la IA ───────────────────────────────────────────────────────

async function responderChatbot(session, userText, message) {
    addToHistory(session, 'user', userText);

    const messages = [
        { role: 'system', content: buildSystemPrompt(session) },
        ...session.history
    ];

    let respuesta;
    try {
        respuesta = await llamarIA(messages, 600);
    } catch (e) {
        console.error('[CHATBOT] Error llamando IA:', e.message);
        const status = e.response?.status;
        if (status === 429) {
            await message.reply('⏳ _Groq está saturado ahora mismo. Intenta en unos segundos._');
        } else {
            await message.reply('⚠️ _No pude conectarme con la IA en este momento. Intenta de nuevo._');
        }
        const last = session.history.pop();
        if (last) session.charCount -= (last.role.length + last.content.length + 2);
        return null;
    }

    addToHistory(session, 'assistant', respuesta);
    tryUpdateStickyInfo(session, userText);
    return respuesta;
}

// ─── Descarga de audio ────────────────────────────────────────────────────────

async function downloadAudioFromMessage(message) {
    try {
        if (typeof message.download === 'function') {
            const buf = await message.download();
            if (buf && buf.length) {
                const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
                const inner = baileyMsg && baileyMsg.message;
                const mime = (inner && inner.audioMessage && inner.audioMessage.mimetype) || 'audio/ogg';
                return { buffer: buf, mime };
            }
        }
    } catch (_) {}

    try {
        let baileys = null;
        for (const name of ['@whiskeysockets/baileys', '@adiwajshing/baileys', 'baileys']) {
            try { baileys = require(name); break; } catch (_) {}
        }
        if (baileys && baileys.downloadContentFromMessage) {
            const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
            const inner = baileyMsg && baileyMsg.message;
            const audioMsg = inner && inner.audioMessage;
            if (audioMsg) {
                const stream = await baileys.downloadContentFromMessage(audioMsg, 'audio');
                const chunks = [];
                for await (const chunk of stream) chunks.push(chunk);
                return { buffer: Buffer.concat(chunks), mime: audioMsg.mimetype || 'audio/ogg' };
            }
        }
    } catch (_) {}

    return null;
}

function isAudioMessage(message) {
    if (message.body === '«audio»') return true;
    const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
    if (!baileyMsg) return false;
    const inner = baileyMsg.message || {};
    return !!(inner.audioMessage || inner.ptvMessage);
}

// ─── Detección de reply al bot ────────────────────────────────────────────────

function getQuotedId(message) {
    // Forma serializada (messageUtils.js ya lo resuelve en message.quoted.id)
    if (message.quoted && message.quoted.id) return message.quoted.id;

    // Fallback: extraer desde Baileys directamente
    try {
        const baileyMsg = message._baileyMessage || message.baileyMessage || message.rawMessage;
        if (!baileyMsg) return null;
        const inner = baileyMsg.message || {};
        const getCtx = (obj) => obj && obj.contextInfo;
        const ctx = getCtx(inner.extendedTextMessage) ||
            getCtx(inner.imageMessage) || getCtx(inner.videoMessage) ||
            getCtx(inner.audioMessage) || getCtx(inner.documentMessage) ||
            getCtx(inner.stickerMessage) || null;
        if (ctx && ctx.stanzaId) return ctx.stanzaId;
    } catch (_) {}

    return null;
}

// ─── Procesamiento unificado de mensaje al chatbot ────────────────────────────

async function procesarMensajeChatbot(message, session, rawUserText) {
    let userText = rawUserText;

    if (!userText || userText === '«audio»') {
        if (isAudioMessage(message)) {
            try {
                await message.reply('🎧 _Transcribiendo audio..._');
                const dl = await downloadAudioFromMessage(message);
                if (dl && dl.buffer && dl.buffer.length) {
                    const transcripcion = await transcribirAudio(dl.buffer, dl.mime);
                    if (transcripcion) {
                        userText = '[Audio transcripto]: ' + transcripcion;
                    } else {
                        await message.reply('⚠️ _No pude transcribir el audio._');
                        return;
                    }
                } else {
                    await message.reply('⚠️ _No pude descargar el audio._');
                    return;
                }
            } catch (e) {
                console.error('[CHATBOT] Error transcribiendo:', e.message);
                await message.reply('⚠️ _Error al transcribir el audio._');
                return;
            }
        } else {
            return;
        }
    }

    if (!userText.trim()) return;

    const respuesta = await responderChatbot(session, userText, message);
    if (!respuesta) return;

    try {
        const sent = await message.reply(respuesta);
        if (sent && sent.key && sent.key.id) {
            session.botMsgIds.add(sent.key.id);
            if (session.botMsgIds.size > 200) {
                const first = session.botMsgIds.values().next().value;
                session.botMsgIds.delete(first);
            }
        }
    } catch (e) {
        console.error('[CHATBOT] Error enviando respuesta:', e.message);
    }
}

// ─── textReplyHandler: detecta replies al bot ─────────────────────────────────

async function textReplyHandler(message) {
    try {
        const userId = getCanonicalUserId(message);
        if (!userId) return;

        const session = sessions.get(userId);
        if (!session) return;

        const quotedId = getQuotedId(message);
        if (!quotedId || !session.botMsgIds.has(quotedId)) return;

        const text = (typeof message.body === 'string' ? message.body : '').trim();
        await procesarMensajeChatbot(message, session, text);
    } catch (e) {
        console.error('[CHATBOT] textReplyHandler error:', e.message);
    }
}

// ─── Handler principal del comando .chatbot ───────────────────────────────────

let handler = async function(message, params) {
    const { text } = params;
    const userId = getCanonicalUserId(message);

    if (!userId) {
        return message.reply('⚠️ No se pudo identificar tu número de WhatsApp.');
    }

    const rawText = (text || '').trim();
    const firstWord = rawText.split(' ')[0].toLowerCase();

    const isStart = /^(start|iniciar|inicio|comenzar|empezar)$/i.test(firstWord) ||
                    /^(start|iniciar|inicio|comenzar|empezar)$/i.test(rawText);
    const isStop  = /^(stop|detener|parar|terminar|salir|fin|cerrar)$/i.test(firstWord) ||
                    /^(stop|detener|parar|terminar|salir|fin|cerrar)$/i.test(rawText);

    // ── .chatbot start ──────────────────────────────────────────────────────
    if (isStart) {
        if (sessions.has(userId)) {
            return message.reply(
                '💬 Ya tienes una sesión de chat activa conmigo.\n' +
                '_Responde a mis mensajes o usa .chatbot <mensaje> para hablarme._\n' +
                '_Usa .chatbot stop para terminar la sesión._'
            );
        }

        const displayName = getUserDisplayName(userId);
        const session = {
            userId,
            botMsgIds: new Set(),
            history: [],
            stickyInfo: displayName ? 'Nombre del usuario: ' + displayName : '',
            charCount: 0,
            lastActive: Date.now()
        };
        sessions.set(userId, session);

        const saludo = displayName
            ? '¡Hola, *' + displayName + '*! 👋 Soy *RobleBOT*\n¿De qué quieres hablar hoy? 😊\n\n_(Responde a este mensaje para chatear conmigo)_'
            : '¡Hola! 👋 Soy *RobleBOT*\n¿De qué quieres hablar hoy? 😊\n\n_(Responde a este mensaje para chatear conmigo)_';

        try {
            const sent = await message.reply(saludo);
            if (sent && sent.key && sent.key.id) {
                session.botMsgIds.add(sent.key.id);
            }
        } catch (e) {
            console.error('[CHATBOT] Error enviando saludo:', e.message);
        }
        return;
    }

    // ── .chatbot stop ───────────────────────────────────────────────────────
    if (isStop) {
        if (!sessions.has(userId)) {
            return message.reply('ℹ️ No tienes ninguna sesión de chat activa.');
        }
        sessions.delete(userId);
        return message.reply('👋 *Sesión de chat finalizada.* ¡Hasta luego!\n_Usa .chatbot start para iniciar una nueva sesión._');
    }

    // ── .chatbot <mensaje> ──────────────────────────────────────────────────
    if (!sessions.has(userId)) {
        return message.reply(
            'ℹ️ No tienes ninguna sesión de chat activa.\n\n' +
            'Usa `.chatbot start` para iniciar una sesión con RobleBOT.'
        );
    }

    await procesarMensajeChatbot(message, sessions.get(userId), rawText);
};

handler.help = ['chatbot start', 'chatbot stop', 'chatbot <mensaje>'];
handler.tags = ['ia', 'chat'];
handler.command = /^chatbot$/i;
handler.textReplyHandler = textReplyHandler;

module.exports = handler;
