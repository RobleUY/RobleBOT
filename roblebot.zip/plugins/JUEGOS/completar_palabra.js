const fs = require('fs');
const path = require('path');

// 📂 Cargar palabras desde el archivo JSON
let palabras = [];
const palabrasPath = path.join(__dirname, 'palabras.json');

try {
    const data = fs.readFileSync(palabrasPath, 'utf8');
    palabras = JSON.parse(data);
    console.log(`\x1b[32m[COMPLETAR] ✅ Cargadas ${palabras.length} palabras desde palabras.json\x1b[0m`);
} catch (error) {
    console.error('\x1b[31m[COMPLETAR] ❌ Error al cargar palabras.json:', error.message, '\x1b[0m');
    palabras = ['roble', 'camion', 'fuego', 'lluvia', 'planta']; // respaldo
}

// 📦 Partidas activas por grupo
const partidasActivas = new Map();

const TIEMPO_LIMITE = 15000; // 15s
const PREMIO_POR_SEGUNDO = 50;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;

// ✨ Eliminar tildes y normalizar texto
function limpiarTexto(str) {
    return str
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]/g, '')
        .toLowerCase()
        .trim();
}

// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

function esCitaValida(message, partida) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    if (!isGroup) return true;

    const qInfo = obtenerQuotedInfo(message);
    if (!qInfo.hasQuote) return false;

    if (partida.botMsgId && qInfo.quotedId && qInfo.quotedId === partida.botMsgId) return true;
    if (qInfo.quotedText && /completar|palabra incompleta|completa la palabra/i.test(qInfo.quotedText)) return true;
    if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) return true;

    return false;
}

// 🔄 Recargar palabras
function recargarPalabras() {
    try {
        delete require.cache[palabrasPath];
        const data = fs.readFileSync(palabrasPath, 'utf8');
        palabras = JSON.parse(data);
        console.log(`\x1b[32m[COMPLETAR] ✅ Recargadas ${palabras.length} palabras\x1b[0m`);
        return true;
    } catch (error) {
        console.error('\x1b[31m[COMPLETAR] ❌ Error al recargar palabras.json:', error.message, '\x1b[0m');
        return false;
    }
}

// 🧠 Generar palabra incompleta (ahora oculta el 25 % de las letras)
function generarIncompleta(palabra) {
    const letras = palabra.split('');
    const indices = new Set();

    // Oculta el 25 % de las letras (mínimo 1)
    const cantidadOcultar = Math.max(1, Math.round(letras.length * 0.25));

    while (indices.size < cantidadOcultar) {
        const idx = Math.floor(Math.random() * letras.length);
        if (/[a-zA-Z]/.test(letras[idx])) indices.add(idx);
    }

    for (const i of indices) letras[i] = '_';
    return letras.join('');
}

// 🎮 Comando principal
async function handler(message, { text, conn }) {
    try {
        console.log('\x1b[33m[COMPLETAR] Comando ejecutado\x1b[0m');
        const sock = conn || message._sock || global.conn;

        // 🔁 Recargar lista
        if (text && text.toLowerCase() === 'reload') {
            const ok = recargarPalabras();
            return await message.reply(
                ok
                    ? `✅ Palabras recargadas exitosamente.\n📘 Total: ${palabras.length}`
                    : '❌ Error al recargar palabras.json.'
            );
        }

        if (!palabras.length) return await message.reply('❌ No hay palabras cargadas.');
        const chatId = message.from;
        if (partidasActivas.has(chatId))
            return await message.reply('❌ Ya hay una palabra activa, espera a que termine.');

        // 🔤 Elegir palabra aleatoria
        const palabraCorrecta = palabras[Math.floor(Math.random() * palabras.length)];
        const palabraLimpia = limpiarTexto(palabraCorrecta);
        const palabraIncompleta = generarIncompleta(palabraLimpia);

        // 💬 Enviar mensaje
        const mensaje = `🧠 *COMPLETA LA PALABRA*\n\n🔡 Completa la palabra:\n*${palabraIncompleta.toUpperCase()}* (${palabraLimpia.length} letras)\n\n💡 Responde con la palabra completa.\n⏱️ Tienes ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;

        const sentMsg = await message.reply(mensaje);

        const partida = {
            palabra: palabraCorrecta,
            palabraLimpia,
            tiempoInicio: Date.now(),
            timeout: null,
            botMsgId: sentMsg?.key?.id || sentMsg?.id || null,
        };

        partidasActivas.set(chatId, partida);

        partida.timeout = setTimeout(async () => {
            const activa = partidasActivas.get(chatId);
            if (!activa) return;
            partidasActivas.delete(chatId);

            await sock.sendMessage(chatId, {
                text: `⏰ *¡TIEMPO AGOTADO!*\n\nLa palabra era: *${activa.palabra.toUpperCase()}*\n💡 Usa /completar para jugar de nuevo.`,
            });
        }, TIEMPO_LIMITE);
    } catch (err) {
        console.error('\x1b[31m[COMPLETAR ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error al iniciar el juego.');
    }
}

// 💬 Manejador de respuestas
async function textReplyHandler(message) {
    try {
        const sock = message._sock || message.conn || global.conn;
        if (!sock) {
            console.error('[COMPLETAR REPLY] No socket disponible para enviar la respuesta');
            return;
        }

        const chatId = message.from;
        const partida = partidasActivas.get(chatId);
        if (!partida) return;

        const isGroup = chatId.endsWith('@g.us');
        if (isGroup && !esCitaValida(message, partida)) return;

        const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
        if (tiempoTranscurrido > TIEMPO_LIMITE) return;

        const respuesta = limpiarTexto(message.body || '');
        if (!respuesta) return;
        if (respuesta.length < 2) {
            return await message.reply('❌ Responde con la palabra completa, por favor.');
        }

        const esCorrecta = respuesta === partida.palabraLimpia;

        if (esCorrecta) {
            const tiempoRestanteMs = TIEMPO_LIMITE - tiempoTranscurrido;
            const segundosRestantes = Math.max(0, tiempoRestanteMs / 1000);
            const premio = Math.max(50, Math.min(150, Math.floor(segundosRestantes * 10)));

            // 💰 Añadir dinero usando global.db (MISMA LÓGICA QUE 'DAILY')
            try {
                // 1) Obtener ID único del usuario
                const winnerId = message.author || message.from;

                // 2) Cargar datos del usuario
                let user = global.db.getUser(winnerId); 
                if (!user) {
                    user = { money: 0 }; 
                }

                // 3) Actualizar dinero del ganador
                user.money = Number(user.money) || 0;
                user.money += premio;
                
                // 4) Guardar los cambios en la base de datos
                global.db.setUser(winnerId, user); 

            } catch (e) {
                console.log('\x1b[31m[COMPLETAR DB ERROR]\x1b[0m', e.message);
            }

            clearTimeout(partida.timeout);
            partidasActivas.delete(chatId);

            const ganador = (message.author || message.from).split('@')[0];
            await sock.sendMessage(chatId, {
                text: `🎉 *¡CORRECTO!* @${ganador}\n\n✅ Palabra: *${partida.palabra.toUpperCase()}*\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s\n💰 Premio: $${premio.toLocaleString()}`,
                mentions: [message.author || message.from],
            });
        } else {
            await message.reply(`❌ *Incorrecto*, intenta otra vez.`);
        }
    } catch (err) {
        console.error('\x1b[31m[COMPLETAR REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(completar)$/i,
    handler,
    textReplyHandler,
    help: 'Juego de completar palabras.\n• Escribe /completar para comenzar.\n• Responde al mensaje con la palabra completa.\n• Tienes 15s.\n• Premio máximo: $7.500.\n• /completar reload para recargar lista (solo owner)',
    tags: ['diversion', 'juegos'],
};

module.exports.apodo = true;