const fs = require('fs');
const path = require('path');

// 📂 Rutas
const palabrasPath = path.join(__dirname, 'ahorcado_palabras.json');
const partidasPath = path.join(__dirname, 'ahorcado_partidas.json');

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎨 DIBUJOS DEL AHORCADO (0 = vivo, 5 = muerto)
// Partes: cabeza, brazo izq, brazo der, pierna izq, pierna der
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const DIBUJOS = [
    // 0 errores - nadie colgado
    `\`\`\`
  +---+
  |   |
      |
      |
      |
      |
=========\`\`\``,

    // 1 error - cabeza
    `\`\`\`
  +---+
  |   |
  O   |
      |
      |
      |
=========\`\`\``,

    // 2 errores - cabeza + brazo izquierdo
    `\`\`\`
  +---+
  |   |
  O   |
  |   |
      |
      |
=========\`\`\``,

    // 3 errores - cabeza + 2 brazos
    `\`\`\`
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========\`\`\``,

    // 4 errores - cabeza + 2 brazos completos
    `\`\`\`
  +---+
  |   |
  O   |
 /|\\  |
      |
      |
=========\`\`\``,

    // 5 errores - cabeza + brazos + pierna izquierda
    `\`\`\`
  +---+
  |   |
  O   |
 /|\\  |
 /    |
      |
=========\`\`\``,

    // 6 errores - MUERTO completo
    `\`\`\`
  +---+
  |   |
  O   |
 /|\\  |
 / \\  |
      |
=========\`\`\``
];

const MAX_ERRORES = 6;
const PARTES_CUERPO = ['cabeza', 'torso', 'brazo izquierdo', 'brazo derecho', 'pierna izquierda', 'pierna derecha'];

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💾 CARGA / GUARDADO DE PARTIDAS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
let estadoGlobal = { partidas: {} };

function cargarEstado() {
    try {
        if (fs.existsSync(partidasPath)) {
            const data = JSON.parse(fs.readFileSync(partidasPath, 'utf8'));
            estadoGlobal.partidas = data.partidas || {};
        }
    } catch (err) {
        console.error('\x1b[31m[AHORCADO] Error al leer partidas:', err.message, '\x1b[0m');
        estadoGlobal = { partidas: {} };
    }
}

function guardarEstado() {
    try {
        fs.writeFileSync(partidasPath, JSON.stringify(estadoGlobal, null, 2), 'utf8');
    } catch (err) {
        console.error('\x1b[31m[AHORCADO] Error al guardar partidas:', err.message, '\x1b[0m');
    }
}

cargarEstado();

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎬 CARGA DE PELÍCULAS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
let peliculas = [];

function cargarPeliculas() {
    try {
        if (fs.existsSync(palabrasPath)) {
            const data = JSON.parse(fs.readFileSync(palabrasPath, 'utf8'));
            peliculas = (data.peliculas || []).filter(p => p && p.trim().length >= 3);
            console.log(`\x1b[32m[AHORCADO] ✅ Cargadas ${peliculas.length} películas\x1b[0m`);
            return true;
        }
    } catch (e) {
        console.error('\x1b[31m[AHORCADO] Error cargando películas:', e.message, '\x1b[0m');
    }
    peliculas = ['Titanic', 'Avatar', 'Matrix', 'Joker', 'Shrek', 'Coco', 'Frozen', 'Mulan'];
    return false;
}

cargarPeliculas();

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🛠️ UTILIDADES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function obtenerCleanUser(sender) {
    if (!sender) return '';
    return String(sender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

function normalizeNumber(jidPart) {
    return String(jidPart || '').split('@')[0].replace(/[^0-9]/g, '').trim();
}

// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 🔍 Obtener información completa del mensaje citado (Baileys multi-device / subbots)
function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function esCitaValida(message, partida, quotedInfo = null) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    if (!isGroup) return true;

    const qInfo = quotedInfo || obtenerQuotedInfo(message);
    const userId = message.author || message.from;

    if (qInfo.hasQuote) {
        // 1. Verificar por ID del mensaje
        if (qInfo.quotedId) {
            const ids = Array.isArray(partida.botMsgIds) ? partida.botMsgIds : [];
            if (partida.botMsgId) ids.push(partida.botMsgId);
            if (ids.includes(qInfo.quotedId)) return true;
        }

        // 2. Verificar por texto del tablero citado
        if (qInfo.quotedText && /ahorcado|película|letras usadas/i.test(qInfo.quotedText)) {
            return true;
        }

        // 3. Verificar si citó un mensaje enviado por un bot
        if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) {
            return true;
        }

        // 4. Si es partida privada del propio usuario
        if (!partida.esPublico && partida.creador && mismoNumero(partida.creador, userId)) {
            return true;
        }

        return false;
    }

    // Sin cita: permitir si es partida privada del propio usuario
    if (!partida.esPublico && partida.creador && mismoNumero(partida.creador, userId)) return true;

    return false;
}

function normalizarTexto(str) {
    return (str || '')
        .toLowerCase()
        .replace(/[áàäâ]/g, 'a')
        .replace(/[éèëê]/g, 'e')
        .replace(/[íìïî]/g, 'i')
        .replace(/[óòöô]/g, 'o')
        .replace(/[úùüû]/g, 'u')
        // ñ se preserva tal cual, no se convierte a n
        .trim();
}

// Convierte "Titanic" → "T _ _ _ _ _ _" respetando espacios
function mostrarProgreso(palabraOriginal, letrasAdivinadas) {
    return palabraOriginal
        .split('')
        .map(char => {
            if (char === ' ') return '  ';
            const norm = normalizarTexto(char);
            if (letrasAdivinadas.has(norm)) return char.toUpperCase();
            return '_';
        })
        .join(' ');
}

function palabraCompleta(palabraOriginal, letrasAdivinadas) {
    return palabraOriginal
        .split('')
        .every(char => char === ' ' || letrasAdivinadas.has(normalizarTexto(char)));
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📊 STATS EN global.db
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function obtenerStats(userId) {
    const base = { jugadas: 0, ganadas: 0, perdidas: 0, racha: 0, maxRacha: 0, monedasGanadas: 0 };
    try {
        if (global.db) {
            const user = global.db.getUser(userId);
            if (user?.ahorcado) return { ...base, ...user.ahorcado };
        }
    } catch (e) {}
    return base;
}

function actualizarStats(userId, esVictoria, premio = 0) {
    try {
        if (!global.db) return;
        let user = global.db.getUser(userId);
        if (!user) user = { money: 0 };
        if (!user.ahorcado) user.ahorcado = { jugadas: 0, ganadas: 0, perdidas: 0, racha: 0, maxRacha: 0, monedasGanadas: 0 };

        const st = user.ahorcado;
        st.jugadas = (st.jugadas || 0) + 1;

        if (esVictoria) {
            st.ganadas = (st.ganadas || 0) + 1;
            st.racha = (st.racha || 0) + 1;
            if (st.racha > (st.maxRacha || 0)) st.maxRacha = st.racha;
            st.monedasGanadas = (st.monedasGanadas || 0) + premio;
            user.money = (Number(user.money) || 0) + premio;
        } else {
            st.perdidas = (st.perdidas || 0) + 1;
            st.racha = 0;
        }

        global.db.setUser(userId, user);
        if (typeof global.db.save === 'function') global.db.save();
    } catch (e) {
        console.error('[AHORCADO DB ERROR]', e.message);
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎨 RENDERIZAR PARTIDA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function renderizar(partida, estado = 'EN_PROGRESO') {
    const errores = partida.errores;
    const dibujo = DIBUJOS[Math.min(errores, MAX_ERRORES)];
    const progreso = mostrarProgreso(partida.palabra, new Set(partida.letrasAdivinadas));
    const letrasUsadas = [...partida.letrasUsadas].sort().join(' ').toUpperCase() || 'Ninguna';
    const creadorClean = (partida.creador || '').split('@')[0];
    const tipoModo = partida.esPublico
        ? '🌐 *PÚBLICA* (Todo el chat puede jugar)'
        : `🔒 *PRIVADA* (Solo @${creadorClean})`;

    const partesRestantes = MAX_ERRORES - errores;
    const vidaBar = '❤️'.repeat(partesRestantes) + '🖤'.repeat(errores);

    let msg = `🎭 *AHORCADO - RobleBOT* 🎭\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `🎮 *Modo:* ${tipoModo}\n`;
    msg += `👤 *Creador:* @${creadorClean}\n`;
    msg += `🎬 *Categoría:* Películas\n\n`;

    msg += `${dibujo}\n\n`;

    msg += `📝 *PALABRA:*\n\`${progreso}\`\n\n`;

    msg += `${vidaBar}\n`;
    msg += `💀 *Errores:* ${errores}/${MAX_ERRORES}\n\n`;

    if (partida.errores > 0) {
        const parteAgregada = PARTES_CUERPO[errores - 1];
        msg += `☠️ *Última parte agregada:* ${parteAgregada}\n\n`;
    }

    msg += `🔤 *Letras usadas:* ${letrasUsadas}\n\n`;

    if (estado === 'EN_PROGRESO') {
        msg += `💡 *¿Cómo jugar?*\n`;
        msg += `• Responde a este mensaje con *una letra*.\n`;
        msg += `• O escribe *.ahorcado <letra>*\n`;
        msg += `• Para adivinar la película entera: *.ahorcado pelicula <nombre>*\n`;
        msg += `• Para rendirte: *.ahorcado rendirse*`;
    }

    return msg;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔍 BUSCAR PARTIDA ACTIVA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function buscarPartida(chatId, userId, quotedInfo = null) {
    cargarEstado();

    const qInfo = quotedInfo || {};

    // 1. Si citó un mensaje, buscar por ID
    if (qInfo.quotedId) {
        for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
            const ids = Array.isArray(p.botMsgIds) ? p.botMsgIds : [];
            if (p.botMsgId) ids.push(p.botMsgId);
            if (ids.includes(qInfo.quotedId)) return { key, partida: p };
        }
    }

    // 2. Si citó mensaje con texto de Ahorcado, buscar en este chat
    if (qInfo.quotedText && /ahorcado|película|letras usadas/i.test(qInfo.quotedText)) {
        for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
            if (key.startsWith(chatId + ':') && mismoNumero(p.creador, userId)) {
                return { key, partida: p };
            }
        }
        if (estadoGlobal.partidas[chatId]) {
            return { key: chatId, partida: estadoGlobal.partidas[chatId] };
        }
    }

    // 3. Buscar partida privada del usuario en este chat
    const cleanUser = obtenerCleanUser(userId);
    const privateKey = `${chatId}:${cleanUser}`;
    if (estadoGlobal.partidas[privateKey]) return { key: privateKey, partida: estadoGlobal.partidas[privateKey] };
    for (const [key, p] of Object.entries(estadoGlobal.partidas)) {
        if (key.startsWith(chatId + ':') && mismoNumero(p.creador, userId)) {
            return { key, partida: p };
        }
    }

    // 4. Buscar partida pública del chat
    const publicKey = chatId;
    if (estadoGlobal.partidas[publicKey]) return { key: publicKey, partida: estadoGlobal.partidas[publicKey] };

    return { key: null, partida: null };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🕹️ PROCESAR LETRA / INTENTO
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function procesarLetra(gameKey, partida, message, letraBruta) {
    const sock = getSock(message);
    const chatId = message.from;
    const userId = message.author || message.from;

    const letra = normalizarTexto(letraBruta.trim());
    if (!letra || letra.length !== 1 || !/[a-zñ0-9]/.test(letra)) return;

    // Verificar si la partida es privada y es de otro user
    if (!partida.esPublico && !mismoNumero(partida.creador, userId)) {
        const creadorClean = String(partida.creador).split('@')[0].split(':')[0];
        return await message.reply(
            `⚠️ Esta partida de Ahorcado es *PRIVADA* de @${creadorClean}.\n\n💡 Usa *.ahorcado* para crear la tuya o *.ahorcado publico* para una pública.`,
            { mentions: [partida.creador] }
        );
    }

    if (partida.letrasUsadas.includes(letra)) {
        return await message.reply(`⚠️ La letra *"${letra.toUpperCase()}"* ya fue usada antes.\n\n🔤 Letras usadas: ${[...partida.letrasUsadas].join(' ').toUpperCase()}`);
    }

    partida.letrasUsadas.push(letra);

    const palabraNorm = normalizarTexto(partida.palabra);
    const letrasNormPalabra = palabraNorm.split('').filter(c => c !== ' ');

    if (letrasNormPalabra.includes(letra)) {
        // ✅ Letra correcta
        partida.letrasAdivinadas.push(letra);

        if (palabraCompleta(partida.palabra, new Set(partida.letrasAdivinadas))) {
            // 🏆 GANÓ
            const errores = partida.errores;
            const base = 80;
            const bonusErrores = (MAX_ERRORES - errores) * 10;
            const premio = base + bonusErrores;

            actualizarStats(userId, true, premio);
            const st = obtenerStats(userId);

            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            const tableroFinal = renderizar(partida, 'VICTORIA');
            const userTag = userId.split('@')[0];
            const msg = `${tableroFinal}\n\n🎉 *¡CORRECTO! ¡GANASTE!* @${userTag}\n\n🎬 La película era: *${partida.palabra}*\n💰 Premio: *$${premio.toLocaleString()}*\n🔥 Racha actual: *${st.racha}*`;

            return await sock.sendMessage(chatId, {
                text: msg,
                mentions: [userId, partida.creador].filter(Boolean)
            });
        }

        // Letra correcta pero no terminó
        guardarEstado();
        const tablero = renderizar(partida, 'EN_PROGRESO');
        const sent = await sock.sendMessage(chatId, {
            text: `✅ *¡Letra "${letra.toUpperCase()}" correcta!*\n\n${tablero}`,
            mentions: [partida.creador, userId].filter(Boolean)
        });
        if (sent?.key?.id) {
            partida.botMsgId = sent.key.id;
            if (!Array.isArray(partida.botMsgIds)) partida.botMsgIds = [];
            partida.botMsgIds.push(sent.key.id);
            guardarEstado();
        }

    } else {
        // ❌ Letra incorrecta
        partida.errores++;

        if (partida.errores >= MAX_ERRORES) {
            // 💀 PERDIÓ
            actualizarStats(userId, false, 0);

            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            const tableroFinal = renderizar(partida, 'DERROTA');
            const userTag = userId.split('@')[0];
            const msg = `${tableroFinal}\n\n💀 *¡GAME OVER!* El ahorcado murió.\n\n🎬 La película era: *${partida.palabra}*\n💡 Usa *.ahorcado* para volver a jugar.`;

            return await sock.sendMessage(chatId, {
                text: msg,
                mentions: [userId, partida.creador].filter(Boolean)
            });
        }

        // Letra incorrecta, sigue el juego
        const parteAgregada = PARTES_CUERPO[partida.errores - 1];
        guardarEstado();
        const tablero = renderizar(partida, 'EN_PROGRESO');
        const sent = await sock.sendMessage(chatId, {
            text: `❌ *Letra "${letra.toUpperCase()}" no está en la película.*\n☠️ Se agregó: *${parteAgregada}*\n\n${tablero}`,
            mentions: [partida.creador, userId].filter(Boolean)
        });
        if (sent?.key?.id) {
            partida.botMsgId = sent.key.id;
            if (!Array.isArray(partida.botMsgIds)) partida.botMsgIds = [];
            partida.botMsgIds.push(sent.key.id);
            guardarEstado();
        }
    }
}

// Intento de adivinar la película entera
async function procesarPeliculaCompleta(gameKey, partida, message, intentoBruto) {
    const sock = message._sock || message.conn || global.conn;
    const chatId = message.from;
    const userId = message.author || message.from;

    if (!partida.esPublico && partida.creador !== userId) {
        const creadorClean = partida.creador.split('@')[0];
        return await message.reply(
            `⚠️ Esta partida es *PRIVADA* de @${creadorClean}.`,
            { mentions: [partida.creador] }
        );
    }

    const intentoNorm = normalizarTexto(intentoBruto);
    const palabraNorm = normalizarTexto(partida.palabra);

    if (intentoNorm === palabraNorm) {
        // 🏆 ACERTÓ LA PELÍCULA ENTERA
        const errores = partida.errores;
        const base = 80;
        const bonusErrores = (MAX_ERRORES - errores) * 10;
        const premio = base + bonusErrores;

        actualizarStats(userId, true, premio);
        const st = obtenerStats(userId);

        // Marcar todas las letras como adivinadas
        const letrasUnicas = [...new Set(normalizarTexto(partida.palabra).split('').filter(c => c !== ' '))];
        partida.letrasAdivinadas = letrasUnicas;

        delete estadoGlobal.partidas[gameKey];
        guardarEstado();

        const tableroFinal = renderizar(partida, 'VICTORIA');
        const userTag = userId.split('@')[0];
        const msg = `${tableroFinal}\n\n🎉 *¡ADIVINASTE LA PELÍCULA COMPLETA!* @${userTag}\n\n🎬 Era: *${partida.palabra}*\n💰 Premio: *$${premio.toLocaleString()}*\n🔥 Racha: *${st.racha}*`;

        return await sock.sendMessage(chatId, {
            text: msg,
            mentions: [userId, partida.creador].filter(Boolean)
        });
    } else {
        // ❌ Incorrecto → penaliza con 1 error
        partida.errores++;

        if (partida.errores >= MAX_ERRORES) {
            actualizarStats(userId, false, 0);
            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            const tableroFinal = renderizar(partida, 'DERROTA');
            const userTag = userId.split('@')[0];
            return await sock.sendMessage(chatId, {
                text: `${tableroFinal}\n\n💀 *¡INCORRECTO Y GAME OVER!*\n🎬 La película era: *${partida.palabra}*`,
                mentions: [userId, partida.creador].filter(Boolean)
            });
        }

        guardarEstado();
        const tablero = renderizar(partida, 'EN_PROGRESO');
        const parteAgregada = PARTES_CUERPO[partida.errores - 1];
        const sent = await sock.sendMessage(chatId, {
            text: `❌ *"${intentoBruto}" no es la película.*\n☠️ Se agregó: *${parteAgregada}* por intento fallido.\n\n${tablero}`,
            mentions: [partida.creador, userId].filter(Boolean)
        });
        if (sent?.key?.id) {
            partida.botMsgId = sent.key.id;
            if (!Array.isArray(partida.botMsgIds)) partida.botMsgIds = [];
            partida.botMsgIds.push(sent.key.id);
            guardarEstado();
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🏆 TOP / RANKING
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
function construirEntradaRanking(userKey, userData) {
    if (!userData) return null;
    const st = userData.ahorcado || {};
    const ganadas = st.ganadas || 0;
    if (ganadas <= 0) return null;

    const jugadas = st.jugadas || 0;
    const winRate = jugadas > 0 ? ((ganadas / jugadas) * 100).toFixed(1) : '0.0';
    const apodoRaw = (userData.apodo || '').trim();
    const apodo = (!apodoRaw || apodoRaw.toLowerCase() === 'sin apodo') ? '👤 Sin Apodo' : apodoRaw;

    return {
        number: normalizeNumber(userKey),
        ganadas,
        jugadas,
        winRate,
        maxRacha: st.maxRacha || 0,
        monedasGanadas: st.monedasGanadas || 0,
        apodo
    };
}

async function mostrarTop(message, sock, argTokens) {
    try {
        if (!global.db?.data?.users) {
            return await message.reply('❌ No se pudo acceder a la base de datos.');
        }

        const chatId = message.from;
        const userId = message.author || message.from;
        const currentUserNumber = normalizeNumber(userId);
        const isGroupChat = typeof chatId === 'string' && chatId.endsWith('@g.us');
        const isGlobal = argTokens[1] && /^(g|global)$/i.test(argTokens[1]);

        if (!isGlobal && !isGroupChat) {
            return await message.reply('❌ Usa *.ahorcado top global* para ver el top mundial.');
        }

        let jugadores = [];

        if (isGlobal) {
            const aliases = global.db.data.aliases || {};
            const seen = new Set();
            for (const [userKey, userData] of Object.entries(global.db.data.users)) {
                if (aliases[userKey] && String(aliases[userKey]) !== String(userKey)) continue;
                const num = normalizeNumber(userKey);
                if (!num || seen.has(num)) continue;
                seen.add(num);
                const entrada = construirEntradaRanking(userKey, userData);
                if (entrada) jugadores.push(entrada);
            }
        } else {
            const participants = (await sock.groupMetadata(chatId)).participants.map(p => p.id);
            const seen = new Set();
            for (const participant of participants) {
                const userNumber = normalizeNumber(participant);
                if (!userNumber || seen.has(userNumber)) continue;
                seen.add(userNumber);

                const userData = global.db.getUser(userNumber);
                const entrada = construirEntradaRanking(participant, userData);
                if (entrada) jugadores.push(entrada);
            }
        }

        if (jugadores.length === 0) {
            return await message.reply('📊 Nadie tiene victorias en el ranking todavía.');
        }

        jugadores.sort((a, b) => b.ganadas - a.ganadas || b.winRate - a.winRate);

        const itemsPerPage = 10;
        const totalPages = Math.max(1, Math.ceil(jugadores.length / itemsPerPage));
        const pageArg = isGlobal ? argTokens[2] : argTokens[1];
        let page = 1;
        if (pageArg && !isNaN(pageArg)) page = Math.max(1, Math.min(parseInt(pageArg), totalPages));

        const start = (page - 1) * itemsPerPage;
        const pageUsers = jugadores.slice(start, start + itemsPerPage);
        const userIndex = jugadores.findIndex(u => u.number === currentUserNumber);
        const userPosition = userIndex + 1;
        const userPage = userPosition > 0 ? Math.ceil(userPosition / itemsPerPage) : 0;

        let txt = isGlobal ? `*🌍 TOP AHORCADO GLOBAL 🎭*\n\n` : `*🏆 TOP AHORCADO DEL GRUPO 🎭*\n\n`;
        txt += `👥 *Jugadores:* ${jugadores.length}\n\n`;

        if (userPosition > 0) {
            txt += `📍 *Tu posición:* #${userPosition} — *${jugadores[userIndex].apodo}*\n`;
            if (userPage !== page) txt += `   ↳ Usa *.ahorcado top ${isGlobal ? 'global ' : ''}${userPage}* para ir a tu página\n`;
        } else {
            txt += `📍 *Tu posición:* No estás en el ranking\n`;
        }

        txt += `\n_Página_ *${page}* _de_ *${totalPages}*\n`;

        if (totalPages > 1) {
            const modeArg = isGlobal ? ' global' : '';
            if (page > 1) txt += `⬅️ *.ahorcado top${modeArg} ${page - 1}* página anterior\n`;
            if (page < totalPages) txt += `➡️ *.ahorcado top${modeArg} ${page + 1}* siguiente página\n`;
        }

        txt += `\n`;

        pageUsers.forEach((u, i) => {
            const pos = start + i + 1;
            const medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `${pos}.`;
            txt += `${medal} *${u.apodo}*\n`;
            txt += `🏆 Victorias: *${u.ganadas}* | 📈 Win: *${u.winRate}%* | 🔥 Racha: *${u.maxRacha}*\n\n`;
        });

        if (!isGlobal) txt += `💡 _Usa *.ahorcado top global* para el ranking mundial_`;

        await message.reply(txt);

    } catch (err) {
        console.error('[AHORCADO TOP ERROR]', err);
        await message.reply('⚠️ Error al obtener el ranking.');
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎮 HANDLER PRINCIPAL
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function handler(message, { text, conn }) {
    try {
        cargarEstado();
        const sock = conn || message._sock || global.conn;
        const chatId = message.from;
        const userId = message.author || message.from;
        const cleanUser = obtenerCleanUser(userId);
        const arg = (text || '').trim();
        const argLower = arg.toLowerCase();
        const argTokens = arg.split(/\s+/).filter(Boolean);

        // ━━ TOP / RANKING ━━
        if (argTokens[0]?.toLowerCase() === 'top') {
            return await mostrarTop(message, sock, argTokens);
        }

        // ━━ STATS ━━
        if (['stats', 'perfil', 'estadisticas'].includes(argLower)) {
            const st = obtenerStats(userId);
            const winRate = st.jugadas > 0 ? ((st.ganadas / st.jugadas) * 100).toFixed(1) : '0.0';
            const userTag = userId.split('@')[0];

            const msg = `🎭 *ESTADÍSTICAS AHORCADO* 🎭\n━━━━━━━━━━━━━━━━━━━━━━\n👤 *Jugador:* @${userTag}\n\n🎮 *Jugadas:* ${st.jugadas}\n🏆 *Victorias:* ${st.ganadas}\n💀 *Derrotas:* ${st.perdidas}\n📈 *Win Rate:* ${winRate}%\n🔥 *Racha actual:* ${st.racha}\n⭐ *Mejor racha:* ${st.maxRacha}\n💰 *Monedas ganadas:* $${(st.monedasGanadas || 0).toLocaleString()}`;

            return await sock.sendMessage(chatId, { text: msg, mentions: [userId] });
        }

        // ━━ RENDIRSE ━━
        if (['rendirse', 'rendirme', 'surrender'].includes(argLower)) {
            const { key: gameKey, partida: p } = buscarPartida(chatId, userId);
            if (!p) return await message.reply('❌ No tienes ninguna partida activa de Ahorcado.');

            if (!p.esPublico && p.creador !== userId) {
                return await message.reply('❌ No puedes rendirte en la partida privada de otro usuario.');
            }

            actualizarStats(userId, false, 0);
            const pelicula = p.palabra;
            delete estadoGlobal.partidas[gameKey];
            guardarEstado();

            return await message.reply(`🏳️ *¡TE RENDISTE!*\n\n🎬 La película era: *${pelicula}*\n💡 Usa *.ahorcado* para jugar de nuevo.`);
        }

        // ━━ AYUDA ━━
        if (['ayuda', 'help', 'reglas'].includes(argLower)) {
            const msg = `🎭 *¿CÓMO JUGAR AL AHORCADO?* 🎭\n━━━━━━━━━━━━━━━━━━━━━━\n\n🎯 *Objetivo:* Adivinar el nombre de la película letra por letra antes de que el ahorcado muera.\n\n☠️ *El ahorcado tiene 6 partes:*\n_Cabeza → Torso → Brazo izq → Brazo der → Pierna izq → Pierna der_\n\nCada letra incorrecta agrega una parte. ¡A los 6 errores, GAME OVER!\n\n🔒 *Modos:*\n• *.ahorcado* → Partida *PRIVADA* (solo tú)\n• *.ahorcado publico* → Partida *PÚBLICA* (todo el chat)\n\n🎮 *Comandos:*\n• *.ahorcado <letra>* → Proponer una letra (ej: *.ahorcado a*)\n• *.ahorcado pelicula <nombre>* → Adivinar la película completa\n• *.ahorcado rendirse* → Rendirse y ver la respuesta\n• *.ahorcado stats* → Ver tus estadísticas\n• *.ahorcado top* → Ranking del grupo\n• *.ahorcado top global* → Ranking mundial\n\n💡 *También puedes* responder al mensaje del tablero con una letra directamente.`;

            return await message.reply(msg);
        }

        // ━━ ADIVINAR PELICULA COMPLETA ━━
        if (argTokens[0]?.toLowerCase() === 'pelicula' && argTokens.length > 1) {
            const { key: gameKey, partida: p } = buscarPartida(chatId, userId);
            if (!p) return await message.reply('❌ No hay ninguna partida activa. Usa *.ahorcado* para empezar.');
            const intentoPelicula = argTokens.slice(1).join(' ');
            return await procesarPeliculaCompleta(gameKey, p, message, intentoPelicula);
        }

        // ━━ PROPONER UNA LETRA (ej: .ahorcado a) ━━
        if (argTokens.length === 1 && /^[a-zñ0-9]$/i.test(normalizarTexto(argTokens[0]))) {
            const { key: gameKey, partida: p } = buscarPartida(chatId, userId);
            if (!p) return await message.reply('❌ No hay ninguna partida activa. Usa *.ahorcado* para empezar.');
            return await procesarLetra(gameKey, p, message, argTokens[0]);
        }

        // ━━ CREAR PARTIDA ━━
        const esPublico = ['publico', 'public', 'grupo'].includes(argLower);
        const targetKey = esPublico ? chatId : `${chatId}:${cleanUser}`;

        if (estadoGlobal.partidas[targetKey]) {
            const p = estadoGlobal.partidas[targetKey];
            const modoTxt = esPublico ? 'pública en este chat' : 'privada activa';
            const tablero = renderizar(p, 'EN_PROGRESO');
            const sent = await sock.sendMessage(chatId, {
                text: `⚠️ *Ya hay una partida ${modoTxt}:*\n\n${tablero}`,
                mentions: [p.creador].filter(Boolean)
            });
            if (sent?.key?.id) {
                p.botMsgId = sent.key.id;
                guardarEstado();
            }
            return;
        }

        // 🎬 Elegir película aleatoria
        if (!peliculas.length) cargarPeliculas();
        if (!peliculas.length) return await message.reply('❌ No hay películas disponibles.');

        const pelicula = peliculas[Math.floor(Math.random() * peliculas.length)];

        const nuevaPartida = {
            palabra: pelicula,
            letrasAdivinadas: [],
            letrasUsadas: [],
            errores: 0,
            creador: userId,
            esPublico: esPublico,
            tiempoInicio: Date.now(),
            botMsgId: null
        };

        estadoGlobal.partidas[targetKey] = nuevaPartida;
        guardarEstado();

        const tableroInicial = renderizar(nuevaPartida, 'EN_PROGRESO');
        const sent = await message.reply(tableroInicial);

        if (sent?.key?.id) {
            nuevaPartida.botMsgId = sent.key.id;
            nuevaPartida.botMsgIds = [sent.key.id];
            guardarEstado();
        }

    } catch (err) {
        console.error('\x1b[31m[AHORCADO HANDLER ERROR]', err, '\x1b[0m');
        await message.reply('❌ Ocurrió un error en el Ahorcado.');
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💬 REPLY HANDLER (responder al tablero con una letra)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async function textReplyHandler(message) {
    try {
        const chatId = message.from;
        const userId = message.author || message.from;
        const body = (message.body || '').trim();

        // No procesar comandos
        if (/^[./#❤️👅😎]/.test(body)) return;

        const quotedInfo = obtenerQuotedInfo(message);
        const { key: gameKey, partida } = buscarPartida(chatId, userId, quotedInfo);
        if (!partida) return;

        const isGroup = chatId.endsWith('@g.us');
        if (isGroup && !esCitaValida(message, partida, quotedInfo)) return;

        // Solo procesar si es exactamente 1 letra
        const bodyNorm = normalizarTexto(body);
        if (/^[a-zñ0-9]$/.test(bodyNorm)) {
            await procesarLetra(gameKey, partida, message, body);
        }

    } catch (err) {
        console.error('\x1b[31m[AHORCADO TEXT REPLY ERROR]', err, '\x1b[0m');
    }
}

module.exports = {
    command: /^(ahorcado|hangman)$/i,
    handler,
    textReplyHandler,
    help: '🎭 Juego del Ahorcado con películas.\n• .ahorcado → Partida privada\n• .ahorcado publico → Partida pública\n• .ahorcado <letra> → Proponer letra\n• .ahorcado pelicula <nombre> → Adivinar película completa\n• .ahorcado rendirse → Rendirse\n• .ahorcado stats → Tus estadísticas\n• .ahorcado top / top global → Ranking',
    tags: ['juegos', 'diversion']
};

module.exports.apodo = true;
