const fs = require('fs');
const path = require('path');

// --- Carga de Preguntas ---
let preguntas = [];
const preguntasPath = path.join(__dirname, 'preguntas.json');

try {
    const preguntasData = fs.readFileSync(preguntasPath, 'utf8');
    preguntas = JSON.parse(preguntasData);
    console.log(`\x1b[32m[TRIVIA] ✅ Cargadas ${preguntas.length} preguntas desde preguntas.json\x1b[0m`);
} catch (error) {
    console.error('\x1b[31m[TRIVIA] ❌ Error al cargar preguntas.json:', error.message, '\x1b[0m');
    // Preguntas de respaldo por si falla la carga
    preguntas = [
        {
            pregunta: "¿Cuál es el planeta más grande del sistema solar?",
            opciones: ["Júpiter", "Saturno", "Neptuno", "Urano"],
            respuesta: 0
        },
        {
            pregunta: "¿Quién pintó la Mona Lisa?",
            opciones: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
            respuesta: 1
        }
    ];
}

// Almacenar preguntas activas por chat
const preguntasActivas = new Map();
const TIEMPO_LIMITE = 15000; // 15 segundos
const PREMIO_POR_SEGUNDO = 10; // $500 por segundo
const PREMIO_MAXIMO = TIEMPO_LIMITE / 1000 * PREMIO_POR_SEGUNDO; // $7500

// 🔌 Obtener el socket activo (compatible con subbots y desconexión del bot principal)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

function esCitaValida(message, partida) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    if (!isGroup) return true;

    const qInfo = obtenerQuotedInfo(message);
    if (!qInfo.hasQuote) return false;

    if (partida.botMsgId && qInfo.quotedId && qInfo.quotedId === partida.botMsgId) return true;
    if (qInfo.quotedText && /trivia|pregunta|opción|opcion/i.test(qInfo.quotedText)) return true;
    if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) return true;

    return false;
}

// 🔄 Función para recargar preguntas desde el archivo
function recargarPreguntas() {
    try {
        // Limpiar caché para forzar recarga
        delete require.cache[preguntasPath];
        
        const preguntasData = fs.readFileSync(preguntasPath, 'utf8');
        preguntas = JSON.parse(preguntasData);
        console.log(`\x1b[32m[TRIVIA] ✅ Recargadas ${preguntas.length} preguntas desde preguntas.json\x1b[0m`);
        return true;
    } catch (error) {
        console.error('\x1b[31m[TRIVIA] ❌ Error al recargar preguntas.json:', error.message, '\x1b[0m');
        return false;
    }
}

// Handler principal del comando .trivia
async function handler(message, { text, conn }) {
    try {
        console.log('\x1b[33m[TRIVIA] Comando .trivia ejecutado\x1b[0m');
        const sock = conn || message._sock || global.conn;
        
        // 🔄 Comando para recargar preguntas (solo owner)
        if (text && text.toLowerCase() === 'reload') {
            const reloaded = recargarPreguntas();
            if (reloaded) {
                return await message.reply(`✅ Preguntas recargadas exitosamente.\n📊 Total: ${preguntas.length} preguntas`);
            } else {
                return await message.reply('❌ Error al recargar las preguntas. Revisa el archivo preguntas.json');
            }
        }

        // Verificar si hay preguntas disponibles
        if (preguntas.length === 0) {
            return await message.reply('❌ No hay preguntas disponibles. Contacta al administrador.');
        }
        
        const chatId = message.from;
        console.log('\x1b[33m[TRIVIA] ChatId:', chatId, '\x1b[0m');
        
        const preguntaActual = preguntasActivas.get(chatId);

        // Si hay una pregunta activa
        if (preguntaActual) {
            console.log('\x1b[33m[TRIVIA] Ya hay una pregunta activa\x1b[0m');
            
            // Verificar si el tiempo ha expirado
            const tiempoTranscurrido = Date.now() - preguntaActual.tiempoInicio;
            if (tiempoTranscurrido > TIEMPO_LIMITE) {
                // Limpiar el timeout anterior
                if (preguntaActual.timeout) {
                    clearTimeout(preguntaActual.timeout);
                }
                preguntasActivas.delete(chatId);
                await message.reply(`⏰ *¡TIEMPO AGOTADO!*\n\nLa respuesta correcta era: ${preguntaActual.opciones[preguntaActual.respuesta]}\n\n💡 Usa .trivia para una nueva pregunta`);
                return;
            }

            return await message.reply('❌ Hay una pregunta activa. Responde al mensaje de la pregunta con un número (1-4) o espera a que termine el tiempo.');
        }

        // Si no hay pregunta activa, generar una nueva
        const nuevaPregunta = preguntas[Math.floor(Math.random() * preguntas.length)];
        
        // Crear mensaje con la pregunta y opciones
        let mensajeTexto = `🎯 *RobleBOT - Trivia*\n\n❓ ${nuevaPregunta.pregunta}\n\n`;
        nuevaPregunta.opciones.forEach((opcion, index) => {
            mensajeTexto += `${index + 1}. ${opcion}\n`;
        });
        mensajeTexto += `\n💡 Responde a este mensaje con el número de tu respuesta (1-4)`;
        mensajeTexto += `\n⏱️ Tienes ${TIEMPO_LIMITE / 1000} segundos para responder`;
        mensajeTexto += `\n💰 Premio inicial: $${PREMIO_MAXIMO.toLocaleString()}`;
        mensajeTexto += `\n📉 Disminuye $${PREMIO_POR_SEGUNDO} por segundo`;

        // Enviar mensaje
        const sentMsg = await message.reply(mensajeTexto);
        
        // Guardar la pregunta activa (sin timeout por ahora)
        const preguntaConTiempo = {
            ...nuevaPregunta,
            tiempoInicio: Date.now(),
            timeout: null,
            botMsgId: sentMsg?.key?.id || sentMsg?.id || null,
            message: message // Guardamos el objeto message para enviar la respuesta después
        };
        
        preguntasActivas.set(chatId, preguntaConTiempo);
        
        // 🆕 Configurar timeout automático
        preguntaConTiempo.timeout = setTimeout(async () => {
            console.log('\x1b[35m[TRIVIA TIMEOUT] ⏰ Tiempo agotado para:', chatId, '\x1b[0m');
            
            const preguntaActiva = preguntasActivas.get(chatId);
            if (preguntaActiva) {
                preguntasActivas.delete(chatId);
                
                try {
                    // Enviar mensaje de tiempo agotado al chat
                    // Usar 'preguntaActiva.message.reply' si tienes acceso directo al método de respuesta
                    // Si no, usa el global.conn para enviar el mensaje
                    await (sock?.sendMessage || preguntaActiva.message.reply)(chatId, {
                        text: `⏰ *¡TIEMPO AGOTADO!*\n\nLa respuesta correcta era: ${preguntaActiva.opciones[preguntaActiva.respuesta]}\n\n💡 Usa .trivia para una nueva pregunta`
                    });
                    console.log('\x1b[35m[TRIVIA TIMEOUT] ✅ Mensaje de tiempo agotado enviado\x1b[0m');
                } catch (error) {
                    console.error('\x1b[31m[TRIVIA TIMEOUT ERROR]', error, '\x1b[0m');
                }
            }
        }, TIEMPO_LIMITE);
        
        console.log('\x1b[33m[TRIVIA] Pregunta guardada con timeout para el chat:', chatId, '\x1b[0m');

    } catch (error) {
        console.error('\x1b[31m[TRIVIA ERROR]', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al generar la pregunta.');
    }
}

// 🆕 HANDLER PARA RESPUESTAS (textReplyHandler)
async function textReplyHandler(message) {
    try {
        const sock = message._sock || message.conn || global.conn;
        if (!sock) {
            console.error('[TRIVIA REPLY] No socket disponible para enviar la respuesta');
            return;
        }

        if (!message.from) return;
        const chatId = message.from;
        const isGroup = chatId.endsWith('@g.us');
        const preguntaActual = preguntasActivas.get(chatId);
        if (!preguntaActual) return;

        if (isGroup && !esCitaValida(message, preguntaActual)) return;

        console.log('\x1b[36m[TRIVIA REPLY] Hay pregunta activa en este chat\x1b[0m');
        console.log('\x1b[36m[TRIVIA REPLY] Procesando respuesta...\x1b[0m');

        // Verificar si el tiempo ha expirado
        const tiempoTranscurrido = Date.now() - preguntaActual.tiempoInicio;
        if (tiempoTranscurrido > TIEMPO_LIMITE) {
            console.log('\x1b[36m[TRIVIA REPLY] Tiempo expirado, ignorando respuesta\x1b[0m');
            return;
        }

        // Obtener el texto de la respuesta
        const respuestaTexto = (message.body || '').trim();
        console.log('\x1b[36m[TRIVIA REPLY] Texto de respuesta:', respuestaTexto, '\x1b[0m');
        
        // Validar que sea solo un número del 1 al 4
        if (!/^[1-4]$/.test(respuestaTexto)) {
            await message.reply('❌ Responde con un número del 1 al 4 citando el mensaje de la pregunta.');
            return;
        }

        const respuesta = parseInt(respuestaTexto) - 1;
        console.log('\x1b[36m[TRIVIA REPLY] Índice de respuesta:', respuesta, '\x1b[0m');

        // Calcular si es correcta
        const esCorrecta = respuesta === preguntaActual.respuesta;
        
        console.log('\x1b[36m[TRIVIA REPLY] ¿Es correcta?:', esCorrecta, '\x1b[0m');
        
        // 💰 Calcular premio basado en tiempo restante
        const tiempoRestanteMs = TIEMPO_LIMITE - tiempoTranscurrido;
        const segundosRestantes = Math.max(0, tiempoRestanteMs / 1000);
        // Asegurar un premio mínimo de 500
        const premio = Math.max(50, Math.floor(segundosRestantes * PREMIO_POR_SEGUNDO));
        
        console.log('\x1b[36m[TRIVIA REPLY] Tiempo restante:', segundosRestantes.toFixed(1), 's | Premio:', premio, '\x1b[0m');
        
        // 💰 Si es correcta, otorgar el premio usando global.db
        if (esCorrecta) {
            try {
                // 1) Obtener ID único del usuario
                const winnerId = message.author || message.from;
                
                // 2) Cargar datos del usuario desde tu base de datos global
                // Usamos global.db.getUser y global.db.setUser como en el código 'daily'
                let winnerUser = global.db.getUser(winnerId); 
                if (!winnerUser) {
                    winnerUser = { money: 0 }; // Inicializar si no existe
                }

                // 3) Actualizar dinero del ganador
                winnerUser.money = Number(winnerUser.money) || 0;
                winnerUser.money += premio;
                
                // 4) Guardar los cambios en la base de datos
                global.db.setUser(winnerId, winnerUser);
                
                console.log('\x1b[36m[TRIVIA REPLY] Premio otorgado:', premio, 'a', winnerId, '\x1b[0m');

                // Nota: El código original usaba 'winnerNumber' y 'extractRealNumber', 
                // lo simplificamos a 'winnerId' para seguir la estructura del 'daily'
                // y mantener la compatibilidad con cómo se guardan los datos.

            } catch (dbError) {
                console.error('\x1b[31m[TRIVIA REPLY DB ERROR]', dbError, '\x1b[0m');
            }
        }
        
        // Crear mensaje de resultado
        const winnerDisplayNumber = (message.author || message.from).split('@')[0];
        const mensaje = esCorrecta 
            ? `🎉 *¡CORRECTO!* @${winnerDisplayNumber}\n\n✅ Respuesta: ${preguntaActual.opciones[preguntaActual.respuesta]}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s\n💰 Premio: $${premio.toLocaleString()}`
            : `❌ *Incorrecto* @${winnerDisplayNumber}\n\n✅ La respuesta correcta era: ${preguntaActual.opciones[preguntaActual.respuesta]}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s`;
        
        // 🆕 Cancelar el timeout ya que respondieron antes
        if (preguntaActual.timeout) {
            clearTimeout(preguntaActual.timeout);
            console.log('\x1b[36m[TRIVIA REPLY] Timeout cancelado (respondieron a tiempo)\x1b[0m');
        }
        
        // Eliminar la pregunta activa
        preguntasActivas.delete(chatId);
        console.log('\x1b[36m[TRIVIA REPLY] Pregunta eliminada, enviando resultado\x1b[0m');
        
        // Enviar resultado con mención
        await sock.sendMessage(chatId, {
            text: mensaje,
            mentions: [message.author || message.from]
        });

    } catch (error) {
        console.error('\x1b[31m[TRIVIA REPLY ERROR]', error, '\x1b[0m');
        console.error('\x1b[31m[TRIVIA REPLY ERROR STACK]', error.stack, '\x1b[0m');
    }
}

module.exports = {
    command: /^(trivia)$/i,
    handler,
    textReplyHandler,
    help: 'Te da una pregunta de trivia para responder.\n• Responde al mensaje del bot con el número de tu respuesta (1-4)\n• Tienes 15 segundos para responder\n• Premio inicial: $7,500 (disminuye $500 por segundo)\n• Usa .trivia reload para recargar las preguntas (solo owner)\n⚠️ Solo funciona en grupos.',
    tags: ['diversion', 'juegos']
};

module.exports.apodo = true;