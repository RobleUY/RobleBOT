const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ── Configuración ───────────────────────────────────────────
// Caché del plugin .bandera (carpeta HERRAMIENTAS/data). Se prueban varias rutas
// por si tu estructura es distinta; ajustá la primera si hace falta.
const CACHE_CANDIDATES = [
    path.join(__dirname, '..', 'HERRAMIENTAS', 'data', 'info-banderas.json'),
    path.join(__dirname, '..', 'herramientas', 'data', 'info-banderas.json'),
    path.join(__dirname, 'data', 'info-banderas.json'),
];

const TIEMPO_LIMITE = 60 * 1000; // 60 s por ronda
const MAX_PISTAS = 3;

// ── Lista de respaldo (por si la caché tiene pocos países) ──
// [código ISO, nombre en español, ...alias]
const PAISES = [
    ['uy', 'Uruguay'], ['ar', 'Argentina'], ['br', 'Brasil', 'Brazil'], ['cl', 'Chile'],
    ['py', 'Paraguay'], ['bo', 'Bolivia'], ['pe', 'Perú', 'Peru'], ['ec', 'Ecuador'],
    ['co', 'Colombia'], ['ve', 'Venezuela'], ['mx', 'México', 'Mexico'], ['gt', 'Guatemala'],
    ['hn', 'Honduras'], ['sv', 'El Salvador'], ['ni', 'Nicaragua'], ['cr', 'Costa Rica'],
    ['pa', 'Panamá', 'Panama'], ['cu', 'Cuba'], ['do', 'República Dominicana', 'Dominicana'],
    ['ht', 'Haití', 'Haiti'], ['jm', 'Jamaica'], ['pr', 'Puerto Rico'],
    ['us', 'Estados Unidos', 'EEUU', 'USA', 'United States'], ['ca', 'Canadá', 'Canada'],
    ['es', 'España', 'Spain'], ['pt', 'Portugal'], ['fr', 'Francia', 'France'],
    ['it', 'Italia', 'Italy'], ['de', 'Alemania', 'Germany'], ['gb', 'Reino Unido', 'Inglaterra', 'United Kingdom', 'UK'],
    ['ie', 'Irlanda', 'Ireland'], ['nl', 'Países Bajos', 'Holanda', 'Netherlands'], ['be', 'Bélgica', 'Belgica', 'Belgium'],
    ['ch', 'Suiza', 'Switzerland'], ['at', 'Austria'], ['se', 'Suecia', 'Sweden'],
    ['no', 'Noruega', 'Norway'], ['dk', 'Dinamarca', 'Denmark'], ['fi', 'Finlandia', 'Finland'],
    ['is', 'Islandia', 'Iceland'], ['pl', 'Polonia', 'Poland'], ['cz', 'Chequia', 'República Checa', 'Czechia'],
    ['sk', 'Eslovaquia', 'Slovakia'], ['hu', 'Hungría', 'Hungria', 'Hungary'], ['ro', 'Rumania', 'Rumanía', 'Romania'],
    ['bg', 'Bulgaria'], ['gr', 'Grecia', 'Greece'], ['tr', 'Turquía', 'Turquia', 'Turkey'],
    ['ua', 'Ucrania', 'Ukraine'], ['ru', 'Rusia', 'Russia'], ['by', 'Bielorrusia', 'Belarus'],
    ['rs', 'Serbia'], ['hr', 'Croacia', 'Croatia'], ['si', 'Eslovenia', 'Slovenia'],
    ['ba', 'Bosnia y Herzegovina', 'Bosnia'], ['al', 'Albania'], ['lt', 'Lituania', 'Lithuania'],
    ['lv', 'Letonia', 'Latvia'], ['ee', 'Estonia'], ['cn', 'China'], ['jp', 'Japón', 'Japon', 'Japan'],
    ['kr', 'Corea del Sur', 'South Korea'], ['kp', 'Corea del Norte', 'North Korea'], ['in', 'India'],
    ['pk', 'Pakistán', 'Pakistan'], ['bd', 'Bangladés', 'Bangladesh'], ['th', 'Tailandia', 'Thailand'],
    ['vn', 'Vietnam'], ['ph', 'Filipinas', 'Philippines'], ['id', 'Indonesia'], ['my', 'Malasia', 'Malaysia'],
    ['sg', 'Singapur', 'Singapore'], ['sa', 'Arabia Saudita', 'Arabia Saudí', 'Saudi Arabia'],
    ['ae', 'Emiratos Árabes Unidos', 'Emiratos Arabes Unidos', 'Emiratos'], ['qa', 'Catar', 'Qatar'],
    ['ir', 'Irán', 'Iran'], ['iq', 'Irak', 'Iraq'], ['il', 'Israel'], ['jo', 'Jordania', 'Jordan'],
    ['lb', 'Líbano', 'Libano', 'Lebanon'], ['eg', 'Egipto', 'Egypt'], ['ma', 'Marruecos', 'Morocco'],
    ['dz', 'Argelia', 'Algeria'], ['tn', 'Túnez', 'Tunez', 'Tunisia'], ['ng', 'Nigeria'],
    ['gh', 'Ghana'], ['sn', 'Senegal'], ['ke', 'Kenia', 'Kenya'], ['et', 'Etiopía', 'Etiopia', 'Ethiopia'],
    ['za', 'Sudáfrica', 'Sudafrica', 'South Africa'], ['au', 'Australia'], ['nz', 'Nueva Zelanda', 'New Zealand'],
];

// ── Utilidades ──────────────────────────────────────────────
function normalizar(s) {
    return String(s || '')
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s]/g, ' ')
        .replace(/\b(la|el|los|las|de|del|republica|reino|estado|estados|the|of|republic)\b/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function levenshtein(a, b) {
    const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
            );
        }
    }
    return dp[a.length][b.length];
}

function coincide(respuesta, aceptadas) {
    const r = normalizar(respuesta);
    if (!r) return false;
    for (const a of aceptadas) {
        if (r === a) return true;
        // tolerancia a una falta de ortografía en nombres largos
        if (a.length >= 6 && r.length >= 5 && levenshtein(r, a) <= 1) return true;
    }
    return false;
}

// ── Pool de banderas (caché + respaldo) ─────────────────────
function cargarCache() {
    for (const file of CACHE_CANDIDATES) {
        try {
            if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
        } catch { /* probar siguiente */ }
    }
    return {};
}

function construirPool() {
    const pool = [];
    const vistos = new Set();

    // 1) Entradas de la caché del .bandera (agrupa las dos claves es/en de cada país)
    const cache = cargarCache();
    const porImagen = new Map();
    for (const [clave, entrada] of Object.entries(cache)) {
        if (!entrada?.imageUrl) continue;
        if (!porImagen.has(entrada.imageUrl)) porImagen.set(entrada.imageUrl, { entrada, claves: new Set() });
        porImagen.get(entrada.imageUrl).claves.add(clave);
    }
    for (const [imageUrl, { entrada, claves }] of porImagen) {
        const oficial = entrada.campos?.officialName || entrada.queryOriginal;
        const aceptadas = new Set();
        for (const c of claves) aceptadas.add(normalizar(c));
        aceptadas.add(normalizar(entrada.queryOriginal));
        aceptadas.add(normalizar(oficial));
        aceptadas.delete('');
        const nombre = entrada.queryOriginal
            ? entrada.queryOriginal.charAt(0).toUpperCase() + entrada.queryOriginal.slice(1)
            : oficial;
        pool.push({ imageUrl, nombre, aceptadas: [...aceptadas], origen: 'cache' });
        for (const a of aceptadas) vistos.add(a);
    }

    // 2) Respaldo (se omiten los países que ya están en la caché)
    for (const [code, nombre, ...alias] of PAISES) {
        const aceptadas = [nombre, ...alias].map(normalizar).filter(Boolean);
        if (aceptadas.some(a => vistos.has(a))) continue;
        pool.push({
            imageUrl: `https://flagcdn.com/w640/${code}.png`,
            nombre,
            aceptadas: [...new Set(aceptadas)],
            origen: 'respaldo',
        });
    }
    return pool;
}

// ── Estado de partidas (una por chat) ───────────────────────
const partidas = new Map();

function elegirBandera() {
    const pool = construirPool();
    if (!pool.length) return null;
    // Prioriza la caché (más rápida) pero deja entrar al respaldo para dar variedad
    const cacheadas = pool.filter(p => p.origen === 'cache');
    const usarCache = cacheadas.length > 0 && Math.random() < 0.7;
    const lista = usarCache ? cacheadas : pool;
    return lista[Math.floor(Math.random() * lista.length)];
}

function pista(partida) {
    const nombre = partida.bandera.nombre;
    partida.pistas++;
    if (partida.pistas === 1) {
        return `💡 *Pista 1:* Empieza con la letra *${nombre[0].toUpperCase()}*`;
    }
    if (partida.pistas === 2) {
        return `💡 *Pista 2:* Tiene *${nombre.replace(/\s/g, '').length}* letras`;
    }
    const mostrar = nombre.split('').map((c, i) => (c === ' ' ? '  ' : (i % 2 === 0 ? c : '_'))).join(' ');
    return `💡 *Pista 3:* ${mostrar}`;
}

// ── Verificar si el mensaje es de un bot ──
function esMensajeDeBot(message) {
    // Verificar si el mensaje es del bot actual
    if (message.fromMe || message.key?.fromMe) return true;
    
    // Verificar si el remitente es alguno de los subbots activos
    if (global.conn?.user?.id) {
        const mainBotId = global.conn.user.id.split('@')[0].split(':')[0];
        const senderId = (message.sender || message.key?.participant || '').split('@')[0].split(':')[0];
        if (senderId === mainBotId) return true;
    }
    
    // Verificar contra subbots
    if (Array.isArray(global.subConns)) {
        for (const subConn of global.subConns) {
            if (subConn?.user?.id) {
                const subBotId = subConn.user.id.split('@')[0].split(':')[0];
                const senderId = (message.sender || message.key?.participant || '').split('@')[0].split(':')[0];
                if (senderId === subBotId) return true;
            }
        }
    }
    
    return false;
}

async function enviarBandera(sock, message, bandera, caption) {
    try {
        const imgRes = await axios.get(bandera.imageUrl, { responseType: 'arraybuffer', timeout: 10000 });
        return await sock.sendMessage(message.from, {
            image: Buffer.from(imgRes.data),
            caption
        }, { quoted: message._baileyMessage });
    } catch {
        try {
            return await sock.sendMessage(message.from, {
                image: { url: bandera.imageUrl },
                caption
            }, { quoted: message._baileyMessage });
        } catch {
            return await message.reply('❌ No se pudo cargar la bandera. Intentá de nuevo con .banderas');
        }
    }
}

function finalizar(chatId) {
    const p = partidas.get(chatId);
    if (p?.timer) clearTimeout(p.timer);
    partidas.delete(chatId);
}

function iniciarTimer(sock, chatId, partida) {
    partida.timer = setTimeout(async () => {
        if (partidas.get(chatId) !== partida) return;
        partidas.delete(chatId);
        try {
            await sock.sendMessage(chatId, {
                text: `⏰ *¡Se acabó el tiempo!*\n\nLa bandera era de: *${partida.bandera.nombre}* 🏳️`
            });
        } catch (e) { console.error('[adivinarbandera] timeout:', e.message); }
    }, TIEMPO_LIMITE);
}

function obtenerTexto(message) {
    return (
        message.body ||
        message.text ||
        message.message?.conversation ||
        message.message?.extendedTextMessage?.text ||
        ''
    );
}

// ── Lógica de acierto (reutilizada por comando y por mensaje libre) ──
async function intentarRespuesta(sock, message, respuesta) {
    const chatId = message.from;
    const partida = partidas.get(chatId);
    if (!partida) return false;

    // Verificar si la respuesta es correcta
    const esCorrecto = coincide(respuesta, partida.bandera.aceptadas);
    
    if (esCorrecto) {
        finalizar(chatId);
        const segundos = ((Date.now() - partida.inicio) / 1000).toFixed(1);
        await message.reply(
            `🎉 *¡Correcto!*\n\n` +
            `🏳️ La bandera era de *${partida.bandera.nombre}*\n` +
            `⏱️ Tiempo: *${segundos}s*\n` +
            `💡 Pistas usadas: *${partida.pistas}*\n\n` +
            `Escribí *.banderas* para jugar otra ronda.`
        );
        return true;
    }
    
    // Si es incorrecto, retornar false para que el handler.before no bloquee otros handlers
    // pero NO enviar mensaje de "incorrecto" aquí para evitar spam de múltiples bots
    return false;
}

// ── Handler (comandos) ──────────────────────────────────────
let handler = async (message, { text, conn }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;
    try {
        const arg = (text || '').trim();
        const argNorm = normalizar(arg);
        const partida = partidas.get(chatId);

        // ── Subcomandos ──
        if (['pista', 'pistas', 'hint', 'ayuda'].includes(argNorm)) {
            if (!partida) return await message.reply('❌ No hay ninguna partida activa. Usá *.banderas* para empezar.');
            if (partida.pistas >= MAX_PISTAS) return await message.reply('🚫 Ya usaste todas las pistas.');
            return await message.reply(pista(partida));
        }

        if (['rendirse', 'rendir', 'skip', 'saltar', 'salir', 'terminar', 'give up'].includes(argNorm)) {
            if (!partida) return await message.reply('❌ No hay ninguna partida activa.');
            finalizar(chatId);
            return await message.reply(`🏳️ Te rendiste. La bandera era de: *${partida.bandera.nombre}*`);
        }

        // ── Respuesta con el comando: .banderas uruguay ──
        if (arg) {
            if (!partida) {
                return await message.reply('❌ No hay ninguna partida activa. Usá *.banderas* para empezar una.');
            }
            
            // Verificar si la respuesta es correcta
            if (coincide(arg, partida.bandera.aceptadas)) {
                finalizar(chatId);
                const segundos = ((Date.now() - partida.inicio) / 1000).toFixed(1);
                await message.reply(
                    `🎉 *¡Correcto!*\n\n` +
                    `🏳️ La bandera era de *${partida.bandera.nombre}*\n` +
                    `⏱️ Tiempo: *${segundos}s*\n` +
                    `💡 Pistas usadas: *${partida.pistas}*\n\n` +
                    `Escribí *.banderas* para jugar otra ronda.`
                );
            } else {
                await message.reply('❌ ¡Incorrecto! Intentá de nuevo o pedí una *.banderas pista*');
            }
            return;
        }

        // ── Sin argumentos: iniciar (o reenviar) partida ──
        if (partida) {
            const restante = Math.max(0, Math.ceil((TIEMPO_LIMITE - (Date.now() - partida.inicio)) / 1000));
            return await enviarBandera(sock, message, partida.bandera,
                `🏳️ *Ya hay una partida en curso*\n\n¿De qué país es esta bandera?\n⏳ Quedan *${restante}s*`);
        }

        const bandera = elegirBandera();
        if (!bandera) return await message.reply('❌ No hay banderas disponibles en este momento.');

        // Guardar información del bot que inicia la partida
        const botId = sock?.user?.id?.split('@')[0].split(':')[0] || 'unknown';
        const nueva = { 
            bandera, 
            inicio: Date.now(), 
            pistas: 0, 
            timer: null,
            iniciadorBotId: botId,  // ID del bot que inició la partida
            mensajeId: null  // Se llenará después de enviar
        };
        partidas.set(chatId, nueva);

        const caption =
            `🏳️ *ADIVINA LA BANDERA*\n\n` +
            `¿De qué país es esta bandera?\n\n` +
            `✍️ Respondé con el *nombre del país* o usá *.banderas <nombre>*\n` +
            `💡 *.banderas pista* · 🏳️ *.banderas rendirse*\n` +
            `⏳ Tenés *${TIEMPO_LIMITE / 1000} segundos*`;

        iniciarTimer(sock, chatId, nueva);
        const sentMsg = await enviarBandera(sock, message, bandera, caption);
        
        // Guardar el ID del mensaje enviado para identificarlo después
        if (sentMsg?.key?.id) {
            nueva.mensajeId = sentMsg.key.id;
        }

    } catch (error) {
        console.error('[adivinarbandera] Error:', error.message);
        await message.reply('❌ Ocurrió un error en el juego. Intentá de nuevo.');
    }
};

// ── Escucha de respuestas sin comando ───────────────────────
// Ajustá la firma/forma de retorno a como lo hacen tus otros juegos de la carpeta JUEGOS.
handler.before = async (message, { conn } = {}) => {
    try {
        const chatId = message.from;
        if (!partidas.has(chatId)) return false;

        const texto = obtenerTexto(message).trim();
        if (!texto || /^[.!/#]/.test(texto)) return false; // los comandos van por el handler normal
        
        // Ignorar mensajes de cualquier bot (propio o subbots)
        if (esMensajeDeBot(message)) return false;

        // Verificar que no sea una respuesta citada al mensaje de la bandera
        // (para evitar que los bots procesen sus propios mensajes de juego)
        const partida = partidas.get(chatId);
        if (partida?.mensajeId) {
            const quotedId = message.message?.extendedTextMessage?.contextInfo?.stanzaId;
            if (quotedId === partida.mensajeId) {
                // Es una respuesta directa al mensaje de la bandera, pero de un bot
                return false;
            }
        }

        const sock = conn || message._sock || global.conn;
        const resultado = await intentarRespuesta(sock, message, texto);
        
        // Si fue correcto, retornar true para que no se procese más
        // Si fue incorrecto, retornar false para permitir que otros handlers lo procesen
        return resultado;
    } catch (e) {
        console.error('[adivinarbandera] before:', e.message);
        return false;
    }
};

handler.help = ['banderas', 'adivinarbandera', 'banderaadivinar', 'abandera'];
handler.tags = ['juegos'];
handler.command = /^(banderas|adivinarbandera|banderaadivinar|abandera)$/i;

module.exports = handler;