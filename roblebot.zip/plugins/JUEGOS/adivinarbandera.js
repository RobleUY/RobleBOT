// 🏳️ Juego: Adivina la Bandera
// Usa la caché del plugin .bandera (HERRAMIENTAS/data/info-banderas.json) para enviar la bandera más rápido
// 💰 Da monedas al ganador (global.db), igual que el juego de Describe los Emojis

const axios = require('axios');
const fs = require('fs');
const path = require('path');

const partidasBandera = new Map();

// ⚙️ Configuración general
const TIEMPO_LIMITE = 30000;      // 30s
const PREMIO_POR_SEGUNDO = 40;
const PREMIO_MAXIMO = (TIEMPO_LIMITE / 1000) * PREMIO_POR_SEGUNDO;
const PREMIO_MINIMO = 200;
const PENALIZACION_PISTA = 0.2;   // cada pista descuenta 20% del premio
const MAX_PISTAS = 3;

// 📦 Caché del plugin .bandera (se prueban varias rutas por si cambia tu estructura)
const CACHE_CANDIDATES = [
    path.join(__dirname, '..', 'HERRAMIENTAS', 'data', 'info-banderas.json'),
    path.join(__dirname, '..', 'herramientas', 'data', 'info-banderas.json'),
    path.join(__dirname, 'data', 'info-banderas.json'),
];

// 🌍 Lista de respaldo: [código ISO, nombre en español, ...alias]
const PAISES = [
    ['uy', 'Uruguay'], ['ar', 'Argentina'], ['br', 'Brasil', 'Brazil'], ['cl', 'Chile'],
    ['py', 'Paraguay'], ['bo', 'Bolivia'], ['pe', 'Perú', 'Peru'], ['ec', 'Ecuador'],
    ['co', 'Colombia'], ['ve', 'Venezuela'], ['mx', 'México', 'Mexico'], ['gt', 'Guatemala'],
    ['hn', 'Honduras'], ['sv', 'El Salvador'], ['ni', 'Nicaragua'], ['cr', 'Costa Rica'],
    ['pa', 'Panamá', 'Panama'], ['cu', 'Cuba'], ['do', 'República Dominicana', 'Dominicana'],
    ['ht', 'Haití', 'Haiti'], ['jm', 'Jamaica'], ['pr', 'Puerto Rico'],
    ['us', 'Estados Unidos', 'EEUU', 'USA', 'United States'], ['ca', 'Canadá', 'Canada'],
    ['es', 'España', 'Spain'], ['pt', 'Portugal'], ['fr', 'Francia', 'France'],
    ['it', 'Italia', 'Italy'], ['de', 'Alemania', 'Germany'], ['gb', 'Reino Unido', 'Inglaterra', 'United Kingdom', 'UK'],
    ['ie', 'Irlanda', 'Ireland'], ['nl', 'Países Bajos', 'Holanda', 'Netherlands'], ['be', 'Bélgica', 'Belgica', 'Belgium'],
    ['ch', 'Suiza', 'Switzerland'], ['at', 'Austria'], ['se', 'Suecia', 'Sweden'],
    ['no', 'Noruega', 'Norway'], ['dk', 'Dinamarca', 'Denmark'], ['fi', 'Finlandia', 'Finland'],
    ['is', 'Islandia', 'Iceland'], ['pl', 'Polonia', 'Poland'], ['cz', 'Chequia', 'República Checa', 'Czechia'],
    ['sk', 'Eslovaquia', 'Slovakia'], ['hu', 'Hungría', 'Hungria', 'Hungary'], ['ro', 'Rumania', 'Rumanía', 'Romania'],
    ['bg', 'Bulgaria'], ['gr', 'Grecia', 'Greece'], ['tr', 'Turquía', 'Turquia', 'Turkey'],
    ['ua', 'Ucrania', 'Ukraine'], ['ru', 'Rusia', 'Russia'], ['by', 'Bielorrusia', 'Belarus'],
    ['rs', 'Serbia'], ['hr', 'Croacia', 'Croatia'], ['si', 'Eslovenia', 'Slovenia'],
    ['ba', 'Bosnia y Herzegovina', 'Bosnia'], ['al', 'Albania'], ['lt', 'Lituania', 'Lithuania'],
    ['lv', 'Letonia', 'Latvia'], ['ee', 'Estonia'], ['cn', 'China'], ['jp', 'Japón', 'Japon', 'Japan'],
    ['kr', 'Corea del Sur', 'South Korea'], ['kp', 'Corea del Norte', 'North Korea'], ['in', 'India'],
    ['pk', 'Pakistán', 'Pakistan'], ['bd', 'Bangladés', 'Bangladesh'], ['th', 'Tailandia', 'Thailand'],
    ['vn', 'Vietnam'], ['ph', 'Filipinas', 'Philippines'], ['id', 'Indonesia'], ['my', 'Malasia', 'Malaysia'],
    ['sg', 'Singapur', 'Singapore'], ['sa', 'Arabia Saudita', 'Arabia Saudí', 'Saudi Arabia'],
    ['ae', 'Emiratos Árabes Unidos', 'Emiratos Arabes Unidos', 'Emiratos'], ['qa', 'Catar', 'Qatar'],
    ['ir', 'Irán', 'Iran'], ['iq', 'Irak', 'Iraq'], ['il', 'Israel'], ['jo', 'Jordania', 'Jordan'],
    ['lb', 'Líbano', 'Libano', 'Lebanon'], ['eg', 'Egipto', 'Egypt'], ['ma', 'Marruecos', 'Morocco'],
    ['dz', 'Argelia', 'Algeria'], ['tn', 'Túnez', 'Tunez', 'Tunisia'], ['ng', 'Nigeria'],
    ['gh', 'Ghana'], ['sn', 'Senegal'], ['ke', 'Kenia', 'Kenya'], ['et', 'Etiopía', 'Etiopia', 'Ethiopia'],
    ['za', 'Sudáfrica', 'Sudafrica', 'South Africa'], ['au', 'Australia'], ['nz', 'Nueva Zelanda', 'New Zealand'],
];

// 🔤 Normalización y comparación de respuestas
function normalizar(s) {
    return String(s || '')
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s]/g, ' ')
        .replace(/\b(la|el|los|las|de|del|republica|reino|estado|estados|the|of|republic)\b/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function levenshtein(a, b) {
    const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
        for (let j = 1; j <= b.length; j++) {
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
            );
        }
    }
    return dp[a.length][b.length];
}

function coincide(respuesta, aceptadas) {
    const r = normalizar(respuesta);
    if (!r) return false;
    for (const a of aceptadas) {
        if (r === a) return true;
        if (a.length >= 6 && r.length >= 5 && levenshtein(r, a) <= 1) return true;
    }
    return false;
}

// 🗂️ Pool de banderas (caché del .bandera + respaldo)
function cargarCache() {
    for (const file of CACHE_CANDIDATES) {
        try {
            if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
        } catch { /* probar siguiente */ }
    }
    return {};
}

function construirPool() {
    const pool = [];
    const vistos = new Set();

    // La caché guarda cada país con dos claves (español e inglés): se agrupan por imagen
    const cache = cargarCache();
    const porImagen = new Map();
    for (const [clave, entrada] of Object.entries(cache)) {
        if (!entrada?.imageUrl) continue;
        if (!porImagen.has(entrada.imageUrl)) porImagen.set(entrada.imageUrl, { entrada, claves: new Set() });
        porImagen.get(entrada.imageUrl).claves.add(clave);
    }
    for (const [imageUrl, { entrada, claves }] of porImagen) {
        const oficial = entrada.campos?.officialName || entrada.queryOriginal;
        const aceptadas = new Set();
        for (const c of claves) aceptadas.add(normalizar(c));
        aceptadas.add(normalizar(entrada.queryOriginal));
        aceptadas.add(normalizar(oficial));
        aceptadas.delete('');
        const base = entrada.queryOriginal || oficial;
        const nombre = base.charAt(0).toUpperCase() + base.slice(1);
        pool.push({ imageUrl, nombre, aceptadas: [...aceptadas], origen: 'cache' });
        for (const a of aceptadas) vistos.add(a);
    }

    for (const [code, nombre, ...alias] of PAISES) {
        const aceptadas = [nombre, ...alias].map(normalizar).filter(Boolean);
        if (aceptadas.some(a => vistos.has(a))) continue;
        pool.push({
            imageUrl: `https://flagcdn.com/w640/${code}.png`,
            nombre,
            aceptadas: [...new Set(aceptadas)],
            origen: 'respaldo',
        });
    }
    return pool;
}

function elegirBandera() {
    const pool = construirPool();
    if (!pool.length) return null;
    const cacheadas = pool.filter(p => p.origen === 'cache');
    const usarCache = cacheadas.length > 0 && Math.random() < 0.7;
    const lista = usarCache ? cacheadas : pool;
    return lista[Math.floor(Math.random() * lista.length)];
}

// 💡 Pistas
function generarPista(partida) {
    const nombre = partida.bandera.nombre;
    partida.pistas++;
    if (partida.pistas === 1) return `💡 *Pista 1:* Empieza con la letra *${nombre[0].toUpperCase()}*`;
    if (partida.pistas === 2) return `💡 *Pista 2:* Tiene *${nombre.replace(/\s/g, '').length}* letras`;
    const mostrar = nombre.split('').map((c, i) => (c === ' ' ? '  ' : (i % 2 === 0 ? c : '_'))).join(' ');
    return `💡 *Pista 3:* ${mostrar}`;
}

// 🔌 Obtener el socket activo (compatible con subbots)
function getSock(message) {
    if (message?._sock?.user) return message._sock;
    if (message?.conn?.user) return message.conn;
    if (global.conn?.user) return global.conn;
    if (Array.isArray(global.subConns)) {
        const active = global.subConns.find(c => c?.user);
        if (active) return active;
    }
    return message?._sock || global.conn;
}

// 🖼️ Enviar la bandera (devuelve el mensaje enviado para poder detectar las citas)
async function enviarBandera(sock, message, bandera, caption) {
    const opciones = { quoted: message._baileyMessage };
    try {
        const imgRes = await axios.get(bandera.imageUrl, { responseType: 'arraybuffer', timeout: 10000 });
        return await sock.sendMessage(message.from, { image: Buffer.from(imgRes.data), caption }, opciones);
    } catch {
        try {
            return await sock.sendMessage(message.from, { image: { url: bandera.imageUrl }, caption }, opciones);
        } catch {
            return null;
        }
    }
}

// 💰 Premio según el tiempo restante y las pistas usadas
function calcularPremio(partida, tiempoTranscurrido) {
    const restante = Math.max(0, (TIEMPO_LIMITE - tiempoTranscurrido) / 1000);
    let premio = Math.floor(restante * PREMIO_POR_SEGUNDO);
    premio = Math.floor(premio * (1 - PENALIZACION_PISTA * partida.pistas));
    return Math.max(PREMIO_MINIMO, premio);
}

function pagarGanador(winnerJid, premio) {
    try {
        let user = global.db.getUser(winnerJid);
        if (!user) user = { money: 0 };
        user.money = Number(user.money) || 0;
        user.money += premio;
        global.db.setUser(winnerJid, user);
    } catch (e) {
        console.error('\x1b[31m[BANDERA DB ERROR]\x1b[0m', e.message);
    }
}

// ✅ Resolver un intento de respuesta (lo usan el comando y las respuestas citadas)
async function resolverIntento(message, respuesta) {
    const chatId = message.from;
    const partida = partidasBandera.get(chatId);
    if (!partida) return;

    const tiempoTranscurrido = Date.now() - partida.tiempoInicio;
    if (tiempoTranscurrido > TIEMPO_LIMITE) return;

    if (!coincide(respuesta, partida.bandera.aceptadas)) {
        return await message.reply('❌ ¡Incorrecto! Intentá de nuevo o pedí una *.banderas pista*');
    }

    clearTimeout(partida.timeout);
    partidasBandera.delete(chatId);

    const winnerJid = message.author || message.from;
    const premio = calcularPremio(partida, tiempoTranscurrido);
    pagarGanador(winnerJid, premio);

    const ganador = winnerJid.split('@')[0];
    await message.reply(
        `✅ *¡Correcto!* @${ganador}\n\n🏳️ La bandera era de: *${partida.bandera.nombre}*\n\n` +
        `💰 Premio: $${premio.toLocaleString()}\n⏱️ Tiempo: ${(tiempoTranscurrido / 1000).toFixed(1)}s` +
        (partida.pistas ? `\n💡 Pistas usadas: ${partida.pistas}` : '') +
        `\n\nUsá *.banderas* para jugar otra vez.`,
        { mentions: [winnerJid] }
    );
}

// 🎮 Comando principal
async function handler(message, { text, conn }) {
    try {
        const sock = conn || getSock(message);
        const chatId = message.from;
        const arg = (text || '').trim();
        const argNorm = normalizar(arg);
        const partida = partidasBandera.get(chatId);

        // Subcomandos
        if (['pista', 'pistas', 'hint', 'ayuda'].includes(argNorm)) {
            if (!partida) return await message.reply('❌ No hay ninguna partida activa. Usá *.banderas* para empezar.');
            if (partida.pistas >= MAX_PISTAS) return await message.reply('🚫 Ya usaste todas las pistas.');
            return await message.reply(generarPista(partida));
        }

        if (['rendirse', 'rendir', 'skip', 'saltar', 'salir', 'terminar'].includes(argNorm)) {
            if (!partida) return await message.reply('❌ No hay ninguna partida activa.');
            clearTimeout(partida.timeout);
            partidasBandera.delete(chatId);
            return await message.reply(`🏳️ Partida terminada. La bandera era de: *${partida.bandera.nombre}*`);
        }

        // Respuesta con el comando: .banderas uruguay
        if (arg) {
            if (!partida) return await message.reply('❌ No hay ninguna partida activa. Usá *.banderas* para empezar una.');
            return await resolverIntento(message, arg);
        }

        if (partida) return await message.reply('⚠️ Ya hay una partida activa. Espera a que termine.');

        // Nueva partida
        const bandera = elegirBandera();
        if (!bandera) return await message.reply('❌ No hay banderas disponibles en este momento.');

        const caption =
            `🏳️ *JUEGO: Adivina la bandera*\n\n` +
            `🌍 ¿De qué país es esta bandera?\n\n` +
            `💬 *Cita (responde) este mensaje* con el nombre del país\n` +
            `o usá *.banderas <país>*\n` +
            `💡 *.banderas pista* · 🏳️ *.banderas rendirse*\n` +
            `⏱️ Tiempo: ${TIEMPO_LIMITE / 1000}s\n💰 Premio máximo: $${PREMIO_MAXIMO.toLocaleString()}`;

        const botMsg = await enviarBandera(sock, message, bandera, caption);
        if (!botMsg) return await message.reply('❌ No se pudo cargar la bandera. Intentá de nuevo con *.banderas*');
        const botMsgId = botMsg?.key?.id || botMsg?.id || null;

        const nueva = {
            bandera,
            tiempoInicio: Date.now(),
            pistas: 0,
            timeout: null,
            messageInicial: message,
            botMsgId,
        };
        partidasBandera.set(chatId, nueva);

        nueva.timeout = setTimeout(async () => {
            const activa = partidasBandera.get(chatId);
            if (!activa) return;
            partidasBandera.delete(chatId);
            await activa.messageInicial.reply(`⏰ *¡Tiempo agotado!*\n\nLa bandera era de:\n👉 *${activa.bandera.nombre}*\n\nUsá *.banderas* para jugar otra vez.`);
        }, TIEMPO_LIMITE);
    } catch (err) {
        console.error('[BANDERA ERROR]', err);
        await message.reply('❌ Ocurrió un error al iniciar el juego.');
    }
}

// 🤖 Verificar si un JID pertenece a algún bot del sistema
function isBotJid(jid, message) {
    if (!jid) return false;
    const candidates = [];
    const currentSock = getSock(message);
    if (currentSock?.user) {
        if (currentSock.user.id) candidates.push(currentSock.user.id);
        if (currentSock.user.jid) candidates.push(currentSock.user.jid);
    }
    if (global.conn?.user) {
        if (global.conn.user.id) candidates.push(global.conn.user.id);
        if (global.conn.user.jid) candidates.push(global.conn.user.jid);
    }
    if (Array.isArray(global.subConns)) {
        for (const sc of global.subConns) {
            if (sc?.user) {
                if (sc.user.id) candidates.push(sc.user.id);
                if (sc.user.jid) candidates.push(sc.user.jid);
            }
        }
    }
    return candidates.some(bJid => bJid && mismoNumero(bJid, jid));
}

// 📞 Comparar JIDs normalizando el número de teléfono
function mismoNumero(jidA, jidB) {
    if (!jidA || !jidB) return false;
    const limpia = j => String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
    const a = limpia(jidA);
    const b = limpia(jidB);
    if (!a || !b) return false;
    if (a === b) return true;
    const norm = n => n.startsWith('549') ? '54' + n.slice(3) : n;
    if (norm(a) === norm(b)) return true;
    if (a.length >= 8 && b.length >= 8 && (a.endsWith(b) || b.endsWith(a))) return true;
    return false;
}

function obtenerQuotedInfo(message) {
    const baileyMsg = message._baileyMessage;
    const allCtx = [
        baileyMsg?.message?.contextInfo,
        baileyMsg?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.buttonsResponseMessage?.contextInfo,
        baileyMsg?.message?.listResponseMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo,
        baileyMsg?.message?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo,
        baileyMsg?.message?.interactiveResponseMessage?.contextInfo,
        baileyMsg?.message?.templateButtonReplyMessage?.contextInfo,
    ];
    const ctx = allCtx.find(c => c && (c.stanzaId || c.quotedMessage || c.participant)) || null;

    const quotedId = message.quoted?.key?.id
        || message.quoted?.id
        || message._data?.quotedMsg?.key?.id
        || message._data?.quotedMsg?.id
        || ctx?.quotedMessage?.key?.id
        || ctx?.quotedMessage?.id
        || ctx?.stanzaId
        || null;

    const quotedSender = message.quoted?.key?.participant
        || message.quoted?.sender
        || message._data?.quotedMsg?.sender
        || ctx?.participant
        || null;

    const quotedMsgObj = ctx?.quotedMessage || message._data?.quotedMsg || null;
    let quotedText = '';
    if (quotedMsgObj) {
        quotedText = quotedMsgObj.conversation
            || quotedMsgObj.extendedTextMessage?.text
            || quotedMsgObj.extendedTextMessageV2?.text
            || quotedMsgObj.imageMessage?.caption
            || quotedMsgObj.videoMessage?.caption
            || '';
    }

    const isFromMe = !!(message.quoted?.key?.fromMe || ctx?.isFromMe || (quotedSender && isBotJid(quotedSender, message)));

    return {
        quotedId,
        quotedSender,
        quotedText,
        isFromMe,
        hasQuote: !!(quotedId || quotedSender || quotedText || message.quoted)
    };
}

function esCitaValida(message, partida) {
    const isGroup = message.from?.endsWith('@g.us');
    if (message.key?.fromMe) return true;
    if (!isGroup) return true;

    const qInfo = obtenerQuotedInfo(message);
    if (!qInfo.hasQuote) return false;

    if (partida.botMsgId && qInfo.quotedId && qInfo.quotedId === partida.botMsgId) return true;
    if (qInfo.quotedText && /adivina la bandera/i.test(qInfo.quotedText)) return true;
    if (qInfo.isFromMe || isBotJid(qInfo.quotedSender, message)) return true;

    return false;
}

// 💬 Manejador de respuestas (citando el mensaje del bot)
async function textReplyHandler(message) {
    try {
        if (!message.from) return;
        const chatId = message.from;
        const isGroup = chatId.endsWith('@g.us');
        const partida = partidasBandera.get(chatId);
        if (!partida) return;

        if (isGroup && !esCitaValida(message, partida)) return;

        const respuestaJugador = message.body?.trim();
        if (!respuestaJugador) return;
        if (/^[.!/#]/.test(respuestaJugador)) return; // los comandos van por el handler

        await resolverIntento(message, respuestaJugador);
    } catch (err) {
        console.error('[BANDERA REPLY ERROR]', err);
    }
}

// 📦 Exportación del comando
module.exports = {
    command: /^(banderas|adivinarbandera|banderaadivinar|abandera)$/i,
    handler,
    textReplyHandler,
    help: '🏳️ Juego de adivinar la bandera.\n• Escribe .banderas para comenzar.\n• Cita el mensaje del bot con el nombre del país, o usa .banderas <país>.\n• .banderas pista / .banderas rendirse\n• 30 segundos por ronda.\n• ¡Gana dinero virtual si aciertas rápido!',
    tags: ['diversion', 'juegos'],
};

module.exports.group = true;