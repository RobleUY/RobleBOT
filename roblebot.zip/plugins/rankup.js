const db = require('../database.js');
const premium = require('../premium');

// Cache de imágenes de rangos para no llamar la API en cada mensaje
let rangosImagenesCache = null;
let rangosImagenesCacheTime = 0;
const CACHE_TTL = 10 * 60 * 1000; // 10 minutos

async function getRangosImagenes() {
  const ahora = Date.now();
  if (rangosImagenesCache && (ahora - rangosImagenesCacheTime) < CACHE_TTL) {
    return rangosImagenesCache;
  }
  try {
    const res = await fetch('https://roblebot-rangos-imagenes.vercel.app/api/rangos');
    if (!res.ok) return null;
    const data = await res.json();
    rangosImagenesCache = data.rangos || [];
    rangosImagenesCacheTime = ahora;
    return rangosImagenesCache;
  } catch (e) {
    console.error('[rankup] Error al obtener imágenes de rangos:', e.message);
    return rangosImagenesCache || null;
  }
}

// Limpia el nombre del rango (quita emojis y espacios extra) para comparar con la API
function limpiarNombreRango(nombre) {
  return nombre
    .replace(/[\u{1F300}-\u{1FFFF}\u{2600}-\u{27BF}]/gu, '')
    .replace(/[^\x20-\x7E\u00C0-\u024F]/g, '')
    .trim();
}

async function getImagenUrlRango(nombreRango) {
  const rangos = await getRangosImagenes();
  if (!rangos) return null;
  const nombreLimpio = limpiarNombreRango(nombreRango).toLowerCase();
  const encontrado = rangos.find(r => r.nombre.toLowerCase() === nombreLimpio);
  return encontrado ? encontrado.imagen_url : null;
}

const RANGOS = [
  { nombre: '🌱 Novato', precio: 0 },
  { nombre: '🪶 Aprendiz', precio: 1000000 },
  { nombre: '🪵 Recluta', precio: 2000000 },
  { nombre: '🔰 Principiante', precio: 3000000 },
  { nombre: '⚙️ Obrero', precio: 4000000 },
  { nombre: '🛠️ Artesano', precio: 5000000 },
  { nombre: '🗡️ Combatiente', precio: 6000000 },
  { nombre: '⚔️ Guerrero', precio: 7000000 },
  { nombre: '🛡️ Defensor', precio: 8000000 },
  { nombre: '🎯 Experto', precio: 9000000 },

  { nombre: '🏹 Veterano', precio: 10000000 },
  { nombre: '🔥 Conquistador', precio: 11000000 },
  { nombre: '🦾 Maestro', precio: 12000000 },
  { nombre: '🥇 Maestro Avanzado', precio: 13000000 },
  { nombre: '💎 Élite', precio: 14000000 },
  { nombre: '💠 Élite Superior', precio: 15000000 },
  { nombre: '🏆 Campeón', precio: 16000000 },
  { nombre: '👑 Gran Campeón', precio: 17000000 },
  { nombre: '🦅 Águila Imperial', precio: 18000000 },
  { nombre: '🐺 Alfa', precio: 19000000 },

  { nombre: '🦁 Titán', precio: 20000000 },
  { nombre: '⚡ Señor de Guerra', precio: 21000000 },
  { nombre: '🐉 Dragón', precio: 22000000 },
  { nombre: '🐲 Dragón Antiguo', precio: 23000000 },
  { nombre: '🔥 Fénix', precio: 24000000 },
  { nombre: '🌋 Fénix Eterno', precio: 25000000 },
  { nombre: '💀 Espectro', precio: 26000000 },
  { nombre: '👻 Fantasma Supremo', precio: 27000000 },
  { nombre: '☠️ Segador', precio: 28000000 },
  { nombre: '🩸 Ángel Caído', precio: 29000000 },

  { nombre: '🕊️ Redentor', precio: 30000000 },
  { nombre: '🌕 Guardián Lunar', precio: 31000000 },
  { nombre: '☀️ Guardián Solar', precio: 32000000 },
  { nombre: '🌠 Guardián Estelar', precio: 33000000 },
  { nombre: '🌌 Guardián Galáctico', precio: 34000000 },
  { nombre: '🪐 Guardián Cósmico', precio: 35000000 },
  { nombre: '⚜️ Noble Supremo', precio: 36000000 },
  { nombre: '🏛️ Gran Noble', precio: 37000000 },
  { nombre: '🧠 Sabio', precio: 38000000 },
  { nombre: '📜 Gran Sabio', precio: 39000000 },

  { nombre: '🔮 Oráculo', precio: 40000000 },
  { nombre: '✨ Místico', precio: 41000000 },
  { nombre: '🌟 Ascendido', precio: 42000000 },
  { nombre: '🌈 Celestial', precio: 43000000 },
  { nombre: '🌠 Celestial Mayor', precio: 44000000 },
  { nombre: '⚡ Divino', precio: 45000000 },
  { nombre: '🙏 Elegido Divino', precio: 46000000 },
  { nombre: '💫 Semidiós', precio: 47000000 },
  { nombre: '👼 Arcángel', precio: 48000000 },
  { nombre: '👼 Arcángel Supremo', precio: 49000000 },

  { nombre: '🌌 Ser Divino', precio: 50000000 },
  { nombre: '💫 Dios Menor', precio: 51000000 },
  { nombre: '💫 Dios', precio: 52000000 },
  { nombre: '💫 Dios Supremo', precio: 53000000 },
  { nombre: '🌠 Inmortal', precio: 54000000 },
  { nombre: '♾️ Inmortal Supremo', precio: 55000000 },
  { nombre: '🌍 Dominador', precio: 56000000 },
  { nombre: '🌎 Dominador Mundial', precio: 57000000 },
  { nombre: '🌐 Dominador Universal', precio: 58000000 },
  { nombre: '🚀 Conquistador Estelar', precio: 59000000 },

  { nombre: '🪐 Cósmico', precio: 60000000 },
  { nombre: '🌌 Cósmico Superior', precio: 61000000 },
  { nombre: '🌌 Señor Galáctico', precio: 62000000 },
  { nombre: '🌌 Emperador Galáctico', precio: 63000000 },
  { nombre: '🛸 Soberano Estelar', precio: 64000000 },
  { nombre: '🌠 Emperador Estelar', precio: 65000000 },
  { nombre: '🌌 Entidad Suprema', precio: 66000000 },
  { nombre: '🧬 Dios Universal', precio: 67000000 },
  { nombre: '🧬 Dios Multiversal', precio: 68000000 },
  { nombre: '♾️ Entidad Multiversal', precio: 69000000 },

  { nombre: '🌌 Arquitecto Cósmico', precio: 70000000 },
  { nombre: '⚛️ Forjador Universal', precio: 71000000 },
  { nombre: '🪐 Creador Estelar', precio: 72000000 },
  { nombre: '🌠 Creador Galáctico', precio: 73000000 },
  { nombre: '🌌 Creador Universal', precio: 74000000 },
  { nombre: '✨ Ser Primordial', precio: 75000000 },
  { nombre: '🔥 Primordial Supremo', precio: 76000000 },
  { nombre: '🌟 Eterno', precio: 77000000 },
  { nombre: '♾️ Eterno Supremo', precio: 78000000 },
  { nombre: '🌌 Trascendente', precio: 79000000 },

  { nombre: '🚪 Trascendente Mayor', precio: 80000000 },
  { nombre: '🌠 Ser Absoluto', precio: 81000000 },
  { nombre: '👁️ Vigilante Eterno', precio: 82000000 },
  { nombre: '⚜️ Rey del Cosmos', precio: 83000000 },
  { nombre: '👑 Emperador del Cosmos', precio: 84000000 },
  { nombre: '🌌 Soberano Absoluto', precio: 85000000 },
  { nombre: '♾️ Amo del Tiempo', precio: 86000000 },
  { nombre: '🌀 Amo del Espacio', precio: 87000000 },
  { nombre: '⚛️ Amo de la Realidad', precio: 88000000 },
  { nombre: '🌌 Amo de las Dimensiones', precio: 89000000 },

  { nombre: '💠 Nexus Universal', precio: 90000000 },
  { nombre: '🌠 Nexus Multiversal', precio: 91000000 },
  { nombre: '♾️ Entidad Eterna', precio: 92000000 },
  { nombre: '✨ Entidad Absoluta', precio: 93000000 },
  { nombre: '🌌 Alfa Universal', precio: 94000000 },
  { nombre: '🌌 Omega Universal', precio: 95000000 },
  { nombre: '🌟 Alfa Omega', precio: 96000000 },
  { nombre: '⚜️ Deidad Suprema', precio: 97000000 },
  { nombre: '👑 Rey de Reyes', precio: 49000000 },
  { nombre: '👑 Legends Team', precio: 49500000 }
];

function getMaxRango() {
  return RANGOS[RANGOS.length - 1].nombre;
}

let handler = async (message, { args, command, conn }) => {
  try {
    const sock = conn || message._sock || global.conn;
    const senderJid = message?.key?.participant || message?.key?.remoteJid;
    const number = senderJid.split('@')[0];
    let user = db.getUser(number);
    if (!user) return await message.reply('❌ No se encontraron tus datos.');

    const isUserPremium = premium.isPremium(senderJid) || premium.isPremium(number);

    const rangoActual = user.rango || '🌱 Novato';
    const indexActual = RANGOS.findIndex(r => r.nombre === rangoActual);
    const siguiente = RANGOS[indexActual + 1];
    const dinero = user.money || 0;

    // -----------------------------
    // 🔹 .rank → muestra rango y progreso
    // -----------------------------
    if (command === 'rank') {
      let msg = `🏅 Tu rango actual: ${rangoActual}\n`;

      if (isUserPremium) {
        msg += `⭐ *Estado:* Usuario Premium activo\n`;
      }

      if (siguiente) {
        const falta = siguiente.precio - dinero;
        const puedeSubir = falta <= 0;
        const emoji = puedeSubir ? '✅' : '❌';
        const textoFalta = puedeSubir
          ? '¡Tienes suficiente dinero para subir de rango!'
          : `Te faltan ${falta.toLocaleString()} monedas.`;
        msg += `➡️ Próximo rango: ${siguiente.nombre}\n`;
        msg += `💰 Precio: ${siguiente.precio.toLocaleString()} monedas\n`;
        msg += `${emoji} ${textoFalta}`;
      } else {
        msg += `🏆 ¡Ya alcanzaste el rango máximo!`;
      }

      // Enviar con imagen del rango actual si está disponible
      const chatId = message.from || message.key?.remoteJid;
      const quotedMessage = message._baileyMessage || message.baileyMessage || message;
      const imagenUrl = await getImagenUrlRango(rangoActual);

      if (imagenUrl && sock) {
        try {
          await sock.sendMessage(
            chatId,
            { image: { url: imagenUrl }, caption: msg },
            { quoted: quotedMessage }
          );
          return;
        } catch (imgErr) {
          console.error('[rankup] Error al enviar imagen en .rank:', imgErr.message);
        }
      }
      return await message.reply(msg);
    }

    // -----------------------------
    // 🔹 .rankup → sube de rango
    // 🔹 .rankup all → sube todos los rangos posibles según el dinero disponible
    // -----------------------------
    if (command === 'rankup') {
      const esAll = args[0] && args[0].toLowerCase() === 'all';

      // -----------------------------
      // 🔸 .rankup all
      // -----------------------------
      if (esAll) {
        if (!siguiente)
          return await message.reply('🏆 Ya estás en el rango máximo.');

        if (dinero < siguiente.precio)
          return await message.reply(
            `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
          );

        let indexIter = indexActual;
        let dineroRestante = dinero;
        let rangosGanados = 0;
        let costoTotal = 0;
        const rangoInicial = rangoActual;

        while (indexIter < RANGOS.length - 1) {
          const proximo = RANGOS[indexIter + 1];
          if (dineroRestante < proximo.precio) break;
          dineroRestante -= proximo.precio;
          costoTotal += proximo.precio;
          indexIter++;
          rangosGanados++;
        }

        if (rangosGanados === 0)
          return await message.reply(
            `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
          );

        const rangoFinal = RANGOS[indexIter];
        const respetoGanado = rangosGanados * 5;

        user.money = dineroRestante;
        user.rango = rangoFinal.nombre;
        user.respeto = (user.respeto || 0) + respetoGanado;
        db.setUser(number, user);

        const msgRankupAll =
          `🎉 ¡Felicidades!\n\n` +
          `📈 Subiste *${rangosGanados}* rango${rangosGanados > 1 ? 's' : ''} de golpe.\n` +
          `🏅 Rango anterior: ${rangoInicial}\n` +
          `🏅 Rango actual: *${rangoFinal.nombre}*\n` +
          `💵 Coste total: ${costoTotal.toLocaleString()} monedas\n` +
          `💰 Monedas restantes: ${dineroRestante.toLocaleString()}\n` +
          `💪 Has ganado +${respetoGanado} Respeto por tu avance.`;

        const chatIdAll = message.from || message.key?.remoteJid;
        const quotedAll = message._baileyMessage || message.baileyMessage || message;
        const imagenAll = await getImagenUrlRango(rangoFinal.nombre);

        if (imagenAll && sock) {
          try {
            await sock.sendMessage(
              chatIdAll,
              { image: { url: imagenAll }, caption: msgRankupAll },
              { quoted: quotedAll }
            );
            return;
          } catch (imgErr) {
            console.error('[rankup] Error al enviar imagen en .rankup all:', imgErr.message);
          }
        }
        return await message.reply(msgRankupAll);
      }

      // -----------------------------
      // 🔸 .rankup (normal, un solo rango)
      // -----------------------------
      if (!siguiente)
        return await message.reply('🏆 Ya estás en el rango máximo.');

      if (dinero < siguiente.precio)
        return await message.reply(
          `❌ Te faltan ${(siguiente.precio - dinero).toLocaleString()} monedas para subir a ${siguiente.nombre}.`
        );

      // Actualizar usuario
      user.money -= siguiente.precio;
      user.rango = siguiente.nombre;
      user.respeto = (user.respeto || 0) + 5;
      db.setUser(number, user);

      const msgRankup =
        `🎉 ¡Felicidades!\n\n` +
        `🏅 Ascendiste a: *${siguiente.nombre}*\n` +
        `💵 Coste: ${siguiente.precio.toLocaleString()} monedas\n` +
        `💪 Has ganado +5 Respeto por tu avance.`;

      // Enviar con imagen del nuevo rango si está disponible
      const chatIdRankup = message.from || message.key?.remoteJid;
      const quotedRankup = message._baileyMessage || message.baileyMessage || message;
      const imagenRankup = await getImagenUrlRango(siguiente.nombre);

      if (imagenRankup && sock) {
        try {
          await sock.sendMessage(
            chatIdRankup,
            { image: { url: imagenRankup }, caption: msgRankup },
            { quoted: quotedRankup }
          );
          return;
        } catch (imgErr) {
          console.error('[rankup] Error al enviar imagen en .rankup:', imgErr.message);
        }
      }
      return await message.reply(msgRankup);
    }

    // -----------------------------
    // 🔹 .ranks → lista completa
    // -----------------------------
    if (command === 'ranks') {
      let texto = '🏆 *Lista de Rangos y Precios*\n\n';
      for (let i = 0; i < RANGOS.length; i++) {
        let actual = RANGOS[i];
        texto += `${i + 1}. ${actual.nombre} — 💰 ${actual.precio.toLocaleString()}\n`;
      }
      texto += `\nUsa *.rankup* para subir de rango.`;
      return await message.reply(texto);
    }

  } catch (err) {
    console.error('Error en comando rank:', err);
    await message.reply('❌ Error al ejecutar el comando de rangos.');
  }
};

handler.help = ['rank', 'rankup [all]', 'ranks'];
handler.tags = ['rpg', 'usuarios', 'economía'];
handler.command = /^(rank|rankup|ranks)$/i;
handler.group = true;

function getSiguienteRango(rangoActual) {
  const idx = RANGOS.findIndex(r => r.nombre === rangoActual);
  if (idx === -1 || idx >= RANGOS.length - 1) return null;
  return RANGOS[idx + 1];
}

handler.RANGOS = RANGOS;
handler.getMaxRango = getMaxRango;
handler.getSiguienteRango = getSiguienteRango;
handler.apodo = true;

module.exports = handler;
module.exports.RANGOS = RANGOS;
module.exports.getMaxRango = getMaxRango;
module.exports.getSiguienteRango = getSiguienteRango;