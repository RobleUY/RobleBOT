'use strict';

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * PLUGIN DE CUMPLEAÑOS
 * ═══════════════════════════════════════════════════════════════════════════════
 * Comandos:
 *  - .micumple <día> <mes> <país>    -> Registra tu cumpleaños en este grupo
 *  - .micumple test                  -> Prueba de felicitación (solo owner)
 *  - .cumpleaños                     -> Lista ordenada de los cumpleaños del grupo
 *  - .cumpleaños @user               -> Información del cumpleaños del usuario
 *  - .cumpleaños set @user <día> <mes> <país> -> Configurar cumpleaños de un usuario (admin/owner)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const fs = require('fs');
const path = require('path');
const birthdayScheduler = require('../../lib/birthdayScheduler');
const botConfig = require('../../config');

const executedMessages = new Set();

// Mapa de países y sus zonas horarias IANA principales
const COUNTRY_TIMEZONES = {
    'uruguay': { tz: 'America/Montevideo', flag: '🇺🇾', name: 'Uruguay' },
    'argentina': { tz: 'America/Argentina/Buenos_Aires', flag: '🇦🇷', name: 'Argentina' },
    'colombia': { tz: 'America/Bogota', flag: '🇨🇴', name: 'Colombia' },
    'mexico': { tz: 'America/Mexico_City', flag: '🇲🇽', name: 'México' },
    'chile': { tz: 'America/Santiago', flag: '🇨🇱', name: 'Chile' },
    'peru': { tz: 'America/Lima', flag: '🇵🇪', name: 'Perú' },
    'venezuela': { tz: 'America/Caracas', flag: '🇻🇪', name: 'Venezuela' },
    'espana': { tz: 'Europe/Madrid', flag: '🇪🇸', name: 'España' },
    'españa': { tz: 'Europe/Madrid', flag: '🇪🇸', name: 'España' },
    'ecuador': { tz: 'America/Guayaquil', flag: '🇪🇨', name: 'Ecuador' },
    'bolivia': { tz: 'America/La_Paz', flag: '🇧🇴', name: 'Bolivia' },
    'paraguay': { tz: 'America/Asuncion', flag: '🇵🇾', name: 'Paraguay' },
    'guatemala': { tz: 'America/Guatemala', flag: '🇬🇹', name: 'Guatemala' },
    'cuba': { tz: 'America/Havana', flag: '🇨🇺', name: 'Cuba' },
    'republica dominicana': { tz: 'America/Santo_Domingo', flag: '🇩🇴', name: 'República Dominicana' },
    'dominicana': { tz: 'America/Santo_Domingo', flag: '🇩🇴', name: 'República Dominicana' },
    'honduras': { tz: 'America/Tegucigalpa', flag: '🇭🇳', name: 'Honduras' },
    'el salvador': { tz: 'America/El_Salvador', flag: '🇸🇻', name: 'El Salvador' },
    'salvador': { tz: 'America/El_Salvador', flag: '🇸🇻', name: 'El Salvador' },
    'nicaragua': { tz: 'America/Managua', flag: '🇳🇮', name: 'Nicaragua' },
    'costa rica': { tz: 'America/Costa_Rica', flag: '🇨🇷', name: 'Costa Rica' },
    'panama': { tz: 'America/Panama', flag: '🇵🇦', name: 'Panamá' },
    'puerto rico': { tz: 'America/Puerto_Rico', flag: '🇵🇷', name: 'Puerto Rico' },
    'estados unidos': { tz: 'America/New_York', flag: '🇺🇸', name: 'Estados Unidos' },
    'usa': { tz: 'America/New_York', flag: '🇺🇸', name: 'USA' },
    'eeuu': { tz: 'America/New_York', flag: '🇺🇸', name: 'EE.UU.' },
    'brasil': { tz: 'America/Sao_Paulo', flag: '🇧🇷', name: 'Brasil' },
    'brazil': { tz: 'America/Sao_Paulo', flag: '🇧🇷', name: 'Brasil' },
    'italia': { tz: 'Europe/Rome', flag: '🇮🇹', name: 'Italia' },
    'portugal': { tz: 'Europe/Lisbon', flag: '🇵🇹', name: 'Portugal' },
    'francia': { tz: 'Europe/Paris', flag: '🇫🇷', name: 'Francia' },
    'alemania': { tz: 'Europe/Berlin', flag: '🇩🇪', name: 'Alemania' },
    'reino unido': { tz: 'Europe/London', flag: '🇬🇧', name: 'Reino Unido' },
    'inglaterra': { tz: 'Europe/London', flag: '🇬🇧', name: 'Inglaterra' }
};

const MONTH_NAMES = {
    'enero': 1, 'ene': 1, '1': 1, '01': 1,
    'febrero': 2, 'feb': 2, '2': 2, '02': 2,
    'marzo': 3, 'mar': 3, '3': 3, '03': 3,
    'abril': 4, 'abr': 4, '4': 4, '04': 4,
    'mayo': 5, 'may': 5, '5': 5, '05': 5,
    'junio': 6, 'jun': 6, '6': 6, '06': 6,
    'julio': 7, 'jul': 7, '7': 7, '07': 7,
    'agosto': 8, 'ago': 8, '8': 8, '08': 8,
    'septiembre': 9, 'sep': 9, 'setiembre': 9, 'set': 9, '9': 9, '09': 9,
    'octubre': 10, 'oct': 10, '10': 10,
    'noviembre': 11, 'nov': 11, '11': 11,
    'diciembre': 12, 'dic': 12, '12': 12
};

const MONTH_STRINGS = [
    '', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

function normalizeText(text) {
    if (!text) return '';
    return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function cleanDigits(val) {
    if (!val) return '';
    return String(val).split('@')[0].split(':')[0].replace(/\D/g, '');
}

function resolveCountry(countryInput) {
    const norm = normalizeText(countryInput);
    if (COUNTRY_TIMEZONES[norm]) return COUNTRY_TIMEZONES[norm];

    // Búsqueda parcial si coincide palabra
    for (const [key, val] of Object.entries(COUNTRY_TIMEZONES)) {
        if (norm.includes(key) || key.includes(norm)) {
            return val;
        }
    }
    return null;
}

function isValidDate(day, month) {
    if (isNaN(day) || isNaN(month)) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;

    // Verificar si el día corresponde al mes (año bisiesto estándar 2024 para permitir 29 feb)
    const testDate = new Date(2024, month - 1, day);
    return testDate.getMonth() === (month - 1) && testDate.getDate() === day;
}

function calculateDaysRemaining(day, month, timezone) {
    const now = new Date();
    const zoned = birthdayScheduler.getZonedParts(now, timezone) || {
        year: now.getFullYear(),
        month: now.getMonth() + 1,
        day: now.getDate()
    };

    let targetYear = zoned.year;

    // Si ya pasó este año en la fecha local, será el año que viene
    if (zoned.month > month || (zoned.month === month && zoned.day > day)) {
        targetYear++;
    }

    const todayDate = new Date(zoned.year, zoned.month - 1, zoned.day);
    const targetDate = new Date(targetYear, month - 1, day);

    const diffTime = targetDate.getTime() - todayDate.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    return {
        days: diffDays,
        isToday: diffDays === 0
    };
}

const handler = async (message, { text, args, command, conn }) => {
    try {
        const msgId = message.id || message.key?.id;
        if (msgId && executedMessages.has(msgId)) return;
        if (msgId) {
            executedMessages.add(msgId);
            setTimeout(() => executedMessages.delete(msgId), 30000);
        }

        const chatId = message.from || message.key?.remoteJid;
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede ser utilizado en grupos.');
        }

        const senderRaw = message.author || message.sender || message.key?.participant || message.from;
        const senderNum = cleanDigits(senderRaw);
        const lowerCmd = (command || '').toLowerCase();

        // ═══════════════════════════════════════════════════════════════════════════
        // COMANDO .micumple
        // ═══════════════════════════════════════════════════════════════════════════
        if (lowerCmd === 'micumple') {
            const rawText = (text || '').trim();

            // Subcomando: .micumple test (Solo Owner)
            if (rawText.toLowerCase() === 'test') {
                const isOwner = await botConfig.isOwnerJid(senderRaw, chatId);
                if (!isOwner) {
                    return await message.reply('⛔ Solo el *owner* del bot puede ejecutar la prueba de cumpleaños.');
                }

                await message.reply('🧪 Realizando prueba de felicitación de cumpleaños en este grupo...');
                const activeSock = message._sock || conn || global.conn;
                const sent = await birthdayScheduler.sendBirthdayGreeting(
                    chatId,
                    senderNum,
                    { country: 'uruguay', timezone: 'America/Montevideo' },
                    { sock: activeSock }
                );

                if (!sent) {
                    return await message.reply('❌ No se pudo enviar la felicitación de prueba.');
                }
                return;
            }

            // Uso normal: .micumple <día> <mes> <país>
            const parts = rawText.split(/\s+/);
            if (parts.length < 3) {
                return await message.reply(
                    '❌ *Formato incorrecto*\n\n' +
                    '📌 *Uso correcto:*\n' +
                    '`.micumple <día> <mes> <país>`\n\n' +
                    '💡 *Ejemplos:*\n' +
                    '• `.micumple 13 enero uruguay`\n' +
                    '• `.micumple 25 mayo argentina`\n' +
                    '• `.micumple 8 octubre colombia`'
                );
            }

            const day = parseInt(parts[0], 10);
            const monthInput = normalizeText(parts[1]);
            const month = MONTH_NAMES[monthInput];
            const countryInput = parts.slice(2).join(' ');
            const countryObj = resolveCountry(countryInput);

            if (!month) {
                return await message.reply(`❌ Mes no reconocido: *${parts[1]}*.\nUsa nombres de mes en español (ej: enero, febrero, marzo...).`);
            }

            if (!isValidDate(day, month)) {
                return await message.reply(`❌ Fecha inválida: *${day} de ${MONTH_STRINGS[month]}*. Verifica el día del mes.`);
            }

            if (!countryObj) {
                const sampleCountries = 'Uruguay, Argentina, Colombia, Chile, México, España, Perú, Venezuela, Ecuador, Bolivia, Paraguay, USA...';
                return await message.reply(`❌ País no reconocido: *${countryInput}*.\n\n🌍 *Países admitidos:* ${sampleCountries}`);
            }

            // Guardar en data/cumpleanos.json
            const db = birthdayScheduler.loadCumpleanos();
            if (!db[chatId]) db[chatId] = {};

            db[chatId][senderNum] = {
                day,
                month,
                country: countryObj.name.toLowerCase(),
                countryDisplay: countryObj.name,
                flag: countryObj.flag,
                timezone: countryObj.tz,
                setBy: senderNum,
                setAt: new Date().toISOString(),
                lastGreeted: null
            };

            birthdayScheduler.saveCumpleanos(db);

            const rem = calculateDaysRemaining(day, month, countryObj.tz);
            const daysText = rem.isToday ? '¡Es HOY! 🎉' : `faltan *${rem.days}* días`;

            return await message.reply(
                `🎂 *¡CUMPLEAÑOS REGISTRADO CON ÉXITO!* 🎂\n\n` +
                `👤 *Usuario:* @${senderNum}\n` +
                `📅 *Fecha:* ${day} de ${MONTH_STRINGS[month]}\n` +
                `🌍 *País:* ${countryObj.flag} ${countryObj.name}\n` +
                `⏳ *Cuenta regresiva:* ${daysText}\n\n` +
                `⏰ _El bot te saludará automáticamente a las 00:02 de tu país en este grupo y mencionará a todos._`,
                { mentions: [`${senderNum}@s.whatsapp.net`] }
            );
        }

        // ═══════════════════════════════════════════════════════════════════════════
        // COMANDO .cumpleaños
        // ═══════════════════════════════════════════════════════════════════════════
        if (lowerCmd === 'cumpleaños' || lowerCmd === 'cumpleanos') {
            const rawText = (text || '').trim();
            const parts = rawText.split(/\s+/).filter(Boolean);
            const db = birthdayScheduler.loadCumpleanos();
            const groupData = db[chatId] || {};

            // 1. Subcomando: .cumpleaños set @user <día> <mes> <país> (Admin u Owner)
            if (parts[0] && parts[0].toLowerCase() === 'set') {
                const activeSock = message._sock || conn || global.conn;
                let meta = null;
                try {
                    meta = await activeSock.groupMetadata(chatId);
                } catch (_) {}

                const isOwner = await botConfig.isOwnerJid(senderRaw, chatId);
                let isAdmin = false;

                if (meta && Array.isArray(meta.participants)) {
                    const senderP = meta.participants.find(p => cleanDigits(p.id) === senderNum);
                    isAdmin = senderP && (senderP.admin === 'admin' || senderP.admin === 'superadmin');
                }

                if (!isAdmin && !isOwner) {
                    return await message.reply('⛔ Solo los *administradores* del grupo o el *owner* pueden configurar el cumpleaños de otro usuario.');
                }

                // Obtener target user
                let targetNum = null;
                if (message.mentions && message.mentions.length > 0) {
                    targetNum = cleanDigits(message.mentions[0]);
                } else if (message.quoted?.sender) {
                    targetNum = cleanDigits(message.quoted.sender);
                }

                // Remover 'set' y mención si vino como texto
                const cleanArgs = parts.slice(1).filter(p => !p.startsWith('@'));
                if (!targetNum && cleanArgs.length > 0 && /^\d+$/.test(cleanArgs[0])) {
                    targetNum = cleanArgs.shift();
                }

                if (!targetNum || cleanArgs.length < 3) {
                    return await message.reply(
                        '❌ *Uso correcto:*\n' +
                        '`.cumpleaños set @usuario <día> <mes> <país>`\n\n' +
                        '💡 *Ejemplo:*\n' +
                        '`.cumpleaños set @usuario 15 marzo argentina`'
                    );
                }

                const day = parseInt(cleanArgs[0], 10);
                const monthInput = normalizeText(cleanArgs[1]);
                const month = MONTH_NAMES[monthInput];
                const countryInput = cleanArgs.slice(2).join(' ');
                const countryObj = resolveCountry(countryInput);

                if (!month) {
                    return await message.reply(`❌ Mes no reconocido: *${cleanArgs[1]}*.`);
                }

                if (!isValidDate(day, month)) {
                    return await message.reply(`❌ Fecha inválida: *${day} de ${MONTH_STRINGS[month]}*.`);
                }

                if (!countryObj) {
                    return await message.reply(`❌ País no reconocido: *${countryInput}*.`);
                }

                if (!db[chatId]) db[chatId] = {};
                db[chatId][targetNum] = {
                    day,
                    month,
                    country: countryObj.name.toLowerCase(),
                    countryDisplay: countryObj.name,
                    flag: countryObj.flag,
                    timezone: countryObj.tz,
                    setBy: senderNum,
                    setAt: new Date().toISOString(),
                    lastGreeted: null
                };

                birthdayScheduler.saveCumpleanos(db);

                return await message.reply(
                    `✅ Cumpleaños de @${targetNum} configurado:\n` +
                    `📅 *Fecha:* ${day} de ${MONTH_STRINGS[month]}\n` +
                    `🌍 *País:* ${countryObj.flag} ${countryObj.name}`,
                    { mentions: [`${targetNum}@s.whatsapp.net`] }
                );
            }

            // 2. Subcomando: .cumpleaños @user (Info del usuario consultado)
            let queriedNum = null;
            if (message.mentions && message.mentions.length > 0) {
                queriedNum = cleanDigits(message.mentions[0]);
            } else if (message.quoted?.sender) {
                queriedNum = cleanDigits(message.quoted.sender);
            } else if (parts.length === 1 && /^\d+$/.test(parts[0].replace('@', ''))) {
                queriedNum = parts[0].replace('@', '').replace(/\D/g, '');
            }

            if (queriedNum) {
                const userEntry = groupData[queriedNum];
                if (!userEntry) {
                    return await message.reply(`ℹ️ El usuario @${queriedNum} no tiene ningún cumpleaños registrado en este grupo.`, {
                        mentions: [`${queriedNum}@s.whatsapp.net`]
                    });
                }

                const rem = calculateDaysRemaining(userEntry.day, userEntry.month, userEntry.timezone);
                const daysText = rem.isToday ? '¡Es HOY! 🎉🎂' : `faltan *${rem.days}* días`;

                return await message.reply(
                    `🎂 *CUMPLEAÑOS DE @${queriedNum}*\n\n` +
                    `📅 *Fecha:* ${userEntry.day} de ${MONTH_STRINGS[userEntry.month]}\n` +
                    `🌍 *País:* ${userEntry.flag || '🌍'} ${userEntry.countryDisplay || userEntry.country}\n` +
                    `⏳ *Falta:* ${daysText}`,
                    { mentions: [`${queriedNum}@s.whatsapp.net`] }
                );
            }

            // 3. Subcomando: .cumpleaños (Lista general del grupo ordenada por cercanía)
            const users = Object.entries(groupData);
            if (users.length === 0) {
                return await message.reply(
                    '📭 *No hay cumpleaños registrados en este grupo.*\n\n' +
                    '👉 Usa `.micumple <día> <mes> <país>` para registrar el tuyo.'
                );
            }

            // Mapear y calcular días restantes para cada uno
            const list = users.map(([num, data]) => {
                const rem = calculateDaysRemaining(data.day, data.month, data.timezone);
                return {
                    num,
                    data,
                    days: rem.days,
                    isToday: rem.isToday
                };
            });

            // Ordenar por el más cercano (menor número de días restantes)
            list.sort((a, b) => a.days - b.days);

            let textResponse = `🎂 *PRÓXIMOS CUMPLEAÑOS DEL GRUPO* 🎂\n\n`;
            const mentionsList = [];

            for (const item of list) {
                const flag = item.data.flag || '🌍';
                const monthName = MONTH_STRINGS[item.data.month] || item.data.month;
                const timeText = item.isToday ? '🎉 ¡ES HOY!' : `en ${item.days} día${item.days !== 1 ? 's' : ''}`;

                textResponse += `• @${item.num} ➜ ${item.data.day} ${monthName} ${flag} _(${timeText})_\n`;
                mentionsList.push(`${item.num}@s.whatsapp.net`);
            }

            textResponse += `\n📌 _Para registrarte usa:_ \`.micumple <día> <mes> <país>\``;

            return await message.reply(textResponse, { mentions: mentionsList });
        }

    } catch (error) {
        console.error('[cumpleanos plugin] Error general:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando de cumpleaños.');
    }
};

handler.help = ['micumple <día> <mes> <país>', 'cumpleaños'];
handler.tags = ['tools', 'group'];
handler.command = /^(micumple|cumpleaños|cumpleanos)$/i;
handler.group = true;

module.exports = handler;

