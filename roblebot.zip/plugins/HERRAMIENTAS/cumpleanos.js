'use strict';

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * PLUGIN DE CUMPLEAÑOS
 * ═══════════════════════════════════════════════════════════════════════════════
 * Comandos:
 *  - .micumple <día> <mes> <país>    -> Registra tu cumpleaños en este grupo
 *  - .micumple test                  -> Prueba de felicitación (solo owner)
 *  - .cumpleaños                     -> Lista ordenada de los cumpleaños del grupo (solo miembros actuales)
 *  - .cumpleaños @user               -> Información del cumpleaños del usuario
 *  - .cumpleaños set @user <día> <mes> <país> -> Configurar cumpleaños de un usuario (admin/owner)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const fs = require('fs');
const path = require('path');
const birthdayScheduler = require('../../lib/birthdayScheduler');
const botConfig = require('../../config');

const executedMessages = new Set();

// Mapa de países y sus zonas horarias IANA principales
const COUNTRY_TIMEZONES = {
    'uruguay': { tz: 'America/Montevideo', flag: '🇺🇾', name: 'Uruguay' },
    'argentina': { tz: 'America/Argentina/Buenos_Aires', flag: '🇦🇷', name: 'Argentina' },
    'colombia': { tz: 'America/Bogota', flag: '🇨🇴', name: 'Colombia' },
    'mexico': { tz: 'America/Mexico_City', flag: '🇲🇽', name: 'México' },
    'chile': { tz: 'America/Santiago', flag: '🇨🇱', name: 'Chile' },
    'peru': { tz: 'America/Lima', flag: '🇵🇪', name: 'Perú' },
    'venezuela': { tz: 'America/Caracas', flag: '🇻🇪', name: 'Venezuela' },
    'espana': { tz: 'Europe/Madrid', flag: '🇪🇸', name: 'España' },
    'españa': { tz: 'Europe/Madrid', flag: '🇪🇸', name: 'España' },
    'ecuador': { tz: 'America/Guayaquil', flag: '🇪🇨', name: 'Ecuador' },
    'bolivia': { tz: 'America/La_Paz', flag: '🇧🇴', name: 'Bolivia' },
    'paraguay': { tz: 'America/Asuncion', flag: '🇵🇾', name: 'Paraguay' },
    'guatemala': { tz: 'America/Guatemala', flag: '🇬🇹', name: 'Guatemala' },
    'cuba': { tz: 'America/Havana', flag: '🇨🇺', name: 'Cuba' },
    'republica dominicana': { tz: 'America/Santo_Domingo', flag: '🇩🇴', name: 'República Dominicana' },
    'dominicana': { tz: 'America/Santo_Domingo', flag: '🇩🇴', name: 'República Dominicana' },
    'honduras': { tz: 'America/Tegucigalpa', flag: '🇭🇳', name: 'Honduras' },
    'el salvador': { tz: 'America/El_Salvador', flag: '🇸🇻', name: 'El Salvador' },
    'salvador': { tz: 'America/El_Salvador', flag: '🇸🇻', name: 'El Salvador' },
    'nicaragua': { tz: 'America/Managua', flag: '🇳🇮', name: 'Nicaragua' },
    'costa rica': { tz: 'America/Costa_Rica', flag: '🇨🇷', name: 'Costa Rica' },
    'panama': { tz: 'America/Panama', flag: '🇵🇦', name: 'Panamá' },
    'puerto rico': { tz: 'America/Puerto_Rico', flag: '🇵🇷', name: 'Puerto Rico' },
    'estados unidos': { tz: 'America/New_York', flag: '🇺🇸', name: 'Estados Unidos' },
    'usa': { tz: 'America/New_York', flag: '🇺🇸', name: 'USA' },
    'eeuu': { tz: 'America/New_York', flag: '🇺🇸', name: 'EE.UU.' },
    'brasil': { tz: 'America/Sao_Paulo', flag: '🇧🇷', name: 'Brasil' },
    'brazil': { tz: 'America/Sao_Paulo', flag: '🇧🇷', name: 'Brasil' },
    'italia': { tz: 'Europe/Rome', flag: '🇮🇹', name: 'Italia' },
    'portugal': { tz: 'Europe/Lisbon', flag: '🇵🇹', name: 'Portugal' },
    'francia': { tz: 'Europe/Paris', flag: '🇫🇷', name: 'Francia' },
    'alemania': { tz: 'Europe/Berlin', flag: '🇩🇪', name: 'Alemania' },
    'reino unido': { tz: 'Europe/London', flag: '🇬🇧', name: 'Reino Unido' },
    'inglaterra': { tz: 'Europe/London', flag: '🇬🇧', name: 'Inglaterra' }
};

const MONTH_NAMES = {
    'enero': 1, 'ene': 1, '1': 1, '01': 1,
    'febrero': 2, 'feb': 2, '2': 2, '02': 2,
    'marzo': 3, 'mar': 3, '3': 3, '03': 3,
    'abril': 4, 'abr': 4, '4': 4, '04': 4,
    'mayo': 5, 'may': 5, '5': 5, '05': 5,
    'junio': 6, 'jun': 6, '6': 6, '06': 6,
    'julio': 7, 'jul': 7, '7': 7, '07': 7,
    'agosto': 8, 'ago': 8, '8': 8, '08': 8,
    'septiembre': 9, 'sep': 9, 'setiembre': 9, 'set': 9, '9': 9, '09': 9,
    'octubre': 10, 'oct': 10, '10': 10,
    'noviembre': 11, 'nov': 11, '11': 11,
    'diciembre': 12, 'dic': 12, '12': 12
};

const MONTH_STRINGS = [
    '', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

function normalizeText(text) {
    if (!text) return '';
    return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function cleanDigits(val) {
    if (!val) return '';
    return String(val).split('@')[0].split(':')[0].replace(/\D/g, '');
}

function resolveCountry(countryInput) {
    const norm = normalizeText(countryInput);
    if (COUNTRY_TIMEZONES[norm]) return COUNTRY_TIMEZONES[norm];

    // Búsqueda parcial si coincide palabra
    for (const [key, val] of Object.entries(COUNTRY_TIMEZONES)) {
        if (norm.includes(key) || key.includes(norm)) {
            return val;
        }
    }
    return null;
}

function isValidDate(day, month) {
    if (isNaN(day) || isNaN(month)) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;

    // Verificar si el día corresponde al mes (año bisiesto estándar 2024 para permitir 29 feb)
    const testDate = new Date(2024, month - 1, day);
    return testDate.getMonth() === (month - 1) && testDate.getDate() === day;
}

function calculateDaysRemaining(day, month, timezone) {
    const now = new Date();
    const zoned = birthdayScheduler.getZonedParts(now, timezone) || {
        year: now.getFullYear(),
        month: now.getMonth() + 1,
        day: now.getDate()
    };

    let targetYear = zoned.year;

    // Si ya pasó este año en la fecha local, será el año que viene
    if (zoned.month > month || (zoned.month === month && zoned.day > day)) {
        targetYear++;
    }

    const todayDate = new Date(zoned.year, zoned.month - 1, zoned.day);
    const targetDate = new Date(targetYear, month - 1, day);

    const diffTime = targetDate.getTime() - todayDate.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    return {
        days: diffDays,
        isToday: diffDays === 0
    };
}

async function getGroupMetadata(conn, chatId) {
    try {
        if (typeof conn?.groupMetadata === 'function') {
            return await conn.groupMetadata(chatId);
        }
    } catch (_) {}
    return null;
}

function findParticipant(participants, numOrJid) {
    if (!Array.isArray(participants)) return null;
    const clean = cleanDigits(numOrJid);
    return participants.find(p => {
        const pNum = cleanDigits(p.phoneNumber);
        const pIdNum = cleanDigits(p.id);
        return pNum === clean || pIdNum === clean;
    });
}

const handler = async (message, { text, args, command, conn }) => {
    try {
        const msgId = message.id || message.key?.id;
        if (msgId && executedMessages.has(msgId)) return;
        if (msgId) {
            executedMessages.add(msgId);
            setTimeout(() => executedMessages.delete(msgId), 30000);
        }

        const chatId = message.from || message.key?.remoteJid;
        if (!chatId || !chatId.endsWith('@g.us')) {
            return await message.reply('❌ Este comando solo puede ser utilizado en grupos.');
        }

        const activeConn = conn || message._sock || global.conn;
        const senderRaw = message.author || message.sender || message.key?.participant || message.from;
        const senderNum = cleanDigits(senderRaw);
        const lowerCmd = (command || '').toLowerCase();

        // Obtener metadatos del grupo
        const meta = await getGroupMetadata(activeConn, chatId);
        const participants = meta?.participants || [];

        // Helper para resolver el JID exacto y displayNum (igual que en warns.js)
        const getExactJidAndDisplay = (numOrJid) => {
            const p = findParticipant(participants, numOrJid);
            const jid = p ? p.id : (String(numOrJid).includes('@') ? numOrJid : `${cleanDigits(numOrJid)}@s.whatsapp.net`);
            const displayNum = jid.split('@')[0];
            return { jid, displayNum, participant: p };
        };

        const quotedMsg = message.baileyMessage || message._baileyMessage || message;

        // ═══════════════════════════════════════════════════════════════════════════
        // COMANDO .micumple
        // ═══════════════════════════════════════════════════════════════════════════
        if (lowerCmd === 'micumple') {
            const rawText = (text || '').trim();

            // Subcomando: .micumple test (Solo Owner)
            if (rawText.toLowerCase() === 'test') {
                const isOwner = await botConfig.isOwnerJid(senderRaw, chatId);
                if (!isOwner) {
                    return await activeConn.sendMessage(chatId, {
                        text: '⛔ Solo el *owner* del bot puede ejecutar la prueba de cumpleaños.'
                    }, { quoted: quotedMsg });
                }

                await activeConn.sendMessage(chatId, {
                    text: '🧪 Realizando prueba de felicitación de cumpleaños en este grupo...'
                }, { quoted: quotedMsg });

                const sent = await birthdayScheduler.sendBirthdayGreeting(
                    chatId,
                    senderNum,
                    { country: 'uruguay', timezone: 'America/Montevideo' },
                    { sock: activeConn, meta }
                );

                if (!sent) {
                    return await activeConn.sendMessage(chatId, {
                        text: '❌ No se pudo enviar la felicitación de prueba.'
                    }, { quoted: quotedMsg });
                }
                return;
            }

            // Uso normal: .micumple <día> <mes> <país>
            const parts = rawText.split(/\s+/);
            if (parts.length < 3) {
                return await activeConn.sendMessage(chatId, {
                    text:
                        '❌ *Formato incorrecto*\n\n' +
                        '📌 *Uso correcto:*\n' +
                        '`.micumple <día> <mes> <país>`\n\n' +
                        '💡 *Ejemplos:*\n' +
                        '• `.micumple 13 enero uruguay`\n' +
                        '• `.micumple 25 mayo argentina`\n' +
                        '• `.micumple 8 octubre colombia`'
                }, { quoted: quotedMsg });
            }

            const day = parseInt(parts[0], 10);
            const monthInput = normalizeText(parts[1]);
            const month = MONTH_NAMES[monthInput];
            const countryInput = parts.slice(2).join(' ');
            const countryObj = resolveCountry(countryInput);

            if (!month) {
                return await activeConn.sendMessage(chatId, {
                    text: `❌ Mes no reconocido: *${parts[1]}*.\nUsa nombres de mes en español (ej: enero, febrero, marzo...).`
                }, { quoted: quotedMsg });
            }

            if (!isValidDate(day, month)) {
                return await activeConn.sendMessage(chatId, {
                    text: `❌ Fecha inválida: *${day} de ${MONTH_STRINGS[month]}*. Verifica el día del mes.`
                }, { quoted: quotedMsg });
            }

            if (!countryObj) {
                const sampleCountries = 'Uruguay, Argentina, Colombia, Chile, México, España, Perú, Venezuela, Ecuador, Bolivia, Paraguay, USA...';
                return await activeConn.sendMessage(chatId, {
                    text: `❌ País no reconocido: *${countryInput}*.\n\n🌍 *Países admitidos:* ${sampleCountries}`
                }, { quoted: quotedMsg });
            }

            // Guardar en data/cumpleanos.json
            const db = birthdayScheduler.loadCumpleanos();
            if (!db[chatId]) db[chatId] = {};

            db[chatId][senderNum] = {
                day,
                month,
                country: countryObj.name.toLowerCase(),
                countryDisplay: countryObj.name,
                flag: countryObj.flag,
                timezone: countryObj.tz,
                setBy: senderNum,
                setAt: new Date().toISOString(),
                lastGreeted: null
            };

            birthdayScheduler.saveCumpleanos(db);

            const rem = calculateDaysRemaining(day, month, countryObj.tz);
            const daysText = rem.isToday ? '¡Es HOY! 🎉' : `faltan *${rem.days}* días`;
            const { jid: senderJid, displayNum } = getExactJidAndDisplay(senderRaw);

            return await activeConn.sendMessage(chatId, {
                text:
                    `🎂 *¡CUMPLEAÑOS REGISTRADO CON ÉXITO!* 🎂\n\n` +
                    `👤 *Usuario:* @${displayNum}\n` +
                    `📅 *Fecha:* ${day} de ${MONTH_STRINGS[month]}\n` +
                    `🌍 *País:* ${countryObj.flag} ${countryObj.name}\n` +
                    `⏳ *Cuenta regresiva:* ${daysText}\n\n` +
                    `⏰ _El bot te saludará automáticamente a las 00:02 de tu país en este grupo y mencionará a todos._`,
                mentions: [senderJid]
            }, { quoted: quotedMsg });
        }

        // ═══════════════════════════════════════════════════════════════════════════
        // COMANDO .cumpleaños
        // ═══════════════════════════════════════════════════════════════════════════
        if (lowerCmd === 'cumpleaños' || lowerCmd === 'cumpleanos') {
            const rawText = (text || '').trim();
            const parts = rawText.split(/\s+/).filter(Boolean);
            const db = birthdayScheduler.loadCumpleanos();
            const groupData = db[chatId] || {};

            // 1. Subcomando: .cumpleaños set @user <día> <mes> <país> (Admin u Owner)
            if (parts[0] && parts[0].toLowerCase() === 'set') {
                const isOwner = await botConfig.isOwnerJid(senderRaw, chatId);
                let isAdmin = false;

                const senderP = findParticipant(participants, senderRaw);
                isAdmin = senderP && (senderP.admin === 'admin' || senderP.admin === 'superadmin');

                if (!isAdmin && !isOwner) {
                    return await activeConn.sendMessage(chatId, {
                        text: '❌ Solo los *administradores* del grupo o el *owner* pueden configurar el cumpleaños de otro usuario.'
                    }, { quoted: quotedMsg });
                }

                // Obtener target user
                let targetRaw = null;
                if (message.mentions && message.mentions.length > 0) {
                    targetRaw = message.mentions[0];
                } else if (message.quoted?.sender) {
                    targetRaw = message.quoted.sender;
                }

                // Remover 'set' y mención si vino como texto
                const cleanArgs = parts.slice(1).filter(p => !p.startsWith('@'));
                if (!targetRaw && cleanArgs.length > 0 && /^\d+$/.test(cleanArgs[0])) {
                    targetRaw = cleanArgs.shift();
                }

                if (!targetRaw || cleanArgs.length < 3) {
                    return await activeConn.sendMessage(chatId, {
                        text:
                            '❌ *Uso correcto:*\n' +
                            '`.cumpleaños set @usuario <día> <mes> <país>`\n\n' +
                            '💡 *Ejemplo:*\n' +
                            '`.cumpleaños set @usuario 15 marzo argentina`'
                    }, { quoted: quotedMsg });
                }

                const targetNum = cleanDigits(targetRaw);
                const day = parseInt(cleanArgs[0], 10);
                const monthInput = normalizeText(cleanArgs[1]);
                const month = MONTH_NAMES[monthInput];
                const countryInput = cleanArgs.slice(2).join(' ');
                const countryObj = resolveCountry(countryInput);

                if (!month) {
                    return await activeConn.sendMessage(chatId, {
                        text: `❌ Mes no reconocido: *${cleanArgs[1]}*.`
                    }, { quoted: quotedMsg });
                }

                if (!isValidDate(day, month)) {
                    return await activeConn.sendMessage(chatId, {
                        text: `❌ Fecha inválida: *${day} de ${MONTH_STRINGS[month]}*.`
                    }, { quoted: quotedMsg });
                }

                if (!countryObj) {
                    return await activeConn.sendMessage(chatId, {
                        text: `❌ País no reconocido: *${countryInput}*.`
                    }, { quoted: quotedMsg });
                }

                if (!db[chatId]) db[chatId] = {};
                db[chatId][targetNum] = {
                    day,
                    month,
                    country: countryObj.name.toLowerCase(),
                    countryDisplay: countryObj.name,
                    flag: countryObj.flag,
                    timezone: countryObj.tz,
                    setBy: senderNum,
                    setAt: new Date().toISOString(),
                    lastGreeted: null
                };

                birthdayScheduler.saveCumpleanos(db);

                const { jid: targetJid, displayNum } = getExactJidAndDisplay(targetRaw || targetNum);

                return await activeConn.sendMessage(chatId, {
                    text:
                        `✅ Cumpleaños de @${displayNum} configurado:\n` +
                        `📅 *Fecha:* ${day} de ${MONTH_STRINGS[month]}\n` +
                        `🌍 *País:* ${countryObj.flag} ${countryObj.name}`,
                    mentions: [targetJid]
                }, { quoted: quotedMsg });
            }

            // 2. Subcomando: .cumpleaños @user (Info del usuario consultado)
            let queriedRaw = null;
            if (message.mentions && message.mentions.length > 0) {
                queriedRaw = message.mentions[0];
            } else if (message.quoted?.sender) {
                queriedRaw = message.quoted.sender;
            } else if (parts.length === 1 && /^\d+$/.test(parts[0].replace('@', ''))) {
                queriedRaw = parts[0].replace('@', '').replace(/\D/g, '');
            }

            if (queriedRaw) {
                const queriedNum = cleanDigits(queriedRaw);
                const userEntry = groupData[queriedNum];
                const { jid: queriedJid, displayNum } = getExactJidAndDisplay(queriedRaw);

                if (!userEntry) {
                    return await activeConn.sendMessage(chatId, {
                        text: `ℹ️ El usuario @${displayNum} no tiene ningún cumpleaños registrado en este grupo.`,
                        mentions: [queriedJid]
                    }, { quoted: quotedMsg });
                }

                const rem = calculateDaysRemaining(userEntry.day, userEntry.month, userEntry.timezone);
                const daysText = rem.isToday ? '¡Es HOY! 🎉🎂' : `faltan *${rem.days}* días`;

                return await activeConn.sendMessage(chatId, {
                    text:
                        `🎂 *CUMPLEAÑOS DE @${displayNum}*\n\n` +
                        `📅 *Fecha:* ${userEntry.day} de ${MONTH_STRINGS[userEntry.month]}\n` +
                        `🌍 *País:* ${userEntry.flag || '🌍'} ${userEntry.countryDisplay || userEntry.country}\n` +
                        `⏳ *Falta:* ${daysText}`,
                    mentions: [queriedJid]
                }, { quoted: quotedMsg });
            }

            // 3. Subcomando: .cumpleaños (Lista general del grupo ordenada por cercanía)
            const users = Object.entries(groupData);
            if (users.length === 0) {
                return await activeConn.sendMessage(chatId, {
                    text:
                        '📭 *No hay cumpleaños registrados en este grupo.*\n\n' +
                        '👉 Usa `.micumple <día> <mes> <país>` para registrar el tuyo.'
                }, { quoted: quotedMsg });
            }

            // Filtrar únicamente los usuarios que actualmente están presentes en el grupo
            // (los ausentes NO se borran de data, solo se omiten del mensaje)
            const activeList = [];
            for (const [num, data] of users) {
                const p = findParticipant(participants, num);
                if (p) {
                    const rem = calculateDaysRemaining(data.day, data.month, data.timezone);
                    const jid = p.id;
                    const displayNum = jid.split('@')[0];
                    activeList.push({
                        num,
                        jid,
                        displayNum,
                        data,
                        days: rem.days,
                        isToday: rem.isToday
                    });
                }
            }

            if (activeList.length === 0) {
                return await activeConn.sendMessage(chatId, {
                    text:
                        '📭 *No hay cumpleaños de miembros actuales en este grupo.*\n\n' +
                        '👉 Usa `.micumple <día> <mes> <país>` para registrar el tuyo.'
                }, { quoted: quotedMsg });
            }

            // Ordenar por el más cercano (menor número de días restantes)
            activeList.sort((a, b) => a.days - b.days);

            let textResponse = `🎂 *PRÓXIMOS CUMPLEAÑOS DEL GRUPO (${activeList.length})* 🎂\n\n`;
            const mentionsList = [];

            for (const item of activeList) {
                const flag = item.data.flag || '🌍';
                const monthName = MONTH_STRINGS[item.data.month] || item.data.month;
                const timeText = item.isToday ? '🎉 ¡ES HOY!' : `en ${item.days} día${item.days !== 1 ? 's' : ''}`;

                textResponse += `• @${item.displayNum} ➜ ${item.data.day} ${monthName} ${flag} _(${timeText})_\n`;
                mentionsList.push(item.jid);
            }

            textResponse += `\n📌 _Para registrarte usa:_ \`.micumple <día> <mes> <país>\``;

            return await activeConn.sendMessage(chatId, {
                text: textResponse,
                mentions: mentionsList
            }, { quoted: quotedMsg });
        }

    } catch (error) {
        console.error('[cumpleanos plugin] Error general:', error);
        await message.reply('❌ Ocurrió un error inesperado al procesar el comando de cumpleaños.');
    }
};

handler.help = ['micumple <día> <mes> <país>', 'cumpleaños'];
handler.tags = ['tools', 'group'];
handler.command = /^(micumple|cumpleaños|cumpleanos)$/i;
handler.group = true;

module.exports = handler;
