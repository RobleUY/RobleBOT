/**
 * Comando: tav
 * Descripción: Convierte texto a voz usando SankaVollerei TTS con respaldo en Delirius
 * Uso: .tav <nombre_voz> <texto>
 * Ejemplo: .tav elon musk Hola a todos
 *          .tav elon-musk Hola a todos
 *          .tav elonmusk Hola a todos
 */

const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

/* --------------------------- VOCES (nombres limpios para mostrar) --------------------------- */
const VOICE_DISPLAY_NAMES = [
  "Nahida",
  "Nami",
  "Ana",
  "Optimus Prime",
  "Goku",
  "Elon Musk",
  "Mickey Mouse",
  "Kendrick Lamar",
  "Eminem"
];

/* --------------------------- CÓDIGOS HTTP REINTENTABLES --------------------------- */
const RETRYABLE_STATUS_CODES = new Set([429, 502, 503, 504]);

/* --------------------------- UTILIDADES --------------------------- */
function tmpFileName(ext = '') {
  const name = crypto.randomBytes(8).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Normaliza: minúsculas, sin tildes, sin guiones/guiones bajos/espacios ni paréntesis
 * Ejemplo: "Elon-Musk" → "elonmusk"  |  "Nahida (Exclusive)" → "nahida"
 */
function normalize(str) {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')  // quita tildes
    .replace(/\(.*?\)/g, '')          // quita paréntesis y contenido
    .replace(/[-_\s]+/g, '')          // quita guiones, guiones bajos y espacios
    .replace(/[^a-z0-9]/g, '')        // quita caracteres especiales
    .trim();
}

/**
 * Busca la voz cuyo nombre normalizado esté al inicio del input.
 */
function detectVoice(input) {
  const normInput = normalize(input);

  const sorted = [...VOICE_DISPLAY_NAMES].sort(
    (a, b) => normalize(b).length - normalize(a).length
  );

  for (const displayName of sorted) {
    const normVoice = normalize(displayName);
    if (normInput.startsWith(normVoice)) {
      let voiceCharsLeft = normVoice.length;
      let i = 0;

      while (i < input.length && voiceCharsLeft > 0) {
        const ch = input[i].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        if (/[a-z0-9]/.test(ch)) voiceCharsLeft--;
        i++;
      }

      while (i < input.length && /[-_\s]/.test(input[i])) i++;

      const rest = input.slice(i).trim();
      if (rest.length > 0) return { displayName, normName: normVoice, rest };
    }
  }
  return null;
}

/**
 * Busca en la lista de resultados de la API la clave correspondiente al audio de la voz.
 */
function matchApiVoice(results, normName) {
  for (const item of results) {
    if (!item.voice_name) continue;
    const itemNorm = normalize(item.voice_name);
    
    if (itemNorm === normName || itemNorm.startsWith(normName)) {
      const keys = Object.keys(item);
      for (const key of keys) {
        if (typeof item[key] === 'string' && item[key].startsWith('http')) {
          return item[key];
        }
      }
    }
  }
  return null;
}

/* --------------------------- FETCH CON RETRY --------------------------- */
async function fetchWithRetry(url, options = {}, maxRetries = 3, baseDelay = 1500, label = 'fetch') {
  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await fetch(url, options);

      if (RETRYABLE_STATUS_CODES.has(res.status)) {
        const delay = baseDelay * attempt;
        console.warn(`⚠️ [${label}] HTTP ${res.status} en intento ${attempt}/${maxRetries}, reintentando en ${delay}ms...`);
        lastError = new Error(`HTTP_RETRYABLE_${res.status}`);
        if (attempt < maxRetries) await sleep(delay);
        continue;
      }

      if (!res.ok) throw new Error(`HTTP_FATAL_${res.status}`);

      return res;

    } catch (err) {
      if (err.message.startsWith('HTTP_FATAL_')) throw err;

      lastError = err;
      const delay = baseDelay * attempt;
      console.warn(`⚠️ [${label}] Error en intento ${attempt}/${maxRetries}: ${err.message}, reintentando en ${delay}ms...`);
      if (attempt < maxRetries) await sleep(delay);
    }
  }

  throw lastError || new Error(`[${label}] no disponible tras ${maxRetries} intentos`);
}

/* --------------------------- LLAMADAS A LAS APIS --------------------------- */
async function fetchSankaVoiceUrl(text, normName) {
  const encoded = encodeURIComponent(text);
  const url = `https://www.sankavollerei.web.id/tools/text-to-speech?apikey=planaai&text=${encoded}`;

  const res = await fetchWithRetry(url, {}, 3, 1500, 'SankaAPI');
  const json = await res.json();

  if (!json.status || !Array.isArray(json.result)) {
    throw new Error('Respuesta inválida de SankaAPI');
  }

  const audioUrl = matchApiVoice(json.result, normName);
  if (!audioUrl) {
    throw new Error('Voz no encontrada o falló en SankaAPI');
  }

  return audioUrl;
}

async function fetchDeliriusVoiceUrl(text) {
  const encoded = encodeURIComponent(text);
  const url = `https://api.delirius.online/tools/gtts?text=${encoded}&language=es`;

  const res = await fetchWithRetry(url, {}, 3, 1500, 'DeliriusAPI');
  const json = await res.json();

  if (!json.status || !json.data || !json.data.download) {
    throw new Error('Respuesta inválida de DeliriusAPI');
  }

  return json.data.download;
}

/* --------------------------- DESCARGA DEL AUDIO --------------------------- */
async function downloadAudio(audioUrl) {
  const res = await fetchWithRetry(audioUrl, {}, 3, 1500, 'DescargaAudio');
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

/* --------------------------- CONVERSIÓN A OPUS --------------------------- */
async function convertToOpus(inputBuffer) {
  const tempIn  = tmpFileName('wav');
  const tempOut = tmpFileName('opus');

  try {
    await fs.writeFile(tempIn, inputBuffer);

    const args = [
      '-y',
      '-i', tempIn,
      '-ar', '48000',
      '-ac', '1',
      '-c:a', 'libopus',
      '-b:a', '64k',
      '-vbr', 'on',
      tempOut
    ];

    await execFileAsync('ffmpeg', args, { windowsHide: true });
    return await fs.readFile(tempOut);
  } finally {
    await fs.unlink(tempIn).catch(() => {});
    await fs.unlink(tempOut).catch(() => {});
  }
}

/* --------------------------- ENVIAR AUDIO --------------------------- */
async function sendAudio(sock, jid, audioBuffer, isPTT = true, quotedMessage = null) {
  try {
    const options = {
      audio: audioBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: isPTT
    };

    // Si tenemos el objeto de mensaje original o su estructura bailey para citar
    if (quotedMessage) {
      options.quoted = quotedMessage._baileyMessage || quotedMessage;
    }

    await sock.sendMessage(jid, options);
    console.log('✅ Audio enviado correctamente');
    return true;
  } catch (err) {
    console.error('❌ Error al enviar audio:', err);
    return false;
  }
}

/* --------------------------- LISTA DE VOCES --------------------------- */
function voiceListText() {
  return VOICE_DISPLAY_NAMES.map((v, i) => `  ${i + 1}. ${v}`).join('\n');
}

/* --------------------------- HANDLER PRINCIPAL --------------------------- */
let handler = async (message, { text }) => {
  try {
    const sock = message._sock || global.conn;
    if (!sock) return await message.reply('❌ Error: conexión no disponible.');

    const jid = message.chat || message.from;
    if (!jid) return await message.reply('❌ Error: no se pudo identificar el chat.');

    if (!text || !text.trim()) {
      return await message.reply(
        '*🗣️ TEXTO A VOZ CON VOCES*\n\n' +
        '💡 *Uso:*\n' +
        '• *.tav <nombre_voz> <texto>*\n\n' +
        '🎙️ *Voces disponibles:*\n' +
        voiceListText() + '\n\n' +
        '📌 *Ejemplos:*\n' +
        '• _.tav elonmusk Hola a todos_\n' +
        '• _.tav elon-musk Hola a todos_\n' +
        '• _.tav goku Esto es un Kamehameha_'
      );
    }

    const input = text.trim();
    const detected = detectVoice(input);

    if (!detected) {
      return await message.reply(
        '❓ *No reconocí el nombre de la voz.*\n\n' +
        '🎙️ *Voces disponibles:*\n' +
        voiceListText() + '\n\n' +
        '📌 *Ejemplo:* _.tav elonmusk Tu texto aquí_'
      );
    }

    let { displayName, normName, rest: content } = detected;

    if (content.length > 1000) {
      content = content.slice(0, 1000);
      await message.reply('⚠️ Texto recortado a 1000 caracteres.');
    }

    await message.reply(`⏳ Generando audio con la voz de *${displayName}*...`);

    let audioUrl;

    // 1. Intentar con SankaAPI
    try {
      audioUrl = await fetchSankaVoiceUrl(content, normName);
      console.log(`🎙️ URL obtenida de SankaAPI: ${audioUrl}`);
    } catch (apiErr) {
      console.warn(`⚠️ SankaAPI falló (${apiErr.message}), intentando con API de respaldo (Delirius)...`);
      try {
        audioUrl = await fetchDeliriusVoiceUrl(content);
        console.log(`🎙️ URL obtenida de respaldo (Delirius): ${audioUrl}`);
        await message.reply('⚠️ La voz personalizada no estuvo disponible temporalmente, se usó la voz estándar.');
      } catch (fallbackErr) {
        throw new Error('Ambas APIs fallaron al generar el audio.');
      }
    }

    // 2. Descargar el archivo de audio
    const audioBuffer = await downloadAudio(audioUrl);
    console.log(`📦 Audio descargado: ${audioBuffer.length} bytes`);

    // 3. Convertir a OGG Opus para WhatsApp
    const opusBuffer = await convertToOpus(audioBuffer);

    if (!opusBuffer) return await message.reply('❌ Error al procesar el audio.');

    // Enviamos el audio respondiendo a tu mensaje original
    const ok = await sendAudio(sock, jid, opusBuffer, true, message);
    if (!ok) return await message.reply('❌ Error al enviar el audio.');

  } catch (err) {
    console.error('❌ Error general en comando TAV:', err);
    await message.reply('❌ Ocurrió un error al generar el audio. Intentá más tarde.');
  }
};

/* --------------------------- CONFIGURACIÓN --------------------------- */
handler.help = ['tav'];
handler.tags = ['audio'];
handler.command = /^(tav)$/i;
module.exports = handler;