const https = require('https');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

// Baileys (solo se usa para descargar media si el mensaje no trae .download())
let baileys = null;
for (const name of ['@whiskeysockets/baileys', '@adiwajshing/baileys', 'baileys']) {
    try { baileys = require(name); break; } catch (_) {}
}

// Circuit breaker global de red (accesible via global.networkGuard si está disponible)
function getNetGuard() { return (typeof global !== 'undefined' && global.networkGuard) ? global.networkGuard : null; }

// ─── Configuración ────────────────────────────────────────────────────────────
const TIMEOUT_CHAT = 20000;
const TIMEOUT_STT = 90000;
const MAX_TEXT_BYTES = 2 * 1024 * 1024;     // 2 MB para archivos de texto
const MAX_AUDIO_BYTES = 24 * 1024 * 1024;   // Groq permite ~25 MB por archivo
const WA_CHUNK = 3500;                      // caracteres por mensaje de WhatsApp
const MAX_CHUNKS = 6;                       // máximo de mensajes al mostrar un archivo
const MAX_AI_CHARS = 12000;                 // contenido máximo que se le pasa a la IA (Groq)
const MAX_DELIRIUS_CHARS = 3000;            // Delirius usa GET, la URL no admite textos largos

const MODEL_LIST = [
    'openai/gpt-oss-20b',
    'openai/gpt-oss-120b',
    'qwen/qwen3-32b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'llama-3.3-70b-versatile',
    'llama-3.3-8b-instant',
    'llama-3.1-8b-instant'
];

const STT_MODELS = ['whisper-large-v3-turbo', 'whisper-large-v3'];

const SYSTEM_PROMPT = `
Nombre: RobleBOT
Rol: Asistente de WhatsApp
Creador: Dev RobleUY (Desarrollador uruguayo)
Idioma: Español

Reglas de formato y comportamiento:
- Formato WhatsApp: Usa *negrita* (NUNCA **negrita**), _cursiva_, ~tachado~ y \`\`\`código\`\`\`.
- Estilo: Mensajes claros, útiles y amigables, con pocos emojis.
- Tarea: El usuario te pasa el contenido de un archivo o la transcripción de un audio/video junto con una instrucción. Respondé a esa instrucción basándote solo en ese contenido.
- Longitud: Sé conciso, salvo que el usuario pida una respuesta detallada.
`.trim();

// Extensiones que se tratan siempre como texto
const TEXT_EXTENSIONS = new Set([
    'txt', 'text', 'log', 'md', 'markdown', 'rst', 'csv', 'tsv',
    'yml', 'yaml', 'json', 'jsonc', 'json5', 'xml', 'toml', 'ini', 'cfg', 'conf', 'config',
    'env', 'properties', 'gitignore', 'dockerfile', 'lock',
    'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx', 'html', 'htm', 'css', 'scss', 'less', 'vue',
    'py', 'java', 'kt', 'c', 'h', 'cpp', 'hpp', 'cs', 'go', 'rs', 'rb', 'php', 'lua', 'swift',
    'sh', 'bash', 'zsh', 'bat', 'cmd', 'ps1', 'sql', 'srt', 'vtt', 'lrc'
]);

// ─── Claves Groq ──────────────────────────────────────────────────────────────
function collectGroqApiKeys() {
    const keys = new Set();
    const keyPattern = /^groq_api_key(?:\d*)?$/i;

    for (const name of Object.keys(process.env)) {
        if (!keyPattern.test(name)) continue;
        const value = process.env[name];
        if (value && typeof value === 'string') {
            const trimmed = value.trim();
            if (trimmed) keys.add(trimmed);
        }
    }

    return Array.from(keys);
}

// ─── IA de texto (Groq + Delirius) ────────────────────────────────────────────
async function callGroq(systemPrompt, userText) {
    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) {
        throw new Error('No hay claves Groq configuradas');
    }

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        const apiKey = apiKeys[keyIndex];
        for (let modelIndex = 0; modelIndex < MODEL_LIST.length; modelIndex++) {
            const model = MODEL_LIST[modelIndex];
            try {
                return await groqRequest(apiKey, model, systemPrompt, userText);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[transcribir] Groq key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
            }
        }
    }

    throw lastErr || new Error('Groq falló');
}

function groqRequest(apiKey, model, systemPrompt, userText) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userText }
            ],
            max_tokens: 1000,
            temperature: 0.7,
            top_p: 0.95
        });

        const options = {
            hostname: 'api.groq.com',
            path: '/openai/v1/chat/completions',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'Content-Length': Buffer.byteLength(body)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    const content = parsed.choices?.[0]?.message?.content?.trim();
                    if (!content) return reject(new Error('Respuesta vacía de Groq'));
                    resolve(content);
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT_CHAT, () => {
            req.destroy();
            reject(new Error('Timeout Groq'));
        });

        req.write(body);
        req.end();
    });
}

function httpGet(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { timeout: TIMEOUT_CHAT }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch { reject(new Error('Error parseando respuesta')); }
            });
        });
        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

async function deliriusGptPrompt(systemPrompt, userText) {
    const url = `https://api.delirius.online/ia/gptprompt?text=${encodeURIComponent(userText)}&prompt=${encodeURIComponent(systemPrompt)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gptprompt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gptprompt: sin contenido');
    return text.trim();
}

async function deliriusGemini(systemPrompt, userText) {
    const query = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/gemini?query=${encodeURIComponent(query)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gemini: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gemini: sin contenido');
    return text.trim();
}

async function deliriusChatgpt(systemPrompt, userText) {
    const q = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/chatgpt?q=${encodeURIComponent(q)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius chatgpt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius chatgpt: sin contenido');
    return text.trim();
}

// Todas las IAs en paralelo, gana la más rápida
async function callIA(systemPrompt, userText) {
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) {
        console.warn('[transcribir] Red caída (circuit breaker activo) — omitiendo peticiones IA.');
        throw new Error('_SILENT_FAIL_');
    }

    // Delirius va por GET: se le pasa una versión recortada del texto
    const textoCorto = userText.length > MAX_DELIRIUS_CHARS
        ? userText.slice(0, MAX_DELIRIUS_CHARS) + '\n[...contenido recortado...]'
        : userText;

    const attempts = [
        callGroq(systemPrompt, userText.slice(0, MAX_AI_CHARS)),
        deliriusGptPrompt(systemPrompt, textoCorto),
        deliriusGemini(systemPrompt, textoCorto),
        deliriusChatgpt(systemPrompt, textoCorto)
    ];

    const names = ['Groq', 'Delirius-gptprompt', 'Delirius-gemini', 'Delirius-chatgpt'];
    const labeled = attempts.map((p, i) => p.catch(e => {
        console.warn(`[transcribir] ${names[i]} falló:`, e.message);
        throw e;
    }));

    try {
        return await Promise.any(labeled);
    } catch (aggregateErr) {
        const details = Array.isArray(aggregateErr?.errors)
            ? aggregateErr.errors.map(e => e.message).join(' | ')
            : aggregateErr.message;
        console.error('[transcribir] Todas las IAs fallaron:', details);
        throw new Error('_SILENT_FAIL_');
    }
}

// ─── Transcripción (Groq Whisper) ─────────────────────────────────────────────
// Nota: las APIs de Delirius de ia.js son solo de texto, no transcriben audio.
// La transcripción usa las mismas claves de Groq (GROQ_API_KEY, GROQ_API_KEY2...).
function extensionPara(mime, kind) {
    const m = (mime || '').toLowerCase();
    if (m.includes('ogg') || m.includes('opus')) return 'ogg';
    if (m.includes('mpeg') || m.includes('mp3')) return 'mp3';
    if (m.includes('wav')) return 'wav';
    if (m.includes('webm')) return 'webm';
    if (m.includes('flac')) return 'flac';
    if (m.includes('m4a') || m.includes('aac') || m.includes('mp4')) return kind === 'video' ? 'mp4' : 'm4a';
    return kind === 'video' ? 'mp4' : 'ogg';
}

function groqTranscribeRequest(apiKey, model, audio, filename, mime) {
    return new Promise((resolve, reject) => {
        const boundary = '----RobleBOT' + Date.now().toString(16) + Math.random().toString(16).slice(2);
        const parts = [];
        const campo = (name, value) => parts.push(Buffer.from(
            `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`
        ));

        campo('model', model);
        campo('response_format', 'json');
        campo('temperature', '0');
        parts.push(Buffer.from(
            `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\n` +
            `Content-Type: ${mime}\r\n\r\n`
        ));
        parts.push(audio);
        parts.push(Buffer.from(`\r\n--${boundary}--\r\n`));

        const body = Buffer.concat(parts);

        const req = https.request({
            hostname: 'api.groq.com',
            path: '/openai/v1/audio/transcriptions',
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': `multipart/form-data; boundary=${boundary}`,
                'Content-Length': body.length
            }
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq STT');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    if (typeof parsed.text !== 'string') return reject(new Error('Respuesta vacía de Groq STT'));
                    resolve(parsed.text.trim());
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq STT'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT_STT, () => {
            req.destroy();
            reject(new Error('Timeout Groq STT'));
        });

        req.write(body);
        req.end();
    });
}

async function transcribirAudio(buffer, mime, kind) {
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) throw new Error('_SILENT_FAIL_');

    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) throw new Error('No hay claves Groq configuradas');

    const cleanMime = (mime || 'audio/ogg').split(';')[0].trim() || 'audio/ogg';
    const filename = `audio.${extensionPara(mime, kind)}`;

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        for (const model of STT_MODELS) {
            try {
                return await groqTranscribeRequest(apiKeys[keyIndex], model, buffer, filename, cleanMime);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[transcribir] Groq STT key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
            }
        }
    }

    throw lastErr || new Error('Groq STT falló');
}

// Convierte audio/video a mp3 mono liviano con ffmpeg (opcional: si no está instalado devuelve null)
function convertirAMp3(buffer) {
    return new Promise((resolve) => {
        const id = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
        const inp = path.join(os.tmpdir(), `stt_${id}.in`);
        const out = path.join(os.tmpdir(), `stt_${id}.mp3`);
        const limpiar = () => { for (const f of [inp, out]) fs.unlink(f, () => {}); };

        fs.writeFile(inp, buffer, (err) => {
            if (err) { limpiar(); return resolve(null); }
            execFile(
                'ffmpeg',
                ['-y', '-i', inp, '-vn', '-ac', '1', '-ar', '16000', '-b:a', '48k', out],
                { timeout: 120000 },
                (e) => {
                    if (e) { limpiar(); return resolve(null); }
                    fs.readFile(out, (e2, data) => { limpiar(); resolve(e2 ? null : data); });
                }
            );
        });
    });
}

// ─── Obtener el archivo del mensaje (citado o propio) ─────────────────────────
// ⚠️ Esta es la parte que depende de cómo tu bot serializa los mensajes.
// Soporta: message.quoted.download() / message.download() (estilo "serialize"),
// y mensajes crudos de Baileys. Si tu bot usa otro método, ajustá solo esta sección.
const RAW_MEDIA_TYPES = ['audioMessage', 'videoMessage', 'ptvMessage', 'documentMessage', 'imageMessage', 'stickerMessage'];

function unwrap(msg) {
    let m = msg;
    for (let i = 0; i < 5 && m; i++) {
        const inner = m.ephemeralMessage?.message
            || m.viewOnceMessage?.message
            || m.viewOnceMessageV2?.message
            || m.documentWithCaptionMessage?.message
            || m.editedMessage?.message;
        if (!inner) break;
        m = inner;
    }
    return m;
}

function findRawMedia(rawMessage) {
    const m = unwrap(rawMessage);
    if (!m || typeof m !== 'object') return null;
    for (const type of RAW_MEDIA_TYPES) {
        if (m[type]) return { type, media: m[type] };
    }
    return null;
}

function quotedRaw(message) {
    const m = unwrap(message?.message);
    if (!m || typeof m !== 'object') return null;
    for (const value of Object.values(m)) {
        const q = value?.contextInfo?.quotedMessage;
        if (q) return q;
    }
    return null;
}

async function downloadRaw(type, media) {
    if (!baileys?.downloadContentFromMessage) throw new Error('Baileys no disponible para descargar el archivo');
    const mediaType = type === 'ptvMessage' ? 'video' : type.replace('Message', '');
    const stream = await baileys.downloadContentFromMessage(media, mediaType);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

function describirRaw(found) {
    const { type, media } = found;
    let mime = media.mimetype || '';
    if (!mime) {
        if (type === 'audioMessage') mime = 'audio/ogg';
        else if (type === 'videoMessage' || type === 'ptvMessage') mime = 'video/mp4';
        else if (type === 'imageMessage' || type === 'stickerMessage') mime = 'image/jpeg';
    }
    return {
        mime,
        fileName: media.fileName || media.title || '',
        getBuffer: () => downloadRaw(type, media)
    };
}

function describirSerializado(c) {
    if (!c || typeof c !== 'object') return null;

    // mtype + msg (estilo Baileys "smsg")
    const mtype = c.mtype;
    const inner = c.msg;
    const mime = c.mimetype || inner?.mimetype || '';
    const fileName = c.fileName || inner?.fileName || '';

    if (typeof c.download === 'function' && (mime || RAW_MEDIA_TYPES.includes(mtype))) {
        let m = mime;
        if (!m) {
            if (mtype === 'audioMessage') m = 'audio/ogg';
            else if (mtype === 'videoMessage' || mtype === 'ptvMessage') m = 'video/mp4';
        }
        return { mime: m, fileName, getBuffer: () => c.download() };
    }

    if (RAW_MEDIA_TYPES.includes(mtype) && inner) {
        return describirRaw({ type: mtype, media: inner });
    }

    const raw = findRawMedia(c.message);
    if (raw) return describirRaw(raw);

    return null;
}

function resolverArchivo(message) {
    // 1) mensaje citado (serializado), 2) mensaje citado crudo, 3) el propio mensaje (media con caption .leer)
    const quoted = message.quoted || message.reply_message;
    const fromQuoted = describirSerializado(quoted);
    if (fromQuoted) return fromQuoted;

    const rawQuoted = findRawMedia(quotedRaw(message));
    if (rawQuoted) return describirRaw(rawQuoted);

    const fromSelf = describirSerializado(message);
    if (fromSelf) return fromSelf;

    const rawSelf = findRawMedia(message.message);
    if (rawSelf) return describirRaw(rawSelf);

    return null;
}

// ─── Utilidades ───────────────────────────────────────────────────────────────
function clasificar(mime, fileName) {
    const m = (mime || '').toLowerCase();
    if (m.startsWith('audio/')) return 'audio';
    if (m.startsWith('video/')) return 'video';
    if (m.startsWith('image/')) return 'imagen';
    return 'doc';
}

function extDe(fileName) {
    const base = (fileName || '').toLowerCase();
    const idx = base.lastIndexOf('.');
    if (idx === -1) return base.replace(/^\./, '');
    return base.slice(idx + 1);
}

// Devuelve el texto si el buffer parece texto, o null si es binario
function bufferATexto(buffer, fileName, mime) {
    const ext = extDe(fileName);
    const m = (mime || '').toLowerCase();
    const esTextoDeclarado = TEXT_EXTENSIONS.has(ext)
        || m.startsWith('text/')
        || /json|xml|yaml|javascript|x-sh|x-yaml|toml|csv/.test(m);

    const muestra = buffer.subarray(0, 8000);
    if (muestra.includes(0)) return null; // bytes nulos → binario

    let texto = buffer.toString('utf8');
    if (texto.charCodeAt(0) === 0xFEFF) texto = texto.slice(1);

    const malos = (texto.match(/\uFFFD/g) || []).length;
    const ratio = texto.length ? malos / texto.length : 0;
    if (ratio > (esTextoDeclarado ? 0.2 : 0.02)) return null;

    return texto.replace(/\r\n/g, '\n');
}

function partir(texto, max) {
    const out = [];
    let resto = texto;
    while (resto.length > max) {
        let corte = resto.lastIndexOf('\n', max);
        if (corte < max * 0.5) corte = max;
        out.push(resto.slice(0, corte));
        resto = resto.slice(corte).replace(/^\n/, '');
    }
    if (resto) out.push(resto);
    return out;
}

function formatoTamano(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

const seguro = (t) => t.replace(/```/g, "'''");

async function pedirIA(instruccion, etiqueta, contenido) {
    const prompt = `Instrucción del usuario: ${instruccion}\n\n${etiqueta}:\n"""\n${contenido}\n"""`;
    return await callIA(SYSTEM_PROMPT, prompt);
}

// ─── Handler principal ────────────────────────────────────────────────────────
let handler = async (message, { text } = {}) => {
    const instruccion = (text || '').trim();

    let archivo = null;
    try {
        archivo = resolverArchivo(message);
    } catch (e) {
        console.warn('[transcribir] Error resolviendo archivo:', e.message);
    }

    if (!archivo) {
        return await message.reply(
            '⚠️ *Uso correcto:*\n' +
            'Respondé a un archivo, audio o video con:\n' +
            '• *.leer* → lee archivos de texto (txt, yml, json, js...) o transcribe audios/videos\n' +
            '• *.transcribir* / *.transcribe* → transcribe audios y videos\n\n' +
            '💡 Podés agregar una instrucción para que la IA trabaje con el contenido:\n' +
            '_.leer resumilo en 3 puntos_'
        );
    }

    const kind = clasificar(archivo.mime, archivo.fileName);

    if (kind === 'imagen') {
        return await message.reply('⚠️ Las imágenes no están soportadas. Respondé a un archivo de texto, audio o video.');
    }

    try {
        await message.reply(kind === 'doc' ? '📖 _Leyendo archivo..._' : '🎧 _Transcribiendo..._');
    } catch (_) {}

    let buffer;
    try {
        buffer = await archivo.getBuffer();
    } catch (e) {
        console.error('[transcribir] No se pudo descargar:', e.message);
        return await message.reply('⚠️ No pude descargar el archivo. Intentá de nuevo.');
    }

    if (!buffer || !buffer.length) {
        return await message.reply('⚠️ El archivo está vacío o no se pudo descargar.');
    }

    // ── Archivos de texto ──
    if (kind === 'doc') {
        if (buffer.length > MAX_TEXT_BYTES) {
            return await message.reply(`⚠️ El archivo es muy grande (${formatoTamano(buffer.length)}). El máximo es ${formatoTamano(MAX_TEXT_BYTES)}.`);
        }

        const contenido = bufferATexto(buffer, archivo.fileName, archivo.mime);
        if (contenido === null) {
            return await message.reply('⚠️ Ese archivo no parece contener texto legible (es binario, como PDF, Word, zip, etc.).');
        }
        if (!contenido.trim()) {
            return await message.reply('⚠️ El archivo no tiene contenido.');
        }

        const nombre = archivo.fileName || 'archivo';

        // Con instrucción: la IA trabaja con el contenido
        if (instruccion) {
            try {
                const respuesta = await pedirIA(instruccion, `Contenido del archivo "${nombre}"`, contenido.slice(0, MAX_AI_CHARS));
                const extra = contenido.length > MAX_AI_CHARS
                    ? `\n\n_⚠️ El archivo es largo: solo se analizaron los primeros ${MAX_AI_CHARS} caracteres._`
                    : '';
                return await message.reply(respuesta + extra);
            } catch (e) {
                console.error('[transcribir] IA falló:', e.message);
                return await message.reply('⚠️ No pude procesar el archivo con la IA en este momento. Intentá de nuevo más tarde.');
            }
        }

        // Sin instrucción: mostrar el contenido
        const lineas = contenido.split('\n').length;
        const trozos = partir(contenido, WA_CHUNK);
        const mostrados = trozos.slice(0, MAX_CHUNKS);

        for (let i = 0; i < mostrados.length; i++) {
            let msg = '';
            if (i === 0) {
                msg += `📄 *${nombre}*\n_${lineas} líneas · ${formatoTamano(buffer.length)}_\n\n`;
            }
            msg += '```' + seguro(mostrados[i]) + '```';
            if (i === mostrados.length - 1 && trozos.length > MAX_CHUNKS) {
                msg += `\n\n_⚠️ Archivo largo: se muestran ${MAX_CHUNKS} de ${trozos.length} partes. Usá *.leer <instrucción>* para que la IA lo resuma._`;
            }
            await message.reply(msg);
        }
        return;
    }

    // ── Audio / video ──
    let audio = buffer;
    let mime = archivo.mime;

    // Los videos (o audios pesados) se pasan a mp3 liviano si hay ffmpeg disponible
    if (kind === 'video' || buffer.length > 20 * 1024 * 1024) {
        const mp3 = await convertirAMp3(buffer);
        if (mp3 && mp3.length) {
            audio = mp3;
            mime = 'audio/mpeg';
        }
    }

    if (audio.length > MAX_AUDIO_BYTES) {
        return await message.reply(
            `⚠️ El archivo es muy pesado (${formatoTamano(audio.length)}). El máximo es ${formatoTamano(MAX_AUDIO_BYTES)}.` +
            (audio === buffer ? '\n_Tip: instalando ffmpeg en el servidor, el bot comprime el audio automáticamente._' : '')
        );
    }

    let transcripcion;
    try {
        transcripcion = await transcribirAudio(audio, mime, audio === buffer ? kind : 'audio');
    } catch (e) {
        console.error('[transcribir] Transcripción falló:', e.message);
        if (/claves Groq/i.test(e.message)) {
            return await message.reply('⚠️ No hay claves de Groq configuradas para transcribir.');
        }
        return await message.reply('⚠️ No pude transcribir el audio en este momento. Intentá de nuevo más tarde.');
    }

    if (!transcripcion) {
        return await message.reply('🔇 No detecté voz en el audio.');
    }

    const icono = kind === 'video' ? '🎬' : '🎙️';
    const trozos = partir(transcripcion, WA_CHUNK);
    for (let i = 0; i < trozos.length; i++) {
        const encabezado = i === 0 ? `${icono} *Transcripción:*\n\n` : '';
        await message.reply(encabezado + trozos[i]);
    }

    // Con instrucción: además la IA trabaja con la transcripción
    if (instruccion) {
        try {
            const respuesta = await pedirIA(instruccion, 'Transcripción del audio', transcripcion.slice(0, MAX_AI_CHARS));
            await message.reply(respuesta);
        } catch (e) {
            console.error('[transcribir] IA falló:', e.message);
            await message.reply('⚠️ La transcripción salió bien, pero no pude procesarla con la IA en este momento.');
        }
    }
};

handler.help = ['leer', 'transcribir', 'transcribe'];
handler.tags = ['tools', 'ia'];
handler.command = /^(leer|read|transcribir|transcribe|transcripcion|transcripción|transcrip|stt)$/i;
handler.transcribirAudio = transcribirAudio;

module.exports = handler;
