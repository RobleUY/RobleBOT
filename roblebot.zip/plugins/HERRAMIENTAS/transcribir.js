const https = require('https');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

// Baileys (solo se usa para descargar media si el mensaje no trae .download())
let baileys = null;
for (const name of ['@whiskeysockets/baileys', '@adiwajshing/baileys', 'baileys']) {
    try { baileys = require(name); break; } catch (_) {}
}

// Circuit breaker global de red (accesible via global.networkGuard si está disponible)
function getNetGuard() { return (typeof global !== 'undefined' && global.networkGuard) ? global.networkGuard : null; }

// ─── Configuración ────────────────────────────────────────────────────────────
const TIMEOUT_CHAT = 25000;
const TIMEOUT_STT = 90000;
const MAX_TEXT_BYTES = 2 * 1024 * 1024;     // 2 MB para archivos de texto
const MAX_AUDIO_BYTES = 24 * 1024 * 1024;   // Groq permite ~25 MB por archivo
const WA_CHUNK = 3500;                      // caracteres por mensaje de WhatsApp
const MAX_CHUNKS = 6;                       // máximo de mensajes al mostrar un archivo
const MAX_AI_CHARS = 12000;                 // contenido máximo que se le pasa a la IA (Groq)
const MAX_DELIRIUS_CHARS = 3000;            // Delirius usa GET, la URL no admite textos largos
const CLEAN_CHUNK = 6000;                   // caracteres por bloque al limpiar una transcripción

// Modelos para consultas generales (instrucciones del usuario)
const MODEL_LIST = [
    'openai/gpt-oss-20b',
    'openai/gpt-oss-120b',
    'qwen/qwen3-32b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'llama-3.3-70b-versatile',
    'llama-3.3-8b-instant',
    'llama-3.1-8b-instant'
];

// Modelos para limpiar transcripciones: rápidos y sin "razonamiento" (gastan menos tiempo y tokens)
const CLEAN_MODELS = [
    'llama-3.3-70b-versatile',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'llama-3.1-8b-instant'
];

const STT_MODELS = ['whisper-large-v3-turbo', 'whisper-large-v3'];

const SYSTEM_PROMPT = `
Nombre: RobleBOT
Rol: Asistente de WhatsApp
Creador: Dev RobleUY (Desarrollador uruguayo)
Idioma: Español

Reglas de formato y comportamiento:
- Formato WhatsApp: Usa *negrita* (NUNCA **negrita**), _cursiva_, ~tachado~ y \`\`\`código\`\`\`.
- Estilo: Mensajes claros, útiles y amigables, con pocos emojis.
- Tarea: El usuario te pasa el contenido de un archivo o la transcripción de un audio/video junto con una instrucción. Respondé a esa instrucción basándote solo en ese contenido.
- Longitud: Sé conciso, salvo que el usuario pida una respuesta detallada.
`.trim();

// Prompt que ordena y puntúa la transcripción cruda de Whisper
const CLEAN_SYSTEM = `
Sos un corrector profesional de transcripciones de audio en español rioplatense. Recibís el texto crudo que devolvió un modelo de reconocimiento de voz (sin puntuación confiable y a veces con símbolos raros) y devolvés ese mismo contenido bien escrito.

Primero decidí qué tipo de audio es:
- CANCION: es la letra de una canción o parte de ella (versos cortos, rimas, estribillos, repeticiones rítmicas, lenguaje poético).
- AUDIO: es una persona hablando (nota de voz, conversación, mensaje, clase, noticia, etc.).

Tu respuesta SIEMPRE empieza con una primera línea exacta: TIPO: CANCION o TIPO: AUDIO. Desde la segunda línea va solo el texto corregido.

Reglas para AUDIO:
- Armá oraciones completas con puntos, comas, punto y coma y dos puntos donde corresponda.
- Usá los signos de apertura y cierre ¿? y ¡! cuando haya preguntas o exclamaciones.
- Mayúscula al iniciar oraciones y en nombres propios.
- Agrupá las ideas en párrafos cortos (2 a 4 oraciones) separados por una línea en blanco. Si es muy corto, un solo párrafo.
- Eliminá tartamudeos y repeticiones accidentales de una palabra ("yo yo yo fui" pasa a "yo fui"), pero conservá el resto de las palabras tal cual.

Reglas para CANCION:
- Un verso por línea, con la primera letra en mayúscula.
- Línea en blanco entre estrofas y antes de cada estribillo repetido.
- Puntuación mínima: comas y signos ¿? ¡! solo cuando hagan falta; sin punto al final de cada verso.
- Conservá TODAS las repeticiones, porque son parte de la letra.

Reglas para ambos:
- Mantené el idioma original. No traduzcas, no resumas, no agregues ni inventes palabras y no completes lo que no se entiende.
- Corregí ortografía, tildes y palabras cortadas o unidas por error, sin cambiar el sentido.
- Mantené las palabras tal como se dijeron (modismos, lunfardo y groserías incluidas).
- PROHIBIDO: emojis, símbolos musicales (♪ ♫), asteriscos, comillas decorativas, viñetas, títulos, markdown, anotaciones como [Música] o (risas) y cualquier comentario tuyo.
- Respondé únicamente con la línea TIPO y el texto corregido.
`.trim();

// Extensiones que se tratan siempre como texto
const TEXT_EXTENSIONS = new Set([
    'txt', 'text', 'log', 'md', 'markdown', 'rst', 'csv', 'tsv',
    'yml', 'yaml', 'json', 'jsonc', 'json5', 'xml', 'toml', 'ini', 'cfg', 'conf', 'config',
    'env', 'properties', 'gitignore', 'dockerfile', 'lock',
    'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx', 'html', 'htm', 'css', 'scss', 'less', 'vue',
    'py', 'java', 'kt', 'c', 'h', 'cpp', 'hpp', 'cs', 'go', 'rs', 'rb', 'php', 'lua', 'swift',
    'sh', 'bash', 'zsh', 'bat', 'cmd', 'ps1', 'sql', 'srt', 'vtt', 'lrc'
]);

// Frases típicas que Whisper inventa en los silencios
const ALUCINACIONES = /(subt[ií]tulos?\s+(realizados|por|de|creados)|amara\.org|gracias por ver|suscr[ií]bete|no olvides suscribirte|thanks for watching|subtitles by|www\.)/i;

// ─── Claves Groq ──────────────────────────────────────────────────────────────
function collectGroqApiKeys() {
    const keys = new Set();
    const keyPattern = /^groq_api_key(?:\d*)?$/i;

    for (const name of Object.keys(process.env)) {
        if (!keyPattern.test(name)) continue;
        const value = process.env[name];
        if (value && typeof value === 'string') {
            const trimmed = value.trim();
            if (trimmed) keys.add(trimmed);
        }
    }

    return Array.from(keys);
}

// ─── IA de texto (Groq + Delirius) ────────────────────────────────────────────
async function callGroq(systemPrompt, userText, opts = {}) {
    const { models = MODEL_LIST, maxTokens = 1000, temperature = 0.7 } = opts;

    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) {
        throw new Error('No hay claves Groq configuradas');
    }

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        const apiKey = apiKeys[keyIndex];
        for (let modelIndex = 0; modelIndex < models.length; modelIndex++) {
            const model = models[modelIndex];
            try {
                return await groqRequest(apiKey, model, systemPrompt, userText, { maxTokens, temperature });
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[transcribir] Groq key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
            }
        }
    }

    throw lastErr || new Error('Groq falló');
}

function groqRequest(apiKey, model, systemPrompt, userText, { maxTokens, temperature }) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({
            model,
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userText }
            ],
            max_tokens: maxTokens,
            temperature,
            top_p: 0.95
        });

        const options = {
            hostname: 'api.groq.com',
            path: '/openai/v1/chat/completions',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'Content-Length': Buffer.byteLength(body)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    const content = parsed.choices?.[0]?.message?.content?.trim();
                    if (!content) return reject(new Error('Respuesta vacía de Groq'));
                    resolve(content);
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT_CHAT, () => {
            req.destroy();
            reject(new Error('Timeout Groq'));
        });

        req.write(body);
        req.end();
    });
}

function httpGet(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { timeout: TIMEOUT_CHAT }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch { reject(new Error('Error parseando respuesta')); }
            });
        });
        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    });
}

async function deliriusGptPrompt(systemPrompt, userText) {
    const url = `https://api.delirius.online/ia/gptprompt?text=${encodeURIComponent(userText)}&prompt=${encodeURIComponent(systemPrompt)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gptprompt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gptprompt: sin contenido');
    return text.trim();
}

async function deliriusGemini(systemPrompt, userText) {
    const query = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/gemini?query=${encodeURIComponent(query)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius gemini: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius gemini: sin contenido');
    return text.trim();
}

async function deliriusChatgpt(systemPrompt, userText) {
    const q = `${systemPrompt}. ${userText}`;
    const url = `https://api.delirius.online/ia/chatgpt?q=${encodeURIComponent(q)}`;
    const json = await httpGet(url);
    if (!json.status) throw new Error('delirius chatgpt: status false');
    const text = typeof json.data === 'string' ? json.data : json.data?.result;
    if (!text) throw new Error('delirius chatgpt: sin contenido');
    return text.trim();
}

// Todas las IAs en paralelo, gana la más rápida (para instrucciones del usuario)
async function callIA(systemPrompt, userText) {
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) {
        console.warn('[transcribir] Red caída (circuit breaker activo) — omitiendo peticiones IA.');
        throw new Error('_SILENT_FAIL_');
    }

    // Delirius va por GET: se le pasa una versión recortada del texto
    const textoCorto = userText.length > MAX_DELIRIUS_CHARS
        ? userText.slice(0, MAX_DELIRIUS_CHARS) + '\n[...contenido recortado...]'
        : userText;

    const attempts = [
        callGroq(systemPrompt, userText.slice(0, MAX_AI_CHARS)),
        deliriusGptPrompt(systemPrompt, textoCorto),
        deliriusGemini(systemPrompt, textoCorto),
        deliriusChatgpt(systemPrompt, textoCorto)
    ];

    const names = ['Groq', 'Delirius-gptprompt', 'Delirius-gemini', 'Delirius-chatgpt'];
    const labeled = attempts.map((p, i) => p.catch(e => {
        console.warn(`[transcribir] ${names[i]} falló:`, e.message);
        throw e;
    }));

    try {
        return await Promise.any(labeled);
    } catch (aggregateErr) {
        const details = Array.isArray(aggregateErr?.errors)
            ? aggregateErr.errors.map(e => e.message).join(' | ')
            : aggregateErr.message;
        console.error('[transcribir] Todas las IAs fallaron:', details);
        throw new Error('_SILENT_FAIL_');
    }
}

// ─── Transcripción (Groq Whisper) ─────────────────────────────────────────────
// Nota: las APIs de Delirius de ia.js son solo de texto, no transcriben audio.
// La transcripción usa las mismas claves de Groq (GROQ_API_KEY, GROQ_API_KEY2...).
function extensionPara(mime, kind) {
    const m = (mime || '').toLowerCase();
    if (m.includes('ogg') || m.includes('opus')) return 'ogg';
    if (m.includes('mpeg') || m.includes('mp3')) return 'mp3';
    if (m.includes('wav')) return 'wav';
    if (m.includes('webm')) return 'webm';
    if (m.includes('flac')) return 'flac';
    if (m.includes('m4a') || m.includes('aac') || m.includes('mp4')) return kind === 'video' ? 'mp4' : 'm4a';
    return kind === 'video' ? 'mp4' : 'ogg';
}

function groqTranscribeRequest(apiKey, model, audio, filename, mime) {
    return new Promise((resolve, reject) => {
        const boundary = '----RobleBOT' + Date.now().toString(16) + Math.random().toString(16).slice(2);
        const parts = [];
        const campo = (name, value) => parts.push(Buffer.from(
            `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`
        ));

        campo('model', model);
        campo('response_format', 'verbose_json'); // devuelve segmentos y métricas de confianza
        campo('temperature', '0');
        parts.push(Buffer.from(
            `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\n` +
            `Content-Type: ${mime}\r\n\r\n`
        ));
        parts.push(audio);
        parts.push(Buffer.from(`\r\n--${boundary}--\r\n`));

        const body = Buffer.concat(parts);

        const req = https.request({
            hostname: 'api.groq.com',
            path: '/openai/v1/audio/transcriptions',
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': `multipart/form-data; boundary=${boundary}`,
                'Content-Length': body.length
            }
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    if (parsed.error) {
                        const err = new Error(parsed.error.message || 'Error Groq STT');
                        err.statusCode = res.statusCode;
                        return reject(err);
                    }
                    if (typeof parsed.text !== 'string') return reject(new Error('Respuesta vacía de Groq STT'));
                    resolve(parsed);
                } catch (parseErr) {
                    reject(new Error('Error parseando respuesta de Groq STT'));
                }
            });
        });

        req.on('error', (err) => {
            const ng = getNetGuard();
            if (ng) ng.reportNetworkError(err);
            reject(err);
        });
        req.setTimeout(TIMEOUT_STT, () => {
            req.destroy();
            reject(new Error('Timeout Groq STT'));
        });

        req.write(body);
        req.end();
    });
}

// Convierte la respuesta de Whisper en líneas de texto, descartando alucinaciones y ruido
function procesarSegmentos(parsed) {
    const segs = Array.isArray(parsed.segments) ? parsed.segments : [];
    let lineas = [];

    if (segs.length) {
        for (const s of segs) {
            const t = (s.text || '').trim();
            if (!t) continue;
            if ((s.no_speech_prob > 0.6 && s.avg_logprob < -1) || s.compression_ratio > 2.4) continue;
            if (ALUCINACIONES.test(t) && (s.no_speech_prob > 0.2 || s.avg_logprob < -0.8)) continue;
            lineas.push(t);
        }
    } else if (parsed.text) {
        lineas = parsed.text.split(/\n+/).map(x => x.trim()).filter(Boolean);
    }

    return { lineas, idioma: parsed.language || '' };
}

async function transcribirAudio(buffer, mime, kind) {
    const ng = getNetGuard();
    if (ng && ng.isNetworkDown()) throw new Error('_SILENT_FAIL_');

    const apiKeys = collectGroqApiKeys();
    if (apiKeys.length === 0) throw new Error('No hay claves Groq configuradas');

    const cleanMime = (mime || 'audio/ogg').split(';')[0].trim() || 'audio/ogg';
    const filename = `audio.${extensionPara(mime, kind)}`;

    let lastErr = null;
    for (let keyIndex = 0; keyIndex < apiKeys.length; keyIndex++) {
        for (const model of STT_MODELS) {
            try {
                const parsed = await groqTranscribeRequest(apiKeys[keyIndex], model, buffer, filename, cleanMime);
                return procesarSegmentos(parsed);
            } catch (e) {
                lastErr = e;
                const isRateLimit = e.statusCode === 429 || /rate.?limit|quota/i.test(e.message || '');
                const isAuthError = e.statusCode === 401 || e.statusCode === 403;
                console.warn(`[transcribir] Groq STT key #${keyIndex + 1} modelo ${model} falló: ${e.message}`);
                if (!isRateLimit && !isAuthError) throw e;
            }
        }
    }

    throw lastErr || new Error('Groq STT falló');
}

// ─── Limpieza inteligente de la transcripción ─────────────────────────────────
// Quita emojis, símbolos musicales, markdown y anotaciones tipo [Música]
function limpiarSimbolos(texto) {
    return (texto || '')
        .replace(/[\[(]\s*(m[uú]sica|music|aplausos|applause|risas|laughter|silencio|ruido|canta|cantando|singing)[^\])]*[\])]/gi, '')
        .replace(/[♪♫♬♩♭♯]/g, '')
        .replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '')
        .replace(/[*_~`#]+/g, '')
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .replace(/[ \t]+/g, ' ')
        .split('\n').map(l => l.trim()).join('\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// Formato mínimo si la IA no está disponible
function formatoBasico(texto) {
    let t = texto.replace(/\s*\n\s*/g, ' ').trim();
    if (!t) return t;
    t = t.charAt(0).toUpperCase() + t.slice(1);
    if (!/[.!?…]$/.test(t)) t += '.';
    return t;
}

// Separa "TIPO: X" del texto corregido
function parsearSalida(salida) {
    let texto = salida.trim();
    let tipo = 'audio';

    const m = texto.match(/^\s*TIPO\s*:\s*(CANCI[OÓ]N|AUDIO)\s*\n?/i);
    if (m) {
        tipo = /CANCI/i.test(m[1]) ? 'cancion' : 'audio';
        texto = texto.slice(m[0].length);
    }

    // Por si el modelo agrega un saludo o comentario inicial
    texto = texto.replace(/^(aqu[ií]\s+(est[aá]|tienes|va)|claro|por supuesto|listo|here is)[^\n]*\n+/i, '');

    return { texto: texto.trim(), tipo };
}

async function limpiarBloque(bloque) {
    const usuario = `Texto crudo (cada línea es un fragmento sin puntuación confiable):\n"""\n${bloque}\n"""`;

    try {
        return await callGroq(CLEAN_SYSTEM, usuario, { models: CLEAN_MODELS, maxTokens: 3500, temperature: 0.2 });
    } catch (e) {
        // Respaldo con Delirius solo si el texto entra en una URL GET
        if (usuario.length + CLEAN_SYSTEM.length > MAX_DELIRIUS_CHARS) throw e;
        console.warn('[transcribir] Groq no pudo limpiar, probando Delirius:', e.message);
        try {
            return await Promise.any([
                deliriusGptPrompt(CLEAN_SYSTEM, usuario),
                deliriusGemini(CLEAN_SYSTEM, usuario),
                deliriusChatgpt(CLEAN_SYSTEM, usuario)
            ]);
        } catch (agg) {
            throw new Error(Array.isArray(agg?.errors) ? agg.errors.map(x => x.message).join(' | ') : agg.message);
        }
    }
}

// Devuelve { texto, tipo } con la transcripción ordenada. Nunca lanza error:
// si la IA falla, devuelve un formato básico del texto crudo.
async function limpiarTranscripcion(lineas) {
    const bloques = [];
    let actual = '';
    for (const l of lineas) {
        if (actual && (actual.length + l.length + 1) > CLEAN_CHUNK) {
            bloques.push(actual);
            actual = '';
        }
        actual += (actual ? '\n' : '') + l;
    }
    if (actual) bloques.push(actual);

    // Los bloques se procesan en paralelo para que los audios largos sigan siendo rápidos
    const resultados = await Promise.all(bloques.map(async (bloque) => {
        const crudo = limpiarSimbolos(bloque);
        const crudoPlano = crudo.replace(/\s*\n\s*/g, ' ');

        if (crudoPlano.replace(/\s/g, '').length < 25) {
            return { texto: formatoBasico(crudo), tipo: 'audio', peso: crudo.length };
        }

        try {
            const salida = await limpiarBloque(bloque);
            const { texto, tipo } = parsearSalida(salida);
            const limpio = limpiarSimbolos(texto);

            // Control de seguridad: si la IA resumió o inventó de más, se descarta
            const ratio = limpio.replace(/\s/g, '').length / Math.max(1, crudoPlano.replace(/\s/g, '').length);
            if (!limpio || ratio < 0.6 || ratio > 1.5) {
                throw new Error(`salida sospechosa (ratio ${ratio.toFixed(2)})`);
            }
            return { texto: limpio, tipo, peso: crudo.length };
        } catch (e) {
            console.warn('[transcribir] Limpieza con IA falló, uso formato básico:', e.message);
            return { texto: formatoBasico(crudo), tipo: 'audio', peso: crudo.length };
        }
    }));

    let pesoCancion = 0;
    let pesoAudio = 0;
    for (const r of resultados) {
        if (r.tipo === 'cancion') pesoCancion += r.peso;
        else pesoAudio += r.peso;
    }

    return {
        texto: resultados.map(r => r.texto).join('\n\n').trim(),
        tipo: pesoCancion > pesoAudio ? 'cancion' : 'audio'
    };
}

// Convierte audio/video a mp3 mono liviano con ffmpeg (opcional: si no está instalado devuelve null)
function convertirAMp3(buffer) {
    return new Promise((resolve) => {
        const id = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
        const inp = path.join(os.tmpdir(), `stt_${id}.in`);
        const out = path.join(os.tmpdir(), `stt_${id}.mp3`);
        const limpiar = () => { for (const f of [inp, out]) fs.unlink(f, () => {}); };

        fs.writeFile(inp, buffer, (err) => {
            if (err) { limpiar(); return resolve(null); }
            execFile(
                'ffmpeg',
                ['-y', '-i', inp, '-vn', '-ac', '1', '-ar', '16000', '-b:a', '48k', out],
                { timeout: 120000 },
                (e) => {
                    if (e) { limpiar(); return resolve(null); }
                    fs.readFile(out, (e2, data) => { limpiar(); resolve(e2 ? null : data); });
                }
            );
        });
    });
}

// ─── Obtener el archivo del mensaje (citado o propio) ─────────────────────────
// ⚠️ Esta es la parte que depende de cómo tu bot serializa los mensajes.
// Soporta: message.quoted.download() / message.download() (estilo "serialize"),
// y mensajes crudos de Baileys. Si tu bot usa otro método, ajustá solo esta sección.
const RAW_MEDIA_TYPES = ['audioMessage', 'videoMessage', 'ptvMessage', 'documentMessage', 'imageMessage', 'stickerMessage'];

function unwrap(msg) {
    let m = msg;
    for (let i = 0; i < 5 && m; i++) {
        const inner = m.ephemeralMessage?.message
            || m.viewOnceMessage?.message
            || m.viewOnceMessageV2?.message
            || m.documentWithCaptionMessage?.message
            || m.editedMessage?.message;
        if (!inner) break;
        m = inner;
    }
    return m;
}

function findRawMedia(rawMessage) {
    const m = unwrap(rawMessage);
    if (!m || typeof m !== 'object') return null;
    for (const type of RAW_MEDIA_TYPES) {
        if (m[type]) return { type, media: m[type] };
    }
    return null;
}

function quotedRaw(message) {
    const m = unwrap(message?.message);
    if (!m || typeof m !== 'object') return null;
    for (const value of Object.values(m)) {
        const q = value?.contextInfo?.quotedMessage;
        if (q) return q;
    }
    return null;
}

async function downloadRaw(type, media) {
    if (!baileys?.downloadContentFromMessage) throw new Error('Baileys no disponible para descargar el archivo');
    const mediaType = type === 'ptvMessage' ? 'video' : type.replace('Message', '');
    const stream = await baileys.downloadContentFromMessage(media, mediaType);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

function describirRaw(found) {
    const { type, media } = found;
    let mime = media.mimetype || '';
    if (!mime) {
        if (type === 'audioMessage') mime = 'audio/ogg';
        else if (type === 'videoMessage' || type === 'ptvMessage') mime = 'video/mp4';
        else if (type === 'imageMessage' || type === 'stickerMessage') mime = 'image/jpeg';
    }
    return {
        mime,
        fileName: media.fileName || media.title || '',
        getBuffer: () => downloadRaw(type, media)
    };
}

function describirSerializado(c) {
    if (!c || typeof c !== 'object') return null;

    // mtype + msg (estilo Baileys "smsg")
    const mtype = c.mtype;
    const inner = c.msg;
    const mime = c.mimetype || inner?.mimetype || '';
    const fileName = c.fileName || inner?.fileName || '';

    if (typeof c.download === 'function' && (mime || RAW_MEDIA_TYPES.includes(mtype))) {
        let m = mime;
        if (!m) {
            if (mtype === 'audioMessage') m = 'audio/ogg';
            else if (mtype === 'videoMessage' || mtype === 'ptvMessage') m = 'video/mp4';
        }
        return { mime: m, fileName, getBuffer: () => c.download() };
    }

    if (RAW_MEDIA_TYPES.includes(mtype) && inner) {
        return describirRaw({ type: mtype, media: inner });
    }

    const raw = findRawMedia(c.message);
    if (raw) return describirRaw(raw);

    return null;
}

function resolverArchivo(message) {
    // 1) mensaje citado (serializado), 2) mensaje citado crudo, 3) el propio mensaje (media con caption .leer)
    const quoted = message.quoted || message.reply_message;
    const fromQuoted = describirSerializado(quoted);
    if (fromQuoted) return fromQuoted;

    const rawQuoted = findRawMedia(quotedRaw(message));
    if (rawQuoted) return describirRaw(rawQuoted);

    const fromSelf = describirSerializado(message);
    if (fromSelf) return fromSelf;

    const rawSelf = findRawMedia(message.message);
    if (rawSelf) return describirRaw(rawSelf);

    return null;
}

// ─── Utilidades ───────────────────────────────────────────────────────────────
function clasificar(mime) {
    const m = (mime || '').toLowerCase();
    if (m.startsWith('audio/')) return 'audio';
    if (m.startsWith('video/')) return 'video';
    if (m.startsWith('image/')) return 'imagen';
    return 'doc';
}

function extDe(fileName) {
    const base = (fileName || '').toLowerCase();
    const idx = base.lastIndexOf('.');
    if (idx === -1) return base.replace(/^\./, '');
    return base.slice(idx + 1);
}

// Devuelve el texto si el buffer parece texto, o null si es binario
function bufferATexto(buffer, fileName, mime) {
    const ext = extDe(fileName);
    const m = (mime || '').toLowerCase();
    const esTextoDeclarado = TEXT_EXTENSIONS.has(ext)
        || m.startsWith('text/')
        || /json|xml|yaml|javascript|x-sh|x-yaml|toml|csv/.test(m);

    const muestra = buffer.subarray(0, 8000);
    if (muestra.includes(0)) return null; // bytes nulos → binario

    let texto = buffer.toString('utf8');
    if (texto.charCodeAt(0) === 0xFEFF) texto = texto.slice(1);

    const malos = (texto.match(/\uFFFD/g) || []).length;
    const ratio = texto.length ? malos / texto.length : 0;
    if (ratio > (esTextoDeclarado ? 0.2 : 0.02)) return null;

    return texto.replace(/\r\n/g, '\n');
}

// Parte un texto largo en mensajes, cortando preferentemente en párrafos o saltos de línea
function partir(texto, max) {
    const out = [];
    let resto = texto;
    while (resto.length > max) {
        let corte = resto.lastIndexOf('\n\n', max);
        if (corte < max * 0.5) corte = resto.lastIndexOf('\n', max);
        if (corte < max * 0.5) corte = max;
        out.push(resto.slice(0, corte));
        resto = resto.slice(corte).replace(/^\n+/, '');
    }
    if (resto) out.push(resto);
    return out;
}

function formatoTamano(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

const seguro = (t) => t.replace(/```/g, "'''");

async function pedirIA(instruccion, etiqueta, contenido) {
    const prompt = `Instrucción del usuario: ${instruccion}\n\n${etiqueta}:\n"""\n${contenido}\n"""`;
    return await callIA(SYSTEM_PROMPT, prompt);
}

// ─── Handler principal ────────────────────────────────────────────────────────
let handler = async (message, { text } = {}) => {
    const instruccion = (text || '').trim();

    let archivo = null;
    try {
        archivo = resolverArchivo(message);
    } catch (e) {
        console.warn('[transcribir] Error resolviendo archivo:', e.message);
    }

    if (!archivo) {
        return await message.reply(
            '⚠️ *Uso correcto:*\n' +
            'Respondé a un archivo, audio o video con:\n' +
            '• *.leer* → lee archivos de texto (txt, yml, json, js...) o transcribe audios/videos\n' +
            '• *.transcribir* / *.transcribe* → transcribe audios y videos\n\n' +
            '💡 Podés agregar una instrucción para que la IA trabaje con el contenido:\n' +
            '_.leer resumilo en 3 puntos_'
        );
    }

    const kind = clasificar(archivo.mime);

    if (kind === 'imagen') {
        return await message.reply('⚠️ Las imágenes no están soportadas. Respondé a un archivo de texto, audio o video.');
    }

    try {
        await message.reply(kind === 'doc' ? '📖 _Leyendo archivo..._' : '🎧 _Transcribiendo..._');
    } catch (_) {}

    let buffer;
    try {
        buffer = await archivo.getBuffer();
    } catch (e) {
        console.error('[transcribir] No se pudo descargar:', e.message);
        return await message.reply('⚠️ No pude descargar el archivo. Intentá de nuevo.');
    }

    if (!buffer || !buffer.length) {
        return await message.reply('⚠️ El archivo está vacío o no se pudo descargar.');
    }

    // ── Archivos de texto ──
    if (kind === 'doc') {
        if (buffer.length > MAX_TEXT_BYTES) {
            return await message.reply(`⚠️ El archivo es muy grande (${formatoTamano(buffer.length)}). El máximo es ${formatoTamano(MAX_TEXT_BYTES)}.`);
        }

        const contenido = bufferATexto(buffer, archivo.fileName, archivo.mime);
        if (contenido === null) {
            return await message.reply('⚠️ Ese archivo no parece contener texto legible (es binario, como PDF, Word, zip, etc.).');
        }
        if (!contenido.trim()) {
            return await message.reply('⚠️ El archivo no tiene contenido.');
        }

        const nombre = archivo.fileName || 'archivo';

        // Con instrucción: la IA trabaja con el contenido
        if (instruccion) {
            try {
                const respuesta = await pedirIA(instruccion, `Contenido del archivo "${nombre}"`, contenido.slice(0, MAX_AI_CHARS));
                const extra = contenido.length > MAX_AI_CHARS
                    ? `\n\n_⚠️ El archivo es largo: solo se analizaron los primeros ${MAX_AI_CHARS} caracteres._`
                    : '';
                return await message.reply(respuesta + extra);
            } catch (e) {
                console.error('[transcribir] IA falló:', e.message);
                return await message.reply('⚠️ No pude procesar el archivo con la IA en este momento. Intentá de nuevo más tarde.');
            }
        }

        // Sin instrucción: mostrar el contenido
        const lineas = contenido.split('\n').length;
        const trozos = partir(contenido, WA_CHUNK);
        const mostrados = trozos.slice(0, MAX_CHUNKS);

        for (let i = 0; i < mostrados.length; i++) {
            let msg = '';
            if (i === 0) {
                msg += `📄 *${nombre}*\n_${lineas} líneas · ${formatoTamano(buffer.length)}_\n\n`;
            }
            msg += '```' + seguro(mostrados[i]) + '```';
            if (i === mostrados.length - 1 && trozos.length > MAX_CHUNKS) {
                msg += `\n\n_⚠️ Archivo largo: se muestran ${MAX_CHUNKS} de ${trozos.length} partes. Usá *.leer <instrucción>* para que la IA lo resuma._`;
            }
            await message.reply(msg);
        }
        return;
    }

    // ── Audio / video ──
    let audio = buffer;
    let mime = archivo.mime;

    // Los videos (o audios pesados) se pasan a mp3 liviano si hay ffmpeg disponible
    if (kind === 'video' || buffer.length > 20 * 1024 * 1024) {
        const mp3 = await convertirAMp3(buffer);
        if (mp3 && mp3.length) {
            audio = mp3;
            mime = 'audio/mpeg';
        }
    }

    if (audio.length > MAX_AUDIO_BYTES) {
        return await message.reply(
            `⚠️ El archivo es muy pesado (${formatoTamano(audio.length)}). El máximo es ${formatoTamano(MAX_AUDIO_BYTES)}.` +
            (audio === buffer ? '\n_Tip: instalando ffmpeg en el servidor, el bot comprime el audio automáticamente._' : '')
        );
    }

    let resultado;
    try {
        resultado = await transcribirAudio(audio, mime, audio === buffer ? kind : 'audio');
    } catch (e) {
        console.error('[transcribir] Transcripción falló:', e.message);
        if (/claves Groq/i.test(e.message)) {
            return await message.reply('⚠️ No hay claves de Groq configuradas para transcribir.');
        }
        return await message.reply('⚠️ No pude transcribir el audio en este momento. Intentá de nuevo más tarde.');
    }

    if (!resultado.lineas.length) {
        return await message.reply('🔇 No detecté voz en el audio.');
    }

    // La IA ordena el texto: puntuación, párrafos, canción vs audio normal y sin símbolos raros
    const { texto, tipo } = await limpiarTranscripcion(resultado.lineas);

    if (!texto) {
        return await message.reply('🔇 No detecté voz en el audio.');
    }

    const encabezado = tipo === 'cancion'
        ? '🎵 *Letra transcrita:*'
        : `${kind === 'video' ? '🎬' : '🎙️'} *Transcripción:*`;

    const trozos = partir(texto, WA_CHUNK);
    for (let i = 0; i < trozos.length; i++) {
        await message.reply((i === 0 ? `${encabezado}\n\n` : '') + trozos[i]);
    }

    // Con instrucción: además la IA trabaja con la transcripción ya ordenada
    if (instruccion) {
        try {
            const respuesta = await pedirIA(instruccion, 'Transcripción del audio', texto.slice(0, MAX_AI_CHARS));
            await message.reply(respuesta);
        } catch (e) {
            console.error('[transcribir] IA falló:', e.message);
            await message.reply('⚠️ La transcripción salió bien, pero no pude procesarla con la IA en este momento.');
        }
    }
};

handler.help = ['leer', 'transcribir', 'transcribe'];
handler.tags = ['tools', 'ia'];
handler.command = /^(leer|read|transcribir|transcribe|transcripcion|transcripción|transcrip|stt)$/i;
handler.transcribirAudio = transcribirAudio;
handler.limpiarTranscripcion = limpiarTranscripcion;

module.exports = handler;
