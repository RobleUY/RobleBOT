// stickers.js
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
// wa-sticker-formatter solo se usa para imágenes estáticas (no re-encodea tanto)
const { Sticker } = require('wa-sticker-formatter');
// node-webpmux: inyecta EXIF en WebP animado sin re-encodear
const { Image: WebPImage } = require('node-webpmux');
const execFileAsync = promisify(execFile);
const { runFFmpeg, limitMediaJob } = require('../../../lib/mediaLimiter');

/**
 * Obtiene el número del bot automáticamente
 */
function getBotNumber(sock) {
  try {
    let botJid = sock.user?.id || sock.user?.jid;
    if (!botJid) return null;
    
    // Eliminar todo después de ":" (como :1, :2, etc)
    botJid = botJid.split(":")[0];
    
    // Normalizar solo números
    return botJid.replace(/[^0-9]/g, '');
  } catch (error) {
    console.error('❌ Error al obtener número del bot:', error);
    return null;
  }
}

function tmpFileName(ext = '') {
  const name = crypto.randomBytes(10).toString('hex') + (ext ? `.${ext}` : '');
  return path.join(os.tmpdir(), name);
}

async function streamToBuffer(stream) {
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  return buffer;
}

/**
 * Detecta si el mensaje actual tiene una imagen o video.
 * @returns {object|null}
 */
async function detectCurrentMedia(baileyMsg = global.lastBaileyMessage) {
  try {
    console.log('🔍 Buscando medios en el mensaje actual...');
    if (!baileyMsg) {
      return null;
    }

    // Normalizar: baileys a veces envuelve en viewOnceMessage, ephemeralMessage, etc.
    const msg = baileyMsg.message;
    const inner =
      msg?.viewOnceMessage?.message ||
      msg?.viewOnceMessageV2?.message ||
      msg?.ephemeralMessage?.message ||
      msg?.documentWithCaptionMessage?.message ||
      msg;

    // imageMessage
    const imgMsg = inner?.imageMessage;
    if (imgMsg) {
      console.log('🖼️ Imagen detectada en el mensaje actual, descargando...');
      try {
        const stream = await downloadContentFromMessage(imgMsg, 'image');
        const buffer = await streamToBuffer(stream);
        return { data: buffer, mimetype: imgMsg.mimetype || 'image/jpeg', type: 'image' };
      } catch (err) {
        console.error('❌ Error descargando imagen actual:', err);
        return null;
      }
    }

    // videoMessage (incluye GIFs - gifPlayback = true)
    const vidMsg = inner?.videoMessage;
    if (vidMsg) {
      const isGif = !!vidMsg.gifPlayback;
      console.log(isGif ? '🎭 GIF detectado en el mensaje actual, descargando...' : '🎥 Video detectado en el mensaje actual, descargando...');
      try {
        const stream = await downloadContentFromMessage(vidMsg, 'video');
        const buffer = await streamToBuffer(stream);
        return { data: buffer, mimetype: vidMsg.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
      } catch (err) {
        console.error('❌ Error descargando video/gif actual:', err);
        return null;
      }
    }

    return null;
  } catch (error) {
    console.error('❌ Error general en detectCurrentMedia:', error);
    return null;
  }
}

/**
 * Detecta medios citados (respondiendo a un mensaje anterior).
 * @returns {object|null}
 */
async function detectQuotedMedia(baileyMsg = global.lastBaileyMessage) {
  try {
    console.log('🔍 Buscando mensaje citado...');
    if (!baileyMsg) {
      console.log('❌ No hay mensaje de @whiskeysockets/baileys guardado');
      return null;
    }

    let contextInfo = null;
    if (baileyMsg.message?.extendedTextMessage?.contextInfo) {
      contextInfo = baileyMsg.message.extendedTextMessage.contextInfo;
    } else if (baileyMsg.message?.imageMessage?.contextInfo) {
      contextInfo = baileyMsg.message.imageMessage.contextInfo;
    } else if (baileyMsg.message?.videoMessage?.contextInfo) {
      contextInfo = baileyMsg.message.videoMessage.contextInfo;
    }

    if (!contextInfo?.quotedMessage) {
      console.log('❌ No hay mensaje citado');
      return null;
    }

    const quotedMessage = contextInfo.quotedMessage;

    // stickerMessage (si el usuario respondió a un sticker)
    if (quotedMessage.stickerMessage) {
      console.log('🎟️ Sticker citado detectado, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.stickerMessage, 'sticker');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.stickerMessage.mimetype || 'image/webp',
          type: 'sticker'
        };
      } catch (err) {
        console.error('❌ Error descargando sticker citado:', err);
        return null;
      }
    }

    // imageMessage
    if (quotedMessage.imageMessage) {
      console.log('🖼️ Imagen citada detectada, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg',
          type: 'image'
        };
      } catch (err) {
        console.error('❌ Error descargando imagen citada:', err);
        return null;
      }
    }

    // videoMessage (incluye GIFs - gifPlayback = true)
    if (quotedMessage.videoMessage) {
      const isGif = !!quotedMessage.videoMessage.gifPlayback;
      console.log(isGif ? '🎭 GIF citado detectado, descargando...' : '🎥 Video citado detectado, descargando...');
      try {
        const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
        const buffer = await streamToBuffer(stream);
        return {
          data: buffer,
          mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4',
          type: isGif ? 'gif' : 'video'
        };
      } catch (err) {
        console.error('❌ Error descargando video/gif citado:', err);
        return null;
      }
    }

    console.log('❌ Tipo de mensaje citado no soportado');
    return null;
  } catch (error) {
    console.error('❌ Error general en detectQuotedMedia:', error);
    return null;
  }
}

/**
 * Intenta convertir buffer (video/gif) a WebP animado usando ffmpeg.
 * Si falla, lanza error y el llamador deberá hacer fallback.
 */
async function ffmpegConvertToAnimatedWebP(inputBuffer, isVideo = true) {
  const inputExt = isVideo ? 'mp4' : 'gif';
  const inputPath = tmpFileName(inputExt);
  const outputPath = tmpFileName('webp');

  try {
    await fs.writeFile(inputPath, inputBuffer);

    // Parámetros agresivos para mantener el sticker por debajo de ~1MB (límite de WhatsApp)
    // - Resolución 320x320: WA la escala igual, no hace falta 512
    // - fps 10: suficiente para animación fluida y mucho menos peso
    // - qscale 50: calidad media-baja, buen balance tamaño/calidad
    // - compression_level 6: compresión extra del contenedor WebP
    // - t 5: máximo 5 segundos (WA no acepta más de 6s de todas formas)
    const baseArgs = [
      '-y',
      '-t', '5',                          // máximo 5 segundos
      '-i', inputPath,
      '-vf', [
        'fps=10',                          // 10 fps: fluido y liviano
        'scale=320:320:flags=lanczos:force_original_aspect_ratio=decrease',
        'pad=320:320:(ow-iw)/2:(oh-ih)/2:color=0x00000000'  // padding transparente
      ].join(','),
      '-vcodec', 'libwebp',
      '-lossless', '0',
      '-qscale', '50',                    // calidad reducida (75 era demasiado pesado)
      '-compression_level', '4',          // compresión óptima de WebP (nivel 4 es 2-3x más rápido que nivel 6 con tamaño similar)
      '-preset', 'picture',               // mejor compresión que 'default'
      '-loop', '0',
      '-an',
      '-vsync', '0',
      outputPath
    ];

    return await limitMediaJob(async () => {
      await runFFmpeg(baseArgs, { timeout: 60_000 });
      const outBuffer = await fs.readFile(outputPath);
      console.log(`📦 WebP animado generado: ${(outBuffer.length / 1024).toFixed(1)} KB`);
      return outBuffer;
    });
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(outputPath).catch(()=>{})]);
  }
}

/**
 * Extrae primer frame con ffmpeg y devuelve buffer (imagen)
 */
async function ffmpegExtractFirstFrame(inputBuffer) {
  const inputPath = tmpFileName('mp4');
  const framePath = tmpFileName('jpg');
  try {
    await fs.writeFile(inputPath, inputBuffer);
    const args = [
      '-y',
      '-i', inputPath,
      '-ss', '0',
      '-vframes', '1',
      framePath
    ];
    await runFFmpeg(args, { timeout: 15_000 });
    const frameBuffer = await fs.readFile(framePath);
    return frameBuffer;
  } finally {
    await Promise.allSettled([fs.unlink(inputPath).catch(()=>{}), fs.unlink(framePath).catch(()=>{})]);
  }
}

async function convertToStickerFormat(mediaBuffer, mediaType, mimetype) {
  try {
    console.log(`🔄 Convirtiendo ${mediaType} a formato sticker...`);

    if (mediaType === 'sticker') {
      console.log('⚡ Es un sticker WebP ya - lo reenvío tal cual');
      return mediaBuffer; // ya está en webp
    }

    if (mediaType === 'image') {
      // imagen estática → webp estático (protegido por limitMediaJob con effort 3 para bajo consumo de CPU)
      return await limitMediaJob(async () => {
        const webpBuffer = await sharp(mediaBuffer)
          .resize(512, 512, { fit: 'contain', background: { r:255,g:255,b:255,alpha:0 } })
          .webp({ quality: 85, lossless: false, effort: 3 })
          .toBuffer();
        console.log('✅ Imagen convertida a WebP estático');
        return webpBuffer;
      });
    }

    // gif o video: intento crear webp animado con ffmpeg
    if (mediaType === 'gif' || mediaType === 'video') {
      const isVideo = mediaType === 'video';
      try {
        console.log('🔁 Intentando crear WebP animado con ffmpeg (puede tardar un instante)...');
        const animated = await ffmpegConvertToAnimatedWebP(mediaBuffer, isVideo);
        console.log('✅ WebP animado creado con ffmpeg, tamaño:', animated.length);
        return animated;
      } catch (ffErr) {
        console.warn('⚠️ ffmpeg no pudo crear webp animado o no está instalado. Haciendo fallback a primer frame. Error:', ffErr?.message || ffErr);
        // fallback: extraer primer frame y convertir a webp estático
        try {
          const frameBuffer = await ffmpegExtractFirstFrame(mediaBuffer);
          const webpStatic = await sharp(frameBuffer)
            .resize(512, 512, { fit: 'contain', background: { r:255,g:255,b:255,alpha:0 } })
            .webp({ quality: 90, lossless: false, effort: 4 })
            .toBuffer();
          console.log('✅ Fallback: primer frame convertido a WebP estático');
          return webpStatic;
        } catch (fallbackErr) {
          console.error('❌ Fallback también falló:', fallbackErr);
          // último recurso: devolver buffer original (probablemente no aceptado por WA)
          return mediaBuffer;
        }
      }
    }

    // si llega acá, no soportado
    console.log('❌ Tipo no soportado para conversión a sticker:', mediaType);
    return null;
  } catch (error) {
    console.error('❌ Error en convertToStickerFormat:', error);
    return null;
  }
}

/**
 * Inyecta metadatos EXIF en un WebP usando node-webpmux.
 * No re-encodea el contenido, solo agrega el chunk EXIF.
 * Mismo método que usa wa-sticker-formatter internamente.
 */
async function injectWebPMetadata(webpBuffer, packname, author) {
  try {
    const json = JSON.stringify({
      'sticker-pack-id': Math.random().toString(36).slice(2),
      'sticker-pack-name': packname,
      'sticker-pack-publisher': author,
      'emojis': []
    });

    // Formato EXIF exacto que usa wa-sticker-formatter
    const exifArr = [
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ];
    const jsonBuf = Buffer.from(json, 'utf-8');
    const exif = Buffer.concat([Buffer.from(exifArr), jsonBuf]);
    // Escribir el tamaño del JSON en offset 14 (4 bytes LE)
    exif.writeUIntLE(jsonBuf.length, 14, 4);

    // Cargar el WebP con node-webpmux e inyectar el EXIF
    const img = new WebPImage();
    await img.load(webpBuffer);
    img.exif = exif;
    const result = await img.save(null);
    return result;
  } catch (e) {
    console.warn('⚠️ No se pudieron inyectar metadatos EXIF:', e.message);
    return webpBuffer;
  }
}

async function sendSticker(sock, jid, mediaBuffer, mediaType, options = {}) {
  try {
    console.log('📤 Preparando sticker para envío...');
    const stickerBuffer = await convertToStickerFormat(mediaBuffer, mediaType, options.mimetype);

    if (!stickerBuffer) {
      console.log('❌ No se pudo convertir la media a sticker');
      return false;
    }

    const packname   = options.packname || 'RobleBOT';
    const authorText = options.author   || '\nInstagram: @robleuy\n\nrobleuy.vercel.app/roblebot';

    let finalBuffer;

    if (mediaType === 'gif' || mediaType === 'video') {
      // Para animados: inyección directa de metadatos con node-webpmux, sin re-encodear
      // wa-sticker-formatter re-encodea y lo infla de ~300 KB a 2.5 MB
      finalBuffer = await injectWebPMetadata(stickerBuffer, packname, authorText);
      console.log(`📦 Sticker animado final: ${(finalBuffer.length / 1024).toFixed(1)} KB`);
    } else {
      // Para estáticos: inyección directa con node-webpmux (0ms, 0 CPU adicional sin re-encodear)
      try {
        finalBuffer = await injectWebPMetadata(stickerBuffer, packname, authorText);
      } catch (errExif) {
        // Fallback seguro a wa-sticker-formatter solo si node-webpmux diera error
        const sticker = new Sticker(stickerBuffer, {
          pack: packname,
          author: authorText,
          type: 'default',
          quality: 90
        });
        finalBuffer = await sticker.toBuffer();
      }
    }

    const sendOptions = options.quoted ? { quoted: options.quoted } : {};
    await sock.sendMessage(jid, { sticker: finalBuffer }, sendOptions);
    console.log('✅ Sticker enviado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error al enviar sticker:', error);
    return false;
  }
}

/**
 * Función unificada que detecta media en el mensaje actual O en el citado,
 * a partir del baileyMessage directamente (sin depender de global.lastBaileyMessage).
 * Soporta todos los wrappers conocidos de Baileys.
 */
async function detectMediaFromBailey(baileyMsg) {
  if (!baileyMsg) return null;

  // ── Normalizar el mensaje raíz ──────────────────────────────────────────────
  // Baileys puede envolver el mensaje real en varios capas
  function unwrap(msg) {
    if (!msg) return null;
    return (
      msg.viewOnceMessage?.message ||
      msg.viewOnceMessageV2?.message ||
      msg.viewOnceMessageV2Extension?.message ||
      msg.ephemeralMessage?.message ||
      msg.documentWithCaptionMessage?.message ||
      msg.buttonReplyMessage?.message ||
      msg.buttonsResponseMessage?.message ||
      msg.templateButtonReplyMessage?.message ||
      msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
      msg
    );
  }

  const rawMsg = baileyMsg.message;
  const inner = unwrap(rawMsg);

  // ── Helper: descargar y devolver buffer ────────────────────────────────────
  async function downloadMsg(msgObj, type) {
    try {
      const stream = await downloadContentFromMessage(msgObj, type);
      return await streamToBuffer(stream);
    } catch (e) {
      console.error(`❌ Error descargando ${type}:`, e.message);
      return null;
    }
  }

  // ── 1. Buscar en el mensaje actual (imagen/video enviado con caption .sticker) ──
  if (inner?.imageMessage) {
    console.log('🖼️ Imagen en mensaje actual');
    const buf = await downloadMsg(inner.imageMessage, 'image');
    if (buf) return { data: buf, mimetype: inner.imageMessage.mimetype || 'image/jpeg', type: 'image' };
  }

  if (inner?.videoMessage) {
    const isGif = !!inner.videoMessage.gifPlayback;
    console.log(isGif ? '🎭 GIF en mensaje actual' : '🎥 Video en mensaje actual');
    const buf = await downloadMsg(inner.videoMessage, 'video');
    if (buf) return { data: buf, mimetype: inner.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
  }

  if (inner?.stickerMessage) {
    console.log('🎟️ Sticker en mensaje actual');
    const buf = await downloadMsg(inner.stickerMessage, 'sticker');
    if (buf) return { data: buf, mimetype: inner.stickerMessage.mimetype || 'image/webp', type: 'sticker' };
  }

  // ── 2. Buscar en el mensaje citado (contextInfo en cualquier capa) ──────────
  // Buscar contextInfo en múltiples posibles ubicaciones
  const contextInfo =
    inner?.extendedTextMessage?.contextInfo ||
    inner?.imageMessage?.contextInfo ||
    inner?.videoMessage?.contextInfo ||
    inner?.stickerMessage?.contextInfo ||
    inner?.audioMessage?.contextInfo ||
    inner?.documentMessage?.contextInfo ||
    rawMsg?.extendedTextMessage?.contextInfo ||
    null;

  const quoted = contextInfo?.quotedMessage;
  if (!quoted) {
    console.log('❌ No se encontró media ni mensaje citado');
    return null;
  }

  // Unwrap también el mensaje citado
  const quotedInner = unwrap(quoted) || quoted;

  if (quotedInner?.imageMessage) {
    console.log('🖼️ Imagen en mensaje citado');
    const buf = await downloadMsg(quotedInner.imageMessage, 'image');
    if (buf) return { data: buf, mimetype: quotedInner.imageMessage.mimetype || 'image/jpeg', type: 'image' };
  }

  if (quotedInner?.videoMessage) {
    const isGif = !!quotedInner.videoMessage.gifPlayback;
    console.log(isGif ? '🎭 GIF en mensaje citado' : '🎥 Video en mensaje citado');
    const buf = await downloadMsg(quotedInner.videoMessage, 'video');
    if (buf) return { data: buf, mimetype: quotedInner.videoMessage.mimetype || 'video/mp4', type: isGif ? 'gif' : 'video' };
  }

  if (quotedInner?.stickerMessage) {
    console.log('🎟️ Sticker en mensaje citado');
    const buf = await downloadMsg(quotedInner.stickerMessage, 'sticker');
    if (buf) return { data: buf, mimetype: quotedInner.stickerMessage.mimetype || 'image/webp', type: 'sticker' };
  }

  console.log('❌ Tipo de media no soportado en mensaje citado:', Object.keys(quotedInner || {}));
  return null;
}

// Handler principal exportado
let handler = async (message, { text, args, conn }) => {
  try {
    console.log('🚀 Iniciando comando sticker...');
    const sock = conn || message._sock || global.conn;
    if (!sock) {
      return await message.reply('❌ Error: Conexión no disponible.');
    }

    // 1. Buscar media en el mensaje actual o en el mensaje citado.
    //    Prioridad: _baileyMessage del propio mensaje (siempre correcto),
    //    luego global.lastBaileyMessage como último recurso.
    //    Cuando se es subbot, global.lastBaileyMessage puede ser de otro bot
    //    o ya estar restaurado al valor anterior; _baileyMessage es siempre el correcto.
    const baileyMsg = message._baileysMessage
      || message._baileyMessage
      || message.baileysMessage
      || message.baileyMessage
      || message.rawMessage
      || global.lastBaileyMessage;
    let quotedMedia = baileyMsg ? await detectMediaFromBailey(baileyMsg) : null;

    // 2. Si no encontró nada con el baileyMessage, intentar con message.download() o message.quoted.download()
    if (!quotedMedia && typeof message.download === 'function') {
      try {
        const buf = await message.download();
        if (buf && buf.length > 100) {
          quotedMedia = { data: buf, mimetype: 'image/jpeg', type: 'image' };
          console.log(`✅ Fallback message.download exitoso (${(buf.length/1024).toFixed(1)} KB)`);
        }
      } catch (_) {}
    }

    if (!quotedMedia && message.quoted?.download) {
      try {
        console.log('⚠️ Fallback: intentando descargar desde message.quoted...');
        const buf = await message.quoted.download();
        if (buf && buf.length > 100) {
          const mime = message.quoted.mimetype || 'image/jpeg';
          const isGif = mime.includes('video') && message.quoted.mtype === 'videoMessage';
          const type = mime.includes('video') ? (isGif ? 'gif' : 'video')
                     : mime.includes('webp')  ? 'sticker'
                     : 'image';
          quotedMedia = { data: buf, mimetype: mime, type };
          console.log(`✅ Fallback exitoso: ${type} (${(buf.length/1024).toFixed(1)} KB)`);
        }
      } catch (fbErr) {
        console.error('❌ Fallback message.quoted falló:', fbErr.message);
      }
    }

    if (!quotedMedia) {
      return await message.reply(
        '❌ *Adjunta o Responde a una imagen, video o GIF con el comando /sticker para crear un sticker.*'
      );
    }

    const mediaType = quotedMedia.type;
    console.log(`✅ ${mediaType.toUpperCase()} encontrado, procesando...`);

    await message.reply('⏳ Creando sticker...');

    const authorText = '\nRobleBOT\nInstagram: @robleuy';

    const success = await sendSticker(sock, message.from, quotedMedia.data, mediaType, {
      mimetype: quotedMedia.mimetype,
      packname: 'RobleBOT',
      author: authorText,
      quoted: message._baileyMessage
    });

    if (!success) {
      return await message.reply(`❌ Error al crear/mandar el sticker desde el ${mediaType}.`);
    }

  } catch (error) {
    console.error('❌ Error general en handler:', error);
    await message.reply('❌ Ocurrió un error al crear el sticker.');
  }
};

handler.help = ['sticker', 'stickers', 's'];
handler.tags = ['stickers'];
handler.command = /^(s|sticker|stickers)$/i;

module.exports = handler;
