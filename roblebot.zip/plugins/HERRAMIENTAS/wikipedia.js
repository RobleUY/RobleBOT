const https = require('https');

// ─── Configuración ────────────────────────────────────────────────────────────
const TIMEOUT = 15000;
const MAX_RESPONSE_SIZE = 2 * 1024 * 1024;
const SEARCH_URL = 'https://es.wikipedia.org/w/api.php';
const SUMMARY_URL = 'https://es.wikipedia.org/api/rest_v1/page/summary/';

const USER_AGENT = 'RobleBOT/1.0 (https://github.com/RobleUY/RobleBOT) Node.js';

// Caché de consultas durante 10 minutos
const CACHE_TTL = 10 * 60 * 1000;
const CACHE_LIMIT = 100;
const cache = new Map();

function getNetGuard() {
    return (typeof global !== 'undefined' && global.networkGuard)
        ? global.networkGuard
        : null;
}

// ─── Peticiones HTTP ──────────────────────────────────────────────────────────
function requestJson(url) {
    return new Promise((resolve, reject) => {
        const req = https.get(url, {
            headers: {
                'User-Agent': USER_AGENT,
                'Accept': 'application/json'
            }
        }, (res) => {
            let data = '';
            res.setEncoding('utf8');

            res.on('data', (chunk) => {
                data += chunk;

                if (Buffer.byteLength(data, 'utf8') > MAX_RESPONSE_SIZE) {
                    req.destroy(new Error('La respuesta de Wikipedia es demasiado grande'));
                }
            });

            res.on('end', () => {
                if (res.statusCode < 200 || res.statusCode >= 300) {
                    const error = new Error(
                        `Wikipedia respondió con HTTP ${res.statusCode}`
                    );

                    error.statusCode = res.statusCode;
                    error.retryAfter = res.headers['retry-after'];

                    return reject(error);
                }

                try {
                    resolve(JSON.parse(data));
                } catch (_) {
                    reject(new Error('Wikipedia devolvió una respuesta JSON inválida'));
                }
            });
        });

        req.on('error', (error) => {
            const netGuard = getNetGuard();
            if (netGuard) netGuard.reportNetworkError(error);
            reject(error);
        });

        req.setTimeout(TIMEOUT, () => {
            req.destroy(new Error('Tiempo de espera agotado al consultar Wikipedia'));
        });
    });
}

// ─── Sistema de caché ─────────────────────────────────────────────────────────
function getCached(key) {
    const item = cache.get(key);
    if (!item) return null;

    if (Date.now() - item.createdAt > CACHE_TTL) {
        cache.delete(key);
        return null;
    }

    return item.value;
}

function setCached(key, value) {
    if (cache.size >= CACHE_LIMIT) {
        const oldestKey = cache.keys().next().value;
        if (oldestKey) cache.delete(oldestKey);
    }

    cache.set(key, {
        value,
        createdAt: Date.now()
    });
}

// ─── Búsqueda en Wikipedia ─────────────────────────────────────────────────────
async function wikipediaSearch(searchText) {
    const query = String(searchText || '').trim();

    if (!query) {
        throw new Error('Escribí qué querés buscar.');
    }

    const cacheKey = query.toLocaleLowerCase('es');
    const cached = getCached(cacheKey);

    if (cached) return cached;

    // 1. Buscar el artículo más relevante
    const searchParams = new URLSearchParams({
        action: 'query',
        list: 'search',
        srsearch: query,
        srnamespace: '0',
        srlimit: '1',
        utf8: '1',
        format: 'json',
        formatversion: '2'
    });

    const searchData = await requestJson(
        `${SEARCH_URL}?${searchParams.toString()}`
    );

    const result = searchData?.query?.search?.[0];

    if (!result || !result.title) {
        throw new Error(
            'No encontré ningún artículo relacionado con esa búsqueda.'
        );
    }

    // 2. Obtener el resumen del artículo
    const encodedTitle = encodeURIComponent(
        result.title.replace(/ /g, '_')
    );

    const article = await requestJson(
        `${SUMMARY_URL}${encodedTitle}`
    );

    const title = article.title || result.title;

    const extract = String(
        article.extract || article.description || ''
    ).trim();

    const articleUrl = article.content_urls?.desktop?.page
        || `https://es.wikipedia.org/wiki/${encodedTitle}`;

    if (!extract) {
        throw new Error(
            'Encontré el artículo, pero Wikipedia no devolvió un resumen.'
        );
    }

    const response = {
        title,
        extract: extract.length > 3200
            ? `${extract.slice(0, 3197).trimEnd()}...`
            : extract,
        url: articleUrl
    };

    setCached(cacheKey, response);

    return response;
}

// ─── Handler principal ────────────────────────────────────────────────────────
let handler = async (message, { text }) => {
    const query = String(text || '').trim();

    if (!query) {
        return await message.reply(
            '⚠️ Uso correcto:\n.wikipedia qué querés buscar\n\n' +
            'Ejemplo:\n.wikipedia Uruguay'
        );
    }

    try {
        await message.reply('🔎 _Buscando en Wikipedia..._');
    } catch (_) {}

    let result;

    try {
        result = await wikipediaSearch(query);
    } catch (error) {
        console.error('[wikipedia] Error:', error.message);

        let errorMessage =
            '⚠️ No pude consultar Wikipedia en este momento. Intentá de nuevo más tarde.';

        if (/No encontré ningún artículo/.test(error.message)) {
            errorMessage =
                '🔎 No encontré ningún artículo con esa búsqueda. Probá con otras palabras.';
        } else if (/Escribí qué querés buscar/.test(error.message)) {
            errorMessage =
                '⚠️ Escribí qué querés buscar después del comando.';
        } else if (error.statusCode === 429) {
            errorMessage =
                '⏳ Wikipedia está limitando las consultas por el momento. Probá de nuevo más tarde.';
        }

        return await message.reply(errorMessage);
    }

    const response =
        `📚 *${result.title}*\n\n` +
        `${result.extract}\n\n` +
        `🔗 ${result.url}\n` +
        '_Fuente: Wikipedia en español._';

    return await message.reply(response);
};

// ─── Configuración del comando ────────────────────────────────────────────────
handler.help = ['wikipedia <búsqueda>'];
handler.tags = ['busqueda', 'ia'];
handler.command = /^wikipedia$/i;
handler.wikipediaSearch = wikipediaSearch;

module.exports = handler;