'use strict';

/**
 * Plugin: resumen
 * Resume con IA (solo Groq) lo que se habló en el grupo en las últimas X horas.
 *
 * Uso:
 *   .resumen        → últimas 12 horas
 *   .resumen 6      → últimas 6 horas
 *   .resumen 24h    → últimas 24 horas
 *
 * Flujo:
 *   1) Toma los mensajes MÁS RECIENTES en orden cronológico (conversación continua,
 *      sin saltear mensajes) hasta llenar MAX_CONTEXT_CHARS.
 *   2) Arma un transcript claro: personas como P1, P2..., respuestas marcadas
 *      ("responde a P1: ..."), mensajes seguidos unidos y pausas largas marcadas.
 *   3) Prueba keys y modelos de Groq hasta que alguno responda.
 *   4) Convierte P1, P2... en @menciones reales y envía el resumen.
 *
 * Requiere chatHistory.js con getRecentMessages().
 * Si chatHistory guarda las respuestas (citas) de los mensajes, mucho mejor
 * (ver extraerCita() más abajo).
 *
 * API keys de Groq (https://console.groq.com/keys):
 *   - Variable de entorno GROQ_KEYS (separadas por coma), o
 *   - GROQ_API_KEY, GROQ_API_KEY1 ... GROQ_API_KEY10, o
 *   - el array GROQ_KEYS_EXTRA de acá abajo (NO recomendado: no subas keys al código)
 *
 * Debug: arrancá el bot con RESUMEN_DEBUG=1 para ver en consola el transcript exacto.
 */

const axios = require('axios');

// ── Configuración ─────────────────────────────────────────────────────────────
const DEFAULT_HOURS     = 12;
const MIN_HOURS         = 1;
const MAX_HOURS         = 48;
const MAX_CONTEXT_CHARS = 9000;     // tope total del transcript (≈2700 tokens)
const MAX_MSG_CHARS     = 300;      // recorte por mensaje
const QUOTE_CHARS       = 90;       // recorte del texto citado en una respuesta
const LINE_OVERHEAD     = 28;       // "[HH:MM] P12: " aprox
const MERGE_WINDOW_MS   = 90_000;   // mensajes seguidos de la misma persona dentro de 90 s se unen
const GAP_MS            = 30 * 60_000; // pausa que se marca como separación de temas
const MAX_OUTPUT_CHARS  = 2500;
const MAX_MENTIONS      = 10;
const COOLDOWN_MS       = 60_000;
const UY_OFFSET         = -3 * 3_600_000;

// Preferí variables de entorno. Si querés, ponelas acá (y NO compartas este archivo).
const GROQ_KEYS_EXTRA = [
    // 'gsk_...',
];

// Orden de prioridad: del más inteligente al más rápido/tonto.
const GROQ_MODELS = [
    'llama-3.3-70b-versatile',
    'openai/gpt-oss-120b',
    'openai/gpt-oss-20b',
    'llama-3.1-8b-instant',
];

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const TIMEOUT  = 25000;

const lastRun = new Map();

// ── Helpers ───────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const pad = (n) => String(n).padStart(2, '0');
const hhmm = (ts) => {
    const d = new Date(ts + UY_OFFSET);
    return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
};

const GROQ_ENV = ['groq_api_key', 'GROQ_API_KEY',
    ...Array.from({ length: 10 }, (_, i) => [`groq_api_key${i + 1}`, `GROQ_API_KEY${i + 1}`]).flat()];

function groqKeys() {
    const keys = new Set();
    for (const k of GROQ_KEYS_EXTRA) if (k && String(k).trim()) keys.add(String(k).trim());
    for (const k of (process.env.GROQ_KEYS || '').split(',')) if (k && k.trim()) keys.add(k.trim());
    for (const n of GROQ_ENV) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    return [...keys];
}

// ── Groq ──────────────────────────────────────────────────────────────────────
async function groq(key, model, systemPrompt, userPrompt, maxTokens) {
    const isOss = model.startsWith('openai/gpt-oss');
    const body = {
        model,
        temperature: 0.3,
        // los modelos "reasoning" gastan tokens pensando, hay que darles margen
        max_tokens: isOss ? maxTokens + 1500 : maxTokens,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
    };
    if (isOss) body.reasoning_effort = 'low';
    const res = await axios.post(GROQ_URL, body, {
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        timeout: TIMEOUT
    });
    return res.data?.choices?.[0]?.message?.content || '';
}

const validar = (t) => {
    const s = typeof t === 'string' ? t.trim() : '';
    return s.length >= 30 ? s : null;
};

async function llamarIA(systemPrompt, userPrompt, maxTokens = 700) {
    const keys = groqKeys();
    if (!keys.length) throw new Error('No hay API keys de Groq configuradas');

    const invalidas = new Set();
    let huboLimite = false;

    for (const model of GROQ_MODELS) {
        for (let i = 0; i < keys.length; i++) {
            if (invalidas.has(i)) continue;
            try {
                const limpio = validar(await groq(keys[i], model, systemPrompt, userPrompt, maxTokens));
                if (!limpio) throw new Error('respuesta vacía');
                console.log(`[RESUMEN] OK con ${model} (key #${i + 1} de ${keys.length})`);
                return limpio;
            } catch (err) {
                const status = err.response?.status;
                if (status === 401 || status === 403) invalidas.add(i);
                if (status === 429) huboLimite = true;
                const detalle = err.response?.data?.error?.message || err.message;
                console.log(`[RESUMEN] ${model} key#${i + 1} falló: ${status || ''} ${detalle}`);
            }
        }
    }

    const err = new Error('Ninguna key de Groq respondió');
    if (huboLimite) err.response = { status: 429 };
    throw err;
}

// Pasa el formato de la IA a formato WhatsApp
function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*(.+)$/gm, '*$1*')
        .replace(/^\s*[-•*]\s+/gm, '• ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function recortar(t, max) {
    if (t.length <= max) return t;
    const cut = t.slice(0, max);
    const i = cut.lastIndexOf('\n');
    return (i > max * 0.5 ? cut.slice(0, i) : cut).trim();
}

// Relaciona números del historial con el JID real del participante (normal o LID)
function buildResolver(meta) {
    const map = new Map(); // número → { tag, jid }
    for (const p of meta?.participants || []) {
        const id = p.id || '';
        const [userPart, server] = id.split('@');
        const user = (userPart || '').split(':')[0];
        if (!user || !server) continue;
        const info = { tag: user, jid: `${user}@${server}` };
        for (const c of [id, p.jid, p.lid, p.phoneNumber]) {
            const n = cleanNum(c || '');
            if (n && !map.has(n)) map.set(n, info);
        }
    }
    return map;
}

// ── Lectura de mensajes (tolerante a distintos formatos de chatHistory) ───────
function msgId(m) {
    return String(m.id || m.msgId || m.messageId || m.key?.id || '') || null;
}

/**
 * Intenta sacar la info de "este mensaje responde a otro".
 * Soporta varios nombres de campo. Si tu chatHistory usa otros, pasame el archivo
 * y lo ajusto.
 */
function extraerCita(m) {
    let q = m.quoted || m.quotedMsg || m.quotedMessage || m.reply || m.replyTo || null;
    if (typeof q === 'string') q = { text: q };
    const text = (q && (q.text || q.body || q.message || q.caption)) || m.quotedText || '';
    const user = (q && (q.userId || q.sender || q.participant || q.from)) ||
                 m.quotedUserId || m.quotedParticipant || m.quotedSender || '';
    const id   = (q && (q.id || q.msgId || q.key?.id)) ||
                 m.quotedId || m.quotedMsgId || m.replyToId || '';
    if (!text && !user && !id) return null;
    return { text: typeof text === 'string' ? text : '', user: String(user || ''), id: String(id || '') };
}

function nombreDe(m) {
    const n = m.name || m.pushName || m.senderName || m.userName || '';
    return typeof n === 'string'
        ? n.replace(/[^\p{L}\p{N} ._-]/gu, '').trim().slice(0, 20)
        : '';
}

const limpiarTexto = (t) => String(t || '').replace(/\s+/g, ' ').trim();

function esRuido(texto) {
    if (/^[.!#\/]\w+/.test(texto)) return true;                       // comandos del bot
    const s = texto.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
    if (!s) return true;                                              // solo emojis/símbolos
    return /^(k+|(ja|je|ji|jo|ha)+j?a?|xd+|l+o+l+|a+h+|e+h+|o+e+)$/.test(s); // risas / interjecciones
}

/**
 * Deja los mensajes en orden cronológico, sin ruido, con citas resueltas
 * y mensajes seguidos de la misma persona unidos.
 */
function prepararMensajes(msgs, canon) {
    const ordenados = [...msgs].sort((a, b) => a.ts - b.ts);

    // índice para resolver respuestas por id (incluye todo, aun lo filtrado)
    const porId = new Map();
    for (const m of ordenados) {
        const id = msgId(m);
        if (id) porId.set(id, m);
    }

    let norm = ordenados.map(m => ({
        id: msgId(m),
        ts: m.ts,
        user: canon(m.userId),
        name: nombreDe(m),
        text: limpiarTexto(m.text).slice(0, MAX_MSG_CHARS),
        q: (() => {
            const q = extraerCita(m);
            if (!q) return null;
            const orig = q.id ? porId.get(q.id) : null;
            return {
                user: orig ? canon(orig.userId) : (q.user ? canon(q.user) : ''),
                text: limpiarTexto(orig ? orig.text : q.text).slice(0, QUOTE_CHARS)
            };
        })()
    }));

    const sinRuido = norm.filter(m => !esRuido(m.text));
    if (sinRuido.length >= 3) norm = sinRuido;

    // Unir mensajes seguidos de la misma persona
    const unidos = [];
    for (const m of norm) {
        const prev = unidos[unidos.length - 1];
        if (prev && prev.user === m.user && !m.q && (m.ts - prev.tsFin) <= MERGE_WINDOW_MS &&
            prev.text.length + m.text.length < MAX_MSG_CHARS * 1.5) {
            prev.text += ' / ' + m.text;
            prev.tsFin = m.ts;
        } else {
            unidos.push({ ...m, tsFin: m.ts });
        }
    }
    return unidos;
}

// Toma los mensajes MÁS RECIENTES (continuos) hasta llenar el cupo
function recortarPorCupo(lista) {
    const elegidos = [];
    let used = 0;
    for (let i = lista.length - 1; i >= 0; i--) {
        const m = lista[i];
        const cost = m.text.length + LINE_OVERHEAD + (m.q ? Math.min(m.q.text.length, QUOTE_CHARS) + 30 : 0);
        if (used + cost > MAX_CONTEXT_CHARS && elegidos.length >= 5) break;
        used += cost;
        elegidos.push(m);
    }
    elegidos.reverse();
    return { elegidos, omitidos: lista.length - elegidos.length };
}

const fmtPausa = (ms) => {
    const min = Math.round(ms / 60000);
    return min >= 90 ? `${Math.round(min / 60)} h` : `${min} min`;
};

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        if (!chatId || !chatId.endsWith('@g.us')) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Cantidad de horas (opcional)
        let rawArg = Array.isArray(args) && args.length ? String(args[0]) : '';
        if (!rawArg) rawArg = ((message.body || text || '').trim().split(/\s+/)[1]) || '';
        let hours = DEFAULT_HOURS;
        if (rawArg) {
            const m = rawArg.trim().match(/^(\d+(?:[.,]\d+)?)\s*h?$/i);
            if (!m) {
                return message.reply(
                    '❌ Formato incorrecto.\n\n' +
                    '📌 Uso: *.resumen* o *.resumen <horas>*\n\n' +
                    'Ejemplos:\n• .resumen → últimas 12 h\n• .resumen 6 → últimas 6 h\n• .resumen 24 → últimas 24 h'
                );
            }
            hours = parseFloat(m[1].replace(',', '.'));
        }
        if (hours < MIN_HOURS || hours > MAX_HOURS) {
            return message.reply(`⚠️ Elige entre *${MIN_HOURS}* y *${MAX_HOURS}* horas.`);
        }

        // Cooldown por grupo
        const wait = COOLDOWN_MS - (Date.now() - (lastRun.get(chatId) || 0));
        if (wait > 0) {
            return message.reply(`⏳ Espera *${Math.ceil(wait / 1000)} s* para pedir otro resumen en este grupo.`);
        }

        const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
        if (!chatHistory?.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
        }
        if (typeof chatHistory.getRecentMessages !== 'function') {
            return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de mensajes con hora).');
        }

        // 1) Mensajes de las últimas X horas
        const since = Date.now() - hours * 3_600_000;
        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
        const isBot = (n) => n === botNum || subNums.includes(n);
        const msgs = chatHistory.getRecentMessages(chatId, since)
            .filter(m => m.text && m.userId !== botNum && !subNums.includes(m.userId));

        const hLabel = Number.isInteger(hours) ? `${hours}` : `${hours}`.replace('.', ',');

        if (msgs.length < 3) {
            return message.reply(
                `📭 No hay suficientes mensajes en las últimas *${hLabel} h* para hacer un resumen.\n` +
                '_Solo se guardan mensajes de texto desde que se activó el registro._'
            );
        }

        lastRun.set(chatId, Date.now());
        const meta = await sock.groupMetadata(chatId).catch(() => null);
        Promise.resolve(message.reply(`⏳ _Leyendo los mensajes de las últimas ${hLabel} h..._`)).catch(() => {});

        // 2) Preparar conversación
        const resolver = buildResolver(meta);
        // identidad única por persona (une número normal y LID)
        const canon = (id) => {
            const n = cleanNum(id);
            return resolver.get(n)?.tag || n;
        };

        const preparados = prepararMensajes(msgs, canon);
        const { elegidos, omitidos } = recortarPorCupo(preparados);

        // Alias P1, P2... en orden de aparición
        const aliasDe = new Map();   // canon → 'P1'
        const canonDe = new Map();   // 'P1' → canon
        const nombres = new Map();   // canon → nombre
        const alias = (c) => {
            if (!aliasDe.has(c)) {
                const a = `P${aliasDe.size + 1}`;
                aliasDe.set(c, a);
                canonDe.set(a, c);
            }
            return aliasDe.get(c);
        };
        for (const m of elegidos) if (m.name && !nombres.has(m.user)) nombres.set(m.user, m.name);

        const reemplazarMenciones = (t) => t.replace(/@(\d{5,})/g, (x, d) => {
            const info = resolver.get(d);
            if (info) return alias(info.tag);
            return isBot(d) ? 'el bot' : 'alguien';
        });

        const quienEs = (c) => {
            if (!c) return 'alguien';
            if (isBot(c)) return 'el bot';
            return alias(c);
        };

        const lineas = [];
        let prevTs = null;
        for (const m of elegidos) {
            if (prevTs && m.ts - prevTs > GAP_MS) {
                lineas.push(`— pasaron ${fmtPausa(m.ts - prevTs)} sin mensajes —`);
            }
            const quien = alias(m.user);
            const cuerpo = reemplazarMenciones(m.text);
            let cita = '';
            if (m.q) {
                const qt = reemplazarMenciones(m.q.text);
                cita = ` (responde a ${quienEs(m.q.user)}${qt ? `: "${qt}"` : ''})`;
            }
            lineas.push(`[${hhmm(m.ts)}] ${quien}${cita}: ${cuerpo}`);
            prevTs = m.tsFin;
        }
        const transcript = lineas.join('\n');

        const leyenda = [...aliasDe.entries()]
            .map(([c, a]) => nombres.has(c) ? `${a} (se hace llamar "${nombres.get(c)}")` : a)
            .join(', ');

        // alias → mención real
        const aliasToTag = new Map();
        for (const [c, a] of aliasDe) {
            const info = resolver.get(c);
            if (info) aliasToTag.set(a, info);
        }

        // 3) Prompt
        const systemPrompt =
            'Sos un asistente que resume chats de WhatsApp de un grupo de amigos uruguayos. ' +
            'Te paso la conversación real, en orden cronológico, y tenés que contarle a alguien que no la leyó de qué se habló, ' +
            'en español rioplatense natural, como si se lo contaras a un amigo.\n\n' +
            'CÓMO LEER LA CONVERSACIÓN:\n' +
            '• Cada línea es "[hora] Pn: mensaje". Pn es una persona (P1, P2...).\n' +
            '• "(responde a Pn: \\"...\\")" indica que ese mensaje contesta DIRECTAMENTE a ese otro mensaje. Usalo para entender quién le habla a quién.\n' +
            '• Los mensajes cortos ("sí", "no", "jaja ni ahí", "dale") casi siempre responden al mensaje inmediatamente anterior o a la persona que lo escribió.\n' +
            '• Varios mensajes seguidos de la misma persona unidos con " / " son una sola idea.\n' +
            '• "— pasaron X sin mensajes —" suele separar temas distintos.\n' +
            '• Es un grupo de amigos: hay bromas, ironía, sarcasmo y jerga. No tomes las bromas literal; si alguien jode, decí que jodió/bromeó.\n\n' +
            'REGLAS:\n' +
            '• Prestá mucha atención a QUIÉN dijo cada cosa. Nunca le atribuyas a una persona lo que dijo otra. Si no estás seguro, hablá en general ("se discutió que...").\n' +
            '• Si dos personas conversaron entre sí, contá el intercambio completo (qué planteó una y qué le respondió la otra).\n' +
            '• Agrupá por temas, en orden cronológico. Un tema = una charla real, no mensajes sueltos. Ignorá saludos, risas y mensajes vacíos.\n' +
            '• NO cites mensajes textuales ni armes una lista de frases por persona: explicá con tus palabras.\n' +
            '• Nombrá personas SOLO con su código exacto (P1, P2...), máx. 8 personas distintas; al resto "otros" o "el grupo". No inventes nombres.\n' +
            '• No inventes nada. Si una parte no se entiende, omitila.\n' +
            '• Formato WhatsApp: *negrita* con un solo asterisco, sin # ni **, viñetas con "• ".\n\n' +
            'ESTRUCTURA:\n' +
            '*De qué se habló:* 3 a 6 viñetas, una por tema, cada una con 1-3 oraciones completas.\n' +
            '*Lo más destacado:* una o dos frases (algo gracioso, una discusión, una noticia, un plan).\n' +
            '*Clima:* una frase.\n' +
            'Máx. 1500 caracteres, sin saludos ni cierres.';

        const periodo = omitidos > 0
            ? `desde las ${hhmm(elegidos[0].ts)} (hora Uruguay); hubo más mensajes anteriores que no entraron`
            : `últimas ${hLabel} h, hora Uruguay`;
        const userPrompt =
            `Grupo: ${meta?.subject || 'Grupo'}\n` +
            `Período: ${periodo}\n` +
            `Participantes: ${leyenda}\n\n` +
            `CONVERSACIÓN:\n${transcript}`;

        if (process.env.RESUMEN_DEBUG) {
            console.log('[RESUMEN][DEBUG] ----- PROMPT -----\n' + userPrompt + '\n[RESUMEN][DEBUG] ------------------');
        }

        // 4) IA
        const respuesta = await llamarIA(systemPrompt, userPrompt, 700);
        if (!respuesta) throw new Error('La IA no devolvió texto');

        // 5) P1, P2... → @menciones reales
        let cuerpo = formatear(respuesta).replace(/\*(P\d{1,3})\*/g, '$1');
        const mentions = new Set();
        cuerpo = cuerpo.replace(/@?\b(P\d{1,3})\b/g, (m, a) => {
            const info = aliasToTag.get(a);
            if (!info) return canonDe.has(a) ? 'alguien' : m;
            if (mentions.has(info.jid) || mentions.size < MAX_MENTIONS) {
                mentions.add(info.jid);
                return `@${info.tag}`;
            }
            return 'alguien';
        });
        cuerpo = recortar(cuerpo, MAX_OUTPUT_CHARS);

        // 6) Mensaje final
        const groupName = (meta?.subject || 'Grupo').replace(/[*_~`]/g, '');
        const personasTotal = new Set(msgs.map(m => canon(m.userId))).size;
        const L = [];
        L.push('📝 𝗥𝗘𝗦𝗨𝗠𝗘𝗡 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
        L.push(`_${groupName}_`);
        L.push(`🕒 Últimas *${hLabel} h* · 🇺🇾 Hora de Uruguay`);
        L.push(`💬 *${msgs.length}* mensajes · 👥 *${personasTotal}* personas`);
        if (omitidos > 0) {
            L.push(`_⚠️ Se analizó desde las ${hhmm(elegidos[0].ts)} en adelante (había más mensajes anteriores)._`);
        }
        L.push('━━━━━━━━━━━━');
        L.push('');
        L.push(cuerpo);

        await sock.sendMessage(chatId, { text: L.join('\n'), mentions: [...mentions] },
            { quoted: message._baileyMessage || message.baileyMessage || message });

    } catch (err) {
        lastRun.delete(chatId);
        console.error('[RESUMEN] Error:', err.message || err);
        const status = err.response?.status;
        if (status === 429) {
            return message.reply('⏳ Groq está saturado ahora mismo. Intenta en unos segundos.');
        }
        return message.reply('❌ No pude hacer el resumen. Intenta de nuevo en un rato.');
    }
};

handler.help    = ['resumen', 'resumen <horas>'];
handler.tags    = ['ia', 'grupos'];
handler.command = /^resumen$/i;
handler.group   = true;

module.exports = handler;