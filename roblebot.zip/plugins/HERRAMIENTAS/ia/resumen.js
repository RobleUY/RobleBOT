'use strict';

/**
 * Plugin: resumen
 * Resume con IA lo que se habló en el grupo en las últimas X horas.
 *
 * Uso:
 *   .resumen        → últimas 12 horas
 *   .resumen 6      → últimas 6 horas
 *   .resumen 24h    → últimas 24 horas
 *
 * Requiere chatHistory.js con getRecentMessages().
 * Usa el mismo motor de IA que sobre-usuarios.js (./ia) y, si falla,
 * Gemini / Groq con las keys de las variables de entorno.
 */

const axios = require('axios');

// ── Configuración ─────────────────────────────────────────────────────────────
const DEFAULT_HOURS   = 12;       // si no se indica cantidad
const MIN_HOURS       = 1;
const MAX_HOURS       = 48;       // chatHistory guarda ~50 h
const MAX_TOTAL_CHARS = 14000;    // tope de texto que se le manda a la IA (≈ 4-5k tokens)
const MAX_USER_CHARS  = 3000;     // tope inicial por persona (se reduce solo si hace falta)
const MIN_USER_CHARS  = 250;      // nunca bajar de esto por persona
const COOLDOWN_MS     = 60_000;   // 1 resumen por grupo cada 60 s
const UY_OFFSET       = -3 * 3_600_000; // horas del resumen en hora de Uruguay

const GEMINI_MODEL = 'gemini-flash-latest';
const GEMINI_URL   = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const GROQ_MODEL   = 'llama-3.3-70b-versatile';
const GROQ_LIGHT   = 'llama-3.1-8b-instant';
const TIMEOUT      = 30000;

const lastRun = new Map(); // groupId → timestamp

// ── Helpers ───────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const pad = (n) => String(n).padStart(2, '0');

function envKeys(names) {
    const keys = new Set();
    for (const n of names) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    return [...keys];
}

const GEMINI_ENV = ['gemini_api_key', 'GEMINI_API_KEY', 'gemini_api_key1', 'GEMINI_API_KEY1',
                    'gemini_api_key2', 'GEMINI_API_KEY2', 'gemini_api_key3', 'GEMINI_API_KEY3'];
const GROQ_ENV   = ['groq_api_key', 'GROQ_API_KEY', 'groq_api_key1', 'GROQ_API_KEY1',
                    'groq_api_key2', 'GROQ_API_KEY2', 'groq_api_key3', 'GROQ_API_KEY3',
                    'groq_api_key4', 'GROQ_API_KEY4'];

async function llamarGemini(systemPrompt, userPrompt, maxTokens) {
    const keys = envKeys(GEMINI_ENV);
    if (!keys.length) throw new Error('Sin keys de Gemini en el entorno');
    let lastErr;
    for (const key of keys) {
        try {
            const res = await axios.post(GEMINI_URL, {
                systemInstruction: { parts: [{ text: systemPrompt }] },
                contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
                generationConfig: { temperature: 0.4, maxOutputTokens: maxTokens, thinkingConfig: { thinkingBudget: 0 } }
            }, { headers: { 'Content-Type': 'application/json', 'X-goog-api-key': key }, timeout: TIMEOUT });
            const texto = res.data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
            if (!texto) throw new Error('Respuesta vacía de Gemini');
            return texto.trim();
        } catch (err) {
            lastErr = err;
            const st = err.response?.status;
            if (st && ![400, 401, 403, 404, 429].includes(st)) throw err;
        }
    }
    throw lastErr;
}

async function llamarGroq(systemPrompt, userPrompt, maxTokens, model = GROQ_MODEL) {
    const keys = envKeys(GROQ_ENV);
    if (!keys.length) throw new Error('Sin keys de Groq en el entorno');
    let lastErr;
    for (const key of keys) {
        try {
            const res = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                model, temperature: 0.4, max_tokens: maxTokens,
                messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
            }, { headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, timeout: TIMEOUT });
            const texto = res.data?.choices?.[0]?.message?.content?.trim() || '';
            if (!texto) throw new Error('Respuesta vacía de Groq');
            return texto;
        } catch (err) {
            lastErr = err;
            const st = err.response?.status;
            const code = err.response?.data?.error?.code;
            if (st && ![401, 403, 413, 429].includes(st) && code !== 'rate_limit_exceeded') throw err;
        }
    }
    throw lastErr;
}

// Motor unificado (./ia) → Gemini → Groq → Groq liviano
async function llamarIA(systemPrompt, userPrompt, maxTokens = 700) {
    try {
        const iaModule = require('./ia');
        const callIA = iaModule.callIA || iaModule;
        if (typeof callIA === 'function') {
            const res = await callIA(systemPrompt, userPrompt);
            if (res && res !== '_SILENT_FAIL_') return res;
        }
    } catch (e) {
        console.warn(`[RESUMEN] Motor unificado falló (${e.message}), probando Gemini/Groq...`);
    }
    try { return await llamarGemini(systemPrompt, userPrompt, maxTokens); }
    catch (e) { console.log(`[RESUMEN] Gemini no disponible (${e.message})`); }
    try { return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_MODEL); }
    catch (e) { console.log(`[RESUMEN] Groq falló (${e.message}), probando modelo liviano...`); }
    return await llamarGroq(systemPrompt, userPrompt, maxTokens, GROQ_LIGHT);
}

// Pasa el formato de la IA a formato WhatsApp
function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*(.+)$/gm, '*$1*')
        .replace(/^\s*[-•]\s+/gm, '• ')
        .replace(/@(\d{6,})/g, '$1')            // sin @ de menciones
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// Nombre del usuario (si el bot lo conoce) o "Miembro ···1234"
async function nombreDe(sock, num) {
    try {
        const n = await Promise.resolve(sock.getName?.(`${num}@s.whatsapp.net`));
        if (typeof n === 'string') {
            const clean = n.replace(/[*_~`@\n]/g, '').trim();
            if (clean && !/^\+?[\d\s-]+$/.test(clean)) return clean.slice(0, 20);
        }
    } catch (_) {}
    return `Miembro ···${num.slice(-4)}`;
}

/**
 * Elige los ÚLTIMOS mensajes de cada persona hasta un tope de caracteres por persona.
 * Si el total supera MAX_TOTAL_CHARS, reduce el tope por persona y repite
 * (así todos quedan representados). Devuelve los mensajes en orden cronológico.
 */
function seleccionarMensajes(msgs) {
    const porUsuario = new Map();
    for (const m of msgs) {
        if (!porUsuario.has(m.userId)) porUsuario.set(m.userId, []);
        porUsuario.get(m.userId).push(m);
    }

    const pick = (cap) => {
        const out = [];
        for (const lista of porUsuario.values()) {
            let used = 0;
            for (let i = lista.length - 1; i >= 0; i--) {   // desde el más nuevo
                const len = lista[i].text.length + 20;
                if (used + len > cap && used > 0) break;
                used += len;
                out.push(lista[i]);
            }
        }
        return out;
    };

    let cap = MAX_USER_CHARS;
    let elegidos = pick(cap);
    const total = (arr) => arr.reduce((a, m) => a + m.text.length + 20, 0);

    while (total(elegidos) > MAX_TOTAL_CHARS && cap > MIN_USER_CHARS) {
        cap = Math.max(MIN_USER_CHARS, Math.floor(cap * 0.8));
        elegidos = pick(cap);
    }
    // Último recurso: quedarse con los más recientes en conjunto
    if (total(elegidos) > MAX_TOTAL_CHARS) {
        elegidos.sort((a, b) => b.ts - a.ts);
        const final = [];
        let used = 0;
        for (const m of elegidos) {
            const len = m.text.length + 20;
            if (used + len > MAX_TOTAL_CHARS) break;
            used += len;
            final.push(m);
        }
        elegidos = final;
    }
    return elegidos.sort((a, b) => a.ts - b.ts);
}

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        if (!chatId || !chatId.endsWith('@g.us')) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Cantidad de horas (opcional)
        let rawArg = Array.isArray(args) && args.length ? String(args[0]) : '';
        if (!rawArg) rawArg = ((message.body || text || '').trim().split(/\s+/)[1]) || '';
        let hours = DEFAULT_HOURS;
        if (rawArg) {
            const m = rawArg.trim().match(/^(\d+(?:[.,]\d+)?)\s*h?$/i);
            if (!m) {
                return message.reply(
                    '❌ Formato incorrecto.\n\n' +
                    '📌 Uso: *.resumen* o *.resumen <horas>*\n\n' +
                    'Ejemplos:\n• .resumen → últimas 12 h\n• .resumen 6 → últimas 6 h\n• .resumen 24 → últimas 24 h'
                );
            }
            hours = parseFloat(m[1].replace(',', '.'));
        }
        if (hours < MIN_HOURS || hours > MAX_HOURS) {
            return message.reply(`⚠️ Elige entre *${MIN_HOURS}* y *${MAX_HOURS}* horas.`);
        }

        // Cooldown por grupo
        const wait = COOLDOWN_MS - (Date.now() - (lastRun.get(chatId) || 0));
        if (wait > 0) {
            return message.reply(`⏳ Espera *${Math.ceil(wait / 1000)} s* para pedir otro resumen en este grupo.`);
        }

        const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
        if (!chatHistory?.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
        }
        if (typeof chatHistory.getRecentMessages !== 'function') {
            return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de mensajes con hora).');
        }

        // 1) Obtener mensajes de las últimas X horas
        const since = Date.now() - hours * 3_600_000;
        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
        const msgs = chatHistory.getRecentMessages(chatId, since)
            .filter(m => m.text && m.userId !== botNum && !subNums.includes(m.userId));

        const hLabel = Number.isInteger(hours) ? `${hours}` : `${hours}`.replace('.', ',');

        if (msgs.length < 3) {
            return message.reply(
                `📭 No hay suficientes mensajes en las últimas *${hLabel} h* para hacer un resumen.\n` +
                '_Solo se guardan mensajes de texto desde que se activó el registro._'
            );
        }

        lastRun.set(chatId, Date.now());
        await message.reply(`⏳ _Leyendo los mensajes de las últimas ${hLabel} h..._`);

        // 2) Elegir los últimos mensajes de cada persona hasta el tope
        const elegidos = seleccionarMensajes(msgs);
        const personas = [...new Set(elegidos.map(m => m.userId))];

        // 3) Nombres (únicos) y transcripción en hora de Uruguay
        const nombres = {};
        const usados = new Set();
        for (const num of personas) {
            let n = await nombreDe(sock, num);
            if (usados.has(n)) n = `${n} ···${num.slice(-3)}`;
            usados.add(n);
            nombres[num] = n;
        }

        const transcript = elegidos.map(m => {
            const d = new Date(m.ts + UY_OFFSET);
            return `[${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}] ${nombres[m.userId]}: ${m.text.replace(/\s+/g, ' ')}`;
        }).join('\n');

        // 4) Pedirle el resumen a la IA
        const systemPrompt =
            'Sos un asistente que resume conversaciones de grupos de WhatsApp. ' +
            'Te paso los mensajes (con hora y nombre de quien los escribió) y tenés que contar qué se habló.\n\n' +
            'REGLAS:\n' +
            '1. Escribí en español informal (rioplatense), claro y directo.\n' +
            '2. No inventes nada: usá solo lo que está en los mensajes. Si algo no se entiende, no lo mencionés.\n' +
            '3. Nombrá a las personas tal cual aparecen, sin @ ni menciones.\n' +
            '4. Formato WhatsApp: *negrita* con un solo asterisco, sin # ni **. Usá "• " para listas.\n' +
            '5. Estructura exacta:\n' +
            '*Tema principal:* una o dos oraciones.\n' +
            '*Puntos clave:* 3 a 6 viñetas cortas con lo más importante (quién dijo/propuso qué).\n' +
            '*Acuerdos o pendientes:* solo si los hubo (si no, omití esta parte).\n' +
            '*Clima del grupo:* una frase sobre el tono (humor, discusión, charla tranquila, etc.).\n' +
            '6. Máximo 1500 caracteres en total. Sin saludos ni cierres.';

        const userPrompt =
            `Grupo: ${(await sock.groupMetadata(chatId).catch(() => null))?.subject || 'Grupo'}\n` +
            `Período: últimas ${hLabel} horas (horas en Uruguay)\n` +
            `Mensajes incluidos: ${elegidos.length} de ${msgs.length} · Personas: ${personas.length}\n` +
            `---\n${transcript}\n---\n\nHacé el resumen.`;

        const respuesta = await llamarIA(systemPrompt, userPrompt, 700);
        if (!respuesta) throw new Error('La IA no devolvió texto');

        // 5) Mensaje final
        const groupName = ((await sock.groupMetadata(chatId).catch(() => null))?.subject || 'Grupo').replace(/[*_~`]/g, '');
        const L = [];
        L.push('📝 𝗥𝗘𝗦𝗨𝗠𝗘𝗡 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
        L.push(`_${groupName}_`);
        L.push(`🕒 Últimas *${hLabel} h* · 🇺🇾 Hora de Uruguay`);
        L.push(`💬 *${msgs.length}* mensajes · 👥 *${new Set(msgs.map(m => m.userId)).size}* personas`);
        L.push('━━━━━━━━━━━━');
        L.push('');
        L.push(formatear(respuesta).slice(0, 3500));
        L.push('');
        L.push('_🤖 Resumen hecho con IA, puede tener errores._');

        await sock.sendMessage(chatId, { text: L.join('\n') },
            { quoted: message._baileyMessage || message.baileyMessage || message });

    } catch (err) {
        lastRun.delete(chatId);
        console.error('[RESUMEN] Error:', err.message || err);
        const status = err.response?.status;
        const code = err.response?.data?.error?.code;
        if (status === 429 || code === 'rate_limit_exceeded') {
            return message.reply('⏳ Todas las IAs están saturadas ahora mismo. Intenta en unos segundos.');
        }
        return message.reply('❌ No pude hacer el resumen. Intenta de nuevo en un rato.');
    }
};

handler.help    = ['resumen', 'resumen <horas>'];
handler.tags    = ['ia', 'grupos'];
handler.command = /^resumen$/i;
handler.group   = true;

module.exports = handler;
