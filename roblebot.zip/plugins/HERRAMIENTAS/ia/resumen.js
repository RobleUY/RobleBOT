'use strict';

/**
 * Plugin: resumen
 * Resume con IA lo que se habló en el grupo en las últimas X horas.
 *
 * Uso:
 *   .resumen        → últimas 12 horas
 *   .resumen 6      → últimas 6 horas
 *   .resumen 24h    → últimas 24 horas
 *
 * Flujo:
 *   1) Junta mensajes de TODOS (los más recientes de cada uno, de a uno por vuelta)
 *      hasta llenar MAX_CONTEXT_CHARS (2000 caracteres).
 *   2) Lanza TODAS las IAs a la vez (motor ./ia, Gemini, Groq, Delirius Gemini,
 *      Delirius ChatGPT) y usa la primera que responda bien; cancela el resto.
 *   3) Envía el resumen con @menciones.
 *
 * Requiere chatHistory.js con getRecentMessages().
 *
 * API keys extra de Gemini (https://aistudio.google.com/api-keys):
 *   - Pegala en EXTRA_GEMINI_KEYS acá abajo, o
 *   - Ponela en la variable de entorno GEMINI_KEYS (separadas por coma).
 */

const axios = require('axios');

// ── Configuración ─────────────────────────────────────────────────────────────
const DEFAULT_HOURS     = 12;       // si no se indica cantidad
const MIN_HOURS         = 1;
const MAX_HOURS         = 48;       // chatHistory guarda ~50 h
const MAX_CONTEXT_CHARS = 2000;     // 👈 tope TOTAL de texto que se le manda a la IA
const MAX_MSG_CHARS     = 200;      // cada mensaje se recorta a esto (para que entren más personas)
const LINE_OVERHEAD     = 24;       // "[HH:MM] @59812345678: " por mensaje
const MAX_OUTPUT_CHARS  = 1200;     // tope del resumen final
const COOLDOWN_MS       = 60_000;   // 1 resumen por grupo cada 60 s
const UY_OFFSET         = -3 * 3_600_000; // horas del resumen en hora de Uruguay

// 👇 Pegá acá tus keys reales de Gemini (AI Studio). Pueden ser varias.
const EXTRA_GEMINI_KEYS = [
    'AQ.Ab8RN6Ki2mY-Lc0bYcSzTBFkJmaE6RSujRGaswExrlUJF7eATw',
];

const GEMINI_MODEL = 'gemini-flash-latest';
const GEMINI_URL   = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
const GROQ_MODEL   = 'llama-3.3-70b-versatile';
const GROQ_LIGHT   = 'llama-3.1-8b-instant';
const DELIRIUS_GEMINI  = 'https://api.delirius.online/ia/gemini';
const DELIRIUS_CHATGPT = 'https://api.delirius.online/ia/chatgpt';
const TIMEOUT      = 25000;

const lastRun = new Map(); // groupId → timestamp

// ── Helpers ───────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const pad = (n) => String(n).padStart(2, '0');

function envKeys(names, extra = []) {
    const keys = new Set();
    for (const n of names) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    for (const k of extra) if (k && String(k).trim()) keys.add(String(k).trim());
    return [...keys];
}

const GEMINI_ENV = ['gemini_api_key', 'GEMINI_API_KEY', 'gemini_api_key1', 'GEMINI_API_KEY1',
                    'gemini_api_key2', 'GEMINI_API_KEY2', 'gemini_api_key3', 'GEMINI_API_KEY3'];
const GROQ_ENV   = ['groq_api_key', 'GROQ_API_KEY', 'groq_api_key1', 'GROQ_API_KEY1',
                    'groq_api_key2', 'GROQ_API_KEY2', 'groq_api_key3', 'GROQ_API_KEY3',
                    'groq_api_key4', 'GROQ_API_KEY4'];

function geminiKeys() {
    const fromList = (process.env.GEMINI_KEYS || '').split(',');
    return envKeys(GEMINI_ENV, [...EXTRA_GEMINI_KEYS, ...fromList]);
}

// ── Proveedores (cada uno devuelve una promesa con el texto) ──────────────────
async function gemini(key, systemPrompt, userPrompt, maxTokens, signal) {
    const res = await axios.post(GEMINI_URL, {
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        generationConfig: { temperature: 0.4, maxOutputTokens: maxTokens, thinkingConfig: { thinkingBudget: 0 } }
    }, { headers: { 'Content-Type': 'application/json', 'X-goog-api-key': key }, timeout: TIMEOUT, signal });
    return res.data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
}

async function groq(key, model, systemPrompt, userPrompt, maxTokens, signal) {
    const res = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model, temperature: 0.4, max_tokens: maxTokens,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
    }, { headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, timeout: TIMEOUT, signal });
    return res.data?.choices?.[0]?.message?.content || '';
}

// Delirius devuelve { status, data: { result } } (o variantes). Sacamos el texto como sea.
function extraerTextoDelirius(d) {
    if (!d) return '';
    if (d.status === false) throw new Error('Delirius status=false');
    const cands = [d?.data?.result, d?.result, d?.data?.response, d?.data?.message, d?.message, d?.data];
    for (const c of cands) if (typeof c === 'string' && c.trim()) return c;
    return '';
}

async function delirius(url, param, systemPrompt, userPrompt, signal) {
    const prompt = `${systemPrompt}\n\n${userPrompt}`;
    const res = await axios.get(url, { params: { [param]: prompt }, timeout: TIMEOUT, signal });
    return extraerTextoDelirius(res.data);
}

async function motorUnificado(systemPrompt, userPrompt) {
    const iaModule = require('./ia');
    const callIA = iaModule.callIA || iaModule;
    if (typeof callIA !== 'function') throw new Error('./ia sin callIA');
    const res = await callIA(systemPrompt, userPrompt);
    if (!res || res === '_SILENT_FAIL_') throw new Error('./ia sin respuesta');
    return res;
}

const validar = (t) => {
    const s = typeof t === 'string' ? t.trim() : '';
    return s.length >= 30 ? s : null;
};

/**
 * Lanza TODAS las IAs a la vez y devuelve la primera respuesta válida.
 * Cuando una gana, se cancelan las demás peticiones HTTP.
 */
async function llamarIA(systemPrompt, userPrompt, maxTokens = 500) {
    const ac = new AbortController();
    const { signal } = ac;
    const errores = [];

    const racers = [];
    racers.push({ name: 'ia-unificada', run: () => motorUnificado(systemPrompt, userPrompt) });
    geminiKeys().forEach((k, i) =>
        racers.push({ name: `gemini#${i + 1}`, run: () => gemini(k, systemPrompt, userPrompt, maxTokens, signal) }));
    const groqKeys = envKeys(GROQ_ENV);
    groqKeys.forEach((k, i) =>
        racers.push({ name: `groq#${i + 1}`, run: () => groq(k, GROQ_MODEL, systemPrompt, userPrompt, maxTokens, signal) }));
    if (groqKeys.length) {
        racers.push({ name: 'groq-liviano', run: () => groq(groqKeys[0], GROQ_LIGHT, systemPrompt, userPrompt, maxTokens, signal) });
    }
    racers.push({ name: 'delirius-gemini',  run: () => delirius(DELIRIUS_GEMINI,  'query', systemPrompt, userPrompt, signal) });
    racers.push({ name: 'delirius-chatgpt', run: () => delirius(DELIRIUS_CHATGPT, 'q',     systemPrompt, userPrompt, signal) });

    const tasks = racers.map(r =>
        Promise.resolve()
            .then(() => r.run())
            .then(t => {
                const limpio = validar(t);
                if (!limpio) throw new Error('respuesta vacía');
                return { name: r.name, texto: limpio };
            })
            .catch(err => {
                if (!signal.aborted) {
                    errores.push(err);
                    console.log(`[RESUMEN] ${r.name} falló: ${err.response?.status || ''} ${err.message}`);
                }
                throw err;
            })
    );

    try {
        const ganador = await Promise.any(tasks);
        console.log(`[RESUMEN] Respondió primero: ${ganador.name} (de ${racers.length} IAs)`);
        return ganador.texto;
    } catch (e) {
        const limit = errores.some(x => x.response?.status === 429 || x.response?.data?.error?.code === 'rate_limit_exceeded');
        const err = new Error('Ninguna IA respondió');
        if (limit) err.response = { status: 429 };
        throw err;
    } finally {
        ac.abort();
    }
}

// Pasa el formato de la IA a formato WhatsApp
function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*(.+)$/gm, '*$1*')
        .replace(/^\s*[-•]\s+/gm, '• ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// Relaciona el número guardado en chatHistory con el JID real del participante
// (así la mención funciona igual con números normales o con LID)
function buildResolver(meta) {
    const map = new Map(); // número → { tag, jid }
    for (const p of meta?.participants || []) {
        const id = p.id || '';
        const [userPart, server] = id.split('@');
        const user = (userPart || '').split(':')[0];
        if (!user || !server) continue;
        const info = { tag: user, jid: `${user}@${server}` };
        for (const c of [id, p.jid, p.lid, p.phoneNumber]) {
            const n = cleanNum(c || '');
            if (n && !map.has(n)) map.set(n, info);
        }
    }
    return map;
}

// Deja solo menciones válidas (@número de alguien del grupo) y arma el array `mentions`
function procesarMenciones(texto, tagToJid, maxMenciones = 8) {
    // La IA a veces pone la etiqueta sin @ o dentro de negrita
    for (const tag of tagToJid.keys()) {
        texto = texto.replace(new RegExp(`(?<![@\\d])${tag}(?!\\d)`, 'g'), `@${tag}`);
    }
    texto = texto.replace(/\*(@\d+)\*/g, '$1');

    const mentions = new Set();
    texto = texto.replace(/@(\d{5,})/g, (m, d) => {
        const jid = tagToJid.get(d);
        if (jid && (mentions.has(jid) || mentions.size < maxMenciones)) {
            mentions.add(jid);
            return m;
        }
        return 'alguien';
    });
    return { texto, mentions: [...mentions] };
}

/**
 * Junta mensajes de TODOS hasta MAX_CONTEXT_CHARS.
 * Va por vueltas: en cada vuelta toma el mensaje más nuevo que le quede a cada persona,
 * así todos quedan representados y se llena el cupo al máximo.
 * Devuelve los mensajes en orden cronológico.
 */
function seleccionarMensajes(msgs) {
    // Cada lista queda de más nuevo a más viejo
    const porUsuario = new Map();
    for (const m of [...msgs].sort((a, b) => b.ts - a.ts)) {
        if (!porUsuario.has(m.userId)) porUsuario.set(m.userId, []);
        porUsuario.get(m.userId).push({ ...m, text: m.text.replace(/\s+/g, ' ').trim().slice(0, MAX_MSG_CHARS) });
    }

    const colas = [...porUsuario.values()];
    const elegidos = [];
    let used = 0;

    while (colas.length) {
        for (let i = colas.length - 1; i >= 0; i--) {
            const cola = colas[i];
            const m = cola[0];
            const len = m.text.length + LINE_OVERHEAD;
            if (used + len > MAX_CONTEXT_CHARS) {   // no entra → esa persona ya no suma más
                colas.splice(i, 1);
                continue;
            }
            used += len;
            elegidos.push(m);
            cola.shift();
            if (!cola.length) colas.splice(i, 1);
        }
        if (used >= MAX_CONTEXT_CHARS - LINE_OVERHEAD) break;
    }
    return elegidos.sort((a, b) => a.ts - b.ts);
}

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        if (!chatId || !chatId.endsWith('@g.us')) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Cantidad de horas (opcional)
        let rawArg = Array.isArray(args) && args.length ? String(args[0]) : '';
        if (!rawArg) rawArg = ((message.body || text || '').trim().split(/\s+/)[1]) || '';
        let hours = DEFAULT_HOURS;
        if (rawArg) {
            const m = rawArg.trim().match(/^(\d+(?:[.,]\d+)?)\s*h?$/i);
            if (!m) {
                return message.reply(
                    '❌ Formato incorrecto.\n\n' +
                    '📌 Uso: *.resumen* o *.resumen <horas>*\n\n' +
                    'Ejemplos:\n• .resumen → últimas 12 h\n• .resumen 6 → últimas 6 h\n• .resumen 24 → últimas 24 h'
                );
            }
            hours = parseFloat(m[1].replace(',', '.'));
        }
        if (hours < MIN_HOURS || hours > MAX_HOURS) {
            return message.reply(`⚠️ Elige entre *${MIN_HOURS}* y *${MAX_HOURS}* horas.`);
        }

        // Cooldown por grupo
        const wait = COOLDOWN_MS - (Date.now() - (lastRun.get(chatId) || 0));
        if (wait > 0) {
            return message.reply(`⏳ Espera *${Math.ceil(wait / 1000)} s* para pedir otro resumen en este grupo.`);
        }

        const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
        if (!chatHistory?.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
        }
        if (typeof chatHistory.getRecentMessages !== 'function') {
            return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de mensajes con hora).');
        }

        // 1) Obtener mensajes de las últimas X horas
        const since = Date.now() - hours * 3_600_000;
        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
        const msgs = chatHistory.getRecentMessages(chatId, since)
            .filter(m => m.text && m.userId !== botNum && !subNums.includes(m.userId));

        const hLabel = Number.isInteger(hours) ? `${hours}` : `${hours}`.replace('.', ',');

        if (msgs.length < 3) {
            return message.reply(
                `📭 No hay suficientes mensajes en las últimas *${hLabel} h* para hacer un resumen.\n` +
                '_Solo se guardan mensajes de texto desde que se activó el registro._'
            );
        }

        lastRun.set(chatId, Date.now());
        const meta = await sock.groupMetadata(chatId).catch(() => null);
        await message.reply(`⏳ _Leyendo los mensajes de las últimas ${hLabel} h..._`);

        // 2) Juntar mensajes de todos hasta 2000 caracteres
        const elegidos = seleccionarMensajes(msgs);
        const personas = [...new Set(elegidos.map(m => m.userId))];

        // 3) Etiquetas: @número real para quienes siguen en el grupo (se convierten en menciones)
        const resolver = buildResolver(meta);
        const etiquetas = {};
        const tagToJid = new Map();
        for (const num of personas) {
            const info = resolver.get(num);
            if (info) {
                etiquetas[num] = `@${info.tag}`;
                tagToJid.set(info.tag, info.jid);
            } else {
                etiquetas[num] = `Miembro ···${num.slice(-4)}`;
            }
        }

        const transcript = elegidos.map(m => {
            const d = new Date(m.ts + UY_OFFSET);
            return `[${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}] ${etiquetas[m.userId]}: ${m.text}`;
        }).join('\n');

        // 4) Llamada a la IA (todas a la vez, gana la más rápida)
        const systemPrompt =
            'Sos un asistente que resume conversaciones de grupos de WhatsApp. ' +
            'Te paso los mensajes (con hora y etiqueta de quien los escribió) y tenés que contar qué se habló.\n\n' +
            'REGLAS:\n' +
            '1. Escribí en español informal (rioplatense), claro y directo.\n' +
            '2. No inventes nada: usá solo lo que está en los mensajes. Si algo no se entiende, no lo mencionés.\n' +
            '3. Cada persona aparece con una etiqueta tipo @59812345678. Para nombrarla usá EXACTAMENTE esa etiqueta, con la @, sin cambiarla y sin agregar nombres. ' +
            'Nombrá solo a quienes sean relevantes (máximo 6 personas distintas); al resto resumilo como "varios" o "el grupo". Si la etiqueta es "Miembro ···1234", usala tal cual.\n' +
            '4. Formato WhatsApp: *negrita* con un solo asterisco, sin # ni **. Usá "• " para listas.\n' +
            '5. Estructura exacta:\n' +
            '*Tema principal:* una o dos oraciones.\n' +
            '*Puntos clave:* 3 a 5 viñetas cortas con lo más importante (quién dijo/propuso qué).\n' +
            '*Acuerdos o pendientes:* solo si los hubo (si no, omití esta parte).\n' +
            '*Clima del grupo:* una frase sobre el tono (humor, discusión, charla tranquila, etc.).\n' +
            `6. Máximo ${MAX_OUTPUT_CHARS - 200} caracteres en total. Sin saludos ni cierres, y sin avisos del tipo "resumen hecho con IA".`;

        const userPrompt =
            `Grupo: ${meta?.subject || 'Grupo'}\n` +
            `Período: últimas ${hLabel} horas (horas en Uruguay)\n` +
            `Mensajes incluidos: ${elegidos.length} de ${msgs.length} · Personas: ${personas.length}\n` +
            `---\n${transcript}\n---\n\nHacé el resumen.`;

        const respuesta = await llamarIA(systemPrompt, userPrompt, 500);
        if (!respuesta) throw new Error('La IA no devolvió texto');

        // 5) Mensaje final
        const groupName = (meta?.subject || 'Grupo').replace(/[*_~`]/g, '');
        const L = [];
        L.push('📝 𝗥𝗘𝗦𝗨𝗠𝗘𝗡 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
        L.push(`_${groupName}_`);
        L.push(`🕒 Últimas *${hLabel} h* · 🇺🇾 Hora de Uruguay`);
        L.push(`💬 *${msgs.length}* mensajes · 👥 *${new Set(msgs.map(m => m.userId)).size}* personas`);
        L.push('━━━━━━━━━━━━');
        L.push('');
        const { texto: cuerpo, mentions } = procesarMenciones(formatear(respuesta).slice(0, MAX_OUTPUT_CHARS), tagToJid);
        L.push(cuerpo);

        await sock.sendMessage(chatId, { text: L.join('\n'), mentions },
            { quoted: message._baileyMessage || message.baileyMessage || message });

    } catch (err) {
        lastRun.delete(chatId);
        console.error('[RESUMEN] Error:', err.message || err);
        const status = err.response?.status;
        const code = err.response?.data?.error?.code;
        if (status === 429 || code === 'rate_limit_exceeded') {
            return message.reply('⏳ Todas las IAs están saturadas ahora mismo. Intenta en unos segundos.');
        }
        return message.reply('❌ No pude hacer el resumen. Intenta de nuevo en un rato.');
    }
};

handler.help    = ['resumen', 'resumen <horas>'];
handler.tags    = ['ia', 'grupos'];
handler.command = /^resumen$/i;
handler.group   = true;

module.exports = handler;