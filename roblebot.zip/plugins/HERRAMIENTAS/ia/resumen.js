'use strict';

/**
 * Plugin: resumen
 * Resume con IA (solo Groq) lo que se habló en el grupo en las últimas X horas.
 *
 * Uso:
 *   .resumen        → últimas 12 horas
 *   .resumen 6      → últimas 6 horas
 *   .resumen 24h    → últimas 24 horas
 *
 * Flujo:
 *   1) Junta mensajes de TODOS (los más recientes de cada uno, de a uno por vuelta)
 *      hasta llenar MAX_CONTEXT_CHARS (2000 caracteres).
 *   2) Prueba las keys de Groq DE A UNA, en orden, hasta que alguna funcione.
 *      Arranca con el modelo más rápido (instant); si todas las keys fallan con ese,
 *      pasa al siguiente modelo de GROQ_MODELS.
 *   3) Envía el resumen con @menciones.
 *
 * Requiere chatHistory.js con getRecentMessages().
 *
 * API keys de Groq (https://console.groq.com/keys). Podés cargarlas de 3 formas:
 *   - Agregalas al array GROQ_KEYS_EXTRA acá abajo (una por línea), o
 *   - Variable de entorno GROQ_KEYS (separadas por coma), o
 *   - Variables GROQ_API_KEY, GROQ_API_KEY1 ... GROQ_API_KEY10
 */

const axios = require('axios');

// ── Configuración ─────────────────────────────────────────────────────────────
const DEFAULT_HOURS     = 12;       // si no se indica cantidad
const MIN_HOURS         = 1;
const MAX_HOURS         = 48;       // chatHistory guarda ~50 h
const MAX_CONTEXT_CHARS = 4000;     // tope TOTAL de texto que se le manda a la IA
const MAX_MSG_CHARS     = 200;      // cada mensaje se recorta a esto (para que entren más personas)
const LINE_OVERHEAD     = 24;       // "[HH:MM] @59812345678: " por mensaje
const MAX_OUTPUT_CHARS  = 1200;     // tope del resumen final
const COOLDOWN_MS       = 60_000;   // 1 resumen por grupo cada 60 s
const UY_OFFSET         = -3 * 3_600_000; // horas del resumen en hora de Uruguay

// 👇 Pegá acá tus keys de Groq (empiezan con gsk_...). Agregá todas las que quieras.
const GROQ_KEYS_EXTRA = [
    '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',
    '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',
];

// Modelos en orden de prioridad (el primero es el más rápido).
// Cada modelo tiene su propio límite en Groq, así que si uno se satura el siguiente suele andar.
// (el 70b resume mucho mejor que el 8b; en Groq sigue siendo rápido)
const GROQ_MODELS = [
    'llama-3.3-70b-versatile',
    'openai/gpt-oss-20b',
    'llama-3.1-8b-instant',
];

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const TIMEOUT  = 15000; // por intento (si una key tarda de más, pasa a la siguiente)

const lastRun = new Map(); // groupId → timestamp

// ── Helpers ───────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const pad = (n) => String(n).padStart(2, '0');

const GROQ_ENV = ['groq_api_key', 'GROQ_API_KEY',
    ...Array.from({ length: 10 }, (_, i) => [`groq_api_key${i + 1}`, `GROQ_API_KEY${i + 1}`]).flat()];

function groqKeys() {
    const keys = new Set();
    for (const k of GROQ_KEYS_EXTRA) if (k && String(k).trim()) keys.add(String(k).trim());
    for (const k of (process.env.GROQ_KEYS || '').split(',')) if (k && k.trim()) keys.add(k.trim());
    for (const n of GROQ_ENV) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    return [...keys];
}

// ── Groq ──────────────────────────────────────────────────────────────────────
async function groq(key, model, systemPrompt, userPrompt, maxTokens) {
    const body = {
        model, temperature: 0.4, max_tokens: maxTokens,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
    };
    if (model.startsWith('openai/gpt-oss')) body.reasoning_effort = 'low';
    const res = await axios.post(GROQ_URL, body, {
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        timeout: TIMEOUT
    });
    return res.data?.choices?.[0]?.message?.content || '';
}

const validar = (t) => {
    const s = typeof t === 'string' ? t.trim() : '';
    return s.length >= 30 ? s : null;
};

/**
 * Prueba las keys de a una (en orden) y devuelve la primera respuesta válida.
 * Orden: para cada modelo, todas las keys; si ninguna sirve, pasa al siguiente modelo.
 * Las keys que dan 401/403 (inválidas) se saltean en los modelos siguientes.
 */
async function llamarIA(systemPrompt, userPrompt, maxTokens = 500) {
    const keys = groqKeys();
    if (!keys.length) throw new Error('No hay API keys de Groq configuradas');

    const invalidas = new Set();
    let huboLimite = false;

    for (const model of GROQ_MODELS) {
        for (let i = 0; i < keys.length; i++) {
            if (invalidas.has(i)) continue;
            try {
                const limpio = validar(await groq(keys[i], model, systemPrompt, userPrompt, maxTokens));
                if (!limpio) throw new Error('respuesta vacía');
                console.log(`[RESUMEN] OK con ${model} (key #${i + 1} de ${keys.length})`);
                return limpio;
            } catch (err) {
                const status = err.response?.status;
                if (status === 401 || status === 403) invalidas.add(i);
                if (status === 429) huboLimite = true;
                console.log(`[RESUMEN] ${model} key#${i + 1} falló: ${status || ''} ${err.message}`);
            }
        }
    }

    const err = new Error('Ninguna key de Groq respondió');
    if (huboLimite) err.response = { status: 429 };
    throw err;
}

// Pasa el formato de la IA a formato WhatsApp
function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*(.+)$/gm, '*$1*')
        .replace(/^\s*[-•]\s+/gm, '• ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// Relaciona el número guardado en chatHistory con el JID real del participante
// (así la mención funciona igual con números normales o con LID)
function buildResolver(meta) {
    const map = new Map(); // número → { tag, jid }
    for (const p of meta?.participants || []) {
        const id = p.id || '';
        const [userPart, server] = id.split('@');
        const user = (userPart || '').split(':')[0];
        if (!user || !server) continue;
        const info = { tag: user, jid: `${user}@${server}` };
        for (const c of [id, p.jid, p.lid, p.phoneNumber]) {
            const n = cleanNum(c || '');
            if (n && !map.has(n)) map.set(n, info);
        }
    }
    return map;
}

// Deja solo menciones válidas (@número de alguien del grupo) y arma el array `mentions`
function procesarMenciones(texto, tagToJid, maxMenciones = 8) {
    // La IA a veces pone la etiqueta sin @ o dentro de negrita
    for (const tag of tagToJid.keys()) {
        texto = texto.replace(new RegExp(`(?<![@\\d])${tag}(?!\\d)`, 'g'), `@${tag}`);
    }
    texto = texto.replace(/\*(@\d+)\*/g, '$1');

    const mentions = new Set();
    texto = texto.replace(/@(\d{5,})/g, (m, d) => {
        const jid = tagToJid.get(d);
        if (jid && (mentions.has(jid) || mentions.size < maxMenciones)) {
            mentions.add(jid);
            return m;
        }
        return 'alguien';
    });
    return { texto, mentions: [...mentions] };
}

/**
 * Junta mensajes de TODOS hasta MAX_CONTEXT_CHARS.
 * Va por vueltas: en cada vuelta toma el mensaje más nuevo que le quede a cada persona,
 * así todos quedan representados y se llena el cupo al máximo.
 * Devuelve los mensajes en orden cronológico.
 */
function seleccionarMensajes(msgs) {
    // Cada lista queda de más nuevo a más viejo
    // Descarta ruido ("k", "oe", stickers sueltos...) para que entre más contenido útil
    const utiles = msgs.filter(m => m.text.replace(/[^\p{L}\p{N}]/gu, '').length >= 3);
    const base = utiles.length >= 5 ? utiles : msgs;

    const porUsuario = new Map();
    for (const m of [...base].sort((a, b) => b.ts - a.ts)) {
        if (!porUsuario.has(m.userId)) porUsuario.set(m.userId, []);
        porUsuario.get(m.userId).push({ ...m, text: m.text.replace(/\s+/g, ' ').trim().slice(0, MAX_MSG_CHARS) });
    }

    const colas = [...porUsuario.values()];
    const elegidos = [];
    let used = 0;

    while (colas.length) {
        for (let i = colas.length - 1; i >= 0; i--) {
            const cola = colas[i];
            const m = cola[0];
            const len = m.text.length + LINE_OVERHEAD;
            if (used + len > MAX_CONTEXT_CHARS) {   // no entra → esa persona ya no suma más
                colas.splice(i, 1);
                continue;
            }
            used += len;
            elegidos.push(m);
            cola.shift();
            if (!cola.length) colas.splice(i, 1);
        }
        if (used >= MAX_CONTEXT_CHARS - LINE_OVERHEAD) break;
    }
    return elegidos.sort((a, b) => a.ts - b.ts);
}

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        if (!chatId || !chatId.endsWith('@g.us')) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Cantidad de horas (opcional)
        let rawArg = Array.isArray(args) && args.length ? String(args[0]) : '';
        if (!rawArg) rawArg = ((message.body || text || '').trim().split(/\s+/)[1]) || '';
        let hours = DEFAULT_HOURS;
        if (rawArg) {
            const m = rawArg.trim().match(/^(\d+(?:[.,]\d+)?)\s*h?$/i);
            if (!m) {
                return message.reply(
                    '❌ Formato incorrecto.\n\n' +
                    '📌 Uso: *.resumen* o *.resumen <horas>*\n\n' +
                    'Ejemplos:\n• .resumen → últimas 12 h\n• .resumen 6 → últimas 6 h\n• .resumen 24 → últimas 24 h'
                );
            }
            hours = parseFloat(m[1].replace(',', '.'));
        }
        if (hours < MIN_HOURS || hours > MAX_HOURS) {
            return message.reply(`⚠️ Elige entre *${MIN_HOURS}* y *${MAX_HOURS}* horas.`);
        }

        // Cooldown por grupo
        const wait = COOLDOWN_MS - (Date.now() - (lastRun.get(chatId) || 0));
        if (wait > 0) {
            return message.reply(`⏳ Espera *${Math.ceil(wait / 1000)} s* para pedir otro resumen en este grupo.`);
        }

        const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
        if (!chatHistory?.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
        }
        if (typeof chatHistory.getRecentMessages !== 'function') {
            return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de mensajes con hora).');
        }

        // 1) Obtener mensajes de las últimas X horas
        const since = Date.now() - hours * 3_600_000;
        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
        const msgs = chatHistory.getRecentMessages(chatId, since)
            .filter(m => m.text && m.userId !== botNum && !subNums.includes(m.userId));

        const hLabel = Number.isInteger(hours) ? `${hours}` : `${hours}`.replace('.', ',');

        if (msgs.length < 3) {
            return message.reply(
                `📭 No hay suficientes mensajes en las últimas *${hLabel} h* para hacer un resumen.\n` +
                '_Solo se guardan mensajes de texto desde que se activó el registro._'
            );
        }

        lastRun.set(chatId, Date.now());
        const meta = await sock.groupMetadata(chatId).catch(() => null);
        // Sin await: el aviso sale en paralelo y no retrasa la llamada a la IA
        Promise.resolve(message.reply(`⏳ _Leyendo los mensajes de las últimas ${hLabel} h..._`)).catch(() => {});

        // 2) Juntar mensajes de todos hasta 2000 caracteres
        const elegidos = seleccionarMensajes(msgs);
        const personas = [...new Set(elegidos.map(m => m.userId))];

        // 3) Etiquetas: @número real para quienes siguen en el grupo (se convierten en menciones)
        const resolver = buildResolver(meta);
        const etiquetas = {};
        const tagToJid = new Map();
        for (const num of personas) {
            const info = resolver.get(num);
            if (info) {
                etiquetas[num] = `@${info.tag}`;
                tagToJid.set(info.tag, info.jid);
            } else {
                etiquetas[num] = `Miembro ···${num.slice(-4)}`;
            }
        }

        const transcript = elegidos.map(m => {
            const d = new Date(m.ts + UY_OFFSET);
            return `[${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}] ${etiquetas[m.userId]}: ${m.text}`;
        }).join('\n');

        // 4) Llamada a Groq (key por key hasta que una funcione)
        const systemPrompt =
            'Le contás a alguien que no leyó un chat de WhatsApp de qué se habló, como si se lo contaras a un amigo, en español rioplatense natural. ' +
            'NO cites mensajes sueltos ni hagas una lista de frases por persona. Ignorá stickers, risas, "k", saludos y mensajes sin contenido. ' +
            'Agrupá por temas, en orden cronológico, y explicá de qué trató cada tema y qué dijo u opinó cada persona clave DENTRO de la oración ' +
            '(ej: "@59811111111 contó que… y @59822222222 le respondió que…"). ' +
            'Nombrá personas solo con su etiqueta exacta (ej: @59812345678), sin comillas, máx. 6; al resto como "varios" o "el grupo". ' +
            'No inventes: si algo no se entiende, omitilo. ' +
            'Formato WhatsApp: *negrita* con un asterisco, sin # ni **, viñetas con "• ". ' +
            'Estructura:\n' +
            '*De qué se habló:* 3 a 5 viñetas, una por tema, cada una con 1-2 oraciones completas.\n' +
            '*Lo más destacado:* una frase (algo gracioso, una discusión, una noticia).\n' +
            '*Clima:* una frase.\n' +
            `Máx. ${MAX_OUTPUT_CHARS - 200} caracteres, sin saludos ni cierres.`;

        const userPrompt = `Grupo: ${meta?.subject || 'Grupo'} (últimas ${hLabel} h, hora Uruguay)\n${transcript}`;

        const respuesta = await llamarIA(systemPrompt, userPrompt, 500);
        if (!respuesta) throw new Error('La IA no devolvió texto');

        // 5) Mensaje final
        const groupName = (meta?.subject || 'Grupo').replace(/[*_~`]/g, '');
        const L = [];
        L.push('📝 𝗥𝗘𝗦𝗨𝗠𝗘𝗡 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
        L.push(`_${groupName}_`);
        L.push(`🕒 Últimas *${hLabel} h* · 🇺🇾 Hora de Uruguay`);
        L.push(`💬 *${msgs.length}* mensajes · 👥 *${new Set(msgs.map(m => m.userId)).size}* personas`);
        L.push('━━━━━━━━━━━━');
        L.push('');
        const { texto: cuerpo, mentions } = procesarMenciones(formatear(respuesta).slice(0, MAX_OUTPUT_CHARS), tagToJid);
        L.push(cuerpo);

        await sock.sendMessage(chatId, { text: L.join('\n'), mentions },
            { quoted: message._baileyMessage || message.baileyMessage || message });

    } catch (err) {
        lastRun.delete(chatId);
        console.error('[RESUMEN] Error:', err.message || err);
        const status = err.response?.status;
        if (status === 429) {
            return message.reply('⏳ Groq está saturado ahora mismo. Intenta en unos segundos.');
        }
        return message.reply('❌ No pude hacer el resumen. Intenta de nuevo en un rato.');
    }
};

handler.help    = ['resumen', 'resumen <horas>'];
handler.tags    = ['ia', 'grupos'];
handler.command = /^resumen$/i;
handler.group   = true;

module.exports = handler;