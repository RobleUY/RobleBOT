'use strict';

/**
 * Plugin: pregunta
 * Responde con IA (Groq) preguntas sobre lo que se habló en el grupo.
 *
 * Uso:
 *   .pregunta quién dijo que iba a comprar el auto
 *   .pregunta con quién habló @usuario
 *   .pregunta @usuario dijo algo de la fiesta?
 *   .pregunta 24h quién habló de fútbol      → busca en las últimas 24 h (por defecto 12, máx. 48)
 *   (también podés responder a un mensaje con .pregunta ... y se toma a esa persona)
 *
 * Cómo funciona:
 *   1) Lee el historial de las últimas X horas (chatHistory.getRecentMessages).
 *   2) NO manda simplemente "lo último": elige los mensajes MÁS RELEVANTES para la pregunta
 *      (los que contienen las palabras clave, los de la persona mencionada y los que le
 *      responden o la nombran), con los mensajes de alrededor para dar contexto.
 *   3) Arma un transcript con P1, P2... (personas), respuestas marcadas y días separados.
 *   4) Groq responde basándose SOLO en ese transcript y se convierten P1, P2... en @menciones.
 *
 * Requiere chatHistory.js con getRecentMessages().
 * Keys: variable GROQ_KEYS (separadas por coma) o GROQ_API_KEY, GROQ_API_KEY1..10.
 * Debug: PREGUNTA_DEBUG=1 muestra en consola el prompt exacto que recibe la IA.
 */

const axios = require('axios');

// ── Configuración ─────────────────────────────────────────────────────────────
const DEFAULT_HOURS     = 12;
const MIN_HOURS         = 1;
const MAX_HOURS         = 48;
const MAX_CONTEXT_CHARS = 10000;
const MAX_MSG_CHARS     = 300;
const QUOTE_CHARS       = 90;
const LINE_OVERHEAD     = 28;
const MERGE_WINDOW_MS   = 90_000;
const GAP_MS            = 30 * 60_000;
const MAX_QUESTION      = 300;
const MAX_OUTPUT_CHARS  = 1800;
const MAX_MENTIONS      = 10;
const COOLDOWN_MS       = 20_000;
const UY_OFFSET         = -3 * 3_600_000;

// Preferí variables de entorno. Si querés, ponelas acá (y NO compartas este archivo).
const GROQ_KEYS_EXTRA = [
    // 'gsk_...',
];

const GROQ_MODELS = [
    'llama-3.3-70b-versatile',
    'openai/gpt-oss-120b',
    'openai/gpt-oss-20b',
    'llama-3.1-8b-instant',
];

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const TIMEOUT  = 25000;

const lastRun = new Map();

// Palabras que no sirven para buscar
const STOPWORDS = new Set((
    'quien quienes que como cual cuales cuando donde cuanto cuantos porque para por con sin sobre ' +
    'del las los una uno unos unas esto esta este eso esa ese aquel mas muy pero tambien ' +
    'dijo dijeron dice dicen decir hablo hablaron hablando hablar habla hablan comento comentaron conto contaron ' +
    'escribio escribieron puso pusieron mando mandaron manda hizo hicieron paso pasa ' +
    'algo alguien alguno alguna algun nadie todos todo nada fue era son ser hay habia hubo estaba estaban ' +
    'ayer hoy grupo mensaje mensajes chat tal cosa cosas tema temas ultimo ultima ultimas ultimos ' +
    'horas hora mismo misma les nos mis sus mio tuyo ese ahi aca alla ' +
    'sabes saber sabe saben dime decime fijate busca buscar'
).split(/\s+/));

// ── Helpers ───────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const pad = (n) => String(n).padStart(2, '0');
const uy = (ts) => new Date(ts + UY_OFFSET);
const hhmm = (ts) => { const d = uy(ts); return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; };
const ddmm = (ts) => { const d = uy(ts); return `${pad(d.getUTCDate())}/${pad(d.getUTCMonth() + 1)}`; };

const normalizar = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

const GROQ_ENV = ['groq_api_key', 'GROQ_API_KEY',
    ...Array.from({ length: 10 }, (_, i) => [`groq_api_key${i + 1}`, `GROQ_API_KEY${i + 1}`]).flat()];

function groqKeys() {
    const keys = new Set();
    for (const k of GROQ_KEYS_EXTRA) if (k && String(k).trim()) keys.add(String(k).trim());
    for (const k of (process.env.GROQ_KEYS || '').split(',')) if (k && k.trim()) keys.add(k.trim());
    for (const n of GROQ_ENV) {
        const v = process.env[n];
        if (v && v.trim()) keys.add(v.trim());
    }
    return [...keys];
}

// ── Groq ──────────────────────────────────────────────────────────────────────
async function groq(key, model, systemPrompt, userPrompt, maxTokens) {
    const isOss = model.startsWith('openai/gpt-oss');
    const body = {
        model,
        temperature: 0.2,
        max_tokens: isOss ? maxTokens + 1500 : maxTokens,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
    };
    if (isOss) body.reasoning_effort = 'low';
    const res = await axios.post(GROQ_URL, body, {
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        timeout: TIMEOUT
    });
    return res.data?.choices?.[0]?.message?.content || '';
}

const validar = (t) => {
    const s = typeof t === 'string' ? t.trim() : '';
    return s.length >= 5 ? s : null;
};

async function llamarIA(systemPrompt, userPrompt, maxTokens = 600) {
    const keys = groqKeys();
    if (!keys.length) throw new Error('No hay API keys de Groq configuradas');

    const invalidas = new Set();
    let huboLimite = false;

    for (const model of GROQ_MODELS) {
        for (let i = 0; i < keys.length; i++) {
            if (invalidas.has(i)) continue;
            try {
                const limpio = validar(await groq(keys[i], model, systemPrompt, userPrompt, maxTokens));
                if (!limpio) throw new Error('respuesta vacía');
                console.log(`[PREGUNTA] OK con ${model} (key #${i + 1} de ${keys.length})`);
                return limpio;
            } catch (err) {
                const status = err.response?.status;
                if (status === 401 || status === 403) invalidas.add(i);
                if (status === 429) huboLimite = true;
                const detalle = err.response?.data?.error?.message || err.message;
                console.log(`[PREGUNTA] ${model} key#${i + 1} falló: ${status || ''} ${detalle}`);
            }
        }
    }

    const err = new Error('Ninguna key de Groq respondió');
    if (huboLimite) err.response = { status: 429 };
    throw err;
}

function formatear(texto) {
    return texto
        .replace(/\*\*([\s\S]+?)\*\*/g, '*$1*')
        .replace(/^\s*#{1,6}\s*(.+)$/gm, '*$1*')
        .replace(/^\s*[-•*]\s+/gm, '• ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function recortar(t, max) {
    if (t.length <= max) return t;
    const cut = t.slice(0, max);
    const i = cut.lastIndexOf('\n');
    return (i > max * 0.5 ? cut.slice(0, i) : cut).trim();
}

function buildResolver(meta) {
    const map = new Map(); // número → { tag, jid }
    for (const p of meta?.participants || []) {
        const id = p.id || '';
        const [userPart, server] = id.split('@');
        const user = (userPart || '').split(':')[0];
        if (!user || !server) continue;
        const info = { tag: user, jid: `${user}@${server}` };
        for (const c of [id, p.jid, p.lid, p.phoneNumber]) {
            const n = cleanNum(c || '');
            if (n && !map.has(n)) map.set(n, info);
        }
    }
    return map;
}

// ── Lectura del mensaje del comando (menciones / respuesta a otro mensaje) ────
function contextInfoDe(message) {
    const fuentes = [message?._baileyMessage, message?.baileyMessage, message?.msg, message];
    for (const f of fuentes) {
        let inner = f?.message || f;
        for (let k = 0; k < 3; k++) {
            inner = inner?.ephemeralMessage?.message || inner?.viewOnceMessage?.message ||
                    inner?.documentWithCaptionMessage?.message || inner;
        }
        if (!inner || typeof inner !== 'object') continue;
        if (inner.contextInfo) return inner.contextInfo;
        for (const v of Object.values(inner)) {
            if (v && typeof v === 'object' && v.contextInfo) return v.contextInfo;
        }
    }
    return null;
}

function mencionadosDe(message, ctx) {
    const out = new Set();
    const push = (v) => { if (Array.isArray(v)) v.forEach(x => x && out.add(String(x))); };
    push(message?.mentionedJid); push(message?.mentionedJids); push(message?.mentions);
    push(ctx?.mentionedJid);
    return [...out];
}

function textoCitadoDe(ctx) {
    const q = ctx?.quotedMessage;
    if (!q) return '';
    return q.conversation || q.extendedTextMessage?.text || q.imageMessage?.caption ||
           q.videoMessage?.caption || '';
}

// ── Lectura de mensajes del historial (tolerante a distintos formatos) ───────
function msgId(m) {
    return String(m.id || m.msgId || m.messageId || m.key?.id || '') || null;
}

function extraerCita(m) {
    let q = m.quoted || m.quotedMsg || m.quotedMessage || m.reply || m.replyTo || null;
    if (typeof q === 'string') q = { text: q };
    const text = (q && (q.text || q.body || q.message || q.caption)) || m.quotedText || '';
    const user = (q && (q.userId || q.sender || q.participant || q.from)) ||
                 m.quotedUserId || m.quotedParticipant || m.quotedSender || '';
    const id   = (q && (q.id || q.msgId || q.key?.id)) ||
                 m.quotedId || m.quotedMsgId || m.replyToId || '';
    if (!text && !user && !id) return null;
    return { text: typeof text === 'string' ? text : '', user: String(user || ''), id: String(id || '') };
}

function nombreDe(m) {
    const n = m.name || m.pushName || m.senderName || m.userName || '';
    return typeof n === 'string'
        ? n.replace(/[^\p{L}\p{N} ._-]/gu, '').trim().slice(0, 20)
        : '';
}

const limpiarTexto = (t) => String(t || '').replace(/\s+/g, ' ').trim();

function esRuido(texto) {
    if (/^[.!#\/]\w+/.test(texto)) return true;
    const s = texto.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
    if (!s) return true;
    return /^(k+|(ja|je|ji|jo|ha)+j?a?|xd+|l+o+l+|a+h+|e+h+|o+e+)$/.test(s);
}

function prepararMensajes(msgs, canon) {
    const ordenados = [...msgs].sort((a, b) => a.ts - b.ts);

    const porId = new Map();
    for (const m of ordenados) {
        const id = msgId(m);
        if (id) porId.set(id, m);
    }

    let norm = ordenados.map(m => ({
        id: msgId(m),
        ts: m.ts,
        user: canon(m.userId),
        name: nombreDe(m),
        text: limpiarTexto(m.text).slice(0, MAX_MSG_CHARS),
        q: (() => {
            const q = extraerCita(m);
            if (!q) return null;
            const orig = q.id ? porId.get(q.id) : null;
            return {
                user: orig ? canon(orig.userId) : (q.user ? canon(q.user) : ''),
                text: limpiarTexto(orig ? orig.text : q.text).slice(0, QUOTE_CHARS)
            };
        })()
    }));

    const sinRuido = norm.filter(m => !esRuido(m.text));
    if (sinRuido.length >= 3) norm = sinRuido;

    const unidos = [];
    for (const m of norm) {
        const prev = unidos[unidos.length - 1];
        if (prev && prev.user === m.user && !m.q && (m.ts - prev.tsFin) <= MERGE_WINDOW_MS &&
            prev.text.length + m.text.length < MAX_MSG_CHARS * 1.5) {
            prev.text += ' / ' + m.text;
            prev.tsFin = m.ts;
        } else {
            unidos.push({ ...m, tsFin: m.ts });
        }
    }
    return unidos;
}

// ── Palabras clave de la pregunta ─────────────────────────────────────────────
function extraerBusqueda(pregunta) {
    // frases entre comillas → búsqueda exacta
    const phrases = [];
    const re = /"([^"]{2,})"|«([^»]{2,})»|“([^”]{2,})”/g;
    let m;
    while ((m = re.exec(pregunta))) {
        const p = normalizar(m[1] || m[2] || m[3]).trim();
        if (p) phrases.push(p);
    }

    const sinMenciones = pregunta.replace(/@\d{5,}/g, ' ');
    const palabras = normalizar(sinMenciones).split(/[^a-z0-9ñ]+/).filter(Boolean);
    const keywords = [...new Set(palabras.filter(w => w.length >= 3 && !STOPWORDS.has(w)))];
    return { keywords, phrases };
}

function kwMatch(textoNorm, kw) {
    if (textoNorm.includes(kw)) return true;
    // raíz aproximada: "comprar" también encuentra "compro", "compré"...
    return kw.length >= 6 && textoNorm.includes(kw.slice(0, kw.length - 2));
}

/**
 * Elige los mensajes más relevantes (con contexto alrededor) dentro del cupo de caracteres.
 * Prioridad: coincidencia con la pregunta > persona mencionada (y quienes le responden/nombran) > lo más reciente.
 */
function seleccionar(lista, { keywords, phrases, targets, canon }) {
    const n = lista.length;
    const prio = new Array(n).fill(0);
    const norm = lista.map(m => normalizar(m.text));
    const bump = (i, v) => { if (i >= 0 && i < n && v > prio[i]) prio[i] = v; };

    for (let i = 0; i < n; i++) {
        const m = lista[i];

        // coincidencias con la pregunta
        let score = 0;
        for (const k of keywords) if (kwMatch(norm[i], k)) score++;
        for (const p of phrases) if (norm[i].includes(p)) score += 3;
        if (score > 0) {
            bump(i, 10 + score);
            for (const d of [-3, -2, -1, 1, 2]) bump(i + d, 8);
        }

        // persona mencionada: sus mensajes, quienes le responden y quienes la nombran
        if (targets.size) {
            let toca = targets.has(m.user) || (m.q && targets.has(m.q.user));
            if (!toca) {
                const re = /@(\d{5,})/g;
                let mm;
                while ((mm = re.exec(m.text))) if (targets.has(canon(mm[1]))) { toca = true; break; }
            }
            if (toca) {
                bump(i, 6);
                bump(i - 1, 5);
                bump(i + 1, 5);
            }
        }

        // relleno: lo más reciente
        bump(i, 1 + i / n);
    }

    const orden = lista.map((_, i) => i).sort((a, b) => (prio[b] - prio[a]) || (b - a));
    const elegidos = [];
    let used = 0;
    for (const i of orden) {
        const m = lista[i];
        const cost = m.text.length + LINE_OVERHEAD + (m.q ? Math.min(m.q.text.length, QUOTE_CHARS) + 30 : 0);
        if (used + cost > MAX_CONTEXT_CHARS && elegidos.length >= 10) continue;
        used += cost;
        elegidos.push(i);
    }
    elegidos.sort((a, b) => a - b);
    return elegidos;
}

const fmtPausa = (ms) => {
    const min = Math.round(ms / 60000);
    return min >= 90 ? `${Math.round(min / 60)} h` : `${min} min`;
};

function parsearArgs(raw) {
    let hours = DEFAULT_HOURS;
    const tokens = raw.trim().split(/\s+/).filter(Boolean);
    const isH = (t) => /^\d+(?:[.,]\d+)?h$/i.test(t);
    const toH = (t) => parseFloat(t.replace(/h$/i, '').replace(',', '.'));
    if (tokens.length && isH(tokens[0])) hours = toH(tokens.shift());
    else if (tokens.length > 1 && isH(tokens[tokens.length - 1])) hours = toH(tokens.pop());
    return { hours, pregunta: tokens.join(' ').trim() };
}

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    try {
        if (!chatId || !chatId.endsWith('@g.us')) {
            return message.reply('❌ Este comando solo funciona en grupos.');
        }

        // Texto de la pregunta
        let raw = Array.isArray(args) && args.length ? args.join(' ') : '';
        if (!raw) {
            raw = String(message.body || text || '').replace(/^\s*[^\p{L}\p{N}\s@]?\s*pregunta\b/iu, '');
        }
        const { hours, pregunta: preguntaRaw } = parsearArgs(raw);

        const ctx = contextInfoDe(message);
        const mencionados = mencionadosDe(message, ctx);
        const citadoUser = ctx?.participant || '';

        if (preguntaRaw.replace(/@\d{5,}/g, '').trim().length < 3 && !mencionados.length) {
            return message.reply(
                '❓ *Cómo usar .pregunta*\n\n' +
                '• .pregunta quién dijo que iba a comprar el auto\n' +
                '• .pregunta con quién habló @usuario\n' +
                '• .pregunta @usuario dijo algo de la fiesta?\n' +
                '• .pregunta 24h quién habló de fútbol\n\n' +
                `_Busca en las últimas ${DEFAULT_HOURS} h por defecto (máx. ${MAX_HOURS} h)._`
            );
        }
        if (preguntaRaw.length > MAX_QUESTION) {
            return message.reply(`⚠️ La pregunta es muy larga (máx. ${MAX_QUESTION} caracteres).`);
        }
        if (hours < MIN_HOURS || hours > MAX_HOURS) {
            return message.reply(`⚠️ Elige entre *${MIN_HOURS}* y *${MAX_HOURS}* horas.`);
        }

        const wait = COOLDOWN_MS - (Date.now() - (lastRun.get(chatId) || 0));
        if (wait > 0) {
            return message.reply(`⏳ Espera *${Math.ceil(wait / 1000)} s* para hacer otra pregunta en este grupo.`);
        }

        const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
        if (!chatHistory?.isReady) {
            return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
        }
        if (typeof chatHistory.getRecentMessages !== 'function') {
            return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de mensajes con hora).');
        }

        const since = Date.now() - hours * 3_600_000;
        const botNum = global.mainBotNumber || '';
        const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
        const isBot = (n) => n === botNum || subNums.includes(n);
        const msgs = chatHistory.getRecentMessages(chatId, since)
            .filter(m => m.text && m.userId !== botNum && !subNums.includes(m.userId));

        const hLabel = Number.isInteger(hours) ? `${hours}` : `${hours}`.replace('.', ',');

        if (msgs.length < 3) {
            return message.reply(
                `📭 No hay suficientes mensajes en las últimas *${hLabel} h* para responder.\n` +
                '_Solo se guardan mensajes de texto desde que se activó el registro._'
            );
        }

        lastRun.set(chatId, Date.now());
        const meta = await sock.groupMetadata(chatId).catch(() => null);
        Promise.resolve(message.reply(`🔎 _Buscando en los mensajes de las últimas ${hLabel} h..._`)).catch(() => {});

        const resolver = buildResolver(meta);
        const canon = (id) => {
            const n = cleanNum(id);
            return resolver.get(n)?.tag || n;
        };

        // Personas a las que apunta la pregunta
        const targets = new Set();
        for (const j of mencionados) { const c = canon(j); if (c && !isBot(c)) targets.add(c); }
        for (const mm of preguntaRaw.matchAll(/@(\d{5,})/g)) {
            const c = canon(mm[1]);
            if (c && !isBot(c)) targets.add(c);
        }
        let citadoCanon = '';
        let citadoTexto = '';
        if (!targets.size && citadoUser) {
            const c = canon(citadoUser);
            if (c && !isBot(c)) {
                targets.add(c);
                citadoCanon = c;
                citadoTexto = limpiarTexto(textoCitadoDe(ctx)).slice(0, 120);
            }
        }

        // 2) Selección de mensajes relevantes
        const preparados = prepararMensajes(msgs, canon);
        const { keywords, phrases } = extraerBusqueda(preguntaRaw);
        const idxs = seleccionar(preparados, { keywords, phrases, targets, canon });

        // Alias P1, P2... (primero las personas mencionadas en la pregunta)
        const aliasDe = new Map();
        const canonDe = new Map();
        const nombres = new Map();
        const alias = (c) => {
            if (!aliasDe.has(c)) {
                const a = `P${aliasDe.size + 1}`;
                aliasDe.set(c, a);
                canonDe.set(a, c);
            }
            return aliasDe.get(c);
        };
        for (const t of targets) alias(t);
        for (const i of idxs) {
            const m = preparados[i];
            if (m.name && !nombres.has(m.user)) nombres.set(m.user, m.name);
        }

        const reemplazarMenciones = (t) => t.replace(/@(\d{5,})/g, (x, d) => {
            const c = canon(d);
            if (isBot(c)) return 'el bot';
            return alias(c);
        });
        const quienEs = (c) => (!c ? 'alguien' : isBot(c) ? 'el bot' : alias(c));

        // 3) Transcript
        const lineas = [];
        let prevIdx = null;
        let prevTs = null;
        let prevDia = null;
        const hoy = ddmm(Date.now());
        const ayer = ddmm(Date.now() - 86_400_000);
        for (const i of idxs) {
            const m = preparados[i];
            const dia = ddmm(m.ts);
            if (dia !== prevDia) {
                const etiqueta = dia === hoy ? 'hoy' : dia === ayer ? 'ayer' : '';
                lineas.push(`=== Día ${dia}${etiqueta ? ` (${etiqueta})` : ''} ===`);
                prevDia = dia;
            } else if (prevIdx !== null && i - prevIdx > 1) {
                lineas.push('— (mensajes salteados) —');
            } else if (prevTs && m.ts - prevTs > GAP_MS) {
                lineas.push(`— pasaron ${fmtPausa(m.ts - prevTs)} sin mensajes —`);
            }
            const quien = alias(m.user);
            const cuerpo = reemplazarMenciones(m.text);
            let cita = '';
            if (m.q) {
                const qt = reemplazarMenciones(m.q.text);
                cita = ` (responde a ${quienEs(m.q.user)}${qt ? `: "${qt}"` : ''})`;
            }
            lineas.push(`[${hhmm(m.ts)}] ${quien}${cita}: ${cuerpo}`);
            prevIdx = i;
            prevTs = m.tsFin;
        }
        const transcript = lineas.join('\n');

        const preguntaIA = reemplazarMenciones(preguntaRaw);
        const mencionadasLista = [...targets].map(c => alias(c)).join(', ');
        const notaRespuesta = citadoCanon
            ? `El usuario hizo la pregunta respondiendo a un mensaje de ${alias(citadoCanon)}` +
              `${citadoTexto ? `: "${citadoTexto}"` : ''}.`
            : '';
        const leyenda = [...aliasDe.entries()]
            .map(([c, a]) => nombres.has(c) ? `${a} (se hace llamar "${nombres.get(c)}")` : a)
            .join(', ');

        const aliasToTag = new Map();
        for (const [c, a] of aliasDe) {
            const info = resolver.get(c);
            if (info) aliasToTag.set(a, info);
        }

        // 4) Prompt
        const systemPrompt =
            'Sos un asistente que responde preguntas sobre un chat de WhatsApp de un grupo de amigos uruguayos. ' +
            'Te paso una pregunta y fragmentos de la conversación real (en orden cronológico). Respondé en español rioplatense natural, ' +
            'breve y directo, basándote ÚNICAMENTE en esa conversación.\n\n' +
            'CÓMO LEER LA CONVERSACIÓN:\n' +
            '• Cada línea es "[hora] Pn: mensaje". Pn es una persona (P1, P2...). Las líneas "=== Día ... ===" indican el día.\n' +
            '• "(responde a Pn: \\"...\\")" indica que ese mensaje contesta DIRECTAMENTE a ese otro mensaje.\n' +
            '• Los mensajes cortos ("sí", "no", "dale") suelen responder al mensaje anterior.\n' +
            '• Varios mensajes unidos con " / " son una sola idea de la misma persona.\n' +
            '• "— (mensajes salteados) —" significa que entre esos mensajes hubo otros que NO se te muestran (se eligieron los más relevantes). ' +
            'Por eso la conversación puede estar incompleta.\n' +
            '• Es un grupo de amigos: hay bromas, ironía y jerga. No tomes las bromas literal.\n\n' +
            'REGLAS:\n' +
            '• Contestá exactamente lo que se pregunta. Si preguntan "quién dijo X", nombrá a la persona (código Pn), la hora/día y qué dijo; ' +
            'podés citar un fragmento corto (máx. ~15 palabras) si ayuda a probarlo.\n' +
            '• Si preguntan si una persona dijo algo: respondé "Sí", "No lo encontré" o "No estoy seguro", con la evidencia.\n' +
            '• Si preguntan con quién habló una persona: listá con quiénes interactuó (respuestas, menciones, charlas seguidas) y sobre qué.\n' +
            '• Prestá mucha atención a QUIÉN dijo cada cosa. Nunca le atribuyas a alguien lo que dijo otra persona.\n' +
            '• Si la respuesta NO está en la conversación, decilo claramente ("No encontré nada sobre eso en lo que revisé") y NO inventes. ' +
            'Si puede que esté en los mensajes salteados, aclaralo.\n' +
            '• Nombrá personas SOLO con su código exacto (P1, P2...). No inventes nombres ni números.\n' +
            '• Formato WhatsApp: *negrita* con un solo asterisco, sin # ni **, viñetas con "• ".\n' +
            '• Máx. 900 caracteres, sin saludos ni cierres.';

        const userPrompt =
            `Grupo: ${meta?.subject || 'Grupo'}\n` +
            `Período analizado: últimas ${hLabel} h (hora Uruguay). Hoy es ${hoy}.\n` +
            `Participantes: ${leyenda || 'sin datos'}\n` +
            (mencionadasLista ? `Personas a las que apunta la pregunta: ${mencionadasLista}\n` : '') +
            (notaRespuesta ? notaRespuesta + '\n' : '') +
            `\nPREGUNTA: ${preguntaIA}\n\n` +
            `CONVERSACIÓN (${idxs.length} de ${preparados.length} mensajes, los más relevantes para la pregunta):\n${transcript}`;

        if (process.env.PREGUNTA_DEBUG || process.env.RESUMEN_DEBUG) {
            console.log('[PREGUNTA][DEBUG] ----- PROMPT -----\n' + userPrompt + '\n[PREGUNTA][DEBUG] ------------------');
        }

        // 5) IA
        const respuesta = await llamarIA(systemPrompt, userPrompt, 600);
        if (!respuesta) throw new Error('La IA no devolvió texto');

        // 6) P1, P2... → @menciones reales
        const mentions = new Set();
        const addMention = (info) => {
            if (mentions.has(info.jid) || mentions.size < MAX_MENTIONS) {
                mentions.add(info.jid);
                return `@${info.tag}`;
            }
            return 'alguien';
        };

        let cuerpo = formatear(respuesta).replace(/\*(P\d{1,3})\*/g, '$1');
        cuerpo = cuerpo.replace(/@?\b(P\d{1,3})\b/g, (m, a) => {
            const info = aliasToTag.get(a);
            if (!info) return canonDe.has(a) ? 'alguien' : m;
            return addMention(info);
        });
        cuerpo = recortar(cuerpo, MAX_OUTPUT_CHARS);

        // La pregunta mostrada con las menciones resueltas
        const preguntaMostrar = preguntaRaw.replace(/@(\d{5,})/g, (m, d) => {
            const info = resolver.get(d);
            return info ? addMention(info) : 'alguien';
        });

        const L = [];
        L.push('❓ 𝗣𝗥𝗘𝗚𝗨𝗡𝗧𝗔');
        L.push(`_${preguntaMostrar}_`);
        L.push(`🕒 Últimas *${hLabel} h* · 🇺🇾 Hora de Uruguay`);
        L.push('━━━━━━━━━━━━');
        L.push('');
        L.push(cuerpo);
        L.push('');
        L.push(`_🔎 Revisé ${idxs.length} de ${preparados.length} mensajes relevantes_`);

        await sock.sendMessage(chatId, { text: L.join('\n'), mentions: [...mentions] },
            { quoted: message._baileyMessage || message.baileyMessage || message });

    } catch (err) {
        lastRun.delete(chatId);
        console.error('[PREGUNTA] Error:', err.message || err);
        const status = err.response?.status;
        if (status === 429) {
            return message.reply('⏳ Groq está saturado ahora mismo. Intenta en unos segundos.');
        }
        return message.reply('❌ No pude responder la pregunta. Intenta de nuevo en un rato.');
    }
};

handler.help    = ['pregunta <pregunta>', 'pregunta <horas>h <pregunta>'];
handler.tags    = ['ia', 'grupos'];
handler.command = /^pregunta$/i;
handler.group   = true;

module.exports = handler;