/**
 * Comando: infog
 * Descripción: Muestra información detallada del grupo (nombre, participantes, admins, creador, descripción y enlace).
 * Uso: .infog
 */

let handler = async (message, { conn }) => {
    try {
        // --- 1. Verificar si se usa en grupo ---
        if (!message.isGroup) {
            return await message.reply('❌ Este comando solo puede usarse en un grupo.');
        }

        // --- 2. Obtener metadatos del grupo ---
        const groupMetadata = await conn.groupMetadata(message.from);
        const participants = groupMetadata.participants || [];
        const totalParticipants = participants.length;

        // --- 3. Obtener administradores ---
        const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
        const adminsList = admins.map((p, index) =>
            `${index + 1}. @${p.id.split('@')[0]} (${p.admin === 'superadmin' ? 'Super Admin' : 'Admin'})`
        ).join('\n');

        // --- 4. Determinar el creador ---
        const ownerJid = groupMetadata.owner;
        const ownerMention = ownerJid ? `@${ownerJid.split('@')[0]}` : 'Desconocido';

        // --- 5. Formatear la fecha de creación ---
        const creationDate = groupMetadata.creation ?
            new Date(groupMetadata.creation * 1000).toLocaleDateString('es-ES', {
                year: 'numeric', month: 'long', day: 'numeric',
                hour: '2-digit', minute: '2-digit'
            }) : 'Desconocida';

        // --- 6. Obtener el enlace con cualquier bot administrador disponible ---
        // El comando de información no necesita permisos; solo la consulta del
        // invite code requiere admin. Evitamos fallar por estar ejecutándolo un
        // subbot no administrador cuando otro bot conectado sí tiene permisos.
        let inviteLink = 'No hay un bot administrador disponible para mostrar el enlace.';
        try {
            const coordinator = require('../../../lib/subbotCoordinator');
            const adminSock = await coordinator.findAdminBotSocket(message.from, conn, groupMetadata);
            if (adminSock && typeof adminSock.groupInviteCode === 'function') {
                const code = await adminSock.groupInviteCode(message.from);
                if (code) inviteLink = `https://chat.whatsapp.com/${code}`;
                else inviteLink = 'El bot administrador no pudo generar el enlace.';
            }
        } catch (inviteError) {
            inviteLink = 'No se pudo verificar un bot administrador para generar el enlace.';
        }

        // --- 7. Construir mensaje final ---
        const info =
            '📌 *I N F O  D E L  G R U P O*\n\n' +
            `🏷️ *Nombre:* ${groupMetadata.subject || 'No definido'}\n` +
            `👥 *Participantes:* ${totalParticipants}\n` +
            `👑 *Creador:* ${ownerMention}\n` +
            `📅 *Fecha de Creación:* ${creationDate}\n\n` +
            '----------------------------------------\n' +
            `🔗 *Enlace de Invitación:*\n${inviteLink}\n` +
            '----------------------------------------\n\n' +
            `🛃 *Administradores (${admins.length}):*\n${adminsList || 'Ninguno'}\n\n` +
            `📄 *Descripción:*\n${groupMetadata.desc || 'No hay descripción.'}`;

        // --- 9. Crear lista de menciones (creador + admins) ---
        const mentions = [ownerJid, ...admins.map(a => a.id)].filter(Boolean);

        // --- 10. Enviar mensaje ---
        await message.reply(info, { mentions });

    } catch (error) {
        console.error('[ERROR] Error en comando infog:', error);
        await message.reply('❌ Ocurrió un error inesperado al intentar obtener la información del grupo.');
    }
};

// --- Configuración del Handler ---
handler.help = ['infog', 'ginfo'];
handler.tags = ['group'];
handler.command = /^(infog|ginfo|groupinfo)$/i;
handler.group = true;
handler.admin = false;

module.exports = handler;
