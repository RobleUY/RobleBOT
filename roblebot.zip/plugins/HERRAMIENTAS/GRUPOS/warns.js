﻿/**
 * Sistema de advertencias (.warn / .unwarn / .warneados)
 * - Warns por grupo (no globales)
 * - Al 3er warn: expulsa automáticamente o avisa a admins si el bot no puede
 * - Solo admins pueden usar los comandos
 * - El bot debe ser admin para expulsar
 */

const fs = require('fs');
const path = require('path');

const WARNS_FILE = path.join(__dirname, '..', '..', '..', 'data', 'warns.json');

// ─── Helpers de datos ─────────────────────────────────────────────────────────

function getWarnsData() {
    if (!fs.existsSync(WARNS_FILE)) return {};
    try {
        return JSON.parse(fs.readFileSync(WARNS_FILE, 'utf8'));
    } catch (e) {
        console.error('❌ Error leyendo warns.json:', e.message);
        throw e;
    }
}

function saveWarnsData(data) {
    try {
        const dir = path.dirname(WARNS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(WARNS_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('❌ Error guardando warns.json:', e.message);
        throw e;
    }
}

function normalizeNumber(id) {
    if (!id) return '';
    return String(id).split('@')[0].split(':')[0].replace(/\D/g, '');
}

// ─── Helpers de grupo ─────────────────────────────────────────────────────────

async function getGroupInfo(conn, groupId, senderId) {
    const meta = await conn.groupMetadata(groupId);
    const participantNumbers = participant => [
        participant.id,
        participant.phoneNumber,
        participant.lid
    ].map(normalizeNumber).filter(Boolean);
    const botNumbers = new Set(participantNumbers({ id: conn.user.id }));
    const botP = meta.participants.find(participant =>
        participantNumbers(participant).some(number => botNumbers.has(number))
    );
    const senderNum = normalizeNumber(senderId);
    const senderP = meta.participants.find(participant =>
        participantNumbers(participant).includes(senderNum)
    );

    const botIsAdmin    = botP    && (botP.admin    === 'admin' || botP.admin    === 'superadmin');
    const senderIsAdmin = senderP && (senderP.admin === 'admin' || senderP.admin === 'superadmin');

    const admins = meta.participants
        .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
        .map(p => p.id);

    const find = num => meta.participants.find(participant =>
        participantNumbers(participant).includes(normalizeNumber(num))
    );

    return { meta, botP, botIsAdmin, senderIsAdmin, admins, find };
}

function getTargetJid(message) {
    if (message.mentions?.length > 0) return message.mentions[0];
    if (message.quoted?.sender)       return message.quoted.sender;
    return null;
}

async function applyWarn(conn, groupId, targetP, targetNum, reason, senderId, groupInfo, quotedMessage) {
    const data = getWarnsData();
    if (!data[groupId]) data[groupId] = {};
    if (!data[groupId][targetNum]) data[groupId][targetNum] = [];

    data[groupId][targetNum].push({
        reason,
        date: new Date().toISOString(),
        by: normalizeNumber(senderId)
    });

    const warnCount = data[groupId][targetNum].length;
    saveWarnsData(data);
    const mention = `@${targetNum}`;

    if (warnCount >= 3) {
        if (groupInfo.botIsAdmin) {
            try {
                await conn.groupParticipantsUpdate(groupId, [targetP.id], 'remove');
                delete data[groupId][targetNum];
                saveWarnsData(data);

                const messageResult = await conn.sendMessage(groupId, {
                    text: `⚠️ ${mention} fue *expulsado* del grupo por acumular *3 advertencias*.\n\n📋 Última razón: ${reason}`,
                    mentions: [targetP.id]
                }, { quoted: quotedMessage });
                return { warnCount, removed: true, messageResult };
            } catch (kickErr) {
                console.error('❌ Error al expulsar:', kickErr.message);
            }
        }

        const adminMentions = groupInfo.admins;
        const adminTags = adminMentions.map(admin => `@${normalizeNumber(admin)}`).join(' ');
        const messageResult = await conn.sendMessage(groupId, {
            text:
                `🚨 *ALERTA: 3 advertencias acumuladas*\n\n` +
                `👤 Usuario: ${mention}\n` +
                `📋 Última razón: ${reason}\n\n` +
                `⚠️ El bot ${groupInfo.botIsAdmin ? 'no pudo expulsar al usuario' : 'no es administrador y no puede expulsarlo'}.\n\n` +
                `🔔 Admins, por favor tomen acción:\n${adminTags}`,
            mentions: [targetP.id, ...adminMentions]
        }, { quoted: quotedMessage });
        return { warnCount, removed: false, messageResult };
    }

    const warnEmoji = warnCount === 1 ? '1️⃣' : '2️⃣';
    const warnsLeft = 3 - warnCount;
    const messageResult = await conn.sendMessage(groupId, {
        text:
            `⚠️ *Advertencia ${warnEmoji} para* ${mention}\n\n` +
            `📋 *Razón:* ${reason}\n` +
            `📊 *Advertencias:* ${warnCount}/3\n` +
            `💡 Le ${warnsLeft === 1 ? 'queda *1 advertencia*' : 'quedan *2 advertencias*'} antes de ser expulsado.`,
        mentions: [targetP.id]
    }, { quoted: quotedMessage });
    return { warnCount, removed: false, messageResult };
}

async function applyChatmodWarn({ conn, groupId, targetJid, reason, quotedMessage }) {
    const actorId = conn?.user?.id;
    if (!actorId) throw new Error('El bot no tiene una identidad válida para registrar el warn.');

    const groupInfo = await getGroupInfo(conn, groupId, actorId);
    const targetNum = normalizeNumber(targetJid);
    const targetP = groupInfo.find(targetNum);
    if (!targetP) return { applied: false, reason: 'target-not-found' };
    if (normalizeNumber(actorId) === targetNum) return { applied: false, reason: 'bot-target' };
    if (targetP.admin === 'admin' || targetP.admin === 'superadmin') {
        return { applied: false, reason: 'target-is-admin' };
    }

    const warn = await applyWarn(
        conn,
        groupId,
        targetP,
        targetNum,
        reason,
        actorId,
        groupInfo,
        quotedMessage
    );
    return { applied: true, warnCount: warn.warnCount, removed: warn.removed };
}

// ─── COMANDO .warn ────────────────────────────────────────────────────────────

let warnHandler = async (message, { args, conn, usedPrefix }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        // Permisos
        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden usar este comando.');
        }

        // Obtener usuario objetivo
        const targetJid = getTargetJid(message);
        if (!targetJid) {
            return await message.reply(
                `⚠️ Debes mencionar a un usuario o responder a su mensaje.\n\n` +
                `*Uso:* ${usedPrefix}warn @usuario <razón opcional>`
            );
        }

        const targetNum = normalizeNumber(targetJid);
        const targetP   = groupInfo.find(targetNum);

        if (!targetP) {
            return await message.reply('❌ El usuario no se encuentra en el grupo.');
        }

        // No warnear al bot ni a otros admins
        if (normalizeNumber(conn.user.id) === targetNum) {
            return await message.reply('❌ No me puedo advertir a mí mismo. 😅');
        }
        if (targetP.admin === 'admin' || targetP.admin === 'superadmin') {
            return await message.reply('❌ No puedes advertir a un administrador.');
        }

        // Razón (todo lo que viene después de la mención)
        const reason = args.slice(1).join(' ').trim() || 'Sin especificar';

        const warn = await applyWarn(
            conn,
            groupId,
            targetP,
            targetNum,
            reason,
            senderId,
            groupInfo,
            message._baileyMessage
        );
        return warn.messageResult;

    } catch (error) {
        console.error('❌ Error en .warn:', error);
        return await message.reply('❌ Ocurrió un error al aplicar la advertencia.');
    }
};

warnHandler.command  = /^warn$/i;
warnHandler.help     = ['warn @usuario <razón>'];
warnHandler.tags     = ['admin'];
warnHandler.group    = true;

// ─── COMANDO .unwarn ──────────────────────────────────────────────────────────

let unwarnHandler = async (message, { args, conn, usedPrefix }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden usar este comando.');
        }

        const targetJid = getTargetJid(message);
        if (!targetJid) {
            return await message.reply(
                `⚠️ Debes mencionar a un usuario o responder a su mensaje.\n\n` +
                `*Uso:* ${usedPrefix}unwarn @usuario <número de warn: 1 o 2>`
            );
        }

        const targetNum = normalizeNumber(targetJid);
        const data      = getWarnsData();

        if (!data[groupId]?.[targetNum]?.length) {
            return await message.reply(`ℹ️ @${targetNum} no tiene advertencias en este grupo.`);
        }

        const warns     = data[groupId][targetNum];
        const warnCount = warns.length;

        // Si se especifica número de warn (1 o 2), eliminar esa específica
        const warnIndex = parseInt(args[1]);
        if (!isNaN(warnIndex) && warnIndex >= 1 && warnIndex <= warnCount) {
            const removed = warns.splice(warnIndex - 1, 1)[0];
            if (warns.length === 0) delete data[groupId][targetNum];
            saveWarnsData(data);

            return await conn.sendMessage(groupId, {
                text:
                    `✅ Advertencia #${warnIndex} eliminada para @${targetNum}\n\n` +
                    `📋 *Razón eliminada:* ${removed.reason}\n` +
                    `📊 *Advertencias restantes:* ${data[groupId]?.[targetNum]?.length || 0}/3`,
                mentions: [targetJid]
            }, { quoted: message._baileyMessage });
        }

        // Sin número → eliminar la última
        const removed = warns.pop();
        if (warns.length === 0) delete data[groupId][targetNum];
        saveWarnsData(data);

        return await conn.sendMessage(groupId, {
            text:
                `✅ Última advertencia eliminada para @${targetNum}\n\n` +
                `📋 *Razón eliminada:* ${removed.reason}\n` +
                `📊 *Advertencias restantes:* ${data[groupId]?.[targetNum]?.length || 0}/3`,
            mentions: [targetJid]
        }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('❌ Error en .unwarn:', error);
        return await message.reply('❌ Ocurrió un error al eliminar la advertencia.');
    }
};

unwarnHandler.command = /^unwarn$/i;
unwarnHandler.help    = ['unwarn @usuario <número opcional>'];
unwarnHandler.tags    = ['admin'];
unwarnHandler.group   = true;

// ─── COMANDO .warneados ───────────────────────────────────────────────────────

let warneadosHandler = async (message, { conn }) => {
    try {
        const groupId  = message.from;
        const senderId = message.author || message.sender || message.from;

        let groupInfo;
        try {
            groupInfo = await getGroupInfo(conn, groupId, senderId);
        } catch (e) {
            return await message.reply('❌ No puedo acceder a la información del grupo.');
        }

        if (!groupInfo.senderIsAdmin) {
            return await message.reply('❌ Solo los *administradores* pueden ver las advertencias.');
        }

        const data       = getWarnsData();
        const groupWarns = data[groupId] || {};
        const entries    = Object.entries(groupWarns).filter(([, w]) => w.length > 0);

        if (entries.length === 0) {
            return await message.reply('✅ No hay usuarios con advertencias en este grupo.');
        }

        const mentions = [];
        let text = `*⚠️ USUARIOS CON ADVERTENCIAS (${entries.length})*\n\n`;

        for (const [num, warns] of entries) {
            // Buscar el JID real del participante en el grupo para la mención correcta
            const participantP = groupInfo.find(num);
            const jid = participantP ? participantP.id : `${num}@s.whatsapp.net`;
            const displayNum = jid.split('@')[0]; // puede incluir :15 si aplica
            mentions.push(jid);
            text += `👤 @${displayNum} — *${warns.length}/3 warns*\n`;
            warns.forEach((w, i) => {
                const date = new Date(w.date).toLocaleDateString('es-ES');
                text += `   ${i + 1}. ${w.reason} _(${date})_\n`;
            });
            text += '\n';
        }

        return await conn.sendMessage(groupId, { text, mentions }, { quoted: message._baileyMessage });

    } catch (error) {
        console.error('❌ Error en .warneados:', error);
        return await message.reply('❌ Ocurrió un error al obtener las advertencias.');
    }
};

warneadosHandler.command = /^warneados$/i;
warneadosHandler.help    = ['warneados'];
warneadosHandler.tags    = ['admin'];
warneadosHandler.group   = true;

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports              = warnHandler;
module.exports.unwarnHandler    = unwarnHandler;
module.exports.warneadosHandler = warneadosHandler;
module.exports.applyChatmodWarn = applyChatmodWarn;