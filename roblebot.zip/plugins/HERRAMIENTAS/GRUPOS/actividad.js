/**
 * Plugin: actividad
 * Muestra la actividad del grupo (mensajes de hoy, ayer, últimos 7 días,
 * horas pico, zona tranquila y top de miembros) en hora de Uruguay.
 *
 * Uso:
 *   .actividad
 */

// ── Configuración ─────────────────────────────────────────────────────────────
const UY_OFFSET = -3 * 3_600_000;   // Uruguay = UTC-3 (sin horario de verano)
const HOUR = 3_600_000;
const DAY  = 86_400_000;
const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

// ── Utilidades ────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const fmt = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const pad = (n) => String(n).padStart(2, '0');
const hh  = (h) => `${pad(h % 24)}:00`;

function bar(value, max, size = 10) {
    const filled = max > 0 ? Math.max(value > 0 ? 1 : 0, Math.round((value / max) * size)) : 0;
    return '█'.repeat(filled) + '░'.repeat(size - filled);
}

function spark(values) {
    const chars = '▁▂▃▄▅▆▇█';
    const max = Math.max(...values, 0);
    if (max === 0) return '▁'.repeat(values.length);
    return values.map(v => v === 0 ? '▁' : chars[Math.min(7, Math.ceil((v / max) * 8) - 1)]).join('');
}

// ── Lectura de datos (chatHistory.getActivityBuckets) ────────────────────────
function loadMessages(chatHistory, chatId, sinceTs) {
    if (typeof chatHistory.getActivityBuckets !== 'function') return null;
    return chatHistory.getActivityBuckets(chatId, sinceTs).map(r => ({
        ts: r.bucket,
        sender: cleanNum(r.userId),
        count: r.count,
        isBot: false
    }));
}

// ── Handler principal ─────────────────────────────────────────────────────────
let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
    if (!chatHistory?.isReady) {
        return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
    }

    // Metadata del grupo
    let meta = null;
    try { meta = await sock.groupMetadata(chatId); } catch (_) {}
    const groupName = meta?.subject || 'Grupo';
    const totalMembers = meta?.participants?.length || 0;

    // Fechas en hora de Uruguay
    const now = Date.now();
    const nowUY = now + UY_OFFSET;                          // "reloj" de Uruguay en ms
    const todayIdx = Math.floor(nowUY / DAY);
    const msOfDayNow = nowUY - todayIdx * DAY;
    const windowStart = (todayIdx - 6) * DAY - UY_OFFSET;   // 00:00 UY de hace 6 días, en UTC

    const msgs = loadMessages(chatHistory, chatId, windowStart);
    if (!msgs) {
        return message.reply(
            '❌ Falta actualizar *chatHistory.js* (no tiene el registro de actividad por hora).'
        );
    }

    // Ignorar bot y subbots
    const botNum = global.mainBotNumber || '';
    const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
    const data = msgs.filter(m => !m.isBot && m.sender !== botNum && !subNums.includes(m.sender));

    // Agregación
    const days = Array.from({ length: 7 }, () => new Array(24).fill(0));
    const hourTotals = new Array(24).fill(0);
    const todayUsers = {};
    let yesterdaySoFar = 0;
    let firstSlot = 6;
    let firstTs = Infinity;

    for (const m of data) {
        const l = m.ts + UY_OFFSET;
        const di = Math.floor(l / DAY);
        const slot = di - (todayIdx - 6);
        if (slot < 0 || slot > 6) continue;

        const msOfDay = l - di * DAY;
        const h = Math.floor(msOfDay / HOUR);

        const c = m.count || 1;
        days[slot][h] += c;
        hourTotals[h] += c;
        if (slot < firstSlot) firstSlot = slot;
        if (m.ts < firstTs) firstTs = m.ts;

        if (slot === 6 && m.sender) todayUsers[m.sender] = (todayUsers[m.sender] || 0) + c;
        if (slot === 5 && msOfDay <= msOfDayNow) yesterdaySoFar += c;
    }

    const dayTotals = days.map(d => d.reduce((a, b) => a + b, 0));
    const today = dayTotals[6];
    const yesterday = dayTotals[5];
    const week = dayTotals.reduce((a, b) => a + b, 0);
    const daysSpan = 7 - firstSlot; // días con registro (1 a 7)

    if (week === 0) {
        return message.reply('📭 Todavía no hay actividad registrada en este grupo. Escriban algunos mensajes y vuelve a intentar.');
    }

    // Tendencia vs ayer a la misma hora
    let trend = '';
    if (yesterdaySoFar > 0) {
        const pct = Math.round(((today - yesterdaySoFar) / yesterdaySoFar) * 100);
        trend = pct > 0 ? `📈 ▲ *${pct}%* más que ayer a esta hora`
              : pct < 0 ? `📉 ▼ *${Math.abs(pct)}%* menos que ayer a esta hora`
              :           '➖ Igual que ayer a esta hora';
    }

    // Día más activo (de los 7)
    let bestSlot = 0;
    dayTotals.forEach((t, i) => { if (t > dayTotals[bestSlot]) bestSlot = i; });
    const bestDayName = DIAS[new Date((todayIdx - 6 + bestSlot) * DAY).getUTCDay()];

    // Horas pico (top 3)
    const peaks = hourTotals
        .map((v, h) => ({ h, v }))
        .filter(x => x.v > 0)
        .sort((a, b) => b.v - a.v)
        .slice(0, 3);
    const peakMax = peaks[0]?.v || 0;

    // Zona tranquila: ventana de 6 horas con menos mensajes
    let quietStart = 0, quietMin = Infinity;
    for (let s = 0; s < 24; s++) {
        let sum = 0;
        for (let k = 0; k < 6; k++) sum += hourTotals[(s + k) % 24];
        if (sum < quietMin) { quietMin = sum; quietStart = s; }
    }

    // Top miembros de hoy
    const top = Object.entries(todayUsers).sort((a, b) => b[1] - a[1]).slice(0, 3);
    const mentions = top.map(([num]) => `${num}@s.whatsapp.net`);
    const medals = ['🥇', '🥈', '🥉'];

    // Hora actual UY
    const nowH = Math.floor(msOfDayNow / HOUR);
    const nowM = Math.floor((msOfDayNow % HOUR) / 60_000);

    // ── Construcción del mensaje ──
    const L = [];
    L.push('📊 𝗔𝗖𝗧𝗜𝗩𝗜𝗗𝗔𝗗 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
    L.push(`_${groupName}_`);
    L.push(`🕒 ${pad(nowH)}:${pad(nowM)} · 🇺🇾 Uruguay`);
    L.push('━━━━━━━━━━━━');
    L.push('');

    L.push('📅 *𝗛𝗢𝗬*');
    L.push(`💬 *${fmt(today)}* mensajes`);
    if (trend) L.push(trend);
    const activeToday = Object.keys(todayUsers).length;
    if (activeToday > 0) {
        L.push(`👥 *${activeToday}*${totalMembers ? ` de ${totalMembers}` : ''} miembros participaron`);
    }
    L.push(`🗓️ Ayer: *${fmt(yesterday)}* en total`);
    L.push('');

    L.push('📆 *𝗨𝗟𝗧𝗜𝗠𝗢𝗦 𝟳 𝗗𝗜𝗔𝗦*');
    L.push(`💬 *${fmt(week)}* mensajes`);
    L.push(`⚖️ Promedio: *${fmt(week / daysSpan)}* por día`);
    L.push(`🔥 Día récord: *${bestDayName}* (${fmt(dayTotals[bestSlot])})`);
    L.push('');

    L.push('⏰ *𝗛𝗢𝗥𝗔𝗦 𝗣𝗜𝗖𝗢*');
    L.push('```');
    peaks.forEach(p => L.push(`${hh(p.h)} ${bar(p.v, peakMax)} ${fmt(p.v)}`));
    L.push('```');
    L.push(`😴 Más tranquilo: *${hh(quietStart)}* a *${hh(quietStart + 6)}*`);
    L.push('');

    L.push('📈 *𝗛𝗢𝗬 𝗣𝗢𝗥 𝗛𝗢𝗥𝗔*');
    L.push('```');
    L.push(spark(days[6]));
    L.push('0     6     12    18   23');
    L.push('```');

    if (top.length) {
        L.push('');
        L.push('🏆 *𝗧𝗢𝗣 𝗗𝗘 𝗛𝗢𝗬*');
        top.forEach(([num, count], i) => {
            L.push(`${medals[i]} @${num} · *${fmt(count)}*`);
        });
    }

    L.push('');
    const fd = new Date(firstTs + UY_OFFSET);
    L.push(daysSpan < 7
        ? `_Registrando desde el ${pad(fd.getUTCDate())}/${pad(fd.getUTCMonth() + 1)}. Los datos se completan con los días._`
        : '_Solo cuenta mensajes de miembros, sin el bot._');

    await sock.sendMessage(chatId, {
        text: L.join('\n'),
        mentions
    }, { quoted: message.baileyMessage || message._baileyMessage });
};

handler.help    = ['actividad'];
handler.tags    = ['grupos'];
handler.command = /^actividad$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;
