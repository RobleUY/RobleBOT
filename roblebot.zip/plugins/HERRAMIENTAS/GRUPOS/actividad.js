/**
 * Plugin: actividad
 * Muestra la actividad del grupo: hoy, últimos 7 días, horas pico
 * y franjas del día.
 * Por defecto usa hora de Uruguay; con un país se convierte a su hora.
 *
 * Requiere chatHistory.js con getActivityBuckets().
 *
 * Uso:
 *   .actividad            → hora de Uruguay
 *   .actividad peru       → hora de Perú
 *   .actividad mexico     → hora de México
 */

// ── Configuración ─────────────────────────────────────────────────────────────
const HOUR = 3_600_000;
const DAY  = 86_400_000;
const SLOTS = 14;                   // 14 días: semana actual (7) + semana anterior (7)
const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

// Países soportados: claves en minúscula y sin tildes
const PAISES = {
    'uruguay':             { name: 'Uruguay',        flag: '🇺🇾', tz: 'America/Montevideo' },
    'argentina':           { name: 'Argentina',      flag: '🇦🇷', tz: 'America/Argentina/Buenos_Aires' },
    'chile':               { name: 'Chile',          flag: '🇨🇱', tz: 'America/Santiago' },
    'paraguay':            { name: 'Paraguay',       flag: '🇵🇾', tz: 'America/Asuncion' },
    'bolivia':             { name: 'Bolivia',        flag: '🇧🇴', tz: 'America/La_Paz' },
    'peru':                { name: 'Perú',           flag: '🇵🇪', tz: 'America/Lima' },
    'ecuador':             { name: 'Ecuador',        flag: '🇪🇨', tz: 'America/Guayaquil' },
    'colombia':            { name: 'Colombia',       flag: '🇨🇴', tz: 'America/Bogota' },
    'venezuela':           { name: 'Venezuela',      flag: '🇻🇪', tz: 'America/Caracas' },
    'brasil':              { name: 'Brasil',         flag: '🇧🇷', tz: 'America/Sao_Paulo' },
    'mexico':              { name: 'México',         flag: '🇲🇽', tz: 'America/Mexico_City' },
    'panama':              { name: 'Panamá',         flag: '🇵🇦', tz: 'America/Panama' },
    'costa rica':          { name: 'Costa Rica',     flag: '🇨🇷', tz: 'America/Costa_Rica' },
    'guatemala':           { name: 'Guatemala',      flag: '🇬🇹', tz: 'America/Guatemala' },
    'el salvador':         { name: 'El Salvador',    flag: '🇸🇻', tz: 'America/El_Salvador' },
    'honduras':            { name: 'Honduras',       flag: '🇭🇳', tz: 'America/Tegucigalpa' },
    'nicaragua':           { name: 'Nicaragua',      flag: '🇳🇮', tz: 'America/Managua' },
    'cuba':                { name: 'Cuba',           flag: '🇨🇺', tz: 'America/Havana' },
    'republica dominicana':{ name: 'Rep. Dominicana',flag: '🇩🇴', tz: 'America/Santo_Domingo' },
    'puerto rico':         { name: 'Puerto Rico',    flag: '🇵🇷', tz: 'America/Puerto_Rico' },
    'espana':              { name: 'España',         flag: '🇪🇸', tz: 'Europe/Madrid' },
    'portugal':            { name: 'Portugal',       flag: '🇵🇹', tz: 'Europe/Lisbon' },
    'francia':             { name: 'Francia',        flag: '🇫🇷', tz: 'Europe/Paris' },
    'italia':              { name: 'Italia',         flag: '🇮🇹', tz: 'Europe/Rome' },
    'alemania':            { name: 'Alemania',       flag: '🇩🇪', tz: 'Europe/Berlin' },
    'reino unido':         { name: 'Reino Unido',    flag: '🇬🇧', tz: 'Europe/London' },
    'estados unidos':      { name: 'Estados Unidos', flag: '🇺🇸', tz: 'America/New_York' }
};
// Alias comunes
const ALIAS = {
    'uy': 'uruguay', 'ar': 'argentina', 'cl': 'chile', 'py': 'paraguay', 'bo': 'bolivia',
    'pe': 'peru', 'ec': 'ecuador', 'co': 'colombia', 've': 'venezuela', 'br': 'brasil',
    'brazil': 'brasil', 'mx': 'mexico', 'pa': 'panama', 'cr': 'costa rica', 'gt': 'guatemala',
    'sv': 'el salvador', 'hn': 'honduras', 'ni': 'nicaragua', 'rd': 'republica dominicana',
    'dominicana': 'republica dominicana', 'pr': 'puerto rico', 'es': 'espana', 'usa': 'estados unidos',
    'eeuu': 'estados unidos', 'ee uu': 'estados unidos', 'us': 'estados unidos', 'uk': 'reino unido',
    'inglaterra': 'reino unido', 'fr': 'francia', 'it': 'italia', 'de': 'alemania', 'pt': 'portugal'
};

// ── Utilidades ────────────────────────────────────────────────────────────────
const cleanNum = (jid = '') => String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
const fmt = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const pad = (n) => String(n).padStart(2, '0');
const hh  = (h) => `${pad(h % 24)}:00`;
const sum = (arr) => arr.reduce((a, b) => a + b, 0);

function bar(value, max, size = 10) {
    const filled = max > 0 ? Math.max(value > 0 ? 1 : 0, Math.round((value / max) * size)) : 0;
    return '█'.repeat(filled) + '░'.repeat(size - filled);
}

function trendLine(now, before, label) {
    if (!before || before <= 0) return '';
    const pct = Math.round(((now - before) / before) * 100);
    if (pct > 0) return `📈 ▲ *${pct}%* más ${label}`;
    if (pct < 0) return `📉 ▼ *${Math.abs(pct)}%* menos ${label}`;
    return `➖ Igual ${label}`;
}

// Normaliza el texto del país: minúsculas, sin tildes ni signos
function normalizeCountry(str = '') {
    const s = str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();
    return ALIAS[s] || s;
}

// Diferencia (ms) entre la hora local de una zona y UTC en el instante ts
function tzOffset(timeZone, ts) {
    const parts = new Intl.DateTimeFormat('en-US', {
        timeZone, hourCycle: 'h23',
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    }).formatToParts(new Date(ts));
    const g = (t) => Number(parts.find(p => p.type === t).value);
    const asUTC = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'), g('second'));
    return Math.round((asUTC - Math.floor(ts / 1000) * 1000) / 60_000) * 60_000;
}

// ── Lectura de datos (chatHistory.getActivityBuckets) ────────────────────────
function loadMessages(chatHistory, chatId, sinceTs) {
    if (typeof chatHistory.getActivityBuckets !== 'function') return null;
    return chatHistory.getActivityBuckets(chatId, sinceTs).map(r => ({
        ts: r.bucket,
        sender: cleanNum(r.userId),
        count: r.count
    }));
}

// ── Handler principal ─────────────────────────────────────────────────────────
let handler = async (message, { conn, args, text }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    // País (opcional)
    let rawCountry = Array.isArray(args) && args.length ? args.join(' ') : '';
    if (!rawCountry) {
        const body = (message.body || text || '').trim();
        rawCountry = body.split(/\s+/).slice(1).join(' ');
    }
    const countryKey = rawCountry ? normalizeCountry(rawCountry) : 'uruguay';
    const country = PAISES[countryKey];

    if (!country) {
        const lista = Object.values(PAISES).map(p => `${p.flag} ${p.name}`).join('\n');
        return message.reply(
            `❌ No reconozco el país *${rawCountry.trim()}*.\n\n` +
            '📌 Uso: *.actividad <país>*\n' +
            'Ejemplos:\n• .actividad peru\n• .actividad mexico\n• .actividad españa\n\n' +
            `🌎 *Países disponibles*\n${lista}`
        );
    }

    const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
    if (!chatHistory?.isReady) {
        return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
    }

    // Metadata del grupo
    let meta = null;
    try { meta = await sock.groupMetadata(chatId); } catch (_) {}
    const groupName = (meta?.subject || 'Grupo').replace(/[*_~`]/g, '');
    const totalMembers = meta?.participants?.length || 0;

    // Fechas en la zona elegida (los datos se guardan en hora absoluta y se convierten)
    const now = Date.now();
    const OFF = tzOffset(country.tz, now);
    const UY_OFF = tzOffset('America/Montevideo', now);
    const diffH = (OFF - UY_OFF) / HOUR;

    const nowLocal = now + OFF;
    const todayIdx = Math.floor(nowLocal / DAY);
    const msOfDayNow = nowLocal - todayIdx * DAY;
    const windowStart = (todayIdx - (SLOTS - 1)) * DAY - OFF;
    const T = SLOTS - 1;                                    // slot de hoy (13)

    const msgs = loadMessages(chatHistory, chatId, windowStart);
    if (!msgs) {
        return message.reply('❌ Falta actualizar *chatHistory.js* (no tiene el registro de actividad por hora).');
    }

    // Ignorar bot y subbots (por seguridad; chatHistory ya no los guarda)
    const botNum = global.mainBotNumber || '';
    const subNums = (global.subConns || []).filter(c => c?.user).map(c => cleanNum(c.user.id));
    const data = msgs.filter(m => m.sender !== botNum && !subNums.includes(m.sender));

    // Agregación
    const days = Array.from({ length: SLOTS }, () => new Array(24).fill(0));
    const hourTotals = new Array(24).fill(0);   // solo semana actual
    const todayUsers = {};
    let yesterdaySoFar = 0;
    let firstSlotAll = T;
    let firstSlotWeek = T;
    let firstTsWeek = Infinity;

    for (const m of data) {
        const l = m.ts + OFF;
        const di = Math.floor(l / DAY);
        const slot = di - (todayIdx - T);
        if (slot < 0 || slot > T) continue;

        const msOfDay = l - di * DAY;
        const h = Math.floor(msOfDay / HOUR);
        const c = m.count || 1;

        days[slot][h] += c;
        if (slot < firstSlotAll) firstSlotAll = slot;

        if (slot >= T - 6) {
            hourTotals[h] += c;
            if (slot < firstSlotWeek) firstSlotWeek = slot;
            if (m.ts < firstTsWeek) firstTsWeek = m.ts;
        }
        if (slot === T && m.sender) todayUsers[m.sender] = (todayUsers[m.sender] || 0) + c;
        if (slot === T - 1 && msOfDay <= msOfDayNow) yesterdaySoFar += c;
    }

    const dayTotals = days.map(sum);
    const weekDays = dayTotals.slice(T - 6);                // 7 días, el último es hoy
    const today = dayTotals[T];
    const yesterday = dayTotals[T - 1];
    const week = sum(weekDays);
    const prevWeek = sum(dayTotals.slice(0, 7));
    const daysSpan = Math.max(1, 7 - (firstSlotWeek - (T - 6)));  // días con registro (1 a 7)

    if (week === 0) {
        return message.reply('📭 Todavía no hay actividad registrada en este grupo. Escriban algunos mensajes y vuelve a intentar.');
    }

    // Comparaciones
    const trendToday = trendLine(today, yesterdaySoFar, 'que ayer a esta hora');
    const prevComplete = firstSlotAll === 0 && daysSpan === 7;
    const trendWeek = prevComplete ? trendLine(week, prevWeek, 'que la semana anterior') : '';

    // Día récord
    const dayName = (slot) => new Date((todayIdx - (T - slot)) * DAY).getUTCDay();
    let bestIdx = 0;
    weekDays.forEach((t, i) => { if (t > weekDays[bestIdx]) bestIdx = i; });
    const bestDayName = DIAS[dayName(T - 6 + bestIdx)];

    // Horas pico (top 3 de la semana)
    const peaks = hourTotals
        .map((v, h) => ({ h, v }))
        .filter(x => x.v > 0)
        .sort((a, b) => b.v - a.v)
        .slice(0, 3);
    const peakMax = peaks[0]?.v || 0;

    // Zona tranquila: ventana de 6 horas con menos mensajes
    let quietStart = 0, quietMin = Infinity;
    for (let s = 0; s < 24; s++) {
        let acc = 0;
        for (let k = 0; k < 6; k++) acc += hourTotals[(s + k) % 24];
        if (acc < quietMin) { quietMin = acc; quietStart = s; }
    }

    // Franjas del día (semana)
    const weekHours = sum(hourTotals);
    const franjas = [
        { icon: '🌙', name: 'Madrugada', from: 0,  to: 6  },
        { icon: '🌅', name: 'Mañana',    from: 6,  to: 12 },
        { icon: '☀️', name: 'Tarde',     from: 12, to: 19 },
        { icon: '🌆', name: 'Noche',     from: 19, to: 24 }
    ].map(f => {
        let v = 0;
        for (let h = f.from; h < f.to; h++) v += hourTotals[h];
        return { ...f, v, pct: weekHours ? Math.round((v / weekHours) * 100) : 0 };
    });

    // Hoy: hora más activa y participación
    let todayPeakH = -1, todayPeakV = 0;
    days[T].forEach((v, h) => { if (v > todayPeakV) { todayPeakV = v; todayPeakH = h; } });
    const activeToday = Object.keys(todayUsers).length;
    const partPct = totalMembers ? Math.round((activeToday / totalMembers) * 100) : 0;

    // Hora actual en la zona elegida
    const nowH = Math.floor(msOfDayNow / HOUR);
    const nowM = Math.floor((msOfDayNow % HOUR) / 60_000);
    const diffTxt = diffH === 0 ? '' : ` (${diffH > 0 ? '+' : '−'}${Math.abs(diffH)} h vs Uruguay)`;

    // ── Construcción del mensaje ──
    const L = [];
    L.push('📊 𝗔𝗖𝗧𝗜𝗩𝗜𝗗𝗔𝗗 𝗗𝗘𝗟 𝗚𝗥𝗨𝗣𝗢');
    L.push(`_${groupName}_`);
    L.push(`🕒 ${pad(nowH)}:${pad(nowM)} · ${country.flag} Hora de ${country.name}${diffTxt}`);
    L.push('━━━━━━━━━━━━');
    L.push('');

    L.push('📅 *𝗛𝗢𝗬*');
    L.push(`💬 *${fmt(today)}* mensajes`);
    if (trendToday) L.push(trendToday);
    if (activeToday > 0) {
        L.push(`👥 *${activeToday}*${totalMembers ? ` de ${totalMembers}` : ''} miembros hablaron${totalMembers ? ` (*${partPct}%*)` : ''}`);
    }
    if (todayPeakH >= 0) L.push(`⚡ Hora más activa: *${hh(todayPeakH)}* (${fmt(todayPeakV)})`);
    L.push(`🗓️ Ayer: *${fmt(yesterday)}* en total`);
    L.push('');

    L.push('📆 *𝗨𝗟𝗧𝗜𝗠𝗢𝗦 𝟳 𝗗𝗜𝗔𝗦*');
    L.push(`💬 *${fmt(week)}* mensajes`);
    L.push(`⚖️ Promedio: *${fmt(week / daysSpan)}* por día`);
    if (trendWeek) L.push(trendWeek);
    L.push(`🔥 Día récord: *${bestDayName}* (${fmt(weekDays[bestIdx])})`);
    L.push('');

    L.push('⏰ *𝗛𝗢𝗥𝗔𝗦 𝗣𝗜𝗖𝗢*');
    L.push('```');
    peaks.forEach(p => L.push(`${hh(p.h)} ${bar(p.v, peakMax)} ${fmt(p.v)}`));
    L.push('```');
    L.push(`😴 Más tranquilo: *${hh(quietStart)}* a *${hh(quietStart + 6)}*`);
    L.push('');

    L.push('🌗 *𝗙𝗥𝗔𝗡𝗝𝗔𝗦 𝗗𝗘𝗟 𝗗𝗜𝗔*');
    franjas.forEach(f => L.push(`${f.icon} ${f.name} · ${bar(f.pct, 100, 6)} *${f.pct}%*`));
    L.push('');
    if (daysSpan < 7) {
        const fd = new Date(firstTsWeek + OFF);
        L.push(`_Registrando desde el ${pad(fd.getUTCDate())}/${pad(fd.getUTCMonth() + 1)}. Los datos se completan con los días._`);
    } else {
        L.push('_Solo cuenta mensajes de miembros, sin el bot._');
    }
    if (!rawCountry) L.push('_💡 Cambia la hora con_ *.actividad peru*');

    await sock.sendMessage(chatId, {
        text: L.join('\n')
    }, { quoted: message.baileyMessage || message._baileyMessage });
};

handler.help    = ['actividad', 'actividad <país>'];
handler.tags    = ['grupos'];
handler.command = /^actividad$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;
