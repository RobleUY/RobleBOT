/**
 * Plugin: reportar
 * Uso: responder a un mensaje con .reportar
 *
 * - Menciona a quien reporta y al reportado, citando el mensaje reportado.
 * - Guarda el contenido (texto o archivo) en disco al momento del reporte.
 * - Si el AUTOR reportado borra su mensaje (sea admin o no), el bot reenvía
 *   el contenido avisando que estaba reportado. Funciona aunque .borrados esté off.
 * - Si otro admin borra el mensaje, el bot NO actúa.
 * - Si el reportado (admin) borra el mensaje de reporte del bot (o el contenido
 *   reenviado), el bot lo vuelve a enviar. Otro admin sí puede borrarlo.
 */

const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ── Almacenamiento ────────────────────────────────────────────────────────────

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'reportes.json');
const MEDIA_DIR = path.join(DATA_DIR, 'reportes_media');
const RETENTION_MS = 7 * 24 * 60 * 60 * 1000; // los reportes se guardan 7 días

for (const dir of [DATA_DIR, MEDIA_DIR]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function loadDb() {
    try {
        if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
        console.error('[reportar] Error cargando reportes.json:', e.message);
    }
    return {};
}

let db = loadDb();

function saveDb() {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
    } catch (e) {
        console.error('[reportar] Error guardando reportes.json:', e.message);
    }
}

function purgeOld() {
    const now = Date.now();
    let changed = false;
    for (const [key, rec] of Object.entries(db)) {
        if (now - (rec.createdAt || 0) > RETENTION_MS) {
            if (rec.mediaFile) {
                try { fs.unlinkSync(path.join(MEDIA_DIR, rec.mediaFile)); } catch {}
            }
            delete db[key];
            changed = true;
        }
    }
    if (changed) saveDb();
}
purgeOld();

const recordKey = (chatId, msgId) => `${chatId}|${msgId}`;

// ── Utilidades ────────────────────────────────────────────────────────────────

const norm = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');

// Devuelve todos los identificadores (número / lid) conocidos de un participante
function idsOf(jid, participants = []) {
    const base = norm(jid);
    const set = new Set(base ? [base] : []);
    for (const p of participants) {
        const pIds = [p.id, p.lid, p.phoneNumber, p.jid].filter(Boolean).map(norm);
        if (pIds.includes(base)) pIds.forEach(x => set.add(x));
    }
    return set;
}

const intersects = (a, b) => [...a].some(x => b.has(x));

async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

// Quita envoltorios (efímeros, view-once, etc.)
function unwrap(msg) {
    let m = msg;
    for (let i = 0; i < 6 && m; i++) {
        const inner =
            m.ephemeralMessage?.message ||
            m.viewOnceMessage?.message ||
            m.viewOnceMessageV2?.message ||
            m.viewOnceMessageV2Extension?.message ||
            m.documentWithCaptionMessage?.message ||
            m.editedMessage?.message;
        if (!inner) break;
        m = inner;
    }
    return m || {};
}

function getContextInfo(baileyMsg) {
    const inner = unwrap(baileyMsg?.message);
    for (const v of Object.values(inner)) {
        if (v && typeof v === 'object' && v.contextInfo?.quotedMessage) return v.contextInfo;
    }
    return null;
}

// Extrae qué contiene el mensaje reportado
function extractContent(raw) {
    const m = unwrap(raw);

    if (m.conversation) return { type: 'text', text: m.conversation };
    if (m.extendedTextMessage) {
        return {
            type: 'text',
            text: m.extendedTextMessage.text || '',
            mentions: m.extendedTextMessage.contextInfo?.mentionedJid || []
        };
    }

    const mediaMap = [
        ['imageMessage', 'image'],
        ['videoMessage', 'video'],
        ['audioMessage', 'audio'],
        ['stickerMessage', 'sticker'],
        ['documentMessage', 'document']
    ];
    for (const [key, type] of mediaMap) {
        if (m[key]) {
            const node = m[key];
            return {
                type,
                media: node,
                caption: node.caption || '',
                mime: node.mimetype || '',
                fileName: node.fileName || 'archivo',
                ptt: !!node.ptt,
                gif: !!node.gifPlayback
            };
        }
    }

    if (m.contactMessage) {
        return {
            type: 'contact',
            displayName: m.contactMessage.displayName || 'Contacto',
            vcard: m.contactMessage.vcard || ''
        };
    }
    if (m.locationMessage) {
        return {
            type: 'location',
            lat: m.locationMessage.degreesLatitude,
            lng: m.locationMessage.degreesLongitude,
            name: m.locationMessage.name || ''
        };
    }
    return null;
}

// ── Envío de contenido ────────────────────────────────────────────────────────

async function sendContent(sock, rec, quoted) {
    const opts = quoted ? { quoted } : {};
    const chatId = rec.chatId;
    const buf = rec.mediaFile && fs.existsSync(path.join(MEDIA_DIR, rec.mediaFile))
        ? fs.readFileSync(path.join(MEDIA_DIR, rec.mediaFile))
        : null;

    switch (rec.type) {
        case 'text':
            return sock.sendMessage(chatId, {
                text: `📝 *Mensaje original:*\n\n${rec.text}`,
                mentions: rec.mentions || []
            }, opts);

        case 'image':
            if (buf) return sock.sendMessage(chatId, { image: buf, caption: rec.caption || '' }, opts);
            break;
        case 'video':
            if (buf) return sock.sendMessage(chatId, { video: buf, caption: rec.caption || '', gifPlayback: !!rec.gif }, opts);
            break;
        case 'audio':
            if (buf) return sock.sendMessage(chatId, {
                audio: buf,
                mimetype: rec.mime || 'audio/ogg; codecs=opus',
                ptt: !!rec.ptt
            }, opts);
            break;
        case 'sticker':
            if (buf) return sock.sendMessage(chatId, { sticker: buf }, opts);
            break;
        case 'document':
            if (buf) return sock.sendMessage(chatId, {
                document: buf,
                mimetype: rec.mime || 'application/octet-stream',
                fileName: rec.fileName || 'archivo',
                caption: rec.caption || ''
            }, opts);
            break;
        case 'contact':
            return sock.sendMessage(chatId, {
                contacts: { displayName: rec.displayName, contacts: [{ vcard: rec.vcard }] }
            }, opts);
        case 'location':
            return sock.sendMessage(chatId, {
                location: { degreesLatitude: rec.lat, degreesLongitude: rec.lng, name: rec.name }
            }, opts);
    }

    return sock.sendMessage(chatId, {
        text: '⚠️ No se pudo recuperar el contenido de ese mensaje (tipo no soportado o archivo no disponible).'
    }, opts);
}

// Envía aviso + contenido y guarda los IDs de los mensajes del bot
async function sendEvidence(sock, rec, intro) {
    const sent = [];
    const mentions = [rec.reportedJid, rec.reporterJid].filter(Boolean);

    const introMsg = await sock.sendMessage(rec.chatId, { text: intro, mentions });
    if (introMsg?.key?.id) sent.push(introMsg.key.id);

    const contentMsg = await sendContent(sock, rec, introMsg);
    if (contentMsg?.key?.id) sent.push(contentMsg.key.id);

    return sent;
}

function reportNoticeText(rec) {
    return (
        `🚨 *MENSAJE REPORTADO* 🚨\n\n` +
        `👤 @${norm(rec.reporterJid)} reportó el mensaje de @${norm(rec.reportedJid)}.\n\n` +
        `⚠️ Este mensaje quedó registrado. Si es eliminado, se reenviará automáticamente su contenido.`
    );
}

// ── Detección de borrados ─────────────────────────────────────────────────────

const processedRevokes = new Set();

async function onUpsert(sock, { messages }) {
    for (const m of messages || []) {
        try {
            const proto = m.message?.protocolMessage;
            if (!proto || !(proto.type === 0 || proto.type === 'REVOKE')) continue;

            const chatId = m.key?.remoteJid;
            if (!chatId || !chatId.endsWith('@g.us') || m.key.fromMe) continue;

            const deletedId = proto.key?.id;
            const deleter = m.key.participant || m.participant;
            if (!deletedId || !deleter) continue;

            const dedupe = `${chatId}|${deletedId}`;
            if (processedRevokes.has(dedupe)) continue;

            // Buscar si es un mensaje reportado o un mensaje del bot ligado a un reporte
            const rec = Object.values(db).find(r =>
                r.chatId === chatId && (r.id === deletedId || (r.botMsgIds || []).includes(deletedId))
            );
            if (!rec) continue;

            // ¿Quien borró es el usuario reportado?
            let participants = [];
            try { participants = (await sock.groupMetadata(chatId)).participants || []; } catch {}
            const reportedIds = idsOf(rec.reportedJid, participants);
            const deleterIds = idsOf(deleter, participants);
            if (!intersects(reportedIds, deleterIds)) continue; // otro admin/usuario: no se actúa

            processedRevokes.add(dedupe);
            setTimeout(() => processedRevokes.delete(dedupe), 60 * 1000);

            if (rec.id === deletedId && !rec.deleted) {
                // El reportado borró su propio mensaje reportado → reenviar
                rec.deleted = true;
                saveDb();
                const intro =
                    `🗑️ @${norm(rec.reportedJid)} eliminó un mensaje que había sido *reportado* por @${norm(rec.reporterJid)}.\n\n` +
                    `Por eso se reenvía su contenido 👇`;
                const ids = await sendEvidence(sock, rec, intro);
                rec.botMsgIds = [...(rec.botMsgIds || []), ...ids];
                saveDb();

            } else if ((rec.botMsgIds || []).includes(deletedId)) {
                // El reportado (admin) borró un mensaje del bot del reporte → reenviar
                rec.botMsgIds = rec.botMsgIds.filter(id => id !== deletedId);
                let ids;
                if (rec.deleted) {
                    const intro =
                        `🚫 @${norm(rec.reportedJid)} intentó borrar el mensaje del bot sobre el reporte de @${norm(rec.reporterJid)}.\n\n` +
                        `El mensaje reportado era 👇`;
                    ids = await sendEvidence(sock, rec, intro);
                } else {
                    const notice = await sock.sendMessage(rec.chatId, {
                        text: reportNoticeText(rec),
                        mentions: [rec.reportedJid, rec.reporterJid].filter(Boolean)
                    });
                    ids = notice?.key?.id ? [notice.key.id] : [];
                }
                rec.botMsgIds = [...rec.botMsgIds, ...ids];
                saveDb();
            }
        } catch (e) {
            console.error('[reportar] Error procesando borrado:', e.message);
        }
    }
}

// ── Registro del listener en el socket ────────────────────────────────────────

const INSTANCE = `${Date.now()}-${Math.random()}`;

function attach(sock) {
    if (!sock?.ev || sock.__reportarInstance === INSTANCE) return;
    if (typeof sock.__reportarOff === 'function') {
        try { sock.__reportarOff(); } catch {}
    }
    const listener = (data) => onUpsert(sock, data);
    sock.ev.on('messages.upsert', listener);
    sock.__reportarInstance = INSTANCE;
    sock.__reportarOff = () => sock.ev.off('messages.upsert', listener);
}

// Engancha el socket principal al cargar y vuelve a engancharlo si se reconecta
if (global.__reportarTimer) clearInterval(global.__reportarTimer);
attach(global.conn);
global.__reportarTimer = setInterval(() => {
    attach(global.conn);
    purgeOld();
}, 15 * 1000);
if (global.__reportarTimer.unref) global.__reportarTimer.unref();

// ── Handler principal ─────────────────────────────────────────────────────────

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    attach(sock); // cubre también subbots

    const baileyMsg = message._baileysMessage
        || message._baileyMessage
        || message.baileysMessage
        || message.baileyMessage
        || message.rawMessage
        || global.lastBaileyMessage;
    if (!baileyMsg) return message.reply('❌ No se encontró el mensaje.');

    const chatId = message.from;
    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    const ctx = getContextInfo(baileyMsg);
    if (!ctx?.quotedMessage || !ctx.stanzaId) {
        return message.reply('❌ Respondé al mensaje que querés reportar con *.reportar*');
    }

    const reporterJid = message.sender || message.author || baileyMsg.key?.participant;
    const reportedJid = ctx.participant;
    if (!reporterJid || !reportedJid) {
        return message.reply('❌ No pude identificar al autor del mensaje o a quien reporta.');
    }

    // No se pueden reportar mensajes del propio bot
    const botIds = new Set([norm(sock.user?.id), norm(sock.user?.lid)].filter(Boolean));
    if (botIds.has(norm(reportedJid))) {
        return message.reply('🤖 No puedo reportar mis propios mensajes.');
    }

    const key = recordKey(chatId, ctx.stanzaId);
    if (db[key]) {
        return message.reply('⚠️ Ese mensaje ya fue reportado.');
    }

    // Guardar el contenido ahora (después de borrado ya no se puede descargar)
    const content = extractContent(ctx.quotedMessage);
    const rec = {
        id: ctx.stanzaId,
        chatId,
        reportedJid,
        reporterJid,
        createdAt: Date.now(),
        deleted: false,
        botMsgIds: [],
        type: content?.type || 'unknown',
        mentions: content?.mentions || []
    };

    if (content) {
        for (const f of ['text', 'caption', 'mime', 'fileName', 'ptt', 'gif', 'displayName', 'vcard', 'lat', 'lng', 'name']) {
            if (content[f] !== undefined) rec[f] = content[f];
        }
        if (content.media) {
            try {
                const stream = await downloadContentFromMessage(content.media, content.type);
                const buffer = await streamToBuffer(stream);
                const fileName = `${Date.now()}_${ctx.stanzaId.replace(/[^a-zA-Z0-9]/g, '')}.bin`;
                fs.writeFileSync(path.join(MEDIA_DIR, fileName), buffer);
                rec.mediaFile = fileName;
            } catch (e) {
                console.error('[reportar] Error descargando media:', e.message);
            }
        }
    }

    // Enviar el aviso citando el mensaje reportado
    try {
        const quoted = {
            key: { remoteJid: chatId, fromMe: false, id: ctx.stanzaId, participant: reportedJid },
            message: ctx.quotedMessage
        };
        const notice = await sock.sendMessage(chatId, {
            text: reportNoticeText(rec),
            mentions: [reportedJid, reporterJid]
        }, { quoted });

        if (notice?.key?.id) rec.botMsgIds.push(notice.key.id);
        db[key] = rec;
        saveDb();
    } catch (e) {
        console.error('[reportar] Error enviando reporte:', e.message);
        await message.reply('❌ No pude enviar el reporte.');
    }
};

handler.help = ['reportar'];
handler.tags = ['group'];
handler.command = /^reportar$/i;
handler.group = true;

module.exports = handler;
// Por si querés que borrados.js ignore los mensajes reportados y no se duplique el reenvío
module.exports.isReported = (chatId, msgId) => !!db[recordKey(chatId, msgId)];