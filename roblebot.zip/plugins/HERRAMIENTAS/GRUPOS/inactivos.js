/**
 * Plugin: inactivos / topinactivos
 * Muestra los miembros del grupo que no han enviado mensajes
 * en el período de tiempo indicado.
 *
 * Uso:
 *   .inactivos 1d      → sin mensaje en las últimas 24 horas
 *   .inactivos 12h     → sin mensaje en las últimas 12 horas
 *   .inactivos 30m     → sin mensaje en los últimos 30 minutos
 *   .topinactivos 7d   → alias del mismo comando
 */

// ── Parsear tiempo ────────────────────────────────────────────────────────────
function parseTime(str) {
    if (!str) return null;
    const match = str.trim().match(/^(\d+(?:\.\d+)?)\s*(m|h|d|s)$/i);
    if (!match) return null;

    const value = parseFloat(match[1]);
    const unit  = match[2].toLowerCase();

    const multipliers = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
    return value * multipliers[unit];
}

// ── Formatear duración legible ────────────────────────────────────────────────
function formatDuration(ms) {
    const d = Math.floor(ms / 86_400_000);
    const h = Math.floor((ms % 86_400_000) / 3_600_000);
    const m = Math.floor((ms % 3_600_000) / 60_000);

    const parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    return parts.length ? parts.join(' ') : 'menos de 1m';
}

// ── Handler principal ─────────────────────────────────────────────────────────
let handler = async (message, { text, args, conn }) => {
    const sock = conn || message._sock || global.conn;
    const chatId = message.from;

    // Solo en grupos
    if (!chatId || !chatId.endsWith('@g.us')) {
        return message.reply('⚠️ Este comando solo funciona en grupos.');
    }

    // Verificar que quien lo usa es admin o owner
    const senderJid = message.author || message.sender;
    const senderNum = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '');

    let isAdmin = false;
    try {
        const meta = await conn.groupMetadata(chatId);
        const participant = meta.participants.find(p => {
            const n = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
            return n === senderNum;
        });
        isAdmin = participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch (_) {}

    const isOwner = (global.botConfig?.isOwner?.(senderNum) || global.botConfig?.isOwner?.(`${senderNum}@s.whatsapp.net`));

    if (!isAdmin && !isOwner) {
        return message.reply('⚠️ Solo los administradores pueden usar este comando.');
    }

    const body = (message.body || text || '').trim();
    const commandName = (body.charAt(0) === '.' || body.charAt(0) === '/' ? body.slice(1) : body)
        .trim().split(/\s+/)[0].toLowerCase();
    const isGhosts = commandName === 'fantasmas';

    let thresholdMs = null;
    if (!isGhosts) {
        const timeArg = args[0] || body.split(/\s+/)[1] || text?.trim().split(' ')[0];
        thresholdMs = parseTime(timeArg);

        if (!thresholdMs) {
            return message.reply(
                '❌ Formato incorrecto.\n\n' +
                '📌 Uso: *.inactivos <tiempo>*\n\n' +
                'Ejemplos:\n' +
                '• .inactivos 1d  → inactivos en 24h\n' +
                '• .inactivos 12h → inactivos en 12h\n' +
                '• .inactivos 30m → inactivos en 30min\n' +
                '• .inactivos 7d  → inactivos en 7 días'
            );
        }
    }

    const now = Date.now();
    const cutoff = isGhosts ? 0 : now - thresholdMs;

    // Obtener miembros del grupo
    let participants = [];
    try {
        const meta = await conn.groupMetadata(chatId);
        participants = meta.participants || [];
    } catch (err) {
        return message.reply('❌ No pude obtener la lista de miembros del grupo.');
    }

    // Obtener actividad registrada para este grupo
    // Usar chatHistory como fuente principal (misma DB que topactivos)
    const chatHistory = (() => { try { return require('../../../chatHistory'); } catch { return null; } })();
    if (!chatHistory?.isReady) {
        return message.reply('❌ El historial de chat no está disponible aún. Intenta nuevamente más tarde.');
    }

    // Filtrar inactivos: miembros cuyo último mensaje fue antes del cutoff
    // Fantasmas: miembros que nunca han enviado un mensaje y no tienen registro
    const inactivos = [];
    const fantasmas = [];

    for (const p of participants) {
        const num = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');

        // Ignorar al propio bot
        const botNum = global.mainBotNumber || '';
        if (num === botNum) continue;

        // Ignorar subbots
        const subNums = (global.subConns || [])
            .filter(c => c?.user)
            .map(c => c.user.id.split('@')[0].split(':')[0].replace(/\D/g, ''));
        if (subNums.includes(num)) continue;

        const { lastSeen, msgCount } = (() => {
            if (chatHistory?.isReady) {
                const hist = chatHistory.getUserHistory(chatId, num);
                if (hist && hist.lastMsgTs > 0) return { lastSeen: hist.lastMsgTs, msgCount: hist.msgCount || 0 };
            }
            return { lastSeen: 0, msgCount: 0 };
        })();

        if (lastSeen === 0) {
            if (isGhosts) {
                fantasmas.push({
                    jid: p.id,
                    num,
                    msgCount,
                    lastSeen,
                    isAdmin: p.admin === 'admin' || p.admin === 'superadmin'
                });
                continue;
            }
        }

        if (!isGhosts && lastSeen < cutoff) {
            inactivos.push({
                jid: p.id,
                num,
                msgCount,
                lastSeen,
                isAdmin: p.admin === 'admin' || p.admin === 'superadmin'
            });
        }
    }

    if (isGhosts) {
        if (fantasmas.length === 0) {
            return message.reply('✅ No hay fantasmas en este grupo. Todos los miembros registrados han escrito al menos una vez.');
        }

        fantasmas.sort((a, b) => a.num.localeCompare(b.num, undefined, { numeric: true }));

        const mentions = fantasmas.map(u => u.jid);
        const lines = [];
        lines.push('👻 *FANTASMAS DEL GRUPO*');
        lines.push(`📊 Total: *${fantasmas.length}* de *${participants.length}* miembros\n`);

        fantasmas.forEach((u, i) => {
            const tag = `@${u.num}`;
            const adminTag = u.isAdmin ? ' 👑' : '';
            lines.push(`${i + 1}. ${tag}${adminTag}`);
            lines.push('🕐 nunca ha escrito');
        });

        lines.push('\n⚠️ _Estos usuarios nunca han enviado mensajes desde que el bot registra la actividad._');

        return await sock.sendMessage(chatId, {
            text: lines.join('\n'),
            mentions
        }, { quoted: message.baileyMessage || message._baileyMessage });
    }

    if (inactivos.length === 0) {
        return message.reply(
            `✅ No hay miembros inactivos en las últimas *${formatDuration(thresholdMs)}*.\n` +
            `Todos han enviado al menos un mensaje en ese período.`
        );
    }

    // Ordenar: primero los que llevan más tiempo sin escribir
    inactivos.sort((a, b) => a.lastSeen - b.lastSeen);

    // Construir mensaje con menciones
    const mentions = inactivos.map(u => u.jid);

    let lines = [];
    lines.push(`🔇 *Inactivos en las últimas ${formatDuration(thresholdMs)}*`);
    lines.push(`📊 Total: *${inactivos.length}* de *${participants.length}* miembros\n`);

    inactivos.forEach((u, i) => {
        const tag = `@${u.num}`;
        const adminTag = u.isAdmin ? ' 👑' : '';

        const diffMs  = now - u.lastSeen;
        const diffMin = Math.floor(diffMs / 60000);
        const diffH   = Math.floor(diffMin / 60);
        const diffD   = Math.floor(diffH / 24);

        let lastSeenStr;
        if      (u.lastSeen === 0) lastSeenStr = 'nunca ha escrito';
        else if (diffD   > 0)      lastSeenStr = `hace ${diffD}d`;
        else if (diffH   > 0)      lastSeenStr = `hace ${diffH}h`;
        else if (diffMin > 0)      lastSeenStr = `hace ${diffMin}min`;
        else                       lastSeenStr = 'ahora';

        const msgLine = u.msgCount > 0 ? `💬 ${u.msgCount.toLocaleString()} mensajes · ` : '';
        lines.push(`${i + 1}. ${tag}${adminTag}\n${msgLine}🕐 ${lastSeenStr}`);
    });

    lines.push(`\n⚠️ _Solo se registran mensajes desde que el bot está activo._`);

    await sock.sendMessage(chatId, {
        text: lines.join('\n'),
        mentions
    }, { quoted: message.baileyMessage || message._baileyMessage });
};

handler.help    = ['inactivos <tiempo>', 'topinactivos <tiempo>', 'fantasmas'];
handler.tags    = ['grupos', 'admin'];
handler.command = /^(inactivos|topinactivos|fantasmas|hijosdeputa)$/i;
handler.group   = true;
handler.owner   = false;

module.exports = handler;

