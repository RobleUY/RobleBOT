'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           🎂 SISTEMA DE CUMPLEAÑOS - ROBLEBOT               ║
 * ║                                                              ║
 * ║  SOLO FUNCIONA EN GRUPOS                                     ║
 * ║                                                              ║
 * ║  .micumple <día> <mes> <país>   → registrar cumple (global) ║
 * ║  .micumple test                 → prueba (solo owner)        ║
 * ║  .cumpleaños                    → ver cumples del grupo      ║
 * ║  .cumpleaños @user              → ver cumple de alguien      ║
 * ║  .cumpleaños set @user <fecha>  → admin: setear cumple       ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * JSON guardado en: data/cumpleanos.json
 * {
 *   "59893900470@s.whatsapp.net": {
 *     day, month, timezone, country,
 *     lastWished,           ← ISO string del último año felicitado (global)
 *     groupOverrides: {     ← overrides por grupo (seteados por admins)
 *       "120363XXX@g.us": { day, month, timezone, country, lastWished }
 *     }
 *   }
 * }
 *
 * NOTA: No se guarda el nombre. Se usa @mención directa siempre.
 *
 * Lógica de aviso:
 * - global → avisa en TODOS los grupos donde esté el usuario (con bot disponible)
 * - groupOverride → avisa SOLO en ese grupo
 * - Cron cada minuto → dispara a las 00:02 hora local del usuario
 * - Solo UN bot por grupo (determinista: main → sub1 → sub2..., prefiere admin)
 */

const fs        = require('fs');
const path      = require('path');
const cron      = require('node-cron');
const moment    = require('moment-timezone');
const botConfig = require('../config');

// ─── Rutas y constantes ───────────────────────────────────────────────────────
const DATA_PATH = path.join(__dirname, '..', 'data', 'cumpleanos.json');

// readMore trick (igual que en menu.js)
const MORE      = String.fromCharCode(8206);
const READ_MORE = MORE.repeat(4001);

// ─── Mapa de países → zonas horarias ─────────────────────────────────────────
const COUNTRY_TZ = {
    'uruguay':         'America/Montevideo',   'uy': 'America/Montevideo',
    'argentina':       'America/Argentina/Buenos_Aires', 'ar': 'America/Argentina/Buenos_Aires',
    'brasil':          'America/Sao_Paulo',    'brazil': 'America/Sao_Paulo', 'br': 'America/Sao_Paulo',
    'chile':           'America/Santiago',     'cl': 'America/Santiago',
    'peru':            'America/Lima',         'pe': 'America/Lima',
    'colombia':        'America/Bogota',       'co': 'America/Bogota',
    'venezuela':       'America/Caracas',      've': 'America/Caracas',
    'bolivia':         'America/La_Paz',       'bo': 'America/La_Paz',
    'ecuador':         'America/Guayaquil',    'ec': 'America/Guayaquil',
    'paraguay':        'America/Asuncion',     'py': 'America/Asuncion',
    'mexico':          'America/Mexico_City',  'méxico': 'America/Mexico_City', 'mx': 'America/Mexico_City',
    'cuba':            'America/Havana',       'cu': 'America/Havana',
    'rep. dominicana': 'America/Santo_Domingo','rep dominicana': 'America/Santo_Domingo',
    'dominicana':      'America/Santo_Domingo','do': 'America/Santo_Domingo',
    'puerto rico':     'America/Puerto_Rico',  'pr': 'America/Puerto_Rico',
    'guatemala':       'America/Guatemala',    'gt': 'America/Guatemala',
    'honduras':        'America/Tegucigalpa',  'hn': 'America/Tegucigalpa',
    'el salvador':     'America/El_Salvador',  'sv': 'America/El_Salvador',
    'nicaragua':       'America/Managua',      'ni': 'America/Managua',
    'costa rica':      'America/Costa_Rica',   'cr': 'America/Costa_Rica',
    'panama':          'America/Panama',       'panamá': 'America/Panama', 'pa': 'America/Panama',
    'españa':          'Europe/Madrid',        'spain': 'Europe/Madrid',  'es': 'Europe/Madrid',
    'portugal':        'Europe/Lisbon',        'pt': 'Europe/Lisbon',
    'france':          'Europe/Paris',         'francia': 'Europe/Paris', 'fr': 'Europe/Paris',
    'alemania':        'Europe/Berlin',        'germany': 'Europe/Berlin','de': 'Europe/Berlin',
    'italia':          'Europe/Rome',          'italy': 'Europe/Rome',    'it': 'Europe/Rome',
    'reino unido':     'Europe/London',        'uk': 'Europe/London',     'gb': 'Europe/London',
    'usa':             'America/New_York',     'estados unidos': 'America/New_York', 'us': 'America/New_York',
    'canada':          'America/Toronto',      'canadá': 'America/Toronto','ca': 'America/Toronto',
    'australia':       'Australia/Sydney',     'au': 'Australia/Sydney',
    'japon':           'Asia/Tokyo',           'japan': 'Asia/Tokyo',     'jp': 'Asia/Tokyo',
    'china':           'Asia/Shanghai',        'cn': 'Asia/Shanghai',
};

const MESES = {
    'enero':1,'jan':1,'january':1,'febrero':2,'feb':2,'february':2,
    'marzo':3,'mar':3,'march':3,'abril':4,'apr':4,'april':4,
    'mayo':5,'may':5,'junio':6,'jun':6,'june':6,'julio':7,'jul':7,'july':7,
    'agosto':8,'aug':8,'august':8,'septiembre':9,'sep':9,'september':9,
    'octubre':10,'oct':10,'october':10,'noviembre':11,'nov':11,'november':11,
    'diciembre':12,'dec':12,'december':12,
};
const MESES_ES = ['','enero','febrero','marzo','abril','mayo','junio',
                  'julio','agosto','septiembre','octubre','noviembre','diciembre'];

// ─── Helpers de persistencia ──────────────────────────────────────────────────

function loadBirthdays() {
    try {
        if (fs.existsSync(DATA_PATH))
            return JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
    } catch (e) {
        console.error('[Cumpleaños] Error cargando cumpleanos.json:', e.message);
    }
    return {};
}

function saveBirthdays(data) {
    try {
        const dir = path.dirname(DATA_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('[Cumpleaños] Error guardando cumpleanos.json:', e.message);
    }
}

// ─── Helpers de JID ──────────────────────────────────────────────────────────

/** Extrae solo los dígitos de cualquier JID */
const cleanId = (v) => v ? String(v).split('@')[0].split(':')[0].replace(/\D/g, '') : '';

/**
 * Convierte cualquier JID (incluyendo @lid) al formato canónico @s.whatsapp.net.
 * 1. Prueba si sock.signalRepository.lidMapping.getPNForLID puede resolverlo.
 * 2. Prueba si global.db.getCanonicalId tiene el alias mapeado a su número real.
 * 3. Fallback: extrae dígitos limpios y retorna @s.whatsapp.net.
 */
async function toCanonicalJid(jid, sock = null) {
    if (!jid) return null;
    const strJid = String(jid);
    
    // Si ya viene con @s.whatsapp.net
    if (strJid.endsWith('@s.whatsapp.net')) {
        const num = cleanId(strJid);
        return num ? `${num}@s.whatsapp.net` : null;
    }

    // Si viene como @lid
    if (strJid.endsWith('@lid')) {
        // Intentar resolver via Baileys Signal Repository LID mapping
        const socket = sock || global.conn;
        if (socket?.signalRepository?.lidMapping?.getPNForLID) {
            try {
                const pn = await socket.signalRepository.lidMapping.getPNForLID(strJid);
                if (pn) {
                    const cleanPn = cleanId(pn);
                    if (cleanPn) {
                        if (global.db?.linkUserAlias) {
                            try { global.db.linkUserAlias(cleanPn, strJid); } catch (_) {}
                        }
                        return `${cleanPn}@s.whatsapp.net`;
                    }
                }
            } catch (_) {}
        }

        // Intentar resolver via aliases en base de datos
        if (global.db?.getCanonicalId) {
            try {
                const cleanDigits = cleanId(strJid);
                const canonical = global.db.getCanonicalId(cleanDigits);
                if (canonical && canonical !== cleanDigits) {
                    return `${canonical}@s.whatsapp.net`;
                }
            } catch (_) {}
        }
    }

    const num = cleanId(strJid);
    return num ? `${num}@s.whatsapp.net` : null;
}

// ─── Helpers de tiempo ────────────────────────────────────────────────────────

/** Tiempo detallado que falta: meses, días, horas, minutos */
function tiempoFalta(day, month, timezone) {
    try {
        const tz       = timezone || 'UTC';
        const now      = moment.tz(tz);
        const year     = now.year();
        let   next     = moment.tz({ year, month: month - 1, date: day, hour: 0, minute: 0, second: 0 }, tz);
        if (next.isSameOrBefore(now, 'minute')) next.add(1, 'year');

        const totalMs   = next.diff(now);
        const totalMins = Math.floor(totalMs / 60000);
        if (totalMins <= 0) return '¡Ahora mismo! 🎉';
        if (totalMins < 60) return `¡Hoy! 🎉 (en ${totalMins}m)`;

        const totalHrs  = Math.floor(totalMins / 60);
        const mins      = totalMins % 60;
        const hours     = totalHrs % 24;
        const totalDays = Math.floor(totalHrs / 24);

        if (totalDays === 0) return `¡Hoy! 🎉 (en ${hours}h ${mins}m)`;

        const months = Math.floor(totalDays / 30);
        const days   = totalDays % 30;

        const parts = [];
        if (months > 0) parts.push(`${months} mes${months !== 1 ? 'es' : ''}`);
        if (days > 0)   parts.push(`${days} día${days !== 1 ? 's' : ''}`);
        if (hours > 0)  parts.push(`${hours}h`);
        if (mins > 0)   parts.push(`${mins}m`);
        return `en ${parts.join(', ')}`;
    } catch (_) {
        return '(error calculando)';
    }
}

/** ¿Es ahora exactamente las 00:02 en la timezone del usuario y es su cumple? */
function isBirthdayNow(day, month, timezone) {
    try {
        const now = moment.tz(timezone || 'UTC');
        return (
            now.date()    === day     &&
            now.month()   === month - 1 &&
            now.hours()   === 0       &&
            now.minutes() === 2
        );
    } catch (_) { return false; }
}

/** ¿Ya fue felicitado este año? */
function alreadyWished(lastWished) {
    if (!lastWished) return false;
    return new Date(lastWished).getFullYear() === new Date().getFullYear();
}

// ─── Helpers de sockets ───────────────────────────────────────────────────────

function isSocketUsable(sock) {
    if (!sock?.user || typeof sock.sendMessage !== 'function') return false;
    const s = sock.ws?.readyState;
    return s !== 2 && s !== 3;
}

function getSocketNums(sock) {
    return [
        cleanId(sock.user?.id),
        cleanId(sock.user?.jid),
        cleanId(sock.user?.lid),
        cleanId(sock._lid),
    ].filter(Boolean);
}

function isSockAdminInGroup(sock, meta) {
    if (!sock?.user || !Array.isArray(meta?.participants)) return false;
    const myIds = new Set(getSocketNums(sock));
    for (const p of meta.participants) {
        if (myIds.has(cleanId(p.id)))
            return p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin === true;
    }
    return false;
}

/** Lista ordenada de sockets: main → sub1 → sub2... (determinista) */
function getAllSockets() {
    const result = [], seen = new Set();
    const add = (sock) => { if (sock && !seen.has(sock)) { seen.add(sock); result.push(sock); } };
    add(global.conn);
    if (Array.isArray(global.subConns)) {
        [...global.subConns]
            .sort((a, b) => Number(a?._subNum ?? 9999) - Number(b?._subNum ?? 9999))
            .forEach(add);
    }
    if (global.subbotLidMap instanceof Map)
        for (const sock of global.subbotLidMap.values()) add(sock);
    return result;
}

/**
 * Encuentra el mejor bot para un grupo:
 * - Debe estar en el grupo
 * - Si solo-admins: debe ser admin
 * - Prefiere admin, acepta cualquiera en grupos normales
 * - Siempre determinista (mismo orden)
 */
function findBotForGroup(groupJid, groupMeta) {
    if (!Array.isArray(groupMeta?.participants) || !groupMeta.participants.length) return null;

    const memberSet  = new Set(groupMeta.participants.map(p => cleanId(p.id)).filter(Boolean));
    const isAnnounce = !!groupMeta.announce;

    const botsInGroup = getAllSockets().filter(sock =>
        isSocketUsable(sock) && getSocketNums(sock).some(n => memberSet.has(n))
    );
    if (!botsInGroup.length) return null;

    if (isAnnounce) {
        return botsInGroup.find(sock => isSockAdminInGroup(sock, groupMeta)) || null;
    }
    return botsInGroup.find(sock => isSockAdminInGroup(sock, groupMeta)) || botsInGroup[0];
}

/** Metadatos del grupo (caché primero, luego red) */
async function getGroupMeta(groupJid, preferredSock = null) {
    try {
        const { getGroupMetadataCached } = require('../lib/groupCache');
        if (typeof getGroupMetadataCached === 'function') {
            const sock = preferredSock || global.conn;
            const meta = await getGroupMetadataCached(sock, groupJid);
            if (meta?.participants?.length) return meta;
        }
    } catch (_) {}

    try {
        const { groupMetadataCache } = require('../lib/groupCache');
        const cached = groupMetadataCache?.get(groupJid)?.data;
        if (cached?.participants?.length) return cached;
    } catch (_) {}

    for (const sock of getAllSockets()) {
        if (!sock?.user || typeof sock.groupMetadata !== 'function') continue;
        try {
            const meta = await sock.groupMetadata(groupJid);
            if (meta?.participants?.length) return meta;
        } catch (_) {}
    }
    return null;
}

/** Lista de grupos conocidos */
async function getAllKnownGroups() {
    try {
        const { groupMetadataCache } = require('../lib/groupCache');
        if (groupMetadataCache?.size) {
            const groups = [...groupMetadataCache.keys()].filter(k => k.endsWith('@g.us'));
            if (groups.length) return groups;
        }
    } catch (_) {}
    for (const sock of getAllSockets().slice(0, 3)) {
        if (typeof sock.groupFetchAllParticipating !== 'function') continue;
        try {
            const groups = await sock.groupFetchAllParticipating();
            if (groups) return Object.keys(groups).filter(k => k.endsWith('@g.us'));
        } catch (_) {}
    }
    return [];
}

// ─── Función de felicitación ──────────────────────────────────────────────────

/**
 * Envía felicitaciones al usuario en sus grupos.
 * @param {string} userJid   - JID canónico (@s.whatsapp.net) del cumpleañero
 * @param {object} rec       - Su registro en el JSON
 * @param {string|null} onlyGroup - Solo enviar en este grupo (override de admin)
 */
async function sendBirthdayWishes(userJid, rec, onlyGroup = null) {
    const userNum   = cleanId(userJid);
    const jidCumple = `${userNum}@s.whatsapp.net`;

    const targetGroups = onlyGroup ? [onlyGroup] : await getAllKnownGroups();
    if (!targetGroups.length) {
        console.log('[Cumpleaños] No se encontraron grupos para', userNum);
        return false;
    }

    let wishedInAtLeastOne = false;

    for (const groupJid of targetGroups) {
        try {
            const meta = await getGroupMeta(groupJid);
            if (!meta?.participants?.length) continue;

            // ¿El cumpleañero está en el grupo? (comparación por número puro)
            const memberNums = meta.participants.map(p => cleanId(p.id));
            if (!memberNums.includes(userNum)) continue;

            // ¿Hay bot disponible?
            const sock = findBotForGroup(groupJid, meta);
            if (!sock) continue;

            // Menciones: todos los miembros del grupo
            const allMentions = meta.participants.map(p => p.id).filter(Boolean);

            // Mensaje: @mención directa, sin nombre hardcodeado
            const msgTexto = [
                '🎂✨ *¡FELIZ CUMPLEAÑOS!* ✨🎂',
                '',
                '╔═════ ≪ 🎉 ≫ ═════',
                `║  @${userNum}`,
                '║  ¡Hoy es tu cumpleaños! 🥳',
                '╚══════════════',
                '',
                '🎊 *¡Feliz cumpleaños!* 🎊',
                'Que sea un día espectacular, lleno de alegría y celebración.',
                '¡Te deseamos lo mejor hoy y siempre! 🎁🍰🥂',
                '',
                READ_MORE,
                allMentions.map(jid => `@${jid.split('@')[0]}`).join(' '),
            ].join('\n');

            await sock.sendMessage(groupJid, {
                text:     msgTexto,
                mentions: [jidCumple, ...allMentions],
            });

            wishedInAtLeastOne = true;
            console.log(`[Cumpleaños] 🎂 Felicitado ${userNum} en ${groupJid}`);

            // Pausa para no saturar WhatsApp
            await new Promise(r => setTimeout(r, 1500));

        } catch (err) {
            console.error(`[Cumpleaños] Error en grupo ${groupJid}:`, err.message);
        }
    }

    return wishedInAtLeastOne;
}

// ─── Cron: verificación cada minuto ──────────────────────────────────────────
// global._birthdayCronTask → sobrevive hot-reloads (no crea segundos crons)
// global._birthdayCronRunning → mutex para evitar solapamiento de iteraciones

function startBirthdayCron() {
    if (global._birthdayCronTask) return;

    global._birthdayCronTask = cron.schedule('* * * * *', async () => {
        if (global._birthdayCronRunning) return;
        global._birthdayCronRunning = true;
        try {
            const data = loadBirthdays();

            for (const [userJid, rec] of Object.entries(data)) {
                if (!rec) continue;

                // ── Cumple GLOBAL ──────────────────────────────────────────
                if (rec.day && rec.month && rec.timezone) {
                    if (!alreadyWished(rec.lastWished) && isBirthdayNow(rec.day, rec.month, rec.timezone)) {
                        console.log(`[Cumpleaños] 🎂 Cumpleaños global de ${userJid}`);
                        const wished = await sendBirthdayWishes(userJid, rec, null);
                        if (wished) {
                            const fresh = loadBirthdays();
                            if (fresh[userJid]) {
                                fresh[userJid].lastWished = new Date().toISOString();
                                saveBirthdays(fresh);
                            }
                        }
                    }
                }

                // ── Overrides por grupo (seteados por admins) ──────────────
                const overrides = rec.groupOverrides;
                if (overrides && typeof overrides === 'object') {
                    for (const [groupJid, ov] of Object.entries(overrides)) {
                        if (!ov?.day || !ov?.month || !ov?.timezone) continue;
                        if (alreadyWished(ov.lastWished)) continue;
                        if (!isBirthdayNow(ov.day, ov.month, ov.timezone)) continue;

                        console.log(`[Cumpleaños] 🎂 Override cumple de ${userJid} en ${groupJid}`);
                        const wished = await sendBirthdayWishes(userJid, { ...rec, ...ov }, groupJid);
                        if (wished) {
                            const fresh = loadBirthdays();
                            if (fresh[userJid]?.groupOverrides?.[groupJid]) {
                                fresh[userJid].groupOverrides[groupJid].lastWished = new Date().toISOString();
                                saveBirthdays(fresh);
                            }
                        }
                    }
                }
            }
        } catch (err) {
            console.error('[Cumpleaños] Error en cron:', err.message);
        } finally {
            global._birthdayCronRunning = false;
        }
    }, { scheduled: true, timezone: 'UTC' });

    console.log('🎂 [Cumpleaños] Cron iniciado (cada minuto, UTC).');
}

startBirthdayCron();

// ─── Helper: parsear fecha desde args ────────────────────────────────────────

/**
 * Parsea tokens como ["13", "enero", "uruguay"] → { day, month, country, timezone }
 * o devuelve { error: "mensaje" }
 */
function parseFechaArgs(parts) {
    if (!parts || parts.length < 2) return { error: 'Faltan el día y el mes.' };

    const day = parseInt(parts[0], 10);
    if (isNaN(day) || day < 1 || day > 31)
        return { error: `Día inválido: *${parts[0]}*. Usá un número entre 1 y 31.` };

    const monthStr = parts[1].toLowerCase();
    const month    = MESES[monthStr] || parseInt(monthStr, 10);
    if (!month || month < 1 || month > 12)
        return { error: `Mes inválido: *${parts[1]}*. Usá el nombre en español (enero, febrero...).` };

    const country  = parts.slice(2).join(' ').toLowerCase() || null;
    const timezone = country ? (COUNTRY_TZ[country] || null) : null;

    if (country && !timezone)
        return { error: `País no reconocido: *${country}*\n\n🌍 Usá: Uruguay, Argentina, Chile, Colombia, México, España, Brasil, Perú, Venezuela, y más.` };

    // Validar que la fecha existe
    try {
        const tz  = timezone || 'UTC';
        const tst = moment.tz({ month: month - 1, date: day }, tz);
        if (!tst.isValid() || tst.date() !== day)
            return { error: `Fecha inválida: el día ${day} no existe en ${MESES_ES[month]}.` };
    } catch (_) {
        return { error: 'Error validando la fecha. Intentá de nuevo.' };
    }

    return { day, month, country, timezone: timezone || null };
}

// ─── HANDLER PRINCIPAL ────────────────────────────────────────────────────────

let handler = async (m, { conn, args, usedPrefix, command }) => {

    // ── SOLO EN GRUPOS ────────────────────────────────────────────────────────
    if (!m.isGroup) {
        return m.reply('❌ Este comando solo funciona en grupos.');
    }

    const chatId    = m.chat; // JID del grupo
    const senderJid = m.sender; // puede ser @lid

    // Resolver el JID canónico del sender (convierte @lid → @s.whatsapp.net)
    const activeSock = conn || m._sock || global.conn;
    const canonicalSenderJid = await toCanonicalJid(senderJid, activeSock);
    if (!canonicalSenderJid) return m.reply('❌ No se pudo identificar tu número.');
    const senderNum = cleanId(canonicalSenderJid);

    // Metadatos del grupo
    let groupMeta = null;
    try { groupMeta = await getGroupMeta(chatId, activeSock); } catch (_) {}
    const participants = groupMeta?.participants || [];

    function isGroupAdmin(jid) {
        const num = cleanId(jid);
        const p   = participants.find(p => cleanId(p.id) === num || cleanId(p.lid) === num || cleanId(p.phoneNumber) === num);
        return p?.admin === 'admin' || p?.admin === 'superadmin' || p?.isAdmin === true;
    }

    // Guardar tanto números como LIDs/phoneNumbers que puedan venir en participants
    const participantNums = new Set();
    for (const p of participants) {
        if (p.id) participantNums.add(cleanId(p.id));
        if (p.lid) participantNums.add(cleanId(p.lid));
        if (p.phoneNumber) participantNums.add(cleanId(p.phoneNumber));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COMANDOS: .cumpleaños / .birthday
    // ══════════════════════════════════════════════════════════════════════════
    if (/^(cumpleaños|cumpleanos|birthday|birthdays)$/i.test(command)) {

        const data = loadBirthdays();

        // ── .cumpleaños set @user <día> <mes> [<país>] ────────────────────────
        if (args[0]?.toLowerCase() === 'set') {
            if (!isGroupAdmin(canonicalSenderJid)) {
                return m.reply('❌ Solo los administradores del grupo pueden usar `.cumpleaños set`.');
            }

            const mentionedJids = m.mentionedJid || [];
            if (!mentionedJids.length) {
                return m.reply(
                    `❌ Debés mencionar al usuario.\n` +
                    `Uso: \`${usedPrefix}cumpleaños set @usuario <día> <mes> <país>\`\n` +
                    `_Ej: \`${usedPrefix}cumpleaños set @usuario 25 diciembre uruguay\`_`
                );
            }

            // Resolver el JID mencionado
            const targetJid = await toCanonicalJid(mentionedJids[0], activeSock);
            if (!targetJid) return m.reply('❌ No se pudo identificar al usuario mencionado.');
            const targetNum = cleanId(targetJid);

            // Filtrar args: sacar "set" y el token del @mencioado (número largo)
            const restArgs = args.slice(1).filter(a => !a.startsWith('@') && !/^\d{6,}/.test(a));

            if (restArgs.length < 2) {
                return m.reply(
                    `❌ Falta la fecha.\n` +
                    `Uso: \`${usedPrefix}cumpleaños set @usuario <día> <mes> <país>\`\n` +
                    `_Ej: \`${usedPrefix}cumpleaños set @usuario 25 diciembre uruguay\`_`
                );
            }

            const parsed = parseFechaArgs(restArgs.map(a => a.toLowerCase()));
            if (parsed.error) return m.reply(`❌ ${parsed.error}`);

            const { day, month, timezone, country } = parsed;
            if (!timezone || !country) {
                return m.reply(
                    `❌ Falta el país.\n` +
                    `Uso: \`${usedPrefix}cumpleaños set @usuario <día> <mes> <país>\`\n` +
                    `_Ej: \`${usedPrefix}cumpleaños set @usuario 25 diciembre uruguay\`_`
                );
            }

            // Guardar como override de este grupo
            if (!data[targetJid]) data[targetJid] = {};
            if (!data[targetJid].groupOverrides) data[targetJid].groupOverrides = {};
            data[targetJid].groupOverrides[chatId] = {
                day, month, timezone, country,
                setBy:      senderNum,
                lastWished: data[targetJid].groupOverrides?.[chatId]?.lastWished || null,
            };
            saveBirthdays(data);

            const fecha   = `${String(day).padStart(2, '0')} de ${MESES_ES[month]}`;
            const falta   = tiempoFalta(day, month, timezone);
            const paisDisp = country.charAt(0).toUpperCase() + country.slice(1);
            return m.reply(
                `✅ *Cumpleaños configurado para este grupo* 🎂\n\n` +
                `╔═════ ≪ 🎂 ≫ ═════\n` +
                `║  👤 Usuario: @${targetNum}\n` +
                `║  📅 Fecha: *${fecha}*\n` +
                `║  🌍 País: *${paisDisp}*\n` +
                `║  🕐 Zona: *${timezone}*\n` +
                `║  ⏳ Falta: *${falta}*\n` +
                `╚══════════════\n\n` +
                `_Solo se avisará en este grupo (configurado por admin)._`,
                { mentions: [targetJid] }
            );
        }

        // ── .cumpleaños @user ─────────────────────────────────────────────────
        const mentionedJids = m.mentionedJid || [];
        if (mentionedJids.length) {
            const targetJid = await toCanonicalJid(mentionedJids[0], activeSock);
            if (!targetJid) return m.reply('❌ No se pudo identificar al usuario.');
            const targetNum = cleanId(targetJid);
            const rec       = data[targetJid];

            if (!rec?.day && !rec?.groupOverrides?.[chatId]?.day) {
                return m.reply(`📭 @${targetNum} no tiene cumpleaños registrado.`, { mentions: [targetJid] });
            }

            // Override del grupo tiene prioridad
            const ov    = rec?.groupOverrides?.[chatId];
            const day   = ov?.day    || rec?.day;
            const month = ov?.month  || rec?.month;
            const tz    = ov?.timezone || rec?.timezone || 'UTC';
            const pais  = ov?.country || rec?.country;

            if (!day || !month) {
                return m.reply(`📭 @${targetNum} no tiene cumpleaños registrado.`, { mentions: [targetJid] });
            }

            const fecha    = `${String(day).padStart(2, '0')} de ${MESES_ES[month]}`;
            const falta    = tiempoFalta(day, month, tz);
            const paisStr  = pais ? ` 🌍 ${pais.charAt(0).toUpperCase() + pais.slice(1)}` : '';
            const fuente   = ov ? '_(configurado por admin del grupo)_' : '_(global)_';

            return m.reply(
                `╔═════ ≪ 🎂 ≫ ═════\n` +
                `║   *CUMPLEAÑOS DE @${targetNum}*\n` +
                `╚══════════════\n\n` +
                `📅 *Fecha:* ${fecha}${paisStr}\n` +
                `🕐 *Zona:* ${tz}\n` +
                `⏳ *Falta:* ${falta}\n` +
                `${fuente}`,
                { mentions: [targetJid] }
            );
        }

        // ── .cumpleaños (sin args) → cumples de los miembros del grupo ────────
        // Filtrar solo los usuarios que están en este grupo
        const entriesDelGrupo = Object.entries(data).filter(([jid]) =>
            participantNums.has(cleanId(jid))
        );

        if (!entriesDelGrupo.length) {
            return m.reply(
                `📭 Ningún miembro de este grupo tiene su cumpleaños registrado.\n\n` +
                `Usá \`${usedPrefix}micumple <día> <mes> <país>\` para registrar el tuyo.`
            );
        }

        // Ordenar por próximo cumpleaños
        const now    = moment();
        const sorted = entriesDelGrupo
            .map(([jid, rec]) => {
                const ov    = rec?.groupOverrides?.[chatId];
                const day   = ov?.day   || rec?.day;
                const month = ov?.month || rec?.month;
                const tz    = ov?.timezone || rec?.timezone || 'UTC';
                const pais  = ov?.country || rec?.country;
                if (!day || !month) return null;

                let next = moment({ year: now.year(), month: month - 1, date: day });
                if (next.isSameOrBefore(now, 'day')) next.add(1, 'year');
                return { jid, day, month, tz, pais, next };
            })
            .filter(Boolean)
            .sort((a, b) => a.next - b.next);

        if (!sorted.length) {
            return m.reply(`📭 Ningún miembro de este grupo tiene su cumpleaños registrado.`);
        }

        const mentionsList = sorted.map(e => e.jid);
        let msg = `╔═════ ≪ 🎂 ≫ ═════\n║   *CUMPLEAÑOS DEL GRUPO*\n╚══════════════\n\n`;

        for (const { jid, day, month, tz, pais } of sorted) {
            const num     = cleanId(jid);
            const fecha   = `${String(day).padStart(2, '0')} de ${MESES_ES[month]}`;
            const paisStr = pais ? ` 🌍 ${pais.charAt(0).toUpperCase() + pais.slice(1)}` : '';
            const falta   = tiempoFalta(day, month, tz);
            const esMio   = num === senderNum ? ' _(tuyo)_' : '';

            msg += `🎂 @${num}${esMio} — ${fecha}${paisStr}\n`;
            msg += `   ⏳ _${falta}_\n\n`;
        }

        msg += `_${sorted.length} cumpleaños en este grupo_`;
        return m.reply(msg, { mentions: mentionsList });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COMANDO: .micumple → registrar el propio cumpleaños (global)
    // ══════════════════════════════════════════════════════════════════════════

    if (!args.length) {
        return m.reply(
            `🎂 *Sistema de Cumpleaños*\n\n` +
            `*Registrar tu cumpleaños:*\n` +
            `\`${usedPrefix}micumple <día> <mes> <país>\`\n` +
            `_Ej: \`${usedPrefix}micumple 13 enero uruguay\`_\n\n` +
            `*Ver cumpleaños del grupo:*\n` +
            `\`${usedPrefix}cumpleaños\`\n\n` +
            `*Ver cumpleaños de alguien:*\n` +
            `\`${usedPrefix}cumpleaños @usuario\`\n\n` +
            `*Setear cumpleaños (solo admins):*\n` +
            `\`${usedPrefix}cumpleaños set @usuario <día> <mes> <país>\`\n\n` +
            `*Test (solo owner):*\n` +
            `\`${usedPrefix}micumple test\`\n\n` +
            `🌍 *Países:* Uruguay, Argentina, Chile, Colombia, México, España, Brasil, Perú, Venezuela...`
        );
    }

    // ── SUBCOMANDO: test ──────────────────────────────────────────────────────
    if (args[0].toLowerCase() === 'test') {
        const isOwner = await botConfig.isOwnerJid(senderJid);
        if (!isOwner) return m.reply('❌ Solo el owner del bot puede usar este subcomando.');

        const data = loadBirthdays();
        const rec  = data[canonicalSenderJid];
        if (!rec?.day) {
            return m.reply('❌ No tenés un cumpleaños registrado.\nUsá primero: `.micumple <día> <mes> <país>`');
        }

        await m.reply('🧪 Iniciando prueba de felicitación...');
        const wished = await sendBirthdayWishes(canonicalSenderJid, rec, null);
        return m.reply(
            wished
                ? '✅ *Prueba completada.* El bot envió felicitaciones en tus grupos. 🎂'
                : '⚠️ No se pudo enviar en ningún grupo. Verificá que el bot esté en algún grupo con vos.'
        );
    }

    // ── REGISTRO NORMAL: .micumple <día> <mes> <país> ─────────────────────────
    const parsed = parseFechaArgs(args.map(a => a.toLowerCase()));
    if (parsed.error) {
        return m.reply(
            `❌ ${parsed.error}\n\n` +
            `✅ *Uso correcto:*\n` +
            `\`${usedPrefix}micumple <día> <mes> <país>\`\n` +
            `_Ejemplo: \`${usedPrefix}micumple 13 enero uruguay\`_`
        );
    }

    if (!parsed.timezone || !parsed.country) {
        return m.reply(
            `❌ Falta el país.\n\n` +
            `✅ *Uso correcto:*\n` +
            `\`${usedPrefix}micumple <día> <mes> <país>\`\n` +
            `_Ejemplo: \`${usedPrefix}micumple 13 enero uruguay\`_`
        );
    }

    const { day, month, timezone, country } = parsed;

    // Guardar (preservar lastWished y groupOverrides existentes, NO guardar name)
    const data = loadBirthdays();
    const existing = data[canonicalSenderJid] || {};
    data[canonicalSenderJid] = {
        groupOverrides: existing.groupOverrides || undefined,
        lastWished:     existing.lastWished     || null,
        day, month, timezone, country,
        registeredAt: new Date().toISOString(),
    };
    // Limpiar undefined
    if (!data[canonicalSenderJid].groupOverrides)
        delete data[canonicalSenderJid].groupOverrides;

    saveBirthdays(data);

    const fecha      = `${String(day).padStart(2, '0')} de ${MESES_ES[month]}`;
    const falta      = tiempoFalta(day, month, timezone);
    const paisDisp   = country.charAt(0).toUpperCase() + country.slice(1);

    return m.reply(
        `✅ *¡Cumpleaños registrado!* 🎂\n\n` +
        `╔═════ ≪ 🎂 ≫ ═════\n` +
        `║  📅 Fecha: *${fecha}*\n` +
        `║  🌍 País: *${paisDisp}*\n` +
        `║  🕐 Zona: *${timezone}*\n` +
        `║  ⏳ Falta: *${falta}*\n` +
        `╚══════════════\n\n` +
        `_A las 00:02 de ${paisDisp} te mencionaré en todos los grupos donde estés junto a todos los miembros._ 🎉`
    );
};

// ─── Configuración ────────────────────────────────────────────────────────────
handler.help    = ['micumple', 'cumpleaños', 'cumpleanos'];
handler.tags    = ['info', 'social'];
handler.command = /^(micumple|micumpleaños|micumpleanos|cumpleaños|cumpleanos|birthday|birthdays)$/i;
handler.group   = true; // Solo funciona en grupos

module.exports = handler;
