const translateSystem = require('../translateSystem');

const { resolveLanguage, getLanguage, setLanguage, resetLanguage } = translateSystem;

// Intenta con la lista local (tolera tildes, typos, códigos y frases tipo "traduceme al italiano").
// Si no lo reconoce, le pregunta a la IA, pero valida la respuesta para no guardar basura.
async function detectLanguage(rawInput) {
    const local = resolveLanguage(rawInput);
    if (local) return local;

    try {
        const iaModule = require('./HERRAMIENTAS/ia/ia.js');
        const answer = await iaModule.callIA(
            'You identify languages. The user may misspell the language name or write it in any language. ' +
            'Reply with ONLY the English name of the language (e.g. Portuguese, Swahili, Basque). ' +
            'If the text is not a language, reply exactly: UNKNOWN',
            `Language requested: "${rawInput}"`
        );
        const name = String(answer || '').trim().replace(/[."'`*]/g, '');
        if (/^[A-Za-z][A-Za-z\- ]{1,24}$/.test(name) && !/unknown/i.test(name) && name.split(' ').length <= 3) {
            return name.charAt(0).toUpperCase() + name.slice(1);
        }
    } catch (e) {
        console.error('[lenguaje] Error detectando idioma con IA:', e.message);
    }
    return null;
}

let handler = async (message, { text }) => {
    const userId = message.author || message.sender || message.from;
    const cleanUserId = userId?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '') || userId;

    if (!text || !text.trim()) {
        const currentLang = getLanguage(cleanUserId);
        return await message.reply(
            '🌍 *CONFIGURACIÓN DE IDIOMA PERSONAL*\n\n' +
            `📌 *Tu idioma actual:* ${currentLang === 'español' ? 'Español (predeterminado)' : currentLang}\n\n` +
            '✅ *Uso:*\n' +
            '• `.traducir inglés` - Cambiar a inglés\n' +
            '• `.traducir portugués` - Cambiar a portugués\n' +
            '• `.traducir francés` - Cambiar a francés\n' +
            '• `.traducir defecto` - Volver al español\n' +
            '• `.traducir traduceme al italiano` - Texto natural\n\n' +
            '💡 Funciona con o sin tildes, en cualquier idioma y aunque lo escribas con algún error.\n' +
            '💡 También sirven `.lenguaje` y `.lang`.\n\n' +
            '⚠️ *FUNCIÓN BETA:*\n' +
            '• Las traducciones pueden no ser perfectas\n' +
            '• Los mensajes pueden tardar más en llegar\n' +
            '• Solo se traduce TEXTO, no imágenes/stickers/audios\n\n' +
            '💡 *Nota:* Solo TÚ verás las traducciones, es personal.'
        );
    }

    const language = await detectLanguage(text.trim());

    if (!language) {
        return await message.reply(
            `❌ No pude reconocer el idioma "*${text.trim()}*".\n\n` +
            'Probá con algo como: `.traducir inglés`, `.traducir portugués`, `.traducir japonés`.'
        );
    }

    // Español = volver a lo normal
    if (language === 'Spanish') {
        resetLanguage(cleanUserId);
        console.log(`[lenguaje] Usuario ${cleanUserId} reseteo a español`);
        return await message.reply(
            '✅ *Idioma restablecido*\n\n' +
            '🇪🇸 Ahora verás las respuestas en *español* (idioma predeterminado).\n' +
            'Los mensajes se enviarán sin traducción.'
        );
    }

    setLanguage(cleanUserId, language);
    console.log(`[lenguaje] Usuario ${cleanUserId} configuró idioma: ${language} (entrada: "${text.trim()}")`);

    return await message.reply(
        '✅ *Idioma configurado*\n\n' +
        `🌍 Ahora verás las respuestas traducidas a: *${language}*\n\n` +
        '⚠️ *Función BETA:* las traducciones pueden no ser perfectas, pueden tardar más y solo se traduce TEXTO.\n\n' +
        '🔄 Para volver al español: `.traducir defecto`'
    );
};

handler.help = ['traducir <idioma>', 'lenguaje <idioma>', 'lang <idioma>', 'language <idioma>'];
handler.tags = ['config'];
handler.command = /^(lenguaje|lang|language|traducir|traduce|traduccion|translate)$/i;

// Exportar funciones para uso en otros módulos
handler.getLanguage = getLanguage;

module.exports = handler;