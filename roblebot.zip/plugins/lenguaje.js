const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/idiomas-usuarios.json');

// Cargar configuración de idiomas
function loadLanguageConfig() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('[lenguaje] Error cargando config:', e);
    }
    return {};
}

// Guardar configuración de idiomas
function saveLanguageConfig(config) {
    try {
        const dir = path.dirname(DATA_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(DATA_FILE, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {
        console.error('[lenguaje] Error guardando config:', e);
    }
}

// Obtener idioma de un usuario
function getLanguage(userId) {
    const config = loadLanguageConfig();
    return config[userId] || 'español';
}

// Establecer idioma de un usuario
function setLanguage(userId, language) {
    const config = loadLanguageConfig();
    config[userId] = language.toLowerCase().trim();
    saveLanguageConfig(config);
}

// Resetear a español
function resetLanguage(userId) {
    const config = loadLanguageConfig();
    delete config[userId];
    saveLanguageConfig(config);
}

let handler = async (message, { conn, text }) => {
    const userId = message.author || message.sender || message.from;
    // Usar la misma lógica de limpieza que handler.js
    const cleanUserId = userId?.split('@')[0]?.split(':')[0]?.replace(/\D/g, '') || userId;

    if (!text || !text.trim()) {
        const currentLang = getLanguage(cleanUserId);
        return await message.reply(
            '🌍 *CONFIGURACIÓN DE IDIOMA PERSONAL*\n\n' +
            `📌 *Tu idioma actual:* ${currentLang === 'español' ? 'Español (predeterminado)' : currentLang}\n\n` +
            '✅ *Uso:*\n' +
            '• `.lenguaje inglés` - Cambiar a inglés\n' +
            '• `.lenguaje portugués` - Cambiar a portugués\n' +
            '• `.lenguaje francés` - Cambiar a francés\n' +
            '• `.lenguaje defecto` - Volver al español\n' +
            '• `.lenguaje traduceme al italiano` - Texto natural\n\n' +
            '⚠️ *FUNCIÓN BETA:*\n' +
            '• Las traducciones pueden no ser perfectas\n' +
            '• Los mensajes pueden tardar más en llegar\n' +
            '• Puede haber cortes en las respuestas\n' +
            '• Contenido inapropiado puede no traducirse\n' +
            '• Se recomienda usar español si lo hablas\n' +
            '• Usa traducciones solo si es necesario\n\n' +
            '💡 *Nota:* Solo TÚ verás las traducciones, es personal.'
        );
    }

    const input = text.trim().toLowerCase();
    
    // Detectar si quiere volver al español/defecto
    const resetPatterns = [
        'español', 'espanol', 'spanish', 'defecto', 'default', 'normal',
        'normalidad', 'original', 'predeterminado', 'quitar', 'eliminar',
        'desactivar', 'reset'
    ];
    
    const wantsReset = resetPatterns.some(p => input.includes(p)) && 
                      (input.includes('volver') || input.includes('reset') || 
                       input.includes('defecto') || input.includes('normal') ||
                       input.includes('español') || input.includes('espanol') ||
                       input.includes('original') || input.includes('quitar'));
    
    if (wantsReset) {
        resetLanguage(cleanUserId);
        console.log(`[lenguaje] Usuario ${cleanUserId} reseteo a español`);
        return await message.reply(
            '✅ *Idioma restablecido*\n\n' +
            '🇪🇸 Ahora verás las respuestas en *español* (idioma predeterminado).\n' +
            'Los mensajes se enviarán sin traducción.'
        );
    }

    // Guardar el idioma tal cual lo escribió el usuario
    const targetLanguage = text.trim();
    setLanguage(cleanUserId, targetLanguage);
    console.log(`[lenguaje] Usuario ${cleanUserId} configuró idioma: ${targetLanguage}`);
    
    return await message.reply(
        '✅ *Idioma configurado*\n\n' +
        `🌍 Ahora verás las respuestas traducidas a: *${targetLanguage}*\n\n` +
        '⚠️ *ADVERTENCIAS IMPORTANTES:*\n' +
        '• Esta es una función *BETA*\n' +
        '• Las traducciones pueden no ser perfectas\n' +
        '• Los mensajes tardarán más en llegar\n' +
        '• Puede haber cortes en las respuestas\n' +
        '• Solo se traduce TEXTO, no imágenes/stickers/audios\n' +
        '• Contenido inapropiado puede no traducirse\n\n' +
        '💡 *Recomendación:* Si hablas español, usa `.lenguaje defecto` para mejor experiencia.\n\n' +
        '🔄 Para volver al español: `.lenguaje defecto`'
    );
};

handler.help = ['lenguaje <idioma>', 'lang <idioma>', 'language <idioma>'];
handler.tags = ['config'];
handler.command = /^(lenguaje|lang|language)$/i;

// Exportar funciones para uso en otros módulos
handler.getLanguage = getLanguage;

module.exports = handler;
