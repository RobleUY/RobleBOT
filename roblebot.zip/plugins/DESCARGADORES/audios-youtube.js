const axios = require('axios');

// ============================================================
// 🎵 CONFIGURACIÓN DE APIS (Delirius)
// ============================================================
const DELIRIUS_SEARCH_API = 'https://api.delirius.online/search/ytsearch';
const DELIRIUS_YTMP3_API = 'https://api.delirius.online/download/ytmp3';

/**
 * 🔍 Valida si una cadena es un enlace válido de YouTube
 */
function esUrlDeYouTube(text) {
    const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
    return youtubeRegex.test(text);
}

/**
 * 🔎 Obtiene la URL de YouTube ya sea directamente o buscando por título
 */
async function obtenerUrlYouTube(query) {
    if (esUrlDeYouTube(query)) {
        console.log('🔗 Se detectó un enlace directo de YouTube.');
        return query.trim();
    }

    console.log(`🔎 Buscando "${query}" en Delirius ytsearch...`);
    const searchUrl = `${DELIRIUS_SEARCH_API}?q=${encodeURIComponent(query)}`;
    
    const res = await axios.get(searchUrl, { timeout: 15000 });
    const json = res.data;

    if (!json.status || !json.data || json.data.length === 0) {
        throw new Error('No se encontraron resultados para la búsqueda.');
    }

    const videoEncontrado = json.data[0];
    console.log(`✅ Video encontrado: "${videoEncontrado.title}" (${videoEncontrado.url})`);
    return videoEncontrado.url;
}

/**
 * 📥 Extrae el enlace de descarga y metadatos usando la API de Delirius YTMP3
 */
async function obtenerAudioDelirius(ytUrl) {
    const apiUrl = `${DELIRIUS_YTMP3_API}?url=${encodeURIComponent(ytUrl)}`;
    console.log(`🚀 Consultando Delirius YTMP3 API...`);

    const res = await axios.get(apiUrl, { timeout: 20000 });
    const json = res.data;

    if (!json.status || !json.data || !json.data.download) {
        throw new Error('La API de Delirius no devolvió un enlace de descarga válido.');
    }

    const resultado = json.data;
    return {
        title: resultado.title || 'Audio de YouTube',
        downloadUrl: resultado.download,
        thumbnail: resultado.image,
        author: resultado.author || 'Desconocido'
    };
}

/**
 * 🎯 Handler principal para .play, .audio, .yta, .ytaudio
 */
let handlerYouTubeAudio = async (message, { conn, text, usedPrefix, command }) => {
    try {
        if (!text || !text.trim()) {
            return await message.reply(
                `❌ *Falta el texto o enlace.*\n\n` +
                `*Uso correcto:*\n` +
                `> ${usedPrefix}${command} Twice\n` +
                `> ${usedPrefix}${command} https://www.youtube.com/watch?v=5M_n2UCe7DQ\n\n` +
                `*Comandos soportados:* \`.play\`, \`.audio\`, \`.yta\`, \`.ytaudio\``
            );
        }

        await message.reply('⏳ *Procesando tu solicitud con Delirius, por favor espera...*');

        // 1️⃣ Obtener URL de YouTube (por búsqueda o enlace directo)
        const ytUrl = await obtenerUrlYouTube(text);

        // 2️⃣ Obtener datos y enlace de descarga de la API de Delirius
        const audioInfo = await obtenerAudioDelirius(ytUrl);

        console.log(`🎧 Enviando audio por URL directa: "${audioInfo.title}"`);
        console.log(`🔗 URL de descarga: ${audioInfo.downloadUrl}`);

        const caption = `🎵 *Título:* ${audioInfo.title}\n👤 *Autor:* ${audioInfo.author}\n🔗 *Enlace:* ${ytUrl}`;

        // 3️⃣ Enviar directamente usando la URL con formato MP3 estricto
        await conn.sendMessage(
            message.from,
            {
                audio: { url: audioInfo.downloadUrl },
                mimetype: 'audio/mpeg', // Forzar mimetype mp3 estándar para WhatsApp
                fileName: `${audioInfo.title.replace(/[^\w\s]/gi, '')}.mp3`,
                ptt: false, // false para audio normal, true si lo quieres como nota de voz (voice note)
                caption: caption
            },
            { quoted: message._baileyMessage }
        );

        console.log(`✅ Audio enviado exitosamente.`);

    } catch (error) {
        console.error('💥 Error en comando YouTube Audio:', error.message || error);
        await message.reply(`❌ Ocurrió un error al procesar el audio: ${error.message || 'Error desconocido'}`);
    }
};

// Configuración de comandos
handlerYouTubeAudio.command = /^(play|audio|yta|ytaudio)$/i;
handlerYouTubeAudio.help = ['play <título o link>', 'audio <título o link>', 'yta <título o link>', 'ytaudio <título o link>'];
handlerYouTubeAudio.tags = ['downloader', 'musica'];

module.exports = handlerYouTubeAudio;