const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');

// ============================================================
// 🎵 CONFIGURACIÓN
// ============================================================
// Búsqueda: Delirius (solo para buscar por título)
const DELIRIUS_SEARCH_API = 'https://api.delirius.online/search/ytsearch';

/**
 * 🔍 Valida si una cadena es un enlace válido de YouTube
 */
function esUrlDeYouTube(text) {
    const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
    return youtubeRegex.test(text);
}

/**
 * 🔎 Obtiene la URL de YouTube ya sea directamente o buscando por título (Delirius)
 */
async function obtenerUrlYouTube(query) {
    if (esUrlDeYouTube(query)) {
        console.log('🔗 Se detectó un enlace directo de YouTube.');
        return query.trim();
    }

    console.log(`🔎 Buscando "${query}" en Delirius ytsearch...`);
    const searchUrl = `${DELIRIUS_SEARCH_API}?q=${encodeURIComponent(query)}`;

    const res = await axios.get(searchUrl, { timeout: 15000 });
    const json = res.data;

    if (!json.status || !json.data || json.data.length === 0) {
        throw new Error('No se encontraron resultados para la búsqueda.');
    }

    const videoEncontrado = json.data[0];
    console.log(`✅ Video encontrado: "${videoEncontrado.title}" (${videoEncontrado.url})`);
    return videoEncontrado.url;
}

/**
 * 🧰 Descarga con yt-dlp (youtube-dl-exec) desde la IP del propio bot.
 * Usa el audio de menor calidad (el más liviano) y lo convierte a MP3 con ffmpeg-static.
 */
async function obtenerAudio(ytUrl) {
    const youtubedl = require('youtube-dl-exec');
    let ffmpegPath;
    try { ffmpegPath = require('ffmpeg-static'); } catch (_) { /* usa el ffmpeg del sistema */ }

    const base = path.join(os.tmpdir(), `ytaudio_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);

    // Opciones para evitar el "Sign in to confirm you're not a bot":
    //   YT_COOKIES = ruta a un cookies.txt (formato Netscape) exportado de YouTube
    //   YT_PROXY   = proxy, ej: http://usuario:clave@host:puerto
    const extra = {};
    // Busca cookies.txt junto a este plugin; si no está, en la carpeta raíz del bot
    const cookiesPath = process.env.YT_COOKIES ||
        [path.join(__dirname, 'cookies.txt'), path.join(process.cwd(), 'cookies.txt')].find(p => fs.existsSync(p)) ||
        path.join(__dirname, 'cookies.txt');
    if (fs.existsSync(cookiesPath)) {
        // yt-dlp puede reescribir el archivo de cookies, así que se usa una copia temporal
        const copia = `${base}_cookies.txt`;
        fs.copyFileSync(cookiesPath, copia);
        extra.cookies = copia;
    }
    if (process.env.YT_PROXY) extra.proxy = process.env.YT_PROXY;

    // YouTube ahora exige resolver un desafío JavaScript; yt-dlp puede usar Node para eso.
    // Si tu binario de yt-dlp es viejo y no conoce esas opciones, se reintenta sin ellas.
    const variantes = [
        { jsRuntimes: 'node', remoteComponents: 'ejs:github' },
        {}
    ];
    const ejecutar = async (url, opts) => {
        let ultimo;
        for (const v of variantes) {
            try {
                return await youtubedl(url, { ...extra, ...v, ...opts });
            } catch (e) {
                ultimo = e;
                const msg = String(e.stderr || e.message || '').split('\n').filter(Boolean).pop() || '';
                console.warn(`   ↳ yt-dlp${Object.keys(v).length ? ' (con node)' : ''} falló: ${msg.slice(0, 200)}`);
            }
        }
        throw ultimo;
    };

    try {
        console.log(`🚀 Descargando audio con yt-dlp...${extra.cookies ? ' (con cookies)' : ''}${extra.proxy ? ' (con proxy)' : ''}`);

        // 1) Metadatos (título)
        const meta = await ejecutar(ytUrl, {
            ignoreNoFormatsError: true, // para obtener el título aunque no haya formatos
            dumpSingleJson: true,
            noWarnings: true,
            noCheckCertificates: true,
            noPlaylist: true
        });

        // 2) Audio más liviano + conversión a MP3
        await ejecutar(ytUrl, {
            format: 'worstaudio/worst/bestaudio/best',
            extractAudio: true,
            audioFormat: 'mp3',
            audioQuality: 9, // 9 = menor calidad / menor peso
            output: `${base}.%(ext)s`,
            noWarnings: true,
            noCheckCertificates: true,
            noPlaylist: true,
            ...(ffmpegPath ? { ffmpegLocation: ffmpegPath } : {})
        });

        const archivo = `${base}.mp3`;
        if (!fs.existsSync(archivo)) throw new Error('yt-dlp no generó el archivo MP3.');
        const buffer = fs.readFileSync(archivo);
        if (!buffer.length) throw new Error('El MP3 generado está vacío.');

        console.log(`📥 Listo (${(buffer.length / 1024 / 1024).toFixed(2)} MB)`);

        return {
            title: (meta && meta.title) || 'Audio de YouTube',
            buffer,
            size: `${(buffer.length / 1024 / 1024).toFixed(2)} MB`
        };
    } finally {
        // Limpieza de archivos temporales
        for (const ext of ['mp3', 'm4a', 'webm', 'opus', 'part']) {
            try { fs.unlinkSync(`${base}.${ext}`); } catch (_) {}
        }
        try { if (extra.cookies) fs.unlinkSync(extra.cookies); } catch (_) {}
    }
}

/**
 * 🎯 Handler principal para .play, .audio, .yta, .ytaudio
 */
let handlerYouTubeAudio = async (message, { conn, text, usedPrefix, command }) => {
    try {
        if (!text || !text.trim()) {
            return await message.reply(
                `❌ *Falta el texto o enlace.*\n\n` +
                `*Uso correcto:*\n` +
                `> ${usedPrefix}${command} Twice\n` +
                `> ${usedPrefix}${command} https://www.youtube.com/watch?v=5M_n2UCe7DQ\n\n` +
                `*Comandos soportados:* \`.play\`, \`.audio\`, \`.yta\`, \`.ytaudio\``
            );
        }

        await message.reply('⏳ *Procesando tu solicitud, por favor espera...*');

        // 1️⃣ URL de YouTube (búsqueda con Delirius o enlace directo)
        const ytUrl = await obtenerUrlYouTube(text);

        // 2️⃣ Audio más liviano con yt-dlp
        const audioInfo = await obtenerAudio(ytUrl);

        console.log(`🎧 Enviando audio: "${audioInfo.title}"`);

        const caption = `🎵 *Título:* ${audioInfo.title}\n📦 *Peso:* ${audioInfo.size}\n🔗 *Enlace:* ${ytUrl}`;
        const nombreLimpio = audioInfo.title.replace(/[^\w\s]/gi, '').trim() || 'audio';

        // 3️⃣ Enviar el MP3
        await conn.sendMessage(
            message.from,
            {
                audio: audioInfo.buffer,
                mimetype: 'audio/mpeg',
                fileName: `${nombreLimpio}.mp3`,
                ptt: false, // true para enviarlo como nota de voz
                caption: caption
            },
            { quoted: message._baileyMessage }
        );

        console.log('✅ Audio enviado exitosamente.');

    } catch (error) {
        console.error('💥 Error en comando YouTube Audio:', error.message || error);
        await message.reply(`❌ Ocurrió un error al procesar el audio: ${error.message || 'Error desconocido'}`);
    }
};

// Configuración de comandos
handlerYouTubeAudio.command = /^(play|audio|yta|ytaudio)$/i;
handlerYouTubeAudio.help = ['play <título o link>', 'audio <título o link>', 'yta <título o link>', 'ytaudio <título o link>'];
handlerYouTubeAudio.tags = ['downloader', 'musica'];

module.exports = handlerYouTubeAudio;