const axios = require('axios')
const yts = require('yt-search')
const downloadUtils = require('../../downloadUtils')
const { downloadWithLimit, cleanupTempFile } = downloadUtils

function getAudioDownloadUrl(value, source) {
  let url
  try {
    url = new URL(value)
  } catch {
    throw new Error(`${source} no devolvió una URL de audio válida`)
  }
  if (!['http:', 'https:'].includes(url.protocol)) {
    throw new Error(`${source} devolvió un protocolo de descarga no válido`)
  }
  return url.toString()
}

// ========================================
// CONFIGURACIÓN
// ========================================
const COMANDO_ACTIVADO = true
const LIMIT_MB = 100 // Límite de 100 MB para audios
const TIMEOUT_MS = 30000

// YouTube Data API v3 key
const YT_API_KEY = process.env.YOUTUBE_API_KEY || '';

const sanitizeFilename = (name = 'audio') => String(name).replace(/[\\/:*?"<>|]/g, '').slice(0, 150)

// ========================================
// YOUTUBE DATA API V3 + YT-SEARCH (INFO ULTRA RÁPIDA)
// ========================================

function extractVideoId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/
  ]
  for (const p of patterns) {
    const m = url.match(p)
    if (m) return m[1]
  }
  return null
}

function buildInfo(videoId, snippet) {
  const thumbs = snippet.thumbnails || {}
  const thumbnailUrl =
    thumbs.maxres?.url ||
    thumbs.standard?.url ||
    thumbs.high?.url ||
    thumbs.medium?.url ||
    thumbs.default?.url ||
    null

  return {
    videoId,
    title: snippet.title,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    thumbnailUrl
  }
}      

async function getVideoInfoById(videoId) {
  const endpoint = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item) throw new Error('No se encontró información en Data API')
  return buildInfo(videoId, item.snippet)
}

async function searchVideoInfo(query) {
  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${YT_API_KEY}`
  const res = await axios.get(endpoint, { timeout: 10000 })
  const item = res.data.items?.[0]
  if (!item || !item.id?.videoId) throw new Error('No se encontraron resultados en Data API')
  return buildInfo(item.id.videoId, item.snippet)
}

async function searchVideoInfoByHtml(query) {
  console.log('[MUSICYT INFO] Consultando búsqueda YouTube HTML fallback...')
  const res = await axios.get(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, {
    timeout: 15000,
    maxRedirects: 10,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'es-ES,es;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Referer': 'https://www.youtube.com/'
    }
  })
  const match = res.data.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)
  if (!match) throw new Error('No se encontró video en HTML')
  const videoId = match[1]
  return await getVideoInfoById(videoId)
}

// Carrera en paralelo para obtener miniatura y título al instante (Promise.any)
async function resolveVideoInfoFast(text, isLink) {
  if (isLink) {
    const videoId = extractVideoId(text)
    if (!videoId) throw new Error('No se obtuvo un link válido de YouTube.')
    return {
      videoId,
      title: null,
      url: `https://www.youtube.com/watch?v=${videoId}`,
      thumbnailUrl: null
    }
  }

  const tasks = []

  // Opción 1: Data API v3
  if (YT_API_KEY) {
    tasks.push(
      (async () => {
        if (isLink) {
          const videoId = extractVideoId(text)
          if (!videoId) throw new Error('No ID')
          return await getVideoInfoById(videoId)
        } else {
          return await searchVideoInfo(text)
        }
      })()
    )
  }

  // Opción 2: yt-search
  tasks.push(
    (async () => {
      const res = await yts(text)
      if (!res?.videos?.length) throw new Error('yt-search sin resultados')
      const v = res.videos[0]
      return {
        videoId: v.videoId || null,
        title: v.title,
        url: v.url,
        thumbnailUrl: v.thumbnail || null
      }
    })()
  )

  try {
    const winner = await Promise.any(tasks)
    console.log(`[MUSICYT INFO] ⚡ Información obtenida rápidamente: "${winner.title}"`)
    return winner
  } catch (e) {
    console.error('[MUSICYT INFO] Fallaron búsquedas rápidas, usando fallback básico:', e.message)
    if (!isLink && typeof text === 'string') {
      try {
        return await searchVideoInfoByHtml(text)
      } catch (htmlErr) {
        console.error('[MUSICYT INFO] Fallback HTML falló:', htmlErr.message)
      }
    }
    throw new Error('No se pudo resolver un video de YouTube válido para ese texto.')
  }
}

// ========================================
// DESCARGA DE AUDIO
// ========================================

function isValidAudioBuffer(buffer) {
  if (!buffer || !Buffer.isBuffer(buffer)) return false
  if (buffer.length < 1024) return false
  if (buffer.subarray(0, 3).toString() === 'ID3') return true
  if (buffer.length >= 8 && buffer.toString('ascii', 4, 8) === 'ftyp') return true
  if (buffer.subarray(0, 4).toString() === 'OggS') return true
  if (buffer.subarray(0, 4).toString() === 'RIFF') return true
  for (let i = 0; i < Math.min(buffer.length - 1, 4096); i++) {
    if (buffer[i] === 0xff && [0xfb, 0xf3, 0xf2].includes(buffer[i + 1])) return true
  }
  return false
}

function getAudioFileInfo(buffer) {
  if (buffer.length >= 8 && buffer.toString('ascii', 4, 8) === 'ftyp') {
    return { extension: 'm4a', mimetype: 'audio/mp4' }
  }
  if (buffer.subarray(0, 4).toString() === 'OggS') {
    return { extension: 'ogg', mimetype: 'audio/ogg' }
  }
  return { extension: 'mp3', mimetype: 'audio/mpeg' }
}

const { 
  isDownloading, 
  startDownload, 
  trackTempFile, 
  cancelDownload, 
  finishDownload 
} = require('../../lib/downloadManager')

// ========================================
// DESCARGA Y VALIDACION DEL BUFFER
// ========================================
async function getWorkingAudio(url, limitMb, signal = null) {
  if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')

  let limitError = null
  const sources = [
    {
      name: 'RobleAPI',
      get: async () => {
        const { data } = await axios.get('https://robleapi.vercel.app/download/ytmp3', {
          params: { url }, timeout: TIMEOUT_MS, signal
        })
        if (data?.ok !== true) throw new Error('respuesta inválida')
        return { download: data.download_url, title: data.title }
      }
    },
    {
      name: 'DeliriusAPI',
      get: async () => {
        const { data } = await axios.get('https://api.delirius.online/download/ytmp3', {
          params: { url }, timeout: TIMEOUT_MS, signal
        })
        if (data?.status !== true) throw new Error('respuesta inválida')
        return { download: data.data?.download, title: data.data?.title }
      }
    },
    {
      name: 'SankaAPI',
      get: async () => {
        const { data } = await axios.get('https://www.sankavollerei.web.id/download/ytmp3', {
          params: { apikey: 'planaai', url }, timeout: TIMEOUT_MS, signal
        })
        if (data?.status !== true) throw new Error('respuesta inválida')
        return {
          download: data.result?.download || data.downloadURL || data.download_url,
          title: data.result?.title || data.title
        }
      }
    }
  ]

  for (const source of sources) {
    if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED')
    let downloadData = null
    try {
      console.log(`[MUSICYT] Consultando ${source.name}...`)
      const result = await source.get()
      const downloadUrl = getAudioDownloadUrl(result.download, source.name)
      downloadData = await downloadWithLimit(downloadUrl, limitMb, {}, signal)
      if (!isValidAudioBuffer(downloadData.buffer)) {
        throw new Error('el archivo recibido no parece ser un audio válido')
      }

      console.log(`[MUSICYT] Audio descargado mediante ${source.name} (${downloadData.sizeMB} MB)`)
      return {
        title: typeof result.title === 'string' && result.title.trim() ? result.title.trim() : 'Audio de YouTube',
        source: source.name,
        downloadData,
        fileInfo: getAudioFileInfo(downloadData.buffer)
      }
    } catch (error) {
      if (downloadData?.tempFile) cleanupTempFile(downloadData.tempFile)
      if (signal?.aborted || error.message === 'DOWNLOAD_ABORTED') {
        throw new Error('DOWNLOAD_ABORTED')
      }
      console.error(`[MUSICYT] ${source.name} falló:`, error.message)
      if (error.message?.startsWith('LIMIT_EXCEEDED:')) limitError = error
    }
  }

  if (limitError) throw limitError
  throw new Error('No se pudo descargar el audio con RobleAPI, DeliriusAPI ni SankaAPI.')
}

// ========================================

// HANDLER PRINCIPAL
// ========================================

let handler = async (message, { text, conn, usedPrefix, command }) => {
  const sock = conn || message._sock || global.conn
  if (!COMANDO_ACTIVADO) {
    return await message.reply('⚠️ *COMANDO EN MANTENIMIENTO*')
  }

  const userId = message.author || message.sender
  const chatId = message.from
  const cleanInput = (text || '').trim().toLowerCase()

  // 1. Comando de Cancelación/Detener
  if (['stop', 'cancel', 'detener', 'cancelar'].includes(cleanInput)) {
    const wasCanceled = cancelDownload(chatId, userId)
    if (wasCanceled) {
      return await message.reply('🛑 *Descarga de audio cancelada correctamente.*')
    } else {
      return await message.reply('ℹ️ *No tienes ninguna descarga en curso para cancelar.*')
    }
  }

  if (!text) {
    return await message.reply(`❌ Por favor envía un link o título.\n*Ejemplo:* ${usedPrefix + command} Never Gonna Give You Up\n*Para cancelar:* ${usedPrefix + command} stop`)
  }

  // 2. Control de Concurrencia por Usuario: 1 sola descarga activa a la vez
  if (isDownloading(chatId, userId)) {
    return await message.reply(
      `⚠️ *Ya tienes una descarga en curso.*\nPor favor espera a que termine o usa *${usedPrefix + command} stop* para cancelarla.`
    )
  }

  let downloadObj = null
  let tempFile = null

  try {
    downloadObj = startDownload(chatId, userId, 'audio', text)
    const { signal } = downloadObj

    // Verificar si la red del servidor está caída antes de intentar descargas
    if (global.networkGuard && global.networkGuard.isNetworkDown()) {
      const status = global.networkGuard.getCircuitStatus()
      const secsLeft = Math.ceil(status.recoveryIn / 1000)
      finishDownload(chatId, userId)
      return await message.reply(`⚠️ *La red del servidor está caída temporalmente.*\nSe detectaron errores masivos de conexión. Intenta en ~${secsLeft}s.`)
    }

    const isLink = /https?:\/\/(www\.)?(youtube\.com|youtu\.be)/i.test(text)

    await message.reply(isLink ? '📥 Descargando audio...' : '🔍 Buscando audio...')

    if (signal.aborted) return

    // 1) Resolver información lo más rápido posible
    const videoInfo = await resolveVideoInfoFast(text, isLink)
    if (signal.aborted) return

    const { url: youtubeUrl, title: videoTitle, thumbnailUrl } = videoInfo
    if (!extractVideoId(youtubeUrl)) {
      throw new Error('No se obtuvo un link válido de YouTube para descargar.')
    }

    // 2) Enviar miniatura inmediatamente
    const sendThumbnailTask = (async () => {
      try {
        if (thumbnailUrl && !signal.aborted) {
          await sock.sendMessage(message.from, {
            image: { url: thumbnailUrl },
            caption: `🎧 *${videoTitle}*\n⏳ Descargando audio...\n_Para cancelar usa: ${usedPrefix + command} stop_`
          }, { quoted: message._baileyMessage })
        }
      } catch (thumbError) {
        console.error('[MUSICYT] No se pudo enviar la miniatura:', thumbError.message)
      }
    })()

    // 3) Descargar audio y enviar archivo
    const sendAudioTask = (async () => {
      const { title, source, downloadData } = await getWorkingAudio(youtubeUrl, LIMIT_MB, signal)
      if (signal.aborted) return

      tempFile = downloadData.tempFile
      if (tempFile) trackTempFile(chatId, userId, tempFile)

      const sizeMB = downloadData.sizeMB
      console.log(`[MUSICYT] 🚀 Enviando a WhatsApp audio descargado vía ${source} (${sizeMB} MB)...`)

      const { extension, mimetype } = getAudioFileInfo(downloadData.buffer)
      const fileName = `${sanitizeFilename(title || videoTitle)}.${extension}`

      if (signal.aborted) return

      await sock.sendMessage(message.from, {
        audio: downloadData.buffer,
        mimetype,
        fileName: fileName,
        ptt: false
      }, { quoted: message._baileyMessage })

      console.log(`[MUSICYT] ✅ Audio enviado a WhatsApp con éxito (vía ${source})`)
    })()

    await Promise.all([sendThumbnailTask, sendAudioTask])

  } catch (e) {
    if (e.message === 'DOWNLOAD_ABORTED' || downloadObj?.signal?.aborted) {
      console.log('[MUSICYT] 🛑 Descarga cancelada por el usuario.')
      return
    }
    console.error('[MUSICYT] Error:', e.message)
    if (e.message?.startsWith('LIMIT_EXCEEDED:')) {
      const sizeMB = e.message.split(':')[1]
      return await message.reply(
        `❌ *EL AUDIO SUPERA EL LÍMITE PERMITIDO*\n\n` +
        `📦 *Tamaño del audio:* ${sizeMB} MB\n` +
        `⚠️ *Límite máximo para audio:* ${LIMIT_MB} MB\n\n` +
        `💡 _Intenta con una canción o audio más corto._`
      )
    }
    await message.reply(
      `❌ *NO SE PUDO DESCARGAR EL AUDIO*\n\n` +
      `📌 *Motivo:* ${e.message?.includes('No se obtuvo') || e.message?.includes('No se pudo resolver') ? 'No se encontraron resultados para tu búsqueda.' : 'Las fuentes de descarga no están disponibles en este momento o el enlace es privado/inválido.'}\n\n` +
      `💡 _Verifica el nombre o enlace e intenta nuevamente._`
    )
  } finally {
    finishDownload(chatId, userId)
    if (tempFile) {
      cleanupTempFile(tempFile)
    }
  }
}

handler.help = ['play <título/link>', 'play stop']
handler.tags = ['audio']
handler.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i

module.exports = handler