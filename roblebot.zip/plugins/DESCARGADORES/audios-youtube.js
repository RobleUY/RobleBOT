
const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);

// ============================================================
// 🎵 CONFIGURACIÓN
// ============================================================

const DELIRIUS_SEARCH_API =
    'https://api.delirius.online/search/ytsearch';

const SANKA_DOWNLOAD_API =
    'https://www.sankavollerei.web.id/download/ytmp3';

const SANKA_API_KEY = 'planaai';

const SEARCH_TIMEOUT = 60000;
const DOWNLOAD_TIMEOUT = 120000;

const MAX_SEARCH_RETRIES = 3;
const MAX_DOWNLOAD_RETRIES = 3;

// ============================================================
// 🔍 VALIDAR YOUTUBE
// ============================================================

function esUrlDeYouTube(text) {
    return /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i.test(text);
}

// ============================================================
// ⏳ ESPERA
// ============================================================

function esperar(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// 📝 MOSTRAR ERRORES REALES DE AXIOS
// ============================================================

function obtenerError(error) {

    if (error.response) {
        let detalle = error.response.data;

        if (Buffer.isBuffer(detalle)) {
            detalle = detalle.toString('utf8');
        }

        if (typeof detalle === 'object' && detalle !== null) {
            detalle = JSON.stringify(detalle);
        }

        return `HTTP ${error.response.status}: ${detalle || 'Respuesta vacía del servidor'}`;
    }

    return `${error.code || 'ERROR'}: ${error.message}`;
}

// ============================================================
// 🔎 BÚSQUEDA DELIRIUS
// ============================================================

async function obtenerUrlYouTube(query) {

    if (esUrlDeYouTube(query)) {
        console.log('🔗 Enlace directo detectado.');
        return query.trim();
    }

    console.log(`🔎 Buscando: ${query}`);

    let ultimoError;

    for (let intento = 1; intento <= MAX_SEARCH_RETRIES; intento++) {

        try {

            console.log(`🔄 Búsqueda ${intento}/${MAX_SEARCH_RETRIES}`);

            const res = await axios.get(DELIRIUS_SEARCH_API, {
                params: {
                    q: query
                },
                timeout: SEARCH_TIMEOUT,
                headers: {
                    Accept: 'application/json',
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            const json = res.data;

            if (!json.status || !Array.isArray(json.data) || !json.data.length) {
                throw new Error('No se encontraron resultados.');
            }

            const video = json.data[0];

            if (!video.url || !esUrlDeYouTube(video.url)) {
                throw new Error('URL de YouTube inválida.');
            }

            console.log(`✅ Encontrado: ${video.title}`);
            console.log(`🔗 URL: ${video.url}`);

            return video.url;

        } catch (error) {

            ultimoError = error;

            console.error(
                `❌ Búsqueda ${intento}:`,
                obtenerError(error)
            );

            if (intento < MAX_SEARCH_RETRIES) {
                await esperar(2000);
            }
        }
    }

    throw new Error(
        `Falló la búsqueda en Delirius: ${ultimoError.message}`
    );
}

// ============================================================
// ⏱️ COMPROBAR DURACIÓN CON FFPROBE
// ============================================================

async function comprobarDuracion(archivo) {

    try {

        const { stdout } = await execFileAsync('ffprobe', [
            '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            archivo
        ]);

        const duracion = parseFloat(stdout.trim());

        return Number.isFinite(duracion) ? duracion : null;

    } catch (_) {

        return null;
    }
}

// ============================================================
// 🔗 OBTENER ENLACE NUEVO DE SANKA
// ============================================================

async function obtenerEnlaceSanka(ytUrl) {

    const res = await axios.get(SANKA_DOWNLOAD_API, {
        params: {
            apikey: SANKA_API_KEY,
            url: ytUrl
        },
        timeout: DOWNLOAD_TIMEOUT,
        headers: {
            Accept: 'application/json',
            'User-Agent': 'Mozilla/5.0'
        }
    });

    const json = res.data;

    if (!json.status || !json.result || json.result.success === false) {
        throw new Error(
            json.message || 'Sanka no pudo procesar el video.'
        );
    }

    const info = json.result;

    const downloadUrl = info.downloadURL || info.download;

    if (!downloadUrl) {
        throw new Error('Sanka no devolvió un enlace de descarga.');
    }

    return {
        title: info.title || 'Audio de YouTube',
        author: info.author || 'Desconocido',
        thumbnail: info.thumbnail || '',
        durationApi: info.duration || 'Desconocida',
        downloadUrl
    };
}

// ============================================================
// 📥 DESCARGA DE AUDIO SANKA
// ============================================================

async function obtenerAudio(ytUrl) {

    const base = path.join(
        os.tmpdir(),
        `sanka_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    );

    const archivo = `${base}.m4a`;

    try {

        for (let intento = 1; intento <= MAX_DOWNLOAD_RETRIES; intento++) {

            try {

                console.log('\n======================================');
                console.log(`🚀 DESCARGA SANKA ${intento}/${MAX_DOWNLOAD_RETRIES}`);
                console.log('======================================');

                // Solicitar un enlace nuevo en cada intento
                const info = await obtenerEnlaceSanka(ytUrl);

                console.log(`🎵 Título: ${info.title}`);
                console.log(`👤 Artista: ${info.author}`);
                console.log(`⏱️ Duración API: ${info.durationApi}`);

                console.log('🔗 Enlace de descarga obtenido.');

                // Descargar archivo
                console.log('📥 Descargando audio...');

                const audioRes = await axios.get(info.downloadUrl, {
                    responseType: 'arraybuffer',
                    timeout: DOWNLOAD_TIMEOUT,
                    maxRedirects: 10,
                    maxContentLength: 100 * 1024 * 1024,
                    maxBodyLength: 100 * 1024 * 1024,
                    headers: {
                        'User-Agent': 'Mozilla/5.0',
                        'Accept': 'audio/mp4,audio/*,*/*',
                        'Referer': 'https://www.youtube.com/'
                    }
                });

                const buffer = Buffer.from(audioRes.data);

                if (!buffer.length) {
                    throw new Error('El servidor devolvió un archivo vacío.');
                }

                // Comprobar estado HTTP
                if (audioRes.status < 200 || audioRes.status >= 300) {
                    throw new Error(`HTTP ${audioRes.status}`);
                }

                // Comprobar formato M4A/MP4
                const esM4A =
                    buffer.length > 12 &&
                    buffer.toString('ascii', 4, 8) === 'ftyp';

                if (!esM4A) {

                    const inicio = buffer
                        .subarray(0, 150)
                        .toString('utf8')
                        .replace(/[^\x20-\x7E]/g, '');

                    throw new Error(
                        `Archivo inválido. Content-Type: ${audioRes.headers['content-type'] || 'desconocido'}. Respuesta: ${inicio || 'sin contenido reconocible'}`
                    );
                }

                // Guardar temporalmente
                fs.writeFileSync(archivo, buffer);

                // Tamaño real
                const bytes = buffer.length;
                const kb = (bytes / 1024).toFixed(2);
                const mb = (bytes / 1024 / 1024).toFixed(2);

                console.log('\n======================================');
                console.log('📦 INFORMACIÓN DEL AUDIO');
                console.log('======================================');

                console.log(`📁 Bytes: ${bytes}`);
                console.log(`📁 KB: ${kb}`);
                console.log(`📁 MB: ${mb}`);

                console.log(
                    `📡 Content-Type: ${audioRes.headers['content-type'] || 'Desconocido'}`
                );

                // Duración real
                let duracion = await comprobarDuracion(archivo);

                if (duracion !== null) {

                    console.log(`⏱️ Duración: ${duracion.toFixed(2)} segundos`);

                    if (duracion <= 0) {
                        throw new Error('El audio tiene duración de 0 segundos.');
                    }

                } else {

                    console.warn(
                        '⚠️ FFprobe no disponible: duración sin verificar.'
                    );
                }

                console.log('======================================');
                console.log('✅ DESCARGA COMPLETADA');

                return {
                    title: info.title,
                    author: info.author,
                    image: info.thumbnail,
                    buffer,
                    size: `${mb} MB`,
                    bytes,
                    duration: duracion,
                    format: 'm4a'
                };

            } catch (error) {

                console.error(
                    `❌ ERROR DESCARGA ${intento}:`,
                    obtenerError(error)
                );

                try {
                    if (fs.existsSync(archivo)) {
                        fs.unlinkSync(archivo);
                    }
                } catch (_) {}

                if (intento < MAX_DOWNLOAD_RETRIES) {
                    console.log('🔄 Solicitando otro enlace a Sanka...');
                    await esperar(2000);
                }
            }
        }

        throw new Error(
            'No se pudo descargar un audio válido después de 3 intentos.'
        );

    } finally {

        try {
            if (fs.existsSync(archivo)) {
                fs.unlinkSync(archivo);
            }
        } catch (_) {}
    }
}

// ============================================================
// 🎯 HANDLER PRINCIPAL
// ============================================================

let handlerYouTubeAudio = async (
    message,
    { conn, text, usedPrefix, command }
) => {

    try {

        if (!text || !text.trim()) {

            return await message.reply(
                `❌ *Falta el texto o enlace.*\n\n` +
                `*Uso correcto:*\n` +
                `> ${usedPrefix}${command} ronpe99 soy\n` +
                `> ${usedPrefix}${command} https://youtu.be/X2bZKeBnqDk\n\n` +
                `*Comandos:* .play, .audio, .yta, .ytaudio`
            );
        }

        await message.reply(
            '⏳ *Buscando y descargando tu canción...*'
        );

        // 1. Buscar
        const ytUrl = await obtenerUrlYouTube(text);

        // 2. Descargar
        const audioInfo = await obtenerAudio(ytUrl);

        // 3. Duración
        let duracionTexto = 'No disponible';

        if (audioInfo.duration !== null) {

            const minutos = Math.floor(audioInfo.duration / 60);
            const segundos = Math.floor(audioInfo.duration % 60);

            duracionTexto =
                `${minutos}:${String(segundos).padStart(2, '0')}`;
        }

        // 4. Nombre
        const nombreLimpio = audioInfo.title
            .replace(/[^\w\s-]/gi, '')
            .trim()
            .slice(0, 100) || 'audio';

        // 5. Caption
        const caption =
            `🎵 *Título:* ${audioInfo.title}\n` +
            `👤 *Artista:* ${audioInfo.author}\n` +
            `📦 *Peso:* ${audioInfo.size}\n` +
            `⏱️ *Duración:* ${duracionTexto}\n` +
            `🎼 *Formato:* M4A\n` +
            `🔗 *YouTube:* ${ytUrl}`;

        // 6. Enviar
        console.log('\n📤 ENVIANDO AUDIO...');
        console.log(`📦 Peso: ${audioInfo.size}`);

        await conn.sendMessage(
            message.from,
            {
                audio: audioInfo.buffer,
                mimetype: 'audio/mp4',
                fileName: `${nombreLimpio}.m4a`,
                ptt: false,
                caption
            },
            {
                quoted: message._baileyMessage
            }
        );

        console.log('✅ AUDIO ENVIADO EXITOSAMENTE.');

    } catch (error) {

        console.error(
            '\n💥 ERROR EN YOUTUBE AUDIO:',
            obtenerError(error)
        );

        await message.reply(
            `❌ *Error al procesar el audio:*\n\n` +
            `${error.message || 'Error desconocido'}`
        );
    }
};

// ============================================================
// ⚙️ COMANDOS
// ============================================================

handlerYouTubeAudio.command = /^(play|audio|yta|ytaudio)$/i;

handlerYouTubeAudio.help = [
    'play <título o link>',
    'audio <título o link>',
    'yta <título o link>',
    'ytaudio <título o link>'
];

handlerYouTubeAudio.tags = ['downloader', 'musica'];

module.exports = handlerYouTubeAudio;
