const axios = require('axios')

const ROBLE_YTMP3 = 'https://robleapi.vercel.app/download/ytmp3'
const DELIRIUS_SEARCH = 'https://api.delirius.online/search/ytsearch'

const API_TIMEOUT_MS = 30000
const BUFFER_DOWNLOAD_TIMEOUT_MS = 60000
const GLOBAL_YT_TIMEOUT_MS = 120000
const MAX_DURATION_SECONDS = 20 * 60 // máximo 20 min (evita archivos enormes en WhatsApp)

function withTimeout(promise, ms, timeoutMessage) {
  let timer
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage || `TIMEOUT_${ms}MS`)), ms)
  })
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer))
}

// Extrae el ID de video de youtube.com/watch, youtu.be, shorts, embed, live y music.youtube.com
function extractVideoId(text = '') {
  const m = text.match(
    /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/|v\/)|youtu\.be\/)([\w-]{11})/i
  )
  return m ? m[1] : null
}

// Convierte duración en formato "mm:ss" o "hh:mm:ss" a segundos (para validar límite)
function parseDurationToSeconds(durationStr = '') {
  const parts = durationStr.split(':').map(Number)
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2]
  } else if (parts.length === 2) {
    return parts[0] * 60 + parts[1]
  }
  return 0
}

function formatDuration(sec) {
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60
  const pad = n => String(n).padStart(2, '0')
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`
}

function sanitizeFileName(name = 'audio') {
  return name.replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 100) || 'audio'
}

// --- Búsqueda por texto con Delirius API ---

async function searchYouTubeText(query) {
  const res = await axios.get(`${DELIRIUS_SEARCH}?q=${encodeURIComponent(query)}`, { timeout: 15000 })
  const json = res.data
  
  if (!json?.status || !json?.data || !Array.isArray(json.data) || json.data.length === 0) {
    throw new Error('NO_SEARCH_RESULTS')
  }

  // Tomamos el primer video de los resultados
  const item = json.data.find(v => v.type === 'video') || json.data[0]
  if (!item?.videoId) throw new Error('NO_SEARCH_RESULTS')

  return {
    videoId: item.videoId,
    title: item.title,
    channel: item.author?.name || 'Desconocido',
    thumbnail: item.image || item.thumbnail,
    durationSec: parseDurationToSeconds(item.duration)
  }
}

// --- RobleAPI: link -> mp3 ---

async function getFromRobleYT(videoId) {
  console.log('[YTAUDIO] Consultando RobleAPI...')
  const url = `https://youtube.com/watch?v=${videoId}`
  const res = await axios.get(`${ROBLE_YTMP3}?url=${encodeURIComponent(url)}`, { timeout: API_TIMEOUT_MS })
  if (!res.data?.ok || !res.data?.download_url) throw new Error('ROBLE_YT_FAIL')
  return { title: res.data.title, downloadUrl: res.data.download_url }
}

async function downloadBuffer(url) {
  const res = await withTimeout(
    axios.get(url, {
      responseType: 'arraybuffer',
      timeout: BUFFER_DOWNLOAD_TIMEOUT_MS,
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36' }
    }),
    BUFFER_DOWNLOAD_TIMEOUT_MS,
    'BUFFER_DOWNLOAD_TIMEOUT'
  )
  return Buffer.from(res.data)
}

// --- Handler ---

let handlerYtAudio = async (message, { conn }) => {
  try {
    const text = (message.body || '').trim().split(/\s+/).slice(1).join(' ').trim()

    if (!text) {
      return await message.reply(
        '🎵 *Uso correcto:*\n/play <enlace o título>\n\nEjemplos:\n/play https://youtu.be/dQw4w9WgXcQ\n/play never gonna give you up'
      )
    }

    let videoId = extractVideoId(text)
    const esEnlace = !!videoId

    let info = null

    if (!esEnlace) {
      await message.reply(`🔍 Buscando *${text}*...`)
      try {
        info = await searchYouTubeText(text)
        videoId = info.videoId
      } catch (e) {
        if (e.message === 'NO_SEARCH_RESULTS') {
          return await message.reply('❌ No se encontraron resultados. Intenta con otro título.')
        }
        throw e
      }
    } else {
      await message.reply('⏳ Descargando audio...')
    }

    // Validar duración si la tenemos por la búsqueda
    if (info?.durationSec && info.durationSec > MAX_DURATION_SECONDS) {
      return await message.reply(
        `⚠️ El video dura *${formatDuration(info.durationSec)}* y el máximo permitido es *${formatDuration(MAX_DURATION_SECONDS)}*.`
      )
    }

    // Si vino de búsqueda, mostramos la info y miniatura
    if (!esEnlace && info) {
      const caption =
        `🎵 *${info.title}*\n` +
        `👤 ${info.channel}\n` +
        (info.durationSec ? `⏱️ ${formatDuration(info.durationSec)}\n` : '') +
        `\n⏳ Descargando audio...`
      try {
        if (info.thumbnail) {
          await conn.sendMessage(message.from, { image: { url: info.thumbnail }, caption }, { quoted: message._baileyMessage })
        } else {
          await message.reply(caption)
        }
      } catch (e) {
        console.log(`[YTAUDIO] No se pudo enviar la miniatura: ${e.message}`)
      }
    }

    const { title, downloadUrl } = await withTimeout(
      (async () => {
        const meta = await getFromRobleYT(videoId)
        return meta
      })(),
      GLOBAL_YT_TIMEOUT_MS,
      'GLOBAL_TIMEOUT'
    )

    const buffer = await downloadBuffer(downloadUrl)
    const finalTitle = info?.title || title || 'audio'

    console.log(`[YTAUDIO] 🚀 Enviando "${finalTitle}" (${(buffer.length / 1024 / 1024).toFixed(2)} MB)...`)

    await conn.sendMessage(
      message.from,
      {
        audio: buffer,
        mimetype: 'audio/mpeg',
        fileName: `${sanitizeFileName(finalTitle)}.mp3`
      },
      { quoted: message._baileyMessage }
    )

    console.log('[YTAUDIO] ✅ Audio enviado correctamente')

  } catch (error) {
    console.error('[YTAUDIO ERROR]', error.message || error)
    if (error.message === 'GLOBAL_TIMEOUT' || error.message === 'BUFFER_DOWNLOAD_TIMEOUT') {
      return await message.reply('⏱️ *La descarga tardó demasiado y fue cancelada.* Probá de nuevo en un momento.')
    }
    if (error.message === 'ROBLE_YT_FAIL') {
      return await message.reply('❌ No se pudo obtener el audio de ese video. Intenta con otro enlace.')
    }
    return await message.reply('❌ Ocurrió un error al obtener o enviar el audio. Intenta nuevamente más tarde.')
  }
}

handlerYtAudio.help = ['play <enlace o título>', 'ytmp3 <enlace o título>']
handlerYtAudio.tags = ['download']
handlerYtAudio.command = /^(audioyt|play|ytaudio|yta|audio|musica|ytmp3)$/i

module.exports.ytaudio = handlerYtAudio