const fs = require('fs');
const path = require('path');
const botConfig = require('../config');

const dataFilePath = path.join(__dirname, '..', 'data', 'comandos.json');
const PREFIXES = ['.', '/', '❤️', '#', '👅', '😎'];
const RESERVED_COMMANDS = ['addcmd', 'mycmds', 'delcmd', 'cmds'];
const MAX_COMMANDS_PER_USER = 50;

function ensureDataFile() {
    const dir = path.dirname(dataFilePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(dataFilePath)) {
        fs.writeFileSync(dataFilePath, JSON.stringify({ commands: {} }, null, 2));
    }
}

let cachedStore = null;

function loadStore() {
    if (cachedStore) return cachedStore;
    try {
        ensureDataFile();
        const raw = fs.readFileSync(dataFilePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') cachedStore = { commands: {} };
        else {
            if (!parsed.commands || typeof parsed.commands !== 'object') parsed.commands = {};
            cachedStore = parsed;
        }
        return cachedStore;
    } catch (error) {
        console.error('[comandos-personalizados] Error cargando comandos:', error.message);
        cachedStore = { commands: {} };
        return cachedStore;
    }
}

function saveStore(store) {
    try {
        cachedStore = store;
        ensureDataFile();
        fs.writeFileSync(dataFilePath, JSON.stringify(store));
    } catch (error) {
        console.error('[comandos-personalizados] Error guardando comandos:', error.message);
    }
}

function normalizeCommandName(raw) {
    if (!raw || typeof raw !== 'string') return '';
    return raw.trim()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/^[^a-zA-Z0-9]+/, '')
        .toLowerCase();
}

function isValidCommandName(name) {
    return /^[a-z0-9_]+$/i.test(name);
}

function normalizeTemplate(template) {
    return (template || '').trim();
}

/**
 * Extrae la URL de imagen del template si existe @img=URL
 * Retorna { imageUrl: string|null, cleanTemplate: string }
 */
function extractImageFromTemplate(template) {
    // Busca @img=VALOR (captura cualquier texto sin espacios)
    const imgRegex = /@img=(\S+)/i;
    const match = template.match(imgRegex);

    if (!match) {
        return { imageUrl: null, cleanTemplate: template };
    }

    const imageUrl = match[1];
    // Elimina el @img=URL del template para que no aparezca en el texto
    const cleanTemplate = template.replace(imgRegex, '').trim();

    return { imageUrl, cleanTemplate };
}

/**
 * Detecta si el template contiene una imagen en base64 (data:image/...)
 */
function templateHasBase64Image(template) {
    return /@img=data:[^;]+;base64,/i.test(template);
}

/**
 * Valida que una URL de imagen sea una URL http/https válida (no base64)
 */
function isValidImageUrl(url) {
    try {
        new URL(url);
        return /^https?:\/\/.+/i.test(url);
    } catch {
        return false;
    }
}

function templateLengthOk(template) {
    // Elimina variables y bloques @pr#=frase para calcular longitud real del texto
    const { cleanTemplate: sinPr } = extractPrWords(template);
    const stripped = sinPr
        .replace(/@yo|@text|@user|@random|@randomUser|@pr/gi, '')
        .replace(/@img=\S+/gi, '')
        .trim();
    return stripped.length <= 500;
}

/**
 * Extrae las opciones @pr1=, @pr2=, ... del template.
 * Los @pr#= DEBEN estar al final del template (después del texto base).
 * Cada valor puede ser una frase con espacios; termina cuando aparece
 * el siguiente @pr#= o el fin del string.
 * Retorna { prWords: string[], cleanTemplate: string }
 * Si hay menos de 2 opciones válidas, retorna prWords vacío y el template sin cambios.
 */
function extractPrWords(template) {
    // Encuentra la posición del PRIMER @pr#=
    const firstMatch = /@pr\d+=/i.exec(template);
    if (!firstMatch) return { prWords: [], cleanTemplate: template };

    const blockStart = firstMatch.index;
    const block = template.slice(blockStart);        // todo desde el primer @pr#=
    const textPart = template.slice(0, blockStart).trimEnd(); // texto antes del bloque

    // Dividir el bloque por cada "@pr<número>=" usando lookahead
    const parts = block.split(/(?=@pr\d+=)/i).filter(p => p.trim());

    const found = [];
    for (const part of parts) {
        const m = /^@pr(\d+)=([\s\S]*)/i.exec(part.trim());
        if (m) found.push({ order: parseInt(m[1], 10), value: m[2].trim() });
    }

    if (found.length < 2) return { prWords: [], cleanTemplate: template };

    found.sort((a, b) => a.order - b.order);
    const prWords = found.map(f => f.value).filter(v => v.length > 0);
    if (prWords.length < 2) return { prWords: [], cleanTemplate: template };

    return { prWords, cleanTemplate: textPart };
}

/**
 * Verifica que los @pr#= estén al final del template:
 * no debe haber texto (ni otras variables) después del primer @pr#=,
 * solo más @pr#= consecutivos.
 * Retorna true si está bien, false si hay texto después.
 */
function prWordsAreAtEnd(template) {
    const firstMatch = /@pr\d+=/i.exec(template);
    if (!firstMatch) return true; // no hay @pr#=, ok
    const block = template.slice(firstMatch.index);
    // En el bloque solo deben existir @pr#=... y sus valores, nada más "extraño"
    // Quitamos todo lo que sea @pr#=<cualquier cosa hasta el siguiente @pr#= o fin>
    const cleaned = block.split(/(?=@pr\d+=)/i)
        .filter(p => p.trim())
        .every(p => /^@pr\d+=/i.test(p.trim()));
    return cleaned;
}

function getCreatorKey(message) {
    const author = message.author || message.sender || message.key?.participant || message.key?.remoteJid;
    if (!author) return null;
    // Importante: cortar el sufijo de dispositivo (":13", ":7", etc.) ANTES de
    // limpiar caracteres no numéricos. Si no, sus dígitos quedan pegados al
    // número real y el mismo usuario "cambia de identidad" cada vez que
    // reconecta o usa otro dispositivo, rompiendo el conteo de usuarios únicos.
    return author.toString().split('@')[0].split(':')[0].replace(/\D/g, '');
}

function getSenderJid(message) {
    return message.key?.participant || message.author;
}

function getMentionJids(message) {
    if (!message) return [];
    return message.mentions || message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

function hasOfficialCommand(commandName) {
    const handler = global.commandHandler;
    if (!handler || !handler.commands) return false;

    if (handler.commands.has(commandName)) {
        return true;
    }

    for (const [cmdKey] of handler.commands) {
        if (cmdKey instanceof RegExp && cmdKey.test(commandName)) {
            return true;
        }
    }

    return false;
}

function hasIaCommand(commandName) {
    try {
        const iaPath = path.join(__dirname, '..', 'data', 'ias-personalizadas.json');
        if (!fs.existsSync(iaPath)) return false;
        const raw = fs.readFileSync(iaPath, 'utf8');
        const parsed = JSON.parse(raw);
        return !!(parsed?.ias?.[commandName]);
    } catch (error) {
        return false;
    }
}

function formatCommandName(name, displayName) {
    const display = displayName || name;
    return display.startsWith('.') ? display : `.${display}`;
}

function getCreatorDisplayName(creator) {
    if (!creator) return 'Sin apodo';
    try {
        if (global.db && typeof global.db.getUser === 'function') {
            const user = global.db.getUser(String(creator));
            const apodo = user?.apodo?.toString().trim();
            if (apodo && apodo.toLowerCase() !== 'sin apodo') {
                return apodo;
            }
        }
    } catch (e) {
        // Ignorar errores de DB y usar el fallback.
    }
    return 'Sin apodo';
}

/**
 * Calcula la cantidad de usuarios ÚNICOS que usaron un comando, que es lo
 * que se muestra en las listas (.cmds y .mycmds). Ya no se usa el viejo
 * contador `uses` para mostrar nada: si el comando todavía no tiene
 * `usedBy` (nadie lo usó desde este cambio), se muestra 0.
 */
function getUniqueUsageCount(data) {
    return Array.isArray(data.usedBy) ? data.usedBy.length : 0;
}

async function getRandomGroupUser(conn, groupId, senderJid) {
    try {
        const metadata = await conn.groupMetadata(groupId);
        if (!metadata || !metadata.participants || metadata.participants.length === 0) {
            return null;
        }

        const participants = metadata.participants
            .map(p => p.id)
            .filter(jid => jid !== senderJid);

        if (participants.length === 0) {
            return null;
        }

        const randomIndex = Math.floor(Math.random() * participants.length);
        const randomJid = participants[randomIndex];
        const randomNumber = randomJid.split('@')[0].split(':')[0];

        return { jid: randomJid, number: randomNumber };
    } catch (error) {
        console.error('[comandos-personalizados] Error obteniendo usuario random:', error.message);
        return null;
    }
}

async function handleAddCmd(message, { args, text }) {
    if (!args || args.length < 1) {
        return await message.reply(
            '⚠️ Uso correcto:\n.addcmd .nombre delcomando @yo hace algo con @text\n\n' +
            'Variables disponibles:\n' +
            '• @yo = tu mención\n' +
            '• @text = mención o texto que escribes (opcional)\n' +
            '• @user = mención obligatoria (debes @ a alguien al usar el comando)\n' +
            '• @random = número aleatorio 0-100\n' +
            '• @randomUser = usuario aleatorio del grupo\n' +
            '• @img=URL = imagen a enviar con el mensaje\n' +
            '• @pr1= @pr2= ... = opciones aleatorias (mínimo 2; aceptan variables como @random, @yo, @text, @randomUser), usa @pr para insertar la elegida\n\n' +
            'Ejemplos:\n' +
            '.addcmd .suerte La suerte de @text es @random%\n' +
            '.addcmd .sorpresa @yo sorprende a @randomUser 🎉\n' +
            '.addcmd .ejemplo Tu tienes: @pr @pr1=@random de aura @pr2=@random de laura\n' +
            '.addcmd .saludar Hola @user cómo estás?\n' +
            '.addcmd .palabrarandom @pr1=hola @pr2=chat @pr3=buenas\n\n' +
            '🤖 O crea uno con IA usando:\n' +
            '.addcmd .ia quiero un comando que sea .felicidad y diga que tengo x% de felicidad'
        );
    }

    // AI Generation Check
    const isIaGeneration = args[0] && /^\.?ia$/i.test(args[0]);
    if (isIaGeneration) {
        const prompt = args.slice(1).join(' ').trim();
        if (!prompt) {
            return await message.reply(
                '⚠️ Debes indicar una descripción de lo que quieres que haga el comando.\n' +
                'Ejemplo: `.addcmd .ia quiero un comando que sea .felicidad y al usarlo diga mi arroba y que tengo x% de felicidad, decoralo bastante.`'
            );
        }

        try {
            await message.reply('⏳ _Generando comando personalizado con IA..._');
        } catch (_) {}

        try {
            const iasPlugin = require('./ias-personalizadas');
            const callIA = iasPlugin.callIA;
            if (typeof callIA !== 'function') {
                return await message.reply('⚠️ El servicio de generación con IA no está disponible en este momento.');
            }

            const systemPrompt = `Eres un asistente experto que diseña comandos personalizados para un bot de WhatsApp.
El usuario describirá el comando que desea crear.
Debes responder UNICAMENTE con un objeto JSON válido (sin explicaciones adicionales fuera del bloque JSON) con la siguiente estructura:
{
  "commandName": ".nombre", // Nombre del comando en minúsculas, comenzando con un punto (solo letras, números y guión bajo).
  "template": "plantilla del comando" // La plantilla del comando.
}

Reglas para el diseño de la plantilla:
1. Puedes usar las siguientes variables para hacer el comando dinámico:
   - @yo : Mención del usuario que ejecuta el comando.
   - @text : Mención o texto opcional que escribe el usuario al usar el comando.
   - @user : Mención obligatoria (el usuario debe mencionar a alguien al usar el comando).
   - @random : Número aleatorio del 0 al 100 (para porcentajes, probabilidad, etc.).
   - @randomUser : Mención de un usuario aleatorio del grupo.
   - @img=URL : Si el usuario pide una imagen, incluye una URL de imagen real o ilustrativa (ej. de imgur, unplash o links directos), o no lo agregues si no se pide.
   - Opciones aleatorias (@pr): Si el usuario quiere respuestas aleatorias múltiples, usa @pr en la plantilla y define al final del texto las opciones como: @pr1=opcion1 @pr2=opcion2 (mínimo 2 opciones).
2. Agrega emojis y decora el texto de manera premium y divertida según lo que el usuario pida.

Ejemplo de respuesta esperada:
\`\`\`json
{
  "commandName": ".felicidad",
  "template": "✨ @yo tiene un @random% de felicidad hoy! 😊🍀"
}
\`\`\``;

            const aiResponse = await callIA(systemPrompt, prompt);
            let jsonStr = aiResponse.trim();
            const match = jsonStr.match(/\{[\s\S]*\}/);
            if (match) {
                jsonStr = match[0];
            }
            const generated = JSON.parse(jsonStr);
            const genName = normalizeCommandName(generated.commandName);
            const genTemplate = normalizeTemplate(generated.template);
            const creator = getCreatorKey(message);

            if (!genName) {
                return await message.reply('⚠️ La IA no pudo generar un nombre de comando válido. Intenta describiendo el comando de forma más clara.');
            }

            if (!isValidCommandName(genName)) {
                return await message.reply(`⚠️ El nombre de comando generado por la IA (.${genName}) no es válido. Debe contener solo letras, números y guion bajo.`);
            }

            // Validar duplicados (con mensaje especial si ya existe)
            if (RESERVED_COMMANDS.includes(genName) || hasOfficialCommand(genName)) {
                return await message.reply(
                    `⚠️ No se pudo crear porque el comando oficial \`.${genName}\` ya existe en el bot.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de comando que no esté en uso.`
                );
            }

            const store = loadStore();
            if (store.commands[genName]) {
                return await message.reply(
                    `⚠️ No se pudo crear porque el comando personalizado \`.${genName}\` ya existe.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de comando que no esté en uso.`
                );
            }

            if (hasIaCommand(genName)) {
                return await message.reply(
                    `⚠️ No se pudo crear porque ya existe una IA personalizada con el nombre \`.${genName}\`.\n` +
                    `Por favor, intenta de nuevo pidiéndole a la IA un nombre diferente de comando que no esté en uso.`
                );
            }

            if (!genTemplate) {
                return await message.reply('⚠️ La IA generó una plantilla vacía. Intenta de nuevo con otra descripción.');
            }

            if (templateHasBase64Image(genTemplate)) {
                return await message.reply('⚠️ La plantilla generada por la IA contiene una imagen en base64 no permitida.');
            }

            const { imageUrl } = extractImageFromTemplate(genTemplate);
            if (imageUrl !== null && !isValidImageUrl(imageUrl)) {
                return await message.reply('⚠️ La URL de imagen generada por la IA no es válida.');
            }

            const { prWords } = extractPrWords(genTemplate);
            const hasPrTags = /@pr\d+=/i.test(genTemplate);
            if (hasPrTags && prWords.length < 2) {
                return await message.reply('⚠️ La plantilla generada por la IA usa @pr pero tiene menos de 2 opciones.');
            }
            if (hasPrTags && !prWordsAreAtEnd(genTemplate)) {
                return await message.reply('⚠️ La plantilla generada por la IA tiene las opciones @pr mal ubicadas (deben estar al final).');
            }

            if (!templateLengthOk(genTemplate)) {
                return await message.reply('⚠️ El comando generado es demasiado largo (máximo 500 caracteres).');
            }

            const userCommandsCount = Object.values(store.commands).filter(cmd => cmd.creator === creator).length;
            if (userCommandsCount >= MAX_COMMANDS_PER_USER) {
                return await message.reply(`⚠️ Has alcanzado el límite de ${MAX_COMMANDS_PER_USER} comandos personalizados.`);
            }

            // Registrar el comando generado
            const displayName = generated.commandName.trim().replace(/^[^a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]+/, '');
            store.commands[genName] = {
                template: genTemplate,
                creator: creator || 'unknown',
                createdAt: Date.now(),
                uses: 0,
                usedBy: [],
                displayName: displayName
            };

            saveStore(store);

            const { cleanTemplate: templateSinImg } = extractImageFromTemplate(genTemplate);
            const { prWords: prPreview } = extractPrWords(templateSinImg);
            const prTag = prPreview.length >= 2 ? `\n🎲 _Palabras random: ${prPreview.join(', ')}_` : '';
            const confirmacion = imageUrl
                ? `✅ Comando creado con éxito usando IA:\n${formatCommandName(genName, displayName)} ${templateSinImg}\n🖼️ _Incluye imagen._${prTag}`
                : `✅ Comando creado con éxito usando IA:\n${formatCommandName(genName, displayName)} ${templateSinImg}${prTag}`;

            return await message.reply(confirmacion);

        } catch (error) {
            console.error('[comandos-personalizados] Error en generación con IA:', error);
            return await message.reply('⚠️ Ocurrió un error al generar el comando con la IA. Inténtalo de nuevo.');
        }
    }

    if (args.length < 2) {
        return await message.reply('⚠️ Debes indicar el mensaje/plantilla que devolverá el comando.');
    }

    const rawCommand = args[0];
    const commandName = normalizeCommandName(rawCommand);
    const template = normalizeTemplate(args.slice(1).join(' '));
    const creator = getCreatorKey(message);
    const creationMentions = getMentionJids(message);

    if (!commandName) {
        return await message.reply('⚠️ Nombre de comando inválido. Debe ser solo letras, números o guion bajo.');
    }

    if (!isValidCommandName(commandName)) {
        return await message.reply('⚠️ El nombre del comando solo puede contener letras, números y guion bajo.');
    }

    if (RESERVED_COMMANDS.includes(commandName)) {
        return await message.reply('⚠️ Ese nombre está reservado. Usa otro nombre para tu comando.');
    }

    if (creationMentions.length > 0) {
        return await message.reply(
            '⚠️ No puedes usar menciones reales al crear el comando. ' +
            'Usa variables como @yo, @text o @randomUser en la plantilla, y menciona a alguien solo cuando ejecutes el comando.'
        );
    }

    if (!template) {
        return await message.reply('⚠️ Debes indicar el mensaje que devolverá el comando.');
    }

    // Rechazar imágenes en base64 (pesan demasiado para guardar en el JSON)
    if (templateHasBase64Image(template)) {
        return await message.reply(
            '⚠️ No se puede usar una imagen en base64 con @img=.\n\n' +
            '📌 Subí la imagen a un hosting gratuito y usá el link directo:\n' +
            '• https://imgbb.com\n' +
            '• https://imgur.com\n\n' +
            'Ejemplo: `.addcmd .meme texto @img=https://i.imgur.com/ejemplo.jpg`'
        );
    }

    // Validar la URL de imagen si se incluye @img=
    const { imageUrl } = extractImageFromTemplate(template);
    if (imageUrl !== null && !isValidImageUrl(imageUrl)) {
        return await message.reply('⚠️ La URL de imagen en @img= no es válida. Debe comenzar con http:// o https://');
    }

    // Validar @pr1=/@pr2=: si se usan, deben ser al menos 2 y estar al final
    const { prWords } = extractPrWords(template);
    const hasPrTags = /@pr\d+=/i.test(template);
    if (hasPrTags && prWords.length < 2) {
        return await message.reply('⚠️ Si usas @pr1=, @pr2=, etc., debes poner al menos *2 opciones* (@pr1= y @pr2= como mínimo).');
    }
    if (hasPrTags && !prWordsAreAtEnd(template)) {
        return await message.reply(
            '⚠️ Las opciones @pr1=, @pr2=, etc. deben ir *al final* del comando, después de todo el texto.\n\n' +
            'Correcto: `.addcmd .cmd El bot dice @pr @pr1=hola a todos @pr2=buenas noches`\n' +
            'Incorrecto: `.addcmd .cmd @pr1=hola a todos texto después @pr2=algo`'
        );
    }

    if (!templateLengthOk(template)) {
        return await message.reply('⚠️ El mensaje no puede tener más de 500 caracteres sin contar los parámetros @yo, @text, @random o @img=URL.');
    }

    const store = loadStore();
    const userCommandsCount = Object.values(store.commands).filter(cmd => cmd.creator === creator).length;

    if (userCommandsCount >= MAX_COMMANDS_PER_USER) {
        return await message.reply(
            `⚠️ Has alcanzado el límite de ${MAX_COMMANDS_PER_USER} comandos personalizados. ` +
            `Elimina uno con .delcmd para poder crear uno nuevo.`
        );
    }

    if (store.commands[commandName]) {
        return await message.reply('⚠️ Ese comando ya existe como comando personalizado. Elige otro nombre.');
    }

    if (hasIaCommand(commandName)) {
        return await message.reply('⚠️ Ese comando ya existe como IA personalizada. Elige otro nombre.');
    }

    if (hasOfficialCommand(commandName)) {
        return await message.reply('⚠️ No puedes crear ese comando porque ya existe como comando oficial del bot.');
    }

    const originalName = rawCommand.trim().replace(/^[^a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ]+/, '');
    store.commands[commandName] = {
        template,
        creator: creator || 'unknown',
        createdAt: Date.now(),
        uses: 0,
        usedBy: [],
        displayName: originalName
    };

    saveStore(store);

    const { cleanTemplate: templateSinImg } = extractImageFromTemplate(template);
    const { prWords: prPreview } = extractPrWords(templateSinImg);
    const prTag = prPreview.length >= 2 ? `\n🎲 _Palabras random: ${prPreview.join(', ')}_` : '';
    const confirmacion = imageUrl
        ? `✅ Comando creado con éxito:\n${formatCommandName(commandName, originalName)} ${templateSinImg}\n🖼️ _Incluye imagen._${prTag}`
        : `✅ Comando creado con éxito:\n${formatCommandName(commandName, originalName)} ${templateSinImg}${prTag}`;

    return await message.reply(confirmacion);
}

async function handleMyCmds(message) {
    const creator = getCreatorKey(message);
    const store = loadStore();
    const ownEntries = Object.entries(store.commands)
        .filter(([_, data]) => data.creator === creator)
        .sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));

    if (!ownEntries.length) {
        return await message.reply('📌 No tienes comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    const ownCount = ownEntries.length;
    const lines = ownEntries.map(([name, data]) => {
        const usageCount = getUniqueUsageCount(data);
        const { imageUrl, cleanTemplate: tplLimpio } = extractImageFromTemplate(data.template);
        const { prWords: prPrev, cleanTemplate: tplFinal } = extractPrWords(tplLimpio);
        const imgTag = imageUrl ? ' 🖼️' : '';
        const prTag = prPrev.length >= 2 ? ` 🎲[${prPrev.join('/')}]` : '';
        return `${formatCommandName(name)}${imgTag}${prTag}\n→ ${tplFinal || tplLimpio || data.template}\n   🔥 Usuarios: ${usageCount}`;
    });

    const header = `📋 *Tus comandos personalizados* — Página 1/1\n` +
        `📊 Total: ${ownCount} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleCmds(message, { args }) {
    const page = Math.max(1, parseInt(args?.[0] || '1', 10) || 1);
    const store = loadStore();
    const allEntries = Object.entries(store.commands);

    if (!allEntries.length) {
        return await message.reply('📌 No hay comandos personalizados guardados. Usa .addcmd para crear uno.');
    }

    // Top ordenado por cantidad de usuarios únicos que usaron el comando (de mayor a menor)
    const ranked = allEntries.sort(([, a], [, b]) => getUniqueUsageCount(b) - getUniqueUsageCount(a));
    const pageSize = 10;
    const total = ranked.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, totalPages);
    const startIndex = (currentPage - 1) * pageSize;
    const pageEntries = ranked.slice(startIndex, startIndex + pageSize);

    const lines = pageEntries.map(([name, data], idx) => {
        const rank = startIndex + idx + 1;
        const ownerName = getCreatorDisplayName(data.creator) || 'Sin apodo';
        const usageCount = getUniqueUsageCount(data);
        const { imageUrl, cleanTemplate: tplLimpio2 } = extractImageFromTemplate(data.template);
        const { prWords: prPrev2, cleanTemplate: tplFinal2 } = extractPrWords(tplLimpio2);
        const imgTag = imageUrl ? ' 🖼️' : '';
        const prTag2 = prPrev2.length >= 2 ? ` 🎲[${prPrev2.join('/')}]` : '';
        return `${rank}. ${formatCommandName(name)}${imgTag}${prTag2} - ${ownerName}\n→ ${tplFinal2 || tplLimpio2 || data.template}\n   🔥 Usuarios: ${usageCount}`;
    });

    const header = `🏆 *Top comandos personalizados* — Página ${currentPage}/${totalPages}\n` +
        `📊 Total: ${total} cmds\n` +
        `─────────────────`;

    return await message.reply(header + '\n' + lines.join('\n\n'));
}

async function handleDelCmd(message, { args }) {
    if (!args || args.length < 1) {
        return await message.reply(
            '⚠️ Uso correcto:\n.delcmd .nombre\n\n' +
            'También podés borrar varios de una:\n.delcmd .nombre1 .nombre2 .nombre3\n\n' +
            'O borrar todos tus comandos:\n.delcmd all'
        );
    }

    const creator = getCreatorKey(message);
    const store = loadStore();

    // Nueva lógica: Verificar si quiere borrar TODOS sus comandos
    const firstArg = args[0].toLowerCase();
    if (['all', 'todo', 'todos'].includes(firstArg)) {
        let deletedCount = 0;

        for (const [cmdName, cmdData] of Object.entries(store.commands)) {
            if (cmdData.creator === creator) {
                delete store.commands[cmdName];
                deletedCount++;
            }
        }

        if (deletedCount > 0) {
            saveStore(store);
            return await message.reply(`✅ Se eliminaron todos tus comandos personalizados (${deletedCount} en total).`);
        } else {
            return await message.reply('⚠️ No tienes comandos personalizados para eliminar.');
        }
    }

    // Lógica normal para eliminar comandos específicos
    const isOwner = creator && botConfig.isOwner(creator);
    const deleted = [];
    const noPermission = [];
    const notFound = [];
    const seen = new Set();

    for (const rawArg of args) {
        const commandName = normalizeCommandName(rawArg);
        if (!commandName || seen.has(commandName)) continue;
        seen.add(commandName);

        const stored = store.commands[commandName];

        if (!stored) {
            notFound.push(commandName);
            continue;
        }

        if (stored.creator !== creator && !isOwner) {
            noPermission.push({ name: commandName, displayName: stored.displayName });
            continue;
        }

        const displayName = stored.displayName || commandName;
        delete store.commands[commandName];
        deleted.push({ name: commandName, displayName });
    }

    if (deleted.length) {
        saveStore(store);
    }

    const lines = [];
    if (deleted.length) {
        lines.push(`✅ Eliminados: ${deleted.map(d => formatCommandName(d.name, d.displayName)).join(', ')}`);
    }
    if (noPermission.length) {
        lines.push(`⚠️ Sin permiso (no sos el creador ni el owner): ${noPermission.map(d => formatCommandName(d.name, d.displayName)).join(', ')}`);
    }
    if (notFound.length) {
        lines.push(`⚠️ No existen: ${notFound.map(formatCommandName).join(', ')}`);
    }
    if (!lines.length) {
        lines.push('⚠️ No se indicó ningún nombre de comando válido.');
    }

    return await message.reply(lines.join('\n'));
}

async function runCustomCommand(message, commandName, argsText, conn) {
    const store = loadStore();
    const stored = store.commands[commandName];
    if (!stored) return false;

    if (hasOfficialCommand(commandName)) {
        delete store.commands[commandName];
        saveStore(store);

        return await message.reply(
            '⚠️ Este comando fue eliminado porque causaba interferencia con un comando oficial del bot.\n' +
            `Puedes crear uno nuevo con otro nombre:\n.addcmd ${formatCommandName(commandName)} ${stored.template}`
        );
    }

    const senderNumber = getCreatorKey(message);
    const senderJid = getSenderJid(message);
    const chatId = message.from || message.key?.remoteJid;
    const isGroup = chatId?.endsWith('@g.us');
    const mentionJids = getMentionJids(message) || [];

    // Extraer imagen del template ANTES de procesar variables
    const { imageUrl, cleanTemplate } = extractImageFromTemplate(stored.template);
    let output = cleanTemplate;

    // Extraer palabras random (pr1=, pr2=, ...)
    const { prWords, cleanTemplate: outputAfterPr } = extractPrWords(output);
    output = outputAfterPr;

    // Sustituir @pr ANTES de evaluar variables (@randomUser, @user, @yo, @random, @text)
    // Esto permite colocar cualquier variable dentro de las opciones @pr1=, @pr2=, etc.
    if (prWords.length >= 2) {
        if (/@pr/i.test(output)) {
            // El usuario puso @pr explícitamente en el texto del template
            output = output.replace(/@pr/gi, () => prWords[Math.floor(Math.random() * prWords.length)]);
        } else {
            // No hay @pr explícito: agregar la opción random al final
            const picked = prWords[Math.floor(Math.random() * prWords.length)];
            output = output.trim() ? output.trim() + ' ' + picked : picked;
        }
    }

    // PRIMERO: Manejar @randomUser (antes de @random para evitar conflicto de regex)
    let randomUserJid = null;
    if (/(@randomUser|@randomuser|@RANDOMUSER)/i.test(output)) {
        if (isGroup && conn) {
            const randomUser = await getRandomGroupUser(conn, chatId, senderJid);
            if (randomUser) {
                randomUserJid = randomUser.jid;
                output = output.replace(/@randomUser/gi, `@${randomUser.number}`);
            } else {
                output = output.replace(/@randomUser/gi, '(sin usuario disponible)');
            }
        } else {
            output = output.replace(/@randomUser/gi, '(solo en grupos)');
        }
    }

    // Manejar @user — mención obligatoria
    let userMentionJid = null;
    if (/@user/i.test(output)) {
        // Buscar la primera mención real en el mensaje
        const firstMention = mentionJids[0] || null;
        if (!firstMention) {
            return await message.reply('⚠️ Este comando requiere que menciones a alguien. Ej: `.palabrarandom @usuario`');
        }
        userMentionJid = firstMention;
        const userNumber = firstMention.split('@')[0].split(':')[0];
        output = output.replace(/@user/gi, `@${userNumber}`);
    }

    // DESPUÉS: Reemplazar otras variables.
    // @random usa una función de reemplazo para generar un número distinto
    // por cada ocurrencia en el template.
    output = output
        .replace(/@yo/gi, senderNumber ? `@${senderNumber}` : '@yo')
        .replace(/@random/gi, () => String(Math.floor(Math.random() * 101)))
        .replace(/@text/gi, argsText || '');

    // ── TRADUCCIÓN: Aplicar traducción si el usuario tiene un idioma configurado ──
    try {
        const translateSystem = require('../translateSystem');
        if (typeof translateSystem.processResponse === 'function') {
            output = await translateSystem.processResponse(output, senderNumber);
        }
    } catch (translateErr) {
        console.error('[comandos-personalizados] Error traduciendo:', translateErr.message);
    }

    // Construir lista de mentions: primero sender, luego random user, luego @user, luego targets mencionados
    const mentions = [];
    if (senderJid) mentions.push(senderJid);
    if (randomUserJid && !mentions.includes(randomUserJid)) mentions.push(randomUserJid);
    if (userMentionJid && !mentions.includes(userMentionJid)) mentions.push(userMentionJid);
    if (Array.isArray(mentionJids)) {
        for (const jid of mentionJids) {
            if (jid && !mentions.includes(jid)) {
                mentions.push(jid);
            }
        }
    }

    // Enviar con imagen si hay @img=URL, o solo texto si no
    if (imageUrl) {
        const sock = conn || message._sock || global.conn;
        if (sock) {
            try {
                await sock.sendMessage(chatId, {
                    image: { url: imageUrl },
                    caption: output,
                    mentions: mentions.length ? mentions : undefined
                });
            } catch (imgError) {
                console.error('[comandos-personalizados] Error enviando imagen:', imgError.message);
                // Fallback: enviar solo texto si la imagen falla
                await message.reply(
                    output + '\n\n⚠️ _No se pudo cargar la imagen._',
                    mentions.length ? { mentions } : undefined
                );
            }
        } else {
            // Sin conexión disponible, enviar solo texto
            await message.reply(
                output,
                mentions.length ? { mentions } : undefined
            );
        }
    } else {
        await message.reply(output, mentions.length ? { mentions } : undefined);
    }

    // Registrar el uso. `uses` sigue siendo el contador histórico total,
    // pero `usedBy` trackea usuarios únicos (un mismo usuario spameando el
    // comando no suma más de una vez al ranking/estadística mostrada).
    if (store.commands[commandName]) {
        store.commands[commandName].uses = Number(store.commands[commandName].uses || 0) + 1;

        if (!Array.isArray(store.commands[commandName].usedBy)) {
            store.commands[commandName].usedBy = [];
        }
        if (senderNumber && !store.commands[commandName].usedBy.includes(senderNumber)) {
            store.commands[commandName].usedBy.push(senderNumber);
        }

        saveStore(store);
    }

    return true;
}

async function textReplyHandler(message) {
    if (!message || typeof message.body !== 'string') return;
    const text = message.body.trim();
    if (!text) return;

    const usedPrefix = PREFIXES.find((prefix) => text.startsWith(prefix));
    if (!usedPrefix) return;

    const commandText = text.slice(usedPrefix.length).trim();
    if (!commandText) return;

    const [rawCommandName, ...args] = commandText.split(' ');
    const commandName = normalizeCommandName(rawCommandName);
    if (!commandName) return;

    const store = loadStore();
    if (!store.commands[commandName]) return;

    const conn = message._sock || global.conn;
    await runCustomCommand(message, commandName, args.join(' '), conn);
}

let handler = async (message, { args, command, text }) => {
    if (/^addcmd$/i.test(command)) {
        return await handleAddCmd(message, { args, text });
    }

    if (/^mycmds$/i.test(command)) {
        return await handleMyCmds(message);
    }

    if (/^cmds$/i.test(command)) {
        return await handleCmds(message, { args });
    }

    if (/^delcmd$/i.test(command)) {
        return await handleDelCmd(message, { args });
    }

    return await message.reply('⚠️ Comando no reconocido. Usa .addcmd, .mycmds, .cmds o .delcmd.');
};

handler.help = ['addcmd .nombre mensaje', 'mycmds', 'cmds [página]', 'delcmd .nombre', 'delcmd all'];
handler.tags = ['fun', 'creador'];
handler.command = /^(addcmd|mycmds|cmds|delcmd)$/i;
handler.textReplyHandler = textReplyHandler;

module.exports = handler;