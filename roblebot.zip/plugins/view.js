/**
 * Plugin: view / ver
 * Abre mensajes view-once (o cualquier media citada) y los reenvía
 * en el mismo chat donde se ejecutó el comando.
 */

const { downloadContentFromMessage, extractMessageContent } = require('@whiskeysockets/baileys');

// ── Helpers ───────────────────────────────────────────────────────────────────

async function streamToBuffer(stream) {
    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

/**
 * Desenvuelve capas anidadas como ephemeralMessage, viewOnceMessage,
 * viewOnceMessageV2, viewOnceMessageV2Extension, etc.
 */
function unwrapMessage(msg) {
    if (!msg) return null;
    let content = extractMessageContent(msg) || msg;

    const wrappers = [
        'viewOnceMessage',
        'viewOnceMessageV2',
        'viewOnceMessageV2Extension',
        'ephemeralMessage',
        'documentWithCaptionMessage',
        'editedMessage'
    ];

    let found = true;
    while (found && content) {
        found = false;
        for (const key of wrappers) {
            if (content[key]?.message) {
                content = content[key].message;
                found = true;
                break;
            }
        }
    }
    return content;
}

/**
 * Busca el contextInfo que contiene el quotedMessage en cualquier
 * tipo de nodo del mensaje entrante.
 */
function getContextInfo(msg) {
    if (!msg) return null;
    const unwrapped = unwrapMessage(msg);
    if (!unwrapped) return null;

    for (const key of Object.keys(unwrapped)) {
        if (unwrapped[key]?.contextInfo?.quotedMessage) {
            return unwrapped[key].contextInfo;
        }
    }
    return null;
}

async function detectQuotedMedia(baileyMsg) {
    try {
        if (!baileyMsg?.message) return null;

        const contextInfo = getContextInfo(baileyMsg.message);
        if (!contextInfo?.quotedMessage) return null;

        // Desenvolver el mensaje citado por completo
        const quoted = unwrapMessage(contextInfo.quotedMessage);
        if (!quoted) return null;

        // Buscar el nodo multimedia (cubre normales, viewOnce envueltos y viewOnce: true directo)
        const mediaMessage =
            quoted.imageMessage ||
            quoted.videoMessage ||
            quoted.stickerMessage ||
            quoted.audioMessage;

        if (!mediaMessage) return null;

        // Verificar que vengan las claves de descarga/descifrado
        if (!mediaMessage.mediaKey && !mediaMessage.directPath && !mediaMessage.url) {
            console.warn('[view] El mensaje citado no contiene mediaKey (restringido por el servidor de WA).');
            return null;
        }

        // Determinar tipo de medio y tipo de descarga para Baileys
        let type, downloadType;
        const mime = mediaMessage.mimetype || '';

        if (quoted.audioMessage || mime.startsWith('audio')) {
            type = 'audio';
            downloadType = 'audio';
        } else if (quoted.videoMessage || mime.startsWith('video') || mediaMessage.gifPlayback) {
            type = mediaMessage.gifPlayback ? 'gif' : 'video';
            downloadType = 'video';
        } else if (quoted.stickerMessage || mime.includes('webp')) {
            type = 'sticker';
            downloadType = 'sticker';
        } else if (quoted.imageMessage || mime.startsWith('image')) {
            type = 'image';
            downloadType = 'image';
        } else {
            return null;
        }

        const stream = await downloadContentFromMessage(mediaMessage, downloadType);
        const buffer = await streamToBuffer(stream);
        return { data: buffer, type, mime };

    } catch (error) {
        console.error('[view] Error detectQuotedMedia:', error.message);
        return null;
    }
}

// ── Handler principal ─────────────────────────────────────────────────────────

let handler = async (message, { conn }) => {
    const sock = conn || message._sock || global.conn;
    // Priorizar _baileyMessage del propio mensaje para evitar race conditions con subbots.
    const baileyMsg = message._baileysMessage
        || message._baileyMessage
        || message.baileysMessage
        || message.baileyMessage
        || message.rawMessage
        || global.lastBaileyMessage;

    if (!baileyMsg) return message.reply('❌ No se encontró el mensaje.');

    const chatId = message.from;
    let media = await detectQuotedMedia(baileyMsg);

    // Fallback si detectQuotedMedia no encontró nada pero existe message.quoted
    if (!media && message.quoted?.download) {
        try {
            const buf = await message.quoted.download();
            if (buf && buf.length > 100) {
                const mime = message.quoted.mimetype || 'image/jpeg';
                const type = mime.includes('video') ? (message.quoted.mtype === 'videoMessage' ? 'video' : 'gif')
                           : mime.includes('audio') ? 'audio'
                           : mime.includes('webp')  ? 'sticker'
                           : 'image';
                media = { data: buf, type, mime };
            }
        } catch (e) {
            console.error('[view fallback] error:', e.message);
        }
    }

    if (!media) {
        return message.reply(
            '❌ Respondé a una imagen, video, audio o mensaje view-once con *.view*'
        );
    }

    try {
        if (media.type === 'image') {
            await sock.sendMessage(chatId, { image: media.data, caption: '' }, { quoted: baileyMsg });

        } else if (media.type === 'sticker') {
            await sock.sendMessage(chatId, { sticker: media.data }, { quoted: baileyMsg });

        } else if (media.type === 'video' || media.type === 'gif') {
            await sock.sendMessage(chatId, {
                video: media.data,
                gifPlayback: media.type === 'gif',
                caption: ''
            }, { quoted: baileyMsg });

        } else if (media.type === 'audio') {
            await sock.sendMessage(chatId, {
                audio: media.data,
                mimetype: media.mime || 'audio/ogg; codecs=opus',
                ptt: true
            }, { quoted: baileyMsg });
        }

    } catch (err) {
        console.error('[view] Error enviando media:', err.message);
        await message.reply('❌ No pude enviar el archivo.');
    }
};

handler.help    = ['view', 'ver'];
handler.tags    = ['herramientas'];
handler.command = /^(view|ver|escrachar)$/i;
handler.group   = false;

module.exports = handler;
