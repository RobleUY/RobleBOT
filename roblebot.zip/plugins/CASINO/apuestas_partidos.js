// ⚽ APUESTAS DE PARTIDOS DE FÚTBOL (datos: API pública de ESPN)
// Sistema "pozo común" (parimutuel): lo apostado por todos forma el pozo y los
// que aciertan se lo reparten en proporción a lo que apostó cada uno.
//   cuota = pozo total / apostado al resultado
//   (cuanto más gente apuesta a un resultado, menor es su cuota)
//
// Archivos que usa (misma carpeta que este plugin, cámbialo en DB_FILE / CACHE_FILE):
//   apuestas_partidos.json        -> partidos, apuestas, resultados
//   apuestas_partidos_cache.json  -> caché de la API de ESPN (compartido por todos)

const fs = require('fs');
const path = require('path');
const https = require('https');
const achievements = require('../../achievements');

// ⚙️ CONFIGURACIÓN
const TZ = 'America/Montevideo';        // zona horaria para mostrar horas y "hoy"
const CACHE_TTL = 60 * 1000;            // segundos que dura el caché de la API
const COOLDOWN_MS = 2000;               // cooldown entre apuestas por usuario
const COMISION = 0;                     // 0 = sin comisión. Ej: 0.05 = 5% del pozo se "quema"
const PAGE_SIZE = 4;                    // partidos por página en .partidos
const MIN_APUESTA = 1;
const DB_FILE = path.join(__dirname, 'apuestas_partidos.json');
const CACHE_FILE = path.join(__dirname, 'apuestas_partidos_cache.json');
const ESPN = 'https://site.api.espn.com/apis/site/v2/sports/soccer';

// 🌍 Ligas filtradas (Solo Sudamérica y Europa principales)
const LEAGUES = {
    // Internacionales / Selecciones
    'fifa.friendly': 'Amistosos Internacionales',
    'fifa.worldq.conmebol': 'Eliminatorias CONMEBOL',
    'fifa.worldq.uefa': 'Eliminatorias UEFA',
    'uefa.nations': 'UEFA Nations League',
    
    // Copas Internacionales de Clubes
    'uefa.champions': 'Champions League',
    'uefa.europa': 'Europa League',
    'uefa.europa.conf': 'Conference League',
    'conmebol.libertadores': 'Copa Libertadores',
    'conmebol.sudamericana': 'Copa Sudamericana',

    // Ligas Top Europa
    'eng.1': 'Premier League',
    'esp.1': 'LaLiga',
    'ita.1': 'Serie A',
    'ger.1': 'Bundesliga',
    'fra.1': 'Ligue 1',
    'por.1': 'Primeira Liga',
    'ned.1': 'Eredivisie',

    // Ligas Top Sudamérica
    'arg.1': 'Liga Argentina',
    'uru.1': 'Liga Uruguaya',
    'bra.1': 'Brasileirão',
    'col.1': 'Liga Colombiana',
    'chi.1': 'Liga Chilena',

    // Copas Nacionales Destacadas
    'esp.copa_del_rey': 'Copa del Rey',
    'eng.fa': 'FA Cup',
    'eng.league_cup': 'Carabao Cup'
};

const CANCEL_STATUSES = ['STATUS_POSTPONED', 'STATUS_CANCELED', 'STATUS_CANCELLED', 'STATUS_ABANDONED'];
const PICK_EMOJI = { '1': '1️⃣', 'X': '❎', '2': '2️⃣' };
const LINE = '┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄';

// ───────────────────────── Persistencia ─────────────────────────
function loadJson(file, fallback) {
    try {
        if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
        console.error(`[PARTIDOS] No se pudo leer ${path.basename(file)}:`, e.message);
    }
    return fallback;
}

function saveJson(file, data, space) {
    try {
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(data, null, space));
        fs.renameSync(tmp, file); // escritura atómica
    } catch (e) {
        console.error(`[PARTIDOS] No se pudo guardar ${path.basename(file)}:`, e.message);
    }
}

let db = loadJson(DB_FILE, null) || {};
db.version = 1;
db.nextId = db.nextId || 1;
db.index = db.index || {};     // "slug:espnId" -> id corto
db.matches = db.matches || {}; // id corto -> partido

let cache = loadJson(CACHE_FILE, null) || { updatedAt: 0, dayKey: '', events: [] };
let inflight = null;
let lastFail = 0;
const cooldowns = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [k, t] of cooldowns.entries()) if (now - t > 60000) cooldowns.delete(k);
}, 5 * 60 * 1000).unref?.();

// ───────────────────────── Utilidades ─────────────────────────
const dateKey = ts => new Date(ts).toLocaleDateString('en-CA', { timeZone: TZ }); // YYYY-MM-DD
const fmtHour = ts => new Date(ts).toLocaleTimeString('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit' });

function fmtDur(ms) {
    if (ms < 60000) return '<1m';
    const m = Math.round(ms / 60000);
    const h = Math.floor(m / 60);
    const mm = m % 60;
    return h ? (mm ? `${h}h ${mm}m` : `${h}h`) : `${m}m`;
}

function fmtNum(n) {
    const abs = Math.abs(n);
    for (const [v, s] of [[1e12, 'T'], [1e9, 'B'], [1e6, 'M']]) {
        if (abs >= v) {
            return (n / v).toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1') + s;
        }
    }
    return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}
const money = n => `$${fmtNum(n)}`;
const short = (s, n = 18) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

function httpGetJson(url, timeout = 8000) {
    return new Promise((resolve, reject) => {
        const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } }, res => {
            if (res.statusCode !== 200) {
                res.resume();
                return reject(new Error('HTTP ' + res.statusCode));
            }
            let body = '';
            res.setEncoding('utf8');
            res.on('data', c => (body += c));
            res.on('end', () => {
                try { resolve(JSON.parse(body)); } catch (e) { reject(e); }
            });
        });
        req.setTimeout(timeout, () => req.destroy(new Error('timeout')));
        req.on('error', reject);
    });
}

// ───────────────────────── ESPN ─────────────────────────
function normalizeComp(event, comp, slug, leagueName) {
    const home = comp.competitors?.find(c => c.homeAway === 'home');
    const away = comp.competitors?.find(c => c.homeAway === 'away');
    if (!home || !away) return null;
    const st = comp.status || event.status || {};
    const type = st.type || {};
    const name = type.name || '';
    const cancelled = CANCEL_STATUSES.includes(name);
    const state = cancelled ? 'cancelled'
        : type.state === 'post' ? 'final'
        : type.state === 'in' ? 'live' : 'pre';
    const start = Date.parse(comp.date || event.date);
    if (isNaN(start)) return null;
    return {
        key: `espn:${event.id}`,
        slug,
        espnId: String(event.id),
        league: leagueName || LEAGUES[slug] || 'Fútbol',
        home: home.team?.displayName || home.team?.name || 'Local',
        away: away.team?.displayName || away.team?.name || 'Visitante',
        start,
        state,
        score: { h: parseInt(home.score) || 0, a: parseInt(away.score) || 0 },
        clock: st.displayClock || '',
        period: st.period || 0
    };
}

async function fetchScoreboard(pathName, day) {
    const data = await httpGetJson(`${ESPN}/${pathName}/scoreboard?dates=${day}&limit=200`, 12000);
    const info = {};
    for (const lg of data.leagues || []) {
        if (lg.uid) info[lg.uid] = { name: lg.name || lg.abbreviation, slug: lg.slug };
    }

    const out = [];
    for (const ev of data.events || []) {
        const comp = ev.competitions?.[0];
        if (!comp) continue;
        const leagueUid = String(ev.uid || '').split('~').slice(0, 2).join('~');
        const li = info[leagueUid] || {};
        const slug = li.slug || (pathName !== 'all' ? pathName : 'all');
        
        // Solo agregar si pertenece a nuestras ligas permitidas
        if (!LEAGUES[slug]) continue;

        const leagueName = li.name || ev.league?.name || ev.league?.abbreviation || LEAGUES[slug];
        const n = normalizeComp(ev, comp, slug, leagueName);
        if (n) out.push(n);
    }
    return out;
}

async function fetchAll() {
    const days = [-1, 0, 1].map(d => dateKey(Date.now() + d * 864e5).replace(/-/g, ''));
    const map = new Map();

    // Consulta específica liga por liga de nuestra lista blanca (LEAGUES)
    const jobs = [];
    for (const slug of Object.keys(LEAGUES)) {
        for (const d of days) jobs.push(fetchScoreboard(slug, d));
    }
    const res = await Promise.allSettled(jobs);
    let ok = 0;
    for (const r of res) {
        if (r.status === 'fulfilled') {
            ok++;
            for (const e of r.value) map.set(e.key, e);
        }
    }
    if (!ok) {
        throw new Error(res.find(r => r.status === 'rejected')?.reason?.message || 'sin respuesta de ESPN');
    }
    return [...map.values()];
}

// ───────────────────────── Lógica de apuestas ─────────────────────────
function pools(m) {
    const p = { '1': 0, 'X': 0, '2': 0 };
    const c = { '1': 0, 'X': 0, '2': 0 };
    for (const b of Object.values(m.bets)) {
        p[b.pick] += b.amount;
        c[b.pick]++;
    }
    return { p, c, total: p['1'] + p.X + p['2'] };
}

function oddsFor(m, pick) {
    const { p, total } = pools(m);
    if (p[pick] <= 0) return null;
    return Math.floor(total * (1 - COMISION)) / p[pick];
}
const oddsText = o => (o ? `x${o.toFixed(2)}` : 'x—');

function settle(m) {
    const { p, c, total } = pools(m);
    let result = null, type, reason = null;
    if (m.state === 'cancelled') {
        type = 'refund';
        reason = 'partido suspendido/cancelado';
    } else {
        result = m.score.h > m.score.a ? '1' : m.score.h < m.score.a ? '2' : 'X';
        if (p[result] === 0) {
            type = 'refund';
            reason = 'nadie acertó el resultado';
        } else {
            type = 'win';
        }
    }
    m.settled = {
        type, result, reason, total,
        pools: p, counts: c,
        net: Math.floor(total * (1 - COMISION)),
        multiplier: type === 'win' ? Math.floor(total * (1 - COMISION)) / p[result] : 1,
        at: Date.now()
    };
}

function payoutFor(m, b) {
    const s = m.settled;
    if (!s) return 0;
    if (s.type === 'refund') return b.amount;
    if (b.pick !== s.result) return 0;
    return Number(BigInt(b.amount) * BigInt(s.net) / BigInt(s.pools[s.result]));
}

function syncDb(events) {
    const now = Date.now();
    const today = dateKey(now);
    const seen = new Set();

    const fresh = events
        .filter(e => !db.index[e.key] && dateKey(e.start) === today)
        .sort((a, b) => a.start - b.start);
    for (const e of fresh) {
        const id = String(db.nextId++);
        db.index[e.key] = id;
        db.matches[id] = {
            id, key: e.key, slug: e.slug, espnId: e.espnId, league: e.league,
            home: e.home, away: e.away, start: e.start, state: e.state,
            score: e.score, clock: e.clock, period: e.period,
            bets: {}, settled: null
        };
    }

    for (const e of events) {
        const m = db.matches[db.index[e.key]];
        if (!m) continue;
        seen.add(e.key);
        if (m.settled) continue;
        m.home = e.home; m.away = e.away; m.league = e.league;
        m.start = e.start; m.state = e.state; m.score = e.score;
        m.clock = e.clock; m.period = e.period;
        if (m.state === 'final' || m.state === 'cancelled') settle(m);
    }
    return seen;
}

async function resolveStale(seen) {
    const now = Date.now();
    const stale = Object.values(db.matches).filter(m =>
        !m.settled && !seen.has(m.key) && Object.keys(m.bets).length && m.start < now - 3 * 3600e3
    ).slice(0, 5);
    for (const m of stale) {
        try {
            const data = await httpGetJson(`${ESPN}/${m.slug}/summary?event=${m.espnId}`);
            const comp = data.header?.competitions?.[0];
            const n = comp && normalizeComp({ id: m.espnId, date: comp.date }, comp, m.slug, m.league);
            if (n) {
                m.state = n.state; m.score = n.score;
                if (m.state === 'final' || m.state === 'cancelled') { settle(m); continue; }
            }
        } catch (e) { /* ignorar */ }
        if (now - m.start > 72 * 3600e3) {
            m.state = 'cancelled';
            settle(m);
        }
    }
}

function pruneDb() {
    const now = Date.now();
    for (const [id, m] of Object.entries(db.matches)) {
        const bets = Object.values(m.bets);
        const unpaid = bets.some(b => !b.paid);
        const age = now - m.start;
        if ((!unpaid && age > 7 * 864e5) || (!bets.length && age > 2 * 864e5)) {
            delete db.matches[id];
            delete db.index[m.key];
        }
    }
}

async function ensureFresh() {
    const now = Date.now();
    if (cache.dayKey === dateKey(now) && now - cache.updatedAt < CACHE_TTL) return;
    if (now - lastFail < 10000) return;
    if (!inflight) {
        inflight = (async () => {
            try {
                const events = await fetchAll();
                cache = { updatedAt: Date.now(), dayKey: dateKey(Date.now()), events };
                saveJson(CACHE_FILE, cache);
                const seen = syncDb(events);
                await resolveStale(seen);
                pruneDb();
                saveJson(DB_FILE, db, 2);
            } catch (e) {
                lastFail = Date.now();
                console.error('[PARTIDOS] Error al actualizar desde ESPN:', e.message);
            } finally {
                inflight = null;
            }
        })();
    }
    return inflight;
}

// ───────────────────────── Parseos ─────────────────────────
function parseAmount(str, balance) {
    const s = String(str).trim().toLowerCase();
    if (['all', 'todo', 'max'].includes(s)) return balance;
    if (s.endsWith('%')) {
        const pct = parseFloat(s.slice(0, -1).replace(',', '.'));
        if (!(pct > 0 && pct <= 100)) return NaN;
        let a = Math.round(balance * pct / 100);
        if (a < 1 && balance > 0) a = 1;
        return a;
    }
    let t = s;
    if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    const mt = t.match(/^(\d+(?:[.,]\d+)?)(k|m|b)?$/);
    if (!mt) return NaN;
    const mult = { k: 1e3, m: 1e6, b: 1e9 }[mt[2]] || 1;
    return Math.floor(parseFloat(mt[1].replace(',', '.')) * mult);
}

function parsePick(str, m) {
    const s = norm(str);
    if (['1', 'local', 'l'].includes(s)) return '1';
    if (['2', 'visitante', 'v'].includes(s)) return '2';
    if (['x', 'empate', 'e', 'draw'].includes(s)) return 'X';
    if (s.length >= 3) {
        const inHome = norm(m.home).includes(s);
        const inAway = norm(m.away).includes(s);
        if (inHome && !inAway) return '1';
        if (inAway && !inHome) return '2';
    }
    return null;
}

const pickName = (m, pick) => (pick === '1' ? m.home : pick === '2' ? m.away : 'Empate');

function estEnd(m) {
    const now = Date.now();
    if (m.state === 'live') {
        const min = parseInt(m.clock);
        if (!isNaN(min)) {
            const rem = Math.max(3, 95 - min) + (m.period === 1 ? 15 : 0);
            return now + rem * 60000;
        }
    }
    return Math.max(m.start + 110 * 60000, now + 3 * 60000);
}

// ───────────────────────── Mensajes ─────────────────────────
function matchBlock(m) {
    const now = Date.now();
    const { c, total } = pools(m);
    const closed = m.state !== 'pre' || now >= m.start;
    const lines = [];
    if (m.state === 'live') {
        lines.push(`*#${m.id}* · 🔴 *EN VIVO* ${m.clock || ''} · *${m.score.h}-${m.score.a}*`);
    } else {
        lines.push(`*#${m.id}* · ⏰ *${fmtHour(m.start)}* _(en ${fmtDur(m.start - now)})_`);
    }
    lines.push(`🏆 _${m.league}_`);
    lines.push(`⚔️ *${short(m.home)}* vs *${short(m.away)}*`);
    lines.push(`1️⃣ ${short(m.home, 16)} ➜ ${c['1']} 👥 · *${oddsText(oddsFor(m, '1'))}*`);
    lines.push(`❎ Empate ➜ ${c.X} 👥 · *${oddsText(oddsFor(m, 'X'))}*`);
    lines.push(`2️⃣ ${short(m.away, 16)} ➜ ${c['2']} 👥 · *${oddsText(oddsFor(m, '2'))}*`);
    lines.push(`💰 Pozo: *${money(total)}*${closed ? ' · 🔒 _cerrado_' : ''}`);
    return lines.join('\n');
}

const HELP =
    '⚽ *APUESTAS DE FÚTBOL* ⚽\n' + LINE + '\n\n' +
    '📋 *Comandos*\n' +
    '▫️ `.partidos` _Partidos de hoy y cuotas_\n' +
    '▫️ `.partidos pag 2` _Siguiente página_\n' +
    '▫️ `.partidos apostar <id> <1/X/2> <monto>`\n' +
    '▫️ `.partidos apuestas` _Tus apuestas_\n' +
    '▫️ `.partidos cobrar` _Cobrar partidos terminados_\n\n' +
    '🎯 *Resultados*\n' +
    '1️⃣ gana local · ❎ empate · 2️⃣ gana visitante\n' +
    '_También puedes escribir el nombre del equipo._\n\n' +
    '💸 *Monto*\n' +
    '`500` · `10%` · `all` · `2k` · `1m`\n\n' +
    '📝 *Ejemplos*\n' +
    '`.partidos apostar 3 1 500`\n' +
    '`.partidos apostar 3 empate 10%`\n\n' +
    '💡 _Pozo común: lo apostado por todos se reparte entre quienes aciertan. Cuanto más gente apuesta a un resultado, menor es su cuota._';

async function cmdList(message, page) {
    const now = Date.now();
    const today = dateKey(now);
    const all = Object.values(db.matches).filter(m => dateKey(m.start) === today);
    const active = all.filter(m => m.state === 'pre' || m.state === 'live').sort((a, b) => a.start - b.start);
    const finished = all.length - active.length;

    if (!active.length) {
        return message.reply(
            '⚽ *PARTIDOS DE HOY*\n' + LINE + '\n\n' +
            '😴 _No quedan partidos de Europa o América por jugar hoy._\n' +
            (finished ? `\n✅ ${finished} finalizado${finished > 1 ? 's' : ''} · usa \`.partidos cobrar\`` : '') +
            (cache.updatedAt ? '' : '\n⚠️ _No se pudo consultar la API de ESPN, intenta en unos segundos._')
        );
    }

    const pages = Math.ceil(active.length / PAGE_SIZE);
    page = Math.min(Math.max(page || 1, 1), pages);
    const slice = active.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
    const dateStr = new Date(now).toLocaleDateString('es-UY', { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long' });

    let out = '⚽ *PARTIDOS DE HOY* ⚽\n' +
        `📅 _${dateStr}_\n` + LINE + '\n\n';
    out += slice.map(matchBlock).join('\n\n' + LINE + '\n\n');
    out += '\n\n' + LINE + '\n';
    out += `📄 Página *${page}/${pages}*` + (page < pages ? ` · \`.partidos pag ${page + 1}\`` : '') + '\n';
    if (finished) out += `✅ ${finished} finalizado${finished > 1 ? 's' : ''} hoy\n`;
    out += '\n🎯 `.partidos apostar <id> <1/X/2> <monto>`\n';
    out += '💡 _Cuota = lo que cobras por cada $1 si aciertas_';
    return message.reply(out);
}

async function cmdBet(message, args, senderNumber) {
    if (args.length < 3) {
        return message.reply(
            '❌ *Faltan datos*\n\n' +
            '📋 *Uso:*\n`.partidos apostar <id> <1/X/2> <monto>`\n\n' +
            '📝 *Ejemplo:*\n`.partidos apostar 3 1 500`'
        );
    }
    const m = db.matches[args[0].replace('#', '')];
    if (!m) return message.reply(`❌ *No existe el partido #${args[0].replace('#', '')}*\n\n_Mira los ids en_ \`.partidos\``);

    if (m.state !== 'pre' || Date.now() >= m.start) {
        return message.reply(
            `🔒 *Apuestas cerradas*\n\n⚔️ *${m.home}* vs *${m.away}*\n_El partido ya comenzó o terminó._`
        );
    }

    const pick = parsePick(args.slice(1, -1).join(' '), m);
    if (!pick) {
        return message.reply(
            '❌ *Resultado inválido*\n\n' +
            `1️⃣ ${short(m.home, 20)}\n❎ Empate\n2️⃣ ${short(m.away, 20)}\n\n` +
            '_Usa 1, X o 2 (o el nombre del equipo)_'
        );
    }

    const ahora = Date.now();
    const last = cooldowns.get(senderNumber) || 0;
    if (ahora - last < COOLDOWN_MS) {
        return message.reply('⏳ *Cooldown activo*\n\n_Espera un par de segundos antes de apostar de nuevo_');
    }

    let user = global.db.getUser(senderNumber);
    if (!user) {
        user = { money: 0, bank: 0, respeto: 0, lastWork: 0, workedHours: 0, totalWorkedHours: 0, totalWorkedTimes: 0 };
        global.db.setUser(senderNumber, user);
    }

    const amount = parseAmount(args[args.length - 1], user.money);
    if (!Number.isSafeInteger(amount) || amount < MIN_APUESTA) {
        return message.reply(
            '❌ *Monto inválido*\n\n' +
            (user.money <= 0 ? '💡 _No tienes dinero. Usa_ `.work`' : '💡 _Ejemplos:_ `500` · `10%` · `all` · `2k`')
        );
    }
    if (amount > user.money) {
        return message.reply(
            '❌ *Saldo insuficiente*\n\n' +
            `💰 *Tu saldo:* ${money(user.money)}\n` +
            `💸 *Intentaste apostar:* ${money(amount)}`
        );
    }

    const existing = m.bets[senderNumber];
    if (existing && existing.pick !== pick) {
        return message.reply(
            '❌ *Ya apostaste en este partido*\n\n' +
            `🎯 Tu pick: ${PICK_EMOJI[existing.pick]} *${pickName(m, existing.pick)}*\n` +
            '_Solo puedes sumar más dinero a ese mismo resultado._'
        );
    }

    user.money -= amount;
    if (existing) {
        existing.amount += amount;
        existing.ts = Date.now();
    } else {
        m.bets[senderNumber] = { pick, amount, ts: Date.now(), paid: false, payout: null };
    }
    cooldowns.set(senderNumber, ahora);
    const achievementMessage = achievements.addAchievementProgress(user, 'betting');
    global.db.setUser(senderNumber, user);
    saveJson(DB_FILE, db, 2);

    const mine = m.bets[senderNumber];
    const odds = oddsFor(m, pick);
    const est = odds ? Math.floor(mine.amount * odds) : mine.amount;

    await message.reply(
        '✅ *APUESTA REGISTRADA*\n' + LINE + '\n' +
        `⚔️ *#${m.id}* ${short(m.home)} vs ${short(m.away)}\n` +
        `🎯 Pick: ${PICK_EMOJI[pick]} *${pickName(m, pick)}*\n` +
        (existing ? `➕ Sumaste: *${money(amount)}*\n💸 Total apostado: *${money(mine.amount)}*\n` : `💸 Apostado: *${money(amount)}*\n`) +
        `📈 Cuota actual: *${oddsText(odds)}*\n` +
        `🏆 Cobro estimado: *${money(est)}*\n` +
        `💵 Saldo: *${money(user.money)}*\n` +
        `⏰ Cierra: *${fmtHour(m.start)}* _(en ${fmtDur(m.start - Date.now())})_\n\n` +
        '💡 _La cuota cambia según lo que apuesten los demás_'
    );
    if (achievementMessage) await message.reply(achievementMessage).catch(() => {});
}

function myMatches(senderNumber) {
    return Object.values(db.matches).filter(m => m.bets[senderNumber]);
}

function statusLine(m, b) {
    const now = Date.now();
    if (!m.settled) {
        return m.state === 'live'
            ? `🔴 En juego ${m.clock || ''} · *${m.score.h}-${m.score.a}*`
            : `⏳ Empieza *${fmtHour(m.start)}* _(en ${fmtDur(Math.max(0, m.start - now))})_`;
    }
    const s = m.settled;
    const payout = payoutFor(m, b);
    const tag = b.paid ? '✅ _cobrado_' : '💰 _por cobrar_';
    if (s.type === 'refund') return `↩️ Reembolso *${money(payout)}* · ${tag}`;
    if (payout > 0) return `🏆 Ganaste *+${money(payout - b.amount)}* (cobro ${money(payout)}) · ${tag}`;
    return `❌ Perdiste *${money(b.amount)}*`;
}

async function cmdMyBets(message, senderNumber) {
    const list = myMatches(senderNumber);
    if (!list.length) {
        return message.reply('📭 *Sin apuestas*\n\n_Aún no apostaste en ningún partido._\n💡 Mira los partidos con `.partidos`');
    }
    list.sort((a, b) => {
        const pa = a.settled ? 1 : 0, pb = b.settled ? 1 : 0;
        if (pa !== pb) return pa - pb;
        return pa ? b.start - a.start : a.start - b.start;
    });
    const MAX = 8;
    let out = '🎟️ *TUS APUESTAS* 🎟️\n' + LINE + '\n\n';
    out += list.slice(0, MAX).map(m => {
        const b = m.bets[senderNumber];
        const score = m.state === 'pre' ? '' : ` · *${m.score.h}-${m.score.a}*`;
        return `*#${m.id}* ⚔️ ${short(m.home, 14)} vs ${short(m.away, 14)}${score}\n` +
            `🎯 ${PICK_EMOJI[b.pick]} *${short(pickName(m, b.pick), 18)}* · ${money(b.amount)}\n` +
            statusLine(m, b);
    }).join('\n\n');
    if (list.length > MAX) out += `\n\n_…y ${list.length - MAX} más antiguas_`;
    const toCollect = list.filter(m => m.settled && !m.bets[senderNumber].paid).length;
    if (toCollect) out += `\n\n💰 *${toCollect}* por cobrar · \`.partidos cobrar\``;
    return message.reply(out);
}

function pendingInfo(pending) {
    if (!pending.length) return '';
    const ends = pending.map(estEnd).sort((a, b) => a - b);
    const now = Date.now();
    let t = `⏳ *Te quedan ${pending.length} partido${pending.length > 1 ? 's' : ''} por cobrar*\n`;
    t += `⏱️ Próximo en terminar: ~*${fmtDur(ends[0] - now)}*\n`;
    if (pending.length > 1) t += `🏁 Último: ~*${fmtDur(ends[ends.length - 1] - now)}*\n`;
    t += '_Tiempos aproximados._';
    return t;
}

async function cmdCollect(message, senderNumber) {
    const list = myMatches(senderNumber);
    if (!list.length) {
        return message.reply('📭 *No tienes apuestas en partidos*\n\n💡 Mira los partidos con `.partidos`');
    }
    const ready = list.filter(m => m.settled && !m.bets[senderNumber].paid).sort((a, b) => a.start - b.start);
    const pending = list.filter(m => !m.settled);

    if (!ready.length) {
        return message.reply(
            '💤 *Nada para cobrar todavía*\n' + LINE + '\n\n' +
            (pending.length ? pendingInfo(pending) : '_Ya cobraste todas tus apuestas._ 🎉')
        );
    }

    let user = global.db.getUser(senderNumber);
    if (!user) {
        user = { money: 0, bank: 0, respeto: 0, lastWork: 0, workedHours: 0, totalWorkedHours: 0, totalWorkedTimes: 0 };
    }

    let totalCobrado = 0, totalApostado = 0;
    const blocks = [];
    for (const m of ready) {
        const b = m.bets[senderNumber];
        const s = m.settled;
        const payout = payoutFor(m, b);
        b.paid = true;
        b.payout = payout;
        totalCobrado += payout;
        totalApostado += b.amount;

        const head = s.type === 'refund' && m.state === 'cancelled' ? '🚫' : '✅';
        const lines = [];
        lines.push(`${head} *#${m.id}* ${short(m.home, 14)} *${m.score.h}-${m.score.a}* ${short(m.away, 14)}`);
        lines.push(`🎯 Tu pick: ${PICK_EMOJI[b.pick]} *${short(pickName(m, b.pick), 18)}* · ${money(b.amount)}`);
        if (s.result) lines.push(`🏁 Resultado: ${PICK_EMOJI[s.result]} *${short(pickName(m, s.result), 18)}*`);
        lines.push(`👥 1️⃣ ${s.counts['1']} · ❎ ${s.counts.X} · 2️⃣ ${s.counts['2']}`);
        lines.push(`💰 Pozo total: *${money(s.total)}*`);
        if (s.type === 'refund') {
            lines.push(`↩️ Reembolso: *${money(payout)}* _(${s.reason})_`);
        } else if (payout > 0) {
            lines.push(`🏆 Cobraste: *${money(payout)}* _(x${s.multiplier.toFixed(2)})_`);
        } else {
            lines.push(`💔 Perdiste: *${money(b.amount)}*`);
        }
        blocks.push(lines.join('\n'));
    }

    user.money += totalCobrado;
    global.db.setUser(senderNumber, user);
    saveJson(DB_FILE, db, 2);

    const neto = totalCobrado - totalApostado;
    let out = '💰 *COBRO DE APUESTAS* 💰\n' + LINE + '\n\n';
    out += blocks.join('\n\n' + LINE + '\n\n');
    out += '\n\n' + LINE + '\n';
    out += `💵 Total cobrado: *${money(totalCobrado)}*\n`;
    out += `📊 Balance: *${neto >= 0 ? '+' : '-'}${money(Math.abs(neto))}*\n`;
    out += `🏦 Saldo: *${money(user.money)}*`;
    if (pending.length) out += '\n\n' + pendingInfo(pending);
    return message.reply(out);
}

// ───────────────────────── Handler ─────────────────────────
let handler = async (message, { text }) => {
    try {
        const chatJid = message?.key?.remoteJid;
        if (chatJid && !chatJid.endsWith('@g.us')) {
            return await message.reply('👥 *Solo en grupos*\n\n_Este comando solo funciona dentro de grupos._');
        }

        const senderJid = message?.key?.participant || chatJid;
        if (!senderJid) {
            console.error('Sender JID no encontrado');
            return await message.reply('❌ No se pudo obtener el remitente del mensaje.');
        }
        const senderNumber = senderJid.split('@')[0];

        const args = (text || '').trim().split(/\s+/).filter(Boolean);
        const sub = (args.shift() || '').toLowerCase();

        if (['ayuda', 'help', 'comandos'].includes(sub)) return await message.reply(HELP);

        await ensureFresh();

        if (!sub || ['lista', 'hoy'].includes(sub)) return await cmdList(message, 1);
        if (/^\d+$/.test(sub)) return await cmdList(message, parseInt(sub));
        if (['pag', 'pagina', 'página', 'p'].includes(sub)) return await cmdList(message, parseInt(args[0]) || 1);
        if (['apostar', 'bet', 'apuesta'].includes(sub)) return await cmdBet(message, args, senderNumber);
        if (['cobrar', 'claim', 'cobro'].includes(sub)) return await cmdCollect(message, senderNumber);
        if (['bets', 'apuestas', 'mis', 'misapuestas'].includes(sub)) return await cmdMyBets(message, senderNumber);

        return await message.reply(HELP);
    } catch (error) {
        console.error('\x1b[31m[ERROR] Error en .partidos:', error, '\x1b[0m');
        return await message.reply('❌ *Error*\n\n_Ocurrió un error al procesar el comando._');
    }
};

handler.help = ['partidos', 'partidos apostar <id> <1/X/2> <monto/%/all>', 'partidos apuestas', 'partidos cobrar'];
handler.tags = ['economy'];
handler.command = /^(partidos?|futbol)$/i;

module.exports = handler;
handler.group = true;
handler.apodo = true;