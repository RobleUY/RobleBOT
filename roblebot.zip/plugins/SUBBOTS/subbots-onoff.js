'use strict';

const fs   = require('fs');
const path = require('path');
const chatCleanScheduler = require('./chat-clean-scheduler');
const chatTracker         = require('./chat-tracker');

// ── Directorio de datos ──────────────────────────────────────────────────────
const DATA_DIR      = path.join(__dirname, 'data');
const ONOFF_FILE    = path.join(DATA_DIR, 'subbot-onoff.json');
const RESPONDER_FILE = path.join(DATA_DIR, 'subbot-responder.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Archivo de datos legado (mybot-on-off.json) para migración ───────────────
const LEGACY_FILE = path.join(__dirname, '..', 'GRUPOS', 'mybot-on-off.json');

// Caché en memoria para evitar I/O masivo síncrono en cada mensaje (0ms latency)
let _onoffCache = null;
let _onoffCacheTime = 0;
const CACHE_TTL_MS = 30000;

function loadOnOff() {
    const now = Date.now();
    if (_onoffCache && (now - _onoffCacheTime < CACHE_TTL_MS)) {
        return _onoffCache;
    }
    try {
        if (fs.existsSync(ONOFF_FILE)) {
            _onoffCache = JSON.parse(fs.readFileSync(ONOFF_FILE, 'utf8'));
            _onoffCacheTime = now;
            return _onoffCache;
        }
    } catch (e) {
        console.error('[subbots-onoff] Error cargando onoff.json:', e.message);
    }
    _onoffCache = _onoffCache || {};
    _onoffCacheTime = now;
    return _onoffCache;
}

function saveOnOff(data) {
    try {
        _onoffCache = data;
        _onoffCacheTime = Date.now();
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando onoff.json:', e.message);
        return false;
    }
}

let _responderCache = null;
let _responderCacheTime = 0;

function loadResponder() {
    const now = Date.now();
    if (_responderCache && (now - _responderCacheTime < CACHE_TTL_MS)) {
        return _responderCache;
    }
    try {
        if (fs.existsSync(RESPONDER_FILE)) {
            _responderCache = JSON.parse(fs.readFileSync(RESPONDER_FILE, 'utf8'));
            _responderCacheTime = now;
            return _responderCache;
        }
    } catch (e) {
        console.error('[subbots-onoff] Error cargando responder.json:', e.message);
    }
    _responderCache = _responderCache || {};
    _responderCacheTime = now;
    return _responderCache;
}

function saveResponder(data) {
    try {
        _responderCache = data;
        _responderCacheTime = Date.now();
        fs.writeFileSync(RESPONDER_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('[subbots-onoff] Error guardando responder.json:', e.message);
        return false;
    }
}

// ── Migración del archivo legado mybot-on-off.json ───────────────────────────
// Se ejecuta una sola vez si el archivo nuevo aún no existe pero el viejo sí.
(function migrateLegacy() {
    try {
        if (fs.existsSync(ONOFF_FILE)) return;             // ya migrado
        if (!fs.existsSync(LEGACY_FILE)) return;           // no hay legado
        const old = JSON.parse(fs.readFileSync(LEGACY_FILE, 'utf8'));
        const nuevo = {};
        for (const [key, val] of Object.entries(old)) {
            // Formato viejo: "groupId_botNum" → nuevo: "chat_groupId_botNum"
            if (val === false) {
                nuevo[`chat_${key}`] = false;
            }
        }
        fs.writeFileSync(ONOFF_FILE, JSON.stringify(nuevo, null, 2), 'utf8');
        console.log('[subbots-onoff] ✅ Migración de mybot-on-off.json completada.');
    } catch (e) {
        console.error('[subbots-onoff] Error en migración legado:', e.message);
    }
})();

// ── Helpers de limpieza de JID y Bot ID ──────────────────────────────────────
function getCleanJidKeys(chatJid) {
    if (!chatJid) return { raw: '', digits: '' };
    const raw = String(chatJid).split('@')[0].split(':')[0].trim();
    const digits = raw.replace(/\D/g, '');
    return { raw, digits };
}

function getCleanBotNum(botNum) {
    if (botNum === null || botNum === undefined) return 'main';
    const str = String(botNum).trim();
    if (str.toLowerCase() === 'main' || str === '') return 'main';
    const digits = str.replace(/\D/g, '');
    return digits || str;
}

// ── Funciones públicas (usadas por handler.js) ───────────────────────────────

/**
 * Verifica si el subbot o bot principal está habilitado en un chat específico.
 * Prioridad: excepción local explícita > estado global > estado local apagado
 */
function isSubBotEnabled(chatJid, botNum) {
    if (!chatJid) return true;
    const data        = loadOnOff();
    const { raw, digits } = getCleanJidKeys(chatJid);
    const cleanBotNum = getCleanBotNum(botNum);

    const localKeyRaw    = `chat_${raw}_${cleanBotNum}`;
    const localKeyDigits = `chat_${digits}_${cleanBotNum}`;
    const globalKey      = `global_${cleanBotNum}`;

    // Excepción local explícita: si el chat tiene activación manual (=== true)
    if (data[localKeyRaw] === true || (digits && data[localKeyDigits] === true)) return true;

    // Apagado global del bot/subbot
    if (data[globalKey] === false) return false;

    // Apagado local en este chat
    if (data[localKeyRaw] === false || (digits && data[localKeyDigits] === false)) return false;

    return true;
}

/**
 * Devuelve true SOLO si hay una entrada explícita === true en el JSON para este chat+subbot.
 * Diferencia clave vs isSubBotEnabled: NO devuelve true por defecto.
 * Usado por handler.js para saber si hay una excepción manual que bypass el .bots off del grupo.
 */
function isSubBotExplicitlyEnabled(chatJid, botNum) {
    if (!chatJid) return false;
    const data        = loadOnOff();
    const { raw, digits } = getCleanJidKeys(chatJid);
    const cleanBotNum = getCleanBotNum(botNum);

    const localKeyRaw    = `chat_${raw}_${cleanBotNum}`;
    const localKeyDigits = `chat_${digits}_${cleanBotNum}`;

    return data[localKeyRaw] === true || (digits && digits !== raw && data[localKeyDigits] === true);
}

/**
 * Verifica si el subbot responde en chats privados.
 * Default: true
 */
function isSubBotRespondsInPriv(botNum) {
    const cleanBotNum = getCleanBotNum(botNum);
    const data   = loadResponder();
    const config = data[cleanBotNum];
    return !config || config.priv !== false;
}

/**
 * Verifica si el subbot responde en grupos.
 * Default: true
 */
function isSubBotRespondsInGrupos(botNum) {
    const cleanBotNum = getCleanBotNum(botNum);
    const data   = loadResponder();
    const config = data[cleanBotNum];
    return !config || config.grupos !== false;
}

/**
 * Verifica si el subbot tiene permitido el contenido NSFW.
 * Default: true
 */
function isSubBotNsfwEnabled(botNum) {
    const cleanBotNum = getCleanBotNum(botNum);
    const data   = loadResponder();
    const config = data[cleanBotNum];
    return !config || config.nsfw !== false;
}

// ── Helper: verificar owner del subbot o owner principal ────────────────────
function isBotOwner(message, sock) {
    if (message.key?.fromMe) return true;
    const senderNum = (message.sender || '').split('@')[0].split(':')[0];
    const ownerNum  = (sock?._ownerJid || '').split('@')[0].split(':')[0];
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return senderNum && ownerNum && senderNum === ownerNum;
}

// ── Helper: verificar si es el owner principal del config.js ────────────────
function isMainOwner(message) {
    const senderNum = (message.sender || message.author || '').split('@')[0].split(':')[0];
    try {
        const botConfig = global.botConfig || require('../../config');
        if (botConfig && typeof botConfig.isOwner === 'function' && botConfig.isOwner(senderNum)) return true;
    } catch (e) {}
    return false;
}


// ── Handler principal: .bot ──────────────────────────────────────────────────
const botHandler = async (message, { conn } = {}) => {
    try {
        const sock    = message._sock || conn;
        const chatId  = message.from || message.key?.remoteJid;
        const rawBody = message.body || '';
        const allArgs = rawBody.split(/\s+/).slice(1);

        // ── Detección silenciosa de ID específico (solo owner principal) ──────
        // Si el último arg es un número >= 4 dígitos y quien escribe es owner
        // de config.js, opera sobre ese subbot sin avisar a nadie.
        let targetBotNum = message._subNum || sock?._subNum || 'main';
        let args = [...allArgs];

        if (isMainOwner(message) && args.length >= 2) {
            const lastArg = args[args.length - 1];
            if (/^\d{4,}$/.test(lastArg)) {
                targetBotNum = parseInt(lastArg, 10);
                args = args.slice(0, -1); // quitar el ID
            }
        }

        const botNum = getCleanBotNum(targetBotNum);

        // Solo el dueño del bot o el owner principal pueden usarlo
        if (!isBotOwner(message, sock) && !isMainOwner(message)) return;

        const sub1 = (args[0] || '').toLowerCase();
        const sub2 = (args[1] || '').toLowerCase();
        const isMain = botNum === 'main';
        const botLabel = isMain ? 'Bot Principal' : `Sub-Bot #${botNum}`;

        // ── Sin argumentos → mostrar estado ──────────────────────────────────
        if (!sub1) {
            const onoffData = loadOnOff();
            const respData  = loadResponder();
            const { raw, digits } = getCleanJidKeys(chatId);
            const globalOff    = onoffData[`global_${botNum}`] === false;
            const localVal     = onoffData[`chat_${raw}_${botNum}`] ?? (digits ? onoffData[`chat_${digits}_${botNum}`] : undefined);
            const localOff     = localVal === false;
            const localExcept  = localVal === true;   // excepción activa (on mientras global off)
            const resp         = respData[botNum] || {};
            const privOk       = resp.priv !== false;
            const grupoOk      = resp.grupos !== false;
            const nsfwOk       = resp.nsfw !== false;

            // Estado efectivo real en este chat
            const effectiveOn  = localExcept || (!globalOff && !localOff);

            let txt  = `🤖 *Estado del ${botLabel}*\n\n`;
            txt += `🌐 *Global:*     ${globalOff ? '❌ Apagado' : '✅ Encendido'}\n`;
            if (localExcept) {
                txt += `💬 *Este chat:*  ✅ Encendido _(excepción al global apagado)_\n`;
            } else {
                txt += `💬 *Este chat:*  ${localOff ? '❌ Apagado manualmente' : '✅ Normal'}\n`;
            }
            txt += `⚡ *Efectivo:*    ${effectiveOn ? '✅ Responde aquí' : '❌ No responde aquí'}\n`;
            txt += `📱 *Privados:*   ${privOk    ? '✅ Responde'   : '❌ No responde'}\n`;
            txt += `👥 *Grupos:*     ${grupoOk   ? '✅ Responde'   : '❌ No responde'}\n`;
            txt += `🔞 *NSFW:*       ${nsfwOk    ? '✅ Permitido'  : '❌ Desactivado'}\n\n`;
            txt += `💡 *Comandos disponibles:*\n`;
            txt += `  • *.bot apagar* → solo este chat\n`;
            txt += `  • *.bot apagar global* → todos los chats\n`;
            txt += `  • *.bot encender* → solo este chat\n`;
            txt += `  • *.bot encender global* → todos los chats\n`;
            txt += `  • *.bot priv on/off* → responder en privados\n`;
            txt += `  • *.bot grupo on/off* → responder en grupos\n`;
            txt += `  • *.bot nsfw on/off* → permitir/desactivar NSFW\n`;
            txt += `  • *.bot chatclean <tiempo> [all]* → borrado auto de chats (ej: 10m all)\n`;
            txt += `  • *.bot chatclean off [all]* → desactivar borrado auto`;
            return await message.reply(txt);
        }

        // ── .bot priv / privado / private ────────────────────────────────────
        if (['priv', 'privado', 'private'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot priv on* o *.bot priv off*');
            }

            const data = loadResponder();
            if (!data[botNum]) data[botNum] = { priv: true, grupos: true };
            data[botNum].priv = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *${botLabel}*\n\n`;
                msg += `El bot ${verb} en chats privados.\n\n`;
                msg += `💡 Para revertir: *.bot priv ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot grupo / grupos / group / groups ──────────────────────────────
        if (['grupo', 'grupos', 'group', 'groups'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar'].includes(sub2);

            if (!enable && !disable) {
                return await message.reply('⚠️ Uso: *.bot grupo on* o *.bot grupo off*');
            }

            const data = loadResponder();
            if (!data[botNum]) data[botNum] = { priv: true, grupos: true };
            data[botNum].grupos = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const verb = enable ? 'ahora responde' : 'ya no responde';
                let msg = `${icon} *${botLabel}*\n\n`;
                msg += `El bot ${verb} en grupos.\n\n`;
                msg += `💡 Para revertir: *.bot grupo ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot nsfw / adulto / adultos ─────────────────────────────────────
        if (['nsfw', 'adulto', 'adultos'].includes(sub1)) {
            const enable  = ['on', 'si', 'sí', 'encender', 'activar', 'enable'].includes(sub2);
            const disable = ['off', 'no', 'apagar', 'desactivar', 'disable'].includes(sub2);

            if (!enable && !disable) {
                const data = loadResponder();
                const isNsfwOn = !data[botNum] || data[botNum].nsfw !== false;
                return await message.reply(
                    `🔞 *${botLabel} - Contenido NSFW*\n\n` +
                    `Estado actual: ${isNsfwOn ? '✅ Permitido' : '❌ Desactivado'}\n\n` +
                    `💡 Uso: *.bot nsfw on* o *.bot nsfw off*`
                );
            }

            const data = loadResponder();
            if (!data[botNum]) data[botNum] = { priv: true, grupos: true, nsfw: true };
            data[botNum].nsfw = enable;

            if (saveResponder(data)) {
                const icon = enable ? '✅' : '❌';
                const statusText = enable ? 'permitido' : 'desactivado (bloqueado)';
                let msg = `${icon} *${botLabel}*\n\n`;
                msg += `El contenido NSFW ahora está *${statusText}* en este bot.\n\n`;
                if (!enable) {
                    msg += `ℹ️ _Aunque un administrador active NSFW en un grupo (.nsfw on), este bot no enviará contenido NSFW._\n\n`;
                }
                msg += `💡 Para cambiar: *.bot nsfw ${enable ? 'off' : 'on'}*`;
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
            return;
        }

        // ── .bot chatclean / limpiarchat / autoclean ──────────────────────────
        if (['chatclean', 'limpiarchat', 'cleanchat', 'autoclean', 'borrarchatauto'].includes(sub1)) {
            const isAll = args.some((arg, idx) => idx >= 1 && arg.toLowerCase() === 'all');
            const actionArg = args.find((arg, idx) => idx >= 1 && arg.toLowerCase() !== 'all') || '';
            const actionLower = actionArg.toLowerCase();
            const disable = ['off', 'no', 'apagar', 'desactivar', 'cancel', '0'].includes(actionLower);

            if (disable) {
                const res = chatCleanScheduler.disableChatClean(botNum, chatId, isAll);
                if (res.disabled) {
                    const scopeText = isAll ? 'todos los chats del bot' : 'este chat';
                    return await message.reply(`❌ *${botLabel}*\n\nLimpieza automática desactivada para *${scopeText}*.`);
                } else {
                    const scopeText = isAll ? 'todos los chats' : 'este chat';
                    return await message.reply(`⚠️ No había ninguna limpieza automática activa para *${scopeText}*.`);
                }
            }

            if (!actionArg) {
                // Mostrar estado actual de chatclean
                const st = chatCleanScheduler.getChatCleanStatus(botNum, chatId);
                let msg  = `🧹 *Limpieza Automática de Chats (${botLabel})*\n\n`;
                msg += `🌐 *Todos los chats:* ${st.all ? `✅ Cada ${st.all.intervalStr}` : '❌ Desactivado'}\n`;
                msg += `💬 *Este chat:*      ${st.chat ? `✅ Cada ${st.chat.intervalStr}` : '❌ Desactivado'}\n\n`;
                msg += `💡 *Uso del comando:*\n`;
                msg += `  • *.bot chatclean 10m all* → borrar todos sus chats cada 10 min\n`;
                msg += `  • *.bot chatclean 15m* → borrar solo este chat cada 15 min\n`;
                msg += `  • *.bot chatclean off [all]* → desactivar limpieza programada\n\n`;
                msg += `⏱️ _El tiempo mínimo es de 10 minutos (10m)._`;
                return await message.reply(msg);
            }

            // Programar nueva limpieza
            const res = chatCleanScheduler.setChatClean(botNum, chatId, actionArg, isAll);
            if (!res.ok) {
                return await message.reply(res.error || '❌ Error al configurar la limpieza automática.');
            }

            const scopeText = isAll ? 'TODOS los chats del bot' : 'ESTE chat';
            let msg  = `✅ *Limpieza Automática Activada (${botLabel})*\n\n`;
            msg += `📱 *Alcance:* ${scopeText}\n`;
            msg += `⏱️ *Frecuencia:* Cada ${res.intervalStr}\n\n`;
            msg += `💡 Para desactivar: *.bot chatclean off ${isAll ? 'all' : ''}*`;
            return await message.reply(msg);
        }

        // ── .bot on / off / encender / apagar [global / g] ───────────────────
        const isOn  = ['on', 'encender', 'activar'].includes(sub1);
        const isOff = ['off', 'apagar', 'desactivar'].includes(sub1);

        if (!isOn && !isOff) {
            return await message.reply(
                '⚠️ *Uso del comando .bot:*\n\n' +
                '  *.bot apagar* — solo este chat\n' +
                '  *.bot apagar global* — todos los chats\n' +
                '  *.bot encender* — solo este chat\n' +
                '  *.bot encender global* — todos los chats\n' +
                '  *.bot priv on/off* — responder en privados\n' +
                '  *.bot grupo on/off* — responder en grupos\n' +
                '  *.bot nsfw on/off* — permitir/desactivar NSFW\n' +
                '  *.bot chatclean <tiempo> [all]* — borrado auto de chats (ej: 10m all)\n' +
                '  *.bot chatclean off [all]* — desactivar borrado auto'
            );
        }

        const isGlobal = ['global', 'g'].includes(sub2);
        const { raw, digits } = getCleanJidKeys(chatId);
        const data     = loadOnOff();

        if (isGlobal) {
            // ── Acción global ─────────────────────────────────────────────────
            if (isOn) {
                delete data[`global_${botNum}`];
                // Al encender globalmente, limpiar también las excepciones locales
                // activas (=== true) ya que ya no son necesarias.
                // Los chats apagados manualmente (=== false) se conservan.
                for (const k of Object.keys(data)) {
                    if (data[k] === true && k.startsWith('chat_') && k.endsWith(`_${botNum}`)) {
                        delete data[k];
                    }
                }
            } else {
                data[`global_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    msg  = `✅ *${botLabel} encendido globalmente*\n\n`;
                    msg += `El bot responde en todos los chats nuevamente.\n\n`;
                    msg += `ℹ️ _Los chats que desactivaste manualmente siguen apagados._\n`;
                    msg += `💡 Para reactivarlos, enviá *.bot encender* en cada uno.`;
                } else {
                    msg  = `❌ *${botLabel} apagado globalmente*\n\n`;
                    msg += `El bot dejó de responder en todos los chats.\n\n`;
                    msg += `💡 Para encenderlo solo aquí: *.bot encender*\n`;
                    msg += `💡 Para encender en todos lados: *.bot encender global*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }

        } else {
            // ── Acción local (solo este chat) ─────────────────────────────────
            const globalOff = data[`global_${botNum}`] === false;

            if (isOn) {
                // Forzar explícitamente data[localKey] = true para garantizar encendido
                // incluso si el grupo o ajuste global estaban en off.
                data[`chat_${raw}_${botNum}`] = true;
                if (digits && digits !== raw) data[`chat_${digits}_${botNum}`] = true;
            } else {
                data[`chat_${raw}_${botNum}`] = false;
                if (digits && digits !== raw) data[`chat_${digits}_${botNum}`] = false;
            }

            if (saveOnOff(data)) {
                let msg;
                if (isOn) {
                    if (globalOff) {
                        msg  = `✅ *${botLabel} encendido en este chat*\n\n`;
                        msg += `⚠️ _El bot está apagado globalmente, pero responderá como excepción en este chat._\n\n`;
                        msg += `💡 Para encender en todos lados: *.bot encender global*`;
                    } else {
                        msg  = `✅ *${botLabel} encendido en este chat*\n\n`;
                        msg += `El bot vuelve a responder aquí.\n\n`;
                        msg += `💡 Para apagar en todos lados: *.bot apagar global*`;
                    }
                } else {
                    msg  = `❌ *${botLabel} apagado en este chat*\n\n`;
                    msg += `Este chat quedó desactivado únicamente.\n`;
                    msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
                    msg += `💡 Para volver a activarlo aquí: *.bot encender*`;
                }
                await message.reply(msg);
            } else {
                await message.reply('❌ Error al guardar la configuración.');
            }
        }

    } catch (error) {
        console.error('[subbots-onoff] Error en .bot:', error.message);
    }
};

botHandler.help    = ['bot'];
botHandler.tags    = ['subbots'];
botHandler.command = /^bot$/i;

// ── Alias: .onmybot (compatibilidad veteranos) ───────────────────────────────
const onmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = getCleanBotNum(message._subNum || sock?._subNum || 'main');
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const { raw } = getCleanJidKeys(chatId);
        const data     = loadOnOff();
        delete data[`chat_${raw}_${botNum}`];

        if (saveOnOff(data)) {
            const isMain = botNum === 'main';
            const botLabel = isMain ? 'Bot Principal' : `Sub-Bot #${botNum}`;
            let msg  = `✅ *${botLabel} encendido en este chat*\n\n`;
            msg += `💡 Para apagar aquí: *.bot apagar* o *.offmybot*\n`;
            msg += `💡 Para apagar globalmente: *.bot apagar global*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en onmybot:', e.message);
    }
};
onmybotHandler.help    = ['onmybot'];
onmybotHandler.tags    = ['subbots'];
onmybotHandler.command = /^onmybot$/i;

// ── Alias: .offmybot (compatibilidad veteranos) ──────────────────────────────
const offmybotHandler = async (message, { conn } = {}) => {
    try {
        const sock   = message._sock || conn;
        const botNum = getCleanBotNum(message._subNum || sock?._subNum || 'main');
        if (!isBotOwner(message, sock)) return;

        const chatId   = message.from || message.key?.remoteJid;
        const { raw } = getCleanJidKeys(chatId);
        const data     = loadOnOff();
        data[`chat_${raw}_${botNum}`] = false;

        if (saveOnOff(data)) {
            const isMain = botNum === 'main';
            const botLabel = isMain ? 'Bot Principal' : `Sub-Bot #${botNum}`;
            let msg  = `❌ *${botLabel} apagado en este chat*\n\n`;
            msg += `Este chat quedó desactivado únicamente.\n`;
            msg += `Para apagar el bot en todos lados usá: *.bot apagar global*\n\n`;
            msg += `💡 Para volver a activarlo: *.bot encender* o *.onmybot*`;
            await message.reply(msg);
        } else {
            await message.reply('❌ Error al guardar la configuración.');
        }
    } catch (e) {
        console.error('[subbots-onoff] Error en offmybot:', e.message);
    }
};
offmybotHandler.help    = ['offmybot'];
offmybotHandler.tags    = ['subbots'];
offmybotHandler.command = /^offmybot$/i;

// ── Limpieza al eliminar un subbot ───────────────────────────────────────────

/**
 * Elimina todas las entradas de configuración de un subbot dado su número.
 * Debe llamarse cuando la sesión del subbot es borrada definitivamente.
 * Limpia: subbot-onoff.json (global_N y chat_*_N) y subbot-responder.json (N).
 */
function cleanupSubBot(botNum) {
    const key = getCleanBotNum(botNum);

    // ── subbot-onoff.json ─────────────────────────────────────────────────────
    try {
        const onoff = loadOnOff();
        let changed = false;
        for (const k of Object.keys(onoff)) {
            // global_<num>  o  chat_<jid>_<num>
            if (k === `global_${key}` || k.endsWith(`_${key}`)) {
                delete onoff[k];
                changed = true;
            }
        }
        if (changed) {
            saveOnOff(onoff);
            console.log(`[subbots-onoff] 🗑️ Configuración on/off eliminada para subbot #${botNum}`);
        }
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando onoff de #${botNum}:`, e.message);
    }

    // ── subbot-responder.json ─────────────────────────────────────────────────
    try {
        const resp = loadResponder();
        if (resp[key] !== undefined) {
            delete resp[key];
            saveResponder(resp);
            console.log(`[subbots-onoff] 🗑️ Configuración responder eliminada para subbot #${botNum}`);
        }
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando responder de #${botNum}:`, e.message);
    }

    // ── known-chats.json ──────────────────────────────────────────────────────
    try {
        chatTracker.clearTrackedChats(key);
        console.log(`[subbots-onoff] 🗑️ Registros de chats conocidos eliminados para subbot #${botNum}`);
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando chats conocidos de #${botNum}:`, e.message);
    }

    // ── subbot-chatclean.json ─────────────────────────────────────────────────
    try {
        chatCleanScheduler.clearSubBotChatClean(key);
        console.log(`[subbots-onoff] 🗑️ Programaciones de chatclean eliminadas para subbot #${botNum}`);
    } catch (e) {
        console.error(`[subbots-onoff] Error limpiando chatclean de #${botNum}:`, e.message);
    }
}

// ── Exports ──────────────────────────────────────────────────────────────────
module.exports                      = botHandler;
module.exports.onmybotAlias         = onmybotHandler;   // cargado por el plugin loader
module.exports.offmybotAlias        = offmybotHandler;  // cargado por el plugin loader
module.exports.isSubBotEnabled          = isSubBotEnabled;
module.exports.isSubBotExplicitlyEnabled = isSubBotExplicitlyEnabled;
module.exports.isSubBotRespondsInPriv   = isSubBotRespondsInPriv;
module.exports.isSubBotRespondsInGrupos = isSubBotRespondsInGrupos;
module.exports.isSubBotNsfwEnabled  = isSubBotNsfwEnabled;
module.exports.cleanupSubBot        = cleanupSubBot;

