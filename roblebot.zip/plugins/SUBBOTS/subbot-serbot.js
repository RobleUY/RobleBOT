'use strict';

const {
    default: makeWASocket,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');
const { useSQLiteAuthState, closeAuthDb } = require('./singleFileAuthState');
const fs     = require('fs');
const path   = require('path');
const P      = require('pino');
const qrcode = require('qrcode');
const { isBorradosEnabled } = require(path.join(__dirname, '..', 'HERRAMIENTAS', 'GRUPOS', 'borrados'));
const { shouldIgnoreFromMePrivateMessage, getMessageText, createCompatibleMessage } = require('../../messageUtils');
const { attachGroupCacheToSocket, getGroupMetadataCached } = require('../../lib/groupCache');

// ── IMPORTAR MÓDULO DE BIENVENIDAS ──
const welcomeGoodbyeModule = require('../../plugins/HERRAMIENTAS/bienvenida-despedida');

// ── IMPORTAR SISTEMA DE TRACKING DE ACTIVIDAD ──
const activityTracker = require('./subbotActivityTracker');
const { cleanupSubBot } = require('./subbots-onoff');
const { cleanupSubbotActivity } = activityTracker;
const chatTracker = require('./chat-tracker');
const chatCleanScheduler = require('./chat-clean-scheduler');
const subbotCoordinator = require('../../lib/subbotCoordinator');
const chatHistory = require('../../chatHistory');

const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

if (!global.subConns) global.subConns = [];

const OFFICIAL_GROUP       = 'Z120363203689229697@g.us'; // Desactivado temporalmente con Z
// Lista de grupos especiales donde TODOS los subbots funcionan siempre (incluso si están apagados)
const SPECIAL_SUBBOT_GROUPS = [
    '120363410569220249@g.us',  // Grupo especial original
    '120363203689229697@g.us'   // Grupo oficial agregado aquí
];
const GOFC_SUBBOTS_FILE    = path.join(__dirname, 'data', 'gofc-subbots.json');

/**
 * Devuelve true si el subbot (por su _subNum) está en la lista blanca
 * de subbots permitidos para responder en el grupo oficial.
 */
const { isSubbotAllowedInOfficial } = require('./gofc');

// ── Módulos de on/off cacheados al nivel del módulo (evita require() en cada mensaje) ──
// Node.js ya cachea módulos pero el lookup tiene overhead; guardamos la referencia directa.
const _subbotOnOffModule  = require('./subbots-onoff');
const _botsAdminsModule   = require('./subbots-admins');

// ── Deduplicación Atómica de Mensajes en Grupos Compartidos ──────────────────
const claimedGroupMessages = new Map();
const connectingSubBots = new Set();
let isAutoReconnecting = false;

/**
 * Intenta reclamar el procesamiento de un mensaje en un grupo.
 * Si 2 o más subbots están en el mismo grupo y reciben el mismo mensaje,
 * el primer subbot lo reclama en memoria atómicamente y los demás lo ignoran.
 * Si el subbot está solo en el grupo, siempre lo reclama al instante.
 * Funciona garantizadamente en 1 o 1000 grupos distintos sin interferencia.
 */
function claimGroupMessage(chatJid, messageId, subNum) {
    if (!chatJid || !messageId) return true;
    const key = `${chatJid}:${messageId}`;
    if (claimedGroupMessages.has(key)) {
        return false; // Ya fue reclamado por otro subbot
    }
    claimedGroupMessages.set(key, { subNum, ts: Date.now() });
    if (claimedGroupMessages.size > 2000) {
        const firstKey = claimedGroupMessages.keys().next().value;
        if (firstKey) claimedGroupMessages.delete(firstKey);
    }
    return true; // Este subbot fue el primero en reclamarlo
}

setInterval(() => {
    const now = Date.now();
    for (const [key, val] of claimedGroupMessages.entries()) {
        if (now - val.ts > 30000) { // 30s de TTL para deduplicar (libera memoria y reduce latencia)
            claimedGroupMessages.delete(key);
        }
    }
}, 15 * 1000);

let _respUsuariosSubbotCache = null, _respUsuariosSubbotTime = 0;
function getRespuestasUsuariosSubbotData() {
    const now = Date.now();
    if (_respUsuariosSubbotCache && (now - _respUsuariosSubbotTime < 5000)) {
        return _respUsuariosSubbotCache;
    }
    try {
        const respFile = path.join(__dirname, '..', '..', 'data', 'respuestas-usuarios.json');
        if (fs.existsSync(respFile)) {
            _respUsuariosSubbotCache = JSON.parse(fs.readFileSync(respFile, 'utf8'));
            _respUsuariosSubbotTime = now;
            return _respUsuariosSubbotCache;
        }
    } catch (e) {}
    _respUsuariosSubbotCache = {};
    _respUsuariosSubbotTime = now;
    return _respUsuariosSubbotCache;
}
const activeSocks = new Map();
// pendingQR guarda { expiresAt: timestamp } para poder mostrar countdown y auto-expirar entradas
const pendingQR = new Map();
const reconnectTimers = new Map();
const reconnectAttempts = new Map();

// Números borrados a propósito (ej: .subbotsclean). connectSubBot() los rechaza
// aunque ya hubiera una reconexión encolada/en curso, para que no "resuciten" solos.
const deletedSubBots = new Set();

// Limpiar archivos huérfanos de sesiones al arrancar (una vez inicializadas las estructuras de memoria)
try { cleanOrphanSessionFiles(); } catch (e) { console.error('[SubBot] Error limpieza inicial sesiones:', e.message); }

/** Limpia entradas expiradas del mapa de pending */
function cleanExpiredPending() {
    const now = Date.now();
    for (const [key, val] of pendingQR.entries()) {
        if (val.expiresAt <= now) pendingQR.delete(key);
    }
}

/** Registra un pending con su tiempo de expiración en ms desde ahora */
function pendingQRAdd(key, ttlMs) {
    pendingQR.set(key, { expiresAt: Date.now() + ttlMs });
}

/** Retorna true si el pending existe Y todavía no expiró (limpiando si ya expiró) */
function pendingQRHas(key) {
    const entry = pendingQR.get(key);
    if (!entry) return false;
    if (entry.expiresAt <= Date.now()) { pendingQR.delete(key); return false; }
    return true;
}

/** Segundos restantes para que expire el pending (0 si no existe o ya expiró) */
function pendingQRSecondsLeft(key) {
    const entry = pendingQR.get(key);
    if (!entry) return 0;
    const left = Math.ceil((entry.expiresAt - Date.now()) / 1000);
    return left > 0 ? left : 0;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * Destruye y libera por completo un socket de SubBot de la memoria RAM.
 * Cancela temporizadores, listeners de Baileys, conexiones WebSocket y mapas globales.
 * NOTA DE SEGURIDAD: NO borra la sesión (.db) en disco. El subbot volverá a conectar automáticamente.
 */
function destroySubBotSocket(sock) {
    if (!sock) return;
    try {
        if (sock._cacheCleanupInterval) {
            clearInterval(sock._cacheCleanupInterval);
            sock._cacheCleanupInterval = null;
        }
        if (typeof sock._closeDb === 'function') {
            try { sock._closeDb(); } catch {}
            sock._closeDb = null;
        }
        if (sock.ev) {
            try { sock.ev.removeAllListeners(); } catch {}
        }
        if (sock.ws) {
            try { sock.ws.close(); } catch {}
            try { sock.ws.terminate(); } catch {}
        }
        if (typeof sock.end === 'function') {
            try { sock.end(undefined); } catch {}
        }
    } catch (e) {
        console.error('[SubBot] Error liberando socket de RAM:', e.message);
    }

    const name = sock._subName;
    if (name) {
        if (activeSocks.get(name) === sock) {
            activeSocks.delete(name);
        }
        if (global.subConns) {
            const idx = global.subConns.indexOf(sock);
            if (idx >= 0) global.subConns.splice(idx, 1);
        }
    }
}

/**
 * Purga por completo el estado en RAM de un sub-bot y bloquea futuras
 * reconexiones automáticas para ese número. Debe llamarse ANTES de borrar
 * los archivos de sesión en disco (ej: desde .subbotsclean), porque si solo
 * se cierra el socket, el listener de 'connection.update' (code 515/405/etc.)
 * termina reencolando una reconexión que vuelve a crear el .db borrado.
 *
 * NOTA: no borra archivos de sesión, solo memoria/colas. Combinar con
 * removeSessionFiles(num) para un borrado real y definitivo.
 */
function forgetSubBot(num) {
    const name = String(num);
    deletedSubBots.add(num);

    // Cancelar timer de reconexión pendiente (backoff o 515)
    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }
    reconnectAttempts.delete(name);

    // Sacar de la cola de reconexión si ya estaba encolado
    for (let i = reconnectQueue.length - 1; i >= 0; i--) {
        if (reconnectQueue[i].num === num) reconnectQueue.splice(i, 1);
    }
    activeReconnections.delete(name);

    // Limpiar pendings de vinculación (QR/código) asociados
    for (const key of pendingQR.keys()) {
        if (key === name || String(key).startsWith(`${name}:`)) pendingQR.delete(key);
    }

    // Destruir el socket si sigue vivo en memoria (esté "conectado" o no)
    const sock = activeSocks.get(name)
        || (global.subConns || []).find(c => c._subNum === num);
    if (sock) {
        try { destroySubBotSocket(sock); } catch (e) {
            console.error(`[SubBot] Error destruyendo socket #${num} en forgetSubBot:`, e.message);
        }
    }
    activeSocks.delete(name);

    // Por si quedó un residuo en subConns (destroySubBotSocket lo hace por nombre)
    if (global.subConns) {
        const idx = global.subConns.findIndex(c => c._subNum === num);
        if (idx >= 0) global.subConns.splice(idx, 1);
    }

    console.log(`[SubBot] 🧹 #${num} purgado de memoria (colas, timers, sockets).`);
}

// ── SISTEMA DE COLA Y PROTECCIÓN DE RED DE SUBBOTS ─────────────────────────
const reconnectQueue = [];
const activeReconnections = new Set();
const MAX_CONCURRENT_RECONNECTS = 1; // 1 reconexión a la vez para no colapsar la IP ni red
let lastDisconnectionTime = 0;
let disconnectionCountInWindow = 0;
let isNetworkPaused = false;
let networkPauseTimer = null;

function registerDisconnection(num, ownerJid, conn) {
    const now = Date.now();
    if (now - lastDisconnectionTime < 10000) {
        disconnectionCountInWindow++;
    } else {
        disconnectionCountInWindow = 1;
        lastDisconnectionTime = now;
    }

    // Si caen 6 o más subbots en menos de 10s, activar Pausa por Caída Masiva de Red
    if (disconnectionCountInWindow >= 6 && !isNetworkPaused) {
        isNetworkPaused = true;
        console.warn(`[SubBot Queue] ⚠️ CAÍDA MASIVA DE RED DETECTADA (${disconnectionCountInWindow} subbots cayeron). Pausando reconexiones 20s para estabilizar red...`);
        // Notificar al circuit breaker global para que IAs y APIs también paren
        if (global.networkGuard) {
            // Reportar algunos errores al circuit breaker para que lo sepa,
            // pero no forzar la apertura (antes eran 8, lo que garantizaba bloquear todo por 45s)
            for (let i = 0; i < 3; i++) global.networkGuard.reportNetworkError(
                { code: 'ECONNREFUSED', message: 'ECONNREFUSED (caída masiva de subbots)' },
                { fromWhatsApp: true }
            );
        }
        if (networkPauseTimer) clearTimeout(networkPauseTimer);
        networkPauseTimer = setTimeout(() => {
            isNetworkPaused = false;
            console.log(`[SubBot Queue] 🟢 Red estabilizada. Reanudando cola de reconexiones (${reconnectQueue.length} pendientes)...`);
            processReconnectQueue();
        }, 20000);
    }

    enqueueSubBotReconnect(num, ownerJid, conn);
}

function enqueueSubBotReconnect(num, ownerJid, conn) {
    const name = String(num);
    const attempts = (reconnectAttempts.get(name) || 0) + 1;
    reconnectAttempts.set(name, attempts);

    // Circuit Breaker: si ha fallado más de 5 veces seguidas, entrar en enfriamiento de 10 minutos
    if (attempts > 5) {
        console.warn(`[SubBot] 🛑 Bot #${num} superó 5 intentos fallidos. Entrando en enfriamiento de seguridad (10 min)...`);
        if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));
        const tid = setTimeout(() => {
            reconnectTimers.delete(name);
            reconnectAttempts.set(name, 1);
            enqueueSubBotReconnect(num, ownerJid, conn);
        }, 10 * 60 * 1000);
        reconnectTimers.set(name, tid);
        return;
    }

    // Backoff escalonado + Jitter aleatorio (Evita picos de reconexión simultánea)
    const baseBackoff = Math.min(120000, Math.floor(10000 * Math.pow(1.4, attempts - 1)));
    const randomJitter = Math.floor(Math.random() * 8000); // 0 a 8000 ms aleatorio
    const delay = baseBackoff + randomJitter;

    console.log(`[SubBot] ⏳ Bot #${num} programado para reconectar en ${(delay / 1000).toFixed(1)}s (intento ${attempts})...`);

    if (reconnectTimers.has(name)) clearTimeout(reconnectTimers.get(name));

    const tid = setTimeout(() => {
        reconnectTimers.delete(name);
        if (!reconnectQueue.some(item => item.num === num)) {
            reconnectQueue.push({ num, ownerJid, conn });
        }
        processReconnectQueue();
    }, delay);

    reconnectTimers.set(name, tid);
}

async function processReconnectQueue() {
    if (isNetworkPaused) return;
    if (reconnectQueue.length === 0) return;
    if (activeReconnections.size >= MAX_CONCURRENT_RECONNECTS) return;

    const item = reconnectQueue.shift();
    if (!item) return;

    const { num, ownerJid, conn } = item;
    const name = String(num);

    activeReconnections.add(name);
    console.log(`[SubBot Queue] 🔄 Procesando reconexión de Bot #${num} (${reconnectQueue.length} restantes en cola)...`);

    try {
        await connectSubBot({ num, chatJid: ownerJid, conn });
    } catch (e) {
        console.error(`[SubBot Queue] Error reconectando #${num}:`, e.message);
    } finally {
        activeReconnections.delete(name);
        setTimeout(() => processReconnectQueue(), 2500); // 2.5s entre reconexiones individuales
    }
}

// ── RAM Watchdog (Modo Silencioso) ──────────────────────────────────────────
setInterval(() => {
    try {
        const mem = process.memoryUsage();
        const heapMb = Math.round(mem.heapUsed / 1024 / 1024);
        const rssMb = Math.round(mem.rss / 1024 / 1024);

        // Recolección de basura silenciosa sin saturar logs ni enviar advertencias molestas
        if (rssMb > 1300 || heapMb > 900) {
            if (global.gc) { try { global.gc(); } catch {} }
        }
    } catch {}
}, 60 * 1000);

// (isMainBotInGroup eliminado: el bot principal no tiene sesión activa,
//  la lógica de groupFetchAllParticipating generaba picos de red innecesarios)

// ── COLA PROGRESIVA Y SUAVE DE UNIÓN A CANALES DE WHATSAPP ─────────────────
// En lugar de hacer 140+ peticiones síncronas masivas a la API de WhatsApp,
// se procesa 1 solo sub-bot cada 60 segundos con 12s de pausa entre canales.
const channelFollowQueue = [];
const verifiedChannelsBots = new Set();
let isProcessingChannelQueue = false;

function enqueueChannelFollow(sock, label = 'Bot') {
    if (!sock?.user) return;
    const key = sock._subNum ? String(sock._subNum) : (sock.user.id || label);
    if (verifiedChannelsBots.has(key)) return;

    if (!channelFollowQueue.some(item => item.key === key)) {
        channelFollowQueue.push({ sock, label, key });
    }
    startChannelQueueProcessor();
}

const sleepMs = ms => new Promise(r => setTimeout(r, ms));

async function processNextChannelSubbot() {
    if (channelFollowQueue.length === 0) {
        isProcessingChannelQueue = false;
        return;
    }

    isProcessingChannelQueue = true;
    const item = channelFollowQueue.shift();

    if (item && item.sock?.user) {
        const { sock, label, key } = item;
        const channelUrls = [
            //'https://whatsapp.com/channel/0029VbDgoneISTkFw19xea41', //canal de agusss - a los 200 seguidores sacar
            'https://whatsapp.com/channel/0029VaePMFRGk1Fq0mv6b80Q', //canal de updates
            'https://whatsapp.com/channel/0029VbDaSad47XeDBsa1jl39', //canal de memes
            'https://whatsapp.com/channel/0029Vb8VGYA3rZZi6vWV9e2d', //canal de frases,memes,stickers, etc
            'https://whatsapp.com/channel/0029VbE4YZB3LdQYh5KCKG0T' //canal de off topic
        ];

        let allOk = true;
        for (let i = 0; i < channelUrls.length; i++) {
            const channelUrl = channelUrls[i];
            try {
                const inviteCode = channelUrl.split('/').pop();
                if (inviteCode) {
                    const metadata = await sock.newsletterMetadata('invite', inviteCode);
                    if (metadata && metadata.id) {
                        await sock.newsletterFollow(metadata.id);
                        console.log(`[Canal ${label}] ✅ Unido exitosamente a (${inviteCode})`);
                    }
                }
            } catch (error) {
                if (error.message?.includes('unexpected response structure')) {
                    // Ya sigue al canal
                } else {
                    allOk = false;
                }
            }
            if (i < channelUrls.length - 1) {
                await sleepMs(12000); // 12 segundos entre canales del mismo subbot
            }
        }

        if (allOk) {
            verifiedChannelsBots.add(key);
        }
    }

    // Programar el siguiente sub-bot en 60 segundos (1 minuto)
    setTimeout(() => {
        processNextChannelSubbot();
    }, 60000);
}

function startChannelQueueProcessor() {
    if (isProcessingChannelQueue) return;
    isProcessingChannelQueue = true;
    setTimeout(() => {
        processNextChannelSubbot();
    }, 5000);
}

// Auto-Sincronización suave cada 4 horas: encola subbots para verificación progresiva
setInterval(() => {
    try {
        if (global.conn?.user) {
            enqueueChannelFollow(global.conn, 'Principal');
        }
        if (Array.isArray(global.subConns)) {
            for (const subSock of global.subConns) {
                if (subSock?.user) {
                    const num = subSock._subNum || '?';
                    enqueueChannelFollow(subSock, `SubBot #${num}`);
                }
            }
        }
    } catch (_) {}
}, 4 * 60 * 60 * 1000);

// FIX 405 (2026-07, actualizado): WhatsApp rota la versión de protocolo aceptada
// con mucha frecuencia. Misma estrategia que en index.js — ver comentario extenso
// ahí. Resumen: env var WA_BAILEYS_VERSION > valor por defecto de abajo > fallback
// a fetchLatestBaileysVersion() si el fijo es rechazado con 405.
// Hilos activos: https://github.com/WhiskeySockets/Baileys/issues/2370
//                https://github.com/WhiskeySockets/Baileys/issues/2485
const DEFAULT_BAILEYS_VERSION = [2, 3000, 1043857760];

let _baileysVersion = null;
let _subbotUsedFallback = false;

function parseEnvVersionSubbot() {
    const raw = process.env.WA_BAILEYS_VERSION;
    if (!raw) return null;
    const parts = raw.split(',').map(n => parseInt(n.trim(), 10));
    if (parts.length !== 3 || parts.some(n => Number.isNaN(n))) return null;
    return parts;
}

async function getBaileysVersion() {
    if (_baileysVersion) return _baileysVersion;
    const envVersion = parseEnvVersionSubbot();
    _baileysVersion = envVersion || DEFAULT_BAILEYS_VERSION;
    return _baileysVersion;
}

// Invalida la versión cacheada tras un 405 para que el próximo intento use
// fetchLatestBaileysVersion() en vez de repetir la misma versión rota.
async function invalidateBaileysVersionOnAuthFailure() {
    if (_subbotUsedFallback) return;
    _subbotUsedFallback = true;
    try {
        const { version } = await fetchLatestBaileysVersion();
        console.log(`[SubBot][Baileys] Versión fija rechazada (405). Probando fetchLatestBaileysVersion(): ${version.join('.')}`);
        _baileysVersion = version;
    } catch (e) {
        console.error('[SubBot][Baileys] fetchLatestBaileysVersion() también falló:', e.message);
    }
}

function sessionPath(num) {
    return path.join(SESSIONS_DIR, `${num}.db`);
}

function sessionFiles(num) {
    const base = path.join(SESSIONS_DIR, String(num));
    return [
        `${base}.db`,
        `${base}.db-wal`,
        `${base}.db-shm`
    ];
}

// ── REGLA DE 48 HORAS: ninguna sesión se borra si ha sido modificada en las últimas 48 horas ──
const SESSION_INACTIVITY_MS = 48 * 60 * 60 * 1000; // 48 horas de inactividad obligatoria (2 días completos)

/**
 * Obtiene la marca de tiempo de modificación más reciente de entre los archivos (.db, .db-wal, .db-shm).
 */
function getSessionLastModified(num) {
    const files = sessionFiles(num);
    let maxMtime = 0;
    for (const f of files) {
        try {
            if (fs.existsSync(f)) {
                const stat = fs.statSync(f);
                if (stat.mtimeMs > maxMtime) maxMtime = stat.mtimeMs;
            }
        } catch (_) {}
    }
    return maxMtime;
}

/**
 * Devuelve true si la sesión no ha tenido NINGUNA modificación en sus archivos en al menos 48 horas.
 */
function isSessionInactive48h(num) {
    const lastMtime = getSessionLastModified(num);
    if (!lastMtime) return true; // No existen archivos en disco
    return (Date.now() - lastMtime) >= SESSION_INACTIVITY_MS;
}

/**
 * Borra los archivos de sesión de un sub-bot solo si han pasado más de 48 horas de inactividad,
 * o si se fuerza explícitamente (ej: comando wipe del owner).
 */
function removeSessionFiles(num, { retries = 3, force = false } = {}) {
    // 🛡️ PROTECCIÓN ESTRICTA: No borrar a menos que lleve 48h de inactividad o sea force: true
    if (!force && !isSessionInactive48h(num)) {
        const lastMod = getSessionLastModified(num);
        const hoursAgo = lastMod ? ((Date.now() - lastMod) / (1000 * 60 * 60)).toFixed(1) : 0;
        console.log(`[SubBot] 🛡️ Sesión #${num} protegida: modificada hace ${hoursAgo}h (mínimo 48h de inactividad requerido). NO se borrará.`);
        return { removed: false, dbGone: false };
    }

    const files = sessionFiles(num);
    const dbFile = files[0];

    // Cerrar cualquier conexión abierta de SQLite a este archivo antes de borrar (evita EBUSY en Windows)
    try {
        if (typeof closeAuthDb === 'function') closeAuthDb(dbFile);
    } catch {}

    let deletedAny = false;

    for (const f of files) {
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                if (!fs.existsSync(f)) break;
                fs.unlinkSync(f);
                deletedAny = true;
                console.log(`[SubBot] 🗑️ Eliminado archivo de sesión inactiva (+48h): ${path.basename(f)}`);
                break;
            } catch (e) {
                if (attempt === retries) {
                    console.error(`[SubBot] Error eliminando ${f} tras ${retries + 1} intentos:`, e.message);
                }
            }
        }
    }

    const dbGone = !fs.existsSync(dbFile);

    if (deletedAny || dbGone) {
        invalidateConfirmedCountCache();
        try { cleanupSubBot(num); } catch (e) {}
        try { cleanupSubbotActivity(num); } catch (e) {}
        try { chatTracker.clearTrackedChats(num); } catch (e) {}
        try { chatCleanScheduler.clearSubBotChatClean(num); } catch (e) {}
    }

    return { removed: deletedAny, dbGone };
}

function cleanOrphanSessionFiles() {
    try {
        if (!fs.existsSync(SESSIONS_DIR)) return;
        const files = fs.readdirSync(SESSIONS_DIR);
        const grouped = {};
        for (const f of files) {
            const m = f.match(/^(\d+)(?:\.db|\.db-wal|\.db-shm)$/);
            if (!m) continue;
            const n = parseInt(m[1], 10);
            if (!grouped[n]) grouped[n] = new Set();
            grouped[n].add(f);
        }

        for (const nStr of Object.keys(grouped)) {
            const n = parseInt(nStr, 10);

            // Si está activamente conectando en memoria, no tocar
            if (activeSocks.has(String(n)) || connectingSubBots.has(String(n))) {
                continue;
            }

            // 🛡️ REGLA FUNDAMENTAL: si fue editado en las últimas 48 horas, SE CONSERVA TOTALMENTE
            if (!isSessionInactive48h(n)) {
                continue;
            }

            // Solo después de 48 horas completas de inactividad total se procede con la limpieza
            const names = Array.from(grouped[n]);
            const hasDb = names.some(x => x.endsWith('.db'));
            const dbFile = sessionPath(n);

            if (!hasDb) {
                console.log(`[SubBot Garbage Collector] 🗑️ Sesión #${n} inactiva (+48h) y sin .db principal, limpiando restos: ${names.join(', ')}`);
                removeSessionFiles(n, { force: true });
                continue;
            }

            try {
                if (fs.existsSync(dbFile)) {
                    if (!isValidSessionDb(dbFile)) {
                        console.log(`[SubBot Garbage Collector] 🗑️ Sesión #${n} inactiva (+48h) y corrupta/vacía, eliminando...`);
                        removeSessionFiles(n, { force: true });
                        continue;
                    }

                    const owner = getConfirmedSessionOwner(dbFile);
                    if (!owner) {
                        console.log(`[SubBot Garbage Collector] 🗑️ Sesión #${n} inactiva (+48h) y sin owner confirmado, eliminando...`);
                        removeSessionFiles(n, { force: true });
                        continue;
                    }
                }
            } catch (err) {
                console.error(`[SubBot Garbage Collector] Error evaluando sesión #${n}:`, err.message);
            }
        }
    } catch (e) {
        console.error('[SubBot Garbage Collector] Error escaneando sesiones:', e.message);
    }
}

// Limpieza periódica suave cada 30 minutos de sesiones huérfanas o no vinculadas
setInterval(() => {
    try { cleanOrphanSessionFiles(); } catch (e) { console.error('[SubBot] Error limpieza periódica sesiones:', e.message); }
}, 30 * 60 * 1000);

function nextSubBotNumber() {
    const existing = fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
    let n;
    do { n = Math.floor(1000 + Math.random() * 9000); } while (existing.includes(n));
    return n;
}

/**
 * Abre una DB SQLite de forma WAL-aware:
 * Intenta modo escritura (aplica WAL automáticamente). Si falla, usa readonly.
 * Siempre cierra la DB antes de retornar.
 * Devuelve null si no se puede abrir de ninguna forma.
 */
function withWalAwareDb(dbFile, fn) {
    if (!fs.existsSync(dbFile)) return null;
    const Database = require('better-sqlite3');
    let db = null;
    let usedReadonly = false;

    // Intento 1: modo escritura (aplica WAL, permite wal_checkpoint)
    try {
        db = new Database(dbFile, { readonly: false });
        db.pragma('busy_timeout = 2000');
        db.pragma('cache_size = -256');
        try { db.pragma('wal_checkpoint(PASSIVE)'); } catch (_) {}
    } catch (_) {
        // Intento 2: modo readonly (fallback si está bloqueada)
        try {
            if (db) { try { db.close(); } catch (_) {} }
            db = new Database(dbFile, { readonly: true });
            db.pragma('busy_timeout = 2000');
            db.pragma('cache_size = -256');
            usedReadonly = true;
        } catch (_) {
            return null;
        }
    }

    try {
        return fn(db, usedReadonly);
    } catch (_) {
        return null;
    } finally {
        try { db.close(); } catch (_) {}
    }
}

function isValidSessionDb(dbFile) {
    if (!fs.existsSync(dbFile)) return false;

    // ✅ FIX C: NO descartar por tamaño si existe un .db-wal con contenido.
    // Tras un reinicio forzado o crash, el .db puede tener pocos bytes pero
    // el .db-wal contiene la sesión completa y válida.
    try {
        const stats = fs.statSync(dbFile);
        const walFile = dbFile + '-wal';
        const hasWal = fs.existsSync(walFile);
        const walSize = hasWal ? fs.statSync(walFile).size : 0;

        if (stats.size < 100 && (!hasWal || walSize < 32)) return false;
    } catch {
        return false;
    }

    // ✅ FIX C: Abrir en modo WAL-aware
    return withWalAwareDb(dbFile, (db) => {
        const hasAuthTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='auth'").get();
        if (!hasAuthTable) return false;

        const rowCreds = db.prepare("SELECT value FROM auth WHERE key = 'creds'").get();
        return !!(rowCreds && rowCreds.value);
    }) ?? false;
}

/**
 * Obtiene los datos del dueño confirmado guardados en la sesión.
 * Solo devuelve datos si la sesión realmente llegó a conectarse ('open')
 * y guardó la clave '_owner' en la tabla 'auth'.
 * Devuelve null si la sesión nunca se vinculó, está corrupta o vacía.
 */
function getConfirmedSessionOwner(dbFile) {
    if (!fs.existsSync(dbFile)) return null;

    // ✅ FIX D: Tamaño WAL-aware
    try {
        const stats = fs.statSync(dbFile);
        const walFile = dbFile + '-wal';
        const hasWal = fs.existsSync(walFile);
        const walSize = hasWal ? fs.statSync(walFile).size : 0;

        if (stats.size < 100 && (!hasWal || walSize < 32)) return null;
    } catch {
        return null;
    }

    // ✅ FIX D: Abrir en modo WAL-aware
    return withWalAwareDb(dbFile, (db) => {
        const hasAuthTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='auth'").get();
        if (!hasAuthTable) return null;

        const row = db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
        if (!row || !row.value) return null;
        const data = JSON.parse(row.value);
        if (!data || (!data.ownerJid && !data.phoneNumber)) return null;
        return data;
    });
}

let _confirmedSubBotsCache = null;
let _confirmedSubBotsCacheTime = 0;
const CONFIRMED_CACHE_TTL = 15000;

function invalidateConfirmedCountCache() {
    _confirmedSubBotsCache = null;
    _confirmedSubBotsCacheTime = 0;
}

/**
 * Cuenta la cantidad de sesiones registradas en disco que están confirmadas con un dueño real.
 */
function countConfirmedSubBots() {
    const now = Date.now();
    if (_confirmedSubBotsCache !== null && (now - _confirmedSubBotsCacheTime < CONFIRMED_CACHE_TTL)) {
        return _confirmedSubBotsCache;
    }
    if (!fs.existsSync(SESSIONS_DIR)) return 0;
    try {
        const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
        let count = 0;
        for (const file of dbFiles) {
            const dbPath = path.join(SESSIONS_DIR, file);
            if (getConfirmedSessionOwner(dbPath)) {
                count++;
            }
        }
        _confirmedSubBotsCache = count;
        _confirmedSubBotsCacheTime = now;
        return count;
    } catch {
        return 0;
    }
}

function getSubBotNumberByOwner(ownerJid) {
    if (!fs.existsSync(SESSIONS_DIR)) return null;
    const ownerNum = (ownerJid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    if (!ownerNum) return null;
    const dbFiles = fs.readdirSync(SESSIONS_DIR).filter(f => /^\d+\.db$/.test(f));
    for (const file of dbFiles) {
        const num = parseInt(file, 10);
        if (isNaN(num)) continue;
        const dbPath = path.join(SESSIONS_DIR, file);
        const ownerData = getConfirmedSessionOwner(dbPath);
        if (!ownerData) continue;
        const storedNum = (ownerData.phoneNumber || ownerData.ownerJid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        if (storedNum && storedNum === ownerNum) return num;
    }
    return null;
}

// ─── Helper: manejar mensajes borrados (texto, imagen, video, sticker, audio) ─
async function _handleBorradoMessage(sock, remoteJid, original) {
    try {
        const msg = original.message || {};
        const senderJid = original.key.participant || original.key.remoteJid || '';
        const userNum = senderJid.split('@')[0].split(':')[0];
        const mentionJid = original.key.participant || original.key.remoteJid;

        // ── Texto / Texto extendido ──────────────────────────────────────
        const textContent = msg.conversation || msg.extendedTextMessage?.text || '';
        if (textContent.trim().length > 0) {
            const hasLink = /(https?:\/\/|www\.)/i.test(textContent);
            if (!hasLink) {
                await sock.sendMessage(remoteJid, {
                    text: `📌 El usuario @${userNum} eliminó este mensaje:\n\n${textContent}`,
                    mentions: [mentionJid]
                });
            }
            return;
        }

        // ── Imagen ───────────────────────────────────────────────────────
        if (msg.imageMessage) {
            const caption = msg.imageMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una imagen${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Video ─────────────────────────────────────────────────────────
        if (msg.videoMessage) {
            const caption = msg.videoMessage.caption || '';
            const hasLink = /(https?:\/\/|www\.)/i.test(caption);
            const newCaption = hasLink ? '' : caption;
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un video${newCaption ? `:\n\n${newCaption}` : '.'}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Sticker ───────────────────────────────────────────────────────
        if (msg.stickerMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un sticker:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el sticker eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Audio / Nota de voz ───────────────────────────────────────────
        if (msg.audioMessage) {
            const isPtt = msg.audioMessage.ptt === true;
            const tipo = isPtt ? 'nota de voz' : 'audio';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ${tipo}:`,
                mentions: [mentionJid]
            });
            await sock.sendMessage(remoteJid, {
                text: `⬆️ Este era el ${tipo} eliminado por @${userNum}`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Documento ─────────────────────────────────────────────────────
        if (msg.documentMessage) {
            const fileName = msg.documentMessage.fileName || 'archivo';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un documento: *${fileName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── GIF ───────────────────────────────────────────────────────────
        if (msg.gifMessage || (msg.videoMessage && msg.videoMessage.gifPlayback)) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un GIF.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Contacto ──────────────────────────────────────────────────────
        if (msg.contactMessage) {
            const contactName = msg.contactMessage.displayName || 'contacto';
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó un contacto: *${contactName}*`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

        // ── Ubicación ─────────────────────────────────────────────────────
        if (msg.locationMessage || msg.liveLocationMessage) {
            await sock.sendMessage(remoteJid, {
                text: `📌 El usuario @${userNum} eliminó una ubicación.`,
                mentions: [mentionJid]
            }, { quoted: original });
            return;
        }

    } catch (err) {
        console.error('[borrados] Error al manejar mensaje borrado:', err.message);
    }
}
// ─────────────────────────────────────────────────────────────────────────────

// ─── Conectar sub-bot ────────────────────────────────────────────────────────
async function connectSubBot({ num, chatJid, conn, token = null, usePairingCode = false, phoneNumber = null, isNewLinking = false, replyQuote = null, pendingKey = null }) {
    const name   = String(num);
    const dbFile = sessionPath(num);

    if (connectingSubBots.has(name)) {
        if (usePairingCode && isNewLinking) {
            throw new Error(`El sub-bot #${num} ya está intentando conectarse. Esperá un momento y volvé a usar .code.`);
        }
        console.log(`[SubBot] ⏳ SubBot #${num} ya está en proceso de conexión. Omitiendo duplicado.`);
        return activeSocks.get(name) || null;
    }

    // Si este número fue borrado explícitamente (.subbotsclean, etc.), no reconectar.
    // Excepción: si es una vinculación nueva y explícita (.qr/.code), se libera el bloqueo.
    if (deletedSubBots.has(num)) {
        if (isNewLinking) {
            deletedSubBots.delete(num);
        } else {
            console.log(`[SubBot] 🚫 Reconexión de #${num} abortada: la sesión fue borrada.`);
            return null;
        }
    }

    connectingSubBots.add(name);

    try {
        return await _doConnectSubBot({ num, chatJid, conn, token, usePairingCode, phoneNumber, isNewLinking, replyQuote, pendingKey, name, dbFile });
    } finally {
        connectingSubBots.delete(name);
    }
}

async function _doConnectSubBot({ num, chatJid, conn, token, usePairingCode, phoneNumber, isNewLinking, replyQuote, pendingKey, name, dbFile }) {

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    let ownerJid = chatJid;
    let storedPhoneNumber = phoneNumber;
    const pendingLockKey = pendingKey || ownerJid || null;

    if (fs.existsSync(dbFile)) {
        try {
            if (isValidSessionDb(dbFile)) {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile, { readonly: true });
                _db.pragma('cache_size = -256');
                _db.pragma('busy_timeout = 3000');
                const row = _db.prepare("SELECT value FROM auth WHERE key = '_owner'").get();
                _db.close();
                if (row) {
                    const data = JSON.parse(row.value);
                    if (!ownerJid) ownerJid = data.ownerJid;
                    if (!storedPhoneNumber) storedPhoneNumber = data.phoneNumber;
                }
            }
        } catch {}
    }

    const prevSock = activeSocks.get(name);
    if (prevSock) {
        destroySubBotSocket(prevSock);
    }

    const { state, saveCreds, close: closeDb } = await useSQLiteAuthState(dbFile);
    const version                              = await getBaileysVersion();

    const subbotHttpsAgent = global.sharedHttpsAgent || (global.sharedHttpsAgent = new (require('https').Agent)({ keepAlive: true, maxSockets: 5000, maxFreeSockets: 512, timeout: 45000, freeSocketTimeout: 15000, family: 4 }));

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        agent: subbotHttpsAgent,
        fetchAgent: subbotHttpsAgent,
        wsOptions: {
            agent: subbotHttpsAgent,
            perMessageDeflate: false, // Optimización 200+ subbots: desactiva zlib per-frame compresión (previene lag CPU y error 408)
            handshakeTimeout: 45000
        },
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, P({ level: 'silent' }))
        },
        msgRetryCounterCache: new Map(),
        // Anti-suspensión: Browsers.windows('Chrome') es obligatorio para que el pairing code
        // no falle con "No se pudo vincular el dispositivo" (error 408).
        browser: Browsers.windows('Chrome'),
        printQRInTerminal: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        getMessage: async () => undefined,
        ignoreStatusBroadcast: true,
        shouldSyncHistoryMessage: () => false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 3000,
        maxMsgRetryCount: 3,
        // Anti-suspensión: 25s de keepAlive estándar (previene desconexión 408 de WhatsApp)
        keepAliveIntervalMs: 25000
    });

    // Exponer la función de guardado para reinicios limpios
    try { sock._saveCreds = saveCreds; } catch (e) {}
    sock._closeDb        = closeDb;

    sock._subName        = name;
    sock._subNum         = num;
    sock._sessDb         = dbFile;
    sock._ownerJid       = ownerJid;
    sock._usePairingCode = usePairingCode;
    sock._phoneNumber    = phoneNumber;
    sock.uptime          = Date.now();
    activeSocks.set(name, sock);

    // ── Resiliencia y Anti-suspensión: Multi-retry & Rate Limit 429 wrapper ──
    // Permite soportar 200+ subbots reintentando automáticamente ante parpadeos de red
    // o errores 'Media upload failed on all hosts' de los servidores MMG de WhatsApp.
    const _originalSendMessage = sock.sendMessage.bind(sock);
    let _rateLimitCount = 0;

    sock.sendMessage = async (jid, content, options = {}) => {
        const MAX_MEDIA_RETRIES = 3;
        let lastError = null;

        for (let attempt = 1; attempt <= MAX_MEDIA_RETRIES; attempt++) {
            try {
                const result = await _originalSendMessage(jid, content, options);
                _rateLimitCount = 0;
                return result;
            } catch (error) {
                lastError = error;
                const errorCode = error?.data || error?.output?.statusCode;
                const errorMsg = String(error?.message || '');

                // Control de Rate Limit 429
                if (errorCode === 429 || errorMsg.includes('rate-overlimit') || errorMsg.includes('rate limit')) {
                    _rateLimitCount++;
                    const waitMs = _rateLimitCount > 5 ? 5000 : 1500;
                    if (_rateLimitCount === 1 || _rateLimitCount % 5 === 0) {
                        console.log(`[SubBot #${num}] ⏱️ Rate limit alcanzado (${_rateLimitCount}x) — pausando ${waitMs}ms...`);
                    }
                    await new Promise(r => setTimeout(r, waitMs));
                    return Promise.reject(new Error('Rate limit exceeded'));
                }

                // Detectar fallo de subida de media o caídas temporales de red MMG WhatsApp
                const isMediaUploadError = errorMsg.includes('Media upload failed') ||
                                           errorMsg.includes('upload') ||
                                           errorMsg.includes('ECONNRESET') ||
                                           errorMsg.includes('ETIMEDOUT') ||
                                           (errorCode >= 500 && errorCode <= 599);

                if (isMediaUploadError && attempt < MAX_MEDIA_RETRIES) {
                    const retryWait = attempt * 1500; // 1.5s, 3.0s
                    console.warn(`[SubBot #${num}] ⚠️ Fallo temporal de envío/media (${errorMsg}). Reintentando (${attempt}/${MAX_MEDIA_RETRIES}) en ${retryWait}ms...`);
                    await new Promise(r => setTimeout(r, retryWait));
                    continue;
                }

                return Promise.reject(error);
            }
        }
        return Promise.reject(lastError);
    };
    // ─────────────────────────────────────────────────────────────────────────

    // ── Caché de groupMetadata centralizada: parchea sock.groupMetadata para que
    // todos los plugins usen automáticamente la caché sin modificaciones individuales.
    attachGroupCacheToSocket(sock);

    if (welcomeGoodbyeModule?.init) {
        try {
            welcomeGoodbyeModule.init(sock);
            console.log(`[SubBot #${num}] ✓ Módulo Bienvenida/Despedida conectado.`);
        } catch (error) {
            console.error(`[SubBot #${num}] ❌ Error iniciando Bienvenida/Despedida:`, error.message);
        }
    }

    let qrSent               = false;
    let qrTimeout            = null;
    let connected            = false;
    let codeSent             = false;
    let pairingCodeRequested = false;

    const sendToOwner = async (content, options = {}) => {
        if (!ownerJid) return;
        const sender = (connected ? sock : (conn || global.conn));
        if (!sender) return; // bot principal aún no conectado, no se puede notificar
        const sendOptions = { ...(options || {}) };
        if (!sendOptions.quoted && replyQuote) {
            sendOptions.quoted = replyQuote;
        }
        try {
            await sender.sendMessage(ownerJid, content, sendOptions);
        } catch (e) {
            try {
                const fallback = sender === sock ? (conn || global.conn) : sock;
                if (fallback) await fallback.sendMessage(ownerJid, content, sendOptions);
            } catch {}
        }
    };

    const expirePairingCode = (message) => {
        if (connected) return;
        if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
        pendingQR.delete(pendingLockKey);
        activeSocks.delete(name);
        try { if (sock?.ev) sock.ev.removeAllListeners(); } catch {}
        try { if (sock?.ws) sock.ws.close(); } catch {}
        try { if (typeof sock._closeDb === 'function') sock._closeDb(); } catch {}
        sendToOwner({ text: message });
        try { require('../../subbotServer').resolveWebCode(num, null); } catch {}
    };

    if (usePairingCode) {
        qrTimeout = setTimeout(() => {
            expirePairingCode('⏰ No se pudo generar el código a tiempo. La solicitud expiró; volvé a intentarlo con `.code`.');
        }, 60000);
    }

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (
            usePairingCode &&
            phoneNumber &&
            !pairingCodeRequested &&
            !connected &&
            !state.creds.registered &&
            (connection === 'connecting' || !!qr)
        ) {
            pairingCodeRequested = true;
            console.log(`[SubBot] Solicitando código para #${num}...`);
            try {
                if (typeof sock.waitForSocketOpen !== 'function') {
                    throw new Error('La conexión de Baileys no permite esperar la apertura del WebSocket');
                }
                await sock.waitForSocketOpen();
                if (connected) return;

                // waitForSocketOpen confirma el transporte, pero Baileys todavía necesita
                // completar el handshake Noise antes de poder enviar el IQ del código.
                await sleep(3000);
                if (connected) return;
                if (!sock.ws?.isOpen && sock.ws?.readyState !== 1) {
                    throw new Error('La conexión con WhatsApp se cerró antes de solicitar el código');
                }
            } catch (e) {
                pairingCodeRequested = false;
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (pendingLockKey) pendingQR.delete(pendingLockKey);
                else if (ownerJid) pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { if (typeof sock._closeDb === 'function') sock._closeDb(); } catch {}
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                sendToOwner({ text: `❌ Error preparando la conexión para generar el código: ${e.message}` });
                try { require('../../subbotServer').resolveWebCode(num, null); } catch {}
                return;
            }

            if (qrTimeout) clearTimeout(qrTimeout);
            qrTimeout = setTimeout(() => {
                expirePairingCode('⏰ No se pudo generar el código a tiempo. La solicitud expiró; volvé a intentarlo con `.code`.');
            }, 60000);

            try {
                const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
                let code = null;
                let lastErr = null;
                for (let attempt = 1; attempt <= 3; attempt++) {
                    let requestTimeout;
                    try {
                        const timeoutError = new Error('Tiempo agotado esperando el código de emparejamiento');
                        timeoutError.code = 'PAIRING_CODE_TIMEOUT';
                        code = await Promise.race([
                            sock.requestPairingCode(cleanPhone),
                            new Promise((_, reject) => {
                                requestTimeout = setTimeout(() => reject(timeoutError), 30000);
                            })
                        ]);
                        if (code) break;
                    } catch (errAttempt) {
                        if (errAttempt?.code === 'PAIRING_CODE_TIMEOUT') throw errAttempt;
                        lastErr = errAttempt;
                        console.warn(`[SubBot #${num}] Intento ${attempt}/3 de solicitar código falló: ${errAttempt.message}`);
                        if (attempt < 3) await sleep(2000);
                    } finally {
                        if (requestTimeout) clearTimeout(requestTimeout);
                    }
                }
                if (!code) throw (lastErr || new Error('No se pudo obtener código de emparejamiento'));

                codeSent = true;

                // Enviar el mensaje con el número + video tutorial adjunto
                const tutorialPath = path.join(__dirname, 'tutorial-code.mp4');
                let sentWithVideo = false;
                if (fs.existsSync(tutorialPath)) {
                    try {
                        const videoBuffer = fs.readFileSync(tutorialPath);
                        await sendToOwner({
                            video: videoBuffer,
                            caption: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                        });
                        sentWithVideo = true;
                    } catch (videoErr) {
                        console.warn(`[SubBot #${num}] No se pudo enviar video tutorial: ${videoErr.message}`);
                    }
                }
                if (!sentWithVideo) {
                    await sendToOwner({
                        text: `🔐 *Código para sub-bot #${num}*\n📱 *Número:* +${cleanPhone}\n\nIngrésalo en:\nWhatsApp → Dispositivos Vinculados → Vincular con número de teléfono\n\n⏱️ Tienes 90 segundos.`
                    });
                }
                await sendToOwner({ text: code });

                try { require('../../subbotServer').resolveWebCode(num, code); } catch {}

                if (qrTimeout) clearTimeout(qrTimeout);
                qrTimeout = setTimeout(() => {
                    expirePairingCode('⏰ Código expirado. Si ya pudiste vincular el sub-bot, no hace falta volver a pedir uno nuevo. Si todavía no lo hiciste, generá otro con `.code`.');
                }, 90000);

            } catch (e) {
                pairingCodeRequested = false;
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (pendingLockKey) pendingQR.delete(pendingLockKey);
                else if (ownerJid)  pendingQR.delete(ownerJid);
                activeSocks.delete(name);
                try { if (typeof sock._closeDb === 'function') sock._closeDb(); } catch {}
                try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                sendToOwner({ text: `❌ Error generando código: ${e.message}` });
                try { require('../../subbotServer').resolveWebCode(num, null); } catch {}
            }
            return;
        }

        if (qr && !usePairingCode) {
            if (connected) return;
            if (qrSent) {
                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                pendingQR.delete(pendingLockKey);
            }

            try {
                const imgBuf = await qrcode.toBuffer(qr, { scale: 8 });
                await sendToOwner({
                    image: imgBuf,
                    caption: `📱 *Escanea el QR para tu sub-bot #${num}*\n_Tienes 30 segundos._`
                });
                qrSent = true;

                try { require('../../subbotServer').resolveWebQR(num, await qrcode.toDataURL(qr)); } catch {}

                qrTimeout = setTimeout(() => {
                    qrTimeout = null;
                    if (connected) return;
                    pendingQR.delete(pendingLockKey);
                    activeSocks.delete(name);
                    try { sock.ev.removeAllListeners(); sock.ws.close(); } catch {}
                    try { if (typeof sock._closeDb === 'function') sock._closeDb(); } catch {}
                    sendToOwner({ text: `⏰ QR expirado. Usa \`.qr\` de nuevo.` });
                }, 35000);
            } catch (e) {
                console.error(`[SubBot #${num}] Error procesando QR:`, e);
                try { require('../../subbotServer').resolveWebQR(num, null); } catch {}
            }
        }

        if (connection === 'open') {
            connected = true;
            if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
            pendingQR.delete(pendingLockKey);
            reconnectAttempts.delete(name);

            if (usePairingCode && !codeSent) {
                await sendToOwner({
                    text: state.creds.registered
                        ? `ℹ️ El sub-bot #${num} ya tenía una sesión vinculada y se conectó correctamente. No hace falta generar un código.`
                        : `ℹ️ El sub-bot #${num} se conectó antes de generar el código. No se envió ninguno; si todavía necesitás vincularlo, volvé a intentar con \`.code\`.`
                });
                try { require('../../subbotServer').resolveWebCode(num, null); } catch {}
            }

            try {
                const Database = require('better-sqlite3');
                const _db = new Database(dbFile);
                _db.pragma('journal_mode = WAL');
                _db.pragma('synchronous = NORMAL');
                _db.pragma('cache_size = -256');
                _db.pragma('busy_timeout = 5000');
                _db.exec(`CREATE TABLE IF NOT EXISTS auth (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
                const ownerData = {
                    ownerJid,
                    num,
                    phoneNumber: storedPhoneNumber || sock.user?.id?.split('@')[0]?.split(':')[0] || null
                };
                _db.prepare('INSERT OR REPLACE INTO auth (key, value) VALUES (?, ?)').run('_owner', JSON.stringify(ownerData));
                // ✅ FIX F: Checkpoint inmediato para que _owner sea visible a cualquier lector (incluso en readonly/reinicio)
                try { _db.pragma('wal_checkpoint(FULL)'); } catch (_) {}
                _db.close();
                invalidateConfirmedCountCache();
            } catch {}

            if (sock.user?.lid) {
                sock._lid = sock.user.lid;
                const cleanL = String(sock.user.lid).split('@')[0].split(':')[0].replace(/\D/g, '');
                if (cleanL) {
                    if (!global.subbotLidMap) global.subbotLidMap = new Map();
                    global.subbotLidMap.set(cleanL, sock);
                }
                if (sock.user?.id && global.db?.linkUserAlias) {
                    global.db.linkUserAlias(sock.user.id, sock.user.lid);
                }
            }
            if (!global.subConns.includes(sock)) global.subConns.push(sock);
            console.log(`[SubBot] ✅ Bot #${num} conectado`);
            enqueueChannelFollow(sock, `SubBot #${num}`);

            // Enviar notificación de conexión únicamente al propio chat privado del subbot (sin molestar en grupos ni chats externos)
            const selfJid = sock.user?.id ? (sock.user.id.split(':')[0].split('@')[0] + '@s.whatsapp.net') : null;
            if (selfJid) {
                const phoneNum = selfJid.split('@')[0];
                try {
                    await sock.sendMessage(selfJid, { text: `✅ *Sub-bot #${num} conectado*\n📱 wa.me/+${phoneNum}` });
                } catch (sendErr) {
                    console.warn(`[SubBot #${num}] No se pudo enviar confirmación al chat propio:`, sendErr.message);
                }
            }

            // ── Unirse / asegurar canal tras cada conexión o reconexión (segundo plano, 5s) ──
            setTimeout(() => {
                try { enqueueChannelFollow(sock, `SubBot #${num}`); } catch (_) {}
            }, 5000);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            const errMsg = String(lastDisconnect?.error?.message || '');
            console.log(`[SubBot] Bot #${num} desconectado, código: ${code}, msg: ${errMsg}`);

            // Destruir limpiamente el socket anterior de la memoria RAM
            destroySubBotSocket(sock);

            // Si estábamos en proceso de vinculación nueva y nunca llegamos a 'open':
            if (!connected && isNewLinking) {
                if (code === 515) {
                    console.log(`[SubBot] ⚠️ Bot #${num} en vinculación reiniciando stream (515)...`);
                    const tid515 = setTimeout(() => {
                        reconnectTimers.delete(name);
                        connectSubBot({ num, chatJid: ownerJid, conn, usePairingCode, phoneNumber, isNewLinking, replyQuote, pendingKey });
                    }, 3000);
                    reconnectTimers.set(name, tid515);
                    return;
                }

                if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                if (pendingLockKey) pendingQR.delete(pendingLockKey);
                activeSocks.delete(name);
                try { if (typeof sock._closeDb === 'function') sock._closeDb(); } catch {}
                return;
            }

            const isLoggedOut = code === DisconnectReason.loggedOut;

            // 515 = reinicio de stream / reconexión requerida por Baileys
            // NO borrar la sesión en disco; reconectar el socket.
            if (code === 515) {
                console.log(`[SubBot] ⚠️ Bot #${num} reconectando tras reinicio de stream (515)...`);
                const tid515 = setTimeout(() => {
                    reconnectTimers.delete(name);
                    connectSubBot({ num, chatJid: ownerJid, conn });
                }, 3000);
                reconnectTimers.set(name, tid515);
                return;
            }

            // 401 = sesión explícitamente cerrada o no autorizada (NO borrar archivo en disco)
            if (code === 401) {
                if (isLoggedOut) {
                    console.log(`[SubBot] ⚠️ Bot #${num} recibió 401/loggedOut. Deteniendo reconexión.`);
                    if (pendingLockKey) pendingQR.delete(pendingLockKey);
                    if (qrTimeout) { clearTimeout(qrTimeout); qrTimeout = null; }
                    if (connected) {
                        sendToOwner({
                            text: `⚠️ *Sub-bot #${num} sesión cerrada*\n\nLa sesión se cerró desde WhatsApp.\n💡 Usá \`.code\` o \`.qr\` para volver a vincular.`
                        });
                    }
                    return;
                } else {
                    console.log(`[SubBot] ⚠️ Bot #${num} recibió 401 temporal. Encolando reintento de reconexión...`);
                    registerDisconnection(num, ownerJid, conn);
                    return;
                }
            }

            if (isLoggedOut || code === 440) {
                if (code === 440) {
                    console.log(`[SubBot] ⚠️ Bot #${num} reemplazado (440). NO reconectará para evitar bucle.`);
                    return;
                }
                sendToOwner({ text: `⚠️ Sesión del sub-bot #${num} cerrada o en espera. Usá \`.qr\` o \`.code\` si necesitás reconectar.` });
                return;
            }

            // Error 403 (Forbidden) - advertir pero NO borrar archivos de disco
            if (code === 403) {
                console.log(`[SubBot] ⚠️ Sub-bot #${num} recibió error 403 (Forbidden).`);
                sendToOwner({ text: `⚠️ Sub-bot #${num} error 403 (Forbidden).\n\n💡 Usá \`.qr\` o \`.code\` para reconectar si es necesario.` });
                return;
            }

            // Otros errores de autenticación (405)
            if (code === 405) {
                console.log(`[SubBot] ⚠️ Sub-bot #${num} recibió un error de auth (${code}). Intentando reconectar sin borrar la sesión.`);
                sendToOwner({ text: `⚠️ Sub-bot #${num} tuvo un error de auth (${code}). Se reintentará reconexión automática.` });
                try { invalidateBaileysVersionOnAuthFailure(); } catch (_) {}
            }

            // ── Encolar reconexión con control de cola, concurrencia y detección de caída masiva ──
            registerDisconnection(num, ownerJid, conn);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // ── Anunciar cambios de admin en grupos (promote/demote externos) ────────
    sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
        if (action !== 'promote' && action !== 'demote') return;
        try {
            for (const participantJid of participants) {
                const targetNum = participantJid.split('@')[0].split(':')[0];
                const msg = action === 'promote'
                    ? `👑 *@${targetNum} ahora es administrador del grupo*`
                    : `👤 *@${targetNum} ya no es administrador del grupo*`;
                await sock.sendMessage(id, { text: msg, mentions: [participantJid] });
            }
        } catch {}
    });

        const processedIds = new Set();
        const processedIdTs = new Map(); // timestamp de cada id para TTL real
        const recentGroupMessages = new Map();
        const RECENT_MESSAGE_TTL  = 2 * 60 * 1000; // 2 minutos
        const PROCESSED_ID_TTL    = 3 * 60 * 1000; // 3 minutos (evita re-procesamiento sin crecer)
        const MAX_SUBBOT_PROCESSED_IDS = 500; // Límite LRU para no inflar RAM por subbot

        const cleanupTimer = setInterval(() => {
            const now = Date.now();

            // Limpiar recentGroupMessages (mensajes borrados)
            for (const [groupId, groupMap] of recentGroupMessages.entries()) {
                for (const [msgId, msg] of groupMap.entries()) {
                    const ts = (msg.messageTimestamp || 0) * 1000;
                    if (!ts || now - ts > RECENT_MESSAGE_TTL) {
                        groupMap.delete(msgId);
                    }
                }
                if (groupMap.size === 0) recentGroupMessages.delete(groupId);
            }

            // Limpiar processedIds por TTL (evita que el Set crezca sin control en grupos activos)
            for (const [id, ts] of processedIdTs.entries()) {
                if (now - ts > PROCESSED_ID_TTL) {
                    processedIds.delete(id);
                    processedIdTs.delete(id);
                }
            }
        }, 30000);
        sock._cacheCleanupInterval = cleanupTimer;

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const baileyMessage of messages) {
                if (!baileyMessage.message) continue;

                const remoteJid = baileyMessage.key?.remoteJid;
                const msgTs = (baileyMessage.messageTimestamp || 0) * 1000;
                if (msgTs > 0 && (Date.now() - msgTs) > 120000) continue;

                const messageId = baileyMessage.key.id;

                if (processedIds.has(messageId)) continue;
                if (processedIds.size >= MAX_SUBBOT_PROCESSED_IDS) {
                    const oldestKey = processedIds.keys().next().value;
                    if (oldestKey) {
                        processedIds.delete(oldestKey);
                        processedIdTs.delete(oldestKey);
                    }
                }
                processedIds.add(messageId);
                processedIdTs.set(messageId, Date.now());

                // Procesar cada mensaje en el siguiente tick (setImmediate) para distribuir el event loop
                setImmediate(async () => {
                    const isOfficialGroup = remoteJid === OFFICIAL_GROUP;
                    const isGroupMsg = typeof remoteJid === 'string' && remoteJid.endsWith('@g.us');
                    const isSpecialSubbotGroup = SPECIAL_SUBBOT_GROUPS.includes(remoteJid);

                    // 1. Regla ultrarrápida para Grupo Oficial:
                    // Si el subbot NO está en la lista blanca del grupo oficial, descartar de inmediato (<0.001ms)
                    // a menos que sea un comando de gestión (.gofc / .gofcbots).
                    let isGofcCmd = false;
                    if (isOfficialGroup && !isSubbotAllowedInOfficial(num)) {
                        const rawMsgText = getMessageText(baileyMessage);
                        const trimmedText = typeof rawMsgText === 'string' ? rawMsgText.trim() : '';
                        isGofcCmd = /^[./❤️#👅😎]?(gofc|gofcbots)\b/i.test(trimmedText);
                        if (!isGofcCmd) return;
                    }

                    const rawMsgText = getMessageText(baileyMessage);

                    // 2. Coordinación Inteligente de Subbots en Grupos Compartidos:
                    // Evalúa elegibilidad (on/off en grupo, modo de anuncio, permisos de admin requeridos)
                    // y balancea la carga equitativamente entre los subbots calificados.
                    let groupPolicyValidated = false;
                    if (isGroupMsg && !isGofcCmd && !baileyMessage.key.fromMe) {
                        try {
                            const coordination = await subbotCoordinator.shouldHandleGroupMessage({
                                groupJid: remoteJid,
                                messageId,
                                msgText: rawMsgText,
                                currentBotNum: num,
                                sock,
                                senderJid: baileyMessage.key.participant || remoteJid
                            });
                            if (coordination && typeof coordination === 'object' && coordination.status === 'admin-unavailable') {
                                const warning = coordination.reason === 'unverified'
                                    ? '❌ No se pudo verificar qué bot tiene permisos de administrador. No ejecuté la acción por seguridad.'
                                    : '❌ Ningún bot conectado que esté en este grupo es administrador. Dale administrador a uno de los bots e intenta nuevamente.';
                                await sock.sendMessage(remoteJid, { text: warning }, { quoted: baileyMessage }).catch(() => {});
                                return;
                            }
                            if (!coordination) return;
                            groupPolicyValidated = true;
                        } catch (coordinationError) {
                            const parsed = subbotCoordinator.parseCommand(rawMsgText || '');
                            if (subbotCoordinator.isBotAdminRequired(parsed?.commandName)) {
                                await sock.sendMessage(remoteJid, {
                                    text: '❌ No se pudo verificar el administrador disponible. La acción fue cancelada por seguridad.'
                                }, { quoted: baileyMessage }).catch(() => {});
                                return;
                            }
                            console.error(`[SubBot #${num}] Error coordinando mensaje:`, coordinationError?.message || coordinationError);
                        }
                    }

                    // ── Verificar y eliminar mensajes de usuarios muteados ────────────
                    if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        if (baileyMessage.message.protocolMessage?.type === 0 && baileyMessage.message.protocolMessage?.key) {
                            const deletedKey = baileyMessage.message.protocolMessage.key;
                            const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid);
                            const original = groupMap?.get(deletedKey.id);

                            if (original && isBorradosEnabled(baileyMessage.key.remoteJid)) {
                                if (subbotCoordinator.shouldHandleGroupEvent(baileyMessage.key.remoteJid, `borrado_${deletedKey.id}`, num)) {
                                    await _handleBorradoMessage(sock, baileyMessage.key.remoteJid, original);
                                }
                            }
                            return;
                        }

                        const groupMap = recentGroupMessages.get(baileyMessage.key.remoteJid) || new Map();
                        groupMap.set(messageId, baileyMessage);
                        recentGroupMessages.set(baileyMessage.key.remoteJid, groupMap);
                    }

                    if (global.muteSystem && baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const wasDeleted = await global.muteSystem.checkAndDeleteMutedMessage(baileyMessage, sock);
                            if (wasDeleted) return;
                        } catch (e) { /* silencioso */ }
                    }

                    // ── ChatMod (moderación de lenguaje en grupos) ──
                    if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const chatmod = require('../chatmod');
                            if (typeof chatmod.checkAndModerateMessage === 'function') {
                                const wasDeleted = await chatmod.checkAndModerateMessage(baileyMessage, sock);
                                if (wasDeleted) return;
                            }
                        } catch (e) { /* silencioso */ }
                    }



                    // ── Verificación de estado on/off del subbot (CRÍTICO: debe ir ANTES de procesar comandos) ──
                    // Esta verificación temprana evita que el subbot procese mensajes cuando está apagado.
                    // Se requiere aquí porque el handler.js verifica DESPUÉS de que el mensaje llegó,
                    // pero necesitamos bloquearlo ANTES en el subbot para evitar procesamiento innecesario.
                    // Usar referencias cacheadas al nivel del módulo (más rápido que require() en cada mensaje)
                    // Las funciones internas siguen leyendo el JSON fresco cada vez que se llaman.
                    const subbotOnOffModule = _subbotOnOffModule;
                    const botsAdminsModule  = _botsAdminsModule;

                    // ── Respuestas automáticas con caché de TTL ──
                    if (baileyMessage.key.remoteJid?.endsWith('@g.us') && !baileyMessage.key.fromMe) {
                        try {
                            const isGroupEnabled = typeof botsAdminsModule?.isBotEnabled === 'function' ? botsAdminsModule.isBotEnabled(remoteJid) !== false : true;
                            const isSubEnabled = typeof subbotOnOffModule?.isSubBotEnabled === 'function' ? subbotOnOffModule.isSubBotEnabled(remoteJid, num) : true;

                            if (isSpecialSubbotGroup || (isGroupEnabled && isSubEnabled)) {
                                const respData = getRespuestasUsuariosSubbotData();
                                const senderNum = (baileyMessage.key.participant || remoteJid).split('@')[0].split(':')[0];
                                const isMuted = global.muteSystem?.isUserMuted(remoteJid, senderNum);
                                if (!isMuted && respData[remoteJid]?.[senderNum]?.length) {
                                    const lista = respData[remoteJid][senderNum];
                                    const texto = lista[Math.floor(Math.random() * lista.length)];
                                    await sock.sendMessage(remoteJid, { text: texto }, { quoted: baileyMessage });
                                }
                            }
                        } catch (e) { /* silencioso */ }
                    }

                    const msgText    = getMessageText(baileyMessage);
                    const hasPrefix  = ['.', '/', '❤️', '#', '👅', '😎'].some(p => msgText.startsWith(p));
                    const msgChatJid = baileyMessage.key.remoteJid;

                    // ── VERIFICACIÓN CRÍTICA: Estado on/off del subbot ANTES de procesar comandos ──
                    // Esta verificación intercepta los mensajes con comando ANTES de enviarlos al handler.
                    // Si el subbot está apagado (.bot off) o el grupo está apagado (.bots off),
                    // bloquea todos los comandos EXCEPTO .bot, .bots, .onmybot, .offmybot (que deben pasar siempre).
                    if (hasPrefix && subbotOnOffModule && botsAdminsModule && !groupPolicyValidated) {
                        try {
                            const isGroupMsg = msgChatJid?.endsWith('@g.us');
                            const isPrivMsg = msgChatJid?.endsWith('@s.whatsapp.net');

                            // Verificar respuestas en privados/grupos
                            if (isPrivMsg && typeof subbotOnOffModule.isSubBotRespondsInPriv === 'function') {
                                if (!subbotOnOffModule.isSubBotRespondsInPriv(num)) {
                                    // Extraer comando
                                    const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                    const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                    const [commandName] = commandText.split(/\s+/);
                                    // Permitir solo comandos de gestión
                                    if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                        return; // Bloquear silenciosamente
                                    }
                                }
                            }

                            if (isGroupMsg && typeof subbotOnOffModule.isSubBotRespondsInGrupos === 'function') {
                                if (!isSpecialSubbotGroup && !subbotOnOffModule.isSubBotRespondsInGrupos(num)) {
                                    const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                    const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                    const [commandName] = commandText.split(/\s+/);
                                    if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                        return; // Bloquear silenciosamente
                                    }
                                }
                            }

                            // ═══════════════════════════════════════════════════════════════════
                            // JERARQUÍA DE PRIORIDAD (de mayor a menor):
                            // 1. .bots off → BLOQUEA TODOS LOS SUBBOTS (sin excepciones)
                            // 2. .bots admins → Solo admins pueden usar comandos
                            // 3. .bot off → Bloquea este subbot específico
                            // 4. .bot on (explícito) → Excepción para bypass global off
                            // ═══════════════════════════════════════════════════════════════════

                            // Verificar estado del grupo PRIMERO (máxima prioridad)
                            const groupBotStatus = isGroupMsg && typeof botsAdminsModule.isBotEnabled === 'function'
                                ? botsAdminsModule.isBotEnabled(msgChatJid)
                                : true;

                            // PRIORIDAD 1: Si .bots off está activo, bloquear salvo excepción explícita (.bot on)
                            const hasExplicitException = typeof subbotOnOffModule.isSubBotExplicitlyEnabled === 'function'
                                ? subbotOnOffModule.isSubBotExplicitlyEnabled(msgChatJid, num)
                                : false;
                            if (isGroupMsg && !isSpecialSubbotGroup && groupBotStatus === false && !hasExplicitException) {
                                const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                const [commandName] = commandText.split(/\s+/);

                                // Solo permitir comandos de gestión (.bot, .bots, etc)
                                if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                    return; // 🚫 BLOQUEADO por .bots off (prioridad máxima)
                                }
                            }

                            // PRIORIDAD 2: Modo solo admins (.bots admins)
                            if (isGroupMsg && groupBotStatus === 'admins') {
                                try {
                                    const senderJid = baileyMessage.key.participant || baileyMessage.key.remoteJid;
                                    const senderNum = senderJid.split('@')[0].split(':')[0];

                                    // Cargar metadata del grupo para verificar si es admin (usando cache centralizado)
                                    const groupMetadata = await getGroupMetadataCached(sock, msgChatJid);
                                    const participants = groupMetadata?.participants || [];
                                    
                                    const senderParticipant = participants.find(p => 
                                        p.id.split('@')[0].split(':')[0] === senderNum
                                    );
                                    const isAdmin = senderParticipant && 
                                        (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');

                                    if (!isAdmin) {
                                        // No es admin: solo permitir comandos de gestión
                                        const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                        const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                        const [commandName] = commandText.split(/\s+/);
                                        if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                            return; // 🚫 BLOQUEADO por .bots admins (no eres admin)
                                        }
                                    }
                                } catch (e) { /* silencioso */ }
                            }

                            // PRIORIDAD 3 y 4: Verificar estado individual del subbot (.bot on/off)
                            // Solo aplica si .bots off no está activo (ya fue verificado arriba)
                            const isSubEnabled = isSpecialSubbotGroup
                                ? true
                                : typeof subbotOnOffModule.isSubBotEnabled === 'function'
                                ? subbotOnOffModule.isSubBotEnabled(msgChatJid, num) 
                                : true;

                            // Si el subbot está apagado individualmente (.bot off)
                            if (isSubEnabled === false) {
                                const prefixUsed = ['.', '/', '❤️', '#', '👅', '😎'].find(p => msgText.startsWith(p));
                                const commandText = prefixUsed ? msgText.slice(prefixUsed.length).trim() : msgText;
                                const [commandName] = commandText.split(/\s+/);

                                // Permitir SIEMPRE los comandos de gestión
                                if (!/^(bot|onmybot|offmybot|bots)$/i.test(commandName)) {
                                    return; // 🚫 BLOQUEADO por .bot off (subbot individual)
                                }
                            }

                            // Si llegamos aquí: el mensaje está permitido (continuar procesamiento normal)

                        } catch (verifyError) {
                            console.error('[SubBot] Error verificando estado on/off:', verifyError.message);
                            // En caso de error en la verificación, permitir el comando (fail-open)
                        }
                    }

                    // ── Registro de actividad de usuario (Asíncrono no bloqueante) ──
                    if (!baileyMessage.key.fromMe && isGroupMsg) {
                        try {
                            const senderJidRec = baileyMessage.key.participant || msgChatJid;
                            const cleanSenderRec = senderJidRec.split('@')[0].split(':')[0].replace(/\D/g, '');
                            const msgTimestamp = (baileyMessage.messageTimestamp || 0) * 1000;
                            if (chatHistory.isReady) {
                                chatHistory.recordMessage(msgChatJid, cleanSenderRec, msgText, msgTimestamp);
                            }
                        } catch (actErr) { /* silencioso */ }
                    }

                    const hasQuotedContext = (msg) => {
                        const ctx = msg?.contextInfo
                                 || msg?.extendedTextMessage?.contextInfo
                                 || msg?.extendedTextMessageV2?.contextInfo
                                 || msg?.buttonsResponseMessage?.contextInfo
                                 || msg?.listResponseMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.ephemeralMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessage?.contextInfo
                                 || msg?.viewOnceMessage?.message?.extendedTextMessageV2?.contextInfo
                                 || null;
                        return !!(ctx?.quotedMessage || ctx?.stanzaId || ctx?.participant);
                    };

                    const isQuotedReply = hasQuotedContext(baileyMessage.message);

                    if (baileyMessage.key.fromMe && !hasPrefix && !isQuotedReply) return;
                    if (shouldIgnoreFromMePrivateMessage(baileyMessage, sock)) return;
                    if (!msgText && !hasPrefix) return;
                    if (msgChatJid === OFFICIAL_GROUP && !isSubbotAllowedInOfficial(num)) return;

                    try {
                        if (!global.db?.data) return;
                        const compatibleMessage   = createCompatibleMessage(baileyMessage, sock);
                        compatibleMessage._sock   = sock;
                        compatibleMessage._subNum = num;
                        compatibleMessage._groupPolicyValidated = groupPolicyValidated;

                        if (hasPrefix) {
                            activityTracker.recordActivity(num);
                        }

                        const prevLastMsg = global.lastBaileyMessage;
                        global.lastBaileyMessage = baileyMessage;

                        try {
                            if (global.commandHandler?.handleMessage)
                                await global.commandHandler.handleMessage(compatibleMessage);
                        } finally {
                            global.lastBaileyMessage = prevLastMsg;
                        }
                    } catch (e) {
                        if (!e.message?.includes('Connection Closed'))
                            console.error(`[SubBot] Error procesando mensaje:`, e.message);
                    }
                });

                // El tracker escribe en RAM y carga el JSON solo la primera vez; hacerlo
                // después de encolar el procesamiento evita que bloquee la respuesta.
                if (remoteJid && baileyMessage.key) {
                    setImmediate(() => {
                        try { chatTracker.trackChat(num, remoteJid, baileyMessage.key, baileyMessage.messageTimestamp); } catch (_) {}
                    });
                }
            }
        });
}

// ─── Helpers ────────────────────────────────────────────────────────────────
function isSubBotMessage(message) { return !!(message._subNum); }

function getMainBotNumber() {
    try {
        const id = (global.conn?.user?.id || '');
        return id.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    } catch { return null; }
}

// ─── Fuerza cierre limpio de un subbot y lo reconecta ───────────────────────
async function forceReconnectSubBot({ num, chatJid, conn }) {
    const name     = String(num);
    const prevSock = activeSocks.get(name);

    if (prevSock) {
        destroySubBotSocket(prevSock);
    }

    if (reconnectTimers.has(name)) {
        clearTimeout(reconnectTimers.get(name));
        reconnectTimers.delete(name);
    }

    await sleep(300);
    return connectSubBot({ num, chatJid: chatJid || null, conn: conn || global.conn });
}

// ════════════════════════════════════════════════════════════════════════════
//  GESTIÓN DE SUBBOTS ACTIVOS (SIN LÍMITE)
// ════════════════════════════════════════════════════════════════════════════
const MAX_ACTIVE_SUBBOTS = Infinity;

/**
 * Cuenta cuántos subbots están realmente activos y conectados
 * @returns {number} Cantidad de subbots activos
 */
function countActiveSubBots() {
    if (!global.subConns || !Array.isArray(global.subConns)) return 0;
    
    let activeCount = 0;
    for (const subSock of global.subConns) {
        if (subSock?.user && subSock.ws && subSock.ws.readyState === 1) {
            activeCount++;
        }
    }
    return activeCount;
}

/**
 * Informa el estado de subbots (sin límite de creación).
 */
function canCreateNewSubBot() {
    const confirmedCount = countConfirmedSubBots();
    const activeCount    = countActiveSubBots();
    const current        = Math.max(confirmedCount, activeCount);
    return {
        allowed: true,
        current,
        max: Infinity,
        confirmedCount,
        activeCount
    };
}

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .serbot | .qr | .code
// ════════════════════════════════════════════════════════════════════════════
const serbotHandler = {
    command: /^(serbot|jadibot|qr|code)$/i,
    help: 'Crear sub-bot. Uso: .qr | .code',
    tags: ['subbots'],
    handler: async (message, { args } = {}) => {
        const sock = message._sock || global.conn;

        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        // El QR/código se manda siempre en el mismo chat donde se usó el comando
        const replyDest = message.from;

        // Los subbots SÍ pueden procesar .serbot/.qr/.code — simplemente usan su propio socket

        const rawCmd       = (message.text || message.body || '').trim().replace(/^([.\/❤️#👅😎])\s+/, '$1').slice(1).split(/\s+/)[0].toLowerCase();
        const isDirectQR   = rawCmd === 'qr';
        const isDirectCode = rawCmd === 'code';

        const senderJid = message.author || message.sender || message.from;
        const allArgs   = (args || []).filter(a => a.trim() !== '');
        const connectWithFeedback = async (options) => {
            try {
                return await connectSubBot(options);
            } catch (error) {
                pendingQR.delete(senderJid);
                console.error(`[SubBot] Error iniciando vinculación de #${options.num}:`, error);
                return sock.sendMessage(replyDest, {
                    text: `❌ No se pudo iniciar la vinculación del sub-bot #${options.num}: ${error.message}`
                }, { quoted: message._baileyMessage });
            }
        };

        let arg0    = isDirectQR ? 'qr' : isDirectCode ? 'code' : (allArgs[0] || '').trim().toLowerCase();
        let codeRaw = '';

        if (isDirectCode) {
            // Normalizar el texto para que ". code 1234" y ".code 1234" se traten igual
            const fullText = (message.text || message.body || '').trim().replace(/^([.\/❤️#👅😎])\s+/, '$1');
            const spaceIdx = fullText.indexOf(' ');
            codeRaw = spaceIdx >= 0 ? fullText.slice(spaceIdx).trim() : '';
        } else {
            codeRaw = allArgs.slice(1).join('');
        }

        let usePairingCode = false;
        let phoneNumber    = null;

        if (arg0 === 'qr') {
            usePairingCode = false;
        } else if (arg0 === 'code') {
            const cleanedNumber = codeRaw.replace(/[^0-9]/g, '');
            if (!cleanedNumber) {
                const key      = message.key || {};
                // En grupos el sender real está en participant, no en remoteJid
                const jidReal  = key.participantAlt || key.remoteJidAlt || key.participant || senderJid;
                const autoNum  = jidReal ? jidReal.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') : null;
                if (!autoNum || autoNum.length < 7)
                    return sock.sendMessage(replyDest, { text: `❌ No pude detectar tu número. Usá \`.code <numero>\`` }, { quoted: message._baileyMessage });
                usePairingCode = true;
                phoneNumber    = autoNum;
            } else {
                usePairingCode = true;
                phoneNumber    = cleanedNumber;
            }
        } else {
            return sock.sendMessage(replyDest, { text: '📌 Opciones: \`.qr\` o \`.code\`' }, { quoted: message._baileyMessage });
        }

        cleanExpiredPending();
        if (pendingQRHas(senderJid)) {
            const secsLeft = pendingQRSecondsLeft(senderJid);
            const pendingMessage = secsLeft > 0
                ? `⏳ Ya tenés un proceso en curso. Podés pedir un nuevo código en *${secsLeft} segundo${secsLeft !== 1 ? 's' : ''}*.`
                : `⏳ Ya tenés un proceso pendiente. Si el anterior expiró o falló, espera unos segundos y volvé a intentarlo.`;
            return sock.sendMessage(replyDest, { text: pendingMessage }, { quoted: message._baileyMessage });
        }

        const targetJid  = `${usePairingCode ? phoneNumber : senderJid.split('@')[0].split(':')[0]}@s.whatsapp.net`;
        const existingNum = getSubBotNumberByOwner(targetJid);

        // ── Verificar que el número existe en WhatsApp (solo para .code) ────
        if (usePairingCode && phoneNumber) {
            const connForCheck = sock?.user ? sock : (global.conn?.user ? global.conn : (global.subConns || []).find(c => c?.user) || null);
            if (connForCheck && typeof connForCheck.onWhatsApp === 'function') {
                try {
                    const results = await connForCheck.onWhatsApp(`${phoneNumber}@s.whatsapp.net`);
                    const result  = Array.isArray(results) ? results[0] : null;
                    const exists  = !!(result && (result.exists === true || result.jid));
                    if (!exists) {
                        return sock.sendMessage(replyDest, {
                            text:
                                `❌ El número de teléfono no pertenece a una cuenta de WhatsApp activa.\n` +
                                `📱 *Número:* +${phoneNumber}\n\n` +
                                `⚠️ Si estás usando la opción de WhatsApp para *ocultar tu número de teléfono*, deberás desactivarla.\n\n` +
                                `De lo contrario podés usar:\n` +
                                `▸ \`.code <tu número>\` — ingresá tu número en formato internacional\n\n` +
                                `Si no sabés cuál es tu número en formato internacional podés usar:\n` +
                                `▸ \`.numwa <país> <número local>\` — para obtenerlo`
                        }, { quoted: message._baileyMessage });
                    }
                } catch (e) {
                    console.warn(`[SubBot] ⚠️ No se pudo verificar el número +${phoneNumber}: ${e.message}`);
                }
            }
        }

        if (existingNum !== null) {
            const existingBot = global.subConns.find(c => c._subNum === existingNum && c.user);
            if (existingBot) {
                if (existingBot.ws?.readyState === 1) {
                    return sock.sendMessage(replyDest, {
                        text: `ℹ️ Ya tenés el Sub-Bot #${existingNum} activo.\n💡 _Si no te está contestando, mandá *.reconnect* para reiniciar su sistema._`
                    }, { quoted: message._baileyMessage });
                } else {
                    try { existingBot.ev.removeAllListeners(); existingBot.ws.close(); } catch {}
                    activeSocks.delete(String(existingNum));
                    const ci = global.subConns.indexOf(existingBot);
                    if (ci >= 0) global.subConns.splice(ci, 1);
                }
            }

            pendingQRAdd(senderJid, usePairingCode ? 95000 : 40000);
            sock.sendMessage(replyDest, { text: `⏳ Generando nueva sesión para tu sub-bot #${existingNum}...` }, { quoted: message._baileyMessage });
            return connectWithFeedback({ num: existingNum, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true, replyQuote: message._baileyMessage, pendingKey: senderJid });
        }

        const num = nextSubBotNumber();
        pendingQRAdd(senderJid, usePairingCode ? 95000 : 40000);
        sock.sendMessage(replyDest, { text: `⏳ Generando acceso para sub-bot #${num}...` }, { quoted: message._baileyMessage });
        return connectWithFeedback({ num, chatJid: replyDest, conn: sock, usePairingCode, phoneNumber, isNewLinking: true, replyQuote: message._baileyMessage, pendingKey: senderJid });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .reconnect | .codebot
//  → Lo puede usar el owner del subbot O el propio subbot
//  → Desconecta y reconecta al 100% aunque esté "activo"
// ════════════════════════════════════════════════════════════════════════════
const reconnectHandler = {
    command: /^(reconnect|codebot)$/i,
    help: 'Reconectar tu sub-bot al 100%. Solo el owner o el propio sub-bot pueden usarlo.',
    tags: ['subbots'],
    handler: async (message) => {
        const sock      = message._sock || global.conn;
        const senderJid = message.author || message.sender || message.from;

        if (message.isGroup)
            return sock.sendMessage(message.from, { text: '❌ Este comando solo se usa por privado.' }, { quoted: message._baileyMessage });

        // Si lo manda el propio subbot, usamos ese número directamente
        let numToReconnect = message._subNum || null;

        // Si no, buscamos si el sender es owner de algún subbot
        if (!numToReconnect) numToReconnect = getSubBotNumberByOwner(senderJid);

        if (!numToReconnect) {
            return sock.sendMessage(message.from, {
                text: `❌ No tenés ningún sub-bot registrado para reconectar.`
            }, { quoted: message._baileyMessage });
        }

        await sock.sendMessage(message.from, {
            text: `🔄 Forzando reconexión completa del sub-bot #${numToReconnect}...\n⚠️ _Puede tardar unos segundos._`
        }, { quoted: message._baileyMessage });

        try {
            await forceReconnectSubBot({ num: numToReconnect, chatJid: senderJid, conn: global.conn || sock });
        } catch (e) {
            console.error(`[reconnect] Error reconectando subbot #${numToReconnect}:`, e.message);
            sock.sendMessage(message.from, { text: `⚠️ Error al reconectar: ${e.message}` });
        }
    }
};


// ════════════════════════════════════════════════════════════════════════════
//  HANDLER: .listbots | .bots | .subbots
// ════════════════════════════════════════════════════════════════════════════
const listBotsHandler = {
    command: /^(listbots|subbots)$/i,
    help: 'Ver sub-bots activos',
    tags: ['subbots'],
    handler: async (message) => {
        if (message.from === OFFICIAL_GROUP && isSubBotMessage(message) && !isSubbotAllowedInOfficial(message._subNum)) return;

        const sock   = message._sock || global.conn;
        const active = global.subConns.filter(c => c.user).sort((a, b) => a._subNum - b._subNum);
        const lines  = [];

        if (global.conn?.user) {
            const mainPhoneNum = global.conn.user.id.split('@')[0].split(':')[0];
            lines.push(`🟢 *Bot Principal*\n📱 wa.me/+${mainPhoneNum}`);
        }

        active.forEach(c => {
            const phoneNum = c.user.id.split('@')[0].split(':')[0];
            lines.push(`🤖 *SubBot #${c._subNum}*\n📱 wa.me/+${phoneNum}`);
        });

        if (lines.length === 0)
            return sock.sendMessage(message.from, { text: '📭 No hay bots conectados.' });

        sock.sendMessage(message.from, {
            text: `🤖 *Bots activos: ${(global.conn?.user ? 1 : 0) + active.length}*\n\n${lines.join('\n\n')}\n\n💡 _Si tu sub-bot se tranca, mandá *.reconnect* para destrabarlo._`
        });
    }
};

// ════════════════════════════════════════════════════════════════════════════
//  Auto-reconexión al iniciar el bot - OPTIMIZADO CON PRIORIZACIÓN Y PARALELISMO
// ════════════════════════════════════════════════════════════════════════════
async function autoReconnectSubBots(conn) {
    if (isAutoReconnecting) {
        console.log(`[SubBot Monitor] ⚠️ Reconexión ya en proceso. Omitiendo barrido duplicado.`);
        return;
    }
    isAutoReconnecting = true;
    try {
        // conn puede ser null si el bot principal aún no se conectó/escaneó.
        // Los subbots tienen sus propias sesiones y se conectan de forma independiente.
        if (!fs.existsSync(SESSIONS_DIR)) return;

        const nums = fs.readdirSync(SESSIONS_DIR)
            .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
            .filter(n => !isNaN(n));

        console.log(`[SubBot Monitor] Analizando bases de datos de sub-bots...`);
        console.log(`[SubBot Monitor] Encontrados ${nums.length} subbots registrados`);

        // ── Preparar subbots para reconexión (sin borrar ninguna sesión) ─────────
        const validNums = [];
        for (const num of nums) {
            const dbFile = sessionPath(num);
            if (!fs.existsSync(dbFile)) continue;
            if (activeSocks.has(String(num)) || connectingSubBots.has(String(num))) continue;
            validNums.push(num);
        }

        // ── Limpiar registros de actividad de subbots eliminados ─────────────────
        activityTracker.cleanupInvalidRecords([...validNums, ...nums]);

        if (validNums.length === 0) {
            console.log(`[SubBot Monitor] ✅ No hay subbots para reconectar`);
            return;
        }

        // ── Ordenar por total de comandos (más usado primero). En empate: más reciente primero ──
        const sortedNums = activityTracker.getSortedByActivity(validNums);

        console.log(`[SubBot Monitor] 🔄 Reconectando ${sortedNums.length} subbots ordenados por actividad (más usado primero)...`);

        // Mostrar el top 10 más activos para referencia
        const top10 = sortedNums.slice(0, 10);
        for (const num of top10) {
            const stats = activityTracker.getActivityStats(num);
            if (stats.commandCount > 0) {
                console.log(`[SubBot Monitor] 🥇 #${num}: ${stats.commandCount} comandos${stats.daysSinceLastUse !== null ? `, último uso hace ${stats.daysSinceLastUse} día(s)` : ''}`);
            } else {
                console.log(`[SubBot Monitor] 📭 #${num}: Sin historial (conectará al final)`);
            }
        }
        if (sortedNums.length > 10) {
            console.log(`[SubBot Monitor] ... y ${sortedNums.length - 10} subbots más sin historial o de menor actividad.`);
        }

        // ════════════════════════════════════════════════════════════════════════
        // CONFIGURACIÓN DE RECURSOS - ESCALONAMIENTO SEGURO
        // ════════════════════════════════════════════════════════════════════════
        const PARALLEL_CONNECTIONS = 12;     // 12 subbots por lote (más rápido con 150+ subbots)
        const DELAY_BETWEEN_BATCHES = 600;    // 600ms entre lotes (reducido para arranque más ágil)
        const DELAY_BETWEEN_BOTS = 80;        // 80ms entre bots dentro del mismo lote

        // ── Procesar en lotes paralelos ──────────────────────────────────────────
        for (let i = 0; i < sortedNums.length; i += PARALLEL_CONNECTIONS) {
            const batch = sortedNums.slice(i, i + PARALLEL_CONNECTIONS);
            const batchNum = Math.floor(i / PARALLEL_CONNECTIONS) + 1;
            const totalBatches = Math.ceil(sortedNums.length / PARALLEL_CONNECTIONS);
            
            console.log(`[SubBot Monitor] 🔄 Lote ${batchNum}/${totalBatches}: Conectando subbots ${batch.join(', ')}`);
            
            // Conectar todos los bots del lote en paralelo
            const promises = batch.map((num, index) => {
                return (async () => {
                    try {
                        if (index > 0) {
                            await sleep(DELAY_BETWEEN_BOTS * index);
                        }
                        
                        const startTime = Date.now();
                        await connectSubBot({ num, chatJid: null, conn });
                        const duration = Date.now() - startTime;
                        
                        console.log(`[SubBot Monitor] ✅ SubBot #${num} conectado en ${duration}ms`);
                    } catch (e) {
                        console.error(`[SubBot Monitor] ❌ Error conectando subbot #${num}:`, e.message);
                    }
                })();
            });
            
            await Promise.all(promises);
            
            if (i + PARALLEL_CONNECTIONS < sortedNums.length) {
                console.log(`[SubBot Monitor] ⏳ Esperando ${DELAY_BETWEEN_BATCHES}ms antes del siguiente lote...`);
                await sleep(DELAY_BETWEEN_BATCHES);
            }
        }
        
        console.log(`[SubBot Monitor] ✅ Proceso de reconexión completado. ${sortedNums.length} subbots procesados.`);
    } finally {
        isAutoReconnecting = false;
    }
}

async function connectSubBotWeb({ num, conn }) {
    if (isAutoReconnecting) {
        throw new Error('Reconexión de sub-bots en curso. Por favor esperá a que terminen de reconectarse todos.');
    }
    return connectSubBot({ num, chatJid: null, conn, isNewLinking: true });
}

async function connectSubBotWebWithCode({ num, conn, phoneNumber }) {
    if (isAutoReconnecting) {
        throw new Error('Reconexión de sub-bots en curso. Por favor esperá a que terminen de reconectarse todos.');
    }
    return connectSubBot({ num, chatJid: null, conn, usePairingCode: true, phoneNumber, isNewLinking: true });
}

// ════════════════════════════════════════════════════════════════════════════
//  EXPORTS — todos los handlers en un solo archivo
// ════════════════════════════════════════════════════════════════════════════
module.exports = {
    // Handler principal (.serbot / .qr / .code)
    command:             serbotHandler.command,
    help:                serbotHandler.help,
    tags:                serbotHandler.tags,
    handler:             serbotHandler.handler,
    apodo:               true,

    // Sub-handlers extras exportados como objetos separados
    // El loader de plugins los registra si los encontrás en module.exports
    reconnect:           reconnectHandler,
    listBots:            listBotsHandler,

    // Funciones internas usadas por otros módulos
    autoReconnectSubBots,
    connectSubBotWeb,
    connectSubBotWebWithCode,
    nextSubBotNumber,
    connectSubBot,        // exportado para uso externo si hiciera falta
    activeSocks,
    getSubBotNumberByOwner,
    removeSessionFiles,
    destroySubBotSocket,
    forgetSubBot,
    deletedSubBots,
    enqueueChannelFollow,
    countConfirmedSubBots,
    canCreateNewSubBot,
    isSubBotReconnecting: () => isAutoReconnecting,
};