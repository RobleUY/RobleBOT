'use strict';

/**
 * Comando .subbotsclean <número>
 * Elimina la cantidad indicada de subbots, empezando por los que tienen menos usos.
 * Los borra SIN importar si están conectados o desconectados.
 * Solo ejecutable por owners.
 *
 * Ejemplo: .subbotsclean 10  → elimina los 10 subbots con menos comandos ejecutados
 */

const fs   = require('fs');
const path = require('path');

const activityTracker = require('./subbotActivityTracker');
const { forgetSubBot, removeSessionFiles } = require('./subbot-serbot');
const SESSIONS_DIR = path.resolve(__dirname, 'sesiones');

// ── Helpers ────────────────────────────────────────────────────────────────
function listRegisteredNums() {
    if (!fs.existsSync(SESSIONS_DIR)) return [];
    return fs.readdirSync(SESSIONS_DIR)
        .map(f => { const m = f.match(/^(\d+)\.db$/); return m ? parseInt(m[1]) : NaN; })
        .filter(n => !isNaN(n));
}

/**
 * Borra un subbot de forma definitiva: primero lo purga de TODA la memoria
 * (sockets, colas de reconexión, timers) para que no se "reconecte solo" y
 * recree el .db, y recién después borra los archivos de sesión en disco.
 *
 * Devuelve true solo si el .db realmente dejó de existir.
 */
function wipeSubBot(num) {
    // 1) Purgar memoria/colas ANTES de tocar el disco. Esto es lo que evita
    //    que el listener de 'connection.update' reencole una reconexión que
    //    vuelva a crear el .db que estamos por borrar.
    try {
        forgetSubBot(num);
    } catch (e) {
        console.error(`[subbotsclean] Error purgando memoria de #${num}:`, e.message);
    }

    // 2) Borrar archivos de sesión (con reintentos y verificación real, force: true por ser comando explícito de owner).
    const { dbGone } = removeSessionFiles(num, { force: true });
    return dbGone;
}

// ── Handler ───────────────────────────────────────────────────────────────────
const handler = async (message) => {
    try {
        // ── Parsear argumento numérico ────────────────────────────────────────
        const rawBody = (message.body || message.text || '').trim();
        const parts   = rawBody.split(/\s+/);
        const count   = parseInt(parts[1] || '', 10);

        if (!count || isNaN(count) || count <= 0) {
            return await message.reply(
                '⚠️ *Uso:* `.subbotsclean <número>`\n\n' +
                '_Ejemplo:_ `.subbotsclean 10` — elimina los 10 subbots con menos usos.'
            );
        }

        // ── Obtener todos los subbots registrados en disco (snapshot inicial) ─
        const registeredNums = listRegisteredNums();
        const totalAntes = registeredNums.length;

        if (totalAntes === 0) {
            return await message.reply('📭 No hay subbots registrados.');
        }

        // ── Obtener datos de actividad y ordenar por usos ASC ────────────────
        const activityData = activityTracker.loadActivity();

        const botsWithStats = registeredNums.map(n => ({
            num:          n,
            commandCount: (activityData[String(n)]?.commandCount) || 0,
            lastUsed:     (activityData[String(n)]?.lastUsed)     || 0
        }));

        // Ordenar: menos usos primero; en empate, el menos recientemente usado
        botsWithStats.sort((a, b) => {
            if (a.commandCount !== b.commandCount) return a.commandCount - b.commandCount;
            return a.lastUsed - b.lastUsed;
        });

        // ── Limitar la cantidad a eliminar ────────────────────────────────────
        const toDelete  = botsWithStats.slice(0, count);
        const realCount = toDelete.length;

        if (realCount === 0) {
            return await message.reply('📭 No hay subbots para eliminar.');
        }

        // ── Confirmación con preview ──────────────────────────────────────────
        const preview = toDelete.map((b, i) =>
            `${i + 1}. SubBot #${b.num} — ⚡ ${b.commandCount} usos`
        ).join('\n');

        await message.reply(
            `🗑️ *Eliminando ${realCount} subbot${realCount !== 1 ? 's' : ''}...*\n\n` +
            `📋 *Lista (menor a mayor usos):*\n${preview}\n\n` +
            `⏳ _Procesando (se borran sin importar si están conectados)..._`
        );

        // ── Eliminar uno por uno ──────────────────────────────────────────────
        let eliminados = 0;
        let errores    = 0;
        const errList  = [];

        for (const bot of toDelete) {
            try {
                const dbGone = wipeSubBot(bot.num);
                if (dbGone) {
                    eliminados++;
                } else {
                    errores++;
                    errList.push(`#${bot.num}`);
                }
            } catch (e) {
                errores++;
                errList.push(`#${bot.num} (${e.message})`);
                console.error(`[subbotsclean] Error eliminando #${bot.num}:`, e.message);
            }
        }

        // ── Resumen final ─────────────────────────────────────────────────────
        const totalDespues = listRegisteredNums().length;
        const esperados    = totalAntes - eliminados;

        let resumen = `✅ *Limpieza completada*\n\n`;
        resumen += `🗑️ *Eliminados:* ${eliminados}\n`;
        if (errores > 0) {
            resumen += `⚠️ *No se pudieron borrar:* ${errores}\n`;
            if (errList.length > 0) resumen += `  _${errList.join(', ')}_\n`;
        }
        resumen += `\n📊 *Subbots antes:* ${totalAntes}\n`;
        resumen += `📊 *Subbots ahora:* ${totalDespues}`;

        if (totalDespues !== esperados) {
            const diff = totalDespues - esperados;
            resumen += `\n\n⚠️ _Nota: se esperaban ${esperados} restantes pero hay ${totalDespues}` +
                (diff > 0
                    ? ` (${diff} sesión${diff !== 1 ? 'es' : ''} nueva${diff !== 1 ? 's' : ''} se creó/crearon mientras corría el comando, ` +
                      `probablemente por vinculaciones nuevas con \`.qr\`/\`.code\` en simultáneo)._`
                    : `._`);
        }

        await message.reply(resumen);

    } catch (error) {
        console.error('[subbotsclean] Error general:', error.message);
        await message.reply('❌ Error al procesar el comando.').catch(() => {});
    }
};

handler.help    = ['subbotsclean <número>'];
handler.tags    = ['subbots'];
handler.command = /^subbotsclean(?:\s+\d+)?$/i;
handler.owner   = true;

module.exports = handler;