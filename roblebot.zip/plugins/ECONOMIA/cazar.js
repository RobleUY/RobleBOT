// --- Mapa en memoria para cooldowns ---
const cooldowns = new Map();
const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        // --- Cooldown en memoria (5 minutos comunes, 2.5 minutos premium) ---
        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        const cooldown = Math.floor(5 * 60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);
            if (remaining > 0) {
                const totalSeg = Math.ceil(remaining / 1000);
                const m = Math.floor(totalSeg / 60);
                const s = totalSeg % 60;
                const tiempoTexto = m > 0 ? `${m}m ${s}s` : `${s} segundos`;
                return await message.reply(`⏳ Debes esperar *${tiempoTexto}* para volver a cazar.`);
            }
        }

        // lista de animales y el precio (rango $100 - $200)
        const animales = [
            { nombre: "Furro", precio: 200 },
            { nombre: "Conejo", precio: 100 },
            { nombre: "Zorro", precio: 120 },
            { nombre: "Ciervo", precio: 140 },
            { nombre: "Jabalí", precio: 160 },
            { nombre: "Pato salvaje", precio: 110 },
            { nombre: "Oso pardo", precio: 190 },
            { nombre: "Lobo", precio: 170 },
            { nombre: "Mapache", precio: 130 },
            { nombre: "Serpiente", precio: 115 },
            { nombre: "Puma", precio: 195 },
            { nombre: "Águila", precio: 180 },
            { nombre: "Zorrillo", precio: 105 },
            { nombre: "Tortuga", precio: 125 },
            { nombre: "Iguana", precio: 110 },
            { nombre: "Jaguar", precio: 200 },
            { nombre: "Lechuza", precio: 120 },
            { nombre: "Búho", precio: 135 },
            { nombre: "Tiburón pequeño", precio: 200 },
            { nombre: "Rana", precio: 100 },
            { nombre: "Murciélago", precio: 105 },
            { nombre: "Cocodrilo", precio: 200 },
            { nombre: "Cabra montés", precio: 150 },
            { nombre: "Jirafa", precio: 200 },
            { nombre: "Elefante", precio: 200 },
            { nombre: "Hipopótamo", precio: 200 },
            { nombre: "Camello", precio: 180 },
            { nombre: "Avestruz", precio: 190 },
            { nombre: "Mono", precio: 155 },
            { nombre: "Tigre", precio: 200 },
            { nombre: "León", precio: 200 },
            { nombre: "Pantera", precio: 195 },
            { nombre: "Cebra", precio: 180 },
            { nombre: "Gacela", precio: 175 },
            { nombre: "Panda", precio: 200 },
        ];

        // Animal aleatorio
        const animal = animales[Math.floor(Math.random() * animales.length)];

        // Aplicar multiplicador según respeto actual (tope +50% de bonus)
        const respeto = Number(user.respeto) || 0;
        const respetoBonus = Math.min(1.5, 1 + respeto / 2000);
        const gananciaFinal = Math.floor(animal.precio * respetoBonus);
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        // Dinero ganado
        user.money += gananciaPremium;
        global.db.setUser(senderNumber, user);

        // Guardar el tiempo actual en memoria
        cooldowns.set(senderNumber, now);

        // Eliminar del mapa después del cooldown (para no llenar la RAM)
        setTimeout(() => cooldowns.delete(senderNumber), cooldown);

        let response = `_Cazaste 1_ *${animal.nombre}* _y ganaste_ *$${gananciaPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando cazar:', error);
        return await message.reply('❌ Ocurrió un error al intentar cazar.');
    }
};

handler.help = ['cazar'];
handler.tags = ['economy'];
handler.command = /^cazar|hunt$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;