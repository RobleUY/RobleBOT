const achievements = require('../../achievements');
const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        // Asegurarnos de que el usuario existe en la base de datos
        let user = global.db.getUser(senderNumber);

        if (!user) {
            user = {
                money: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0
            };
            global.db.setUser(senderNumber, user);
        }

        // Verificar si el usuario tiene lastWork inicializado
        if (!user.lastWork) {
            user.lastWork = 0;
        }

        let timeDiff = Date.now() - (new Date(user.lastWork)).getTime();
        const userJidForPrem = senderJid || senderNumber;
        const premiumMultiplier = premium.isPremium(userJidForPrem) ? 0.5 : 1;
        let waitTime = Math.floor(5 * 60 * 1000 * premiumMultiplier);  // 5 minutos comunes, 2.5 minutos si es premium

        if (timeDiff < waitTime) {
            const totalSeg = Math.ceil((waitTime - timeDiff) / 1000);
            const m = Math.floor(totalSeg / 60);
            const s = totalSeg % 60;
            const tiempoTexto = m > 0 ? `${m}m ${s}s` : `${s} segundos`;
            return await message.reply(`*⏰ DEBES ESPERAR ${tiempoTexto} ANTES DE TRABAJAR NUEVAMENTE.*`);
        }

        // Lista de trabajos disponibles
        let trabajos = [
            "programador", "diseñador", "escritor", "mesero", "conductor", "pintor", "jardinero", "chef", 
            "repartidor", "cajero", "vendedor", "músico", "modelo", "actor", "profesor", "ingeniero", "arquitecto", 
            "doctor", "enfermero", "fotógrafo", "astrónomo"
        ];
        
        // Selección aleatoria de trabajo
        let trabajoActual = trabajos[Math.floor(Math.random() * trabajos.length)];
        let ganancia = Math.floor(Math.random() * (200 - 100 + 1)) + 100; // Rango estricto $100 - $200

        // Aplicar multiplicador según respeto actual (tope +50% de bonus)
        const respetoActual = Number(user.respeto) || 0;
        const respetoBonus = Math.min(1.5, 1 + respetoActual / 2000);
        const gananciaFinal = Math.floor(ganancia * respetoBonus);
        const multiplier = premium.getPremiumMultiplier(userJidForPrem);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        // Aumentar la ganancia de dinero del usuario
        user.money = (user.money || 0) + gananciaPremium;

        // Actualizar el tiempo de trabajo
        user.lastWork = new Date();
        user.workedHours = (user.workedHours || 0) + 1;
        user.totalWorkedHours = (user.totalWorkedHours || 0) + 1;
        user.totalWorkedTimes = (user.totalWorkedTimes || 0) + 1;

        // 10% de probabilidad de sumar +1 de respeto
        if (Math.random() < 0.10) {
            user.respeto = (user.respeto || 0) + 1;
        }
        const achievementMessage = achievements.addAchievementProgress(user, 'work');

        // Guardar cambios en la base de datos
        global.db.setUser(senderNumber, user);
        global.db.save();

        // Formato de la respuesta con la información del trabajo realizado
        let profileInfo = `_Trabajaste de_ *${trabajoActual}* _y ganaste_ *$${gananciaPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            profileInfo += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }

        if (achievementMessage) {
            profileInfo += `\n\n${achievementMessage}`;
        }

        // Enviar respuesta sin menciones para evitar errores
        return await message.reply(profileInfo);
    } catch (error) {
        console.error('[ERROR] Error en trabajo:', error);
        return await message.reply('❌ Ocurrió un error al procesar el trabajo.');
    }
};

handler.help = ['work', 'trabajar'];
handler.tags = ['economy'];
handler.command = /^(work|trabajar)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;