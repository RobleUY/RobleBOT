// handler-minar.js
const premium = require('../../premium');

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        // Obtener usuario desde la DB
        let user = global.db.getUser(senderNumber);
        if (!user) {
            return await message.reply("❌ No se pudo cargar tu usuario en la base de datos.");
        }

        // Cooldown de minar (5 minutos comunes, 2.5 minutos premium)
        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        let cooldown = Math.floor(5 * 60 * 1000 * premiumMultiplier);
        let timeDiff = Date.now() - (new Date(user.lastMining)).getTime();

        if (timeDiff < cooldown) {
            const totalSeg = Math.ceil((cooldown - timeDiff) / 1000);
            const m = Math.floor(totalSeg / 60);
            const s = totalSeg % 60;
            const tiempoTexto = m > 0 ? `${m}m ${s}s` : `${s} segundos`;
            return await message.reply(`⏳ Debes esperar ${tiempoTexto} antes de volver a minar.`);
        }

        // Probabilidades y cantidades de cada mineral (ajustado para ganancias de $100 a $200)
        let mineralesProb = [
            { nombre: "CARBON", prob: 35, min: 10, max: 12 },
            { nombre: "HIERRO", prob: 25, min: 6, max: 8 },
            { nombre: "PLATA", prob: 15, min: 5, max: 6 },
            { nombre: "ORO", prob: 10, min: 4, max: 5 },
            { nombre: "DIAMANTE", prob: 8, min: 3, max: 4 },
            { nombre: "ESMERALDA", prob: 4, min: 3, max: 3 },
            { nombre: "RUBI", prob: 3, min: 2, max: 2 }
        ];

        // Precios de minerales
        let precios = {
            CARBON: 10,
            HIERRO: 18,
            PLATA: 25,
            ORO: 35,
            DIAMANTE: 45,
            ESMERALDA: 60,
            RUBI: 100
        };

        // Selección según probabilidad
        let totalProb = mineralesProb.reduce((sum, m) => sum + m.prob, 0);
        let rand = Math.random() * totalProb;
        let acumulado = 0;
        let obtenido = null;

        for (let m of mineralesProb) {
            acumulado += m.prob;
            if (rand <= acumulado) {
                let cantidad = Math.floor(Math.random() * (m.max - m.min + 1)) + m.min;
                user.minerales[m.nombre] += cantidad;
                obtenido = { nombre: m.nombre, cantidad };
                break;
            }
        }

        // Calcular venta inmediata
        let totalGanancia = 0;
        let detalleVenta = [];
        for (let mineral in user.minerales) {
            let cantidad = user.minerales[mineral] || 0;
            if (cantidad > 0) {
                let valor = precios[mineral] * cantidad;
                totalGanancia += valor;
                detalleVenta.push(`${mineral}: ${cantidad} x ${precios[mineral]} = ${valor}`);
                user.minerales[mineral] = 0; // resetear inventario
            }
        }

        // Aplicar multiplicador según respeto actual (tope +50% de bonus)
        const respeto = Number(user.respeto) || 0;
        const respetoBonus = Math.min(1.5, 1 + respeto / 2000);
        const gananciaFinal = Math.floor(totalGanancia * respetoBonus);
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const gananciaPremium = Math.floor(gananciaFinal * multiplier);

        // Actualizar datos
        user.money += gananciaPremium;
        user.lastMining = new Date();
        global.db.setUser(senderNumber, user);
        global.db.save();

        let response = `_Fuiste a minar y vendiste_ *${obtenido.cantidad}* _de_ *${obtenido.nombre}* _por:_ *$${gananciaPremium.toLocaleString()}*\n` +
            `_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error("[ERROR] Error en minería:", error);
        return await message.reply("❌ Ocurrió un error al procesar minería.");
    }
};

handler.help = ['minar'];
handler.tags = ['economy'];
handler.command = /^(minar|minerar|mine)$/i;

module.exports = handler;
handler.group = false;
handler.apodo = true;