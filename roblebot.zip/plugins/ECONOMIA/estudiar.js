const premium = require('../../premium');

// --- Mapa en memoria para cooldowns ---
const cooldowns = new Map();

let handler = async (message, { text }) => {
    try {
        const senderJid = message?.key?.participant
            || message?.participant
            || message?.author
            || message?.sender
            || (!message?.key?.remoteJid?.endsWith('@g.us') ? message?.key?.remoteJid : null)
            || message?.from;

        const senderNumber = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        let user = global.db.getUser(senderNumber);

        // Si no existe el usuario en la DB, inicializamos
        if (!user) {
            user = {
                money: 1000,
                bank: 0,
                respeto: 0,
                lastWork: 0,
                workedHours: 0,
                totalWorkedHours: 0,
                totalWorkedTimes: 0,
            };
            global.db.setUser(senderNumber, user);
        }

        const premiumMultiplier = premium.isPremium(senderNumber) ? 0.5 : 1;
        // --- Cooldown en memoria (5 minutos comunes, 2.5 minutos premium) ---
        const cooldown = Math.floor(5 * 60 * 1000 * premiumMultiplier);
        const now = Date.now();

        if (cooldowns.has(senderNumber)) {
            const last = cooldowns.get(senderNumber);
            const remaining = cooldown - (now - last);
            if (remaining > 0) {
                const totalSeg = Math.ceil(remaining / 1000);
                const m = Math.floor(totalSeg / 60);
                const s = totalSeg % 60;
                const tiempoTexto = m > 0 ? `${m}m ${s}s` : `${s} segundos`;
                return await message.reply(`📚 Debes esperar *${tiempoTexto}* antes de volver a estudiar.`);
            }
        }

        // Materias con recompensas (rango $100 - $200)
        const materias = [
            { nombre: "Matemáticas", pago: 150 },
            { nombre: "Historia", pago: 120 },
            { nombre: "Física", pago: 170 },
            { nombre: "Química", pago: 140 },
            { nombre: "Programación", pago: 190 },
            { nombre: "Economía", pago: 200 },
            { nombre: "Literatura", pago: 130 },
            { nombre: "Arte", pago: 110 },
            { nombre: "Idiomas", pago: 160 },
            { nombre: "Biología", pago: 150 },
        ];

        // Materia aleatoria
        const materia = materias[Math.floor(Math.random() * materias.length)];

        // Ganancia base
        const basePago = materia.pago;
        const respeto = Number(user.respeto) || 0;
        const respetoBonus = Math.min(1.5, 1 + respeto / 2000);
        const pagoFinal = Math.floor(basePago * respetoBonus);
        const multiplier = premium.getPremiumMultiplier(senderNumber);
        const pagoPremium = Math.floor(pagoFinal * multiplier);

        user.money += pagoPremium;
        // 10% de probabilidad de sumar +1 de respeto
        if (Math.random() < 0.10) {
            user.respeto = (user.respeto || 0) + 1;
        }
        global.db.setUser(senderNumber, user);

        // Guardar tiempo actual en memoria
        cooldowns.set(senderNumber, now);
        setTimeout(() => cooldowns.delete(senderNumber), cooldown);

        let response = `_Estudiaste_ *${materia.nombre}* _y ganaste_ *$${pagoPremium.toLocaleString()}*\n_Nuevo saldo:_ *$${user.money.toLocaleString()}*`;
        if (multiplier > 1) {
            response += `\n\n★ Como usuario premium recibiste el doble de recompensa.`;
        }
        return await message.reply(response);

    } catch (error) {
        console.error('[ERROR] Error en comando estudiar:', error);
        return await message.reply('❌ Ocurrió un error al intentar estudiar.');
    }
};

handler.help = ['estudiar'];
handler.tags = ['economy'];
handler.command = /^estudiar|study$/i;
handler.group = false;

module.exports = handler;
handler.apodo = true;