const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');
const { loadStats } = require('../botStatsRecorder');

const more = String.fromCharCode(8206);
const readMore = more.repeat(4000);

// === FUNCION PRINCIPAL DEL MENÚ ===
async function getMenuContent(conn, usedPrefix = '.') {

    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    const uptimeFormatted = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    // Próximo reinicio programado
    let nextRestartFormatted = 'N/A';
    if (global._nextRestartTime) {
        const nextMoment = moment.tz(global._nextRestartTime, 'America/Montevideo');
        const diffMs = global._nextRestartTime - Date.now();
        const diffMin = Math.max(0, Math.floor(diffMs / 60000));
        const rh = Math.floor(diffMin / 60);
        const rm = diffMin % 60;
        const countdownStr = rh > 0 ? `${rh}h ${rm}m` : `${rm}m`;
        nextRestartFormatted = `${nextMoment.format('HH:mm')} UY (en ${countdownStr})`;
    }

    // Stats del bot
    const activeSubBots = (global.subConns || []).filter(c => c?.user).length;
    const botStats = loadStats();
    const totalCommandsExecuted = botStats.totalCommandsExecuted || botStats.totalCommands || 0;
    const totalUsersDisplay = global.db?.countRealUsers ? global.db.countRealUsers() : 0;

    const menu = `
╔═════ ≪ 🤖 ≫ ═════
║   *ROBLEBOT MENÚ PRINCIPAL*
║
║  👑 *Creador:* RobleUY
║     _https://www.instagram.com/robleuy_
║  ⏳ *Bot activo hace:*
║          _${uptimeFormatted}_
║  🤖 *Subbots:* _${activeSubBots}_
║  👥 *Usuarios:* _${totalUsersDisplay}_
║  ⚡ *Comandos ejecutados:* _${totalCommandsExecuted}_
╚═════ ≪ 🤖 ≫ ═════
*¡Hola!* Usa el prefijo \`${usedPrefix}\` para
cualquier comando.
*Ejemplo:* ${usedPrefix}menu

💡 ¿Tenés dudas? Usá *${usedPrefix}ayuda* seguido de tu pregunta.
_Ej: ${usedPrefix}ayuda como ser subbot_
${readMore}

╔═════ ≪ 🤖 ≫ ═════
║   *SUBBOTS*
_Creá tu propio subbot, controlalo y gestioná su comportamiento en grupos._
╚══════════════
*⚙️ Crear Subbot*
\_${usedPrefix}qr | ${usedPrefix}code\_
> *Propósito:* Convertite en subbot con QR o código.

*🔛 Encender / Apagar tu Subbot*
\_${usedPrefix}bot apagar | ${usedPrefix}bot encender\_
> *Propósito:* Apaga o enciende tu subbot solo en el chat actual.

\_${usedPrefix}bot apagar global | ${usedPrefix}bot encender global\_
> *Propósito:* Apaga o enciende tu subbot en todos los chats a la vez.
> ⚠️ Al encender globalmente, los chats apagados manualmente siguen apagados.

\_${usedPrefix}bot priv on | ${usedPrefix}bot priv off\_
> *Propósito:* Activa o desactiva si tu subbot responde en chats privados.

\_${usedPrefix}bot grupo on | ${usedPrefix}bot grupo off\_
> *Propósito:* Activa o desactiva si tu subbot responde en grupos.

\_${usedPrefix}onmybot | ${usedPrefix}offmybot\_
> *Propósito:* Alias rápidos para encender/apagar tu subbot en el chat actual.

*👥 Control de Bots en el Grupo (Solo Admins del grupo)*
\_${usedPrefix}bots on | ${usedPrefix}bots off\_
> *Propósito:* Enciende o apaga todos los bots en el grupo.

\_${usedPrefix}bots admins\_
> *Propósito:* Pone todos los bots en modo solo administradores.

*🔄 Reconectar*
\_${usedPrefix}reconectar\_
> *Propósito:* Reconecta tu subbot en caso de caídas o lentitud.
> Nota: Solo funciona en chat privado con el bot principal.

\_${usedPrefix}mybot\_
> *Propósito:* Descubrí cuál es el ID de tu SubBot.
──────────────

╔═════ ≪ 🎰 ≫ ═════
║   *CASINO Y APUESTAS*
_Probá tu suerte en juegos de azar._
╚══════════════
\_${usedPrefix}apostar | ${usedPrefix}bj | ${usedPrefix}slot\_
\_${usedPrefix}caraocruz | ${usedPrefix}race\_
> *Propósito:* Prueba tu suerte apostando tu dinero.

\_${usedPrefix}apostar @usuario\_
> *Propósito:* Prueba tu suerte retando a otro usuario a una apuesta.
──────────────

╔═════ ≪ 💰 ≫ ═════
║   *ECONOMÍA Y BANCO*
_Gestioná tu dinero virtual: ahorrá, retirará y trabajá para conseguir más coins._
╚══════════════
*💼 Cuentas*
\_${usedPrefix}saldo\_
> *Propósito:* Verificá el saldo actual de tu cuenta.

\_${usedPrefix}depositar | ${usedPrefix}retirar | ${usedPrefix}darcoins\_
> *Propósito:* Depositá, retirà o regalà coins.

${' '.repeat(10)}
*🛠️ Ganar dinero*
\_${usedPrefix}work | ${usedPrefix}study | ${usedPrefix}slut | ${usedPrefix}crime\_
\_${usedPrefix}cazar | ${usedPrefix}minar | ${usedPrefix}robar @usuario\_
> *Propósito:* Ganà dinero realizando distintas acciones.

\_${usedPrefix}cadadia\_
> *Propósito:* Reclamá tu recompensa diaria.
${' '.repeat(10)}
*🏦 Préstamos*
\_${usedPrefix}prestamo <cantidad>\_
> *Propósito:* Solicitá un préstamo al banco.

\_${usedPrefix}prestamo pagar <cantidad|todo>\_
> *Propósito:* Pagá tu préstamo o la deuda completa.
──────────────

╔═════ ≪ ⬇️ ≫ ═════
║   *MULTIMEDIA Y DESCARGAS*
_Descargá audios, videos, apks e imágenes de distintas fuentes y redes sociales de forma directa._
╚══════════════
*🔗 Descargar*
\_${usedPrefix}ytvideo | ${usedPrefix}ytaudio | ${usedPrefix}pinterest\_
\_${usedPrefix}instagram | ${usedPrefix}facebook | ${usedPrefix}threads\_
\_${usedPrefix}twitter | ${usedPrefix}apk | ${usedPrefix}tiktok\_
\_${usedPrefix}playlist | ${usedPrefix}playlist2
> *Propósito:* Descargá contenido multimedia.

\_${usedPrefix}igreel <enlace o búsqueda>\_
> *Propósito:* Descargá o buscá reels de Instagram. Podés pegar un enlace directo o escribir un tema para buscar.

\_${usedPrefix}pinterest2 <búsqueda>\_
> *Propósito:* Buscá y descargá videos de Pinterest.
──────────────

╔═════ ≪ 🔎 ≫ ═════
║   *BUSCADORES*
_Realizá búsquedas rápidas en distintas plataformas de video._
╚══════════════
\_${usedPrefix}ytsearch | ${usedPrefix}ttsearch\_
> *Propósito:* Buscá videos en YouTube y obtené resultados.
──────────────

╔═════ ≪ 👤 ≫ ═════
║   *PERFIL Y SOCIAL*
_Personalizá tu perfil, gestioná amistades y compartí información social._
╚══════════════
*✨ Perfil*
\_${usedPrefix}perfil | ${usedPrefix}nivel\_
> *Propósito:* Muestra tu perfil completo y estadísticas.

*⬆ Nivel*
\_${usedPrefix}nivel\_
> *Propósito:* Muestra tu nivel y xp faltante para el siguiente.

*✨ Genero y Apodo*
\_${usedPrefix}genero  | ${usedPrefix}apodo\_
> *Propósito:* Cambia tu genero y apodo.

*❤️ Parejas*
\_${usedPrefix}pareja <estado|pedir|aceptar|rechazar|romper>\_
> *Propósito:* Gestioná tu estado civil (pedir matrimonio, aceptar, etc.).

*📱 Redes Sociales (Compartir)*
\_${usedPrefix}redes\_
> *Propósito:* Muestra las redes sociales registradas.

\_${usedPrefix}redes tiktok|instagram <usuario>\_
> *Propósito:* Registrá tu usuario de red social.


╔═════ ≪ � ≫ ═════
║   *RANKUP*
_Sube de rango y demuestra quien manda._
╚══════════════
*💪 Rankup*
\_${usedPrefix}rankup | ${usedPrefix}ranks | ${usedPrefix}rank\_
> *Propósito:* Sube de rango, consulta los rangos disponibles y tu rango actual.
──────────────

╔═════ ≪ ⚽ ≫ ═════
║   *FUTBOLISTAS*
_Coleccioná, reclamá e intercambiá futbolistas con otros usuarios._
╚══════════════
*🎁 Acciones*
_${usedPrefix}fpj reclamar_
> *Propósito:* Reclamá tu futbolista coleccionable diario.

_${usedPrefix}myfpj_
> *Propósito:* Muestra los futbolistas coleccionables que posees.
${' '.repeat(10)}
*🔄 Comercio*
_${usedPrefix}fpj vender <nombre> <cantidad|all>_
> *Propósito:* Vendé futbolistas coleccionables.

_${usedPrefix}fpj regalar @user <nombre>_
> *Propósito:* Regalá un futbolista a otro usuario.

_${usedPrefix}fpj intercambio @user <mi_fp> <su_fp>_
> *Propósito:* Proponé un intercambio de futbolistas.
──────────────

╔═════ ≪ 🧠 ≫ ═════
║   *PERSONAJES (ANIME)*
_Coleccioná, reclamá e intercambiá personajes de anime con otros usuarios._
╚══════════════
*🎁 Acciones*
_${usedPrefix}pj reclamar_
> *Propósito:* Reclamá tu personaje coleccionable diario.

_${usedPrefix}mypj_
> *Propósito:* Muestra los personajes coleccionables que posees.
${' '.repeat(10)}
*🔄 Comercio*
_${usedPrefix}pj vender <nombre> <cantidad|all>_
> *Propósito:* Vendé personajes coleccionables.

_${usedPrefix}pj regalar @user <nombre>_
> *Propósito:* Regalá un personaje a otro usuario.

_${usedPrefix}pj intercambio @user <mi_pj> <su_pj>_
> *Propósito:* Proponé un intercambio de personajes.
──────────────

╔═════ ≪ 🌟 ≫ ═════
║   *FAMOSOS*
_Coleccioná, reclamá e intercambiá famosos del mundo del espectáculo, deporte y tecnología._
╚══════════════
*🎁 Acciones*
_${usedPrefix}famoso reclamar_
> *Propósito:* Reclamá un famoso aleatorio (1 por hora).

_${usedPrefix}myfamoso_
> *Propósito:* Muestra los famosos que tenés en tu colección.
${' '.repeat(10)}
*🔍 Ver*
_${usedPrefix}famoso ver <nombre>_
> *Propósito:* Muestra la imagen de un famoso (solo si lo tenés).
${' '.repeat(10)}
*🔄 Intercambio*
_${usedPrefix}famoso regalar @user <nombre>_
> *Propósito:* Regalá un famoso a otro usuario.

_${usedPrefix}famoso intercambio @user <mi_famoso> <su_famoso>_
> *Propósito:* Proponé un intercambio de famosos.
──────────────

╔═════ ≪ 🎮 ≫ ═════
║   *JUEGOS Y ENTRETENIMIENTO*
_Diversión con duelos, adivinanzas, oráculos y el sistema de pene._
╚══════════════
*⚔️ Duelos*
\_${usedPrefix}ppt @user\_
> *Propósito:* Jugá Piedra, Papel o Tijera contra otro usuario.

*❓ Juegos*
\_${usedPrefix}describe | ${usedPrefix}emoji | ${usedPrefix}completar
\_${usedPrefix}ordenar | ${usedPrefix}trivia | ${usedPrefix}escribir
\_${usedPrefix}wordle\_ | ${usedPrefix}numle\_ | ${usedPrefix}ahorcado\_
\_${usedPrefix}ppt\_ | ${usedPrefix}tateti\_
> *Propósito:* Juega y diviertete.


*🔮 Oráculos y Decisiones*
\_${usedPrefix}quien | ${usedPrefix}siono\_
\_${usedPrefix}elegir | ${usedPrefix}quiero\_
> *Propósito:* Diviertete con respuestas random.
──────────────

╔═════ ≪ 🤣 ≫ ═════
║   *RANDOM E INTERACCIONES*
_Calculos random._
╚══════════════
*💖 Interacciones (con @usuario)*
\_${usedPrefix}love | ${usedPrefix}ship | ${usedPrefix}abrazar\_
\_${usedPrefix}besar | ${usedPrefix}follar | ${usedPrefix}matar | ${usedPrefix}golpear\_
> *Propósito:* Realizá una interacción con otro usuario.

*🔢 Calculadoras*
\_${usedPrefix}calcular1 | ${usedPrefix}calcular2 | ${usedPrefix}calcular3\_
\_${usedPrefix}ego | ${usedPrefix}drama | ${usedPrefix}banana\_
> *Propósito:* Muestra un resultado random.

*🔢 Poemmas Y Excusas*
\_${usedPrefix}poema\_
\_${usedPrefix}excusa\_
> *Propósito:*Genera un poema o una excusa usando ia.

──────────────

╔═════ ≪ 🖼️ ≫ ═════
║   *IMÁGENES Y STICKERS*
_Buscá contenido y creá stickers divertidos._
╚══════════════
*🎨 Generación y Búsqueda*

\_${usedPrefix}imagen | ${usedPrefix}pinterest\_
\_${usedPrefix}waifu | ${usedPrefix}bts | ${usedPrefix}blackpink\_
> *Propósito:* Obtené una imagen.

\_${usedPrefix}memes | ${usedPrefix}memes  <búsqueda>\_
> *Propósito:* Obtené una imagen de un meme random o de un termino de busqueda.

*🔄 Conversión*
\_${usedPrefix}toimg\_ (Sticker a Imagen)
> *Propósito:* Convertí un sticker a formato de imagen.

*🪅 Stickers*
\_${usedPrefix}sticker\_ (Imagen/Video)
> *Propósito:* Convertí una imagen, GIF o video corto en sticker.

\_${usedPrefix}brat <texto>\_
> *Propósito:* Creá un sticker con texto tipo "Brat Style".

\_${usedPrefix}brat2 <texto>\_
> *Propósito:* Creá un sticker de video animado con texto tipo "Brat Style".

\_${usedPrefix}ss <búsqueda>\_
> *Propósito:* Buscá y convertí videos de Tenor en stickers animados.

\_${usedPrefix}emojimix <2 emojis>\_
> *Propósito:* Combiná dos emojis en un sticker.

\_${usedPrefix}emojitos <emoji>\_
> *Propósito:* Convertí un emoji en sticker.

\_${usedPrefix}tts <texto>\_ (Texto a Sticker)
> *Propósito:* Creá un sticker simple con texto.

\_${usedPrefix}tts <texto> <color> <fondo>\_ (Personalizado)
> *Propósito:* Creá un sticker con texto, color de texto y color de fondo personalizados.
──────────────

╔═════ ≪ �🔧 ≫ ═════
║   *HERRAMIENTAS Y UTILITIES*
_Funciones útiles para el día a día, inteligencia artificial, edición y más._
╚══════════════
*🧠 Inteligencia Artificial*
\_${usedPrefix}ia <texto>\_ (Texto)
> *Propósito:* Conversá con el bot de forma inteligente.

\_${usedPrefix}iavoz <texto>\_ (Voz)
> *Propósito:* Enviá una nota de voz y recibí respuesta de la IA.

\_${usedPrefix}tradai <texto + idioma>\_
> *Propósito:* Traducí texto usando IA (ej: tradai Hola mundo inglés).

${' '.repeat(10)}
*✂️ Edición y Conversión*
\_${usedPrefix}efecto\_ (Audio)
> *Propósito:* Aplicá efectos a audios (subí la nota de voz y usá el comando).

\_${usedPrefix}removebg\_ (Imagen)
> *Propósito:* Remové el fondo de una imagen (enviá la imagen y usá el comando).

\_${usedPrefix}leer\_ (Transcribir Audio/Doc)
> *Propósito:* Transcribí el texto de un audio o documento.

\_${usedPrefix}tav <texto>\_ (Texto a Voz)
> *Propósito:* Convertí texto a audio (voz).
${' '.repeat(10)}
*📡 Stalkers*
\_${usedPrefix}ytstalk | ttstalk | igstalk <usuario>\_
> *Propósito:* Obtené información de un perfil de red social.

\_${usedPrefix}xstalk | tgstalk | thstalk <usuario>\_
> *Propósito:* Stalk de Twitter/X, Telegram o Threads.

\_${usedPrefix}ghstalk | ptstalk | steamstalk <usuario>\_
> *Propósito:* Stalk de GitHub, Pinterest o Steam.

\_${usedPrefix}mcstalk <usuario>\_
> *Propósito:* Información de un perfil de Minecraft.
${' '.repeat(10)}
*☁️ Otros*
\_${usedPrefix}clima <ciudad y pais>\_
> *Propósito:* Obtené el clima actual de una ubicación específica.

\_${usedPrefix}bandera <país>\_
> *Propósito:* Muestra la bandera e información del país (nombre oficial, capital, población, moneda, etc.).

\_${usedPrefix}fuente\_
> *Propósito:* Cambia la fuente (tipo de letra) de un texto.
──────────────

╔═════ ≪ 🛠️ ≫ ═════
║   *ADMINISTRACIÓN DE GRUPO*
_Comandos esenciales para moderadores y administradores de grupos._
╚══════════════
*ℹ️ Info y Links*
\_${usedPrefix}infog\_
> *Propósito:* Muestra la información del grupo.

\_${usedPrefix}link\_
> *Propósito:* Obtené el enlace de invitación del grupo.
${' '.repeat(10)}
*✍️ Edición*
\_${usedPrefix}nameg <texto>\_
> *Propósito:* Cambiá el nombre del grupo.

\_${usedPrefix}desc <texto>\_
> *Propósito:* Cambiá la descripción del grupo.
${' '.repeat(10)}
*👥 Miembros*
\_${usedPrefix}kick @user\_
> *Propósito:* Expulsá a un miembro del grupo.

\_${usedPrefix}warn @user <razón>\_
> *Propósito:* Advertí a un miembro. Al acumular 3 warns es expulsado automáticamente.

\_${usedPrefix}unwarn @user <1|2>\_
> *Propósito:* Eliminá una advertencia específica de un miembro.

\_${usedPrefix}warneados\_
> *Propósito:* Mostrá todos los miembros con advertencias activas en el grupo.

\_${usedPrefix}op @user\_
> *Propósito:* Nombrá a un miembro como administrador.

\_${usedPrefix}deop @user\_
> *Propósito:* Remové el estado de administrador de un miembro.

*🔒 Apertura/Cierre*
\_${usedPrefix}close\_
> *Propósito:* Cerrá el grupo (solo admins pueden escribir).

\_${usedPrefix}open\_
> *Propósito:* Abrí el grupo (todos pueden escribir).
──────────────

╔═════ ≪ 🎨 ≫ ═════
║   *COMANDOS PERSONALIZADOS*
_Crea tus propios comandos tipo mención con tus reglas y mensajes._
╚══════════════
*➕ Crear comando*
\_${usedPrefix}addcmd .nombre mensaje con @yo y @text\_
> *Propósito:* Crea un comando personalizado.
> *Variables disponibles:*
>   • @yo = tu mención
>   • @text = mención o texto que escribas
>   • @random = número aleatorio 0-100
>   • @randomUser = usuario aleatorio del grupo
> *Ejemplos:*
>   ${usedPrefix}addcmd .suerte La suerte de @text es @random%
>   ${usedPrefix}addcmd .abrazo @yo abraza a @text 🤗
>   ${usedPrefix}addcmd .sorpresa @yo sorprende a @randomUser 🎉
> *🤖 Crear con IA:*
>   ${usedPrefix}addcmd .ia quiero un comando que sea .suerte y al usarlo diga la suerte de @text es x%

*📋 Ver mis comandos*
\_${usedPrefix}mycmds\_
> *Propósito:* Muestra todos tus comandos personalizados creados.

*🗑️ Eliminar comando*
\_${usedPrefix}delcmd .nombre\_
> *Propósito:* Elimina uno de tus comandos personalizados.
──────────────

╔═════ ≪ 🤖 ≫ ═════
║   *IAs PERSONALIZADAS*
_Creá tu propio asistente de IA con personalidad y nombre propios._
╚══════════════
*➕ Crear IA*
\_${usedPrefix}addia .nombre prompt\_
> *Propósito:* Crea una IA personalizada con ese nombre e instrucciones.
> *Ejemplo:*
>   ${usedPrefix}addia .chefbot Eres un chef experto que solo habla de cocina
> *🤖 Crear con IA:*
>   ${usedPrefix}addia .ia Eres una ia llamada PO y siempre hablas sobre kung fu panda

*💬 Usar IA*
\_${usedPrefix}.nombreia mensaje\_
> *Propósito:* Chateá con cualquier IA personalizada creada en el bot.
> *Ejemplo:*
>   .chefbot ¿Cómo hago una pizza?

*📋 Ver mis IAs*
\_${usedPrefix}myia\_
> *Propósito:* Muestra todas las IAs personalizadas que creaste.

*🏆 Top IAs*
\_${usedPrefix}topia [página]\_
> *Propósito:* Muestra las IAs más usadas del bot.

*🗑️ Eliminar IA*
\_${usedPrefix}delia .nombre\_
> *Propósito:* Elimina una de tus IAs personalizadas.

\_${usedPrefix}delia all\_
> *Propósito:* Elimina todas tus IAs personalizadas de una vez.
──────────────

╔═════ ≪ 🏴 ≫ ═════
║   *CLANES*
_Formá tu clan, atacá enemigos, depositá fondos y luchá por la supremacía global._
╚══════════════
*📋 Información y Ranking*
\_${usedPrefix}clan_
> *Propósito:* Muestra el menú interactivo de clanes y todos los comandos disponibles.

\_${usedPrefix}clan top [página]\_
> *Propósito:* Ranking global de clanes ordenado por riqueza depositada. Incluye HP de cada clan.

\_${usedPrefix}clan info [nombre]\_
> *Propósito:* Ficha completa del clan: vida, estadísticas de combate, top 10 depositantes y tu rol. Si especificás un nombre ves la info de ese clan.
${' '.repeat(10)}
*⚔️ Combate*
\_${usedPrefix}clan atacar \u003cnombre_clan\u003e\_
> *Propósito:* Ataca a un clan enemigo causándole 10 HP de daño. Cooldown de 30 minutos por usuario. El clan atacado queda protegido 30 minutos.
> ⚠️ Si un clan llega a 0 HP es destruido y su dinero depositado se reparte entre los miembros del clan atacante como saldo depositado.

${' '.repeat(10)}
*💰 Economía del Clan*
\_${usedPrefix}clan depositar | deposite | dep | d \u003cmonto / % / all\u003e\_
> *Propósito:* Depositá dinero de tu billetera al clan. Ese dinero es tuyo dentro del clan y lo podés usar para reparar.
> ⚠️ *El dinero depositado al clan no se puede recuperar.*

\_${usedPrefix}clan reparar | repair [cantidad / all]\_
> *Propósito:* Reparás la vida de tu clan gastando tu dinero depositado. El costo escala: comienza en $50,000/HP y sube $50,000/HP con cada reparación que haga el clan.
${' '.repeat(10)}
*🆕 Sin Clan*
\_${usedPrefix}clan crear \u003cnombre\u003e\_
> *Propósito:* Creá un clan nuevo. El nombre va sin espacios, máx. 30 caracteres.
${' '.repeat(10)}
*👥 Miembro / Decano*
\_${usedPrefix}clan salir\_
> *Propósito:* Salís del clan (requiere confirmar con .clan salir confirmar). El líder no puede salir sin transferir el liderazgo.

\_${usedPrefix}clan invitaciones\_
> *Propósito:* Muestra las invitaciones pendientes que recibiste de otros clanes.

\_${usedPrefix}clan aceptar | rechazar \u003cclan/@invitador/apodo\u003e\_
> *Propósito:* Aceptás o rechazás una invitación a un clan.
${' '.repeat(10)}
*⭐ Decano y Líder*
\_${usedPrefix}clan invitar @user / apodo\_
> *Propósito:* Invitá a un usuario al clan. Límite: 30 miembros.

\_${usedPrefix}clan invitar cancelar @user / apodo\_
> *Propósito:* Cancelá una invitación pendiente.

\_${usedPrefix}clan expulsar @user / apodo\_
> *Propósito:* Expulsá a un miembro del clan.
${' '.repeat(10)}
*👑 Solo Líder*
\_${usedPrefix}clan decano agregar | borrar @user / apodo\_
> *Propósito:* Otorgá o quitá el rol de Decano a un miembro.

\_${usedPrefix}clan lider @user / apodo\_
> *Propósito:* Transferís el liderazgo a otro miembro (requiere confirmar con .clan lider confirmar).

\_${usedPrefix}clan nombre \u003cnuevo_nombre\u003e\_
> *Propósito:* Renombrá el clan.

\_${usedPrefix}clan borrar\_
> *Propósito:* Eliminá el clan por completo (requiere confirmar con .clan borrar confirmar).
──────────────

*🍆 Tu Pene y Tu Vagina 🌸*
\_${usedPrefix}mipene | ${usedPrefix}mivagina\_
\_${usedPrefix}toppenes | ${usedPrefix}topvaginas\_
\_${usedPrefix}chuparpene | ${usedPrefix}chuparvagina\_
> *Propósito:* Interactua con tu pene o tu vagina.

*💦 Masturbar*
\_${usedPrefix}masturbar\_
> *Propósito:* Te masturbas a ti mismo: sube +1 nivel tanto tu pene como tu vagina. Cooldown 1h.
──────────────

╔═════ ≪ 🎂 ≫ ═════
║   *CUMPLEAÑOS*
_Registrá tu cumpleaños y recibí felicitaciones automáticas en todos tus grupos._
╚══════════════
\\_${usedPrefix}micumple <día> <mes> <país>\\_
> *Propósito:* Registrá tu cumpleaños con tu país para recibir la hora correcta.
> *Ejemplo:* ${usedPrefix}micumple 13 enero uruguay

\\_${usedPrefix}cumpleaños\\_
> *Propósito:* Muestra todos los cumpleaños registrados y cuánto tiempo falta para cada uno.

\\_${usedPrefix}micumple test\\_
> *Propósito:* Prueba de felicitación de cumpleaños (solo owner).
> ⚠️ A las 00:02 de tu país, el bot te mencionará junto a todos los miembros en cada grupo donde estés.
──────────────

╔═════ ≪ 🔞 ≫ ═════
║   *CONTENIDO +18 (NSFW)*
_Sección de contenido adulto y explícito. *Úsala bajo tu propia responsabilidad*._
╚══════════════
*🎥 Videos*
\_${usedPrefix}xnxx <título|link>\_
\_${usedPrefix}xvideos <título|link>\_
> *Propósito:* Buscá y descargá videos de XVIDEOS.
\_${usedPrefix}xvideossearch <título>\_
> *Propósito:* Buscar enlaces de XVIDEOS.

\_${usedPrefix}hentaiv\_
> *Propósito:* Obtené un video Hentai aleatorio.
${' '.repeat(10)}
*🔞 Imágenes*
\_${usedPrefix}tetas\_
> *Propósito:* Obtené una imagen aleatoria de "tetas".
\_${usedPrefix}hotgirl\_
> *Propósito:* Obtené una imagen de "chica sexy" aleatoria.
──────────────

*✨ ROBLEBOT • v2.0*
_Developed BY: RobleUY_
`;

    return menu.trim();
}

// === LIMPIA EL TEXTO DEL MENÚ PARA GUARDARLO COMO TEXTO PLANO ===
function limpiarParaTxt(menuText) {
    return menuText
        .split('\n')
        .map(l => {
            // chars invisibles / readMore
            l = l.replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\u200e\u200d\ufeff]/g, '');
            // formato WhatsApp
            l = l.replace(/\*([^*\n]+)\*/g, '$1');
            l = l.replace(/_([^_\n]+)_/g, '$1');
            l = l.replace(/`([^`\n]+)`/g, '$1');
            l = l.replace(/~([^~\n]+)~/g, '$1');
            // cita "> "
            l = l.replace(/^>\s*/, '');
            // escapes \_ \* etc
            l = l.replace(/\\([_*`~\\])/g, '$1');
            // caracteres de caja y separadores
            l = l.replace(/[╔╗╚╝║═≪≫]/g, '');
            // emojis de número: 1️⃣ 2️⃣ etc
            l = l.replace(/\d\uFE0F\u20E3/g, '');
            l = l.replace(/\d️⃣/g, '');
            // todos los emojis
            l = l.replace(/[\u{1F000}-\u{1FFFF}]/gu, '');
            l = l.replace(/[\u{2600}-\u{27BF}]/gu, '');
            l = l.replace(/[\u{2300}-\u{23FF}]/gu, '');
            l = l.replace(/[\u{FE00}-\u{FEFF}]/gu, '');
            l = l.replace(/[\u{1F900}-\u{1F9FF}]/gu, '');
            l = l.replace(/[\u{1FA00}-\u{1FA6F}]/gu, '');
            // "Propósito: " redundante
            l = l.replace(/^Propósito:\s*/i, '');
            return l.trim();
        })
        .filter(l => {
            if (!l) return false;
            if (/^\s+$/.test(l)) return false;
            if (/^[-─━═•·▬▪\s]{3,}$/.test(l)) return false;
            return true;
        })
        .join('\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

// === GUARDA AUTOMÁTICAMENTE EL MENÚ EN UN ARCHIVO ===
async function saveMenuFile(menuText) {
    try {
        const menuFilePath = path.join(__dirname, '..', 'menu.txt');
        const limpio = limpiarParaTxt(menuText);
        fs.writeFileSync(menuFilePath, limpio, 'utf8');
        console.log('✅ menu.txt actualizado.');
    } catch (error) {
        console.error('❌ Error al guardar menu.txt:', error);
    }
}

// === GENERA menu.txt AL ARRANCAR (sin conn, con prefix por defecto) ===
(async () => {
    try {
        const menuFilePath = path.join(__dirname, '..', 'menu.txt');
        // Generar con un conn mínimo falso — solo necesitamos el texto estático
        const fakeConn = {};
        const menuText = await getMenuContent(fakeConn, '.');
        const limpio = limpiarParaTxt(menuText);
        fs.writeFileSync(menuFilePath, limpio, 'utf8');
        console.log('✅ menu.txt generado al arrancar.');
    } catch (e) {
        console.error('❌ Error generando menu.txt al arrancar:', e.message);
    }
})();

// === HANDLER DEL COMANDO ===
let handler = async (message, { conn }) => {
    try {
        const usedPrefix = (message.body && message.body.charAt(0)) || '.';
        const menuText = await getMenuContent(conn, usedPrefix);

        // Envía el menú al chat inmediatamente
        await message.reply(menuText);

        // Guardar menú en disco en segundo plano (sin bloquear la respuesta)
        saveMenuFile(menuText).catch(() => { });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Error al mostrar el menú:', error, '\x1b[0m');
        return await message.reply('❌ Ocurrió un error al mostrar el menú.');
    }
};

handler.help = ['menu', 'menú'];
handler.tags = ['info'];
handler.command = /^(menu|menú|comandos|juegos)$/i;
handler.getMenuContent = getMenuContent;

module.exports = handler;
