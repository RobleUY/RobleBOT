const db = require('../database.js');
const premium = require('../premium.js');
const botConfig = require('../config.js');

let handler = async (message, { args, text, command, usedPrefix, conn }) => {
    try {
        const senderJid = message?.key?.participant || message?.key?.remoteJid || message?.sender || message?.from;
        const cleanSender = (senderJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

        const isOwner = (typeof botConfig.isOwner === 'function' && (botConfig.isOwner(cleanSender) || botConfig.isOwner(`${cleanSender}@s.whatsapp.net`))) ||
                        (Array.isArray(botConfig.adminsbot) && (botConfig.adminsbot.includes(cleanSender) || botConfig.adminsbot.includes(senderJid))) ||
                        (Array.isArray(botConfig.owners) && botConfig.owners.some(o => (o || '').toString().replace(/\D/g, '') === cleanSender));

        if (!isOwner) {
            return await message.reply('⛔ *Acceso denegado:* Este comando solo puede ser utilizado por el propietario o administradores del bot.');
        }

        const input = (args[0] || '').trim().toLowerCase();

        // ── CASO 1: Resetear a un usuario específico ──────────────────────────
        const mentionedJid = message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        let targetParam = mentionedJid || args[0];

        if (targetParam && input !== 'all' && input !== 'todos') {
            let targetClean = (targetParam || '').split('@')[0].split(':')[0].replace(/\D/g, '');
            let canonicalId = null;

            if (targetClean && targetClean.length >= 7) {
                canonicalId = (typeof db.getCanonicalId === 'function') ? (db.getCanonicalId(targetClean) || targetClean) : targetClean;
            } else {
                const found = premium.findNumberByApodo(targetParam);
                if (found) canonicalId = found;
            }

            if (!canonicalId) {
                return await message.reply(`❌ No se encontró ningún usuario con el identificador: *${targetParam}*`);
            }

            const user = db.getUser(canonicalId);
            if (!user) {
                return await message.reply(`❌ El usuario con ID *${canonicalId}* no existe en la base de datos.`);
            }

            const wasClaimed = !!user.premium_free_claimed;
            delete user.premium_free_claimed;
            db.setUser(canonicalId, user);
            if (typeof db.saveNow === 'function') db.saveNow();

            const apodo = user.apodo || canonicalId;
            return await message.reply(
                `✅ *Reclamo de Premium Gratuito Reseteado*\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `👤 *Usuario:* @${apodo}\n` +
                `📱 *ID:* ${canonicalId}\n` +
                `🔄 *Estado anterior:* ${wasClaimed ? 'Ya había reclamado' : 'No tenía reclamo registrado'}\n\n` +
                `👉 Este usuario ya puede volver a reclamar su día de Premium Gratis desde la página web.`
            );
        }

        // ── CASO 2: Resetear a TODOS los usuarios que hayan reclamado ────────
        const rows = db._stmts ? db._stmts.getAllUsers.all() : [];
        let resetCount = 0;

        for (const row of rows) {
            try {
                const user = JSON.parse(row.data);
                if (user && user.premium_free_claimed) {
                    delete user.premium_free_claimed;
                    const jsonStr = JSON.stringify(user);
                    db._stmts.setUser.run(row.id, jsonStr);
                    if (db._userCache && db._userCache.has(row.id)) {
                        db._userCache.get(row.id).obj = user;
                    }
                    resetCount++;
                }
            } catch (_) {}
        }

        if (typeof db.saveNow === 'function') {
            db.saveNow();
        }

        return await message.reply(
            `🎉 *¡REINICIO DE PREMIUM GRATIS COMPLETADO!*\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Se ha reseteado el registro de Premium Gratuito para *${resetCount} usuario(s)*.\n\n` +
            `✅ *Ahora todas las personas que ya habían reclamado pueden volver a reclamar su Premium Gratis (1 día) en la página web.*`
        );

    } catch (e) {
        console.error('[resetfreeclaim] Error:', e);
        return await message.reply(`❌ Ocurrió un error al procesar el reinicio: ${e.message}`);
    }
};

handler.help = ['resetfreeclaim', 'resetfreeclaim all', 'resetfreeclaim @usuario'];
handler.tags = ['owner', 'admin'];
handler.command = /^(resetfreeclaim|resetfree|resetpremiumgratis|resetclaim)$/i;
handler.owner = true;

module.exports = handler;

