/**
 * SISTEMA DE RESET AUTOMÁTICO DE TEMPORADA
 * 
 * Este módulo se encarga de ejecutar automáticamente el reset de temporada
 * cada día 1 de cada mes a las 00:05 hora de Uruguay (UTC-3).
 * 
 * Filosofía de Lista Blanca (Whitelist):
 * Para evitar que queden datos obsoletos o que se pierdan datos futuros al agregar
 * nuevas características, la reconstrucción de objetos se hace utilizando una lista
 * blanca definida en `data/reset-whitelist.json`. Todo lo que no esté explícitamente
 * en la lista blanca de conservar se reinicia de cero.
 */

const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const { resetAllStats } = require('./botStatsRecorder');

// Zona horaria de Uruguay: America/Montevideo
const URUGUAY_TIMEZONE = 'America/Montevideo';

// Estado global para bloquear comandos durante el reinicio
global.isSeasonResetting = false;

function isSeasonResetting() {
  return !!global.isSeasonResetting;
}

/**
 * Función auxiliar para borrar un directorio y todo su contenido recursivamente
 */
function deleteFolderRecursive(folderPath) {
  if (fs.existsSync(folderPath)) {
    fs.readdirSync(folderPath).forEach((file) => {
      const curPath = path.join(folderPath, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        deleteFolderRecursive(curPath);
      } else {
        try { fs.unlinkSync(curPath); } catch (_) {}
      }
    });
    try { fs.rmdirSync(folderPath); } catch (_) {}
  }
}

/**
 * Función que ejecuta el reset de temporada completo
 */
async function ejecutarResetTemporada(sock = null, isAutomatic = false) {
  try {
    // Activar bloqueo de comandos para los usuarios durante el reinicio
    global.isSeasonResetting = true;

    const logPrefix = isAutomatic ? '[RESET AUTOMÁTICO]' : '[RESET MANUAL]';
    
    console.log('\n🔄 ========================================');
    console.log(`🔄 ${logPrefix} INICIANDO RESET DE TEMPORADA (BLOQUEO ACTIVO 1 MIN)`);
    console.log('🔄 ========================================\n');

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
    const backupResults = [];
    const resetResults = [];

    // Rutas principales
    const databasePath = path.join(__dirname, 'database.db');
    const botstatsPath = path.join(__dirname, 'data', 'botstats.json');
    const iasPath = path.join(__dirname, 'data', 'ias-personalizadas.json');
    const comandosPath = path.join(__dirname, 'data', 'comandos.json');
    const subbotActividadPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', 'subbots-actividad.json');
    const whitelistPath = path.join(__dirname, 'data', 'reset-whitelist.json');

    // Cargar configuración de lista blanca (whitelist)
    let whitelist = {
      userFieldsToKeep: ['apodo'],
      clanFieldsToKeep: ['nombre', 'lider', 'decanos', 'miembros', 'invitaciones', 'creadoEn', 'logo', 'banner', 'descripcion'],
      kvCollectionsToKeep: ['parejas', 'aliases']
    };

    if (fs.existsSync(whitelistPath)) {
      try {
        const rawWl = fs.readFileSync(whitelistPath, 'utf8');
        const parsedWl = JSON.parse(rawWl);
        if (parsedWl.userFieldsToKeep) whitelist.userFieldsToKeep = parsedWl.userFieldsToKeep;
        if (parsedWl.clanFieldsToKeep) whitelist.clanFieldsToKeep = parsedWl.clanFieldsToKeep;
        if (parsedWl.kvCollectionsToKeep) whitelist.kvCollectionsToKeep = parsedWl.kvCollectionsToKeep;
        console.log('📋 Lista blanca cargada desde data/reset-whitelist.json');
      } catch (wlErr) {
        console.warn('⚠️ Error leyendo reset-whitelist.json, usando lista blanca por defecto:', wlErr.message);
      }
    }

    // ============ PASO 1: FLUSH PREVIO Y BACKUPS ============
    console.log('📦 Guardando datos pendientes y creando backups de seguridad...\n');

    if (global.db && typeof global.db.saveNow === 'function') {
      await global.db.saveNow();
    }

    // SQLite WAL Checkpoint previo
    if (global.db && global.db.db) {
      try {
        global.db.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
      } catch (_) {}
    }

    // Backup database.db (SQLite)
    try {
      if (global.db && typeof global.db.backup === 'function') {
        const backupDbPath = global.db.backup();
        backupResults.push(`✅ database.db (${backupDbPath ? path.basename(backupDbPath) : 'creado'})`);
        console.log('   ✅ Backup de database.db creado');
      } else if (fs.existsSync(databasePath)) {
        const backupDbPath = path.join(__dirname, `database_backup_${timestamp}.db`);
        fs.copyFileSync(databasePath, backupDbPath);
        backupResults.push('✅ database.db (copia directa)');
        console.log('   ✅ Backup de database.db creado');
      }
    } catch (err) {
      backupResults.push('❌ database.db: ' + err.message);
    }

    // Backup botstats.json
    try {
      if (fs.existsSync(botstatsPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-botstats-${timestamp}.json`);
        fs.copyFileSync(botstatsPath, backupPath);
        backupResults.push('✅ botstats.json');
      }
    } catch (err) { backupResults.push('❌ botstats.json: ' + err.message); }

    // Backup ias-personalizadas.json
    try {
      if (fs.existsSync(iasPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-ias-personalizadas-${timestamp}.json`);
        fs.copyFileSync(iasPath, backupPath);
        backupResults.push('✅ ias-personalizadas.json');
      }
    } catch (err) { backupResults.push('❌ ias-personalizadas.json: ' + err.message); }

    // Backup comandos.json
    try {
      if (fs.existsSync(comandosPath)) {
        const backupPath = path.join(__dirname, 'data', `backup-comandos-${timestamp}.json`);
        fs.copyFileSync(comandosPath, backupPath);
        backupResults.push('✅ comandos.json');
      }
    } catch (err) { backupResults.push('❌ comandos.json: ' + err.message); }

    // Backup subbots-actividad.json
    try {
      if (fs.existsSync(subbotActividadPath)) {
        const backupPath = path.join(__dirname, 'plugins', 'SUBBOTS', 'data', `backup-subbots-actividad-${timestamp}.json`);
        fs.copyFileSync(subbotActividadPath, backupPath);
        backupResults.push('✅ subbots-actividad.json');
      }
    } catch (err) { backupResults.push('❌ subbots-actividad.json: ' + err.message); }

    console.log('\n🔄 Iniciando reset de datos...\n');

    // ============ PASO 2: BORRADO COMPLETO DE DATABASE.DB ============
    // En lugar de resetear campo a campo, borramos el archivo directamente.
    // El bot lo recreará vacío al reiniciarse, conservando solo lo de botstats/clanes/etc.

    try {
      // Liberar el handle de SQLite antes de borrar el archivo
      if (global.db && global.db.db) {
        try { global.db.db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}
        try { global.db.db.close(); } catch (_) {}
        global.db.db = null;
      }

      const dbFiles = [databasePath, databasePath + '-shm', databasePath + '-wal'];
      let borrados = 0;
      for (const f of dbFiles) {
        if (fs.existsSync(f)) {
          fs.unlinkSync(f);
          borrados++;
        }
      }
      resetResults.push(`✅ database.db eliminado (${borrados} archivos: .db, -shm, -wal)`);
      console.log(`   ✅ database.db eliminado completamente (${borrados} archivos).`);
    } catch (errDb) {
      resetResults.push('❌ Borrar database.db: ' + errDb.message);
      console.error('   ❌ Error borrando database.db:', errDb.message);
    }

    // ============ PASO 3: RESET Y BORRADO DE ARCHIVOS DE DATOS ============

    // 1. Borrar carpeta data/chats/
    try {
      const chatsDir = path.join(__dirname, 'data', 'chats');
      if (fs.existsSync(chatsDir)) {
        deleteFolderRecursive(chatsDir);
        resetResults.push('✅ data/chats/: Carpeta y base de datos eliminadas');
        console.log('   ✅ data/chats/ eliminada.');
      }
    } catch (err) { resetResults.push('❌ data/chats/: ' + err.message); }

    // 2. Borrar carpeta data/NOTAS-VOZ-GUARDADAS/
    try {
      const notasDir = path.join(__dirname, 'data', 'NOTAS-VOZ-GUARDADAS');
      if (fs.existsSync(notasDir)) {
        deleteFolderRecursive(notasDir);
        resetResults.push('✅ data/NOTAS-VOZ-GUARDADAS/: Carpeta eliminada');
        console.log('   ✅ data/NOTAS-VOZ-GUARDADAS/ eliminada.');
      }
    } catch (err) { resetResults.push('❌ data/NOTAS-VOZ-GUARDADAS/: ' + err.message); }

    // 3. Resetear data/botstats.json y limpiar estadísticas en memoria
    try {
      resetAllStats();
      resetResults.push('✅ data/botstats.json: Estadísticas reseteadas a 0');
      console.log('   ✅ data/botstats.json reseteado a 0.');
    } catch (err) { resetResults.push('❌ data/botstats.json: ' + err.message); }

    // 4. Borrar data/huertos.json
    try {
      const huertosPath = path.join(__dirname, 'data', 'huertos.json');
      if (fs.existsSync(huertosPath)) {
        fs.unlinkSync(huertosPath);
        resetResults.push('✅ data/huertos.json: Archivo eliminado');
        console.log('   ✅ data/huertos.json eliminado.');
      }
    } catch (err) { resetResults.push('❌ data/huertos.json: ' + err.message); }

    // 5. Borrar data/mascotas.json
    try {
      const mascotasPath = path.join(__dirname, 'data', 'mascotas.json');
      if (fs.existsSync(mascotasPath)) {
        fs.unlinkSync(mascotasPath);
        resetResults.push('✅ data/mascotas.json: Archivo eliminado');
        console.log('   ✅ data/mascotas.json eliminado.');
      }
    } catch (err) { resetResults.push('❌ data/mascotas.json: ' + err.message); }

    // 6. Resetear data/comandos.json (usos = 0, usuariosUsados = [])
    try {
      if (fs.existsSync(comandosPath)) {
        const comandosData = JSON.parse(fs.readFileSync(comandosPath, 'utf8'));
        let count = 0;
        if (comandosData.commands) {
          for (const cmdKey in comandosData.commands) {
            const cmd = comandosData.commands[cmdKey];
            if (cmd) {
              cmd.uses = 0;
              cmd.usedBy = [];
              count++;
            }
          }
        }
        fs.writeFileSync(comandosPath, JSON.stringify(comandosData, null, 2), 'utf8');
        resetResults.push(`✅ Comandos Personalizados: ${count} comandos reseteados a 0 usos`);
        console.log(`   ✅ Comandos Personalizados: ${count} comandos reseteados.`);
      }
    } catch (err) { resetResults.push('❌ Comandos Personalizados: ' + err.message); }

    // 7. Resetear data/ias-personalizadas.json (usos = 0, usuariosUsados = [])
    try {
      if (fs.existsSync(iasPath)) {
        const iasData = JSON.parse(fs.readFileSync(iasPath, 'utf8'));
        let count = 0;
        if (iasData.ias) {
          for (const iaKey in iasData.ias) {
            const ia = iasData.ias[iaKey];
            if (ia) {
              ia.uses = 0;
              ia.usedBy = [];
              count++;
            }
          }
        }
        fs.writeFileSync(iasPath, JSON.stringify(iasData, null, 2), 'utf8');
        resetResults.push(`✅ IAs Personalizadas: ${count} IAs reseteadas a 0 usos`);
        console.log(`   ✅ IAs Personalizadas: ${count} IAs reseteadas.`);
      }
    } catch (err) { resetResults.push('❌ IAs Personalizadas: ' + err.message); }

    // 8. Resetear plugins/SUBBOTS/data/subbots-actividad.json (commandCount = 0, lastUsed = 0)
    try {
      if (fs.existsSync(subbotActividadPath)) {
        const subActData = JSON.parse(fs.readFileSync(subbotActividadPath, 'utf8'));
        let count = 0;
        for (const subKey in subActData) {
          if (subActData[subKey]) {
            subActData[subKey].commandCount = 0;
            subActData[subKey].lastUsed = 0;
            count++;
          }
        }
        fs.writeFileSync(subbotActividadPath, JSON.stringify(subActData, null, 2), 'utf8');
        resetResults.push(`✅ Subbots Actividad: ${count} subbots reseteados a 0 comandos`);
        console.log(`   ✅ Subbots Actividad: ${count} subbots reseteados.`);
      }
    } catch (err) { resetResults.push('❌ Subbots Actividad: ' + err.message); }

    // ============ PASO 4: LIMPIEZA DE CACHÉS EN MEMORIA ============
    console.log('\n🧹 Limpiando cachés en memoria...\n');

    // Limpiar cachés del objeto db (el archivo ya fue borrado, solo limpiamos memoria)
    if (global.db) {
      if (global.db._userCache && typeof global.db._userCache.clear === 'function') {
        global.db._userCache.clear();
      }
      if (global.db._kvCache && typeof global.db._kvCache.clear === 'function') {
        global.db._kvCache.clear();
      }
      if (global.db._usersMapCache) {
        global.db._usersMapCache = null;
      }
    }

    // Invalidad caché en subbotActivityTracker si está cargado
    try {
      const subActivityTracker = require('./plugins/SUBBOTS/subbotActivityTracker');
      if (typeof subActivityTracker.loadActivity === 'function') {
        subActivityTracker.loadActivity();
      }
    } catch (_) {}

    // Reinicializar SQLite vacía en caliente para cuando se complete el minuto
    if (global.db && typeof global.db._openDb === 'function') {
      try {
        global.db._openDb();
        global.db._initSchema();
        console.log('   ✅ SQLite reinicializada en caliente (base limpia creada).');
      } catch (errDbReinit) {
        console.error('   ❌ Error al reinicializar SQLite:', errDbReinit.message);
      }
    }

    console.log('\n✅ ========================================');
    console.log('✅ RESET DE TEMPORADA COMPLETADO');
    console.log('⏳ Bloqueo activo 1 minuto (hasta la 01:00). A la 01:00 se reiniciará el servidor...');
    console.log('✅ ========================================\n');

    // A la 01:00 (1 minuto después de las 00:59), reiniciar el servidor exactamente como .reiniciar
    setTimeout(() => {
      global.isSeasonResetting = false;
      console.log('\n🔄 [RESET DE TEMPORADA] 01:00 Alcanzada. Reiniciando el servidor por completo...\n');
      if (typeof global.forceRestart === 'function') {
        global.forceRestart();
      } else {
        process.exit(1);
      }
    }, 60000);

    return { success: true, resetResults, backupResults };

  } catch (error) {
    console.error('❌ ERROR FATAL DURANTE EL RESET:', error);
    setTimeout(() => {
      global.isSeasonResetting = false;
      if (typeof global.forceRestart === 'function') {
        global.forceRestart();
      } else {
        process.exit(1);
      }
    }, 60000);
    return { success: false, error: error.message };
  }
}

/**
 * Inicializar el sistema de reset automático
 */
function inicializarResetAutomatico(sock) {
  console.log('\n🤖 Inicializando sistema de reset automático de temporada...');
  
  // Cron para ejecutar todos los días a las 00:59 hora de Uruguay
  const cronExpression = '59 0 * * *';
  
  const task = cron.schedule(cronExpression, async () => {
    console.log('\n⏰ CRON DISPARADO (00:59): Ejecutando reset de temporada diario...');
    await ejecutarResetTemporada(sock, true);
  }, {
    scheduled: true,
    timezone: URUGUAY_TIMEZONE
  });
  
  console.log(`✅ Reset automático programado:`);
  console.log(`   📅 Frecuencia: Todos los días`);
  console.log(`   🕐 Hora reset: 00:59 hora Uruguay`);
  console.log(`   🔄 Hora reinicio servidor: 01:00 hora Uruguay`);
  console.log(`   🌍 Zona horaria: ${URUGUAY_TIMEZONE}`);
  console.log(`   📋 Expresión cron: ${cronExpression}\n`);
  
  return task;
}

module.exports = {
  inicializarResetAutomatico,
  ejecutarResetTemporada,
  isSeasonResetting
};
