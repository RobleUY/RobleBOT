const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Configuración
const MAX_FILE_SIZE_MB = 300;
const TEMP_DIR = path.join(__dirname, '.temp');

// Crear directorio stemporal si no existe
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// Headers por defecto para evitar bloqueos (googlevideo.com, etc.)
const DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Referer': 'https://www.youtube.com/',
    'Origin': 'https://www.youtube.com'
};

const { limitMediaJob } = require('./lib/mediaLimiter');

/**
 * Descargar archivo con límite de tamaño
 * @param {string} url - URL del archivo
 * @param {number} maxSizeMB - Tamaño máximo en MB (opcional, por defecto 300MB)
 * @param {object} extraHeaders - Headers adicionales (opcional)
 * @returns {Promise<{buffer: Buffer, size: number, tempFile: string, sizeMB: string}>}
 */
async function downloadWithLimit(url, maxSizeMB = MAX_FILE_SIZE_MB, extraHeaders = {}, signal = null) {
    return limitMediaJob(async () => {
        if (signal?.aborted) {
            throw new Error('DOWNLOAD_ABORTED');
        }
        const maxBytes = maxSizeMB * 1024 * 1024;
        const headers = { ...DEFAULT_HEADERS, ...extraHeaders };

        try {
            // HEAD request para verificar tamaño antes de descargar
            const headResponse = await axios.head(url, {
                timeout: 7000,
                headers,
                signal
            }).catch(() => null);

            if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED');

            if (headResponse?.headers['content-length']) {
                const contentLength = parseInt(headResponse.headers['content-length']);
                if (contentLength > maxBytes) {
                    const sizeMB = (contentLength / (1024 * 1024)).toFixed(2);
                    throw new Error(`LIMIT_EXCEEDED:${sizeMB}`);
                }
            }

            // Descargar el archivo con timeout optimizado (60s en lugar de 120s para no bloquear slots)
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: 60000,
                maxContentLength: maxBytes,
                maxBodyLength: maxBytes,
                headers,
                signal
            });

            if (signal?.aborted) throw new Error('DOWNLOAD_ABORTED');

            const buffer = Buffer.from(response.data);
            const size = buffer.length;

            // Verificar tamaño después de descargar
            if (size > maxBytes) {
                const sizeMB = (size / (1024 * 1024)).toFixed(2);
                throw new Error(`LIMIT_EXCEEDED:${sizeMB}`);
            }

            // Guardar en archivo temporal asíncronamente (evita bloquear el event loop)
            const tempFileName = `download_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            const tempFilePath = path.join(TEMP_DIR, tempFileName);
            await fs.promises.writeFile(tempFilePath, buffer);

            return {
                buffer,
                size,
                tempFile: tempFilePath,
                sizeMB: (size / (1024 * 1024)).toFixed(2)
            };

        } catch (error) {
            if (axios.isCancel(error) || error.name === 'CanceledError' || error.name === 'AbortError' || signal?.aborted) {
                throw new Error('DOWNLOAD_ABORTED');
            }
            if (error.message?.startsWith('LIMIT_EXCEEDED:')) throw error;
            if (error.code === 'ERR_FR_MAX_BODY_LENGTH_EXCEEDED') throw new Error(`LIMIT_EXCEEDED:${maxSizeMB}`);
            throw error;
        }
    });
}

/**
 * Limpiar archivo temporal
 * @param {string} tempFile - Ruta del archivo temporal
 */
function cleanupTempFile(tempFile) {
    try {
        if (tempFile && fs.existsSync(tempFile)) {
            fs.unlinkSync(tempFile);
        }
    } catch (error) {
        console.error('[downloadUtils] Error limpiando archivo temporal:', error.message);
    }
}

/**
 * Limpiar archivos temporales antiguos (más de 1 hora)
 */
function cleanupOldTempFiles() {
    try {
        if (!fs.existsSync(TEMP_DIR)) return;

        const files = fs.readdirSync(TEMP_DIR);
        const now = Date.now();
        const oneHour = 60 * 60 * 1000;
        let cleaned = 0;

        for (const file of files) {
            const filePath = path.join(TEMP_DIR, file);
            try {
                const stats = fs.statSync(filePath);
                if (now - stats.mtimeMs > oneHour) {
                    fs.unlinkSync(filePath);
                    cleaned++;
                }
            } catch (e) {
                // Ignorar errores en archivos individuales
            }
        }

        if (cleaned > 0) {
            console.log(`[downloadUtils] 🧹 Limpiados ${cleaned} archivos temporales antiguos`);
        }
    } catch (error) {
        console.error('[downloadUtils] Error limpiando archivos antiguos:', error.message);
    }
}

// Limpiar archivos antiguos cada 30 minutos
setInterval(cleanupOldTempFiles, 30 * 60 * 1000);

// Limpiar al iniciar
cleanupOldTempFiles();

module.exports = {
    downloadWithLimit,
    cleanupTempFile,
    cleanupOldTempFiles,
    MAX_FILE_SIZE_MB,
    TEMP_DIR
};
